cd main_app
mvn clean package -Pcloud,postgresql -Dwar.output.directory=cloud_dist $2
cd ../srf-webapp-html5
mvn clean package
cd ..
cp -r main_app/cloud_dist/srt.war $1/webapps/
cp -r srf-webapp-html5/target/srt-html5.war $1/webapps/

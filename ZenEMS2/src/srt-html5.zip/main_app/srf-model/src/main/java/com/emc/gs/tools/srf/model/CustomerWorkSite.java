/*
 * This code is copyright (c) 2013 - 2014 EMC Corporation.
 */
package com.emc.gs.tools.srf.model;

import com.emc.gs.tools.srf.model.engagement.DeliveryCountry;
import com.emc.gs.tools.srf.model.Region;

/**
 * <p>
 * This is CustomerWorkSite entity class.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safety.
 * </p>
 * 
 * <p>
 * <strong>Changes V1.1:</strong>
 * <strong>SRT 1.1 DEC 2014 Updates Assembly</strong>
 * <ul>
 * <li>Replaced siteLocation field with deliveryCountry, deliveryRegion and deliveryCity fields.</li>
 * </ul>
 * </p>
 *
 * @author faeton, stevenfrog, MonicaMuranyi
 * @version 1.1
 */
public class CustomerWorkSite extends IdentifiableEntity {
    /**
     * <p>
     * The siteName.
     * </p>
     */
    private String siteName;

    /**
     * <p>
     * The deliveryCountry.
     * </p>
     */
    private DeliveryCountry deliveryCountry;
    
    /**
     * <p>
     * The deliveryRegion.
     * </p>
     */
    private Region deliveryRegion;
    
    /**
     * <p>
     * The deliveryCity.
     * </p>
     */
    private String deliveryCity;

    /**
     * <p>
     * The default constructor.
     * </p>
     */
    public CustomerWorkSite() {
        // Empty
    }

    /**
     * <p>
     * Retrieves the siteName field.
     * </p>
     *
     * @return the siteName
     */
    public String getSiteName() {
        return siteName;
    }

    /**
     * <p>
     * Sets the value to siteName field.
     * </p>
     *
     * @param siteName
     *            the siteName to set
     */
    public void setSiteName(String siteName) {
        this.siteName = siteName;
    }
    
    /**
     * <p>
     * Retrieves the deliveryCountry field.
     * </p>
     *
     * @return the deliveryCountry
     */
    public DeliveryCountry getDeliveryCountry() {
        return deliveryCountry;
    }

    /**
     * <p>
     * Sets the value to deliveryCountry field.
     * </p>
     *
     * @param deliveryCountry
     *            the delivery country to set
     */
    public void setDeliveryCountry(DeliveryCountry deliveryCountry) {
        this.deliveryCountry = deliveryCountry;
    }

    /**
     * <p>
     * Retrieves the deliveryRegion field.
     * </p>
     *
     * @return the deliveryRegion
     */
    public Region getDeliveryRegion() {
        return deliveryRegion;
    }

    /**
     * <p>
     * Sets the value to deliveryRegion field.
     * </p>
     *
     * @param deliveryRegion
     *            the delivery region to set
     */
    public void setDeliveryRegion(Region deliveryRegion) {
        this.deliveryRegion = deliveryRegion;
    }

    /**
     * <p>
     * Retrieves the deliveryCity field.
     * </p>
     *
     * @return the deliveryCity
     */
    public String getDeliveryCity() {
        return deliveryCity;
    }

    /**
     * <p>
     * Sets the value to deliveryCity field.
     * </p>
     *
     * @param deliveryCity
     *            the delivery city to set
     */
    public void setDeliveryCity(String deliveryCity) {
        this.deliveryCity = deliveryCity;
    }

    /**
     * The toString method.
     *
     * @return the string of this entity
     */
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("{").append(super.toString());
        sb.append(", deliveryCountry:").append(deliveryCountry);
        sb.append(", deliveryRegion:").append(deliveryRegion);
        sb.append(", deliveryCity:").append(deliveryCity).append("}");
        return sb.toString();
    }

}

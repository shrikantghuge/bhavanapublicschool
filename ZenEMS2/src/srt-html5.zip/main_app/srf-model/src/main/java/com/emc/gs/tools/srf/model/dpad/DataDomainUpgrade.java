/*
 * This code is copyright (c) 2014 EMC Corporation
 */
package com.emc.gs.tools.srf.model.dpad;

import com.emc.gs.tools.srf.model.IdentifiableEntity;

/**
 * <p>
 * This is DataDomainUpgrade entity class.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safety.
 * </p>
 * 
 * @author TCSASSEMBLER
 * @version 1.0
 * @since SRT Phase 3-5 - BRS Tabs Part 2 Assembly
 */
public class DataDomainUpgrade extends IdentifiableEntity {

    /**
     * Type of Upgrade.
     */
    private DataDomainUpgradeType upgradeType;

    /**
     * # of Data Domain Appliances to Perform DD OS Upgrade.
     */
    private Integer appliancesNum;

    /**
     * Represents whether upgrade from DD690,860,880 to DD890.
     */
    private boolean dd890;

    /**
     * DD890 appliances number.
     */
    private Integer dd890AppliancesNum;

    /**
     * Represents whether upgrade from DD690,860,880,890 to DD990.
     */
    private boolean dd990;

    /**
     * DD990 appliances number.
     */
    private Integer dd990AppliancesNum;

    /**
     * Represents whether upgrade from DD690,860,880,890 to DD4200.
     */
    private boolean dd4200;

    /**
     * DD4200 appliances number.
     */
    private Integer dd4200AppliancesNum;

    /**
     * Represents whether upgrade from DD690,860,880,890 to DD4500.
     */
    private boolean dd4500;

    /**
     * DD4500 appliances number.
     */
    private Integer dd4500AppliancesNum;

    /**
     * Represents whether upgrade from DD690,860,880,890 to DD7200.
     */
    private boolean dd7200;

    /**
     * DD7200 appliances number.
     */
    private Integer dd7200AppliancesNum;

    /**
     * # of Data Domain Storage Expansion Shelves.
     */
    private Integer storageExpansionShelvesNum;

    /**
     * # of Data Domain System Controller Upgrades.
     */
    private Integer systemControllerUpgradesNum;

    /**
     * <p>
     * The default constructor.
     * </p>
     */
    public DataDomainUpgrade() {
    }

    /**
     * Getter method for property <tt>upgradeType</tt>.
     * 
     * @return property value of upgradeType
     */
    public DataDomainUpgradeType getUpgradeType() {
        return upgradeType;
    }

    /**
     * Setter method for property <tt>upgradeType</tt>.
     * 
     * @param upgradeType
     *            value to be assigned to property upgradeType
     */
    public void setUpgradeType(DataDomainUpgradeType upgradeType) {
        this.upgradeType = upgradeType;
    }

    /**
     * Getter method for property <tt>appliancesNum</tt>.
     * 
     * @return property value of appliancesNum
     */
    public Integer getAppliancesNum() {
        return appliancesNum;
    }

    /**
     * Setter method for property <tt>appliancesNum</tt>.
     * 
     * @param appliancesNum
     *            value to be assigned to property appliancesNum
     */
    public void setAppliancesNum(Integer appliancesNum) {
        this.appliancesNum = appliancesNum;
    }

    /**
     * Getter method for property <tt>dd890</tt>.
     * 
     * @return property value of dd890
     */
    public boolean isDd890() {
        return dd890;
    }

    /**
     * Setter method for property <tt>dd890</tt>.
     * 
     * @param dd890
     *            value to be assigned to property dd890
     */
    public void setDd890(boolean dd890) {
        this.dd890 = dd890;
    }

    /**
     * Getter method for property <tt>dd890AppliancesNum</tt>.
     * 
     * @return property value of dd890AppliancesNum
     */
    public Integer getDd890AppliancesNum() {
        return dd890AppliancesNum;
    }

    /**
     * Setter method for property <tt>dd890AppliancesNum</tt>.
     * 
     * @param dd890AppliancesNum
     *            value to be assigned to property dd890AppliancesNum
     */
    public void setDd890AppliancesNum(Integer dd890AppliancesNum) {
        this.dd890AppliancesNum = dd890AppliancesNum;
    }

    /**
     * Getter method for property <tt>dd990</tt>.
     * 
     * @return property value of dd990
     */
    public boolean isDd990() {
        return dd990;
    }

    /**
     * Setter method for property <tt>dd990</tt>.
     * 
     * @param dd990
     *            value to be assigned to property dd990
     */
    public void setDd990(boolean dd990) {
        this.dd990 = dd990;
    }

    /**
     * Getter method for property <tt>dd990AppliancesNum</tt>.
     * 
     * @return property value of dd990AppliancesNum
     */
    public Integer getDd990AppliancesNum() {
        return dd990AppliancesNum;
    }

    /**
     * Setter method for property <tt>dd990AppliancesNum</tt>.
     * 
     * @param dd990AppliancesNum
     *            value to be assigned to property dd990AppliancesNum
     */
    public void setDd990AppliancesNum(Integer dd990AppliancesNum) {
        this.dd990AppliancesNum = dd990AppliancesNum;
    }

    /**
     * Getter method for property <tt>dd4200</tt>.
     * 
     * @return property value of dd4200
     */
    public boolean isDd4200() {
        return dd4200;
    }

    /**
     * Setter method for property <tt>dd4200</tt>.
     * 
     * @param dd4200
     *            value to be assigned to property dd4200
     */
    public void setDd4200(boolean dd4200) {
        this.dd4200 = dd4200;
    }

    /**
     * Getter method for property <tt>dd4200AppliancesNum</tt>.
     * 
     * @return property value of dd4200AppliancesNum
     */
    public Integer getDd4200AppliancesNum() {
        return dd4200AppliancesNum;
    }

    /**
     * Setter method for property <tt>dd4200AppliancesNum</tt>.
     * 
     * @param dd4200AppliancesNum
     *            value to be assigned to property dd4200AppliancesNum
     */
    public void setDd4200AppliancesNum(Integer dd4200AppliancesNum) {
        this.dd4200AppliancesNum = dd4200AppliancesNum;
    }

    /**
     * Getter method for property <tt>dd4500</tt>.
     * 
     * @return property value of dd4500
     */
    public boolean isDd4500() {
        return dd4500;
    }

    /**
     * Setter method for property <tt>dd4500</tt>.
     * 
     * @param dd4500
     *            value to be assigned to property dd4500
     */
    public void setDd4500(boolean dd4500) {
        this.dd4500 = dd4500;
    }

    /**
     * Getter method for property <tt>dd4500AppliancesNum</tt>.
     * 
     * @return property value of dd4500AppliancesNum
     */
    public Integer getDd4500AppliancesNum() {
        return dd4500AppliancesNum;
    }

    /**
     * Setter method for property <tt>dd4500AppliancesNum</tt>.
     * 
     * @param dd4500AppliancesNum
     *            value to be assigned to property dd4500AppliancesNum
     */
    public void setDd4500AppliancesNum(Integer dd4500AppliancesNum) {
        this.dd4500AppliancesNum = dd4500AppliancesNum;
    }

    /**
     * Getter method for property <tt>dd7200</tt>.
     * 
     * @return property value of dd7200
     */
    public boolean isDd7200() {
        return dd7200;
    }

    /**
     * Setter method for property <tt>dd7200</tt>.
     * 
     * @param dd7200
     *            value to be assigned to property dd7200
     */
    public void setDd7200(boolean dd7200) {
        this.dd7200 = dd7200;
    }

    /**
     * Getter method for property <tt>dd7200AppliancesNum</tt>.
     * 
     * @return property value of dd7200AppliancesNum
     */
    public Integer getDd7200AppliancesNum() {
        return dd7200AppliancesNum;
    }

    /**
     * Setter method for property <tt>dd7200AppliancesNum</tt>.
     * 
     * @param dd7200AppliancesNum
     *            value to be assigned to property dd7200AppliancesNum
     */
    public void setDd7200AppliancesNum(Integer dd7200AppliancesNum) {
        this.dd7200AppliancesNum = dd7200AppliancesNum;
    }

    /**
     * Getter method for property <tt>storageExpansionShelvesNum</tt>.
     * 
     * @return property value of storageExpansionShelvesNum
     */
    public Integer getStorageExpansionShelvesNum() {
        return storageExpansionShelvesNum;
    }

    /**
     * Setter method for property <tt>storageExpansionShelvesNum</tt>.
     * 
     * @param storageExpansionShelvesNum
     *            value to be assigned to property storageExpansionShelvesNum
     */
    public void setStorageExpansionShelvesNum(Integer storageExpansionShelvesNum) {
        this.storageExpansionShelvesNum = storageExpansionShelvesNum;
    }

    /**
     * Getter method for property <tt>systemControllerUpgradesNum</tt>.
     * 
     * @return property value of systemControllerUpgradesNum
     */
    public Integer getSystemControllerUpgradesNum() {
        return systemControllerUpgradesNum;
    }

    /**
     * Setter method for property <tt>systemControllerUpgradesNum</tt>.
     * 
     * @param systemControllerUpgradesNum
     *            value to be assigned to property systemControllerUpgradesNum
     */
    public void setSystemControllerUpgradesNum(Integer systemControllerUpgradesNum) {
        this.systemControllerUpgradesNum = systemControllerUpgradesNum;
    }

}

/*
 * This code is copyright (c) 2014 EMC Corporation.
 */
package com.emc.gs.tools.srf.model;

/**
 * <p>
 * This is the AppIdentifier entity class.
 * </p>
 *
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safe.
 * </p>
 * 
 * @author TCSASSEMBLER
 * @version 1.0
 * @since SRT Phase 4 - ET Assembly 2
 */
public class AppIdentifier {

    /**
     * The application identifier.
     */
    private String identifier;

    /**
     * Empty constructor.
     */
    public AppIdentifier() {
    }

    /**
     * Getter method for property <tt>identifier</tt>.
     * 
     * @return property value of identifier
     */
    public String getIdentifier() {
        return identifier;
    }

    /**
     * Setter method for property <tt>identifier</tt>.
     * 
     * @param identifier
     *            value to be assigned to property identifier
     */
    public void setIdentifier(String identifier) {
        this.identifier = identifier;
    }

}

/*
 * This code is copyright (c) 2014 EMC Corporation
 */
package com.emc.gs.tools.srf.model.healthcheck;

import com.emc.gs.tools.srf.model.IdentifiableEntity;

/**
 * <p>
 * This is HealthCheckSAP entity class.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safety.
 * </p>
 * <p>
 * 
 * @author TCSASSEMBLER
 * @version 1.0
 * @since SRT Phase 3-4 - ASD and Healthcheck Tabs Assembly
 */
public class HealthCheckSAP extends IdentifiableEntity {

    /**
     * # of Dish Library for Mainframe (DLm) subsystem to be evaluated?
     */
    private Integer dlmSubsystemNum;

    /**
     * Amount of storage, in whole TeraBytes (TB), on the DLm subsystem(s) to be evaluated?
     */
    private Integer storageAmount;

    /**
     * <p>
     * The default constructor.
     * </p>
     */
    public HealthCheckSAP() {
    }

    /**
     * Getter method for property <tt>dlmSubsystemNum</tt>.
     * 
     * @return property value of dlmSubsystemNum
     */
    public Integer getDlmSubsystemNum() {
        return dlmSubsystemNum;
    }

    /**
     * Setter method for property <tt>dlmSubsystemNum</tt>.
     * 
     * @param dlmSubsystemNum
     *            value to be assigned to property dlmSubsystemNum
     */
    public void setDlmSubsystemNum(Integer dlmSubsystemNum) {
        this.dlmSubsystemNum = dlmSubsystemNum;
    }

    /**
     * Getter method for property <tt>storageAmount</tt>.
     * 
     * @return property value of storageAmount
     */
    public Integer getStorageAmount() {
        return storageAmount;
    }

    /**
     * Setter method for property <tt>storageAmount</tt>.
     * 
     * @param storageAmount
     *            value to be assigned to property storageAmount
     */
    public void setStorageAmount(Integer storageAmount) {
        this.storageAmount = storageAmount;
    }

}

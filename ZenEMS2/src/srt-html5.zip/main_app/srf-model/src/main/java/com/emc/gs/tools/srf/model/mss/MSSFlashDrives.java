/*
 * This code is copyright (c) 2014 EMC Corporation
 */
package com.emc.gs.tools.srf.model.mss;

import com.emc.gs.tools.srf.model.IdentifiableEntity;

/**
 * <p>
 * This is Flash Drives of MSSArray entity class.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safe.
 * </p>
 * <p>
 * <strong>Changes V1.1:</strong> <strong>SRT Phase 3-1 - CTA Rainfinity and MSS Tabs Update Assembly</strong>
 * <ul>
 * <li>Add flash100GB field.</li>
 * </ul>
 * </p>
 * 
 * @author TCSASSEMBLER
 * @version 1.1
 * @since SRT Phase 3-1 - CTA Rainfinity and MSS Tabs Assembly
 */
public class MSSFlashDrives extends IdentifiableEntity {

    /**
     * Flash Drives 73GB.
     */
    private String flash73GB;

    /**
     * Flash Drives 100GB.
     */
    private String flash100GB;

    /**
     * Flash Drives 146GB.
     */
    private String flash146GB;

    /**
     * Flash Drives 200GB.
     */
    private String flash200GB;

    /**
     * Flash Drives 400GB.
     */
    private String flash400GB;

    /**
     * Other Flash Drives.
     */
    private String flashOther;

    /**
     * <p>
     * The default constructor.
     * </p>
     */
    public MSSFlashDrives() {
    }

    /**
     * Getter method for property <tt>flash73GB</tt>.
     * 
     * @return property value of flash73GB
     */
    public String getFlash73GB() {
        return flash73GB;
    }

    /**
     * Setter method for property <tt>flash73GB</tt>.
     * 
     * @param flash73GB
     *            value to be assigned to property flash73GB
     */
    public void setFlash73GB(String flash73gb) {
        flash73GB = flash73gb;
    }

    /**
     * Getter method for property <tt>flash100GB</tt>.
     * 
     * @return property value of flash100GB
     */
    public String getFlash100GB() {
        return flash100GB;
    }

    /**
     * Setter method for property <tt>flash100GB</tt>.
     * 
     * @param flash100GB
     *            value to be assigned to property flash100GB
     */
    public void setFlash100GB(String flash100gb) {
        flash100GB = flash100gb;
    }

    /**
     * Getter method for property <tt>flash146GB</tt>.
     * 
     * @return property value of flash146GB
     */
    public String getFlash146GB() {
        return flash146GB;
    }

    /**
     * Setter method for property <tt>flash146GB</tt>.
     * 
     * @param flash146GB
     *            value to be assigned to property flash146GB
     */
    public void setFlash146GB(String flash146gb) {
        flash146GB = flash146gb;
    }

    /**
     * Getter method for property <tt>flash200GB</tt>.
     * 
     * @return property value of flash200GB
     */
    public String getFlash200GB() {
        return flash200GB;
    }

    /**
     * Setter method for property <tt>flash200GB</tt>.
     * 
     * @param flash200GB
     *            value to be assigned to property flash200GB
     */
    public void setFlash200GB(String flash200gb) {
        flash200GB = flash200gb;
    }

    /**
     * Getter method for property <tt>flash400GB</tt>.
     * 
     * @return property value of flash400GB
     */
    public String getFlash400GB() {
        return flash400GB;
    }

    /**
     * Setter method for property <tt>flash400GB</tt>.
     * 
     * @param flash400GB
     *            value to be assigned to property flash400GB
     */
    public void setFlash400GB(String flash400gb) {
        flash400GB = flash400gb;
    }

    /**
     * Getter method for property <tt>flashOther</tt>.
     * 
     * @return property value of flashOther
     */
    public String getFlashOther() {
        return flashOther;
    }

    /**
     * Setter method for property <tt>flashOther</tt>.
     * 
     * @param flashOther
     *            value to be assigned to property flashOther
     */
    public void setFlashOther(String flashOther) {
        this.flashOther = flashOther;
    }

}

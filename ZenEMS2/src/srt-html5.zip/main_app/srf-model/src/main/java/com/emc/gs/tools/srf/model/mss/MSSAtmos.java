/*
 * This code is copyright (c) 2014 EMC Corporation
 */
package com.emc.gs.tools.srf.model.mss;

import com.emc.gs.tools.srf.model.IdentifiableEntity;

/**
 * <p>
 * This is ATMOS of MSSArray entity class.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safe.
 * </p>
 * 
 * @author TCSASSEMBLER
 * @version 1.0
 * @since SRT Phase 3-1 - CTA Rainfinity and MSS Tabs Update Assembly
 */
public class MSSAtmos extends IdentifiableEntity {

    /**
     * 2.5 IN 250GB(SATA) disk drives.
     */
    private String atmos25Inch250GB;

    /**
     * 1TB(SATA) disk drives.
     */
    private String atmos1TB;

    /**
     * 2TB(SATA) disk drives.
     */
    private String atmos2TB;

    /**
     * 3TB(SATA) disk drives.
     */
    private String atmos3TB;

    /**
     * ATMOS other drives.
     */
    private String atmosOther;

    /**
     * <p>
     * The default constructor.
     * </p>
     */
    public MSSAtmos() {
    }

    /**
     * Getter method for property <tt>atmos25Inch250GB</tt>.
     * 
     * @return property value of atmos25Inch250GB
     */
    public String getAtmos25Inch250GB() {
        return atmos25Inch250GB;
    }

    /**
     * Setter method for property <tt>atmos25Inch250GB</tt>.
     * 
     * @param atmos25Inch250GB
     *            value to be assigned to property atmos25Inch250GB
     */
    public void setAtmos25Inch250GB(String atmos25Inch250GB) {
        this.atmos25Inch250GB = atmos25Inch250GB;
    }

    /**
     * Getter method for property <tt>atmos1TB</tt>.
     * 
     * @return property value of atmos1TB
     */
    public String getAtmos1TB() {
        return atmos1TB;
    }

    /**
     * Setter method for property <tt>atmos1TB</tt>.
     * 
     * @param atmos1TB
     *            value to be assigned to property atmos1TB
     */
    public void setAtmos1TB(String atmos1tb) {
        atmos1TB = atmos1tb;
    }

    /**
     * Getter method for property <tt>atmos2TB</tt>.
     * 
     * @return property value of atmos2TB
     */
    public String getAtmos2TB() {
        return atmos2TB;
    }

    /**
     * Setter method for property <tt>atmos2TB</tt>.
     * 
     * @param atmos2TB
     *            value to be assigned to property atmos2TB
     */
    public void setAtmos2TB(String atmos2tb) {
        atmos2TB = atmos2tb;
    }

    /**
     * Getter method for property <tt>atmos3TB</tt>.
     * 
     * @return property value of atmos3TB
     */
    public String getAtmos3TB() {
        return atmos3TB;
    }

    /**
     * Setter method for property <tt>atmos3TB</tt>.
     * 
     * @param atmos3TB
     *            value to be assigned to property atmos3TB
     */
    public void setAtmos3TB(String atmos3tb) {
        atmos3TB = atmos3tb;
    }

    /**
     * Getter method for property <tt>atmosOther</tt>.
     * 
     * @return property value of atmosOther
     */
    public String getAtmosOther() {
        return atmosOther;
    }

    /**
     * Setter method for property <tt>atmosOther</tt>.
     * 
     * @param atmosOther
     *            value to be assigned to property atmosOther
     */
    public void setAtmosOther(String atmosOther) {
        this.atmosOther = atmosOther;
    }

}

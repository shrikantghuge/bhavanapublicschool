/*
 * This code is copyright (c) 2014 EMC Corporation.
 */
package com.emc.gs.tools.srf.model.engagement;

import com.emc.gs.tools.srf.model.IdentifiableEntity;
import com.fasterxml.jackson.annotation.JsonGetter;

/**
 * <p>
 * This is EngagementTypeData entity class.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safety.
 * </p>
 *
 * <p>
 * <strong>Changes V1.1:</strong>
 * <strong>SRT Phase 4 - ET Assembly 3</strong>
 * <ul>
 * <li>Added a dummy setter setSrtPath for the readonly property srtPath
 * so that Jackson won't throw an exception when deserialization.</li>
 * </ul>
 * </p>
 *
 * <p>
 * Version 1.2 Change notes:
 *   <ol>
 *     <li>Added {@link #countSelectedLOBs()} method.</li>
 *     <li>Updated {@link #calculateSRTPath()} method to evaluate SRT path against latest rules from client.</li>
 *   </ol>
 * </p>
 *
 * @author TCSASSEMBLER
 * @version 1.2
 * @since SRT Phase 4 - ET Assembly 1
 */
public class EngagementTypeData extends IdentifiableEntity {

    /**
     * Indicates whether the "Product Lead" type is selected.
     */
    private boolean productLead;

    /**
     * Indicates whether the "Service Lead" type is selected.
     */
    private boolean serviceLead;

    /**
     * Indicates whether the "EMC" LOB is selected.
     */
    private boolean emc;

    /**
     * Indicates whether the "ECD" LOB is selected.
     */
    private boolean ecd;

    /**
     * Indicates whether the "RSA" LOB is selected.
     */
    private boolean rsa;

    /**
     * Indicates whether the "MS" LOB is selected.
     */
    private boolean ms;

    /**
     * Delivery Country.
     */
    private DeliveryCountry deliveryCountry;

    /**
     * Empty constructor.
     */
    public EngagementTypeData() {
    }

    /**
     * Getter method for property <tt>productLead</tt>.
     *
     * @return property value of productLead
     */
    public boolean isProductLead() {
        return productLead;
    }

    /**
     * Setter method for property <tt>productLead</tt>.
     *
     * @param productLead
     *            value to be assigned to property productLead
     */
    public void setProductLead(boolean productLead) {
        this.productLead = productLead;
    }

    /**
     * Getter method for property <tt>serviceLead</tt>.
     *
     * @return property value of serviceLead
     */
    public boolean isServiceLead() {
        return serviceLead;
    }

    /**
     * Setter method for property <tt>serviceLead</tt>.
     *
     * @param serviceLead
     *            value to be assigned to property serviceLead
     */
    public void setServiceLead(boolean serviceLead) {
        this.serviceLead = serviceLead;
    }

    /**
     * Getter method for property <tt>emc</tt>.
     *
     * @return property value of emc
     */
    public boolean isEmc() {
        return emc;
    }

    /**
     * Setter method for property <tt>emc</tt>.
     *
     * @param emc
     *            value to be assigned to property emc
     */
    public void setEmc(boolean emc) {
        this.emc = emc;
    }

    /**
     * Getter method for property <tt>ecd</tt>.
     *
     * @return property value of ecd
     */
    public boolean isEcd() {
        return ecd;
    }

    /**
     * Setter method for property <tt>ecd</tt>.
     *
     * @param ecd
     *            value to be assigned to property ecd
     */
    public void setEcd(boolean ecd) {
        this.ecd = ecd;
    }

    /**
     * Getter method for property <tt>rsa</tt>.
     *
     * @return property value of rsa
     */
    public boolean isRsa() {
        return rsa;
    }

    /**
     * Setter method for property <tt>rsa</tt>.
     *
     * @param rsa
     *            value to be assigned to property rsa
     */
    public void setRsa(boolean rsa) {
        this.rsa = rsa;
    }

    /**
     * Getter method for property <tt>ms</tt>.
     *
     * @return property value of ms
     */
    public boolean isMs() {
        return ms;
    }

    /**
     * Setter method for property <tt>ms</tt>.
     *
     * @param ms
     *            value to be assigned to property ms
     */
    public void setMs(boolean ms) {
        this.ms = ms;
    }

    /**
     * Getter method for property <tt>deliveryCountry</tt>.
     *
     * @return property value of deliveryCountry
     */
    public DeliveryCountry getDeliveryCountry() {
        return deliveryCountry;
    }

    /**
     * Setter method for property <tt>deliveryCountry</tt>.
     *
     * @param deliveryCountry
     *            value to be assigned to property deliveryCountry
     */
    public void setDeliveryCountry(DeliveryCountry deliveryCountry) {
        this.deliveryCountry = deliveryCountry;
    }

    /**
     * <p>Counts the number of LOBs selected by user.</p>
     * 
     * @return an <code>int</code> providing the number of LOBs selected by user.
     * @since 1.2
     */
    public int countSelectedLOBs() {
        int counter = 0;
        if (isEmc()) {
            counter++;
        }
        if (isEcd()) {
            counter++;
        }
        if (isRsa()) {
            counter++;
        }
        if (isMs()) {
            counter++;
        }
        return counter;
    }

    /**
     * Calculates SRT path.
     * 
     * @return SRT path.
     */
    @JsonGetter("srtPath")
    public SRTPath calculateSRTPath() {
        SRTPath path = SRTPath.UNKNOWN;
        int lobCheckedLength = countSelectedLOBs();
        boolean isOnlyEMCChecked = emc && lobCheckedLength == 1;
        boolean isOnlyECDChecked = ecd && lobCheckedLength == 1;
        boolean isOnlyRSAChecked = rsa && lobCheckedLength == 1;
        boolean isOnlyMSChecked = ms && lobCheckedLength == 1;
        boolean isJustEMCECDCombination = emc && ecd && lobCheckedLength == 2;

        if (productLead && !serviceLead) {
            if (isOnlyEMCChecked) {
                path = SRTPath.SRT3;
            } else if (isJustEMCECDCombination) {
                path = SRTPath.SRT_HYBRID;
            }
        } else if (!productLead && serviceLead) {
            if (isJustEMCECDCombination || isOnlyEMCChecked || isOnlyECDChecked || isOnlyRSAChecked || isOnlyMSChecked) {
                path = SRTPath.SRT4;
            }
        } else if (productLead && serviceLead) {
            if (isOnlyEMCChecked || isJustEMCECDCombination) {
                path = SRTPath.SRT_HYBRID;
            }
        }
        return path;
    }

    /**
     * Represent a do-nothing private setter for "srtPath". The purpose is just to let Jackson ignore the field.
     * @param ignored the srtPath
     */
    private void setSrtPath(SRTPath ignored) {}
}

/*
 * This code is copyright (c) 2014 EMC Corporation.
 */
package com.emc.gs.tools.srf.model.dpad;

import com.emc.gs.tools.srf.model.IdentifiableEntity;

/**
 * <p>This is RecoverPoint entity class.</p>
 * 
 * <p><strong>Thread safety</strong>: This class is mutable, it is not thread safety.</p>
 *
 * <p>
 * Version 1.1 (SRT 4 OCT2014 Updates Part 2 Assembly) Change notes:
 *   <ol>
 *     <li>Totally re-designed the class per new requirements.</li>
 *   </ol>
 * </p>
 * 
 * @author isv
 * @version 1.1
 * @since SRT Phase 3-5 - BRS Tabs Part 1 Assembly
 */
public class RecoverPoint extends IdentifiableEntity {

    /**
     * <p>A <code>boolean</code> providing the value for "RecoverPoint Installation and Implementation" flag
     * property.</p>
     * 
     * @since 1.1
     */
    private boolean installAndImplement;

    /**
     * <p>A <code>boolean</code> providing the value for "Intelligent Fabric Splitter Migration" flag property.</p>
     * 
     * @since 1.1
     */
    private boolean migrateIntelligentFabricSplitter;

    /**
     * <p>A <code>boolean</code> providing the value for "RPA Hardware Upgrade" flag property.</p>
     * 
     * @since 1.1
     */
    private boolean upgradeRPAHardware;

    /**
     * <p>A <code>RecoverPointInstallationAndImplementation</code> providing the value for "RecoverPoint Installation
     * and Implementation" grouping property.</p>
     * 
     * @since 1.1
     */
    private RecoverPointInstallationAndImplementation installationAndImplementation;

    /**
     * <p>A <code>RPAHardwareUpgrade</code> providing the value for "RPA Hardware Upgrade" grouping property.</p>
     * 
     * @since 1.1
     */
    private RPAHardwareUpgrade rpaHardwareUpgrade;

    /**
     * <p>A <code>IntelligentFabricSplitterMigration</code> providing the value for "Intelligent Fabric Splitter
     * Migration" grouping property.</p>
     * 
     * @since 1.1
     */
    private IntelligentFabricSplitterMigration intelligentFabricSplitterMigration;

    /**
     * <p>Constructs new <code>RecoverPoint</code> instance. This implementation does nothing.</p>
     */
    public RecoverPoint() {
    }

    /**
     * <p>Gets the "RecoverPoint Installation and Implementation" grouping property.</p>
     *
     * @return a <code>RecoverPointInstallationAndImplementation</code> providing the value for "RecoverPoint
     * Installation and Implementation" grouping property.
     * @since 1.1
     */
    public RecoverPointInstallationAndImplementation getInstallationAndImplementation() {
        return this.installationAndImplementation;
    }

    /**
     * <p>Sets the "RecoverPoint Installation and Implementation" grouping property.</p>
     *
     * @param installationAndImplementation a <code>RecoverPointInstallationAndImplementation</code> providing the value
     * for "RecoverPoint Installation and Implementation" grouping property.
     * @since 1.1
     */
    public void setInstallationAndImplementation(
        RecoverPointInstallationAndImplementation installationAndImplementation) {
        this.installationAndImplementation = installationAndImplementation;
    }

    /**
     * <p>Gets the "Intelligent Fabric Splitter Migration" grouping property.</p>
     *
     * @return a <code>IntelligentFabricSplitterMigration</code> providing the value for "Intelligent Fabric Splitter
     * Migration" grouping property.
     * @since 1.1
     */
    public IntelligentFabricSplitterMigration getIntelligentFabricSplitterMigration() {
        return this.intelligentFabricSplitterMigration;
    }

    /**
     * <p>Sets the "Intelligent Fabric Splitter Migration" grouping property.</p>
     *
     * @param intelligentFabricSplitterMigration a <code>IntelligentFabricSplitterMigration</code> providing the value
     * for "Intelligent Fabric Splitter Migration" grouping property.
     * @since 1.1
     */
    public void setIntelligentFabricSplitterMigration(
        IntelligentFabricSplitterMigration intelligentFabricSplitterMigration) {
        this.intelligentFabricSplitterMigration = intelligentFabricSplitterMigration;
    }

    /**
     * <p>Gets the "RPA Hardware Upgrade" grouping property.</p>
     *
     * @return a <code>RPAHardwareUpgrade</code> providing the value for "RPA Hardware Upgrade" grouping property.
     * @since 1.1
     */
    public RPAHardwareUpgrade getRpaHardwareUpgrade() {
        return this.rpaHardwareUpgrade;
    }

    /**
     * <p>Sets the "RPA Hardware Upgrade" grouping property.</p>
     *
     * @param rpaHardwareUpgrade a <code>RPAHardwareUpgrade</code> providing the value for "RPA Hardware Upgrade"
     * grouping property.
     * @since 1.1
     */
    public void setRpaHardwareUpgrade(RPAHardwareUpgrade rpaHardwareUpgrade) {
        this.rpaHardwareUpgrade = rpaHardwareUpgrade;
    }

    /**
     * <p>Gets the "RPA Hardware Upgrade" flag property.</p>
     *
     * @return a <code>boolean</code> providing the value for "RPA Hardware Upgrade" flag property.
     * @since 1.1
     */
    public boolean getUpgradeRPAHardware() {
        return this.upgradeRPAHardware;
    }

    /**
     * <p>Sets the "RPA Hardware Upgrade" flag property.</p>
     *
     * @param upgradeRPAHardware a <code>boolean</code> providing the value for "RPA Hardware Upgrade" flag property.
     * @since 1.1
     */
    public void setUpgradeRPAHardware(boolean upgradeRPAHardware) {
        this.upgradeRPAHardware = upgradeRPAHardware;
    }

    /**
     * <p>Gets the "Intelligent Fabric Splitter Migration" flag property.</p>
     *
     * @return a <code>boolean</code> providing the value for "Intelligent Fabric Splitter Migration" flag property.
     * @since 1.1
     */
    public boolean getMigrateIntelligentFabricSplitter() {
        return this.migrateIntelligentFabricSplitter;
    }

    /**
     * <p>Sets the "Intelligent Fabric Splitter Migration" flag property.</p>
     *
     * @param migrateIntelligentFabricSplitter a <code>boolean</code> providing the value for "Intelligent Fabric
     * Splitter Migration" flag property.
     * @since 1.1
     */
    public void setMigrateIntelligentFabricSplitter(boolean migrateIntelligentFabricSplitter) {
        this.migrateIntelligentFabricSplitter = migrateIntelligentFabricSplitter;
    }

    /**
     * <p>Gets the "RecoverPoint Installation and Implementation" flag property.</p>
     *
     * @return a <code>boolean</code> providing the value for "RecoverPoint Installation and Implementation" flag
     * property.
     * @since 1.1
     */
    public boolean getInstallAndImplement() {
        return this.installAndImplement;
    }

    /**
     * <p>Sets the "RecoverPoint Installation and Implementation" flag property.</p>
     *
     * @param installAndImplement a <code>boolean</code> providing the value for "RecoverPoint Installation and
     * Implementation" flag property.
     * @since 1.1
     */
    public void setInstallAndImplement(boolean installAndImplement) {
        this.installAndImplement = installAndImplement;
    }
}

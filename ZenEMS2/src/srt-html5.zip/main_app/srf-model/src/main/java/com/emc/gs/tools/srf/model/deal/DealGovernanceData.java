/*
 * This code is copyright (c) 2014 EMC Corporation.
 */
package com.emc.gs.tools.srf.model.deal;

import java.util.Date;
import java.util.Map;

import com.emc.gs.tools.srf.model.IdentifiableEntity;

/**
 * <p>
 * This is DealGovernanceData entity class.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safety.
 * </p>
 * 
 * @author TCSASSEMBLER
 * @version 1.0
 * @since SRT Phase 4 - ET Assembly 1
 */
public class DealGovernanceData extends IdentifiableEntity {

    /**
     * Opportunity Name (client then project name).
     */
    private String opportunityName;

    /**
     * Who is Primary Delivery Org?
     */
    private String primaryDeliveryOrg;

    /**
     * What other practices are involved, if any?
     */
    private String otherPractices;

    /**
     * Estimated Start Date.
     */
    private Date estimatedStartDate;

    /**
     * Provide a brief description of scope/deliverables.
     */
    private String briefDescription;

    /**
     * Contract Structure (select from pull down).
     */
    private ContractStructure contractStructure;

    /**
     * Approver Notes.
     */
    private String approverNotes;

    /**
     * The map from question id to answers.
     */
    private Map<Long, DealAnswer> dealAnswers;

    /**
     * Empty constructor.
     */
    public DealGovernanceData() {
    }

    /**
     * Getter method for property <tt>opportunityName</tt>.
     * 
     * @return property value of opportunityName
     */
    public String getOpportunityName() {
        return opportunityName;
    }

    /**
     * Setter method for property <tt>opportunityName</tt>.
     * 
     * @param opportunityName
     *            value to be assigned to property opportunityName
     */
    public void setOpportunityName(String opportunityName) {
        this.opportunityName = opportunityName;
    }

    /**
     * Getter method for property <tt>primaryDeliveryOrg</tt>.
     * 
     * @return property value of primaryDeliveryOrg
     */
    public String getPrimaryDeliveryOrg() {
        return primaryDeliveryOrg;
    }

    /**
     * Setter method for property <tt>primaryDeliveryOrg</tt>.
     * 
     * @param primaryDeliveryOrg
     *            value to be assigned to property primaryDeliveryOrg
     */
    public void setPrimaryDeliveryOrg(String primaryDeliveryOrg) {
        this.primaryDeliveryOrg = primaryDeliveryOrg;
    }

    /**
     * Getter method for property <tt>otherPractices</tt>.
     * 
     * @return property value of otherPractices
     */
    public String getOtherPractices() {
        return otherPractices;
    }

    /**
     * Setter method for property <tt>otherPractices</tt>.
     * 
     * @param otherPractices
     *            value to be assigned to property otherPractices
     */
    public void setOtherPractices(String otherPractices) {
        this.otherPractices = otherPractices;
    }

    /**
     * Getter method for property <tt>estimatedStartDate</tt>.
     * 
     * @return property value of estimatedStartDate
     */
    public Date getEstimatedStartDate() {
        return estimatedStartDate;
    }

    /**
     * Setter method for property <tt>estimatedStartDate</tt>.
     * 
     * @param estimatedStartDate
     *            value to be assigned to property estimatedStartDate
     */
    public void setEstimatedStartDate(Date estimatedStartDate) {
        this.estimatedStartDate = estimatedStartDate;
    }

    /**
     * Getter method for property <tt>briefDescription</tt>.
     * 
     * @return property value of briefDescription
     */
    public String getBriefDescription() {
        return briefDescription;
    }

    /**
     * Setter method for property <tt>briefDescription</tt>.
     * 
     * @param briefDescription
     *            value to be assigned to property briefDescription
     */
    public void setBriefDescription(String briefDescription) {
        this.briefDescription = briefDescription;
    }

    /**
     * Getter method for property <tt>contractStructure</tt>.
     * 
     * @return property value of contractStructure
     */
    public ContractStructure getContractStructure() {
        return contractStructure;
    }

    /**
     * Setter method for property <tt>contractStructure</tt>.
     * 
     * @param contractStructure
     *            value to be assigned to property contractStructure
     */
    public void setContractStructure(ContractStructure contractStructure) {
        this.contractStructure = contractStructure;
    }

    /**
     * Getter method for property <tt>approverNotes</tt>.
     * 
     * @return property value of approverNotes
     */
    public String getApproverNotes() {
        return approverNotes;
    }

    /**
     * Setter method for property <tt>approverNotes</tt>.
     * 
     * @param approverNotes
     *            value to be assigned to property approverNotes
     */
    public void setApproverNotes(String approverNotes) {
        this.approverNotes = approverNotes;
    }

    /**
     * Getter method for property <tt>dealAnswers</tt>.
     * 
     * @return property value of dealAnswers
     */
    public Map<Long, DealAnswer> getDealAnswers() {
        return dealAnswers;
    }

    /**
     * Setter method for property <tt>dealAnswers</tt>.
     * 
     * @param dealAnswers
     *            value to be assigned to property dealAnswers
     */
    public void setDealAnswers(Map<Long, DealAnswer> dealAnswers) {
        this.dealAnswers = dealAnswers;
    }

}

/*
 * This code is copyright (c) 2013 - 2014 EMC Corporation.
 */
package com.emc.gs.tools.srf.model;


/**
 * <p>
 * This is BaseSearchParams entity class.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safety.
 * </p>
 *
 * @author faeton, stevenfrog
 * @version 1.0
 */
public abstract class BaseSearchParams {
    /**
     * <p>
     * The pageSize.
     * </p>
     */
    private int pageSize;

    /**
     * <p>
     * The pageNumber.
     * </p>
     */
    private int pageNumber;

    /**
     * <p>
     * The sortBy.
     * </p>
     */
    private String sortBy;

    /**
     * <p>
     * The sortOrder.
     * </p>
     */
    private SortOrder sortOrder;

    /**
     * <p>
     * The default constructor.
     * </p>
     */
    protected BaseSearchParams() {
        // Empty
    }

    /**
     * <p>
     * Retrieves the pageSize field.
     * </p>
     *
     * @return the pageSize
     */
    public int getPageSize() {
        return pageSize;
    }

    /**
     * <p>
     * Sets the value to pageSize field.
     * </p>
     *
     * @param pageSize
     *            the pageSize to set
     */
    public void setPageSize(int pageSize) {
        this.pageSize = pageSize;
    }

    /**
     * <p>
     * Retrieves the pageNumber field.
     * </p>
     *
     * @return the pageNumber
     */
    public int getPageNumber() {
        return pageNumber;
    }

    /**
     * <p>
     * Sets the value to pageNumber field.
     * </p>
     *
     * @param pageNumber
     *            the pageNumber to set
     */
    public void setPageNumber(int pageNumber) {
        this.pageNumber = pageNumber;
    }

    /**
     * <p>
     * Retrieves the sortBy field.
     * </p>
     *
     * @return the sortBy
     */
    public String getSortBy() {
        return sortBy;
    }

    /**
     * <p>
     * Sets the value to sortBy field.
     * </p>
     *
     * @param sortBy
     *            the sortBy to set
     */
    public void setSortBy(String sortBy) {
        this.sortBy = sortBy;
    }

    /**
     * <p>
     * Retrieves the sortOrder field.
     * </p>
     *
     * @return the sortOrder
     */
    public SortOrder getSortOrder() {
        return sortOrder;
    }

    /**
     * <p>
     * Sets the value to sortOrder field.
     * </p>
     *
     * @param sortOrder
     *            the sortOrder to set
     */
    public void setSortOrder(SortOrder sortOrder) {
        this.sortOrder = sortOrder;
    }

    /**
     * The toString method.
     *
     * @return the string for this entity
     */
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("pageSize:").append(pageSize);
        sb.append(", pageNumber:").append(pageNumber);
        sb.append(", sortBy:").append(sortBy);
        sb.append(", sortOrder:").append(sortOrder);
        return sb.toString();
    }
}

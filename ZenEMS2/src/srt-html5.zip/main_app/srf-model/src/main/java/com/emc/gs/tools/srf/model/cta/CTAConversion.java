/*
 * This code is copyright (c) 2014 EMC Corporation
 */
package com.emc.gs.tools.srf.model.cta;

import com.emc.gs.tools.srf.model.IdentifiableEntity;

/**
 * <p>
 * This is CTAConversion entity class.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safety.
 * </p>
 * 
 * @author TCSASSEMBLER
 * @version 1.0
 * @since SRT Phase 3-1 - CTA Rainfinity and MSS Tabs Update Assembly
 */
public class CTAConversion extends IdentifiableEntity {

    /**
     * Select Conversation Type.
     */
    private CTAConversationType conversationType;

    /**
     * # of Cloud Tiering Appliance or Cloud Tiering Appliance/VEs for conversion.
     */
    private Integer cloudTieringApplianceNum;

    /**
     * # of file servers for the conversion.
     */
    private Integer fileServersNum;

    /**
     * # of sites for Rainfinity File Management Appliance conversion.
     */
    private Integer managementSitesNum;

    /**
     * # of Files on all the File Systems to be Converted (in millions).
     */
    private Integer filesConvertedNum;

    /**
     * # of Centera File Archivers in conversion environment.
     */
    private Integer fileArchiversNum;

    /**
     * # of CFA database records to be converted to Cloud Tiering Appliance (in millions).
     */
    private Integer cfaRecordsNum;

    /**
     * Select the Cloud Tiering Appliance Stub Conversion Monitoring Method.
     */
    private CTAMonitoringMethod monitoringMethod;

    /**
     * <p>
     * The default constructor.
     * </p>
     */
    public CTAConversion() {
    }

    /**
     * Getter method for property <tt>conversationType</tt>.
     * 
     * @return property value of conversationType
     */
    public CTAConversationType getConversationType() {
        return conversationType;
    }

    /**
     * Setter method for property <tt>conversationType</tt>.
     * 
     * @param conversationType
     *            value to be assigned to property conversationType
     */
    public void setConversationType(CTAConversationType conversationType) {
        this.conversationType = conversationType;
    }

    /**
     * Getter method for property <tt>cloudTieringApplianceNum</tt>.
     * 
     * @return property value of cloudTieringApplianceNum
     */
    public Integer getCloudTieringApplianceNum() {
        return cloudTieringApplianceNum;
    }

    /**
     * Setter method for property <tt>cloudTieringApplianceNum</tt>.
     * 
     * @param cloudTieringApplianceNum
     *            value to be assigned to property cloudTieringApplianceNum
     */
    public void setCloudTieringApplianceNum(Integer cloudTieringApplianceNum) {
        this.cloudTieringApplianceNum = cloudTieringApplianceNum;
    }

    /**
     * Getter method for property <tt>fileServersNum</tt>.
     * 
     * @return property value of fileServersNum
     */
    public Integer getFileServersNum() {
        return fileServersNum;
    }

    /**
     * Setter method for property <tt>fileServersNum</tt>.
     * 
     * @param fileServersNum
     *            value to be assigned to property fileServersNum
     */
    public void setFileServersNum(Integer fileServersNum) {
        this.fileServersNum = fileServersNum;
    }

    /**
     * Getter method for property <tt>managementSitesNum</tt>.
     * 
     * @return property value of managementSitesNum
     */
    public Integer getManagementSitesNum() {
        return managementSitesNum;
    }

    /**
     * Setter method for property <tt>managementSitesNum</tt>.
     * 
     * @param managementSitesNum
     *            value to be assigned to property managementSitesNum
     */
    public void setManagementSitesNum(Integer managementSitesNum) {
        this.managementSitesNum = managementSitesNum;
    }

    /**
     * Getter method for property <tt>filesConvertedNum</tt>.
     * 
     * @return property value of filesConvertedNum
     */
    public Integer getFilesConvertedNum() {
        return filesConvertedNum;
    }

    /**
     * Setter method for property <tt>filesConvertedNum</tt>.
     * 
     * @param filesConvertedNum
     *            value to be assigned to property filesConvertedNum
     */
    public void setFilesConvertedNum(Integer filesConvertedNum) {
        this.filesConvertedNum = filesConvertedNum;
    }

    /**
     * Getter method for property <tt>fileArchiversNum</tt>.
     * 
     * @return property value of fileArchiversNum
     */
    public Integer getFileArchiversNum() {
        return fileArchiversNum;
    }

    /**
     * Setter method for property <tt>fileArchiversNum</tt>.
     * 
     * @param fileArchiversNum
     *            value to be assigned to property fileArchiversNum
     */
    public void setFileArchiversNum(Integer fileArchiversNum) {
        this.fileArchiversNum = fileArchiversNum;
    }

    /**
     * Getter method for property <tt>cfaRecordsNum</tt>.
     * 
     * @return property value of cfaRecordsNum
     */
    public Integer getCfaRecordsNum() {
        return cfaRecordsNum;
    }

    /**
     * Setter method for property <tt>cfaRecordsNum</tt>.
     * 
     * @param cfaRecordsNum
     *            value to be assigned to property cfaRecordsNum
     */
    public void setCfaRecordsNum(Integer cfaRecordsNum) {
        this.cfaRecordsNum = cfaRecordsNum;
    }

    /**
     * Getter method for property <tt>monitoringMethod</tt>.
     * 
     * @return property value of monitoringMethod
     */
    public CTAMonitoringMethod getMonitoringMethod() {
        return monitoringMethod;
    }

    /**
     * Setter method for property <tt>monitoringMethod</tt>.
     * 
     * @param monitoringMethod
     *            value to be assigned to property monitoringMethod
     */
    public void setMonitoringMethod(CTAMonitoringMethod monitoringMethod) {
        this.monitoringMethod = monitoringMethod;
    }

}

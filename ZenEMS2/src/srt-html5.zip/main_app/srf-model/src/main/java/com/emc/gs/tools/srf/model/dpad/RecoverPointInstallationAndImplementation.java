/*
 * This code is copyright (c) 2014 EMC Corporation
 */
package com.emc.gs.tools.srf.model.dpad;

import com.emc.gs.tools.srf.model.IdentifiableEntity;

/**
 * <p>This is RecoverPointInstallationAndImplementation entity class.</p>
 *
 * <p><strong>Thread safety</strong>: This class is mutable, it is not thread safety.</p>
 *
 * @author isv
 * @version 1.0 (SRT 4 OCT2014 Updates Part 2)
 */
public class RecoverPointInstallationAndImplementation extends IdentifiableEntity {

    /**
     * <p>A <code>boolean</code> providing the value for "Delivery Option - Design" flag property.</p>
     */
    private boolean deliveryOptionDesign;

    /**
     * <p>A <code>boolean</code> providing the value for "Delivery Option - Implementation" flag property.</p>
     */
    private boolean deliveryOptionImplementation;

    /**
     * <p>A <code>RecoverPointOption</code> providing the value for "RecoverPoint Option" property.</p>
     */
    private RecoverPointOption recoverPointOption;

    /**
     * <p>A <code>boolean</code> providing the value for "RecoverPoint Replication Method - Local" flag property.</p>
     */
    private boolean localReplicationMethod;

    /**
     * <p>A <code>boolean</code> providing the value for "RecoverPoint Replication Method - Remote" flag property.</p>
     */
    private boolean remoteReplicationMethod;

    /**
     * <p>A <code>Boolean</code> providing the value for "Include Cluster Enabler?" property.</p>
     */
    private Boolean includeClusterEnabler;

    /**
     * <p>A <code>RecoverPointSplitterType</code> providing the value for "RecoverPoint Splitter Type" property.</p>
     */
    private RecoverPointSplitterType recoverPointSplitterType;

    /**
     * <p>A <code>boolean</code> providing the value for "VNX or CLARiiON" storage array option property.</p>
     */
    private boolean vnxOrClariionInvolved;

    /**
     * <p>A <code>boolean</code> providing the value for "VMAX DMX or SYMM" storage array option property.</p>
     */
    private boolean vmaxDMXorSYMMInvolved;

    /**
     * <p>A <code>boolean</code> providing the value for "3rd PArty or Non-EMC Storage" storage array option
     * property.</p>
     */
    private boolean nonEMCor3rdPartyStorageInvolved;

    /**
     * <p>A <code>boolean</code> providing the value for "No Source Array" storage array option property.</p>
     */
    private boolean noSourceArrayInvolved;

    /**
     * <p>A <code>boolean</code> providing the value for "XtremIO Cluster" storage array option property.</p>
     */
    private boolean xtremIOClusterInvolved;

    /**
     * <p>A <code>Integer</code> providing the value for "# of Existing Physical Hosts?" property.</p>
     */
    private Integer numberOfExistingPhysicalHosts;

    /**
     * <p>A <code>Integer</code> providing the value for "# of Existing ESX Servers (Not Virtual Machines)?"
     * property.</p>
     */
    private Integer numberOfExistingESXServers;

    /**
     * <p>A <code>Integer</code> providing the value for "# of client / servers / ESX servers in RP Environment?"
     * property.</p>
     */
    private Integer numberOfRPEnvironmentClientsServers;

    /**
     * <p>A <code>Integer</code> providing the value for "# of RecoverPoint Appliances (Count each RPA Separately)?"
     * property.</p>
     */
    private Integer numberOfRPAppliances;

    /**
     * <p>A <code>Integer</code> providing the value for "# of Storage Systems Requiring Splitter?" property.</p>
     */
    private Integer numberOfStorageSystemsRequiringSplitter;

    /**
     * <p>A <code>Boolean</code> providing the value for "Include Bandwidth Analysis as Part of Planning and Design?"
     * property.</p>
     */
    private Boolean includeBandwidthAnalysis;

    /**
     * <p>A <code>Boolean</code> providing the value for "Dispatch EMC Team to Customer's Remote Site to Install RPA?"
     * property.</p>
     */
    private Boolean dispatchEMCTeam;

    /**
     * <p>A <code>Boolean</code> providing the value for "Include 3rd Party Storage Array Planning and Design?"
     * property.</p>
     */
    private Boolean include3rdPartyStorageArrayPlanningAndDesign;

    /**
     * <p>A <code>Boolean</code> providing the value for "Include 3rd Party Storage Array Integration?" property .</p>
     */
    private Boolean include3rdPartyStorageArrayIntegration;

    /**
     * <p>A <code>Integer</code> providing the value for "# of Non-EMC Storage Arrays?" property.</p>
     */
    private Integer numberOfNonEMCStorageArrays;

    /**
     * <p>A <code>Boolean</code> providing the value for "Include RecoverPoint Integration within existing Replication
     * Manager Environment?" property.</p>
     */
    private Boolean includeReplicationManagerEnvironmentIntegration;

    /**
     * <p>A <code>Boolean</code> providing the value for "Include RecoverPoint Integration with an existing VMWare
     * vCenter Site?" property.</p>
     */
    private Boolean includeVMWarevCenterSiteIntegration;

    /**
     * <p>A <code>Integer</code> providing the value for "# of Microsoft Clusters /Failover Cluster to be managed by
     * CE?" property.</p>
     */
    private Integer numberOfMicrosoftFailoverClusters;

    /**
     * <p>A <code>Integer</code> providing the value for "# of RecoverPoint/CE Cluster Nodes?" property.</p>
     */
    private Integer numberOfRPCEClusterNodes;

    /**
     * <p>A <code>Integer</code> providing the value for "# of RecoverPoint Consistency Groups to be Converted to CE
     * Cluster Groups?" property.</p>
     */
    private Integer numberOfRPConsistencyGroups;

    /**
     * <p>Gets the "# of RecoverPoint Consistency Groups to be Converted to CE Cluster Groups?" property.</p>
     *
     * @return a <code>Integer</code> providing the value for "# of RecoverPoint Consistency Groups to be Converted to
     * CE Cluster Groups?" property.
     */
    public Integer getNumberOfRPConsistencyGroups() {
        return this.numberOfRPConsistencyGroups;
    }

    /**
     * <p>Sets the "# of RecoverPoint Consistency Groups to be Converted to CE Cluster Groups?" property.</p>
     *
     * @param numberOfRPConsistencyGroups a <code>Integer</code> providing the value for "# of RecoverPoint Consistency
     * Groups to be Converted to CE Cluster Groups?" property.
     */
    public void setNumberOfRPConsistencyGroups(Integer numberOfRPConsistencyGroups) {
        this.numberOfRPConsistencyGroups = numberOfRPConsistencyGroups;
    }


    /**
     * <p>Gets the "# of RecoverPoint/CE Cluster Nodes?" property.</p>
     *
     * @return a <code>Integer</code> providing the value for "# of RecoverPoint/CE Cluster Nodes?" property.
     */
    public Integer getNumberOfRPCEClusterNodes() {
        return this.numberOfRPCEClusterNodes;
    }

    /**
     * <p>Sets the "# of RecoverPoint/CE Cluster Nodes?" property.</p>
     *
     * @param numberOfRPCEClusterNodes a <code>Integer</code> providing the value for "# of RecoverPoint/CE Cluster
     * Nodes?" property.
     */
    public void setNumberOfRPCEClusterNodes(Integer numberOfRPCEClusterNodes) {
        this.numberOfRPCEClusterNodes = numberOfRPCEClusterNodes;
    }

    /**
     * <p>Gets the "# of Microsoft Clusters /Failover Cluster to be managed by CE?" property.</p>
     *
     * @return a <code>Integer</code> providing the value for "# of Microsoft Clusters /Failover Cluster to be managed
     * by CE?" property.
     */
    public Integer getNumberOfMicrosoftFailoverClusters() {
        return this.numberOfMicrosoftFailoverClusters;
    }

    /**
     * <p>Sets the "# of Microsoft Clusters /Failover Cluster to be managed by CE?" property.</p>
     *
     * @param numberOfMicrosoftFailoverClusters a <code>Integer</code> providing the value for "# of Microsoft Clusters
     * /Failover Cluster to be managed by CE?" property.
     */
    public void setNumberOfMicrosoftFailoverClusters(Integer numberOfMicrosoftFailoverClusters) {
        this.numberOfMicrosoftFailoverClusters = numberOfMicrosoftFailoverClusters;
    }

    /**
     * <p>Gets the "Include RecoverPoint Integration with an existing VMWare vCenter Site?" property.</p>
     *
     * @return a <code>Boolean</code> providing the value for "Include RecoverPoint Integration with an existing VMWare
     * vCenter Site?" property.
     */
    public Boolean getIncludeVMWarevCenterSiteIntegration() {
        return this.includeVMWarevCenterSiteIntegration;
    }

    /**
     * <p>Sets the "Include RecoverPoint Integration with an existing VMWare vCenter Site?" property.</p>
     *
     * @param includeVMWarevCenterSiteIntegration a <code>Boolean</code> providing the value for "Include RecoverPoint
     * Integration with an existing VMWare vCenter Site?" property.
     */
    public void setIncludeVMWarevCenterSiteIntegration(Boolean includeVMWarevCenterSiteIntegration) {
        this.includeVMWarevCenterSiteIntegration = includeVMWarevCenterSiteIntegration;
    }

    /**
     * <p>Gets the "Include RecoverPoint Integration within existing Replication Manager Environment?" property.</p>
     *
     * @return a <code>Boolean</code> providing the value for "Include RecoverPoint Integration within existing
     * Replication Manager Environment?" property.
     */
    public Boolean getIncludeReplicationManagerEnvironmentIntegration() {
        return this.includeReplicationManagerEnvironmentIntegration;
    }

    /**
     * <p>Sets the "Include RecoverPoint Integration within existing Replication Manager Environment?" property.</p>
     *
     * @param includeReplicationManagerEnvironmentIntegration a <code>Boolean</code> providing the value for "Include
     * RecoverPoint Integration within existing Replication Manager Environment?" property.
     */
    public void setIncludeReplicationManagerEnvironmentIntegration(
        Boolean includeReplicationManagerEnvironmentIntegration) {
        this.includeReplicationManagerEnvironmentIntegration = includeReplicationManagerEnvironmentIntegration;
    }

    /**
     * <p>Gets the "# of Non-EMC Storage Arrays?" property.</p>
     *
     * @return a <code>Integer</code> providing the value for "# of Non-EMC Storage Arrays?" property.
     */
    public Integer getNumberOfNonEMCStorageArrays() {
        return this.numberOfNonEMCStorageArrays;
    }

    /**
     * <p>Sets the "# of Non-EMC Storage Arrays?" property.</p>
     *
     * @param numberOfNonEMCStorageArrays a <code>Integer</code> providing the value for "# of Non-EMC Storage Arrays?"
     * property.
     */
    public void setNumberOfNonEMCStorageArrays(Integer numberOfNonEMCStorageArrays) {
        this.numberOfNonEMCStorageArrays = numberOfNonEMCStorageArrays;
    }

    /**
     * <p>Gets the "Include 3rd Party Storage Array Integration?" property.</p>
     *
     * @return a <code>Boolean</code> providing the value for "Include 3rd Party Storage Array Integration?" property.
     */
    public Boolean getInclude3rdPartyStorageArrayIntegration() {
        return this.include3rdPartyStorageArrayIntegration;
    }

    /**
     * <p>Sets the "Include 3rd Party Storage Array Integration?" property.</p>
     *
     * @param include3rdPartyStorageArrayIntegration a <code>Boolean</code> providing the value for "Include 3rd Party
     * Storage Array Integration?" property.
     */
    public void setInclude3rdPartyStorageArrayIntegration(Boolean include3rdPartyStorageArrayIntegration) {
        this.include3rdPartyStorageArrayIntegration = include3rdPartyStorageArrayIntegration;
    }

    /**
     * <p>Gets the "Include 3rd Party Storage Array Planning and Design?" property.</p>
     *
     * @return a <code>Boolean</code> providing the value for "Include 3rd Party Storage Array Planning and Design?"
     * property.
     */
    public Boolean getInclude3rdPartyStorageArrayPlanningAndDesign() {
        return this.include3rdPartyStorageArrayPlanningAndDesign;
    }

    /**
     * <p>Sets the "Include 3rd Party Storage Array Planning and Design?" property.</p>
     *
     * @param include3rdPartyStorageArrayPlanningAndDesign a <code>Boolean</code> providing the value for "Include 3rd
     * Party Storage Array Planning and Design?" property.
     */
    public void setInclude3rdPartyStorageArrayPlanningAndDesign(Boolean include3rdPartyStorageArrayPlanningAndDesign) {
        this.include3rdPartyStorageArrayPlanningAndDesign = include3rdPartyStorageArrayPlanningAndDesign;
    }

    /**
     * <p>Gets the "Dispatch EMC Team to Customer's Remote Site to Install RPA?"  property.</p>
     *
     * @return a <code>Boolean</code> providing the value for "Dispatch EMC Team to Customer's Remote Site to Install
     * RPA?"  property.
     */
    public Boolean getDispatchEMCTeam() {
        return this.dispatchEMCTeam;
    }

    /**
     * <p>Sets the "Dispatch EMC Team to Customer's Remote Site to Install RPA?"  property.</p>
     *
     * @param dispatchEMCTeam a <code>Boolean</code> providing the value for "Dispatch EMC Team to Customer's Remote
     * Site to Install RPA?"  property.
     */
    public void setDispatchEMCTeam(Boolean dispatchEMCTeam) {
        this.dispatchEMCTeam = dispatchEMCTeam;
    }

    /**
     * <p>Gets the "Include Bandwidth Analysis as Part of Planning and Design?" property.</p>
     *
     * @return a <code>Boolean</code> providing the value for "Include Bandwidth Analysis as Part of Planning and
     * Design?" property.
     */
    public Boolean getIncludeBandwidthAnalysis() {
        return this.includeBandwidthAnalysis;
    }

    /**
     * <p>Sets the "Include Bandwidth Analysis as Part of Planning and Design?" property.</p>
     *
     * @param includeBandwidthAnalysis a <code>Boolean</code> providing the value for "Include Bandwidth Analysis as
     * Part of Planning and Design?" property.
     */
    public void setIncludeBandwidthAnalysis(Boolean includeBandwidthAnalysis) {
        this.includeBandwidthAnalysis = includeBandwidthAnalysis;
    }

    /**
     * <p>Gets the "# of Storage Systems Requiring Splitter?" property.</p>
     *
     * @return a <code>Integer</code> providing the value for "# of Storage Systems Requiring Splitter?" property.
     */
    public Integer getNumberOfStorageSystemsRequiringSplitter() {
        return this.numberOfStorageSystemsRequiringSplitter;
    }

    /**
     * <p>Sets the "# of Storage Systems Requiring Splitter?" property.</p>
     *
     * @param numberOfStorageSystemsRequiringSplitter a <code>Integer</code> providing the value for "# of Storage
     * Systems Requiring Splitter?" property.
     */
    public void setNumberOfStorageSystemsRequiringSplitter(Integer numberOfStorageSystemsRequiringSplitter) {
        this.numberOfStorageSystemsRequiringSplitter = numberOfStorageSystemsRequiringSplitter;
    }


    /**
     * <p>Gets the "# of RecoverPoint Appliances (Count each RPA Separately)?" property.</p>
     *
     * @return a <code>Integer</code> providing the value for "# of RecoverPoint Appliances (Count each RPA
     * Separately)?" property.
     */
    public Integer getNumberOfRPAppliances() {
        return this.numberOfRPAppliances;
    }

    /**
     * <p>Sets the "# of RecoverPoint Appliances (Count each RPA Separately)?" property.</p>
     *
     * @param numberOfRPAppliances a <code>Integer</code> providing the value for "# of RecoverPoint Appliances (Count
     * each RPA Separately)?" property.
     */
    public void setNumberOfRPAppliances(Integer numberOfRPAppliances) {
        this.numberOfRPAppliances = numberOfRPAppliances;
    }

    /**
     * <p>Gets the "# of client / servers / ESX servers in RP Environment?" property.</p>
     *
     * @return a <code>Integer</code> providing the value for "# of client / servers / ESX servers in RP Environment?"
     * property.
     */
    public Integer getNumberOfRPEnvironmentClientsServers() {
        return this.numberOfRPEnvironmentClientsServers;
    }

    /**
     * <p>Sets the "# of client / servers / ESX servers in RP Environment?" property.</p>
     *
     * @param numberOfRPEnvironmentClientsServers a <code>Integer</code> providing the value for "# of client / servers
     * / ESX servers in RP Environment?" property.
     */
    public void setNumberOfRPEnvironmentClientsServers(Integer numberOfRPEnvironmentClientsServers) {
        this.numberOfRPEnvironmentClientsServers = numberOfRPEnvironmentClientsServers;
    }

    /**
     * <p>Gets the "# of Existing ESX Servers (Not Virtual Machines)?" property.</p>
     *
     * @return a <code>Integer</code> providing the value for "# of Existing ESX Servers (Not Virtual Machines)?"
     * property.
     */
    public Integer getNumberOfExistingESXServers() {
        return this.numberOfExistingESXServers;
    }

    /**
     * <p>Sets the "# of Existing ESX Servers (Not Virtual Machines)?" property.</p>
     *
     * @param numberOfExistingESXServers a <code>Integer</code> providing the value for "# of Existing ESX Servers (Not
     * Virtual Machines)?" property.
     */
    public void setNumberOfExistingESXServers(Integer numberOfExistingESXServers) {
        this.numberOfExistingESXServers = numberOfExistingESXServers;
    }

    /**
     * <p>Gets the "# of Existing Physical Hosts?" property.</p>
     *
     * @return a <code>Integer</code> providing the value for "# of Existing Physical Hosts?" property.
     */
    public Integer getNumberOfExistingPhysicalHosts() {
        return this.numberOfExistingPhysicalHosts;
    }

    /**
     * <p>Sets the "# of Existing Physical Hosts?" property.</p>
     *
     * @param numberOfExistingPhysicalHosts a <code>Integer</code> providing the value for "# of Existing Physical
     * Hosts?" property.
     */
    public void setNumberOfExistingPhysicalHosts(Integer numberOfExistingPhysicalHosts) {
        this.numberOfExistingPhysicalHosts = numberOfExistingPhysicalHosts;
    }

    /**
     * <p>Gets the "Include Cluster Enabler?" property.</p>
     *
     * @return a <code>Boolean</code> providing the value for "Include Cluster Enabler?" property.
     */
    public Boolean getIncludeClusterEnabler() {
        return this.includeClusterEnabler;
    }

    /**
     * <p>Sets the "Include Cluster Enabler?" property.</p>
     *
     * @param includeClusterEnabler a <code>Boolean</code> providing the value for "Include Cluster Enabler?" property.
     */
    public void setIncludeClusterEnabler(Boolean includeClusterEnabler) {
        this.includeClusterEnabler = includeClusterEnabler;
    }

    /**
     * <p>Gets the "RecoverPoint Replication Method - Remote" flag property.</p>
     *
     * @return a <code>boolean</code> providing the value for "RecoverPoint Replication Method - Remote" flag property.
     */
    public boolean getRemoteReplicationMethod() {
        return this.remoteReplicationMethod;
    }

    /**
     * <p>Sets the "RecoverPoint Replication Method - Remote" flag property.</p>
     *
     * @param remoteReplicationMethod a <code>boolean</code> providing the value for "RecoverPoint Replication Method -
     * Remote" flag property.
     */
    public void setRemoteReplicationMethod(boolean remoteReplicationMethod) {
        this.remoteReplicationMethod = remoteReplicationMethod;
    }

    /**
     * <p>Gets the "RecoverPoint Replication Method - Local" flag property.</p>
     *
     * @return a <code>boolean</code> providing the value for "RecoverPoint Replication Method - Local" flag property.
     */
    public boolean getLocalReplicationMethod() {
        return this.localReplicationMethod;
    }

    /**
     * <p>Sets the "RecoverPoint Replication Method - Local" flag property.</p>
     *
     * @param localReplicationMethod a <code>boolean</code> providing the value for "RecoverPoint Replication Method -
     * Local" flag property.
     */
    public void setLocalReplicationMethod(boolean localReplicationMethod) {
        this.localReplicationMethod = localReplicationMethod;
    }

    /**
     * <p>Gets the "Delivery Option - Implementation" flag property.</p>
     *
     * @return a <code>boolean</code> providing the value for "Delivery Option - Implementation" flag property.
     */
    public boolean getDeliveryOptionImplementation() {
        return this.deliveryOptionImplementation;
    }

    /**
     * <p>Sets the "Delivery Option - Implementation" flag property.</p>
     *
     * @param deliveryOptionImplementation a <code>boolean</code> providing the value for "Delivery Option -
     * Implementation" flag property.
     */
    public void setDeliveryOptionImplementation(boolean deliveryOptionImplementation) {
        this.deliveryOptionImplementation = deliveryOptionImplementation;
    }

    /**
     * <p>Gets the "Delivery Option - Design" flag property.</p>
     *
     * @return a <code>boolean</code> providing the value for "Delivery Option - Design" flag property.
     */
    public boolean getDeliveryOptionDesign() {
        return this.deliveryOptionDesign;
    }

    /**
     * <p>Sets the "Delivery Option - Design" flag property.</p>
     *
     * @param deliveryOptionDesign a <code>boolean</code> providing the value for "Delivery Option - Design" flag
     * property.
     */
    public void setDeliveryOptionDesign(boolean deliveryOptionDesign) {
        this.deliveryOptionDesign = deliveryOptionDesign;
    }

    /**
     * <p>Gets the "RecoverPoint Option" property.</p>
     *
     * @return a <code>RecoverPointOption</code> providing the value for "RecoverPoint Option" property.
     */
    public RecoverPointOption getRecoverPointOption() {
        return this.recoverPointOption;
    }

    /**
     * <p>Sets the "RecoverPoint Option" property.</p>
     *
     * @param recoverPointOption a <code>RecoverPointOption</code> providing the value for "RecoverPoint Option"
     * property.
     */
    public void setRecoverPointOption(RecoverPointOption recoverPointOption) {
        this.recoverPointOption = recoverPointOption;
    }

    /**
     * <p>Gets the "XtremIO Cluster" storage array option property.</p>
     *
     * @return a <code>boolean</code> providing the value for "XtremIO Cluster" storage array option property.
     */
    public boolean getXtremIOClusterInvolved() {
        return this.xtremIOClusterInvolved;
    }

    /**
     * <p>Sets the "XtremIO Cluster" storage array option property.</p>
     *
     * @param xtremIOClusterInvolved a <code>boolean</code> providing the value for "XtremIO Cluster" storage array
     * option property.
     */
    public void setXtremIOClusterInvolved(boolean xtremIOClusterInvolved) {
        this.xtremIOClusterInvolved = xtremIOClusterInvolved;
    }

    /**
     * <p>Gets the "No Source Array" storage array option property.</p>
     *
     * @return a <code>boolean</code> providing the value for "No Source Array" storage array option property.
     */
    public boolean getNoSourceArrayInvolved() {
        return this.noSourceArrayInvolved;
    }

    /**
     * <p>Sets the "No Source Array" storage array option property.</p>
     *
     * @param noSourceArrayInvolved a <code>boolean</code> providing the value for "No Source Array" storage array
     * option property.
     */
    public void setNoSourceArrayInvolved(boolean noSourceArrayInvolved) {
        this.noSourceArrayInvolved = noSourceArrayInvolved;
    }

    /**
     * <p>Gets the "3rd PArty or Non-EMC Storage" storage array option property.</p>
     *
     * @return a <code>boolean</code> providing the value for "3rd PArty or Non-EMC Storage" storage array option
     * property.
     */
    public boolean getNonEMCor3rdPartyStorageInvolved() {
        return this.nonEMCor3rdPartyStorageInvolved;
    }

    /**
     * <p>Sets the "3rd PArty or Non-EMC Storage" storage array option property.</p>
     *
     * @param nonEMCor3rdPartyStorageInvolved a <code>boolean</code> providing the value for "3rd PArty or Non-EMC
     * Storage" storage array option property.
     */
    public void setNonEMCor3rdPartyStorageInvolved(boolean nonEMCor3rdPartyStorageInvolved) {
        this.nonEMCor3rdPartyStorageInvolved = nonEMCor3rdPartyStorageInvolved;
    }

    /**
     * <p>Gets the "VMAX DMX or SYMM" storage array option property.</p>
     *
     * @return a <code>boolean</code> providing the value for "VMAX DMX or SYMM" storage array option property.
     */
    public boolean getVmaxDMXorSYMMInvolved() {
        return this.vmaxDMXorSYMMInvolved;
    }

    /**
     * <p>Sets the "VMAX DMX or SYMM" storage array option property.</p>
     *
     * @param vmaxDMXorSYMMInvolved a <code>boolean</code> providing the value for "VMAX DMX or SYMM" storage array
     * option property.
     */
    public void setVmaxDMXorSYMMInvolved(boolean vmaxDMXorSYMMInvolved) {
        this.vmaxDMXorSYMMInvolved = vmaxDMXorSYMMInvolved;
    }

    /**
     * <p>Gets the "VNX or CLARiiON" storage array option property.</p>
     *
     * @return a <code>boolean</code> providing the value for "VNX or CLARiiON" storage array option property.
     */
    public boolean getVnxOrClariionInvolved() {
        return this.vnxOrClariionInvolved;
    }

    /**
     * <p>Sets the "VNX or CLARiiON" storage array option property.</p>
     *
     * @param vnxOrClariionInvolved a <code>boolean</code> providing the value for "VNX or CLARiiON" storage array
     * option property.
     */
    public void setVnxOrClariionInvolved(boolean vnxOrClariionInvolved) {
        this.vnxOrClariionInvolved = vnxOrClariionInvolved;
    }

    /**
     * <p>Gets the "RecoverPoint Splitter Type" property.</p>
     *
     * @return a <code>RecoverPointSplitterType</code> providing the value for "RecoverPoint Splitter Type" property.
     */
    public RecoverPointSplitterType getRecoverPointSplitterType() {
        return this.recoverPointSplitterType;
    }

    /**
     * <p>Sets the "RecoverPoint Splitter Type" property.</p>
     *
     * @param recoverPointSplitterType a <code>RecoverPointSplitterType</code> providing the value for "RecoverPoint
     * Splitter Type" property.
     */
    public void setRecoverPointSplitterType(RecoverPointSplitterType recoverPointSplitterType) {
        this.recoverPointSplitterType = recoverPointSplitterType;
    }

}

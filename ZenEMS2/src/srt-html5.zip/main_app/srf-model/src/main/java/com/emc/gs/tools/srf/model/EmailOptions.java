/*
 * This code is copyright (c) 2013 - 2014 EMC Corporation.
 */
package com.emc.gs.tools.srf.model;

/**
 * <p>
 * This is EmailOptions entity class.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safety.
 * </p>
 *
 * <p>
 * <strong>Changes V1.1:</strong>
 * <strong>SRT Phase 2 Release Assembly</strong>
 * <ul>
 * <li>Remove host/port fields</li>
 * </ul>
 * </p>
 *
 * @author faeton, stevenfrog
 * @version 1.1
 */
public class EmailOptions extends IdentifiableEntity {

    /**
     * <p>
     * The username.
     * </p>
     */
    private String username;

    /**
     * <p>
     * The password.
     * </p>
     */
    private String password;

    /**
     * <p>
     * The default constructor.
     * </p>
     */
    public EmailOptions() {
        // Empty
    }

    /**
     * <p>
     * Retrieves the username field.
     * </p>
     *
     * @return the username
     */
    public String getUsername() {
        return username;
    }

    /**
     * <p>
     * Sets the value to username field.
     * </p>
     *
     * @param username
     *            the username to set
     */
    public void setUsername(String username) {
        this.username = username;
    }

    /**
     * <p>
     * Retrieves the password field.
     * </p>
     *
     * @return the password
     */
    public String getPassword() {
        return password;
    }

    /**
     * <p>
     * Sets the value to password field.
     * </p>
     *
     * @param password
     *            the password to set
     */
    public void setPassword(String password) {
        this.password = password;
    }

    /**
     * The toString method.
     *
     * @return the string of this entity
     */
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("{").append(super.toString());
        sb.append(", username:").append(username);
        sb.append(", password:").append("******").append("}");
        return sb.toString();
    }

}

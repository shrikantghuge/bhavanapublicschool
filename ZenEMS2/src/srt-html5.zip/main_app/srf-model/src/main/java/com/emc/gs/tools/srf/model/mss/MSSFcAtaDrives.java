/*
 * This code is copyright (c) 2014 EMC Corporation
 */
package com.emc.gs.tools.srf.model.mss;

import com.emc.gs.tools.srf.model.IdentifiableEntity;

/**
 * <p>
 * This is FC / ATA Drives of MSSArray entity class.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safe.
 * </p>
 * <p>
 * <strong>Changes V1.1:</strong> <strong>SRT Phase 3-1 - CTA Rainfinity and MSS Tabs Update Assembly</strong>
 * <ul>
 * <li>Add fcAta3TB4G field.</li>
 * </ul>
 * </p>
 * 
 * @author TCSASSEMBLER
 * @version 1.1
 * @since SRT Phase 3-1 - CTA Rainfinity and MSS Tabs Assembly
 */
public class MSSFcAtaDrives extends IdentifiableEntity {

    /**
     * FC / ATA Drives 73GB.
     */
    private String fcAta73GB;

    /**
     * FC / ATA Drives 146GB.
     */
    private String fcAta146GB;

    /**
     * FC / ATA Drives 300GB.
     */
    private String fcAta300GB;

    /**
     * FC / ATA Drives 400GB.
     */
    private String fcAta400GB;

    /**
     * FC / ATA Drives 450GB.
     */
    private String fcAta450GB;

    /**
     * FC / ATA Drives 500GB.
     */
    private String fcAta500GB;

    /**
     * FC / ATA Drives 600GB.
     */
    private String fcAta600GB;

    /**
     * FC / ATA Drives 750GB.
     */
    private String fcAta750GB;

    /**
     * FC / ATA Drives 1TB.
     */
    private String fcAta1TB;

    /**
     * FC / ATA Drives 2TB.
     */
    private String fcAta2TB;

    /**
     * FC / ATA Drives 3TB (4G).
     */
    private String fcAta3TB4G;

    /**
     * Other FC / ATA Drives.
     */
    private String fcAtaOther;

    /**
     * <p>
     * The default constructor.
     * </p>
     */
    public MSSFcAtaDrives() {
    }

    /**
     * Getter method for property <tt>fcAta73GB</tt>.
     * 
     * @return property value of fcAta73GB
     */
    public String getFcAta73GB() {
        return fcAta73GB;
    }

    /**
     * Setter method for property <tt>fcAta73GB</tt>.
     * 
     * @param fcAta73GB
     *            value to be assigned to property fcAta73GB
     */
    public void setFcAta73GB(String fcAta73GB) {
        this.fcAta73GB = fcAta73GB;
    }

    /**
     * Getter method for property <tt>fcAta146GB</tt>.
     * 
     * @return property value of fcAta146GB
     */
    public String getFcAta146GB() {
        return fcAta146GB;
    }

    /**
     * Setter method for property <tt>fcAta146GB</tt>.
     * 
     * @param fcAta146GB
     *            value to be assigned to property fcAta146GB
     */
    public void setFcAta146GB(String fcAta146GB) {
        this.fcAta146GB = fcAta146GB;
    }

    /**
     * Getter method for property <tt>fcAta300GB</tt>.
     * 
     * @return property value of fcAta300GB
     */
    public String getFcAta300GB() {
        return fcAta300GB;
    }

    /**
     * Setter method for property <tt>fcAta300GB</tt>.
     * 
     * @param fcAta300GB
     *            value to be assigned to property fcAta300GB
     */
    public void setFcAta300GB(String fcAta300GB) {
        this.fcAta300GB = fcAta300GB;
    }

    /**
     * Getter method for property <tt>fcAta400GB</tt>.
     * 
     * @return property value of fcAta400GB
     */
    public String getFcAta400GB() {
        return fcAta400GB;
    }

    /**
     * Setter method for property <tt>fcAta400GB</tt>.
     * 
     * @param fcAta400GB
     *            value to be assigned to property fcAta400GB
     */
    public void setFcAta400GB(String fcAta400GB) {
        this.fcAta400GB = fcAta400GB;
    }

    /**
     * Getter method for property <tt>fcAta450GB</tt>.
     * 
     * @return property value of fcAta450GB
     */
    public String getFcAta450GB() {
        return fcAta450GB;
    }

    /**
     * Setter method for property <tt>fcAta450GB</tt>.
     * 
     * @param fcAta450GB
     *            value to be assigned to property fcAta450GB
     */
    public void setFcAta450GB(String fcAta450GB) {
        this.fcAta450GB = fcAta450GB;
    }

    /**
     * Getter method for property <tt>fcAta500GB</tt>.
     * 
     * @return property value of fcAta500GB
     */
    public String getFcAta500GB() {
        return fcAta500GB;
    }

    /**
     * Setter method for property <tt>fcAta500GB</tt>.
     * 
     * @param fcAta500GB
     *            value to be assigned to property fcAta500GB
     */
    public void setFcAta500GB(String fcAta500GB) {
        this.fcAta500GB = fcAta500GB;
    }

    /**
     * Getter method for property <tt>fcAta600GB</tt>.
     * 
     * @return property value of fcAta600GB
     */
    public String getFcAta600GB() {
        return fcAta600GB;
    }

    /**
     * Setter method for property <tt>fcAta600GB</tt>.
     * 
     * @param fcAta600GB
     *            value to be assigned to property fcAta600GB
     */
    public void setFcAta600GB(String fcAta600GB) {
        this.fcAta600GB = fcAta600GB;
    }

    /**
     * Getter method for property <tt>fcAta750GB</tt>.
     * 
     * @return property value of fcAta750GB
     */
    public String getFcAta750GB() {
        return fcAta750GB;
    }

    /**
     * Setter method for property <tt>fcAta750GB</tt>.
     * 
     * @param fcAta750GB
     *            value to be assigned to property fcAta750GB
     */
    public void setFcAta750GB(String fcAta750GB) {
        this.fcAta750GB = fcAta750GB;
    }

    /**
     * Getter method for property <tt>fcAta1TB</tt>.
     * 
     * @return property value of fcAta1TB
     */
    public String getFcAta1TB() {
        return fcAta1TB;
    }

    /**
     * Setter method for property <tt>fcAta1TB</tt>.
     * 
     * @param fcAta1TB
     *            value to be assigned to property fcAta1TB
     */
    public void setFcAta1TB(String fcAta1TB) {
        this.fcAta1TB = fcAta1TB;
    }

    /**
     * Getter method for property <tt>fcAta2TB</tt>.
     * 
     * @return property value of fcAta2TB
     */
    public String getFcAta2TB() {
        return fcAta2TB;
    }

    /**
     * Setter method for property <tt>fcAta2TB</tt>.
     * 
     * @param fcAta2TB
     *            value to be assigned to property fcAta2TB
     */
    public void setFcAta2TB(String fcAta2TB) {
        this.fcAta2TB = fcAta2TB;
    }

    /**
     * Getter method for property <tt>fcAta3TB4G</tt>.
     * 
     * @return property value of fcAta3TB4G
     */
    public String getFcAta3TB4G() {
        return fcAta3TB4G;
    }

    /**
     * Setter method for property <tt>fcAta3TB4G</tt>.
     * 
     * @param fcAta3TB4G
     *            value to be assigned to property fcAta3TB4G
     */
    public void setFcAta3TB4G(String fcAta3TB4G) {
        this.fcAta3TB4G = fcAta3TB4G;
    }

    /**
     * Getter method for property <tt>fcAtaOther</tt>.
     * 
     * @return property value of fcAtaOther
     */
    public String getFcAtaOther() {
        return fcAtaOther;
    }

    /**
     * Setter method for property <tt>fcAtaOther</tt>.
     * 
     * @param fcAtaOther
     *            value to be assigned to property fcAtaOther
     */
    public void setFcAtaOther(String fcAtaOther) {
        this.fcAtaOther = fcAtaOther;
    }

}

/*
 * This code is copyright (c) 2014 EMC Corporation
 */
package com.emc.gs.tools.srf.model.dpad;

import com.emc.gs.tools.srf.model.IdentifiableEntity;

/**
 * <p>
 * This is NetworkerComponents entity class.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safety.
 * </p>
 * 
 * @author TCSASSEMBLER
 * @version 1.0
 * @since SRT Phase 3-5 - BRS Tabs Part 3 Assembly
 */
public class NetworkerComponents extends IdentifiableEntity {

    /**
     * Represents whether "Networker Server" component is selected.
     */
    private boolean server;

    /**
     * Represents whether "Networker Advanced Backup Technology" component is selected.
     */
    private boolean advancedBackupTech;

    /**
     * Represents whether "Networker Storage Nodes" component is selected.
     */
    private boolean storageNodes;

    /**
     * Represents whether "Networker File System Client Backups" component is selected.
     */
    private boolean fileSystemClientBackups;

    /**
     * Represents whether "Media Devices" component is selected.
     */
    private boolean mediaDevices;

    /**
     * Represents whether "Networker Application Backups" component is selected.
     */
    private boolean applicationBackups;

    /**
     * Represents whether "EMC Backup and Recovery Manager" component is selected.
     */
    private boolean emcBackupRecoveryManager;

    /**
     * <p>
     * The default constructor.
     * </p>
     */
    public NetworkerComponents() {
    }

    /**
     * Getter method for property <tt>server</tt>.
     * 
     * @return property value of server
     */
    public boolean isServer() {
        return server;
    }

    /**
     * Setter method for property <tt>server</tt>.
     * 
     * @param server
     *            value to be assigned to property server
     */
    public void setServer(boolean server) {
        this.server = server;
    }

    /**
     * Getter method for property <tt>advancedBackupTech</tt>.
     * 
     * @return property value of advancedBackupTech
     */
    public boolean isAdvancedBackupTech() {
        return advancedBackupTech;
    }

    /**
     * Setter method for property <tt>advancedBackupTech</tt>.
     * 
     * @param advancedBackupTech
     *            value to be assigned to property advancedBackupTech
     */
    public void setAdvancedBackupTech(boolean advancedBackupTech) {
        this.advancedBackupTech = advancedBackupTech;
    }

    /**
     * Getter method for property <tt>storageNodes</tt>.
     * 
     * @return property value of storageNodes
     */
    public boolean isStorageNodes() {
        return storageNodes;
    }

    /**
     * Setter method for property <tt>storageNodes</tt>.
     * 
     * @param storageNodes
     *            value to be assigned to property storageNodes
     */
    public void setStorageNodes(boolean storageNodes) {
        this.storageNodes = storageNodes;
    }

    /**
     * Getter method for property <tt>fileSystemClientBackups</tt>.
     * 
     * @return property value of fileSystemClientBackups
     */
    public boolean isFileSystemClientBackups() {
        return fileSystemClientBackups;
    }

    /**
     * Setter method for property <tt>fileSystemClientBackups</tt>.
     * 
     * @param fileSystemClientBackups
     *            value to be assigned to property fileSystemClientBackups
     */
    public void setFileSystemClientBackups(boolean fileSystemClientBackups) {
        this.fileSystemClientBackups = fileSystemClientBackups;
    }

    /**
     * Getter method for property <tt>mediaDevices</tt>.
     * 
     * @return property value of mediaDevices
     */
    public boolean isMediaDevices() {
        return mediaDevices;
    }

    /**
     * Setter method for property <tt>mediaDevices</tt>.
     * 
     * @param mediaDevices
     *            value to be assigned to property mediaDevices
     */
    public void setMediaDevices(boolean mediaDevices) {
        this.mediaDevices = mediaDevices;
    }

    /**
     * Getter method for property <tt>applicationBackups</tt>.
     * 
     * @return property value of applicationBackups
     */
    public boolean isApplicationBackups() {
        return applicationBackups;
    }

    /**
     * Setter method for property <tt>applicationBackups</tt>.
     * 
     * @param applicationBackups
     *            value to be assigned to property applicationBackups
     */
    public void setApplicationBackups(boolean applicationBackups) {
        this.applicationBackups = applicationBackups;
    }

    /**
     * Getter method for property <tt>emcBackupRecoveryManager</tt>.
     * 
     * @return property value of emcBackupRecoveryManager
     */
    public boolean isEmcBackupRecoveryManager() {
        return emcBackupRecoveryManager;
    }

    /**
     * Setter method for property <tt>emcBackupRecoveryManager</tt>.
     * 
     * @param emcBackupRecoveryManager
     *            value to be assigned to property emcBackupRecoveryManager
     */
    public void setEmcBackupRecoveryManager(boolean emcBackupRecoveryManager) {
        this.emcBackupRecoveryManager = emcBackupRecoveryManager;
    }

}

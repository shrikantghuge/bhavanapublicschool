/*
 * This code is copyright (c) 2014 EMC Corporation
 */
package com.emc.gs.tools.srf.model.atmos;

import com.emc.gs.tools.srf.model.IdentifiableEntity;

/**
 * <p>
 * This is CenteraUniversalAccess entity class.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safety.
 * </p>
 * 
 * @author TCSASSEMBLER
 * @version 1.0
 * @since SRT Phase 3-1 - Atmos Centera and Vblock Tabs Assembly
 */
public class CenteraUniversalAccess extends IdentifiableEntity {

    /**
     * # of active CUAs to add to this Centera at this location.
     */
    private Integer activeCUAsNum;

    /**
     * # of data pools required on this CUA.
     */
    private Integer dataPoolsNum;

    /**
     * # of standby CUAs to add to this Centera at this location.
     */
    private Integer standbyCUAsNum;

    /**
     * CUA Hardware Type.
     */
    private CUAHardwareType cuaHardwareType;

    /**
     * # of active or standby CUAs to be relocated.
     */
    private Integer relocatedCUAsNum;

    /**
     * <p>
     * The default constructor.
     * </p>
     */
    public CenteraUniversalAccess() {
    }

    /**
     * Getter method for property <tt>activeCUAsNum</tt>.
     * 
     * @return property value of activeCUAsNum
     */
    public Integer getActiveCUAsNum() {
        return activeCUAsNum;
    }

    /**
     * Setter method for property <tt>activeCUAsNum</tt>.
     * 
     * @param activeCUAsNum
     *            value to be assigned to property activeCUAsNum
     */
    public void setActiveCUAsNum(Integer activeCUAsNum) {
        this.activeCUAsNum = activeCUAsNum;
    }

    /**
     * Getter method for property <tt>dataPoolsNum</tt>.
     * 
     * @return property value of dataPoolsNum
     */
    public Integer getDataPoolsNum() {
        return dataPoolsNum;
    }

    /**
     * Setter method for property <tt>dataPoolsNum</tt>.
     * 
     * @param dataPoolsNum
     *            value to be assigned to property dataPoolsNum
     */
    public void setDataPoolsNum(Integer dataPoolsNum) {
        this.dataPoolsNum = dataPoolsNum;
    }

    /**
     * Getter method for property <tt>standbyCUAsNum</tt>.
     * 
     * @return property value of standbyCUAsNum
     */
    public Integer getStandbyCUAsNum() {
        return standbyCUAsNum;
    }

    /**
     * Setter method for property <tt>standbyCUAsNum</tt>.
     * 
     * @param standbyCUAsNum
     *            value to be assigned to property standbyCUAsNum
     */
    public void setStandbyCUAsNum(Integer standbyCUAsNum) {
        this.standbyCUAsNum = standbyCUAsNum;
    }

    /**
     * Getter method for property <tt>cuaHardwareType</tt>.
     * 
     * @return property value of cuaHardwareType
     */
    public CUAHardwareType getCuaHardwareType() {
        return cuaHardwareType;
    }

    /**
     * Setter method for property <tt>cuaHardwareType</tt>.
     * 
     * @param cuaHardwareType
     *            value to be assigned to property cuaHardwareType
     */
    public void setCuaHardwareType(CUAHardwareType cuaHardwareType) {
        this.cuaHardwareType = cuaHardwareType;
    }

    /**
     * Getter method for property <tt>relocatedCUAsNum</tt>.
     * 
     * @return property value of relocatedCUAsNum
     */
    public Integer getRelocatedCUAsNum() {
        return relocatedCUAsNum;
    }

    /**
     * Setter method for property <tt>relocatedCUAsNum</tt>.
     * 
     * @param relocatedCUAsNum
     *            value to be assigned to property relocatedCUAsNum
     */
    public void setRelocatedCUAsNum(Integer relocatedCUAsNum) {
        this.relocatedCUAsNum = relocatedCUAsNum;
    }

}

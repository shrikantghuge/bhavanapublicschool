/*
 * This code is copyright (c) 2014 EMC Corporation
 */
package com.emc.gs.tools.srf.model.isilon;

import com.emc.gs.tools.srf.model.IdentifiableEntity;

/**
 * <p>
 * This is IsilonServicesScope entity class.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safety.
 * </p>
 * 
 * @author TCSASSEMBLER
 * @version 1.0
 * @since SRT Phase 3-3 - Implement Isilon and ViPR Tabs Assembly
 */
public class IsilonServicesScope extends IdentifiableEntity {

    /**
     * Represents whether Isilon Cluster Relocation service is in scope.
     */
    private boolean clusterRelocation;

    /**
     * Represents whether Isilon Hardware Upgrade service is in scope.
     */
    private boolean hardwareUpgrade;

    /**
     * Represents whether Isilon Migration service is in scope.
     */
    private boolean migration;

    /**
     * Represents whether Isilon Design and Implementation service is in scope.
     */
    private boolean designAndImpl;

    /**
     * Represents whether Isilon Configuration Assurance service is in scope.
     */
    private boolean configAssurance;

    /**
     * <p>
     * The default constructor.
     * </p>
     */
    public IsilonServicesScope() {
    }

    /**
     * Getter method for property <tt>clusterRelocation</tt>.
     * 
     * @return property value of clusterRelocation
     */
    public boolean isClusterRelocation() {
        return clusterRelocation;
    }

    /**
     * Setter method for property <tt>clusterRelocation</tt>.
     * 
     * @param clusterRelocation
     *            value to be assigned to property clusterRelocation
     */
    public void setClusterRelocation(boolean clusterRelocation) {
        this.clusterRelocation = clusterRelocation;
    }

    /**
     * Getter method for property <tt>hardwareUpgrade</tt>.
     * 
     * @return property value of hardwareUpgrade
     */
    public boolean isHardwareUpgrade() {
        return hardwareUpgrade;
    }

    /**
     * Setter method for property <tt>hardwareUpgrade</tt>.
     * 
     * @param hardwareUpgrade
     *            value to be assigned to property hardwareUpgrade
     */
    public void setHardwareUpgrade(boolean hardwareUpgrade) {
        this.hardwareUpgrade = hardwareUpgrade;
    }

    /**
     * Getter method for property <tt>migration</tt>.
     * 
     * @return property value of migration
     */
    public boolean isMigration() {
        return migration;
    }

    /**
     * Setter method for property <tt>migration</tt>.
     * 
     * @param migration
     *            value to be assigned to property migration
     */
    public void setMigration(boolean migration) {
        this.migration = migration;
    }

    /**
     * Getter method for property <tt>designAndImpl</tt>.
     * 
     * @return property value of designAndImpl
     */
    public boolean isDesignAndImpl() {
        return designAndImpl;
    }

    /**
     * Setter method for property <tt>designAndImpl</tt>.
     * 
     * @param designAndImpl
     *            value to be assigned to property designAndImpl
     */
    public void setDesignAndImpl(boolean designAndImpl) {
        this.designAndImpl = designAndImpl;
    }

    /**
     * Getter method for property <tt>configAssurance</tt>.
     * 
     * @return property value of configAssurance
     */
    public boolean isConfigAssurance() {
        return configAssurance;
    }

    /**
     * Setter method for property <tt>configAssurance</tt>.
     * 
     * @param configAssurance
     *            value to be assigned to property configAssurance
     */
    public void setConfigAssurance(boolean configAssurance) {
        this.configAssurance = configAssurance;
    }

}

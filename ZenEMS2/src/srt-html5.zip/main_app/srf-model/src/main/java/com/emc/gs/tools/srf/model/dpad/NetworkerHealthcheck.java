/*
 * This code is copyright (c) 2014 EMC Corporation.
 */
package com.emc.gs.tools.srf.model.dpad;

import com.emc.gs.tools.srf.model.IdentifiableEntity;

/**
 * <p>This is NetworkerHealthcheck entity class.</p>
 * 
 * <p><strong>Thread safety</strong>: This class is mutable, it is not thread safety.</p>
 * 
 * @author isv
 * @version 1.0 (SRT 4 OCT2014 Updates Part 1 Assembly)
 */
public class NetworkerHealthcheck extends IdentifiableEntity {

    /**
     * <p>A <code>Boolean</code> providing the value for "Will a presentation of EMC Assessment Service Analysis be
     * given?" property.</p>
     */
    private Boolean emcAssessmentServiceAnalysisPresentation;

    /**
     * <p>A <code>Integer</code> providing the value for "# of Networker Datazones?" property.</p>
     */
    private Integer numberOfNetworkerDatazones;

    /**
     * <p>A <code>Integer</code> providing the value for "# of Assessment Interviews?" property.</p>
     */
    private Integer numberOfAssessmentInterviews;

    /**
     * <p>Constructs new <code>NetworkerHealthcheck</code> instance. This implementation does nothing.</p>
     */
    public NetworkerHealthcheck() {
    }

    /**
     * <p>Gets the "# of Assessment Interviews?" property.</p>
     *
     * @return a <code>Integer</code> providing the value for "# of Assessment Interviews?" property.
     */
    public Integer getNumberOfAssessmentInterviews() {
        return this.numberOfAssessmentInterviews;
    }

    /**
     * <p>Sets the "# of Assessment Interviews?" property.</p>
     *
     * @param numberOfAssessmentInterviews a <code>Integer</code> providing the value for "# of Assessment Interviews?"
     * property.
     */
    public void setNumberOfAssessmentInterviews(Integer numberOfAssessmentInterviews) {
        this.numberOfAssessmentInterviews = numberOfAssessmentInterviews;
    }

    /**
     * <p>Gets the "# of Networker Datazones?" property.</p>
     *
     * @return a <code>Integer</code> providing the value for "# of Networker Datazones?" property.
     */
    public Integer getNumberOfNetworkerDatazones() {
        return this.numberOfNetworkerDatazones;
    }

    /**
     * <p>Sets the "# of Networker Datazones?" property.</p>
     *
     * @param numberOfNetworkerDatazones a <code>Integer</code> providing the value for "# of Networker Datazones?"
     * property.
     */
    public void setNumberOfNetworkerDatazones(Integer numberOfNetworkerDatazones) {
        this.numberOfNetworkerDatazones = numberOfNetworkerDatazones;
    }

    /**
     * <p>Gets the "Will a presentation of EMC Assessment Service Analysis be given?" property.</p>
     *
     * @return a <code>Boolean</code> providing the value for "Will a presentation of EMC Assessment Service Analysis be
     * given?" property.
     */
    public Boolean getEmcAssessmentServiceAnalysisPresentation() {
        return this.emcAssessmentServiceAnalysisPresentation;
    }

    /**
     * <p>Sets the "Will a presentation of EMC Assessment Service Analysis be given?" property.</p>
     *
     * @param emcAssessmentServiceAnalysisPresentation a <code>Boolean</code> providing the value for "Will a
     * presentation of EMC Assessment Service Analysis be given?" property.
     */
    public void setEmcAssessmentServiceAnalysisPresentation(Boolean emcAssessmentServiceAnalysisPresentation) {
        this.emcAssessmentServiceAnalysisPresentation = emcAssessmentServiceAnalysisPresentation;
    }

}

/*
 * This code is copyright (c) 2013 - 2014 EMC Corporation.
 */
package com.emc.gs.tools.srf.model.bc;

import java.util.HashMap;
import java.util.Map;

import com.emc.gs.tools.srf.model.IdentifiableEntity;

/**
 * <p>
 * This is SnapViewInformation entity class.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safety.
 * </p>
 * 
 * <p>
 * <strong>Changes V1.1:</strong>
 * <strong>SRT Bug Fixes - F121, F153, F154, F162</strong>
 * <ul>
 * <li>Add knowledgeTransferHours field.</li>
 * </ul>
 * </p>
 * 
 * <p>
 * <strong>Changes V1.2:</strong>
 * <ul>
 * <li>Removed databaseNumbers, copiesNumber, areaSizingType, emcMapPointsOption fields.</li>
 * </ul>
 * </p>
 * 
 * <p>
 * <strong>Changes V1.3:</strong>
 * <strong>https://apps.topcoder.com/bugs/browse/SRT-35</strong>
 * <ul>
 * <li>Added snapViewFunctionalityRequired, snapShotViewFunctionalityRequired, nrOfVnxArrays, 
 * nrOfVnxSnapshotsCopies, nrOfSnapViewClonesCopies fields.</li>
 * </ul>
 * </p> 
 *
 * <p>
 * Version 1.4 (SRT 4 OCT2014 Updates Part 1 Assembly) Change notes:
 *   <ol>
 *     <li>Added {@link #numberOfSnapViewConsistentSessions} property.</li>
 *     <li>Added {@link #numberOfSnapViewPersistentSessions} property.</li>
 *   </ol>
 * </p>
 * 
 * @author faeton, stevenfrog, MonicaMuranyi
 * @version 1.4
 */
public class SnapViewInformation extends IdentifiableEntity {
    
    /**
     * <p>
     * The knowledgeTransferHours.
     * </p>
     */
    private String knowledgeTransferHours;
    
    /**
     * <p>
     * The hostNumbers.
     * </p>
     */
    private Map<String, Integer> hostNumbers = new HashMap<String, Integer>();

    /**
     * <p>
     * The replicatedStorageSize.
     * </p>
     */
    private Integer replicatedStorageSize;

    /**
     * <p>
     * The scriptingLevel.
     * </p>
     */
    private ScriptingLevel scriptingLevel;
    
    /**
     * <p>
     * The snapViewFunctionalityRequired.
     * </p>
     */
    private boolean snapViewFunctionalityRequired;
    
    /**
     * <p>
     * The snapShotViewFunctionalityRequired.
     * </p>
     */
    private boolean snapShotViewFunctionalityRequired;
    
    /**
     * <p>
     * The nrOfVnxArrays.
     * </p>
     */
    private Integer nrOfVnxArrays;
    
    /**
     * <p>
     * The nrOfVnxSnapshotsCopies.
     * </p>
     */
    private Integer nrOfVnxSnapshotsCopies;
    
    /**
     * <p>
     * The nrOfSnapViewClonesCopies.
     * </p>
     */
    private Integer nrOfSnapViewClonesCopies;

    /**
     * <p>A <code>Integer</code> providing the value for "# of Consistent Sessions for SnapView?" property.</p>
     *
     * @since 1.4
     */
    private Integer numberOfSnapViewConsistentSessions;

    /**
     * <p>A <code>Integer</code> providing the value for "# of Persistent Sessions for SnapView?" property.</p>
     *
     * @since 1.4
     */
    private Integer numberOfSnapViewPersistentSessions;

    /**
     * <p>
     * The default constructor.
     * </p>
     */
    public SnapViewInformation() {
        // Empty
    }
    
    /**
     * <p>
     * Retrieves the knowledgeTransferHours field.
     * </p>
     *
     * @return the knowledgeTransferHours
     */
    public String getKnowledgeTransferHours() {
        return knowledgeTransferHours;
    }
    
    /**
     * <p>
     * Sets the value to knowledgeTransferHours field.
     * </p>
     *
     * @param knowledgeTransferHours
     *            the knowledgeTransferHours to set
     */
    public void setKnowledgeTransferHours(String knowledgeTransferHours) {
        this.knowledgeTransferHours = knowledgeTransferHours;
    }

    /**
     * <p>
     * Retrieves the hostNumbers field.
     * </p>
     *
     * @return the value of hostNumbers
     */
    public Map<String, Integer> getHostNumbers() {
        return hostNumbers;
    }

    /**
     * <p>
     * Sets the value to hostNumbers field.
     * </p>
     *
     * @param hostNumbers the value of hostNumbers to set
     */
    public void setHostNumbers(Map<String, Integer> hostNumbers) {
        this.hostNumbers = hostNumbers;
    }

    /**
     * <p>
     * Retrieves the replicatedStorageSize field.
     * </p>
     *
     * @return the replicatedStorageSize
     */
    public Integer getReplicatedStorageSize() {
        return replicatedStorageSize;
    }

    /**
     * <p>
     * Sets the value to replicatedStorageSize field.
     * </p>
     *
     * @param replicatedStorageSize
     *            the replicatedStorageSize to set
     */
    public void setReplicatedStorageSize(Integer replicatedStorageSize) {
        this.replicatedStorageSize = replicatedStorageSize;
    }

    /**
     * <p>
     * Retrieves the scriptingLevel field.
     * </p>
     *
     * @return the scriptingLevel
     */
    public ScriptingLevel getScriptingLevel() {
        return scriptingLevel;
    }

    /**
     * <p>
     * Sets the value to scriptingLevel field.
     * </p>
     *
     * @param scriptingLevel
     *            the scriptingLevel to set
     */
    public void setScriptingLevel(ScriptingLevel scriptingLevel) {
        this.scriptingLevel = scriptingLevel;
    }
    
    /**
     * <p>
     * Retrieves the snapViewFunctionalityRequired field.
     * </p>
     *
     * @return the snapViewFunctionalityRequired
     */
    public boolean isSnapViewFunctionalityRequired() {
        return snapViewFunctionalityRequired;
    }

    /**
     * <p>
     * Sets the value to snapViewFunctionalityRequired field.
     * </p>
     *
     * @param snapViewFunctionalityRequired
     *            the snapViewFunctionalityRequired to set
     */
    public void setSnapViewFunctionalityRequired(boolean snapViewFunctionalityRequired) {
        this.snapViewFunctionalityRequired = snapViewFunctionalityRequired;
    }
    
    /**
     * <p>
     * Retrieves the snapShotViewFunctionalityRequired field.
     * </p>
     *
     * @return the snapShotViewFunctionalityRequired
     */
    public boolean isSnapShotViewFunctionalityRequired() {
        return snapShotViewFunctionalityRequired;
    }

    /**
     * <p>
     * Sets the value to snapShotViewFunctionalityRequired field.
     * </p>
     *
     * @param snapShotViewFunctionalityRequired
     *            the snapShotViewFunctionalityRequired to set
     */
    public void setSnapShotViewFunctionalityRequired(boolean snapShotViewFunctionalityRequired) {
        this.snapShotViewFunctionalityRequired = snapShotViewFunctionalityRequired;
    }

    /**
     * <p>
     * Retrieves the nrOfVnxArrays field.
     * </p>
     *
     * @return the nrOfVnxArrays
     */
    public Integer getNrOfVnxArrays() {
        return nrOfVnxArrays;
    }

    /**
     * <p>
     * Sets the value to nrOfVnxArrays field.
     * </p>
     *
     * @param nrOfVnxArrays
     *            the nrOfVnxArrays to set
     */
    public void setNrOfVnxArrays(Integer nrOfVnxArrays) {
        this.nrOfVnxArrays = nrOfVnxArrays;
    }

    /**
     * <p>
     * Retrieves the nrOfVnxSnapshotsCopies field.
     * </p>
     *
     * @return the nrOfVnxSnapshotsCopies
     */
    public Integer getNrOfVnxSnapshotsCopies() {
        return nrOfVnxSnapshotsCopies;
    }

    /**
     * <p>
     * Sets the value to nrOfVnxSnapshotsCopies field.
     * </p>
     *
     * @param nrOfVnxSnapshotsCopies
     *            the nrOfVnxSnapshotsCopies to set
     */
    public void setNrOfVnxSnapshotsCopies(Integer nrOfVnxSnapshotsCopies) {
        this.nrOfVnxSnapshotsCopies = nrOfVnxSnapshotsCopies;
    }

    /**
     * <p>
     * Retrieves the nrOfSnapViewClonesCopies field.
     * </p>
     *
     * @return the nrOfSnapViewClonesCopies
     */
    public Integer getNrOfSnapViewClonesCopies() {
        return nrOfSnapViewClonesCopies;
    }

    /**
     * <p>
     * Sets the value to nrOfSnapViewClonesCopies field.
     * </p>
     *
     * @param nrOfSnapViewClonesCopies
     *            the nrOfSnapViewClonesCopies to set
     */
    public void setNrOfSnapViewClonesCopies(Integer nrOfSnapViewClonesCopies) {
        this.nrOfSnapViewClonesCopies = nrOfSnapViewClonesCopies;
    }

    /**
     * <p>Gets the "# of Persistent Sessions for SnapView?" property.</p>
     *
     * @return a <code>Integer</code> providing the value for "# of Persistent Sessions for SnapView?" property.
     * @since 1.4
     */
    public Integer getNumberOfSnapViewPersistentSessions() {
        return this.numberOfSnapViewPersistentSessions;
    }

    /**
     * <p>Sets the "# of Persistent Sessions for SnapView?" property.</p>
     *
     * @param numberOfSnapViewPersistentSessions a <code>Integer</code> providing the value for "# of Persistent
     * Sessions for SnapView?" property.
     * @since 1.4
     */
    public void setNumberOfSnapViewPersistentSessions(Integer numberOfSnapViewPersistentSessions) {
        this.numberOfSnapViewPersistentSessions = numberOfSnapViewPersistentSessions;
    }

    /**
     * <p>Gets the "# of Consistent Sessions for SnapView?" property.</p>
     *
     * @return a <code>Integer</code> providing the value for "# of Consistent Sessions for SnapView?" property.
     * @since 1.4
     */
    public Integer getNumberOfSnapViewConsistentSessions() {
        return this.numberOfSnapViewConsistentSessions;
    }

    /**
     * <p>Sets the "# of Consistent Sessions for SnapView?" property.</p>
     *
     * @param numberOfSnapViewConsistentSessions a <code>Integer</code> providing the value for "# of Consistent
     * Sessions for SnapView?" property.
     * @since 1.4
     */
    public void setNumberOfSnapViewConsistentSessions(Integer numberOfSnapViewConsistentSessions) {
        this.numberOfSnapViewConsistentSessions = numberOfSnapViewConsistentSessions;
    }

    /**
     * The toString method.
     *
     * @return the string for this entity
     */
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("{").append(super.toString());
        sb.append(", knowledgeTransferHours:").append(knowledgeTransferHours);
        sb.append(", hostNumbers:").append(hostNumbers);
        sb.append(", replicatedStorageSize:").append(replicatedStorageSize);
        sb.append(", replicatedStorageSize:").append(snapViewFunctionalityRequired);
        sb.append(", replicatedStorageSize:").append(snapShotViewFunctionalityRequired);
        sb.append(", nrOfVnxArrays:").append(nrOfVnxArrays);
        sb.append(", nrOfVnxSnapshotsCopies:").append(nrOfVnxSnapshotsCopies);
        sb.append(", nrOfSnapViewClonesCopies:").append(nrOfSnapViewClonesCopies);
        sb.append(", numberOfSnapViewConsistentSessions:").append(numberOfSnapViewConsistentSessions);
        sb.append(", numberOfSnapViewPersistentSessions:").append(numberOfSnapViewPersistentSessions);
        sb.append(", scriptingLevel:").append(scriptingLevel).append("}");
        return sb.toString();
    }
}

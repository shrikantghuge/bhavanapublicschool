/*
 * This code is copyright (c) 2014 EMC Corporation
 */
package com.emc.gs.tools.srf.model.dpad;

import com.emc.gs.tools.srf.model.IdentifiableEntity;

/**
 * <p>This is RPAHardwareUpgrade entity class.</p>
 *
 * <p><strong>Thread safety</strong>: This class is mutable, it is not thread safety.</p>
 *
 * @author isv
 * @version 1.0 (SRT 4 OCT2014 Updates Part 2)
 */
public class RPAHardwareUpgrade extends IdentifiableEntity {

    /**
     * <p>A <code>Boolean</code> providing the value for "Is the RP Upgrade Being Done on GEN1 RPA Hardware?" flag
     * property.</p>
     */
    private Boolean gen1RPAHardwareUsed;

    /**
     * <p>A <code>Integer</code> providing the value for "# of RPAs to be Upgraded?" property.</p>
     */
    private Integer numberOfRPAsToUpgrade;

    /**
     * <p>Constructs new <code>RPAHardwareUpgrade</code> instance. This implementation does nothing.</p>
     */
    public RPAHardwareUpgrade() {
    }

    /**
     * <p>Gets the "Is the RP Upgrade Being Done on GEN1 RPA Hardware?" flag property.</p>
     *
     * @return a <code>Boolean</code> providing the value for "Is the RP Upgrade Being Done on GEN1 RPA Hardware?" flag
     * property.
     */
    public Boolean getGen1RPAHardwareUsed() {
        return this.gen1RPAHardwareUsed;
    }

    /**
     * <p>Sets the "Is the RP Upgrade Being Done on GEN1 RPA Hardware?" flag property.</p>
     *
     * @param gen1RPAHardwareUsed a <code>Boolean</code> providing the value for "Is the RP Upgrade Being Done on GEN1
     * RPA Hardware?" flag property.
     */
    public void setGen1RPAHardwareUsed(Boolean gen1RPAHardwareUsed) {
        this.gen1RPAHardwareUsed = gen1RPAHardwareUsed;
    }

    /**
     * <p>Gets the "# of RPAs to be Upgraded?" property.</p>
     *
     * @return a <code>Integer</code> providing the value for "# of RPAs to be Upgraded?" property.
     */
    public Integer getNumberOfRPAsToUpgrade() {
        return this.numberOfRPAsToUpgrade;
    }

    /**
     * <p>Sets the "# of RPAs to be Upgraded?" property.</p>
     *
     * @param numberOfRPAsToUpgrade a <code>Integer</code> providing the value for "# of RPAs to be Upgraded?"
     * property.
     */
    public void setNumberOfRPAsToUpgrade(Integer numberOfRPAsToUpgrade) {
        this.numberOfRPAsToUpgrade = numberOfRPAsToUpgrade;
    }
}

/*
 * This code is copyright (c) 2014 EMC Corporation
 */
package com.emc.gs.tools.srf.model.isilon;

import java.math.BigDecimal;

import com.emc.gs.tools.srf.model.IdentifiableEntity;

/**
 * <p>
 * This is IsilonMigration entity class.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safety.
 * </p>
 * 
 * @author TCSASSEMBLER
 * @version 1.0
 * @since SRT Phase 3-3 - Implement Isilon and ViPR Tabs Assembly
 */
public class IsilonMigration extends IdentifiableEntity {

    /**
     * Migration Type: NetApp/Third Party Migration to Isilon.
     */
    private boolean netApp3rdPartyMigration;

    /**
     * Migration Type: Celerra/Unified File to Isilon.
     */
    private boolean celerraUnifiedFile;

    /**
     * Migration Type: Isilon to Isilon SyncIQ.
     */
    private boolean syncIQ;

    /**
     * Migration Type: Isilon Technology Refresh.
     */
    private boolean techRefresh;

    /**
     * Level of EMC Involvement: Planning and Design.
     */
    private boolean planAndDesign;

    /**
     * Level of EMC Involvement: Implementation and Migration.
     */
    private boolean implAndMigration;

    /**
     * Include Activities for User Defined Additional Effort: Additional Testing.
     */
    private boolean additionalTesting;

    /**
     * Include Activities for User Defined Additional Effort: Additional Monitoring.
     */
    private boolean additionalMonitoring;

    /**
     * Include Activities for User Defined Additional Effort: Scripting Work.
     */
    private boolean scriptingWork;

    /**
     * Install Isilon Hardware(New cluster or node expansion)?
     */
    private Boolean installIsilonHardware;

    /**
     * Select protocols for Isilon Migrations: CIFS.
     */
    private boolean cifs;

    /**
     * Select protocols for Isilon Migrations: NFS.
     */
    private boolean nfs;

    /**
     * Select protocols for Isilon Migrations: Multi-protocol.
     */
    private boolean multiProtocol;

    /**
     * Amount of CIFS data in TB to be migrated.
     */
    private Integer cifsDataAmount;

    /**
     * Include Local Users and Groups?
     */
    private Boolean includeLocalUsersGroups;

    /**
     * Amount of NFS Data in TB to be Migrated.
     */
    private Integer nfsDataAmount;

    /**
     * Amount of Multi-Protocol Data in TB to be Migrated.
     */
    private Integer multiProtocolDataAmount;

    /**
     * Average duration of data migration event.
     */
    private BigDecimal averageDuration;

    /**
     * # of data migration events.
     */
    private Integer dataMigEventsNum;

    /**
     * # of weeks to monitor data movement.
     */
    private Integer monitorWeeksNum;

    /**
     * # of cutover events for synch IQ migration.
     */
    private Integer cutoverEventsNum;

    /**
     * Is SmartPools already enabled on the clusters?
     */
    private Boolean smartPoolsEnabled;

    /**
     * Total # of Isilon nodes to be removed on the cluster after refresh.
     */
    private Integer removeNodesNum;

    /**
     * # of events required to move all node data.
     */
    private Integer requiredEventsNum;

    /**
     * Total TB of data to be moved as part of tech refresh.
     */
    private Integer techRefreshMovedData;

    /**
     * <p>
     * The default constructor.
     * </p>
     */
    public IsilonMigration() {
    }

    /**
     * Getter method for property <tt>netApp3rdPartyMigration</tt>.
     * 
     * @return property value of netApp3rdPartyMigration
     */
    public boolean isNetApp3rdPartyMigration() {
        return netApp3rdPartyMigration;
    }

    /**
     * Setter method for property <tt>netApp3rdPartyMigration</tt>.
     * 
     * @param netApp3rdPartyMigration
     *            value to be assigned to property netApp3rdPartyMigration
     */
    public void setNetApp3rdPartyMigration(boolean netApp3rdPartyMigration) {
        this.netApp3rdPartyMigration = netApp3rdPartyMigration;
    }

    /**
     * Getter method for property <tt>celerraUnifiedFile</tt>.
     * 
     * @return property value of celerraUnifiedFile
     */
    public boolean isCelerraUnifiedFile() {
        return celerraUnifiedFile;
    }

    /**
     * Setter method for property <tt>celerraUnifiedFile</tt>.
     * 
     * @param celerraUnifiedFile
     *            value to be assigned to property celerraUnifiedFile
     */
    public void setCelerraUnifiedFile(boolean celerraUnifiedFile) {
        this.celerraUnifiedFile = celerraUnifiedFile;
    }

    /**
     * Getter method for property <tt>syncIQ</tt>.
     * 
     * @return property value of syncIQ
     */
    public boolean isSyncIQ() {
        return syncIQ;
    }

    /**
     * Setter method for property <tt>syncIQ</tt>.
     * 
     * @param syncIQ
     *            value to be assigned to property syncIQ
     */
    public void setSyncIQ(boolean syncIQ) {
        this.syncIQ = syncIQ;
    }

    /**
     * Getter method for property <tt>techRefresh</tt>.
     * 
     * @return property value of techRefresh
     */
    public boolean isTechRefresh() {
        return techRefresh;
    }

    /**
     * Setter method for property <tt>techRefresh</tt>.
     * 
     * @param techRefresh
     *            value to be assigned to property techRefresh
     */
    public void setTechRefresh(boolean techRefresh) {
        this.techRefresh = techRefresh;
    }

    /**
     * Getter method for property <tt>planAndDesign</tt>.
     * 
     * @return property value of planAndDesign
     */
    public boolean isPlanAndDesign() {
        return planAndDesign;
    }

    /**
     * Setter method for property <tt>planAndDesign</tt>.
     * 
     * @param planAndDesign
     *            value to be assigned to property planAndDesign
     */
    public void setPlanAndDesign(boolean planAndDesign) {
        this.planAndDesign = planAndDesign;
    }

    /**
     * Getter method for property <tt>implAndMigration</tt>.
     * 
     * @return property value of implAndMigration
     */
    public boolean isImplAndMigration() {
        return implAndMigration;
    }

    /**
     * Setter method for property <tt>implAndMigration</tt>.
     * 
     * @param implAndMigration
     *            value to be assigned to property implAndMigration
     */
    public void setImplAndMigration(boolean implAndMigration) {
        this.implAndMigration = implAndMigration;
    }

    /**
     * Getter method for property <tt>additionalTesting</tt>.
     * 
     * @return property value of additionalTesting
     */
    public boolean isAdditionalTesting() {
        return additionalTesting;
    }

    /**
     * Setter method for property <tt>additionalTesting</tt>.
     * 
     * @param additionalTesting
     *            value to be assigned to property additionalTesting
     */
    public void setAdditionalTesting(boolean additionalTesting) {
        this.additionalTesting = additionalTesting;
    }

    /**
     * Getter method for property <tt>additionalMonitoring</tt>.
     * 
     * @return property value of additionalMonitoring
     */
    public boolean isAdditionalMonitoring() {
        return additionalMonitoring;
    }

    /**
     * Setter method for property <tt>additionalMonitoring</tt>.
     * 
     * @param additionalMonitoring
     *            value to be assigned to property additionalMonitoring
     */
    public void setAdditionalMonitoring(boolean additionalMonitoring) {
        this.additionalMonitoring = additionalMonitoring;
    }

    /**
     * Getter method for property <tt>scriptingWork</tt>.
     * 
     * @return property value of scriptingWork
     */
    public boolean isScriptingWork() {
        return scriptingWork;
    }

    /**
     * Setter method for property <tt>scriptingWork</tt>.
     * 
     * @param scriptingWork
     *            value to be assigned to property scriptingWork
     */
    public void setScriptingWork(boolean scriptingWork) {
        this.scriptingWork = scriptingWork;
    }

    /**
     * Getter method for property <tt>installIsilonHardware</tt>.
     * 
     * @return property value of installIsilonHardware
     */
    public Boolean getInstallIsilonHardware() {
        return installIsilonHardware;
    }

    /**
     * Setter method for property <tt>installIsilonHardware</tt>.
     * 
     * @param installIsilonHardware
     *            value to be assigned to property installIsilonHardware
     */
    public void setInstallIsilonHardware(Boolean installIsilonHardware) {
        this.installIsilonHardware = installIsilonHardware;
    }

    /**
     * Getter method for property <tt>cifs</tt>.
     * 
     * @return property value of cifs
     */
    public boolean isCifs() {
        return cifs;
    }

    /**
     * Setter method for property <tt>cifs</tt>.
     * 
     * @param cifs
     *            value to be assigned to property cifs
     */
    public void setCifs(boolean cifs) {
        this.cifs = cifs;
    }

    /**
     * Getter method for property <tt>nfs</tt>.
     * 
     * @return property value of nfs
     */
    public boolean isNfs() {
        return nfs;
    }

    /**
     * Setter method for property <tt>nfs</tt>.
     * 
     * @param nfs
     *            value to be assigned to property nfs
     */
    public void setNfs(boolean nfs) {
        this.nfs = nfs;
    }

    /**
     * Getter method for property <tt>multiProtocol</tt>.
     * 
     * @return property value of multiProtocol
     */
    public boolean isMultiProtocol() {
        return multiProtocol;
    }

    /**
     * Setter method for property <tt>multiProtocol</tt>.
     * 
     * @param multiProtocol
     *            value to be assigned to property multiProtocol
     */
    public void setMultiProtocol(boolean multiProtocol) {
        this.multiProtocol = multiProtocol;
    }

    /**
     * Getter method for property <tt>cifsDataAmount</tt>.
     * 
     * @return property value of cifsDataAmount
     */
    public Integer getCifsDataAmount() {
        return cifsDataAmount;
    }

    /**
     * Setter method for property <tt>cifsDataAmount</tt>.
     * 
     * @param cifsDataAmount
     *            value to be assigned to property cifsDataAmount
     */
    public void setCifsDataAmount(Integer cifsDataAmount) {
        this.cifsDataAmount = cifsDataAmount;
    }

    /**
     * Getter method for property <tt>includeLocalUsersGroups</tt>.
     * 
     * @return property value of includeLocalUsersGroups
     */
    public Boolean getIncludeLocalUsersGroups() {
        return includeLocalUsersGroups;
    }

    /**
     * Setter method for property <tt>includeLocalUsersGroups</tt>.
     * 
     * @param includeLocalUsersGroups
     *            value to be assigned to property includeLocalUsersGroups
     */
    public void setIncludeLocalUsersGroups(Boolean includeLocalUsersGroups) {
        this.includeLocalUsersGroups = includeLocalUsersGroups;
    }

    /**
     * Getter method for property <tt>nfsDataAmount</tt>.
     * 
     * @return property value of nfsDataAmount
     */
    public Integer getNfsDataAmount() {
        return nfsDataAmount;
    }

    /**
     * Setter method for property <tt>nfsDataAmount</tt>.
     * 
     * @param nfsDataAmount
     *            value to be assigned to property nfsDataAmount
     */
    public void setNfsDataAmount(Integer nfsDataAmount) {
        this.nfsDataAmount = nfsDataAmount;
    }

    /**
     * Getter method for property <tt>multiProtocolDataAmount</tt>.
     * 
     * @return property value of multiProtocolDataAmount
     */
    public Integer getMultiProtocolDataAmount() {
        return multiProtocolDataAmount;
    }

    /**
     * Setter method for property <tt>multiProtocolDataAmount</tt>.
     * 
     * @param multiProtocolDataAmount
     *            value to be assigned to property multiProtocolDataAmount
     */
    public void setMultiProtocolDataAmount(Integer multiProtocolDataAmount) {
        this.multiProtocolDataAmount = multiProtocolDataAmount;
    }

    /**
     * Getter method for property <tt>averageDuration</tt>.
     * 
     * @return property value of averageDuration
     */
    public BigDecimal getAverageDuration() {
        return averageDuration;
    }

    /**
     * Setter method for property <tt>averageDuration</tt>.
     * 
     * @param averageDuration
     *            value to be assigned to property averageDuration
     */
    public void setAverageDuration(BigDecimal averageDuration) {
        this.averageDuration = averageDuration;
    }

    /**
     * Getter method for property <tt>dataMigEventsNum</tt>.
     * 
     * @return property value of dataMigEventsNum
     */
    public Integer getDataMigEventsNum() {
        return dataMigEventsNum;
    }

    /**
     * Setter method for property <tt>dataMigEventsNum</tt>.
     * 
     * @param dataMigEventsNum
     *            value to be assigned to property dataMigEventsNum
     */
    public void setDataMigEventsNum(Integer dataMigEventsNum) {
        this.dataMigEventsNum = dataMigEventsNum;
    }

    /**
     * Getter method for property <tt>monitorWeeksNum</tt>.
     * 
     * @return property value of monitorWeeksNum
     */
    public Integer getMonitorWeeksNum() {
        return monitorWeeksNum;
    }

    /**
     * Setter method for property <tt>monitorWeeksNum</tt>.
     * 
     * @param monitorWeeksNum
     *            value to be assigned to property monitorWeeksNum
     */
    public void setMonitorWeeksNum(Integer monitorWeeksNum) {
        this.monitorWeeksNum = monitorWeeksNum;
    }

    /**
     * Getter method for property <tt>cutoverEventsNum</tt>.
     * 
     * @return property value of cutoverEventsNum
     */
    public Integer getCutoverEventsNum() {
        return cutoverEventsNum;
    }

    /**
     * Setter method for property <tt>cutoverEventsNum</tt>.
     * 
     * @param cutoverEventsNum
     *            value to be assigned to property cutoverEventsNum
     */
    public void setCutoverEventsNum(Integer cutoverEventsNum) {
        this.cutoverEventsNum = cutoverEventsNum;
    }

    /**
     * Getter method for property <tt>smartPoolsEnabled</tt>.
     * 
     * @return property value of smartPoolsEnabled
     */
    public Boolean getSmartPoolsEnabled() {
        return smartPoolsEnabled;
    }

    /**
     * Setter method for property <tt>smartPoolsEnabled</tt>.
     * 
     * @param smartPoolsEnabled
     *            value to be assigned to property smartPoolsEnabled
     */
    public void setSmartPoolsEnabled(Boolean smartPoolsEnabled) {
        this.smartPoolsEnabled = smartPoolsEnabled;
    }

    /**
     * Getter method for property <tt>removeNodesNum</tt>.
     * 
     * @return property value of removeNodesNum
     */
    public Integer getRemoveNodesNum() {
        return removeNodesNum;
    }

    /**
     * Setter method for property <tt>removeNodesNum</tt>.
     * 
     * @param removeNodesNum
     *            value to be assigned to property removeNodesNum
     */
    public void setRemoveNodesNum(Integer removeNodesNum) {
        this.removeNodesNum = removeNodesNum;
    }

    /**
     * Getter method for property <tt>requiredEventsNum</tt>.
     * 
     * @return property value of requiredEventsNum
     */
    public Integer getRequiredEventsNum() {
        return requiredEventsNum;
    }

    /**
     * Setter method for property <tt>requiredEventsNum</tt>.
     * 
     * @param requiredEventsNum
     *            value to be assigned to property requiredEventsNum
     */
    public void setRequiredEventsNum(Integer requiredEventsNum) {
        this.requiredEventsNum = requiredEventsNum;
    }

    /**
     * Getter method for property <tt>techRefreshMovedData</tt>.
     * 
     * @return property value of techRefreshMovedData
     */
    public Integer getTechRefreshMovedData() {
        return techRefreshMovedData;
    }

    /**
     * Setter method for property <tt>techRefreshMovedData</tt>.
     * 
     * @param techRefreshMovedData
     *            value to be assigned to property techRefreshMovedData
     */
    public void setTechRefreshMovedData(Integer techRefreshMovedData) {
        this.techRefreshMovedData = techRefreshMovedData;
    }

}

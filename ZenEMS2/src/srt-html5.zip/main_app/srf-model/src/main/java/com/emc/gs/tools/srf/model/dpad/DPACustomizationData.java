/*
 * This code is copyright (c) 2014 EMC Corporation
 */
package com.emc.gs.tools.srf.model.dpad;

/**
 * <p>
 * This is DPACustomizationData entity class.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safety.
 * </p>
 * 
 * @author TCSASSEMBLER
 * @version 1.0
 * @since SRT Phase 3-5 - BRS Tabs Part 2 Assembly
 */
public class DPACustomizationData {

    /**
     * Include Requirements Workshop.
     */
    private Boolean includeRequirementsWorkshop;

    /**
     * Include Data Protection Advisor Scale Plan.
     */
    private Boolean includeScalePlan;

    /**
     * # of Data Protection Advisor Collection Nodes.
     */
    private Integer collectionNodesNum;

    /**
     * # of Data Protection Collector Nodes to Configure.
     */
    private Integer collectorNodesNum;

    /**
     * <p>
     * The default constructor.
     * </p>
     */
    public DPACustomizationData() {
    }

    /**
     * Getter method for property <tt>includeRequirementsWorkshop</tt>.
     * 
     * @return property value of includeRequirementsWorkshop
     */
    public Boolean getIncludeRequirementsWorkshop() {
        return includeRequirementsWorkshop;
    }

    /**
     * Setter method for property <tt>includeRequirementsWorkshop</tt>.
     * 
     * @param includeRequirementsWorkshop
     *            value to be assigned to property includeRequirementsWorkshop
     */
    public void setIncludeRequirementsWorkshop(Boolean includeRequirementsWorkshop) {
        this.includeRequirementsWorkshop = includeRequirementsWorkshop;
    }

    /**
     * Getter method for property <tt>includeScalePlan</tt>.
     * 
     * @return property value of includeScalePlan
     */
    public Boolean getIncludeScalePlan() {
        return includeScalePlan;
    }

    /**
     * Setter method for property <tt>includeScalePlan</tt>.
     * 
     * @param includeScalePlan
     *            value to be assigned to property includeScalePlan
     */
    public void setIncludeScalePlan(Boolean includeScalePlan) {
        this.includeScalePlan = includeScalePlan;
    }

    /**
     * Getter method for property <tt>collectionNodesNum</tt>.
     * 
     * @return property value of collectionNodesNum
     */
    public Integer getCollectionNodesNum() {
        return collectionNodesNum;
    }

    /**
     * Setter method for property <tt>collectionNodesNum</tt>.
     * 
     * @param collectionNodesNum
     *            value to be assigned to property collectionNodesNum
     */
    public void setCollectionNodesNum(Integer collectionNodesNum) {
        this.collectionNodesNum = collectionNodesNum;
    }

    /**
     * Getter method for property <tt>collectorNodesNum</tt>.
     * 
     * @return property value of collectorNodesNum
     */
    public Integer getCollectorNodesNum() {
        return collectorNodesNum;
    }

    /**
     * Setter method for property <tt>collectorNodesNum</tt>.
     * 
     * @param collectorNodesNum
     *            value to be assigned to property collectorNodesNum
     */
    public void setCollectorNodesNum(Integer collectorNodesNum) {
        this.collectorNodesNum = collectorNodesNum;
    }

}

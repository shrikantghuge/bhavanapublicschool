/*
 * This code is copyright (c) 2014 EMC Corporation
 */
package com.emc.gs.tools.srf.model.cta;

import com.emc.gs.tools.srf.model.IdentifiableEntity;

/**
 * <p>
 * This is NASDestination entity class.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safety.
 * </p>
 * 
 * @author TCSASSEMBLER
 * @version 1.0
 * @since SRT Phase 3-1 - CTA Rainfinity and MSS Tabs Update Assembly
 */
public class NASDestination extends IdentifiableEntity {

    /**
     * Celerra.
     */
    private boolean celerra;

    /**
     * VNX.
     */
    private boolean vnx;

    /**
     * VNXe.
     */
    private boolean vnxe;

    /**
     * Network Appliance.
     */
    private boolean networkAppliance;

    /**
     * Centera.
     */
    private boolean centera;

    /**
     * Windows.
     */
    private boolean windows;

    /**
     * Atmos.
     */
    private boolean atmos;

    /**
     * Data Domain.
     */
    private boolean dataDomain;

    /**
     * <p>
     * The default constructor.
     * </p>
     */
    public NASDestination() {
    }

    /**
     * Getter method for property <tt>celerra</tt>.
     * 
     * @return property value of celerra
     */
    public boolean isCelerra() {
        return celerra;
    }

    /**
     * Setter method for property <tt>celerra</tt>.
     * 
     * @param celerra
     *            value to be assigned to property celerra
     */
    public void setCelerra(boolean celerra) {
        this.celerra = celerra;
    }

    /**
     * Getter method for property <tt>vnx</tt>.
     * 
     * @return property value of vnx
     */
    public boolean isVnx() {
        return vnx;
    }

    /**
     * Setter method for property <tt>vnx</tt>.
     * 
     * @param vnx
     *            value to be assigned to property vnx
     */
    public void setVnx(boolean vnx) {
        this.vnx = vnx;
    }

    /**
     * Getter method for property <tt>vnxe</tt>.
     * 
     * @return property value of vnxe
     */
    public boolean isVnxe() {
        return vnxe;
    }

    /**
     * Setter method for property <tt>vnxe</tt>.
     * 
     * @param vnxe
     *            value to be assigned to property vnxe
     */
    public void setVnxe(boolean vnxe) {
        this.vnxe = vnxe;
    }

    /**
     * Getter method for property <tt>networkAppliance</tt>.
     * 
     * @return property value of networkAppliance
     */
    public boolean isNetworkAppliance() {
        return networkAppliance;
    }

    /**
     * Setter method for property <tt>networkAppliance</tt>.
     * 
     * @param networkAppliance
     *            value to be assigned to property networkAppliance
     */
    public void setNetworkAppliance(boolean networkAppliance) {
        this.networkAppliance = networkAppliance;
    }

    /**
     * Getter method for property <tt>centera</tt>.
     * 
     * @return property value of centera
     */
    public boolean isCentera() {
        return centera;
    }

    /**
     * Setter method for property <tt>centera</tt>.
     * 
     * @param centera
     *            value to be assigned to property centera
     */
    public void setCentera(boolean centera) {
        this.centera = centera;
    }

    /**
     * Getter method for property <tt>windows</tt>.
     * 
     * @return property value of windows
     */
    public boolean isWindows() {
        return windows;
    }

    /**
     * Setter method for property <tt>windows</tt>.
     * 
     * @param windows
     *            value to be assigned to property windows
     */
    public void setWindows(boolean windows) {
        this.windows = windows;
    }

    /**
     * Getter method for property <tt>atmos</tt>.
     * 
     * @return property value of atmos
     */
    public boolean isAtmos() {
        return atmos;
    }

    /**
     * Setter method for property <tt>atmos</tt>.
     * 
     * @param atmos
     *            value to be assigned to property atmos
     */
    public void setAtmos(boolean atmos) {
        this.atmos = atmos;
    }

    /**
     * Getter method for property <tt>dataDomain</tt>.
     * 
     * @return property value of dataDomain
     */
    public boolean isDataDomain() {
        return dataDomain;
    }

    /**
     * Setter method for property <tt>dataDomain</tt>.
     * 
     * @param dataDomain
     *            value to be assigned to property dataDomain
     */
    public void setDataDomain(boolean dataDomain) {
        this.dataDomain = dataDomain;
    }

}

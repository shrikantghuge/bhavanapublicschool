/*
 * This code is copyright (c) 2013 - 2014 EMC Corporation.
 */
package com.emc.gs.tools.srf.model.infrastructure;

import com.emc.gs.tools.srf.model.IdentifiableEntity;

/**
 * <p>
 * This is VnxClariionInformation entity class.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safety.
 * </p>
 *
 * <p>
 * <strong>Changes:</strong>
 * <strong>SRT Release Assembly - Mainframe tab</strong>
 * <ul>
 * <li>removed mappingLunMaskingHostNumber</li>
 * </ul>
 * </p>
 * 
 * <p>
 * <strong>Changes V1.2:</strong>
 * <strong>SRT Bug Fixes</strong>
 * <ul>
 * <li>Removed cx3Cx4UpgradedNumber</li>
 * </ul>
 * </p>
 * 
 * <p>
 * <strong>Changes V1.3:</strong>
 * <strong>SRT Bug Fixes - F121, F153, F154, F162</strong>
 * <ul>
 * <li>Add knowledgeTransferHours field.</li>
 * </ul>
 * </p>
 * 
 * <p>
 * <strong>Changes V1.4:</strong>
 * <ul>
 * <li>Removed mirrowViewHostsNumber, mirrowViewAHostsNumber, sanCopyHostsNumber, cxCloneHostsNumber, 
 * cxSnapHostsNumber fields.</li>
 * </ul>
 * </p>
 * 
 * @author faeton, stevenfrog, TCSASSEMBLER, MonicaMuranyi
 * @version 1.4
 */
public class VnxClariionInformation extends IdentifiableEntity {
    
    /**
     * <p>
     * The knowledgeTransferHours.
     * </p>
     */
    private String knowledgeTransferHours;
    
    /**
     * <p>
     * The fastCacheSetupNumber.
     * </p>
     */
    private Integer fastCacheSetupNumber;
    /**
     * <p>
     * The virtualProvisioningArraysNumber.
     * </p>
     */
    private Integer virtualProvisioningArraysNumber;

    /**
     * <p>
     * The flashStorageLayoutServices.
     * </p>
     */
    private FlashStorageLayoutServices flashStorageLayoutServices;
    /**
     * <p>
     * The vnxArraysNumber.
     * </p>
     */
    private Integer vnxArraysNumber;

    /**
     * <p>
     * The unisphereDomainsNumber.
     * </p>
     */
    private Integer unisphereDomainsNumber;

    /**
     * <p>
     * The certifiedDiskErasureArraysNumber.
     * </p>
     */
    private Integer certifiedDiskErasureArraysNumber;

    /**
     * <p>
     * The deinstallCxNsVnxNumber.
     * </p>
     */
    private Integer deinstallCxNsVnxNumber;

    /**
     * <p>
     * The unifiedConversionsRequired.
     * </p>
     */
    private boolean unifiedConversionsRequired;

    /**
     * <p>
     * The unifiedConversionType.
     * </p>
     */
    private UnifiedConversionType unifiedConversionType;

    /**
     * <p>
     * The healthCheckRequired.
     * </p>
     */
    private boolean healthCheckRequired;

    /**
     * <p>
     * The sapHanaRequired.
     * </p>
     */
    private boolean sapHanaRequired;

    /**
     * <p>
     * The vnxInstallProtocolType.
     * </p>
     */
    private VnxInstallProtocolType vnxInstallProtocolType;

    /**
     * <p>
     * The vnxMonitoringReportingRequired.
     * </p>
     */
    private boolean vnxMonitoringReportingRequired;

    /**
     * <p>
     * The fcStorageConnectivityRequired.
     * </p>
     */
    private boolean fcStorageConnectivityRequired;

    /**
     * <p>
     * The fcoeStorageConnectivityRequired.
     * </p>
     */
    private boolean fcoeStorageConnectivityRequired;

    /**
     * <p>
     * The iscsiSanExtensionStorageConnectivityRequired.
     * </p>
     */
    private boolean iscsiSanExtensionStorageConnectivityRequired;

    /**
     * <p>
     * The vsanLsanStorageConnectivityRequired.
     * </p>
     */
    private boolean vsanLsanStorageConnectivityRequired;

    /**
     * <p>
     * The fcRoutingStorageConnectivityRequired.
     * </p>
     */
    private boolean fcRoutingStorageConnectivityRequired;

    /**
     * <p>
     * The virtualInfrastructureEnablementIncluded.
     * </p>
     */
    private boolean virtualInfrastructureEnablementIncluded;

    /**
     * <p>
     * The watch4NetIncluded.
     * </p>
     */
    private boolean watch4NetIncluded;

    /**
     * <p>
     * The unifiedLocalProtection.
     * </p>
     */
    private boolean unifiedLocalProtection;

    /**
     * <p>
     * The unifiedRemoteProtection.
     * </p>
     */
    private boolean unifiedRemoteProtection;

    /**
     * <p>
     * The unifiedApplicationProtection.
     * </p>
     */
    private boolean unifiedApplicationProtection;

    /**
     * <p>
     * The unifiedFastDeployment.
     * </p>
     */
    private boolean unifiedFastDeployment;

    /**
     * <p>
     * The unifiedSecurityCompliance.
     * </p>
     */
    private boolean unifiedSecurityCompliance;

    /**
     * <p>
     * The unifiedManagementSuite.
     * </p>
     */
    private boolean unifiedManagementSuite;

    /**
     * <p>
     * The dataProtectionAdvisor.
     * </p>
     */
    private boolean dataProtectionAdvisor;

    /**
     * <p>
     * The fastLunMigrator.
     * </p>
     */
    private boolean fastLunMigrator;

    /**
     * <p>
     * The mirrorView.
     * </p>
     */
    private boolean mirrorView;

    /**
     * <p>
     * The qosManager.
     * </p>
     */
    private boolean qosManager;

    /**
     * <p>
     * The replicationManager.
     * </p>
     */
    private boolean replicationManager;

    /**
     * <p>
     * The recoverPoint.
     * </p>
     */
    private boolean recoverPoint;

    /**
     * <p>
     * The sanCopy.
     * </p>
     */
    private boolean sanCopy;

    /**
     * <p>
     * The snapViewVnxSnapShots.
     * </p>
     */
    private boolean snapViewVnxSnapShots;

    /**
     * <p>
     * The virtualProvisioning.
     * </p>
     */
    private boolean virtualProvisioning;

    /**
     * <p>
     * The unisphereAnalyzer.
     * </p>
     */
    private boolean unisphereAnalyzer;

    /**
     * <p>
     * The unisphereRemote.
     * </p>
     */
    private boolean unisphereRemote;

    /**
     * <p>
     * The storageAnalytics.
     * </p>
     */
    private boolean storageAnalytics;

    /**
     * <p>
     * The unifiedFileOERequired.
     * </p>
     */
    private boolean unifiedFileOERequired;

    /**
     * <p>
     * The dialHomeActivities.
     * </p>
     */
    private boolean dialHomeActivities;

    /**
     * <p>
     * The vnxFileServersNumber.
     * </p>
     */
    private Integer vnxFileServersNumber;

    /**
     * <p>
     * The totalStorageAmount.
     * </p>
     */
    private Double totalStorageAmount;

    /**
     * <p>
     * The activeDataMoversNumber.
     * </p>
     */
    private Integer activeDataMoversNumber;

    /**
     * <p>
     * The controlStationsNumber.
     * </p>
     */
    private Integer controlStationsNumber;

    /**
     * <p>
     * The fileSystemsNumber.
     * </p>
     */
    private Integer fileSystemsNumber;

    /**
     * <p>
     * The avgFileSystemSize.
     * </p>
     */
    private String avgFileSystemSize;

    /**
     * <p>
     * The storagePoolsNumber.
     * </p>
     */
    private Integer storagePoolsNumber;

    /**
     * <p>
     * The thinLunsNumber.
     * </p>
     */
    private Integer thinLunsNumber;

    /**
     * <p>
     * The storageGroupsNumber.
     * </p>
     */
    private Integer storageGroupsNumber;

    /**
     * <p>
     * The iscsi.
     * </p>
     */
    private boolean iscsi;

    /**
     * <p>
     * The iScsiRequired.
     * </p>
     */
    private Boolean iScsiRequired;

    /**
     * <p>
     * The iScsiHostQuantity.
     * </p>
     */
    private Integer iScsiHostQuantity;

    /**
     * <p>
     * The iVnxScsiHostQuantity.
     * </p>
     */
    private Integer iVnxScsiHostQuantity;

    /**
     * <p>
     * The iDartScsiHostQuantity.
     * </p>
     */
    private Integer iDartScsiHostQuantity;

    /**
     * <p>
     * The default constructor.
     * </p>
     */
    public VnxClariionInformation() {
        // Empty
    }
    
    /**
     * <p>
     * Retrieves the knowledgeTransferHours field.
     * </p>
     *
     * @return the knowledgeTransferHours
     */
    public String getKnowledgeTransferHours() {
        return knowledgeTransferHours;
    }

    /**
     * <p>
     * Sets the value to knowledgeTransferHours field.
     * </p>
     *
     * @param knowledgeTransferHours
     *            the knowledgeTransferHours to set
     */
    public void setKnowledgeTransferHours(String knowledgeTransferHours) {
        this.knowledgeTransferHours = knowledgeTransferHours;
    }

    /**
     * <p>
     * Retrieves the vnxArraysNumber field.
     * </p>
     *
     * @return the vnxArraysNumber
     */
    public Integer getVnxArraysNumber() {
        return vnxArraysNumber;
    }

    /**
     * <p>
     * Sets the value to vnxArraysNumber field.
     * </p>
     *
     * @param vnxArraysNumber
     *            the vnxArraysNumber to set
     */
    public void setVnxArraysNumber(Integer vnxArraysNumber) {
        this.vnxArraysNumber = vnxArraysNumber;
    }

    /**
     * <p>
     * Retrieves the unisphereDomainsNumber field.
     * </p>
     *
     * @return the unisphereDomainsNumber
     */
    public Integer getUnisphereDomainsNumber() {
        return unisphereDomainsNumber;
    }

    /**
     * <p>
     * Sets the value to unisphereDomainsNumber field.
     * </p>
     *
     * @param unisphereDomainsNumber
     *            the unisphereDomainsNumber to set
     */
    public void setUnisphereDomainsNumber(Integer unisphereDomainsNumber) {
        this.unisphereDomainsNumber = unisphereDomainsNumber;
    }


    /**
     * <p>
     * Retrieves the certifiedDiskErasureArraysNumber field.
     * </p>
     *
     * @return the certifiedDiskErasureArraysNumber
     */
    public Integer getCertifiedDiskErasureArraysNumber() {
        return certifiedDiskErasureArraysNumber;
    }

    /**
     * <p>
     * Sets the value to certifiedDiskErasureArraysNumber field.
     * </p>
     *
     * @param certifiedDiskErasureArraysNumber
     *            the certifiedDiskErasureArraysNumber to set
     */
    public void setCertifiedDiskErasureArraysNumber(Integer certifiedDiskErasureArraysNumber) {
        this.certifiedDiskErasureArraysNumber = certifiedDiskErasureArraysNumber;
    }

    /**
     * <p>
     * Retrieves the deinstallCxNsVnxNumber field.
     * </p>
     *
     * @return the deinstallCxNsVnxNumber
     */
    public Integer getDeinstallCxNsVnxNumber() {
        return deinstallCxNsVnxNumber;
    }

    /**
     * <p>
     * Sets the value to deinstallCxNsVnxNumber field.
     * </p>
     *
     * @param deinstallCxNsVnxNumber
     *            the deinstallCxNsVnxNumber to set
     */
    public void setDeinstallCxNsVnxNumber(Integer deinstallCxNsVnxNumber) {
        this.deinstallCxNsVnxNumber = deinstallCxNsVnxNumber;
    }

    /**
     * <p>
     * Retrieves the unifiedConversionsRequired field.
     * </p>
     *
     * @return the unifiedConversionsRequired
     */
    public boolean isUnifiedConversionsRequired() {
        return unifiedConversionsRequired;
    }

    /**
     * <p>
     * Sets the value to unifiedConversionsRequired field.
     * </p>
     *
     * @param unifiedConversionsRequired
     *            the unifiedConversionsRequired to set
     */
    public void setUnifiedConversionsRequired(boolean unifiedConversionsRequired) {
        this.unifiedConversionsRequired = unifiedConversionsRequired;
    }

    /**
     * <p>
     * Retrieves the unifiedConversionType field.
     * </p>
     *
     * @return the unifiedConversionType
     */
    public UnifiedConversionType getUnifiedConversionType() {
        return unifiedConversionType;
    }

    /**
     * <p>
     * Sets the value to unifiedConversionType field.
     * </p>
     *
     * @param unifiedConversionType
     *            the unifiedConversionType to set
     */
    public void setUnifiedConversionType(UnifiedConversionType unifiedConversionType) {
        this.unifiedConversionType = unifiedConversionType;
    }

    /**
     * <p>
     * Retrieves the healthCheckRequired field.
     * </p>
     *
     * @return the healthCheckRequired
     */
    public boolean isHealthCheckRequired() {
        return healthCheckRequired;
    }

    /**
     * <p>
     * Sets the value to healthCheckRequired field.
     * </p>
     *
     * @param healthCheckRequired
     *            the healthCheckRequired to set
     */
    public void setHealthCheckRequired(boolean healthCheckRequired) {
        this.healthCheckRequired = healthCheckRequired;
    }

    /**
     * <p>
     * Retrieves the sapHanaRequired field.
     * </p>
     *
     * @return the sapHanaRequired
     */
    public boolean isSapHanaRequired() {
        return sapHanaRequired;
    }

    /**
     * <p>
     * Sets the value to sapHanaRequired field.
     * </p>
     *
     * @param sapHanaRequired
     *            the sapHanaRequired to set
     */
    public void setSapHanaRequired(boolean sapHanaRequired) {
        this.sapHanaRequired = sapHanaRequired;
    }

    /**
     * <p>
     * Retrieves the vnxInstallProtocolType field.
     * </p>
     *
     * @return the vnxInstallProtocolType
     */
    public VnxInstallProtocolType getVnxInstallProtocolType() {
        return vnxInstallProtocolType;
    }

    /**
     * <p>
     * Sets the value to vnxInstallProtocolType field.
     * </p>
     *
     * @param vnxInstallProtocolType
     *            the vnxInstallProtocolType to set
     */
    public void setVnxInstallProtocolType(VnxInstallProtocolType vnxInstallProtocolType) {
        this.vnxInstallProtocolType = vnxInstallProtocolType;
    }

    /**
     * <p>
     * Retrieves the vnxMonitoringReportingRequired field.
     * </p>
     *
     * @return the vnxMonitoringReportingRequired
     */
    public boolean isVnxMonitoringReportingRequired() {
        return vnxMonitoringReportingRequired;
    }

    /**
     * <p>
     * Sets the value to vnxMonitoringReportingRequired field.
     * </p>
     *
     * @param vnxMonitoringReportingRequired
     *            the vnxMonitoringReportingRequired to set
     */
    public void setVnxMonitoringReportingRequired(boolean vnxMonitoringReportingRequired) {
        this.vnxMonitoringReportingRequired = vnxMonitoringReportingRequired;
    }

    /**
     * <p>
     * Retrieves the fcStorageConnectivityRequired field.
     * </p>
     *
     * @return the fcStorageConnectivityRequired
     */
    public boolean isFcStorageConnectivityRequired() {
        return fcStorageConnectivityRequired;
    }

    /**
     * <p>
     * Sets the value to fcStorageConnectivityRequired field.
     * </p>
     *
     * @param fcStorageConnectivityRequired
     *            the fcStorageConnectivityRequired to set
     */
    public void setFcStorageConnectivityRequired(boolean fcStorageConnectivityRequired) {
        this.fcStorageConnectivityRequired = fcStorageConnectivityRequired;
    }

    /**
     * <p>
     * Retrieves the fcoeStorageConnectivityRequired field.
     * </p>
     *
     * @return the fcoeStorageConnectivityRequired
     */
    public boolean isFcoeStorageConnectivityRequired() {
        return fcoeStorageConnectivityRequired;
    }

    /**
     * <p>
     * Sets the value to fcoeStorageConnectivityRequired field.
     * </p>
     *
     * @param fcoeStorageConnectivityRequired
     *            the fcoeStorageConnectivityRequired to set
     */
    public void setFcoeStorageConnectivityRequired(boolean fcoeStorageConnectivityRequired) {
        this.fcoeStorageConnectivityRequired = fcoeStorageConnectivityRequired;
    }

    /**
     * <p>
     * Retrieves the iscsiSanExtensionStorageConnectivityRequired field.
     * </p>
     *
     * @return the iscsiSanExtensionStorageConnectivityRequired
     */
    public boolean isIscsiSanExtensionStorageConnectivityRequired() {
        return iscsiSanExtensionStorageConnectivityRequired;
    }

    /**
     * <p>
     * Sets the value to iscsiSanExtensionStorageConnectivityRequired field.
     * </p>
     *
     * @param iscsiSanExtensionStorageConnectivityRequired
     *            the iscsiSanExtensionStorageConnectivityRequired to set
     */
    public void setIscsiSanExtensionStorageConnectivityRequired(boolean iscsiSanExtensionStorageConnectivityRequired) {
        this.iscsiSanExtensionStorageConnectivityRequired = iscsiSanExtensionStorageConnectivityRequired;
    }

    /**
     * <p>
     * Retrieves the vsanLsanStorageConnectivityRequired field.
     * </p>
     *
     * @return the vsanLsanStorageConnectivityRequired
     */
    public boolean isVsanLsanStorageConnectivityRequired() {
        return vsanLsanStorageConnectivityRequired;
    }

    /**
     * <p>
     * Sets the value to vsanLsanStorageConnectivityRequired field.
     * </p>
     *
     * @param vsanLsanStorageConnectivityRequired
     *            the vsanLsanStorageConnectivityRequired to set
     */
    public void setVsanLsanStorageConnectivityRequired(boolean vsanLsanStorageConnectivityRequired) {
        this.vsanLsanStorageConnectivityRequired = vsanLsanStorageConnectivityRequired;
    }

    /**
     * <p>
     * Retrieves the fcRoutingStorageConnectivityRequired field.
     * </p>
     *
     * @return the fcRoutingStorageConnectivityRequired
     */
    public boolean isFcRoutingStorageConnectivityRequired() {
        return fcRoutingStorageConnectivityRequired;
    }

    /**
     * <p>
     * Sets the value to fcRoutingStorageConnectivityRequired field.
     * </p>
     *
     * @param fcRoutingStorageConnectivityRequired
     *            the fcRoutingStorageConnectivityRequired to set
     */
    public void setFcRoutingStorageConnectivityRequired(boolean fcRoutingStorageConnectivityRequired) {
        this.fcRoutingStorageConnectivityRequired = fcRoutingStorageConnectivityRequired;
    }

    /**
     * <p>
     * Retrieves the virtualInfrastructureEnablementIncluded field.
     * </p>
     *
     * @return the virtualInfrastructureEnablementIncluded
     */
    public boolean isVirtualInfrastructureEnablementIncluded() {
        return virtualInfrastructureEnablementIncluded;
    }

    /**
     * <p>
     * Sets the value to virtualInfrastructureEnablementIncluded field.
     * </p>
     *
     * @param virtualInfrastructureEnablementIncluded
     *            the virtualInfrastructureEnablementIncluded to set
     */
    public void setVirtualInfrastructureEnablementIncluded(boolean virtualInfrastructureEnablementIncluded) {
        this.virtualInfrastructureEnablementIncluded = virtualInfrastructureEnablementIncluded;
    }

    /**
     * <p>
     * Retrieves the watch4NetIncluded field.
     * </p>
     *
     * @return the watch4NetIncluded
     */
    public boolean isWatch4NetIncluded() {
        return watch4NetIncluded;
    }

    /**
     * <p>
     * Sets the value to watch4NetIncluded field.
     * </p>
     *
     * @param watch4NetIncluded
     *            the watch4NetIncluded to set
     */
    public void setWatch4NetIncluded(boolean watch4NetIncluded) {
        this.watch4NetIncluded = watch4NetIncluded;
    }

    /**
     * <p>
     * Retrieves the unifiedLocalProtection field.
     * </p>
     *
     * @return the unifiedLocalProtection
     */
    public boolean isUnifiedLocalProtection() {
        return unifiedLocalProtection;
    }

    /**
     * <p>
     * Sets the value to unifiedLocalProtection field.
     * </p>
     *
     * @param unifiedLocalProtection
     *            the unifiedLocalProtection to set
     */
    public void setUnifiedLocalProtection(boolean unifiedLocalProtection) {
        this.unifiedLocalProtection = unifiedLocalProtection;
    }

    /**
     * <p>
     * Retrieves the unifiedRemoteProtection field.
     * </p>
     *
     * @return the unifiedRemoteProtection
     */
    public boolean isUnifiedRemoteProtection() {
        return unifiedRemoteProtection;
    }

    /**
     * <p>
     * Sets the value to unifiedRemoteProtection field.
     * </p>
     *
     * @param unifiedRemoteProtection
     *            the unifiedRemoteProtection to set
     */
    public void setUnifiedRemoteProtection(boolean unifiedRemoteProtection) {
        this.unifiedRemoteProtection = unifiedRemoteProtection;
    }

    /**
     * <p>
     * Retrieves the unifiedApplicationProtection field.
     * </p>
     *
     * @return the unifiedApplicationProtection
     */
    public boolean isUnifiedApplicationProtection() {
        return unifiedApplicationProtection;
    }

    /**
     * <p>
     * Sets the value to unifiedApplicationProtection field.
     * </p>
     *
     * @param unifiedApplicationProtection
     *            the unifiedApplicationProtection to set
     */
    public void setUnifiedApplicationProtection(boolean unifiedApplicationProtection) {
        this.unifiedApplicationProtection = unifiedApplicationProtection;
    }

    /**
     * <p>
     * Retrieves the unifiedFastDeployment field.
     * </p>
     *
     * @return the unifiedFastDeployment
     */
    public boolean isUnifiedFastDeployment() {
        return unifiedFastDeployment;
    }

    /**
     * <p>
     * Sets the value to unifiedFastDeployment field.
     * </p>
     *
     * @param unifiedFastDeployment
     *            the unifiedFastDeployment to set
     */
    public void setUnifiedFastDeployment(boolean unifiedFastDeployment) {
        this.unifiedFastDeployment = unifiedFastDeployment;
    }

    /**
     * <p>
     * Retrieves the unifiedSecurityCompliance field.
     * </p>
     *
     * @return the unifiedSecurityCompliance
     */
    public boolean isUnifiedSecurityCompliance() {
        return unifiedSecurityCompliance;
    }

    /**
     * <p>
     * Sets the value to unifiedSecurityCompliance field.
     * </p>
     *
     * @param unifiedSecurityCompliance
     *            the unifiedSecurityCompliance to set
     */
    public void setUnifiedSecurityCompliance(boolean unifiedSecurityCompliance) {
        this.unifiedSecurityCompliance = unifiedSecurityCompliance;
    }

    /**
     * <p>
     * Retrieves the unifiedManagementSuite field.
     * </p>
     *
     * @return the unifiedManagementSuite
     */
    public boolean isUnifiedManagementSuite() {
        return unifiedManagementSuite;
    }

    /**
     * <p>
     * Sets the value to unifiedManagementSuite field.
     * </p>
     *
     * @param unifiedManagementSuite
     *            the unifiedManagementSuite to set
     */
    public void setUnifiedManagementSuite(boolean unifiedManagementSuite) {
        this.unifiedManagementSuite = unifiedManagementSuite;
    }

    /**
     * <p>
     * Retrieves the dataProtectionAdvisor field.
     * </p>
     *
     * @return the dataProtectionAdvisor
     */
    public boolean isDataProtectionAdvisor() {
        return dataProtectionAdvisor;
    }

    /**
     * <p>
     * Sets the value to dataProtectionAdvisor field.
     * </p>
     *
     * @param dataProtectionAdvisor
     *            the dataProtectionAdvisor to set
     */
    public void setDataProtectionAdvisor(boolean dataProtectionAdvisor) {
        this.dataProtectionAdvisor = dataProtectionAdvisor;
    }

    /**
     * <p>
     * Retrieves the fastLunMigrator field.
     * </p>
     *
     * @return the fastLunMigrator
     */
    public boolean isFastLunMigrator() {
        return fastLunMigrator;
    }

    /**
     * <p>
     * Sets the value to fastLunMigrator field.
     * </p>
     *
     * @param fastLunMigrator
     *            the fastLunMigrator to set
     */
    public void setFastLunMigrator(boolean fastLunMigrator) {
        this.fastLunMigrator = fastLunMigrator;
    }

    /**
     * <p>
     * Retrieves the mirrorView field.
     * </p>
     *
     * @return the mirrorView
     */
    public boolean isMirrorView() {
        return mirrorView;
    }

    /**
     * <p>
     * Sets the value to mirrorView field.
     * </p>
     *
     * @param mirrorView
     *            the mirrorView to set
     */
    public void setMirrorView(boolean mirrorView) {
        this.mirrorView = mirrorView;
    }

    /**
     * <p>
     * Retrieves the qosManager field.
     * </p>
     *
     * @return the qosManager
     */
    public boolean isQosManager() {
        return qosManager;
    }

    /**
     * <p>
     * Sets the value to qosManager field.
     * </p>
     *
     * @param qosManager
     *            the qosManager to set
     */
    public void setQosManager(boolean qosManager) {
        this.qosManager = qosManager;
    }

    /**
     * <p>
     * Retrieves the replicationManager field.
     * </p>
     *
     * @return the replicationManager
     */
    public boolean isReplicationManager() {
        return replicationManager;
    }

    /**
     * <p>
     * Sets the value to replicationManager field.
     * </p>
     *
     * @param replicationManager
     *            the replicationManager to set
     */
    public void setReplicationManager(boolean replicationManager) {
        this.replicationManager = replicationManager;
    }

    /**
     * <p>
     * Retrieves the recoverPoint field.
     * </p>
     *
     * @return the recoverPoint
     */
    public boolean isRecoverPoint() {
        return recoverPoint;
    }

    /**
     * <p>
     * Sets the value to recoverPoint field.
     * </p>
     *
     * @param recoverPoint
     *            the recoverPoint to set
     */
    public void setRecoverPoint(boolean recoverPoint) {
        this.recoverPoint = recoverPoint;
    }

    /**
     * <p>
     * Retrieves the sanCopy field.
     * </p>
     *
     * @return the sanCopy
     */
    public boolean isSanCopy() {
        return sanCopy;
    }

    /**
     * <p>
     * Sets the value to sanCopy field.
     * </p>
     *
     * @param sanCopy
     *            the sanCopy to set
     */
    public void setSanCopy(boolean sanCopy) {
        this.sanCopy = sanCopy;
    }

    /**
     * <p>
     * Retrieves the snapViewVnxSnapShots field.
     * </p>
     *
     * @return the snapViewVnxSnapShots
     */
    public boolean isSnapViewVnxSnapShots() {
        return snapViewVnxSnapShots;
    }

    /**
     * <p>
     * Sets the value to snapViewVnxSnapShots field.
     * </p>
     *
     * @param snapViewVnxSnapShots
     *            the snapViewVnxSnapShots to set
     */
    public void setSnapViewVnxSnapShots(boolean snapViewVnxSnapShots) {
        this.snapViewVnxSnapShots = snapViewVnxSnapShots;
    }

    /**
     * <p>
     * Retrieves the virtualProvisioning field.
     * </p>
     *
     * @return the virtualProvisioning
     */
    public boolean isVirtualProvisioning() {
        return virtualProvisioning;
    }

    /**
     * <p>
     * Sets the value to virtualProvisioning field.
     * </p>
     *
     * @param virtualProvisioning
     *            the virtualProvisioning to set
     */
    public void setVirtualProvisioning(boolean virtualProvisioning) {
        this.virtualProvisioning = virtualProvisioning;
    }

    /**
     * <p>
     * Retrieves the storageAnalytics field.
     * </p>
     *
     * @return the storageAnalytics
     */
    public boolean isStorageAnalytics() {
        return storageAnalytics;
    }

    /**
     * <p>
     * Sets the value to storageAnalytics field.
     * </p>
     *
     * @param storageAnalytics
     *            the storageAnalytics to set
     */
    public void setStorageAnalytics(boolean storageAnalytics) {
        this.storageAnalytics = storageAnalytics;
    }

    /**
     * <p>
     * Retrieves the unifiedFileOERequired field.
     * </p>
     *
     * @return the unifiedFileOERequired
     */
    public boolean isUnifiedFileOERequired() {
        return unifiedFileOERequired;
    }

    /**
     * <p>
     * Sets the value to unifiedFileOERequired field.
     * </p>
     *
     * @param unifiedFileOERequired
     *            the unifiedFileOERequired to set
     */
    public void setUnifiedFileOERequired(boolean unifiedFileOERequired) {
        this.unifiedFileOERequired = unifiedFileOERequired;
    }

    /**
     * <p>
     * Retrieves the dialHomeActivities field.
     * </p>
     *
     * @return the dialHomeActivities
     */
    public boolean isDialHomeActivities() {
        return dialHomeActivities;
    }

    /**
     * <p>
     * Sets the value to dialHomeActivities field.
     * </p>
     *
     * @param dialHomeActivities
     *            the dialHomeActivities to set
     */
    public void setDialHomeActivities(boolean dialHomeActivities) {
        this.dialHomeActivities = dialHomeActivities;
    }

    /**
     * <p>
     * Retrieves the fastCacheSetupNumber field.
     * </p>
     *
     * @return the value of fastCacheSetupNumber
     */
    public Integer getFastCacheSetupNumber() {
        return fastCacheSetupNumber;
    }

    /**
     * <p>
     * Sets the value to fastCacheSetupNumber field.
     * </p>
     *
     * @param fastCacheSetupNumber the value of fastCacheSetupNumber to set
     */
    public void setFastCacheSetupNumber(Integer fastCacheSetupNumber) {
        this.fastCacheSetupNumber = fastCacheSetupNumber;
    }

    /**
     * <p>
     * Retrieves the flashStorageLayoutServices field.
     * </p>
     *
     * @return the value of flashStorageLayoutServices
     */
    public FlashStorageLayoutServices getFlashStorageLayoutServices() {
        return flashStorageLayoutServices;
    }

    /**
     * <p>
     * Sets the value to flashStorageLayoutServices field.
     * </p>
     *
     * @param flashStorageLayoutServices the value of flashStorageLayoutServices to set
     */
    public void setFlashStorageLayoutServices(FlashStorageLayoutServices flashStorageLayoutServices) {
        this.flashStorageLayoutServices = flashStorageLayoutServices;
    }

    /**
     * <p>
     * Retrieves the virtualProvisioningArraysNumber field.
     * </p>
     *
     * @return the value of virtualProvisioningArraysNumber
     */
    public Integer getVirtualProvisioningArraysNumber() {
        return virtualProvisioningArraysNumber;
    }

    /**
     * <p>
     * Sets the value to virtualProvisioningArraysNumber field.
     * </p>
     *
     * @param virtualProvisioningArraysNumber the value of virtualProvisioningArraysNumber to set
     */
    public void setVirtualProvisioningArraysNumber(Integer virtualProvisioningArraysNumber) {
        this.virtualProvisioningArraysNumber = virtualProvisioningArraysNumber;
    }

    /**
     * Getter method for property <tt>unisphereAnalyzer</tt>.
     * @return property value of unisphereAnalyzer
     */
    public boolean isUnisphereAnalyzer() {
        return unisphereAnalyzer;
    }

    /**
     * Setter method for property <tt>unisphereAnalyzer</tt>.
     * @param unisphereAnalyzer value to be assigned to property unisphereAnalyzer
     */
    public void setUnisphereAnalyzer(boolean unisphereAnalyzer) {
        this.unisphereAnalyzer = unisphereAnalyzer;
    }

    /**
     * Getter method for property <tt>unisphereRemote</tt>.
     * @return property value of unisphereRemote
     */
    public boolean isUnisphereRemote() {
        return unisphereRemote;
    }

    /**
     * Setter method for property <tt>unisphereRemote</tt>.
     * @param unisphereRemote value to be assigned to property unisphereRemote
     */
    public void setUnisphereRemote(boolean unisphereRemote) {
        this.unisphereRemote = unisphereRemote;
    }

    /**
     * Getter method for property <tt>vnxFileServersNumber</tt>.
     * @return property value of vnxFileServersNumber
     */
    public Integer getVnxFileServersNumber() {
        return vnxFileServersNumber;
    }

    /**
     * Setter method for property <tt>vnxFileServersNumber</tt>.
     * @param vnxFileServersNumber
     *            value to be assigned to property vnxFileServersNumber
     */
    public void setVnxFileServersNumber(Integer vnxFileServersNumber) {
        this.vnxFileServersNumber = vnxFileServersNumber;
    }

    /**
     * Getter method for property <tt>totalStorageAmount</tt>.
     * @return property value of totalStorageAmount
     */
    public Double getTotalStorageAmount() {
        return totalStorageAmount;
    }

    /**
     * Setter method for property <tt>totalStorageAmount</tt>.
     * @param totalStorageAmount
     *            value to be assigned to property totalStorageAmount
     */
    public void setTotalStorageAmount(Double totalStorageAmount) {
        this.totalStorageAmount = totalStorageAmount;
    }

    /**
     * Getter method for property <tt>activeDataMoversNumber</tt>.
     * @return property value of activeDataMoversNumber
     */
    public Integer getActiveDataMoversNumber() {
        return activeDataMoversNumber;
    }

    /**
     * Setter method for property <tt>activeDataMoversNumber</tt>.
     * @param activeDataMoversNumber
     *            value to be assigned to property activeDataMoversNumber
     */
    public void setActiveDataMoversNumber(Integer activeDataMoversNumber) {
        this.activeDataMoversNumber = activeDataMoversNumber;
    }

    /**
     * Getter method for property <tt>controlStationsNumber</tt>.
     * @return property value of controlStationsNumber
     */
    public Integer getControlStationsNumber() {
        return controlStationsNumber;
    }

    /**
     * Setter method for property <tt>controlStationsNumber</tt>.
     * @param controlStationsNumber
     *            value to be assigned to property controlStationsNumber
     */
    public void setControlStationsNumber(Integer controlStationsNumber) {
        this.controlStationsNumber = controlStationsNumber;
    }

    /**
     * Getter method for property <tt>fileSystemsNumber</tt>.
     * @return property value of fileSystemsNumber
     */
    public Integer getFileSystemsNumber() {
        return fileSystemsNumber;
    }

    /**
     * Setter method for property <tt>fileSystemsNumber</tt>.
     * @param fileSystemsNumber
     *            value to be assigned to property fileSystemsNumber
     */
    public void setFileSystemsNumber(Integer fileSystemsNumber) {
        this.fileSystemsNumber = fileSystemsNumber;
    }

    /**
     * Getter method for property <tt>avgFileSystemSize</tt>.
     * @return property value of avgFileSystemSize
     */
    public String getAvgFileSystemSize() {
        return avgFileSystemSize;
    }

    /**
     * Setter method for property <tt>avgFileSystemSize</tt>.
     * @param avgFileSystemSize
     *            value to be assigned to property avgFileSystemSize
     */
    public void setAvgFileSystemSize(String avgFileSystemSize) {
        this.avgFileSystemSize = avgFileSystemSize;
    }

    /**
     * Getter method for property <tt>storagePoolsNumber</tt>.
     * @return property value of storagePoolsNumber
     */
    public Integer getStoragePoolsNumber() {
        return storagePoolsNumber;
    }

    /**
     * Setter method for property <tt>storagePoolsNumber</tt>.
     * @param storagePoolsNumber
     *            value to be assigned to property storagePoolsNumber
     */
    public void setStoragePoolsNumber(Integer storagePoolsNumber) {
        this.storagePoolsNumber = storagePoolsNumber;
    }

    /**
     * Getter method for property <tt>thinLunsNumber</tt>.
     * @return property value of thinLunsNumber
     */
    public Integer getThinLunsNumber() {
        return thinLunsNumber;
    }

    /**
     * Setter method for property <tt>thinLunsNumber</tt>.
     * @param thinLunsNumber
     *            value to be assigned to property thinLunsNumber
     */
    public void setThinLunsNumber(Integer thinLunsNumber) {
        this.thinLunsNumber = thinLunsNumber;
    }

    /**
     * Getter method for property <tt>storageGroupsNumber</tt>.
     * @return property value of storageGroupsNumber
     */
    public Integer getStorageGroupsNumber() {
        return storageGroupsNumber;
    }

    /**
     * Setter method for property <tt>storageGroupsNumber</tt>.
     * @param storageGroupsNumber
     *            value to be assigned to property storageGroupsNumber
     */
    public void setStorageGroupsNumber(Integer storageGroupsNumber) {
        this.storageGroupsNumber = storageGroupsNumber;
    }

    /**
     * Getter method for property <tt>iscsi</tt>.
     * @return property value of iscsi
     */
    public boolean isIscsi() {
        return iscsi;
    }

    /**
     * Setter method for property <tt>iscsi</tt>.
     * @param iscsi
     *            value to be assigned to property iscsi
     */
    public void setIscsi(boolean iscsi) {
        this.iscsi = iscsi;
    }

    /**
     * Getter method for property <tt>iScsiRequired</tt>.
     * @return property value of iScsiRequired
     */
    public Boolean getiScsiRequired() {
        return iScsiRequired;
    }

    /**
     * Setter method for property <tt>iScsiRequired</tt>.
     * @param iScsiRequired
     *            value to be assigned to property iScsiRequired
     */
    public void setiScsiRequired(Boolean iScsiRequired) {
        this.iScsiRequired = iScsiRequired;
    }

    /**
     * Getter method for property <tt>iScsiHostQuantity</tt>.
     * @return property value of iScsiHostQuantity
     */
    public Integer getiScsiHostQuantity() {
        return iScsiHostQuantity;
    }

    /**
     * Setter method for property <tt>iScsiHostQuantity</tt>.
     * @param iScsiHostQuantity
     *            value to be assigned to property iScsiHostQuantity
     */
    public void setiScsiHostQuantity(Integer iScsiHostQuantity) {
        this.iScsiHostQuantity = iScsiHostQuantity;
    }

    /**
     * Getter method for property <tt>iVnxScsiHostQuantity</tt>.
     * @return property value of iVnxScsiHostQuantity
     */
    public Integer getiVnxScsiHostQuantity() {
        return iVnxScsiHostQuantity;
    }

    /**
     * Setter method for property <tt>iVnxScsiHostQuantity</tt>.
     * @param iVnxScsiHostQuantity
     *            value to be assigned to property iVnxScsiHostQuantity
     */
    public void setiVnxScsiHostQuantity(Integer iVnxScsiHostQuantity) {
        this.iVnxScsiHostQuantity = iVnxScsiHostQuantity;
    }

    /**
     * Getter method for property <tt>iDartScsiHostQuantity</tt>.
     * @return property value of iDartScsiHostQuantity
     */
    public Integer getiDartScsiHostQuantity() {
        return iDartScsiHostQuantity;
    }

    /**
     * Setter method for property <tt>iDartScsiHostQuantity</tt>.
     * @param iDartScsiHostQuantity
     *            value to be assigned to property iDartScsiHostQuantity
     */
    public void setiDartScsiHostQuantity(Integer iDartScsiHostQuantity) {
        this.iDartScsiHostQuantity = iDartScsiHostQuantity;
    }

    /**
     * The toString method.
     *
     * @return the string for this entity
     */
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("{").append(super.toString());
        sb.append(", knowledgeTransferHours:").append(knowledgeTransferHours);
        sb.append(", vnxArraysNumber:").append(vnxArraysNumber);
        sb.append(", unisphereDomainsNumber:").append(unisphereDomainsNumber);
        sb.append(", fastCacheSetupNumber:").append(fastCacheSetupNumber);
        sb.append(", certifiedDiskErasureArraysNumber:").append(certifiedDiskErasureArraysNumber);
        sb.append(", deinstallCxNsVnxNumber:").append(deinstallCxNsVnxNumber);
        sb.append(", unifiedConversionsRequired:").append(unifiedConversionsRequired);
        sb.append(", unifiedConversionType:").append(unifiedConversionType);
        sb.append(", healthCheckRequired:").append(healthCheckRequired);
        sb.append(", sapHanaRequired:").append(sapHanaRequired);
        sb.append(", vnxInstallProtocolType:").append(vnxInstallProtocolType);
        sb.append(", vnxMonitoringReportingRequired:").append(vnxMonitoringReportingRequired);
        sb.append(", fcStorageConnectivityRequired:").append(fcStorageConnectivityRequired);
        sb.append(", fcoeStorageConnectivityRequired:").append(fcoeStorageConnectivityRequired);
        sb.append(", iscsiSanExtensionStorageConnectivityRequired:")
            .append(iscsiSanExtensionStorageConnectivityRequired);
        sb.append(", vsanLsanStorageConnectivityRequired:").append(vsanLsanStorageConnectivityRequired);
        sb.append(", fcRoutingStorageConnectivityRequired:").append(fcRoutingStorageConnectivityRequired);
        sb.append(", virtualInfrastructureEnablementIncluded:").append(virtualInfrastructureEnablementIncluded);
        sb.append(", watch4NetIncluded:").append(watch4NetIncluded);
        sb.append(", unifiedLocalProtection:").append(unifiedLocalProtection);
        sb.append(", unifiedRemoteProtection:").append(unifiedRemoteProtection);
        sb.append(", unifiedApplicationProtection:").append(unifiedApplicationProtection);
        sb.append(", unifiedFastDeployment:").append(unifiedFastDeployment);
        sb.append(", unifiedSecurityCompliance:").append(unifiedSecurityCompliance);
        sb.append(", unifiedManagementSuite:").append(unifiedManagementSuite);
        sb.append(", dataProtectionAdvisor:").append(dataProtectionAdvisor);
        sb.append(", fastLunMigrator:").append(fastLunMigrator);
        sb.append(", mirrorView:").append(mirrorView);
        sb.append(", qosManager:").append(qosManager);
        sb.append(", replicationManager:").append(replicationManager);
        sb.append(", recoverPoint:").append(recoverPoint);
        sb.append(", sanCopy:").append(sanCopy);
        sb.append(", snapViewVnxSnapShots:").append(snapViewVnxSnapShots);
        sb.append(", virtualProvisioning:").append(virtualProvisioning);
        sb.append(", storageAnalytics:").append(storageAnalytics);
        sb.append(", unifiedFileOERequired:").append(unifiedFileOERequired);
        sb.append(", unisphereAnalyzer:").append(unisphereAnalyzer);
        sb.append(", unisphereRemote:").append(unisphereRemote);
        sb.append(", vnxFileServersNumber:").append(vnxFileServersNumber);
        sb.append(", totalStorageAmount:").append(totalStorageAmount);
        sb.append(", activeDataMoversNumber:").append(activeDataMoversNumber);
        sb.append(", controlStationsNumber:").append(controlStationsNumber);
        sb.append(", fileSystemsNumber:").append(fileSystemsNumber);
        sb.append(", avgFileSystemSize:").append(avgFileSystemSize);
        sb.append(", storagePoolsNumber:").append(storagePoolsNumber);
        sb.append(", storageGroupsNumber:").append(storageGroupsNumber);
        sb.append(", thinLunsNumber:").append(thinLunsNumber);
        sb.append(", iscsi:").append(iscsi);
        sb.append(", iScsiRequired:").append(iScsiRequired);
        sb.append(", iScsiHostQuantity:").append(iScsiHostQuantity);
        sb.append(", iVnxScsiHostQuantity:").append(iVnxScsiHostQuantity);
        sb.append(", iDartScsiHostQuantity:").append(iDartScsiHostQuantity);
        sb.append(", dialHomeActivities:").append(dialHomeActivities).append("}");
        return sb.toString();
    }
}

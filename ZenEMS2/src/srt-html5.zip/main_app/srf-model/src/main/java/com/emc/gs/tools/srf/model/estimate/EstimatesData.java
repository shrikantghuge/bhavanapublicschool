/*
 * This code is copyright (c) 2014 EMC Corporation.
 */
package com.emc.gs.tools.srf.model.estimate;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import com.emc.gs.tools.srf.model.IdentifiableEntity;

/**
 * <p>
 * This is EstimatesData entity class.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safety.
 * </p>
 *
 * <p>
 * Version 1.1 (SRT Phase 4 - ET Release Assembly) Change notes:
 *   <ol>
 *     <li>Added {@link #contingencyPercent} property.</li>
 *   </ol>
 * </p>
 *
 * <p>
 * Version 1.2 Change notes:
 *   <ol>
 *     <li>Added {@link #sowNumber} property.</li>
 *     <li>Added {@link #contractNumber} property.</li>
 *     <li>Added {@link #ipEduData} property.</li>
 *   </ol>
 * </p>
 * 
 * @author TCSASSEMBLER
 * @version 1.2
 * @since SRT Phase 4 - ET Assembly 1
 */
public class EstimatesData extends IdentifiableEntity {

    /**
     * The list of resources.
     */
    private List<LOBResources> lobResources = new ArrayList<LOBResources>();

    /**
     * The selected deal currency.
     */
    private DealCurrency dealCurrency;

    /**
     * The expense estimated percent.
     */
    private BigDecimal estimatedPercent;

    /**
     * The expense amount.
     */
    private BigDecimal expenseAmount;

    /**
     * The capped percent.
     */
    private BigDecimal cappedPercent;

    /**
     * The client pricing override.
     */
    private BigDecimal clientPricingOverride;

    /**
     * The deliver action.
     */
    private DeliverAction deliverAction;

    /**
     * The deliver description.
     */
    private String deliverDescription;

    /**
     * <p>A <code>BigDecimal</code> providing the value for contingencyPercent property.</p>
     * 
     * @since 1.1
     */
    private BigDecimal contingencyPercent;

    /**
     * <p>A <code>String</code> providing the value for sowNumber property.</p>
     * 
     * @since 1.2
     */
    private String sowNumber;

    /**
     * <p>A <code>String</code> providing the value for contractNumber property.</p>
     * 
     * @since 1.2
     */
    private String contractNumber;

    /**
     * <p>A <code>List</code> providing the value for ipEduData property.</p>
     * 
     * @since 1.2
     */
    private List<IPEDURecord> ipEduData;

    /**
     * Empty constructor.
     */
    public EstimatesData() {
    }

    /**
     * Getter method for property <tt>lobResources</tt>.
     * 
     * @return property value of lobResources
     */
    public List<LOBResources> getLobResources() {
        return lobResources;
    }

    /**
     * Setter method for property <tt>lobResources</tt>.
     * 
     * @param lobResources
     *            value to be assigned to property lobResources
     */
    public void setLobResources(List<LOBResources> lobResources) {
        this.lobResources = lobResources;
    }

    /**
     * Getter method for property <tt>dealCurrency</tt>.
     * 
     * @return property value of dealCurrency
     */
    public DealCurrency getDealCurrency() {
        return dealCurrency;
    }

    /**
     * Setter method for property <tt>dealCurrency</tt>.
     * 
     * @param dealCurrency
     *            value to be assigned to property dealCurrency
     */
    public void setDealCurrency(DealCurrency dealCurrency) {
        this.dealCurrency = dealCurrency;
    }

    /**
     * Getter method for property <tt>estimatedPercent</tt>.
     * 
     * @return property value of estimatedPercent
     */
    public BigDecimal getEstimatedPercent() {
        return estimatedPercent;
    }

    /**
     * Setter method for property <tt>estimatedPercent</tt>.
     * 
     * @param estimatedPercent
     *            value to be assigned to property estimatedPercent
     */
    public void setEstimatedPercent(BigDecimal estimatedPercent) {
        this.estimatedPercent = estimatedPercent;
    }

    /**
     * Getter method for property <tt>expenseAmount</tt>.
     * 
     * @return property value of expenseAmount
     */
    public BigDecimal getExpenseAmount() {
        return expenseAmount;
    }

    /**
     * Setter method for property <tt>expenseAmount</tt>.
     * 
     * @param expenseAmount
     *            value to be assigned to property expenseAmount
     */
    public void setExpenseAmount(BigDecimal expenseAmount) {
        this.expenseAmount = expenseAmount;
    }

    /**
     * Getter method for property <tt>cappedPercent</tt>.
     * 
     * @return property value of cappedPercent
     */
    public BigDecimal getCappedPercent() {
        return cappedPercent;
    }

    /**
     * Setter method for property <tt>cappedPercent</tt>.
     * 
     * @param cappedPercent
     *            value to be assigned to property cappedPercent
     */
    public void setCappedPercent(BigDecimal cappedPercent) {
        this.cappedPercent = cappedPercent;
    }

    /**
     * Getter method for property <tt>clientPricingOverride</tt>.
     * 
     * @return property value of clientPricingOverride
     */
    public BigDecimal getClientPricingOverride() {
        return clientPricingOverride;
    }

    /**
     * Setter method for property <tt>clientPricingOverride</tt>.
     * 
     * @param clientPricingOverride
     *            value to be assigned to property clientPricingOverride
     */
    public void setClientPricingOverride(BigDecimal clientPricingOverride) {
        this.clientPricingOverride = clientPricingOverride;
    }

    /**
     * Getter method for property <tt>deliverAction</tt>.
     * 
     * @return property value of deliverAction
     */
    public DeliverAction getDeliverAction() {
        return deliverAction;
    }

    /**
     * Setter method for property <tt>deliverAction</tt>.
     * 
     * @param deliverAction
     *            value to be assigned to property deliverAction
     */
    public void setDeliverAction(DeliverAction deliverAction) {
        this.deliverAction = deliverAction;
    }

    /**
     * Getter method for property <tt>deliverDescription</tt>.
     * 
     * @return property value of deliverDescription
     */
    public String getDeliverDescription() {
        return deliverDescription;
    }

    /**
     * Setter method for property <tt>deliverDescription</tt>.
     * 
     * @param deliverDescription
     *            value to be assigned to property deliverDescription
     */
    public void setDeliverDescription(String deliverDescription) {
        this.deliverDescription = deliverDescription;
    }

    /**
     * <p>Gets the contingencyPercent property.</p>
     *
     * @return a <code>BigDecimal</code> providing the value for contingencyPercent property.
     * @since 1.1
     */
    public BigDecimal getContingencyPercent() {
        return this.contingencyPercent;
    }

    /**
     * <p>Sets the contingencyPercent property.</p>
     *
     * @param contingencyPercent a <code>BigDecimal</code> providing the value for contingencyPercent proeprty.
     * @since 1.1
     */
    public void setContingencyPercent(BigDecimal contingencyPercent) {
        this.contingencyPercent = contingencyPercent;
    }

    /**
     * <p>Gets the sowNumber property.</p>
     *
     * @return a <code>String</code> providing the value for sowNumber property.
     * @since 1.2
     */
    public String getSowNumber() {
        return this.sowNumber;
    }

    /**
     * <p>Sets the sowNumber property.</p>
     *
     * @param sowNumber a <code>String</code> providing the value for sowNumber property.
     * @since 1.2
     */
    public void setSowNumber(String sowNumber) {
        this.sowNumber = sowNumber;
    }

    /**
     * <p>Gets the contractNumber property.</p>
     *
     * @return a <code>String</code> providing the value for contractNumber property.
     * @since 1.2
     */
    public String getContractNumber() {
        return this.contractNumber;
    }

    /**
     * <p>Sets the contractNumber property.</p>
     *
     * @param contractNumber a <code>String</code> providing the value for contractNumber property.
     * @since 1.2
     */
    public void setContractNumber(String contractNumber) {
        this.contractNumber = contractNumber;
    }

    /**
     * <p>Gets the ipEduData property.</p>
     *
     * @return a <code>List</code> providing the value for ipEduData property.
     * @since 1.2
     */
    public List<IPEDURecord> getIpEduData() {
        return this.ipEduData;
    }

    /**
     * <p>Sets the ipEduData property.</p>
     *
     * @param ipEduData a <code>List</code> providing the value for ipEduData property.
     * @since 1.2
     */
    public void setIpEduData(List<IPEDURecord> ipEduData) {
        this.ipEduData = ipEduData;
    }
}

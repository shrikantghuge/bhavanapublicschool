/*
 * This code is copyright (c) 2014 EMC Corporation
 */
package com.emc.gs.tools.srf.model.isilon;

import java.math.BigDecimal;

import com.emc.gs.tools.srf.model.IdentifiableEntity;

/**
 * <p>
 * This is IsilonRequestData entity class.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safety.
 * </p>
 * 
 * @author TCSASSEMBLER
 * @version 1.0
 * @since SRT Phase 3-3 - Implement Isilon and ViPR Tabs Assembly
 */
public class IsilonRequestData extends IdentifiableEntity {

    /**
     * # of Hours of Knowledge Transfer.
     */
    private BigDecimal knowledgeTransferHours;

    /**
     * General Comment.
     */
    private String generalComment;

    /**
     * Services scope.
     */
    private IsilonServicesScope servicesScope;

    /**
     * Isilon Cluster Relocation.
     */
    private IsilonClusterRelocation clusterRelocation;

    /**
     * Isilon Hardware Upgrade.
     */
    private IsilonHardwareUpgrade hardwareUpgrade;

    /**
     * Isilon Migration.
     */
    private IsilonMigration migration;

    /**
     * Isilon Design and Implementation.
     */
    private IsilonDesignAndImpl designAndImpl;

    /**
     * <p>
     * The default constructor.
     * </p>
     */
    public IsilonRequestData() {
    }

    /**
     * Getter method for property <tt>knowledgeTransferHours</tt>.
     * 
     * @return property value of knowledgeTransferHours
     */
    public BigDecimal getKnowledgeTransferHours() {
        return knowledgeTransferHours;
    }

    /**
     * Setter method for property <tt>knowledgeTransferHours</tt>.
     * 
     * @param knowledgeTransferHours
     *            value to be assigned to property knowledgeTransferHours
     */
    public void setKnowledgeTransferHours(BigDecimal knowledgeTransferHours) {
        this.knowledgeTransferHours = knowledgeTransferHours;
    }

    /**
     * Getter method for property <tt>generalComment</tt>.
     * 
     * @return property value of generalComment
     */
    public String getGeneralComment() {
        return generalComment;
    }

    /**
     * Setter method for property <tt>generalComment</tt>.
     * 
     * @param generalComment
     *            value to be assigned to property generalComment
     */
    public void setGeneralComment(String generalComment) {
        this.generalComment = generalComment;
    }

    /**
     * Getter method for property <tt>servicesScope</tt>.
     * 
     * @return property value of servicesScope
     */
    public IsilonServicesScope getServicesScope() {
        return servicesScope;
    }

    /**
     * Setter method for property <tt>servicesScope</tt>.
     * 
     * @param servicesScope
     *            value to be assigned to property servicesScope
     */
    public void setServicesScope(IsilonServicesScope servicesScope) {
        this.servicesScope = servicesScope;
    }

    /**
     * Getter method for property <tt>clusterRelocation</tt>.
     * 
     * @return property value of clusterRelocation
     */
    public IsilonClusterRelocation getClusterRelocation() {
        return clusterRelocation;
    }

    /**
     * Setter method for property <tt>clusterRelocation</tt>.
     * 
     * @param clusterRelocation
     *            value to be assigned to property clusterRelocation
     */
    public void setClusterRelocation(IsilonClusterRelocation clusterRelocation) {
        this.clusterRelocation = clusterRelocation;
    }

    /**
     * Getter method for property <tt>hardwareUpgrade</tt>.
     * 
     * @return property value of hardwareUpgrade
     */
    public IsilonHardwareUpgrade getHardwareUpgrade() {
        return hardwareUpgrade;
    }

    /**
     * Setter method for property <tt>hardwareUpgrade</tt>.
     * 
     * @param hardwareUpgrade
     *            value to be assigned to property hardwareUpgrade
     */
    public void setHardwareUpgrade(IsilonHardwareUpgrade hardwareUpgrade) {
        this.hardwareUpgrade = hardwareUpgrade;
    }

    /**
     * Getter method for property <tt>migration</tt>.
     * 
     * @return property value of migration
     */
    public IsilonMigration getMigration() {
        return migration;
    }

    /**
     * Setter method for property <tt>migration</tt>.
     * 
     * @param migration
     *            value to be assigned to property migration
     */
    public void setMigration(IsilonMigration migration) {
        this.migration = migration;
    }

    /**
     * Getter method for property <tt>designAndImpl</tt>.
     * 
     * @return property value of designAndImpl
     */
    public IsilonDesignAndImpl getDesignAndImpl() {
        return designAndImpl;
    }

    /**
     * Setter method for property <tt>designAndImpl</tt>.
     * 
     * @param designAndImpl
     *            value to be assigned to property designAndImpl
     */
    public void setDesignAndImpl(IsilonDesignAndImpl designAndImpl) {
        this.designAndImpl = designAndImpl;
    }

}

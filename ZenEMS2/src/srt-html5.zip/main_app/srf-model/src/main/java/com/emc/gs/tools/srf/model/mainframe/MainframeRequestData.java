/*
 * This code is copyright (c) 2013 - 2014 EMC Corporation.
 */
package com.emc.gs.tools.srf.model.mainframe;

import java.util.ArrayList;
import java.util.List;

import com.emc.gs.tools.srf.model.IdentifiableEntity;

/**
 * <p>
 * This is MainframeRequestData entity class.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safety.
 * </p>
 *
 * <p>
 * <strong>Changes V1.1:</strong>
 * <strong>SRT Phase 3-1 - CTA Rainfinity and MSS Tabs Update Assembly</strong>
 * <ul>
 * <li>Add generalComment field.</li>
 * </ul>
 * </p>
 *
 * @author faeton, stevenfrog
 * @version 1.1
 */
public class MainframeRequestData extends IdentifiableEntity {

    /**
     * General comment.
     */
    private String generalComment;

    /**
     * <p>
     * The servicesScope.
     * </p>
     */
    private MainframeServicesScope servicesScope;

    /**
     * <p>
     * The booleanServiceData.
     * </p>
     */
    private List<BooleanServiceData> booleanServiceData = new ArrayList<BooleanServiceData>();

    /**
     * <p>
     * The stringServiceData.
     * </p>
     */
    private List<StringServiceData> stringServiceData = new ArrayList<StringServiceData>();

    /**
     * <p>
     * The default constructor.
     * </p>
     */
    public MainframeRequestData() {
        // Empty
    }

    /**
     * Getter method for property <tt>generalComment</tt>.
     * 
     * @return property value of generalComment
     */
    public String getGeneralComment() {
        return generalComment;
    }

    /**
     * Setter method for property <tt>generalComment</tt>.
     * 
     * @param generalComment
     *            value to be assigned to property generalComment
     */
    public void setGeneralComment(String generalComment) {
        this.generalComment = generalComment;
    }

    /**
     * <p>
     * Retrieves the servicesScope field.
     * </p>
     *
     * @return the servicesScope
     */
    public MainframeServicesScope getServicesScope() {
        return servicesScope;
    }

    /**
     * <p>
     * Sets the value to servicesScope field.
     * </p>
     *
     * @param servicesScope
     *            the servicesScope to set
     */
    public void setServicesScope(MainframeServicesScope servicesScope) {
        this.servicesScope = servicesScope;
    }

    /**
     * <p>
     * Retrieves the booleanServiceData field.
     * </p>
     *
     * @return the booleanServiceData
     */
    public List<BooleanServiceData> getBooleanServiceData() {
        return booleanServiceData;
    }

    /**
     * <p>
     * Sets the value to booleanServiceData field.
     * </p>
     *
     * @param booleanServiceData
     *            the booleanServiceData to set
     */
    public void setBooleanServiceData(List<BooleanServiceData> booleanServiceData) {
        this.booleanServiceData = booleanServiceData;
    }

    /**
     * <p>
     * Retrieves the stringServiceData field.
     * </p>
     *
     * @return the stringServiceData
     */
    public List<StringServiceData> getStringServiceData() {
        return stringServiceData;
    }

    /**
     * <p>
     * Sets the value to stringServiceData field.
     * </p>
     *
     * @param stringServiceData
     *            the stringServiceData to set
     */
    public void setStringServiceData(List<StringServiceData> stringServiceData) {
        this.stringServiceData = stringServiceData;
    }

    /**
     * The toString method.
     *
     * @return the string for this entity
     */
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("{").append(super.toString()).append("}");
        return sb.toString();
    }
}

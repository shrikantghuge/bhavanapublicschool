/*
 * This code is copyright (c) 2014 EMC Corporation.
 */
package com.emc.gs.tools.srf.model.move;

import java.util.ArrayList;
import java.util.List;

import com.emc.gs.tools.srf.model.IdentifiableEntity;

/**
 * <p>
 * This is MoveRequestData entity class. It maps directly to the fields described in Detailed Tab Documentation - Move
 * Request.docx
 * </p>
 * 
 * v1.1 - updated field list as specified in issue F230
 * @author TCSASSEMBLER
 * @version 1.1
 * @since SRT Phase 3-2 - Move Request and Change Request Tabs Assembly
 */
public class MoveRequestData extends IdentifiableEntity {

    /**
     * General comments.
     * @since 1.1
     */
    private String generalComments;

    /**
     * Move services scope.
     * @since 1.1
     */
    private boolean moveServices;
    /**
     * Power up/down scope.
     * @since 1.1
     */
    private boolean powerDownPowerUp;
    /**
     * Reinstall/Deinstall scope.
     * @since 1.1
     */
    private boolean deinstallReinstall;
    /**
     * Reconfiguration support scope.
     * @since 1.1
     */
    private boolean reconfigurationSupport;
    /**
     * Power up/down equipment list.
     * @since 1.1
     */
    private String powerUpEquipment;
    /**
     * De/Reinstall equipment list.
     * @since 1.1
     */
    private String deinstallUpEquipment;
    /**
     * IP change required flag.
     * @since 1.1
     */
    private Boolean ipChangeRequired;
    /**
     * Explain customer requirements text.
     * @since 1.1
     */
    private String explainCustRequirements;
    
    /**
     * List of move sites.
     * @since 1.1
     */
    private List<SiteInformation> siteInformation = new ArrayList<SiteInformation>();
    
    /**
     * Full Project Description / Scope.
     */
    private String fullDescription;
    /**
     * Are after-hours, holiday, or weekend services needed?.
     */
    private Boolean afterHoursMSSNeeded;
    /**
     * What is the project timeline.
     */
    private String projectTimeline;
    /**
     * Weekday or Weekend delivery (Target date).
     */
    private String targetDate;
    /**
     * How many EMC Racks Total.
     */
    private Integer emcRacksTotal;
    /**
     * How many NON-EMC Racks Total.
     */
    private Integer nonEmcRacksTotal;
    /**
     * If no rack please provide a description of the components.
     */
    private String noRack;
    /**
     * Equipment.
     */
    private String equipment;
    /**
     * Is this equipment under an EMC Maintenance contract?.
     */
    private Boolean equipmentUnderMaintenance;
    /**
     * Are EMC move services needed.
     */
    private Boolean emcMoveServicesNeeded;
    /**
     * Does the pickup/delivery need to be completed after-business hours.
     */
    private Boolean pickupAfterHours;
    /**
     * Will the move take place as a single event.
     */
    private Boolean singleEvent;
    /**
     * Does each piece of equipment need networking configuration reset.
     */
    private Boolean eachPieceNeedsNetCfgReset;
    /**
     * Is EMC packaging material needed.
     */
    private Boolean emcPackingMaterialsNeeded;
    /**
     * Gross Value of equipment (Hardware) (US$).
     */
    private String totalValue;
    /**
     * Leave any comments in this box.
     */
    private String comments;
    /**
     * Please indicate desired shipping speed (this will affect shipping price)Examples: Same-day, Overnight, 2 day, 3
     * day, etc.
     */
    private String shippingTimeline;
    
    /**
     * Is any EMC Equipment recertification required?.
     * @since 1.1
     */
    private Boolean emcCertificationRequired;

    /**
     * Empty constructor.
     */
    public MoveRequestData() {
    }

    /**
     * Gets the value of the field <code>fullDescription</code>.
     * 
     * @return the fullDescription
     */
    public String getFullDescription() {
        return fullDescription;
    }

    /**
     * Sets the value of the field <code>fullDescription</code>.
     * 
     * @param fullDescription the fullDescription to set
     */
    public void setFullDescription(String fullDescription) {
        this.fullDescription = fullDescription;
    }

    /**
     * Gets the value of the field <code>afterHoursMSSNeeded</code>.
     * 
     * @return the afterHoursMSSNeeded
     */
    public Boolean getAfterHoursMSSNeeded() {
        return afterHoursMSSNeeded;
    }

    /**
     * Sets the value of the field <code>afterHoursMSSNeeded</code>.
     * 
     * @param afterHoursMSSNeeded the afterHoursMSSNeeded to set
     */
    public void setAfterHoursMSSNeeded(Boolean afterHoursMSSNeeded) {
        this.afterHoursMSSNeeded = afterHoursMSSNeeded;
    }

    /**
     * Gets the value of the field <code>projectTimeline</code>.
     * 
     * @return the projectTimeline
     */
    public String getProjectTimeline() {
        return projectTimeline;
    }

    /**
     * Sets the value of the field <code>projectTimeline</code>.
     * 
     * @param projectTimeline the projectTimeline to set
     */
    public void setProjectTimeline(String projectTimeline) {
        this.projectTimeline = projectTimeline;
    }

    /**
     * Gets the value of the field <code>targetDate</code>.
     * 
     * @return the targetDate
     */
    public String getTargetDate() {
        return targetDate;
    }

    /**
     * Sets the value of the field <code>targetDate</code>.
     * 
     * @param targetDate the targetDate to set
     */
    public void setTargetDate(String targetDate) {
        this.targetDate = targetDate;
    }

    /**
     * Gets the value of the field <code>emcRacksTotal</code>.
     * 
     * @return the emcRacksTotal
     */
    public Integer getEmcRacksTotal() {
        return emcRacksTotal;
    }

    /**
     * Sets the value of the field <code>emcRacksTotal</code>.
     * 
     * @param emcRacksTotal the emcRacksTotal to set
     */
    public void setEmcRacksTotal(Integer emcRacksTotal) {
        this.emcRacksTotal = emcRacksTotal;
    }

    /**
     * Gets the value of the field <code>nonEmcRacksTotal</code>.
     * 
     * @return the nonEmcRacksTotal
     */
    public Integer getNonEmcRacksTotal() {
        return nonEmcRacksTotal;
    }

    /**
     * Sets the value of the field <code>nonEmcRacksTotal</code>.
     * 
     * @param nonEmcRacksTotal the nonEmcRacksTotal to set
     */
    public void setNonEmcRacksTotal(Integer nonEmcRacksTotal) {
        this.nonEmcRacksTotal = nonEmcRacksTotal;
    }

    /**
     * Gets the value of the field <code>noRack</code>.
     * 
     * @return the noRack
     */
    public String getNoRack() {
        return noRack;
    }

    /**
     * Sets the value of the field <code>noRack</code>.
     * 
     * @param noRack the noRack to set
     */
    public void setNoRack(String noRack) {
        this.noRack = noRack;
    }

    /**
     * Gets the value of the field <code>equipment</code>.
     * 
     * @return the equipment
     */
    public String getEquipment() {
        return equipment;
    }

    /**
     * Sets the value of the field <code>equipment</code>.
     * 
     * @param equipment the equipment to set
     */
    public void setEquipment(String equipment) {
        this.equipment = equipment;
    }

    /**
     * Gets the value of the field <code>equipmentUnderMaintenance</code>.
     * 
     * @return the equipmentNotUnderMaintenance
     */
    public Boolean getEquipmentUnderMaintenance() {
        return equipmentUnderMaintenance;
    }

    /**
     * Sets the value of the field <code>equipmentUnderMaintenance</code>.
     * 
     * @param equipmentUnderMaintenance the equipmentUnderMaintenance to set
     */
    public void setEquipmentUnderMaintenance(Boolean equipmentUnderMaintenance) {
        this.equipmentUnderMaintenance = equipmentUnderMaintenance;
    }

    /**
     * Gets the value of the field <code>emcMoveServicesNeeded</code>.
     * 
     * @return the emcMoveServicesNeeded
     */
    public Boolean getEmcMoveServicesNeeded() {
        return emcMoveServicesNeeded;
    }

    /**
     * Sets the value of the field <code>emcMoveServicesNeeded</code>.
     * 
     * @param emcMoveServicesNeeded the emcMoveServicesNeeded to set
     */
    public void setEmcMoveServicesNeeded(Boolean emcMoveServicesNeeded) {
        this.emcMoveServicesNeeded = emcMoveServicesNeeded;
    }

    /**
     * Gets the value of the field <code>pickupAfterHours</code>.
     * 
     * @return the pickupAfterHours
     */
    public Boolean getPickupAfterHours() {
        return pickupAfterHours;
    }

    /**
     * Sets the value of the field <code>pickupAfterHours</code>.
     * 
     * @param pickupAfterHours the pickupAfterHours to set
     */
    public void setPickupAfterHours(Boolean pickupAfterHours) {
        this.pickupAfterHours = pickupAfterHours;
    }

    /**
     * Gets the value of the field <code>singleEvent</code>.
     * 
     * @return the singleEvent
     */
    public Boolean getSingleEvent() {
        return singleEvent;
    }

    /**
     * Sets the value of the field <code>singleEvent</code>.
     * 
     * @param singleEvent the singleEvent to set
     */
    public void setSingleEvent(Boolean singleEvent) {
        this.singleEvent = singleEvent;
    }

    /**
     * Gets the value of the field <code>eachPieceNeedsNetCfgReset</code>.
     * 
     * @return the eachPieceNeedsNetCfgReset
     */
    public Boolean getEachPieceNeedsNetCfgReset() {
        return eachPieceNeedsNetCfgReset;
    }

    /**
     * Sets the value of the field <code>eachPieceNeedsNetCfgReset</code>.
     * 
     * @param eachPieceNeedsNetCfgReset the eachPieceNeedsNetCfgReset to set
     */
    public void setEachPieceNeedsNetCfgReset(Boolean eachPieceNeedsNetCfgReset) {
        this.eachPieceNeedsNetCfgReset = eachPieceNeedsNetCfgReset;
    }

    /**
     * Gets the value of the field <code>emcPackingMaterialsNeeded</code>.
     * 
     * @return the emcPackingMaterialsNeeded
     */
    public Boolean getEmcPackingMaterialsNeeded() {
        return emcPackingMaterialsNeeded;
    }

    /**
     * Sets the value of the field <code>emcPackingMaterialsNeeded</code>.
     * 
     * @param emcPackingMaterialsNeeded the emcPackingMaterialsNeeded to set
     */
    public void setEmcPackingMaterialsNeeded(Boolean emcPackingMaterialsNeeded) {
        this.emcPackingMaterialsNeeded = emcPackingMaterialsNeeded;
    }

    /**
     * Gets the value of the field <code>totalValue</code>.
     * 
     * @return the totalValue
     */
    public String getTotalValue() {
        return totalValue;
    }

    /**
     * Sets the value of the field <code>totalValue</code>.
     * 
     * @param totalValue the totalValue to set
     */
    public void setTotalValue(String totalValue) {
        this.totalValue = totalValue;
    }

    /**
     * Gets the value of the field <code>comments</code>.
     * 
     * @return the comments
     */
    public String getComments() {
        return comments;
    }

    /**
     * Sets the value of the field <code>comments</code>.
     * 
     * @param comments the comments to set
     */
    public void setComments(String comments) {
        this.comments = comments;
    }

    /**
     * Gets the value of the field <code>shippingTimeline</code>.
     * 
     * @return the shippingTimeline
     */
    public String getShippingTimeline() {
        return shippingTimeline;
    }

    /**
     * Sets the value of the field <code>shippingTimeline</code>.
     * 
     * @param shippingTimeline the shippingTimeline to set
     */
    public void setShippingTimeline(String shippingTimeline) {
        this.shippingTimeline = shippingTimeline;
    }


    /**
     * Gets the value of the field <code>emcCertificationRequired</code>.
     * @return the emcCertificationRequired
     * @since 1.1
     */
    public Boolean getEmcCertificationRequired() {
        return emcCertificationRequired;
    }

    /**
     * Sets the value of the field <code>emcCertificationRequired</code>.
     * @param emcCertificationRequired the emcCertificationRequired to set
     * @since 1.1
     */
    public void setEmcCertificationRequired(Boolean emcCertificationRequired) {
        this.emcCertificationRequired = emcCertificationRequired;
    }

    /**
     * Gets the value of the field <code>moveServices</code>.
     * @return the moveServices
     * @since 1.1
     */
    public boolean isMoveServices() {
        return moveServices;
    }

    /**
     * Sets the value of the field <code>moveServices</code>.
     * @param moveServices the moveServices to set
     * @since 1.1
     */
    public void setMoveServices(boolean moveServices) {
        this.moveServices = moveServices;
    }

    /**
     * Gets the value of the field <code>powerDownPowerUp</code>.
     * @return the powerDownPowerUp
     * @since 1.1
     */
    public boolean isPowerDownPowerUp() {
        return powerDownPowerUp;
    }

    /**
     * Sets the value of the field <code>powerDownPowerUp</code>.
     * @param powerDownPowerUp the powerDownPowerUp to set
     * @since 1.1
     */
    public void setPowerDownPowerUp(boolean powerDownPowerUp) {
        this.powerDownPowerUp = powerDownPowerUp;
    }

    /**
     * Gets the value of the field <code>deinstallReinstall</code>.
     * @return the deinstallReinstall
     * @since 1.1
     */
    public boolean isDeinstallReinstall() {
        return deinstallReinstall;
    }

    /**
     * Sets the value of the field <code>deinstallReinstall</code>.
     * @param deinstallReinstall the deinstallReinstall to set
     * @since 1.1
     */
    public void setDeinstallReinstall(boolean deinstallReinstall) {
        this.deinstallReinstall = deinstallReinstall;
    }

    /**
     * Gets the value of the field <code>reconfigurationSupport</code>.
     * @return the reconfigurationSupport
     * @since 1.1
     */
    public boolean isReconfigurationSupport() {
        return reconfigurationSupport;
    }

    /**
     * Sets the value of the field <code>reconfigurationSupport</code>.
     * @param reconfigurationSupport the reconfigurationSupport to set
     * @since 1.1
     */
    public void setReconfigurationSupport(boolean reconfigurationSupport) {
        this.reconfigurationSupport = reconfigurationSupport;
    }

    /**
     * Gets the value of the field <code>powerUpEquipment</code>.
     * @return the powerUpEquipment
     * @since 1.1
     */
    public String getPowerUpEquipment() {
        return powerUpEquipment;
    }

    /**
     * Sets the value of the field <code>powerUpEquipment</code>.
     * @param powerUpEquipment the powerUpEquipment to set
     * @since 1.1
     */
    public void setPowerUpEquipment(String powerUpEquipment) {
        this.powerUpEquipment = powerUpEquipment;
    }

    /**
     * Gets the value of the field <code>deinstallUpEquipment</code>.
     * @return the deinstallUpEquipment
     * @since 1.1
     */
    public String getDeinstallUpEquipment() {
        return deinstallUpEquipment;
    }

    /**
     * Sets the value of the field <code>deinstallUpEquipment</code>.
     * @param deinstallUpEquipment the deinstallUpEquipment to set
     * @since 1.1
     */
    public void setDeinstallUpEquipment(String deinstallUpEquipment) {
        this.deinstallUpEquipment = deinstallUpEquipment;
    }

    /**
     * Gets the value of the field <code>ipChangeRequired</code>.
     * @return the ipChangeRequired
     * @since 1.1
     */
    public Boolean getIpChangeRequired() {
        return ipChangeRequired;
    }

    /**
     * Sets the value of the field <code>ipChangeRequired</code>.
     * @param ipChangeRequired the ipChangeRequired to set
     * @since 1.1
     */
    public void setIpChangeRequired(Boolean ipChangeRequired) {
        this.ipChangeRequired = ipChangeRequired;
    }

    /**
     * Gets the value of the field <code>explainCustRequirements</code>.
     * @return the explainCustRequirements
     * @since 1.1
     */
    public String getExplainCustRequirements() {
        return explainCustRequirements;
    }

    /**
     * Sets the value of the field <code>explainCustRequirements</code>.
     * @param explainCustRequirements the explainCustRequirements to set
     * @since 1.1
     */
    public void setExplainCustRequirements(String explainCustRequirements) {
        this.explainCustRequirements = explainCustRequirements;
    }

    /**
     * Gets the value of the field <code>siteInformation</code>.
     * @return the siteInformation
     * @since 1.1
     */
    public List<SiteInformation> getSiteInformation() {
        return siteInformation;
    }

    /**
     * Sets the value of the field <code>siteInformation</code>.
     * @param siteInformation the siteInformation to set
     * @since 1.1
     */
    public void setSiteInformation(List<SiteInformation> siteInformation) {
        this.siteInformation = siteInformation;
    }

    /**
     * Gets the value of the field <code>generalComments</code>.
     * @return the generalComments
     * @since 1.1
     */
    public String getGeneralComments() {
        return generalComments;
    }

    /**
     * Sets the value of the field <code>generalComments</code>.
     * @param generalComments the generalComments to set
     * @since 1.1
     */
    public void setGeneralComments(String generalComments) {
        this.generalComments = generalComments;
    }

    /**
     * Generates a string representation of this entity.
     * 
     * @return the properties of this object.
     */
    @Override
    public String toString() {
        return "MoveRequestData [generalComments=" + generalComments + ", moveServices=" + moveServices
            + ", powerDownPowerUp=" + powerDownPowerUp + ", deinstallReinstall=" + deinstallReinstall
            + ", reconfigurationSupport=" + reconfigurationSupport + ", powerUpEquipment=" + powerUpEquipment
            + ", deinstallUpEquipment=" + deinstallUpEquipment + ", ipChangeRequired=" + ipChangeRequired
            + ", explainCustRequirements=" + explainCustRequirements + ", siteInformation=" + siteInformation
            + ", fullDescription=" + fullDescription + ", afterHoursMSSNeeded=" + afterHoursMSSNeeded
            + ", projectTimeline=" + projectTimeline + ", targetDate=" + targetDate + ", emcRacksTotal="
            + emcRacksTotal + ", nonEmcRacksTotal=" + nonEmcRacksTotal + ", noRack=" + noRack + ", equipment="
            + equipment + ", equipmentUnderMaintenance=" + equipmentUnderMaintenance + ", emcMoveServicesNeeded="
            + emcMoveServicesNeeded + ", pickupAfterHours=" + pickupAfterHours + ", singleEvent=" + singleEvent
            + ", eachPieceNeedsNetCfgReset=" + eachPieceNeedsNetCfgReset + ", emcPackingMaterialsNeeded="
            + emcPackingMaterialsNeeded + ", totalValue=" + totalValue + ", comments=" + comments
            + ", shippingTimeline=" + shippingTimeline + ", emcCertificationRequired=" + emcCertificationRequired + "]";
    }
}

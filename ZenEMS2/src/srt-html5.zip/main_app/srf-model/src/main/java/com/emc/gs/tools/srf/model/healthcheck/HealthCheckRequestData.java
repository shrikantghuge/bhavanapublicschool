/*
 * This code is copyright (c) 2014 EMC Corporation
 */
package com.emc.gs.tools.srf.model.healthcheck;

import com.emc.gs.tools.srf.model.IdentifiableEntity;

/**
 * <p>
 * This is HealthCheckRequestData entity class.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safety.
 * </p>
 * <p>
 * 
 * @author TCSASSEMBLER
 * @version 1.0
 * @since SRT Phase 3-4 - ASD and Healthcheck Tabs Assembly
 */
public class HealthCheckRequestData extends IdentifiableEntity {

    /**
     * General comment.
     */
    private String generalComment;

    /**
     * Health Check Services scope.
     */
    private HealthCheckServicesScope servicesScope;

    /**
     * Avamar health check.
     */
    private HealthCheckAvamar avamar;

    /**
     * Data Domain health check.
     */
    private HealthCheckDataDomain dataDomain;

    /**
     * Data Protection Advisor health check.
     */
    private HealthCheckDPA dpa;

    /**
     * DLM health check.
     */
    private HealthCheckDLM dlm;

    /**
     * GreenPlum health check.
     */
    private HealthCheckGreenPlum greenPlum;

    /**
     * Ionix health check.
     */
    private HealthCheckIonix ionix;

    /**
     * NetWorker health check.
     */
    private HealthCheckNetWorker netWorker;

    /**
     * San Security health check.
     */
    private HealthCheckSanSecurity sanSecurity;

    /**
     * SAP health check.
     */
    private HealthCheckSAP sap;

    /**
     * SourceOne health check.
     */
    private HealthCheckSourceOne sourceOne;

    /**
     * Symmetrix / Vmax health check.
     */
    private HealthCheckSymmetrixVmax symmetrixVmax;

    /**
     * Symmetrix / Vmax Storage Replication health check.
     */
    private HealthCheckSymmetrixVmaxStorageReplication symmetrixVmaxStorageReplication;

    /**
     * Unified health check.
     */
    private HealthCheckUnified unified;

    /**
     * Vblock health check.
     */
    private HealthCheckVblock vblock;

    /**
     * VMWare Virtual Infrastructure health check.
     */
    private HealthCheckVmwareVirtualInfrastructure vmwareVirtualInfrastructure;

    /**
     * Vplex health check.
     */
    private HealthCheckVplex vplex;

    /**
     * <p>
     * The default constructor.
     * </p>
     */
    public HealthCheckRequestData() {
    }

    /**
     * Getter method for property <tt>generalComment</tt>.
     * 
     * @return property value of generalComment
     */
    public String getGeneralComment() {
        return generalComment;
    }

    /**
     * Setter method for property <tt>generalComment</tt>.
     * 
     * @param generalComment
     *            value to be assigned to property generalComment
     */
    public void setGeneralComment(String generalComment) {
        this.generalComment = generalComment;
    }

    /**
     * Getter method for property <tt>servicesScope</tt>.
     * 
     * @return property value of servicesScope
     */
    public HealthCheckServicesScope getServicesScope() {
        return servicesScope;
    }

    /**
     * Setter method for property <tt>servicesScope</tt>.
     * 
     * @param servicesScope
     *            value to be assigned to property servicesScope
     */
    public void setServicesScope(HealthCheckServicesScope servicesScope) {
        this.servicesScope = servicesScope;
    }

    /**
     * Getter method for property <tt>avamar</tt>.
     * 
     * @return property value of avamar
     */
    public HealthCheckAvamar getAvamar() {
        return avamar;
    }

    /**
     * Setter method for property <tt>avamar</tt>.
     * 
     * @param avamar
     *            value to be assigned to property avamar
     */
    public void setAvamar(HealthCheckAvamar avamar) {
        this.avamar = avamar;
    }

    /**
     * Getter method for property <tt>dataDomain</tt>.
     * 
     * @return property value of dataDomain
     */
    public HealthCheckDataDomain getDataDomain() {
        return dataDomain;
    }

    /**
     * Setter method for property <tt>dataDomain</tt>.
     * 
     * @param dataDomain
     *            value to be assigned to property dataDomain
     */
    public void setDataDomain(HealthCheckDataDomain dataDomain) {
        this.dataDomain = dataDomain;
    }

    /**
     * Getter method for property <tt>dpa</tt>.
     * 
     * @return property value of dpa
     */
    public HealthCheckDPA getDpa() {
        return dpa;
    }

    /**
     * Setter method for property <tt>dpa</tt>.
     * 
     * @param dpa
     *            value to be assigned to property dpa
     */
    public void setDpa(HealthCheckDPA dpa) {
        this.dpa = dpa;
    }

    /**
     * Getter method for property <tt>dlm</tt>.
     * 
     * @return property value of dlm
     */
    public HealthCheckDLM getDlm() {
        return dlm;
    }

    /**
     * Setter method for property <tt>dlm</tt>.
     * 
     * @param dlm
     *            value to be assigned to property dlm
     */
    public void setDlm(HealthCheckDLM dlm) {
        this.dlm = dlm;
    }

    /**
     * Getter method for property <tt>greenPlum</tt>.
     * 
     * @return property value of greenPlum
     */
    public HealthCheckGreenPlum getGreenPlum() {
        return greenPlum;
    }

    /**
     * Setter method for property <tt>greenPlum</tt>.
     * 
     * @param greenPlum
     *            value to be assigned to property greenPlum
     */
    public void setGreenPlum(HealthCheckGreenPlum greenPlum) {
        this.greenPlum = greenPlum;
    }

    /**
     * Getter method for property <tt>ionix</tt>.
     * 
     * @return property value of ionix
     */
    public HealthCheckIonix getIonix() {
        return ionix;
    }

    /**
     * Setter method for property <tt>ionix</tt>.
     * 
     * @param ionix
     *            value to be assigned to property ionix
     */
    public void setIonix(HealthCheckIonix ionix) {
        this.ionix = ionix;
    }

    /**
     * Getter method for property <tt>netWorker</tt>.
     * 
     * @return property value of netWorker
     */
    public HealthCheckNetWorker getNetWorker() {
        return netWorker;
    }

    /**
     * Setter method for property <tt>netWorker</tt>.
     * 
     * @param netWorker
     *            value to be assigned to property netWorker
     */
    public void setNetWorker(HealthCheckNetWorker netWorker) {
        this.netWorker = netWorker;
    }

    /**
     * Getter method for property <tt>sanSecurity</tt>.
     * 
     * @return property value of sanSecurity
     */
    public HealthCheckSanSecurity getSanSecurity() {
        return sanSecurity;
    }

    /**
     * Setter method for property <tt>sanSecurity</tt>.
     * 
     * @param sanSecurity
     *            value to be assigned to property sanSecurity
     */
    public void setSanSecurity(HealthCheckSanSecurity sanSecurity) {
        this.sanSecurity = sanSecurity;
    }

    /**
     * Getter method for property <tt>sap</tt>.
     * 
     * @return property value of sap
     */
    public HealthCheckSAP getSap() {
        return sap;
    }

    /**
     * Setter method for property <tt>sap</tt>.
     * 
     * @param sap
     *            value to be assigned to property sap
     */
    public void setSap(HealthCheckSAP sap) {
        this.sap = sap;
    }

    /**
     * Getter method for property <tt>sourceOne</tt>.
     * 
     * @return property value of sourceOne
     */
    public HealthCheckSourceOne getSourceOne() {
        return sourceOne;
    }

    /**
     * Setter method for property <tt>sourceOne</tt>.
     * 
     * @param sourceOne
     *            value to be assigned to property sourceOne
     */
    public void setSourceOne(HealthCheckSourceOne sourceOne) {
        this.sourceOne = sourceOne;
    }

    /**
     * Getter method for property <tt>symmetrixVmax</tt>.
     * 
     * @return property value of symmetrixVmax
     */
    public HealthCheckSymmetrixVmax getSymmetrixVmax() {
        return symmetrixVmax;
    }

    /**
     * Setter method for property <tt>symmetrixVmax</tt>.
     * 
     * @param symmetrixVmax
     *            value to be assigned to property symmetrixVmax
     */
    public void setSymmetrixVmax(HealthCheckSymmetrixVmax symmetrixVmax) {
        this.symmetrixVmax = symmetrixVmax;
    }

    /**
     * Getter method for property <tt>symmetrixVmaxStorageReplication</tt>.
     * 
     * @return property value of symmetrixVmaxStorageReplication
     */
    public HealthCheckSymmetrixVmaxStorageReplication getSymmetrixVmaxStorageReplication() {
        return symmetrixVmaxStorageReplication;
    }

    /**
     * Setter method for property <tt>symmetrixVmaxStorageReplication</tt>.
     * 
     * @param symmetrixVmaxStorageReplication
     *            value to be assigned to property symmetrixVmaxStorageReplication
     */
    public void setSymmetrixVmaxStorageReplication(
            HealthCheckSymmetrixVmaxStorageReplication symmetrixVmaxStorageReplication) {
        this.symmetrixVmaxStorageReplication = symmetrixVmaxStorageReplication;
    }

    /**
     * Getter method for property <tt>unified</tt>.
     * 
     * @return property value of unified
     */
    public HealthCheckUnified getUnified() {
        return unified;
    }

    /**
     * Setter method for property <tt>unified</tt>.
     * 
     * @param unified
     *            value to be assigned to property unified
     */
    public void setUnified(HealthCheckUnified unified) {
        this.unified = unified;
    }

    /**
     * Getter method for property <tt>vblock</tt>.
     * 
     * @return property value of vblock
     */
    public HealthCheckVblock getVblock() {
        return vblock;
    }

    /**
     * Setter method for property <tt>vblock</tt>.
     * 
     * @param vblock
     *            value to be assigned to property vblock
     */
    public void setVblock(HealthCheckVblock vblock) {
        this.vblock = vblock;
    }

    /**
     * Getter method for property <tt>vmwareVirtualInfrastructure</tt>.
     * 
     * @return property value of vmwareVirtualInfrastructure
     */
    public HealthCheckVmwareVirtualInfrastructure getVmwareVirtualInfrastructure() {
        return vmwareVirtualInfrastructure;
    }

    /**
     * Setter method for property <tt>vmwareVirtualInfrastructure</tt>.
     * 
     * @param vmwareVirtualInfrastructure
     *            value to be assigned to property vmwareVirtualInfrastructure
     */
    public void setVmwareVirtualInfrastructure(HealthCheckVmwareVirtualInfrastructure vmwareVirtualInfrastructure) {
        this.vmwareVirtualInfrastructure = vmwareVirtualInfrastructure;
    }

    /**
     * Getter method for property <tt>vplex</tt>.
     * 
     * @return property value of vplex
     */
    public HealthCheckVplex getVplex() {
        return vplex;
    }

    /**
     * Setter method for property <tt>vplex</tt>.
     * 
     * @param vplex
     *            value to be assigned to property vplex
     */
    public void setVplex(HealthCheckVplex vplex) {
        this.vplex = vplex;
    }

}

/*
 * This code is copyright (c) 2014 EMC Corporation
 */
package com.emc.gs.tools.srf.model.asd;

import java.math.BigDecimal;

import com.emc.gs.tools.srf.model.IdentifiableEntity;

/**
 * <p>
 * This is ASDAppSync entity class.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safety.
 * </p>
 * <p>
 * 
 * @author TCSASSEMBLER
 * @version 1.0
 * @since SRT Phase 3-4 - ASD and Healthcheck Tabs Assembly
 */
public class ASDAppSync extends IdentifiableEntity {

    /**
     * Install VSI AppSync Management Plugin?
     */
    private Boolean installVSI;

    /**
     * # of AppSync Instances Installed?
     */
    private Integer appSyncInstancesNum;

    /**
     * # of vCenter Servers Discovered?
     */
    private Integer vCenterServersNum;

    /**
     * # of Application Production Hosts Discovered?
     */
    private Integer applicationProductionHostsNum;

    /**
     * # of VNX Arrays Discovered?
     */
    private Integer vnxArraysNum;

    /**
     * # of Application Mount Hosts Discovered?
     */
    private Integer applicationMountHostsNum;

    /**
     * # of RecoverPoint Appliances Discovered?
     */
    private Integer recoverPointAppliancesNum;

    /**
     * # of hours for additional knowledge transfer (IS effort)?
     */
    private BigDecimal knowledgeTransferHours;

    /**
     * <p>
     * The default constructor.
     * </p>
     */
    public ASDAppSync() {
    }

    /**
     * Getter method for property <tt>installVSI</tt>.
     * 
     * @return property value of installVSI
     */
    public Boolean getInstallVSI() {
        return installVSI;
    }

    /**
     * Setter method for property <tt>installVSI</tt>.
     * 
     * @param installVSI
     *            value to be assigned to property installVSI
     */
    public void setInstallVSI(Boolean installVSI) {
        this.installVSI = installVSI;
    }

    /**
     * Getter method for property <tt>appSyncInstancesNum</tt>.
     * 
     * @return property value of appSyncInstancesNum
     */
    public Integer getAppSyncInstancesNum() {
        return appSyncInstancesNum;
    }

    /**
     * Setter method for property <tt>appSyncInstancesNum</tt>.
     * 
     * @param appSyncInstancesNum
     *            value to be assigned to property appSyncInstancesNum
     */
    public void setAppSyncInstancesNum(Integer appSyncInstancesNum) {
        this.appSyncInstancesNum = appSyncInstancesNum;
    }

    /**
     * Getter method for property <tt>vCenterServersNum</tt>.
     * 
     * @return property value of vCenterServersNum
     */
    public Integer getvCenterServersNum() {
        return vCenterServersNum;
    }

    /**
     * Setter method for property <tt>vCenterServersNum</tt>.
     * 
     * @param vCenterServersNum
     *            value to be assigned to property vCenterServersNum
     */
    public void setvCenterServersNum(Integer vCenterServersNum) {
        this.vCenterServersNum = vCenterServersNum;
    }

    /**
     * Getter method for property <tt>applicationProductionHostsNum</tt>.
     * 
     * @return property value of applicationProductionHostsNum
     */
    public Integer getApplicationProductionHostsNum() {
        return applicationProductionHostsNum;
    }

    /**
     * Setter method for property <tt>applicationProductionHostsNum</tt>.
     * 
     * @param applicationProductionHostsNum
     *            value to be assigned to property applicationProductionHostsNum
     */
    public void setApplicationProductionHostsNum(Integer applicationProductionHostsNum) {
        this.applicationProductionHostsNum = applicationProductionHostsNum;
    }

    /**
     * Getter method for property <tt>vnxArraysNum</tt>.
     * 
     * @return property value of vnxArraysNum
     */
    public Integer getVnxArraysNum() {
        return vnxArraysNum;
    }

    /**
     * Setter method for property <tt>vnxArraysNum</tt>.
     * 
     * @param vnxArraysNum
     *            value to be assigned to property vnxArraysNum
     */
    public void setVnxArraysNum(Integer vnxArraysNum) {
        this.vnxArraysNum = vnxArraysNum;
    }

    /**
     * Getter method for property <tt>applicationMountHostsNum</tt>.
     * 
     * @return property value of applicationMountHostsNum
     */
    public Integer getApplicationMountHostsNum() {
        return applicationMountHostsNum;
    }

    /**
     * Setter method for property <tt>applicationMountHostsNum</tt>.
     * 
     * @param applicationMountHostsNum
     *            value to be assigned to property applicationMountHostsNum
     */
    public void setApplicationMountHostsNum(Integer applicationMountHostsNum) {
        this.applicationMountHostsNum = applicationMountHostsNum;
    }

    /**
     * Getter method for property <tt>recoverPointAppliancesNum</tt>.
     * 
     * @return property value of recoverPointAppliancesNum
     */
    public Integer getRecoverPointAppliancesNum() {
        return recoverPointAppliancesNum;
    }

    /**
     * Setter method for property <tt>recoverPointAppliancesNum</tt>.
     * 
     * @param recoverPointAppliancesNum
     *            value to be assigned to property recoverPointAppliancesNum
     */
    public void setRecoverPointAppliancesNum(Integer recoverPointAppliancesNum) {
        this.recoverPointAppliancesNum = recoverPointAppliancesNum;
    }

    /**
     * Getter method for property <tt>knowledgeTransferHours</tt>.
     * 
     * @return property value of knowledgeTransferHours
     */
    public BigDecimal getKnowledgeTransferHours() {
        return knowledgeTransferHours;
    }

    /**
     * Setter method for property <tt>knowledgeTransferHours</tt>.
     * 
     * @param knowledgeTransferHours
     *            value to be assigned to property knowledgeTransferHours
     */
    public void setKnowledgeTransferHours(BigDecimal knowledgeTransferHours) {
        this.knowledgeTransferHours = knowledgeTransferHours;
    }

}

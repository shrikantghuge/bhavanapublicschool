/*
 * This code is copyright (c) 2014 EMC Corporation
 */
package com.emc.gs.tools.srf.model.dpad;

import com.emc.gs.tools.srf.model.IdentifiableEntity;

/**
 * <p>
 * This is EDLDesignImpl entity class.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safety.
 * </p>
 * 
 * @author TCSASSEMBLER
 * @version 1.0
 * @since SRT Phase 3-5 - BRS Tabs Part 1 Assembly
 */
public class EDLDesignImpl extends IdentifiableEntity {

    /**
     * EMC Disk Library Feature: Replication.
     */
    private boolean replication;

    /**
     * EMC Disk Library Feature: ACSLS.
     */
    private boolean acsls;

    /**
     * EMC Disk Library Feature: Auto Engine Failover (AEF).
     */
    private boolean autoEngineFailover;

    /**
     * EMC Disk Library Feature: EDL Integrated Backup Application.
     */
    private boolean integratedBackupApplication;

    /**
     * # of EMC Disk Library Backend Storage Arrays.
     */
    private Integer backendStorageArraysNum;

    /**
     * # of Backup Servers (includes storage nodes / media servers).
     */
    private Integer backupServersNum;

    /**
     * # of Physical Tape Library Units to Which EMC Disk Library Writes.
     */
    private Integer physicalTapeLibUnitsNum;

    /**
     * # of EMC Disk Library Virtual Tape Libraries (VTL).
     */
    private Integer virtualTapeLibrariesNum;

    /**
     * # of EMC Disk Library Virtual Tapes.
     */
    private Integer virtualTapesNum;

    /**
     * # of Virtual Tape Drives.
     */
    private Integer virtualTapeDrivesNum;

    /**
     * # of EMC Disk Library Replications to Be Created.
     */
    private Integer replicationsCreatedNum;

    /**
     * <p>
     * The default constructor.
     * </p>
     */
    public EDLDesignImpl() {
    }

    /**
     * Getter method for property <tt>replication</tt>.
     * 
     * @return property value of replication
     */
    public boolean isReplication() {
        return replication;
    }

    /**
     * Setter method for property <tt>replication</tt>.
     * 
     * @param replication
     *            value to be assigned to property replication
     */
    public void setReplication(boolean replication) {
        this.replication = replication;
    }

    /**
     * Getter method for property <tt>acsls</tt>.
     * 
     * @return property value of acsls
     */
    public boolean isAcsls() {
        return acsls;
    }

    /**
     * Setter method for property <tt>acsls</tt>.
     * 
     * @param acsls
     *            value to be assigned to property acsls
     */
    public void setAcsls(boolean acsls) {
        this.acsls = acsls;
    }

    /**
     * Getter method for property <tt>autoEngineFailover</tt>.
     * 
     * @return property value of autoEngineFailover
     */
    public boolean isAutoEngineFailover() {
        return autoEngineFailover;
    }

    /**
     * Setter method for property <tt>autoEngineFailover</tt>.
     * 
     * @param autoEngineFailover
     *            value to be assigned to property autoEngineFailover
     */
    public void setAutoEngineFailover(boolean autoEngineFailover) {
        this.autoEngineFailover = autoEngineFailover;
    }

    /**
     * Getter method for property <tt>integratedBackupApplication</tt>.
     * 
     * @return property value of integratedBackupApplication
     */
    public boolean isIntegratedBackupApplication() {
        return integratedBackupApplication;
    }

    /**
     * Setter method for property <tt>integratedBackupApplication</tt>.
     * 
     * @param integratedBackupApplication
     *            value to be assigned to property integratedBackupApplication
     */
    public void setIntegratedBackupApplication(boolean integratedBackupApplication) {
        this.integratedBackupApplication = integratedBackupApplication;
    }

    /**
     * Getter method for property <tt>backendStorageArraysNum</tt>.
     * 
     * @return property value of backendStorageArraysNum
     */
    public Integer getBackendStorageArraysNum() {
        return backendStorageArraysNum;
    }

    /**
     * Setter method for property <tt>backendStorageArraysNum</tt>.
     * 
     * @param backendStorageArraysNum
     *            value to be assigned to property backendStorageArraysNum
     */
    public void setBackendStorageArraysNum(Integer backendStorageArraysNum) {
        this.backendStorageArraysNum = backendStorageArraysNum;
    }

    /**
     * Getter method for property <tt>backupServersNum</tt>.
     * 
     * @return property value of backupServersNum
     */
    public Integer getBackupServersNum() {
        return backupServersNum;
    }

    /**
     * Setter method for property <tt>backupServersNum</tt>.
     * 
     * @param backupServersNum
     *            value to be assigned to property backupServersNum
     */
    public void setBackupServersNum(Integer backupServersNum) {
        this.backupServersNum = backupServersNum;
    }

    /**
     * Getter method for property <tt>physicalTapeLibUnitsNum</tt>.
     * 
     * @return property value of physicalTapeLibUnitsNum
     */
    public Integer getPhysicalTapeLibUnitsNum() {
        return physicalTapeLibUnitsNum;
    }

    /**
     * Setter method for property <tt>physicalTapeLibUnitsNum</tt>.
     * 
     * @param physicalTapeLibUnitsNum
     *            value to be assigned to property physicalTapeLibUnitsNum
     */
    public void setPhysicalTapeLibUnitsNum(Integer physicalTapeLibUnitsNum) {
        this.physicalTapeLibUnitsNum = physicalTapeLibUnitsNum;
    }

    /**
     * Getter method for property <tt>virtualTapeLibrariesNum</tt>.
     * 
     * @return property value of virtualTapeLibrariesNum
     */
    public Integer getVirtualTapeLibrariesNum() {
        return virtualTapeLibrariesNum;
    }

    /**
     * Setter method for property <tt>virtualTapeLibrariesNum</tt>.
     * 
     * @param virtualTapeLibrariesNum
     *            value to be assigned to property virtualTapeLibrariesNum
     */
    public void setVirtualTapeLibrariesNum(Integer virtualTapeLibrariesNum) {
        this.virtualTapeLibrariesNum = virtualTapeLibrariesNum;
    }

    /**
     * Getter method for property <tt>virtualTapesNum</tt>.
     * 
     * @return property value of virtualTapesNum
     */
    public Integer getVirtualTapesNum() {
        return virtualTapesNum;
    }

    /**
     * Setter method for property <tt>virtualTapesNum</tt>.
     * 
     * @param virtualTapesNum
     *            value to be assigned to property virtualTapesNum
     */
    public void setVirtualTapesNum(Integer virtualTapesNum) {
        this.virtualTapesNum = virtualTapesNum;
    }

    /**
     * Getter method for property <tt>virtualTapeDrivesNum</tt>.
     * 
     * @return property value of virtualTapeDrivesNum
     */
    public Integer getVirtualTapeDrivesNum() {
        return virtualTapeDrivesNum;
    }

    /**
     * Setter method for property <tt>virtualTapeDrivesNum</tt>.
     * 
     * @param virtualTapeDrivesNum
     *            value to be assigned to property virtualTapeDrivesNum
     */
    public void setVirtualTapeDrivesNum(Integer virtualTapeDrivesNum) {
        this.virtualTapeDrivesNum = virtualTapeDrivesNum;
    }

    /**
     * Getter method for property <tt>replicationsCreatedNum</tt>.
     * 
     * @return property value of replicationsCreatedNum
     */
    public Integer getReplicationsCreatedNum() {
        return replicationsCreatedNum;
    }

    /**
     * Setter method for property <tt>replicationsCreatedNum</tt>.
     * 
     * @param replicationsCreatedNum
     *            value to be assigned to property replicationsCreatedNum
     */
    public void setReplicationsCreatedNum(Integer replicationsCreatedNum) {
        this.replicationsCreatedNum = replicationsCreatedNum;
    }

}

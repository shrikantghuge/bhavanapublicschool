/*
 * This code is copyright (c) 2014 EMC Corporation
 */
package com.emc.gs.tools.srf.model.healthcheck;

import com.emc.gs.tools.srf.model.IdentifiableEntity;

/**
 * <p>
 * This is HealthCheckDPA entity class.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safety.
 * </p>
 * <p>
 * 
 * @author TCSASSEMBLER
 * @version 1.0
 * @since SRT Phase 3-4 - ASD and Healthcheck Tabs Assembly
 */
public class HealthCheckDPA extends IdentifiableEntity {

    /**
     * # of DPA site implementations?
     */
    private Integer siteImplementationsNum;

    /**
     * <p>
     * The default constructor.
     * </p>
     */
    public HealthCheckDPA() {
    }

    /**
     * Getter method for property <tt>siteImplementationsNum</tt>.
     * 
     * @return property value of siteImplementationsNum
     */
    public Integer getSiteImplementationsNum() {
        return siteImplementationsNum;
    }

    /**
     * Setter method for property <tt>siteImplementationsNum</tt>.
     * 
     * @param siteImplementationsNum
     *            value to be assigned to property siteImplementationsNum
     */
    public void setSiteImplementationsNum(Integer siteImplementationsNum) {
        this.siteImplementationsNum = siteImplementationsNum;
    }

}

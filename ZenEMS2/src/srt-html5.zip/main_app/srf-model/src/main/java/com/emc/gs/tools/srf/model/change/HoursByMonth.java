/*
 * This code is copyright (c) 2014 EMC Corporation.
 */
package com.emc.gs.tools.srf.model.change;

import java.util.List;

import com.emc.gs.tools.srf.model.IdentifiableEntity;

/**
 * SAP WBS Element group record.
 * 
 * v1.1 - removed wbsElement field
 * @author TCSASSEMBLER
 * @version 1.1
 * @since SRT Phase 3-2 - Move Request and Change Request Tabs Assembly
 */
public class HoursByMonth extends IdentifiableEntity {

    /**
     * Current SAP WBS Element #.
     */
    private String currentSAPWBSElementNo;

    /**
     * Role.
     */
    private List<RoleHoursByMonth> rows;
    
    /**
     * Empty constructor.
     */
    public HoursByMonth() {
    }

    /**
     * Gets the value of the field <code>currentSAPWBSElementNo</code>.
     * @return the currentSAPWBSElementNo
     */
    public String getCurrentSAPWBSElementNo() {
        return currentSAPWBSElementNo;
    }

    /**
     * Sets the value of the field <code>currentSAPWBSElementNo</code>.
     * @param currentSAPWBSElementNo the currentSAPWBSElementNo to set
     */
    public void setCurrentSAPWBSElementNo(String currentSAPWBSElementNo) {
        this.currentSAPWBSElementNo = currentSAPWBSElementNo;
    }

    /**
     * Gets the value of the field <code>rows</code>.
     * @return the rows
     */
    public List<RoleHoursByMonth> getRows() {
        return rows;
    }

    /**
     * Sets the value of the field <code>rows</code>.
     * @param rows the rows to set
     */
    public void setRows(List<RoleHoursByMonth> rows) {
        this.rows = rows;
    }

    /**
     * Generates a string representation of this entity.
     * 
     * @return the properties of this object.
     */
    @Override
    public String toString() {
        return "HoursByMonth [currentSAPWBSElementNo=" + currentSAPWBSElementNo
            + ", rows=" + rows + ", getId()=" + getId() + "]";
    }
}

/*
 * This code is copyright (c) 2014 EMC Corporation.
 */
package com.emc.gs.tools.srf.model;

/**
 * <p>
 * This is AffinityOptions entity class.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safety.
 * </p>
 * @author liuliquan
 * @version 1.0
 */
public class AffinityOptions extends IdentifiableEntity {

    /**
     * <p>
     * The vmware.
     * </p>
     */
    private boolean vmware;

    /**
     * <p>
     * The pivotal.
     * </p>
     */
    private boolean pivotal;

    /**
     * <p>
     * The rsa.
     * </p>
     */
    private boolean rsa;

    /**
     * <p>
     * The vce.
     * </p>
     */
    private boolean vce;

    /**
     * <p>
     * The ecd.
     * </p>
     */
    private boolean ecd;

    /**
     * Empty constructor.
     */
    public AffinityOptions() {
    }

    /**
     * Getter method for property <tt>vmware</tt>.
     * @return property value of vmware
     */
    public boolean isVmware() {
        return vmware;
    }

    /**
     * Setter method for property <tt>vmware</tt>.
     * @param vmware
     *            value to be assigned to property vmware
     */
    public void setVmware(boolean vmware) {
        this.vmware = vmware;
    }

    /**
     * Getter method for property <tt>pivotal</tt>.
     * @return property value of pivotal
     */
    public boolean isPivotal() {
        return pivotal;
    }

    /**
     * Setter method for property <tt>pivotal</tt>.
     * @param pivotal
     *            value to be assigned to property pivotal
     */
    public void setPivotal(boolean pivotal) {
        this.pivotal = pivotal;
    }

    /**
     * Getter method for property <tt>rsa</tt>.
     * @return property value of rsa
     */
    public boolean isRsa() {
        return rsa;
    }

    /**
     * Setter method for property <tt>rsa</tt>.
     * @param rsa
     *            value to be assigned to property rsa
     */
    public void setRsa(boolean rsa) {
        this.rsa = rsa;
    }

    /**
     * Getter method for property <tt>vce</tt>.
     * @return property value of vce
     */
    public boolean isVce() {
        return vce;
    }

    /**
     * Setter method for property <tt>vce</tt>.
     * @param vce
     *            value to be assigned to property vce
     */
    public void setVce(boolean vce) {
        this.vce = vce;
    }

    /**
     * Getter method for property <tt>ecd</tt>.
     * @return property value of ecd
     */
    public boolean isEcd() {
        return ecd;
    }

    /**
     * Setter method for property <tt>ecd</tt>.
     * @param ecd
     *            value to be assigned to property ecd
     */
    public void setEcd(boolean ecd) {
        this.ecd = ecd;
    }

    /**
     * The toString method.
     * @return the string for this entity
     */
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("{").append(super.toString());
        sb.append(", vmware:").append(vmware);
        sb.append(", pivotal:").append(pivotal);
        sb.append(", rsa:").append(rsa);
        sb.append(", vce:").append(vce);
        sb.append(", ecd:").append(ecd).append("}");
        return sb.toString();
    }
}

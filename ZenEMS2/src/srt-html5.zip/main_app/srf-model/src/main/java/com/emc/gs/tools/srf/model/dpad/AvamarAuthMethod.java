/*
 * This code is copyright (c) 2014 EMC Corporation
 */
package com.emc.gs.tools.srf.model.dpad;

/**
 * The Avamar authentication method enum.
 * <p>
 * <strong>Thread safety</strong>: Enum is thread safety.
 * </p>
 * 
 * @author TCSASSEMBLER
 * @version 1.0
 * @since SRT Phase 3-5 - BRS Tabs Part 1 Assembly
 */
public enum AvamarAuthMethod {

    /**
     * Internal.
     */
    INTERNAL("Internal"),

    /**
     * Enterprise.
     */
    ENTERPRISE("Enterprise");

    /**
     * The description.
     */
    private final String description;

    /**
     * <p>
     * The constructor with description.
     * </p>
     * 
     * @param description
     *            the description
     */
    private AvamarAuthMethod(String description) {
        this.description = description;
    }

    /**
     * Override the toString method.
     * 
     * @return the description
     */
    @Override
    public String toString() {
        return description;
    }
}

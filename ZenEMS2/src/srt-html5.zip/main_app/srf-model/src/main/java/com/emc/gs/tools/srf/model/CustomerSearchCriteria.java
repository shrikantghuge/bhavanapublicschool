/*
 * This code is copyright (c) 2013 - 2015 EMC Corporation.
 */
package com.emc.gs.tools.srf.model;

/**
 * <p>
 * This is CustomerSearchCriteria entity class.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safety.
 * </p>
 * 
 * <p>
 * <strong>Changes V1.2:</strong>
 * <ul>
 * <li>Removed shortName field.</li>
 * </ul>
 * </p>
 * 
 * <p>
 * <strong>Changes V1.3:</strong>
 * <strong>SRT HTML5 ET Production Fixes Part 2 Assembly 1.0</strong>
 * <ul>
 * <li>add the country attribute</li>
 * </ul>
 * </p>
 * @author faeton, stevenfrog, MonicaMuranyi, TCSASSEMBLER
 * @version 1.3
 */
public class CustomerSearchCriteria extends BaseSearchParams {
    /**
     * <p>
     * The name.
     * </p>
     */
    private String name;

    /**
     * <p>
     * The formalName.
     * </p>
     */
    private String formalName;

    /**
     * <p>
     * The address.
     * </p>
     */
    private String address;

    /**
     * <p>
     * The city.
     * </p>
     */
    private String city;

    /**
     * <p>
     * The state.
     * </p>
     */
    private String state;

    /**
     * <p>
     * The zip.
     * </p>
     */
    private String zip;
    
    /**
     * <p>
     * The country.
     * </p>
     */
    private String country;

    /**
     * <p>
     * The default constructor.
     * </p>
     */
    public CustomerSearchCriteria() {
        // Empty
    }

    /**
     * <p>
     * Retrieves the name field.
     * </p>
     *
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * <p>
     * Sets the value to name field.
     * </p>
     *
     * @param name
     *            the name to set
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * <p>
     * Retrieves the formalName field.
     * </p>
     *
     * @return the formalName
     */
    public String getFormalName() {
        return formalName;
    }

    /**
     * <p>
     * Sets the value to formalName field.
     * </p>
     *
     * @param formalName
     *            the formalName to set
     */
    public void setFormalName(String formalName) {
        this.formalName = formalName;
    }

    /**
     * <p>
     * Retrieves the address field.
     * </p>
     *
     * @return the address
     */
    public String getAddress() {
        return address;
    }

    /**
     * <p>
     * Sets the value to address field.
     * </p>
     *
     * @param address
     *            the address to set
     */
    public void setAddress(String address) {
        this.address = address;
    }

    /**
     * <p>
     * Retrieves the city field.
     * </p>
     *
     * @return the city
     */
    public String getCity() {
        return city;
    }

    /**
     * <p>
     * Sets the value to city field.
     * </p>
     *
     * @param city
     *            the city to set
     */
    public void setCity(String city) {
        this.city = city;
    }

    /**
     * <p>
     * Retrieves the state field.
     * </p>
     *
     * @return the state
     */
    public String getState() {
        return state;
    }

    /**
     * <p>
     * Sets the value to state field.
     * </p>
     *
     * @param state
     *            the state to set
     */
    public void setState(String state) {
        this.state = state;
    }

    /**
     * <p>
     * Retrieves the zip field.
     * </p>
     *
     * @return the zip
     */
    public String getZip() {
        return zip;
    }

    /**
     * <p>
     * Sets the value to zip field.
     * </p>
     *
     * @param zip
     *            the zip to set
     */
    public void setZip(String zip) {
        this.zip = zip;
    }
    
    /**
     * <p>
     *     Gets the country
     * </p>
     *
     * @return the country
     */
    public String getCountry() {
        return country;
    }

    /**
     * <p>
     *     Sets the country
     * </p>
     * @param country
     *          the country to set
     */
    public void setCountry(String country) {
        this.country = country;
    }
    

    /**
     * The toString method.
     *
     * @return the string for this entity
     */
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("{").append(super.toString());
        sb.append(", name:").append(name);
        sb.append(", formalName:").append(formalName);
        sb.append(", address:").append(address);
        sb.append(", city:").append(city);
        sb.append(", state:").append(state);
        sb.append(", zip:").append(zip);
        sb.append(", country").append(country).append("}");
        return sb.toString();
    }
}

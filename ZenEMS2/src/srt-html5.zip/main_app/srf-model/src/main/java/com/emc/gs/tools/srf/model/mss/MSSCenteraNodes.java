/*
 * This code is copyright (c) 2014 EMC Corporation
 */
package com.emc.gs.tools.srf.model.mss;

import com.emc.gs.tools.srf.model.IdentifiableEntity;

/**
 * <p>
 * This is Centera nodes of MSSArray entity class.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safe.
 * </p>
 * <p>
 * <strong>Changes V1.1:</strong> <strong>SRT Phase 3-1 - CTA Rainfinity and MSS Tabs Update Assembly</strong>
 * <ul>
 * <li>Add gen4LPNodes2TB field.</li>
 * </ul>
 * </p>
 * 
 * @author TCSASSEMBLER
 * @version 1.1
 * @since SRT Phase 3-1 - CTA Rainfinity and MSS Tabs Assembly
 */
public class MSSCenteraNodes extends IdentifiableEntity {

    /**
     * Gen-1 640GB nodes.
     */
    private String gen1Nodes640GB;

    /**
     * Gen-2 1TB nodes.
     */
    private String gen2Nodes1TB;

    /**
     * Gen-3 1.28TB nodes.
     */
    private String gen3Nodes128TB;

    /**
     * Gen-4 750GB nodes.
     */
    private String gen4Nodes750GB;

    /**
     * Gen-4 1.28TB nodes.
     */
    private String gen4Nodes128TB;

    /**
     * Gen-4 2TB nodes.
     */
    private String gen4Nodes2TB;

    /**
     * Gen-4LP 1TB drive nodes.
     */
    private String gen4LPNodes1TB;

    /**
     * Gen-4LP 2TB drive nodes.
     */
    private String gen4LPNodes2TB;

    /**
     * Other Centera nodes.
     */
    private String otherCenteraNodes;

    /**
     * <p>
     * The default constructor.
     * </p>
     */
    public MSSCenteraNodes() {
    }

    /**
     * Getter method for property <tt>gen1Nodes640GB</tt>.
     * 
     * @return property value of gen1Nodes640GB
     */
    public String getGen1Nodes640GB() {
        return gen1Nodes640GB;
    }

    /**
     * Setter method for property <tt>gen1Nodes640GB</tt>.
     * 
     * @param gen1Nodes640GB
     *            value to be assigned to property gen1Nodes640GB
     */
    public void setGen1Nodes640GB(String gen1Nodes640GB) {
        this.gen1Nodes640GB = gen1Nodes640GB;
    }

    /**
     * Getter method for property <tt>gen2Nodes1TB</tt>.
     * 
     * @return property value of gen2Nodes1TB
     */
    public String getGen2Nodes1TB() {
        return gen2Nodes1TB;
    }

    /**
     * Setter method for property <tt>gen2Nodes1TB</tt>.
     * 
     * @param gen2Nodes1TB
     *            value to be assigned to property gen2Nodes1TB
     */
    public void setGen2Nodes1TB(String gen2Nodes1TB) {
        this.gen2Nodes1TB = gen2Nodes1TB;
    }

    /**
     * Getter method for property <tt>gen3Nodes128TB</tt>.
     * 
     * @return property value of gen3Nodes128TB
     */
    public String getGen3Nodes128TB() {
        return gen3Nodes128TB;
    }

    /**
     * Setter method for property <tt>gen3Nodes128TB</tt>.
     * 
     * @param gen3Nodes128TB
     *            value to be assigned to property gen3Nodes128TB
     */
    public void setGen3Nodes128TB(String gen3Nodes128TB) {
        this.gen3Nodes128TB = gen3Nodes128TB;
    }

    /**
     * Getter method for property <tt>gen4Nodes750GB</tt>.
     * 
     * @return property value of gen4Nodes750GB
     */
    public String getGen4Nodes750GB() {
        return gen4Nodes750GB;
    }

    /**
     * Setter method for property <tt>gen4Nodes750GB</tt>.
     * 
     * @param gen4Nodes750GB
     *            value to be assigned to property gen4Nodes750GB
     */
    public void setGen4Nodes750GB(String gen4Nodes750GB) {
        this.gen4Nodes750GB = gen4Nodes750GB;
    }

    /**
     * Getter method for property <tt>gen4Nodes128TB</tt>.
     * 
     * @return property value of gen4Nodes128TB
     */
    public String getGen4Nodes128TB() {
        return gen4Nodes128TB;
    }

    /**
     * Setter method for property <tt>gen4Nodes128TB</tt>.
     * 
     * @param gen4Nodes128TB
     *            value to be assigned to property gen4Nodes128TB
     */
    public void setGen4Nodes128TB(String gen4Nodes128TB) {
        this.gen4Nodes128TB = gen4Nodes128TB;
    }

    /**
     * Getter method for property <tt>gen4Nodes2TB</tt>.
     * 
     * @return property value of gen4Nodes2TB
     */
    public String getGen4Nodes2TB() {
        return gen4Nodes2TB;
    }

    /**
     * Setter method for property <tt>gen4Nodes2TB</tt>.
     * 
     * @param gen4Nodes2TB
     *            value to be assigned to property gen4Nodes2TB
     */
    public void setGen4Nodes2TB(String gen4Nodes2TB) {
        this.gen4Nodes2TB = gen4Nodes2TB;
    }

    /**
     * Getter method for property <tt>gen4LPNodes1TB</tt>.
     * 
     * @return property value of gen4LPNodes1TB
     */
    public String getGen4LPNodes1TB() {
        return gen4LPNodes1TB;
    }

    /**
     * Setter method for property <tt>gen4LPNodes1TB</tt>.
     * 
     * @param gen4LPNodes1TB
     *            value to be assigned to property gen4LPNodes1TB
     */
    public void setGen4LPNodes1TB(String gen4lpNodes1TB) {
        gen4LPNodes1TB = gen4lpNodes1TB;
    }

    /**
     * Getter method for property <tt>gen4LPNodes2TB</tt>.
     * 
     * @return property value of gen4LPNodes2TB
     */
    public String getGen4LPNodes2TB() {
        return gen4LPNodes2TB;
    }

    /**
     * Setter method for property <tt>gen4LPNodes2TB</tt>.
     * 
     * @param gen4LPNodes2TB
     *            value to be assigned to property gen4LPNodes2TB
     */
    public void setGen4LPNodes2TB(String gen4lpNodes2TB) {
        gen4LPNodes2TB = gen4lpNodes2TB;
    }

    /**
     * Getter method for property <tt>otherCenteraNodes</tt>.
     * 
     * @return property value of otherCenteraNodes
     */
    public String getOtherCenteraNodes() {
        return otherCenteraNodes;
    }

    /**
     * Setter method for property <tt>otherCenteraNodes</tt>.
     * 
     * @param otherCenteraNodes
     *            value to be assigned to property otherCenteraNodes
     */
    public void setOtherCenteraNodes(String otherCenteraNodes) {
        this.otherCenteraNodes = otherCenteraNodes;
    }

}

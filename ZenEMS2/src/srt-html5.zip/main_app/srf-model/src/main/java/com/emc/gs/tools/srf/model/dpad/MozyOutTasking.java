/*
 * This code is copyright (c) 2014 EMC Corporation
 */
package com.emc.gs.tools.srf.model.dpad;

import com.emc.gs.tools.srf.model.IdentifiableEntity;

import java.math.BigDecimal;
import java.util.Date;

/**
 * <p>This is MozyOutTasking entity class.</p>
 *
 * <p><strong>Thread safety</strong>: This class is mutable, it is not thread safety.</p>
 *
 * @author TCSASSEMBLER
 * @version 1.0
 * @since SRT Phase 3 Pilot - Mozy and Xtrem and Vipr Tabs Assembly
 */
public class MozyOutTasking extends IdentifiableEntity {

    /**
     * <p>A <code>Date</code> providing the out tasking start date.</p>
     */
    private Date outTaskingStartDate;

    /**
     * <p>A <code>BigDecimal</code> providing the hours for Mozy Out Tasking.</p>
     */
    private BigDecimal hoursForMozyOutTasking;

    /**
     * <p>Constructs new <code>MozyOutTasking</code> instance. This implementation does nothing.</p>
     */
    public MozyOutTasking() {
    }

    /**
     * <p>Gets the out tasking start date.</p>
     *
     * @return a <code>Date</code> providing the out tasking start date.
     */
    public Date getOutTaskingStartDate() {
        return this.outTaskingStartDate;
    }

    /**
     * <p>Sets the out tasking start date.</p>
     *
     * @param outTaskingStartDate a <code>Date</code> providing the out tasking start date.
     */
    public void setOutTaskingStartDate(Date outTaskingStartDate) {
        this.outTaskingStartDate = outTaskingStartDate;
    }

    /**
     * <p>Gets the hours for Mozy Out Tasking.</p>
     *
     * @return a <code>BigDecimal</code> providing the hours for Mozy Out Tasking.
     */
    public BigDecimal getHoursForMozyOutTasking() {
        return this.hoursForMozyOutTasking;
    }

    /**
     * <p>Sets the hours for Mozy Out Tasking.</p>
     *
     * @param hoursForMozyOutTasking a <code>BigDecimal</code> providing the hours for Mozy Out Tasking.
     */
    public void setHoursForMozyOutTasking(BigDecimal hoursForMozyOutTasking) {
        this.hoursForMozyOutTasking = hoursForMozyOutTasking;
    }

}

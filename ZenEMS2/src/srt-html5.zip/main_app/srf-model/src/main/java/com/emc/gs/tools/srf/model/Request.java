/*
 * This code is copyright (c) 2013 - 2015 EMC Corporation.
 */
package com.emc.gs.tools.srf.model;

import com.emc.gs.tools.srf.model.asd.ASDRequestData;
import com.emc.gs.tools.srf.model.atmos.AtmosCenteraRequestData;
import com.emc.gs.tools.srf.model.bc.BcRequestData;
import com.emc.gs.tools.srf.model.change.ChangeRequestData;
import com.emc.gs.tools.srf.model.cta.CTARequestData;
import com.emc.gs.tools.srf.model.deal.DealGovernanceData;
import com.emc.gs.tools.srf.model.deal.RiskCalculationData;
import com.emc.gs.tools.srf.model.dpad.DPADRequestData;
import com.emc.gs.tools.srf.model.engagement.EngagementTypeData;
import com.emc.gs.tools.srf.model.estimate.EstimatesData;
import com.emc.gs.tools.srf.model.healthcheck.HealthCheckRequestData;
import com.emc.gs.tools.srf.model.infrastructure.InfrastructureRequestData;
import com.emc.gs.tools.srf.model.infrastructure.SanTanInformation;
import com.emc.gs.tools.srf.model.isilon.IsilonRequestData;
import com.emc.gs.tools.srf.model.mainframe.MainframeRequestData;
import com.emc.gs.tools.srf.model.move.MoveRequestData;
import com.emc.gs.tools.srf.model.mss.MSSRequestData;
import com.emc.gs.tools.srf.model.residency.ResidencyRequestData;
import com.emc.gs.tools.srf.model.sourceone.SourceOneRequestData;
import com.emc.gs.tools.srf.model.srm.SRMRequestData;
import com.emc.gs.tools.srf.model.unfunded.UnfundedProjectData;
import com.emc.gs.tools.srf.model.unified.UnifiedRequestData;
import com.emc.gs.tools.srf.model.vblock.VblockRequestData;
import com.emc.gs.tools.srf.model.vipr.ViprRequestData;
import com.emc.gs.tools.srf.model.vmware.VMwareRequestData;
import com.emc.gs.tools.srf.model.w4n.W4NData;
import com.emc.gs.tools.srf.model.xtreme.XtremeRequestData;

import java.util.Date;
import java.util.List;

/**
 * <p>
 * This model represents Request data model.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safety.
 * </p>
 * <p>
 * <strong>Changes V1.1:</strong> <strong>SRT Bug Fixes</strong>
 * <ul>
 * <li>Removed dateSubmitted field.</li>
 * </ul>
 * </p>
 * <p>
 * <strong>Changes V1.2:</strong> <strong>BRS Tab Assembly</strong>
 * <ul>
 * <li>Add brsRequestData field.</li>
 * </ul>
 * </p>
 * <p>
 * <strong>Changes V1.3:</strong> <strong>CTA Rainfinity and MSS Tabs Assembly</strong>
 * <ul>
 * <li>Add mssRequestData/ctaRequestData fields.</li>
 * </ul>
 * </p>
 * <p>
 * <strong>Changes V1.4:</strong> <strong>Isilon and Residency Tabs Assembly</strong>
 * <ul>
 * <li>Add isilonRequestData/residencyRequestData fields.</li>
 * </ul>
 * </p>
 * <p>
 * <strong>Changes V1.5:</strong> <strong>SRT Phase 3-3 - Remove BRS and Isilon and Update Residency and Implement
 * SourceOne Tabs Assembly</strong>
 * <ul>
 * <li>Remove brsRequestData/isilonRequestData fields.</li>
 * <li>Add sourceOneRequestData field.</li>
 * </ul>
 * </p>
 * <p>
 * <strong>Changes V1.6:</strong> <strong>SRT Phase 3-4 - ASD and Healthcheck Tabs Assembly</strong>
 * <ul>
 * <li>Add asdRequestData/healthCheckRequestData fields.</li>
 * </ul>
 * </p>
 * <p>
 * <strong>Changes V1.7:</strong> <strong>SRT Phase 3-3 - Implement Isilon and ViPR Tabs Assembly</strong>
 * <ul>
 * <li>Add isilonRequestData/viprRequestData fields.</li>
 * </ul>
 * </p>
 * <p>
 * <strong>Changes V1.8:</strong> <strong>SRT Phase 3-1 - Atmos Centera and Vblock Tabs Assembly</strong>
 * <ul>
 * <li>Add atmosRequestData/vblockRequestData fields.</li>
 * </ul>
 * </p>
 * <p>
 * <strong>Changes V1.9:</strong> <strong>SRT Phase 3-5 - BRS Tabs Part 1 Assembly</strong>
 * <ul>
 * <li>Add dpadRequestData field.</li>
 * </ul>
 * </p>
 * <p>
 * <strong>Changes V2.0:</strong> <strong>SRT Phase 3-1 - Implement VMWare Tab Assembly</strong>
 * <ul>
 * <li>Add vmwareRequestData field.</li>
 * </ul>
 * </p>
 * <p>
 * <strong>Changes V2.1:</strong> <strong>SRT Phase 3 Merge Assembly</strong>
 * <ul>
 * <li>Add moveRequestData/changeRequestData/w4nData/unfundedProjectData/srmRequestData fields.</li>
 * </ul>
 * </p>
 *
 * <p>
 * Version 2.2 (SRT Phase 3 Pilot - Mozy and Xtrem and Vipr Tabs Assembly) Change notes:
 *   <ol>
 *     <li>Added {@link #xtremeRequestData} property.</li>
 *   </ol>
 * </p>
 *
 * <p>
 * <strong>Changes V2.3:</strong> <strong>SRT Phase 4 - ET Assembly 1</strong>
 * <ul>
 * <li>Add engagementTypeData/dealGovernanceData/estimatesData fields.</li>
 * </ul>
 * </p>
 *
 * <p>
 * <strong>Changes V2.4:</strong> <strong>SRT Phase 4 - ET Assembly 2</strong>
 * <ul>
 * <li>Change to extend from CorrelatedIdentifiableEntity.</li>
 * </ul>
 * </p>
 *
 * <p>
 * Version 2.4 (SRT Phase 4 - ET Release Assembly) Change notes:
 *   <ol>
 *     <li>Added {@link #projectRegulatoryType} property.</li>
 *     <li>Added {@link #projectStartDate} property.</li>
 *     <li>Added {@link #projectEndDate} property.</li>
 *   </ol>
 * </p>
 *
 * <p>
 * Version 2.5 (SRT 1.1 DEC 2014 Risk Calculation Assembly) Change notes:
 *   <ol>
 *     <li>Added {@link #riskCalculationData} property.</li>
 *   </ol>
 * </p>
 *
 * <p>
 * Version 2.6  Change notes:
 *   <ol>
 *     <li>Added {@link #projectDescription} property.</li>
 *   </ol>
 * </p>
 *
 * <p>
 * Version 2.7  Change notes:
 *   <ol>
 *     <li>Added {@link #sanTanInformation} property.</li>
 *   </ol>
 * </p>
 * 
 * <p>
 * <strong>Changes V2.8:</strong>
 * <strong>SRT 1.1 Approval Process Assembly</strong>
 * <ul>
 * <li>Added additionalRecipients and approver fields.</li>
 * </ul>
 * </p>
 * 
 * @author faeton, stevenfrog, isv, MonicaMuranyi
 * @version 2.8
 */
public class Request extends CorrelatedIdentifiableEntity {

    /**
     * <p>A <code>RiskCalculationData</code> providing the value for "riskCalculationData" property.</p>
     * 
     * @since 2.5
     */
    private RiskCalculationData riskCalculationData; 

    /**
     * <p>
     * The customer.
     * </p>
     */
    private Customer customer;

    /**
     * <p>
     * The requestStatus.
     * </p>
     */
    private RequestStatus requestStatus = RequestStatus.DRAFT;

    /**
     * <p>
     * The requestType.
     * </p>
     */
    private RequestType requestType;

    /**
     * <p>
     * The projectName.
     * </p>
     */
    private String projectName;

    /**
     * <p>
     * The projectType.
     * </p>
     */
    private ProjectType projectType;

    /**
     * <p>
     * The startRequestData.
     * </p>
     */
    private StartRequestData startRequestData;

    /**
     * <p>
     * The mainframeRequestData.
     * </p>
     */
    private MainframeRequestData mainframeRequestData;

    /**
     * <p>
     * The infrastuctureRequestData.
     * </p>
     */
    private InfrastructureRequestData infrastuctureRequestData;

    /**
     * <p>
     * The bcRequestData.
     * </p>
     */
    private BcRequestData bcRequestData;

    /**
     * <p>
     * The unifiedRequestData.
     * </p>
     */
    private UnifiedRequestData unifiedRequestData;

    /**
     * <p>
     * The mssRequestData.
     * </p>
     * 
     * @since SRT Phase 3-1 - CTA Rainfinity and MSS Tabs Assembly
     */
    private MSSRequestData mssRequestData;

    /**
     * <p>
     * The ctaRequestData.
     * </p>
     * 
     * @since SRT Phase 3-1 - CTA Rainfinity and MSS Tabs Assembly
     */
    private CTARequestData ctaRequestData;

    /**
     * <p>
     * The residencyRequestData.
     * </p>
     * 
     * @since SRT Phase 3-3 - Isilon and Residency Tabs Assembly
     */
    private ResidencyRequestData residencyRequestData;

    /**
     * <p>
     * The sourceOneRequestData.
     * </p>
     * 
     * @since SRT Phase 3-3 - Remove BRS and Isilon and Update Residency and Implement SourceOne Tabs Assembly
     */
    private SourceOneRequestData sourceOneRequestData;

    /**
     * <p>
     * The asdRequestData.
     * </p>
     * 
     * @since SRT Phase 3-4 - ASD and Healthcheck Tabs Assembly
     */
    private ASDRequestData asdRequestData;

    /**
     * <p>
     * The healthCheckRequestData.
     * </p>
     * 
     * @since SRT Phase 3-4 - ASD and Healthcheck Tabs Assembly
     */
    private HealthCheckRequestData healthCheckRequestData;

    /**
     * <p>
     * The isilonRequestData.
     * </p>
     * 
     * @since SRT Phase 3-3 - Implement Isilon and ViPR Tabs Assembly
     */
    private IsilonRequestData isilonRequestData;

    /**
     * <p>
     * The viprRequestData.
     * </p>
     * 
     * @since SRT Phase 3-3 - Implement Isilon and ViPR Tabs Assembly
     */
    private ViprRequestData viprRequestData;

    /**
     * <p>
     * The atmosRequestData.
     * </p>
     * 
     * @since SRT Phase 3-1 - Atmos Centera and Vblock Tabs Assembly
     */
    private AtmosCenteraRequestData atmosRequestData;

    /**
     * <p>
     * The vblockRequestData.
     * </p>
     * 
     * @since SRT Phase 3-1 - Atmos Centera and Vblock Tabs Assembly
     */
    private VblockRequestData vblockRequestData;

    /**
     * <p>
     * The dpadRequestData.
     * </p>
     * 
     * @since SRT Phase 3-5 - BRS Tabs Part 1 Assembly
     */
    private DPADRequestData dpadRequestData;

    /**
     * <p>
     * The vmwareRequestData.
     * </p>
     * 
     * @since SRT Phase 3-1 - Implement VMWare Tab Assembly
     */
    private VMwareRequestData vmwareRequestData;

    /**
     * <p>
     * The moveRequestData.
     * </p>
     * 
     * @since SRT Phase 3-2 - Move Request and Change Request Tabs Assembly
     */
    private MoveRequestData moveRequestData;

    /**
     * <p>
     * The changeRequestData.
     * </p>
     * 
     * @since SRT Phase 3-2 - Move Request and Change Request Tabs Assembly
     */
    private ChangeRequestData changeRequestData;

    /**
     * <p>
     * The w4nData.
     * </p>
     * 
     * @since SRT Phase 3-2 - W4N and Unfunded Project Tabs Assembly
     */
    private W4NData w4nData;

    /**
     * <p>
     * The unfundedProjectData.
     * </p>
     * 
     * @since SRT Phase 3-2 - W4N and Unfunded Project Tabs Assembly
     */
    private UnfundedProjectData unfundedProjectData;

    /**
     * <p>
     * The SRM Request Data.
     * </p>
     * 
     * @since SRT Phase 3-2 - Implement SRM and Update Change Request and Move Request Tabs Assembly
     */
    private SRMRequestData srmRequestData;

    /**
     * <p>A <code>XtremeRequestData</code> providing the data for Xtreme tab.</p>
     *
     * @since 2.2
     */
    private XtremeRequestData xtremeRequestData;

    /**
     * <p>
     * The Engagement Type Data.
     * </p>
     * 
     * @since SRT Phase 4 - ET Assembly 1
     */
    private EngagementTypeData engagementTypeData;

    /**
     * <p>
     * The Deal Governance Data.
     * </p>
     * 
     * @since SRT Phase 4 - ET Assembly 1
     */
    private DealGovernanceData dealGovernanceData;

    /**
     * <p>
     * The Estimates Data.
     * </p>
     * 
     * @since SRT Phase 4 - ET Assembly 1
     */
    private EstimatesData estimatesData;

    /**
     * <p>A <code>ProjectRegulatoryType</code> providing the value for projectRegulatoryType property.</p>
     *
     * @since 2.4
     */
    private ProjectRegulatoryType projectRegulatoryType;

    /**
     * <p>A <code>Date</code> providing the value for projectStartDate property.</p>
     *
     * @since 2.4
     */
    private Date projectStartDate;

    /**
     * <p>A <code>Date</code> providing the value for projectEndDate property.</p>
     *
     * @since 2.4
     */
    private Date projectEndDate;

    /**
     * <p>A <code>String</code> providing the value for "Project Description" property.</p>
     * 
     * @since 2.6
     */
    private String projectDescription;

    /**
     * <p> The sanTanInformation. </p>
     * 
     * @since 2.7
     */
    private SanTanInformation sanTanInformation;
    
    /**
     * <p>
     * The approver.
     * </p>
     * @since 2.8
     */
    private Profile approver;
    
    /**
     * <p>
     * The additionalRecipients.
     * </p>
     * @since 2.8
     */
    private List<Profile> additionalRecipients;

    /**
     * <p>
     * The default constructor.
     * </p>
     */
    public Request() {
        // Empty
    }

    /**
     * <p>
     * Retrieves the customer field.
     * </p>
     * 
     * @return the customer
     */
    public Customer getCustomer() {
        return customer;
    }

    /**
     * <p>
     * Sets the value to customer field.
     * </p>
     * 
     * @param customer
     *            the customer to set
     */
    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    /**
     * <p>
     * Retrieves the requestStatus field.
     * </p>
     * 
     * @return the requestStatus
     */
    public RequestStatus getRequestStatus() {
        return requestStatus;
    }

    /**
     * <p>
     * Sets the value to requestStatus field.
     * </p>
     * 
     * @param requestStatus
     *            the requestStatus to set
     */
    public void setRequestStatus(RequestStatus requestStatus) {
        this.requestStatus = requestStatus;
    }

    /**
     * <p>
     * Retrieves the requestType field.
     * </p>
     * 
     * @return the requestType
     */
    public RequestType getRequestType() {
        return requestType;
    }

    /**
     * <p>
     * Sets the value to requestType field.
     * </p>
     * 
     * @param requestType
     *            the requestType to set
     */
    public void setRequestType(RequestType requestType) {
        this.requestType = requestType;
    }

    /**
     * <p>
     * Retrieves the projectName field.
     * </p>
     * 
     * @return the projectName
     */
    public String getProjectName() {
        return projectName;
    }

    /**
     * <p>
     * Sets the value to projectName field.
     * </p>
     * 
     * @param projectName
     *            the projectName to set
     */
    public void setProjectName(String projectName) {
        this.projectName = projectName;
    }

    /**
     * <p>
     * Retrieves the projectType field.
     * </p>
     * 
     * @return the projectType
     */
    public ProjectType getProjectType() {
        return projectType;
    }

    /**
     * <p>
     * Sets the value to projectType field.
     * </p>
     * 
     * @param projectType
     *            the projectType to set
     */
    public void setProjectType(ProjectType projectType) {
        this.projectType = projectType;
    }

    /**
     * <p>
     * Retrieves the startRequestData field.
     * </p>
     * 
     * @return the startRequestData
     */
    public StartRequestData getStartRequestData() {
        return startRequestData;
    }

    /**
     * <p>
     * Sets the value to startRequestData field.
     * </p>
     * 
     * @param startRequestData
     *            the startRequestData to set
     */
    public void setStartRequestData(StartRequestData startRequestData) {
        this.startRequestData = startRequestData;
    }

    /**
     * <p>
     * Retrieves the mainframeRequestData field.
     * </p>
     * 
     * @return the mainframeRequestData
     */
    public MainframeRequestData getMainframeRequestData() {
        return mainframeRequestData;
    }

    /**
     * <p>
     * Sets the value to mainframeRequestData field.
     * </p>
     * 
     * @param mainframeRequestData
     *            the mainframeRequestData to set
     */
    public void setMainframeRequestData(MainframeRequestData mainframeRequestData) {
        this.mainframeRequestData = mainframeRequestData;
    }

    /**
     * <p>
     * Retrieves the infrastuctureRequestData field.
     * </p>
     * 
     * @return the infrastuctureRequestData
     */
    public InfrastructureRequestData getInfrastuctureRequestData() {
        return infrastuctureRequestData;
    }

    /**
     * <p>
     * Sets the value to infrastuctureRequestData field.
     * </p>
     * 
     * @param infrastuctureRequestData
     *            the infrastuctureRequestData to set
     */
    public void setInfrastuctureRequestData(InfrastructureRequestData infrastuctureRequestData) {
        this.infrastuctureRequestData = infrastuctureRequestData;
    }

    /**
     * <p>
     * Retrieves the bcRequestData field.
     * </p>
     * 
     * @return the bcRequestData
     */
    public BcRequestData getBcRequestData() {
        return bcRequestData;
    }

    /**
     * <p>
     * Sets the value to bcRequestData field.
     * </p>
     * 
     * @param bcRequestData
     *            the bcRequestData to set
     */
    public void setBcRequestData(BcRequestData bcRequestData) {
        this.bcRequestData = bcRequestData;
    }

    /**
     * <p>
     * Retrieves the unifiedRequestData field.
     * </p>
     * 
     * @return the unifiedRequestData
     */
    public UnifiedRequestData getUnifiedRequestData() {
        return unifiedRequestData;
    }

    /**
     * <p>
     * Sets the value to unifiedRequestData field.
     * </p>
     * 
     * @param unifiedRequestData
     *            the unifiedRequestData to set
     */
    public void setUnifiedRequestData(UnifiedRequestData unifiedRequestData) {
        this.unifiedRequestData = unifiedRequestData;
    }

    /**
     * Getter method for property <tt>mssRequestData</tt>.
     * 
     * @return property value of mssRequestData
     * @since SRT Phase 3-1 - CTA Rainfinity and MSS Tabs Assembly
     */
    public MSSRequestData getMssRequestData() {
        return mssRequestData;
    }

    /**
     * Setter method for property <tt>mssRequestData</tt>.
     * 
     * @param mssRequestData
     *            value to be assigned to property mssRequestData
     * @since SRT Phase 3-1 - CTA Rainfinity and MSS Tabs Assembly
     */
    public void setMssRequestData(MSSRequestData mssRequestData) {
        this.mssRequestData = mssRequestData;
    }

    /**
     * Getter method for property <tt>ctaRequestData</tt>.
     * 
     * @return property value of ctaRequestData
     * @since SRT Phase 3-1 - CTA Rainfinity and MSS Tabs Assembly
     */
    public CTARequestData getCtaRequestData() {
        return ctaRequestData;
    }

    /**
     * Setter method for property <tt>ctaRequestData</tt>.
     * 
     * @param ctaRequestData
     *            value to be assigned to property ctaRequestData
     * @since SRT Phase 3-1 - CTA Rainfinity and MSS Tabs Assembly
     */
    public void setCtaRequestData(CTARequestData ctaRequestData) {
        this.ctaRequestData = ctaRequestData;
    }

    /**
     * Getter method for property <tt>residencyRequestData</tt>.
     * 
     * @return property value of residencyRequestData
     * @since SRT Phase 3-3 - Isilon and Residency Tabs Assembly
     */
    public ResidencyRequestData getResidencyRequestData() {
        return residencyRequestData;
    }

    /**
     * Setter method for property <tt>residencyRequestData</tt>.
     * 
     * @param residencyRequestData
     *            value to be assigned to property residencyRequestData
     * @since SRT Phase 3-3 - Isilon and Residency Tabs Assembly
     */
    public void setResidencyRequestData(ResidencyRequestData residencyRequestData) {
        this.residencyRequestData = residencyRequestData;
    }

    /**
     * Getter method for property <tt>sourceOneRequestData</tt>.
     * 
     * @return property value of sourceOneRequestData
     * @since SRT Phase 3-3 - Remove BRS and Isilon and Update Residency and Implement SourceOne Tabs Assembly
     */
    public SourceOneRequestData getSourceOneRequestData() {
        return sourceOneRequestData;
    }

    /**
     * Setter method for property <tt>sourceOneRequestData</tt>.
     * 
     * @param sourceOneRequestData
     *            value to be assigned to property sourceOneRequestData
     * @since SRT Phase 3-3 - Remove BRS and Isilon and Update Residency and Implement SourceOne Tabs Assembly
     */
    public void setSourceOneRequestData(SourceOneRequestData sourceOneRequestData) {
        this.sourceOneRequestData = sourceOneRequestData;
    }

    /**
     * Getter method for property <tt>asdRequestData</tt>.
     * 
     * @return property value of asdRequestData
     * @since SRT Phase 3-4 - ASD and Healthcheck Tabs Assembly
     */
    public ASDRequestData getAsdRequestData() {
        return asdRequestData;
    }

    /**
     * Setter method for property <tt>asdRequestData</tt>.
     * 
     * @param asdRequestData
     *            value to be assigned to property asdRequestData
     * @since SRT Phase 3-4 - ASD and Healthcheck Tabs Assembly
     */
    public void setAsdRequestData(ASDRequestData asdRequestData) {
        this.asdRequestData = asdRequestData;
    }

    /**
     * Getter method for property <tt>healthCheckRequestData</tt>.
     * 
     * @return property value of healthCheckRequestData
     * @since SRT Phase 3-4 - ASD and Healthcheck Tabs Assembly
     */
    public HealthCheckRequestData getHealthCheckRequestData() {
        return healthCheckRequestData;
    }

    /**
     * Setter method for property <tt>healthCheckRequestData</tt>.
     * 
     * @param healthCheckRequestData
     *            value to be assigned to property healthCheckRequestData
     * @since SRT Phase 3-4 - ASD and Healthcheck Tabs Assembly
     */
    public void setHealthCheckRequestData(HealthCheckRequestData healthCheckRequestData) {
        this.healthCheckRequestData = healthCheckRequestData;
    }

    /**
     * Getter method for property <tt>isilonRequestData</tt>.
     * 
     * @return property value of isilonRequestData
     * @since SRT Phase 3-3 - Implement Isilon and ViPR Tabs Assembly
     */
    public IsilonRequestData getIsilonRequestData() {
        return isilonRequestData;
    }

    /**
     * Setter method for property <tt>isilonRequestData</tt>.
     * 
     * @param isilonRequestData
     *            value to be assigned to property isilonRequestData
     * @since SRT Phase 3-3 - Implement Isilon and ViPR Tabs Assembly
     */
    public void setIsilonRequestData(IsilonRequestData isilonRequestData) {
        this.isilonRequestData = isilonRequestData;
    }

    /**
     * Getter method for property <tt>viprRequestData</tt>.
     * 
     * @return property value of viprRequestData
     * @since SRT Phase 3-3 - Implement Isilon and ViPR Tabs Assembly
     */
    public ViprRequestData getViprRequestData() {
        return viprRequestData;
    }

    /**
     * Setter method for property <tt>viprRequestData</tt>.
     * 
     * @param viprRequestData
     *            value to be assigned to property viprRequestData
     * @since SRT Phase 3-3 - Implement Isilon and ViPR Tabs Assembly
     */
    public void setViprRequestData(ViprRequestData viprRequestData) {
        this.viprRequestData = viprRequestData;
    }

    /**
     * Getter method for property <tt>atmosRequestData</tt>.
     * 
     * @return property value of atmosRequestData
     * @since SRT Phase 3-1 - Atmos Centera and Vblock Tabs Assembly
     */
    public AtmosCenteraRequestData getAtmosRequestData() {
        return atmosRequestData;
    }

    /**
     * Setter method for property <tt>atmosRequestData</tt>.
     * 
     * @param atmosRequestData
     *            value to be assigned to property atmosRequestData
     * @since SRT Phase 3-1 - Atmos Centera and Vblock Tabs Assembly
     */
    public void setAtmosRequestData(AtmosCenteraRequestData atmosRequestData) {
        this.atmosRequestData = atmosRequestData;
    }

    /**
     * Getter method for property <tt>vblockRequestData</tt>.
     * 
     * @return property value of vblockRequestData
     * @since SRT Phase 3-1 - Atmos Centera and Vblock Tabs Assembly
     */
    public VblockRequestData getVblockRequestData() {
        return vblockRequestData;
    }

    /**
     * Setter method for property <tt>vblockRequestData</tt>.
     * 
     * @param vblockRequestData
     *            value to be assigned to property vblockRequestData
     * @since SRT Phase 3-1 - Atmos Centera and Vblock Tabs Assembly
     */
    public void setVblockRequestData(VblockRequestData vblockRequestData) {
        this.vblockRequestData = vblockRequestData;
    }

    /**
     * Getter method for property <tt>dpadRequestData</tt>.
     * 
     * @return property value of dpadRequestData
     * @since SRT Phase 3-5 - BRS Tabs Part 1 Assembly
     */
    public DPADRequestData getDpadRequestData() {
        return dpadRequestData;
    }

    /**
     * Setter method for property <tt>dpadRequestData</tt>.
     * 
     * @param dpadRequestData
     *            value to be assigned to property dpadRequestData
     * @since SRT Phase 3-5 - BRS Tabs Part 1 Assembly
     */
    public void setDpadRequestData(DPADRequestData dpadRequestData) {
        this.dpadRequestData = dpadRequestData;
    }

    /**
     * Getter method for property <tt>vmwareRequestData</tt>.
     * 
     * @return property value of vmwareRequestData
     * @since SRT Phase 3-1 - Implement VMWare Tab Assembly
     */
    public VMwareRequestData getVmwareRequestData() {
        return vmwareRequestData;
    }

    /**
     * Setter method for property <tt>vmwareRequestData</tt>.
     * 
     * @param vmwareRequestData
     *            value to be assigned to property vmwareRequestData
     * @since SRT Phase 3-1 - Implement VMWare Tab Assembly
     */
    public void setVmwareRequestData(VMwareRequestData vmwareRequestData) {
        this.vmwareRequestData = vmwareRequestData;
    }

    /**
     * Getter method for property <tt>moveRequestData</tt>.
     * 
     * @return property value of moveRequestData
     * @since SRT Phase 3-2 - Move Request and Change Request Tabs Assembly
     */
    public MoveRequestData getMoveRequestData() {
        return moveRequestData;
    }

    /**
     * Setter method for property <tt>moveRequestData</tt>.
     * 
     * @param moveRequestData
     *            value to be assigned to property moveRequestData
     * @since SRT Phase 3-2 - Move Request and Change Request Tabs Assembly
     */
    public void setMoveRequestData(MoveRequestData moveRequestData) {
        this.moveRequestData = moveRequestData;
    }

    /**
     * Getter method for property <tt>changeRequestData</tt>.
     * 
     * @return property value of changeRequestData
     * @since SRT Phase 3-2 - Move Request and Change Request Tabs Assembly
     */
    public ChangeRequestData getChangeRequestData() {
        return changeRequestData;
    }

    /**
     * Setter method for property <tt>changeRequestData</tt>.
     * 
     * @param changeRequestData
     *            value to be assigned to property changeRequestData
     * @since SRT Phase 3-2 - Move Request and Change Request Tabs Assembly
     */
    public void setChangeRequestData(ChangeRequestData changeRequestData) {
        this.changeRequestData = changeRequestData;
    }

    /**
     * Getter method for property <tt>w4nData</tt>.
     * 
     * @return property value of w4nData
     * @since SRT Phase 3-2 - W4N and Unfunded Project Tabs Assembly
     */
    public W4NData getW4nData() {
        return w4nData;
    }

    /**
     * Setter method for property <tt>w4nData</tt>.
     * 
     * @param w4nData
     *            value to be assigned to property w4nData
     * @since SRT Phase 3-2 - W4N and Unfunded Project Tabs Assembly
     */
    public void setW4nData(W4NData w4nData) {
        this.w4nData = w4nData;
    }

    /**
     * Getter method for property <tt>unfundedProjectData</tt>.
     * 
     * @return property value of unfundedProjectData
     * @since SRT Phase 3-2 - W4N and Unfunded Project Tabs Assembly
     */
    public UnfundedProjectData getUnfundedProjectData() {
        return unfundedProjectData;
    }

    /**
     * Setter method for property <tt>unfundedProjectData</tt>.
     * 
     * @param unfundedProjectData
     *            value to be assigned to property unfundedProjectData
     * @since SRT Phase 3-2 - W4N and Unfunded Project Tabs Assembly
     */
    public void setUnfundedProjectData(UnfundedProjectData unfundedProjectData) {
        this.unfundedProjectData = unfundedProjectData;
    }

    /**
     * Getter method for property <tt>srmRequestData</tt>.
     * 
     * @return property value of srmRequestData
     */
    public SRMRequestData getSrmRequestData() {
        return srmRequestData;
    }

    /**
     * Setter method for property <tt>srmRequestData</tt>.
     * 
     * @param srmRequestData
     *            value to be assigned to property srmRequestData
     * @since SRT Phase 3-2 - Implement SRM and Update Change Request and Move Request Tabs Assembly
     */
    public void setSrmRequestData(SRMRequestData srmRequestData) {
        this.srmRequestData = srmRequestData;
    }

    /**
     * <p>Gets the data for Xtreme tab.</p>
     *
     * @return a <code>XtremeRequestData</code> providing the data for Xtreme tab.
     * @since 2.2
     */
    public XtremeRequestData getXtremeRequestData() {
        return this.xtremeRequestData;
    }

    /**
     * <p>Sets the data for Xtreme tab.</p>
     *
     * @param xtremeRequestData a <code>XtremeRequestData</code> providing the data for Xtreme tab.
     * @since 2.2
     */
    public void setXtremeRequestData(XtremeRequestData xtremeRequestData) {
        this.xtremeRequestData = xtremeRequestData;
    }

    /**
     * Getter method for property <tt>engagementTypeData</tt>.
     * 
     * @return property value of engagementTypeData
     * @since SRT Phase 4 - ET Assembly 1
     */
    public EngagementTypeData getEngagementTypeData() {
        return engagementTypeData;
    }

    /**
     * Setter method for property <tt>engagementTypeData</tt>.
     * 
     * @param engagementTypeData
     *            value to be assigned to property engagementTypeData
     * @since SRT Phase 4 - ET Assembly 1
     */
    public void setEngagementTypeData(EngagementTypeData engagementTypeData) {
        this.engagementTypeData = engagementTypeData;
    }

    /**
     * Getter method for property <tt>dealGovernanceData</tt>.
     * 
     * @return property value of dealGovernanceData
     * @since SRT Phase 4 - ET Assembly 1
     */
    public DealGovernanceData getDealGovernanceData() {
        return dealGovernanceData;
    }

    /**
     * Setter method for property <tt>dealGovernanceData</tt>.
     * 
     * @param dealGovernanceData
     *            value to be assigned to property dealGovernanceData
     * @since SRT Phase 4 - ET Assembly 1
     */
    public void setDealGovernanceData(DealGovernanceData dealGovernanceData) {
        this.dealGovernanceData = dealGovernanceData;
    }

    /**
     * Getter method for property <tt>estimatesData</tt>.
     * 
     * @return property value of estimatesData
     * @since SRT Phase 4 - ET Assembly 1
     */
    public EstimatesData getEstimatesData() {
        return estimatesData;
    }

    /**
     * Setter method for property <tt>estimatesData</tt>.
     * 
     * @param estimatesData
     *            value to be assigned to property estimatesData
     * @since SRT Phase 4 - ET Assembly 1
     */
    public void setEstimatesData(EstimatesData estimatesData) {
        this.estimatesData = estimatesData;
    }

    /**
     * <p>Gets the projectRegulatoryType property.</p>
     *
     * @return a <code>ProjectRegulatoryType</code> providing the value for projectRegulatoryType property.
     * @since 2.4
     */
    public ProjectRegulatoryType getProjectRegulatoryType() {
        return this.projectRegulatoryType;
    }

    /**
     * <p>Sets the projectRegulatoryType property.</p>
     *
     * @param projectRegulatoryType a <code>ProjectRegulatoryType</code> providing the value for projectRegulatoryType
     * proeprty.
     * @since 2.4
     */
    public void setProjectRegulatoryType(ProjectRegulatoryType projectRegulatoryType) {
        this.projectRegulatoryType = projectRegulatoryType;
    }

    /**
     * <p>Gets the projectEndDate property.</p>
     *
     * @return a <code>Date</code> providing the value for projectEndDate property.
     * @since 2.4
     */
    public Date getProjectEndDate() {
        return this.projectEndDate;
    }

    /**
     * <p>Sets the projectEndDate property.</p>
     *
     * @param projectEndDate a <code>Date</code> providing the value for projectEndDate proeprty.
     * @since 2.4
     */
    public void setProjectEndDate(Date projectEndDate) {
        this.projectEndDate = projectEndDate;
    }

    /**
     * <p>Gets the projectStartDate property.</p>
     *
     * @return a <code>Date</code> providing the value for projectStartDate property.
     * @since 2.4
     */
    public Date getProjectStartDate() {
        return this.projectStartDate;
    }

    /**
     * <p>Sets the projectStartDate property.</p>
     *
     * @param projectStartDate a <code>Date</code> providing the value for projectStartDate proeprty.
     * @since 2.4
     */
    public void setProjectStartDate(Date projectStartDate) {
        this.projectStartDate = projectStartDate;
    }

    /**
     * <p>Gets the "riskCalculationData" property.</p>
     *
     * @return a <code>RiskCalculationData</code> providing the value for "riskCalculationData" property.
     * @since 2.5
     */
    public RiskCalculationData getRiskCalculationData() {
        return this.riskCalculationData;
    }

    /**
     * <p>Sets the "riskCalculationData" property.</p>
     *
     * @param riskCalculationData a <code>RiskCalculationData</code> providing the value for "riskCalculationData"
     * property.
     * @since 2.5
     */
    public void setRiskCalculationData(RiskCalculationData riskCalculationData) {
        this.riskCalculationData = riskCalculationData;
    }

    /**
     * <p>Gets the "Project Description" property.</p>
     *
     * @return a <code>String</code> providing the value for "Project Description" property.
     * @since 2.6
     */
    public String getProjectDescription() {
        return this.projectDescription;
    }

    /**
     * <p>Sets the "Project Description" property.</p>
     *
     * @param projectDescription a <code>String</code> providing the value for "Project Description" property.
     * @since 2.6
     */
    public void setProjectDescription(String projectDescription) {
        this.projectDescription = projectDescription;
    }

    /**
     * <p> Retrieves the sanTanInformation field. </p>
     *
     * @return the sanTanInformation
     * @since 2.7
     */
    public SanTanInformation getSanTanInformation() {
        return sanTanInformation;
    }

    /**
     * <p> Sets the value to sanTanInformation field. </p>
     *
     * @param sanTanInformation the sanTanInformation to set
     * @since 2.7
     */
    public void setSanTanInformation(SanTanInformation sanTanInformation) {
        this.sanTanInformation = sanTanInformation;
    }
    
    /**
     * <p> Retrieves the approver field. </p>
     *
     * @return the approver
     * @since 2.7
     */
    public Profile getApprover() {
        return approver;
    }

    /**
     * <p> Sets the value to approver field. </p>
     *
     * @param approver the approver to set
     * @since 2.7
     */
    public void setApprover(Profile approver) {
        this.approver = approver;
    }

    /**
     * <p> Retrieves the additionalRecipients field. </p>
     *
     * @return the additionalRecipients
     * @since 2.7
     */
    public List<Profile> getAdditionalRecipients() {
        return additionalRecipients;
    }

    /**
     * <p> Sets the value to additionalRecipients field. </p>
     *
     * @param additionalRecipients the additionalRecipients to set
     * @since 2.7
     */
    public void setAdditionalRecipients(List<Profile> additionalRecipients) {
        this.additionalRecipients = additionalRecipients;
    }

    /**
     * The toString method.
     * 
     * @return the string for this entity
     */
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("{").append(super.toString());
        sb.append(", requestStatus:").append(requestStatus);
        sb.append(", projectName:").append(projectName).append("}");
        return sb.toString();
    }
}

/*
 * This code is copyright (c) 2014 EMC Corporation
 */
package com.emc.gs.tools.srf.model.healthcheck;

import com.emc.gs.tools.srf.model.IdentifiableEntity;

/**
 * <p>
 * This is HealthCheckIonix entity class.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safety.
 * </p>
 * <p>
 * 
 * @author TCSASSEMBLER
 * @version 1.0
 * @since SRT Phase 3-4 - ASD and Healthcheck Tabs Assembly
 */
public class HealthCheckIonix extends IdentifiableEntity {

    /**
     * Include the Executive Summary Presentation?
     */
    private Boolean includeExecutiveSummaryPresentation;

    /**
     * What size environment?
     */
    private SizeEnvironment sizeEnvironment;

    /**
     * <p>
     * The default constructor.
     * </p>
     */
    public HealthCheckIonix() {
    }

    /**
     * Getter method for property <tt>includeExecutiveSummaryPresentation</tt>.
     * 
     * @return property value of includeExecutiveSummaryPresentation
     */
    public Boolean getIncludeExecutiveSummaryPresentation() {
        return includeExecutiveSummaryPresentation;
    }

    /**
     * Setter method for property <tt>includeExecutiveSummaryPresentation</tt>.
     * 
     * @param includeExecutiveSummaryPresentation
     *            value to be assigned to property includeExecutiveSummaryPresentation
     */
    public void setIncludeExecutiveSummaryPresentation(Boolean includeExecutiveSummaryPresentation) {
        this.includeExecutiveSummaryPresentation = includeExecutiveSummaryPresentation;
    }

    /**
     * Getter method for property <tt>sizeEnvironment</tt>.
     * 
     * @return property value of sizeEnvironment
     */
    public SizeEnvironment getSizeEnvironment() {
        return sizeEnvironment;
    }

    /**
     * Setter method for property <tt>sizeEnvironment</tt>.
     * 
     * @param sizeEnvironment
     *            value to be assigned to property sizeEnvironment
     */
    public void setSizeEnvironment(SizeEnvironment sizeEnvironment) {
        this.sizeEnvironment = sizeEnvironment;
    }

}

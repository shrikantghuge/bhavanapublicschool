/*
 * This code is copyright (c) 2013 - 2014 EMC Corporation.
 */
package com.emc.gs.tools.srf.model.bc;

import com.emc.gs.tools.srf.model.IdentifiableEntity;

/**
 * <p>
 * This is MirrorViewSrdfInformation entity class.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread
 * safety.
 * </p>
 * 
 * <p>
 * <strong>Changes V1.1:</strong> <strong>SRT Bug Fixes - F121, F153, F154,
 * F162</strong>
 * <ul>
 * <li>Add knowledgeTransferHours field.</li>
 * </ul>
 * </p>
 * 
 * @author faeton, stevenfrog, MonicaMuranyi
 * @version 1.1
 */
public class MirrorViewSrdfInformation extends IdentifiableEntity {

    /**
     * <p>
     * The knowledgeTransferHours.
     * </p>
     */
    private String knowledgeTransferHours;

    /**
     * <p>
     * The postSalesCompletionQualifier.
     * </p>
     */
    private PostSalesCompletionQualifier postSalesCompletionQualifier;

    /**
     * <p>
     * The msClustersNumber.
     * </p>
     */
    private Integer msClustersNumber;

    /**
     * <p>
     * The totalClusteredServersNumber.
     * </p>
     */
    private Integer totalClusteredServersNumber;

    /**
     * <p>
     * The osVersions.
     * </p>
     */
    private String osVersions;

    /**
     * <p>
     * The mirrorViewNewInstall.
     * </p>
     */
    private boolean mirrorViewNewInstall;

    /**
     * <p>
     * The srdfNewInstall.
     * </p>
     */
    private boolean srdfNewInstall;

    /**
     * <p>
     * The default constructor.
     * </p>
     */
    public MirrorViewSrdfInformation() {
        // Empty
    }

    /**
     * <p>
     * Retrieves the knowledgeTransferHours field.
     * </p>
     * 
     * @return the knowledgeTransferHours
     */
    public String getKnowledgeTransferHours() {
        return knowledgeTransferHours;
    }

    /**
     * <p>
     * Sets the value to knowledgeTransferHours field.
     * </p>
     * 
     * @param knowledgeTransferHours
     *            the knowledgeTransferHours to set
     */
    public void setKnowledgeTransferHours(String knowledgeTransferHours) {
        this.knowledgeTransferHours = knowledgeTransferHours;
    }

    /**
     * <p>
     * Retrieves the postSalesCompletionQualifier field.
     * </p>
     * 
     * @return the postSalesCompletionQualifier
     */
    public PostSalesCompletionQualifier getPostSalesCompletionQualifier() {
        return postSalesCompletionQualifier;
    }

    /**
     * <p>
     * Sets the value to postSalesCompletionQualifier field.
     * </p>
     * 
     * @param postSalesCompletionQualifier
     *            the postSalesCompletionQualifier to set
     */
    public void setPostSalesCompletionQualifier(PostSalesCompletionQualifier postSalesCompletionQualifier) {
        this.postSalesCompletionQualifier = postSalesCompletionQualifier;
    }

    /**
     * <p>
     * Retrieves the msClustersNumber field.
     * </p>
     * 
     * @return the msClustersNumber
     */
    public Integer getMsClustersNumber() {
        return msClustersNumber;
    }

    /**
     * <p>
     * Sets the value to msClustersNumber field.
     * </p>
     * 
     * @param msClustersNumber
     *            the msClustersNumber to set
     */
    public void setMsClustersNumber(Integer msClustersNumber) {
        this.msClustersNumber = msClustersNumber;
    }

    /**
     * <p>
     * Retrieves the totalClusteredServersNumber field.
     * </p>
     * 
     * @return the totalClusteredServersNumber
     */
    public Integer getTotalClusteredServersNumber() {
        return totalClusteredServersNumber;
    }

    /**
     * <p>
     * Sets the value to totalClusteredServersNumber field.
     * </p>
     * 
     * @param totalClusteredServersNumber
     *            the totalClusteredServersNumber to set
     */
    public void setTotalClusteredServersNumber(Integer totalClusteredServersNumber) {
        this.totalClusteredServersNumber = totalClusteredServersNumber;
    }

    /**
     * <p>
     * Retrieves the osVersions field.
     * </p>
     * 
     * @return the osVersions
     */
    public String getOsVersions() {
        return osVersions;
    }

    /**
     * <p>
     * Sets the value to osVersions field.
     * </p>
     * 
     * @param osVersions
     *            the osVersions to set
     */
    public void setOsVersions(String osVersions) {
        this.osVersions = osVersions;
    }

    /**
     * <p>
     * Retrieves the mirrorViewNewInstall field.
     * </p>
     * 
     * @return the mirrorViewNewInstall
     */
    public boolean isMirrorViewNewInstall() {
        return mirrorViewNewInstall;
    }

    /**
     * <p>
     * Sets the value to mirrorViewNewInstall field.
     * </p>
     * 
     * @param mirrorViewNewInstall
     *            the mirrorViewNewInstall to set
     */
    public void setMirrorViewNewInstall(boolean mirrorViewNewInstall) {
        this.mirrorViewNewInstall = mirrorViewNewInstall;
    }

    /**
     * <p>
     * Retrieves the srdfNewInstall field.
     * </p>
     * 
     * @return the srdfNewInstall
     */
    public boolean isSrdfNewInstall() {
        return srdfNewInstall;
    }

    /**
     * <p>
     * Sets the value to srdfNewInstall field.
     * </p>
     * 
     * @param srdfNewInstall
     *            the srdfNewInstall to set
     */
    public void setSrdfNewInstall(boolean srdfNewInstall) {
        this.srdfNewInstall = srdfNewInstall;
    }

    /**
     * The toString method.
     * 
     * @return the string for this entity
     */
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("{").append(super.toString());
        sb.append(", knowledgeTransferHours:").append(knowledgeTransferHours);
        sb.append(", postSalesCompletionQualifier:").append(postSalesCompletionQualifier);
        sb.append(", msClustersNumber:").append(msClustersNumber);
        sb.append(", totalClusteredServersNumber:").append(totalClusteredServersNumber);
        sb.append(", osVersions:").append(osVersions);
        sb.append(", mirrorViewNewInstall:").append(mirrorViewNewInstall);
        sb.append(", srdfNewInstall:").append(srdfNewInstall).append("}");
        return sb.toString();
    }
}

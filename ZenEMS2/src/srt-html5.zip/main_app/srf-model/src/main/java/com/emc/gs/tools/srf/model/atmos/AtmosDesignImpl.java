/*
 * This code is copyright (c) 2014 EMC Corporation
 */
package com.emc.gs.tools.srf.model.atmos;

import com.emc.gs.tools.srf.model.IdentifiableEntity;

/**
 * <p>
 * This is AtmosDesignImpl entity class.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safety.
 * </p>
 * 
 * @author TCSASSEMBLER
 * @version 1.0
 * @since SRT Phase 3-1 - Atmos Centera and Vblock Tabs Assembly
 */
public class AtmosDesignImpl extends IdentifiableEntity {

    /**
     * Include Atmos Cloud Delivery Platform?
     */
    private Boolean includeACDP;

    /**
     * # of RMGs for base Hardware and Software of Atmos.
     */
    private Integer rmgsNum;

    /**
     * # of RMGs for base software for Atmos VE.
     */
    private Integer rmgsVENum;

    /**
     * # of Atmos Installation Segments (IS).
     */
    private Integer installationSegmentsNum;

    /**
     * Is the cabinet type WS2-360?
     */
    private Boolean cabinetTypeWS2;

    /**
     * # of Atmos Hardware Servers to Install.
     */
    private Integer hardwareServersNum;

    /**
     * # of CIFS servers to configure within Atmos.
     */
    private Integer cifsServersNum;

    /**
     * # of NFS servers to configure within Atmos.
     */
    private Integer nfsServersNum;

    /**
     * # of IFS servers to configure within Atmos.
     */
    private Integer ifsServersNum;

    /**
     * # of WS servers to configure within Atmos.
     */
    private Integer wsServersNum;

    /**
     * # of tenants to be created.
     */
    private Integer tenantsNum;

    /**
     * # of subtenants to be created.
     */
    private Integer subTenantsNum;

    /**
     * # of policies to be created.
     */
    private Integer policiesNum;

    /**
     * Include secondary site for ACDP?
     */
    private Boolean includeSecondaryACDPSite;

    /**
     * <p>
     * The default constructor.
     * </p>
     */
    public AtmosDesignImpl() {
    }

    /**
     * Getter method for property <tt>includeACDP</tt>.
     * 
     * @return property value of includeACDP
     */
    public Boolean getIncludeACDP() {
        return includeACDP;
    }

    /**
     * Setter method for property <tt>includeACDP</tt>.
     * 
     * @param includeACDP
     *            value to be assigned to property includeACDP
     */
    public void setIncludeACDP(Boolean includeACDP) {
        this.includeACDP = includeACDP;
    }

    /**
     * Getter method for property <tt>rmgsNum</tt>.
     * 
     * @return property value of rmgsNum
     */
    public Integer getRmgsNum() {
        return rmgsNum;
    }

    /**
     * Setter method for property <tt>rmgsNum</tt>.
     * 
     * @param rmgsNum
     *            value to be assigned to property rmgsNum
     */
    public void setRmgsNum(Integer rmgsNum) {
        this.rmgsNum = rmgsNum;
    }

    /**
     * Getter method for property <tt>rmgsVENum</tt>.
     * 
     * @return property value of rmgsVENum
     */
    public Integer getRmgsVENum() {
        return rmgsVENum;
    }

    /**
     * Setter method for property <tt>rmgsVENum</tt>.
     * 
     * @param rmgsVENum
     *            value to be assigned to property rmgsVENum
     */
    public void setRmgsVENum(Integer rmgsVENum) {
        this.rmgsVENum = rmgsVENum;
    }

    /**
     * Getter method for property <tt>installationSegmentsNum</tt>.
     * 
     * @return property value of installationSegmentsNum
     */
    public Integer getInstallationSegmentsNum() {
        return installationSegmentsNum;
    }

    /**
     * Setter method for property <tt>installationSegmentsNum</tt>.
     * 
     * @param installationSegmentsNum
     *            value to be assigned to property installationSegmentsNum
     */
    public void setInstallationSegmentsNum(Integer installationSegmentsNum) {
        this.installationSegmentsNum = installationSegmentsNum;
    }

    /**
     * Getter method for property <tt>cabinetTypeWS2</tt>.
     * 
     * @return property value of cabinetTypeWS2
     */
    public Boolean getCabinetTypeWS2() {
        return cabinetTypeWS2;
    }

    /**
     * Setter method for property <tt>cabinetTypeWS2</tt>.
     * 
     * @param cabinetTypeWS2
     *            value to be assigned to property cabinetTypeWS2
     */
    public void setCabinetTypeWS2(Boolean cabinetTypeWS2) {
        this.cabinetTypeWS2 = cabinetTypeWS2;
    }

    /**
     * Getter method for property <tt>hardwareServersNum</tt>.
     * 
     * @return property value of hardwareServersNum
     */
    public Integer getHardwareServersNum() {
        return hardwareServersNum;
    }

    /**
     * Setter method for property <tt>hardwareServersNum</tt>.
     * 
     * @param hardwareServersNum
     *            value to be assigned to property hardwareServersNum
     */
    public void setHardwareServersNum(Integer hardwareServersNum) {
        this.hardwareServersNum = hardwareServersNum;
    }

    /**
     * Getter method for property <tt>cifsServersNum</tt>.
     * 
     * @return property value of cifsServersNum
     */
    public Integer getCifsServersNum() {
        return cifsServersNum;
    }

    /**
     * Setter method for property <tt>cifsServersNum</tt>.
     * 
     * @param cifsServersNum
     *            value to be assigned to property cifsServersNum
     */
    public void setCifsServersNum(Integer cifsServersNum) {
        this.cifsServersNum = cifsServersNum;
    }

    /**
     * Getter method for property <tt>nfsServersNum</tt>.
     * 
     * @return property value of nfsServersNum
     */
    public Integer getNfsServersNum() {
        return nfsServersNum;
    }

    /**
     * Setter method for property <tt>nfsServersNum</tt>.
     * 
     * @param nfsServersNum
     *            value to be assigned to property nfsServersNum
     */
    public void setNfsServersNum(Integer nfsServersNum) {
        this.nfsServersNum = nfsServersNum;
    }

    /**
     * Getter method for property <tt>ifsServersNum</tt>.
     * 
     * @return property value of ifsServersNum
     */
    public Integer getIfsServersNum() {
        return ifsServersNum;
    }

    /**
     * Setter method for property <tt>ifsServersNum</tt>.
     * 
     * @param ifsServersNum
     *            value to be assigned to property ifsServersNum
     */
    public void setIfsServersNum(Integer ifsServersNum) {
        this.ifsServersNum = ifsServersNum;
    }

    /**
     * Getter method for property <tt>wsServersNum</tt>.
     * 
     * @return property value of wsServersNum
     */
    public Integer getWsServersNum() {
        return wsServersNum;
    }

    /**
     * Setter method for property <tt>wsServersNum</tt>.
     * 
     * @param wsServersNum
     *            value to be assigned to property wsServersNum
     */
    public void setWsServersNum(Integer wsServersNum) {
        this.wsServersNum = wsServersNum;
    }

    /**
     * Getter method for property <tt>tenantsNum</tt>.
     * 
     * @return property value of tenantsNum
     */
    public Integer getTenantsNum() {
        return tenantsNum;
    }

    /**
     * Setter method for property <tt>tenantsNum</tt>.
     * 
     * @param tenantsNum
     *            value to be assigned to property tenantsNum
     */
    public void setTenantsNum(Integer tenantsNum) {
        this.tenantsNum = tenantsNum;
    }

    /**
     * Getter method for property <tt>subTenantsNum</tt>.
     * 
     * @return property value of subTenantsNum
     */
    public Integer getSubTenantsNum() {
        return subTenantsNum;
    }

    /**
     * Setter method for property <tt>subTenantsNum</tt>.
     * 
     * @param subTenantsNum
     *            value to be assigned to property subTenantsNum
     */
    public void setSubTenantsNum(Integer subTenantsNum) {
        this.subTenantsNum = subTenantsNum;
    }

    /**
     * Getter method for property <tt>policiesNum</tt>.
     * 
     * @return property value of policiesNum
     */
    public Integer getPoliciesNum() {
        return policiesNum;
    }

    /**
     * Setter method for property <tt>policiesNum</tt>.
     * 
     * @param policiesNum
     *            value to be assigned to property policiesNum
     */
    public void setPoliciesNum(Integer policiesNum) {
        this.policiesNum = policiesNum;
    }

    /**
     * Getter method for property <tt>includeSecondaryACDPSite</tt>.
     * 
     * @return property value of includeSecondaryACDPSite
     */
    public Boolean getIncludeSecondaryACDPSite() {
        return includeSecondaryACDPSite;
    }

    /**
     * Setter method for property <tt>includeSecondaryACDPSite</tt>.
     * 
     * @param includeSecondaryACDPSite
     *            value to be assigned to property includeSecondaryACDPSite
     */
    public void setIncludeSecondaryACDPSite(Boolean includeSecondaryACDPSite) {
        this.includeSecondaryACDPSite = includeSecondaryACDPSite;
    }

}

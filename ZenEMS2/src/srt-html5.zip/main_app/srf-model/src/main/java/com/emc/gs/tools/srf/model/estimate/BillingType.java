/*
 * This code is copyright (c) 2014 EMC Corporation.
 */
package com.emc.gs.tools.srf.model.estimate;

import com.emc.gs.tools.srf.model.LookupCodeEntity;

/**
 * <p>
 * This is BillingType entity class.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safety.
 * </p>
 * 
 * <p>
 * <strong>Changes V1.1:</strong>
 * <strong>SRT 1.1 DEC 2014 Updates Assembly</strong>
 * <ul>
 * <li>Changed to extend LookupCodeEntity.</li>
 * </ul>
 * </p>
 * 
 * @author TCSASSEMBLER, MonicaMuranyi
 * @version 1.1
 * @since SRT Phase 4 - ET Assembly 1
 */
public class BillingType extends LookupCodeEntity {

    /**
     * Empty constructor.
     */
    public BillingType() {
    }

}

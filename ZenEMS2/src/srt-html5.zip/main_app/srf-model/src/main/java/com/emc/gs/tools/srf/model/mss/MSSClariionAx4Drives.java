/*
 * This code is copyright (c) 2014 EMC Corporation
 */
package com.emc.gs.tools.srf.model.mss;

import com.emc.gs.tools.srf.model.IdentifiableEntity;

/**
 * <p>
 * This is CLARiiON AX4 Drives of MSSArray entity class.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safe.
 * </p>
 * 
 * @author TCSASSEMBLER
 * @version 1.0
 * @since SRT Phase 3-1 - CTA Rainfinity and MSS Tabs Assembly
 */
public class MSSClariionAx4Drives extends IdentifiableEntity {

    /**
     * CLARiiON AX4 Drives 500GB SATA-II.
     */
    private String clariionAx4SataII500GB;

    /**
     * CLARiiON AX4 Drives 750GB SATA-II.
     */
    private String clariionAx4SataII750GB;

    /**
     * CLARiiON AX4 Drives 1000GB SATA-II.
     */
    private String clariionAx4SataII1000GB;

    /**
     * CLARiiON AX4 Drives 146GB 15K SAS.
     */
    private String clariionAx4Sas146GB15k;

    /**
     * CLARiiON AX4 Drives 300GB 15K SAS.
     */
    private String clariionAx4Sas300GB15k;

    /**
     * CLARiiON AX4 Drives 400GB 15K SAS.
     */
    private String clariionAx4Sas400GB15k;

    /**
     * CLARiiON AX4 Drives 450GB 10K SAS.
     */
    private String clariionAx4Sas450GB10k;

    /**
     * CLARiiON AX4 Drives 600GB 10K SAS.
     */
    private String clariionAx4Sas600GB10k;

    /**
     * Other CLARiiON AX4 Drives.
     */
    private String clariionAx4Other;

    /**
     * <p>
     * The default constructor.
     * </p>
     */
    public MSSClariionAx4Drives() {
    }

    /**
     * Getter method for property <tt>clariionAx4SataII500GB</tt>.
     * 
     * @return property value of clariionAx4SataII500GB
     */
    public String getClariionAx4SataII500GB() {
        return clariionAx4SataII500GB;
    }

    /**
     * Setter method for property <tt>clariionAx4SataII500GB</tt>.
     * 
     * @param clariionAx4SataII500GB
     *            value to be assigned to property clariionAx4SataII500GB
     */
    public void setClariionAx4SataII500GB(String clariionAx4SataII500GB) {
        this.clariionAx4SataII500GB = clariionAx4SataII500GB;
    }

    /**
     * Getter method for property <tt>clariionAx4SataII750GB</tt>.
     * 
     * @return property value of clariionAx4SataII750GB
     */
    public String getClariionAx4SataII750GB() {
        return clariionAx4SataII750GB;
    }

    /**
     * Setter method for property <tt>clariionAx4SataII750GB</tt>.
     * 
     * @param clariionAx4SataII750GB
     *            value to be assigned to property clariionAx4SataII750GB
     */
    public void setClariionAx4SataII750GB(String clariionAx4SataII750GB) {
        this.clariionAx4SataII750GB = clariionAx4SataII750GB;
    }

    /**
     * Getter method for property <tt>clariionAx4SataII1000GB</tt>.
     * 
     * @return property value of clariionAx4SataII1000GB
     */
    public String getClariionAx4SataII1000GB() {
        return clariionAx4SataII1000GB;
    }

    /**
     * Setter method for property <tt>clariionAx4SataII1000GB</tt>.
     * 
     * @param clariionAx4SataII1000GB
     *            value to be assigned to property clariionAx4SataII1000GB
     */
    public void setClariionAx4SataII1000GB(String clariionAx4SataII1000GB) {
        this.clariionAx4SataII1000GB = clariionAx4SataII1000GB;
    }

    /**
     * Getter method for property <tt>clariionAx4Sas146GB15k</tt>.
     * 
     * @return property value of clariionAx4Sas146GB15k
     */
    public String getClariionAx4Sas146GB15k() {
        return clariionAx4Sas146GB15k;
    }

    /**
     * Setter method for property <tt>clariionAx4Sas146GB15k</tt>.
     * 
     * @param clariionAx4Sas146GB15k
     *            value to be assigned to property clariionAx4Sas146GB15k
     */
    public void setClariionAx4Sas146GB15k(String clariionAx4Sas146GB15k) {
        this.clariionAx4Sas146GB15k = clariionAx4Sas146GB15k;
    }

    /**
     * Getter method for property <tt>clariionAx4Sas300GB15k</tt>.
     * 
     * @return property value of clariionAx4Sas300GB15k
     */
    public String getClariionAx4Sas300GB15k() {
        return clariionAx4Sas300GB15k;
    }

    /**
     * Setter method for property <tt>clariionAx4Sas300GB15k</tt>.
     * 
     * @param clariionAx4Sas300GB15k
     *            value to be assigned to property clariionAx4Sas300GB15k
     */
    public void setClariionAx4Sas300GB15k(String clariionAx4Sas300GB15k) {
        this.clariionAx4Sas300GB15k = clariionAx4Sas300GB15k;
    }

    /**
     * Getter method for property <tt>clariionAx4Sas400GB15k</tt>.
     * 
     * @return property value of clariionAx4Sas400GB15k
     */
    public String getClariionAx4Sas400GB15k() {
        return clariionAx4Sas400GB15k;
    }

    /**
     * Setter method for property <tt>clariionAx4Sas400GB15k</tt>.
     * 
     * @param clariionAx4Sas400GB15k
     *            value to be assigned to property clariionAx4Sas400GB15k
     */
    public void setClariionAx4Sas400GB15k(String clariionAx4Sas400GB15k) {
        this.clariionAx4Sas400GB15k = clariionAx4Sas400GB15k;
    }

    /**
     * Getter method for property <tt>clariionAx4Sas450GB10k</tt>.
     * 
     * @return property value of clariionAx4Sas450GB10k
     */
    public String getClariionAx4Sas450GB10k() {
        return clariionAx4Sas450GB10k;
    }

    /**
     * Setter method for property <tt>clariionAx4Sas450GB10k</tt>.
     * 
     * @param clariionAx4Sas450GB10k
     *            value to be assigned to property clariionAx4Sas450GB10k
     */
    public void setClariionAx4Sas450GB10k(String clariionAx4Sas450GB10k) {
        this.clariionAx4Sas450GB10k = clariionAx4Sas450GB10k;
    }

    /**
     * Getter method for property <tt>clariionAx4Sas600GB10k</tt>.
     * 
     * @return property value of clariionAx4Sas600GB10k
     */
    public String getClariionAx4Sas600GB10k() {
        return clariionAx4Sas600GB10k;
    }

    /**
     * Setter method for property <tt>clariionAx4Sas600GB10k</tt>.
     * 
     * @param clariionAx4Sas600GB10k
     *            value to be assigned to property clariionAx4Sas600GB10k
     */
    public void setClariionAx4Sas600GB10k(String clariionAx4Sas600GB10k) {
        this.clariionAx4Sas600GB10k = clariionAx4Sas600GB10k;
    }

    /**
     * Getter method for property <tt>clariionAx4Other</tt>.
     * 
     * @return property value of clariionAx4Other
     */
    public String getClariionAx4Other() {
        return clariionAx4Other;
    }

    /**
     * Setter method for property <tt>clariionAx4Other</tt>.
     * 
     * @param clariionAx4Other
     *            value to be assigned to property clariionAx4Other
     */
    public void setClariionAx4Other(String clariionAx4Other) {
        this.clariionAx4Other = clariionAx4Other;
    }

}

/*
 * This code is copyright (c) 2014 EMC Corporation
 */
package com.emc.gs.tools.srf.model.cta;

import java.math.BigDecimal;

import com.emc.gs.tools.srf.model.IdentifiableEntity;
import com.emc.gs.tools.srf.model.SitesInvolved;

/**
 * <p>
 * This is CTARequestData entity class.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safety.
 * </p>
 * <p>
 * <strong>Changes V1.1:</strong> <strong>SRT Phase 3-1 - CTA Rainfinity and MSS Tabs Update Assembly</strong>
 * <ul>
 * <li>Remove highLevelDesign/migration fields.</li>
 * <li>Add generalComment/conversion/raininfinity fields.</li>
 * </ul>
 * </p>
 * 
 * @author TCSASSEMBLER
 * @version 1.1
 * @since SRT Phase 3-1 - CTA Rainfinity and MSS Tabs Assembly
 */
public class CTARequestData extends IdentifiableEntity {

    /**
     * # of sites involved.
     */
    private SitesInvolved sitesInvolved;

    /**
     * # days of knowledge transfer.
     */
    private BigDecimal daysOfknowledgeTransfer;

    /**
     * General comment.
     */
    private String generalComment;

    /**
     * Services scoped.
     */
    private CTAServicesScope servicesScope;

    /**
     * CTA implementation.
     */
    private CTAImplementation implementation;

    /**
     * CTA conversion.
     */
    private CTAConversion conversion;

    /**
     * CTA raininfinity.
     */
    private CTARaininfinity raininfinity;

    /**
     * <p>
     * The default constructor.
     * </p>
     */
    public CTARequestData() {
    }

    /**
     * Getter method for property <tt>sitesInvolved</tt>.
     * 
     * @return property value of sitesInvolved
     */
    public SitesInvolved getSitesInvolved() {
        return sitesInvolved;
    }

    /**
     * Setter method for property <tt>sitesInvolved</tt>.
     * 
     * @param sitesInvolved
     *            value to be assigned to property sitesInvolved
     */
    public void setSitesInvolved(SitesInvolved sitesInvolved) {
        this.sitesInvolved = sitesInvolved;
    }

    /**
     * Getter method for property <tt>daysOfknowledgeTransfer</tt>.
     * 
     * @return property value of daysOfknowledgeTransfer
     */
    public BigDecimal getDaysOfknowledgeTransfer() {
        return daysOfknowledgeTransfer;
    }

    /**
     * Setter method for property <tt>daysOfknowledgeTransfer</tt>.
     * 
     * @param daysOfknowledgeTransfer
     *            value to be assigned to property daysOfknowledgeTransfer
     */
    public void setDaysOfknowledgeTransfer(BigDecimal daysOfknowledgeTransfer) {
        this.daysOfknowledgeTransfer = daysOfknowledgeTransfer;
    }

    /**
     * Getter method for property <tt>generalComment</tt>.
     * 
     * @return property value of generalComment
     */
    public String getGeneralComment() {
        return generalComment;
    }

    /**
     * Setter method for property <tt>generalComment</tt>.
     * 
     * @param generalComment
     *            value to be assigned to property generalComment
     */
    public void setGeneralComment(String generalComment) {
        this.generalComment = generalComment;
    }

    /**
     * Getter method for property <tt>servicesScope</tt>.
     * 
     * @return property value of servicesScope
     */
    public CTAServicesScope getServicesScope() {
        return servicesScope;
    }

    /**
     * Setter method for property <tt>servicesScope</tt>.
     * 
     * @param servicesScope
     *            value to be assigned to property servicesScope
     */
    public void setServicesScope(CTAServicesScope servicesScope) {
        this.servicesScope = servicesScope;
    }

    /**
     * Getter method for property <tt>implementation</tt>.
     * 
     * @return property value of implementation
     */
    public CTAImplementation getImplementation() {
        return implementation;
    }

    /**
     * Setter method for property <tt>implementation</tt>.
     * 
     * @param implementation
     *            value to be assigned to property implementation
     */
    public void setImplementation(CTAImplementation implementation) {
        this.implementation = implementation;
    }

    /**
     * Getter method for property <tt>conversion</tt>.
     * 
     * @return property value of conversion
     */
    public CTAConversion getConversion() {
        return conversion;
    }

    /**
     * Setter method for property <tt>conversion</tt>.
     * 
     * @param conversion
     *            value to be assigned to property conversion
     */
    public void setConversion(CTAConversion conversion) {
        this.conversion = conversion;
    }

    /**
     * Getter method for property <tt>raininfinity</tt>.
     * 
     * @return property value of raininfinity
     */
    public CTARaininfinity getRaininfinity() {
        return raininfinity;
    }

    /**
     * Setter method for property <tt>raininfinity</tt>.
     * 
     * @param raininfinity
     *            value to be assigned to property raininfinity
     */
    public void setRaininfinity(CTARaininfinity raininfinity) {
        this.raininfinity = raininfinity;
    }

}

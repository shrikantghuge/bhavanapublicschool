/*
 * This code is copyright (c) 2013 - 2014 EMC Corporation.
 */
package com.emc.gs.tools.srf.model.infrastructure;

import com.emc.gs.tools.srf.model.IdentifiableEntity;
import com.emc.gs.tools.srf.model.bc.OpenReplicator;
import com.emc.gs.tools.srf.model.dpad.Vplex;

/**
 * <p>
 * This is InfrastructureRequestData entity class.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safety.
 * </p>
 * 
 * <p>
 * <strong>Changes V1.1:</strong>
 * <strong>SRT Bug Fixes - F121, F153, F154, F162</strong>
 * <ul>
 * <li>Remove knowledgeTransferDays field.</li>
 * </ul>
 * </p>
 * 
 * <p>
 * <strong>Changes V1.2:</strong>
 * <ul>
 * <li>Removed symmReplicationServiceEnabled, arrayPerformanceCheckServiceEnabled, recoverPointServiceEnabled,
 * softwareInstallationServiceEnabled, smartsServiceEnabled, recoverPointInformation, miscellaneousInformation
 * fields.</li>
 * </ul>
 * </p>
 * 
 * <p>
 * <strong>Changes V1.3:</strong> <strong>SRT Phase 3-1 - CTA Rainfinity and MSS Tabs Update Assembly</strong>
 * <ul>
 * <li>Add generalComment field.</li>
 * </ul>
 * </p>
 * 
 * <p>
 * <strong>Changes V1.4:</strong>
 * <strong>SRT Phase 3-5 - BRS Tabs Part 1 Assembly</strong>
 * <ul>
 * <li>Remove vplexServiceEnabled/vplexInformation fields.</li>
 * </ul>
 *
 * <p>
 * Version 1.5 Change notes:
 *   <ol>
 *     <li>Removed <code>sanTanInformation</code> property.</li>
 *     <li>Removed <code>sanTanConnectivityServiceEnabled</code> property.</li>
 *   </ol>
 * </p>
 * </p>
 *
 * <p>
 * Version 1.6 Change notes:
 *   <ol>
 *     <li>Added {@link #symmetrixMF} property.</li>
 *     <li>Added {@link #symmetrixOS} property.</li>
 *     <li>Added {@link #symmetrixOSServiceEnabled} property.</li>
 *     <li>Added {@link #symmetrixMFServiceEnabled} property.</li>
 *   </ol>
 * </p>
 *
 * <p>
 * Version 1.7 Change notes:
 *   <ol>
 *     <li>Removed <code>symmetrixInformation</code> property.</li>
 *     <li>Removed <code>symmetrixServiceEnabled</code> property.</li>
 *     <li>Added {@link #vplex} property.</li>
 *     <li>Added {@link #vplexServiceEnabled} property.</li>
 *   </ol>
 * </p>

 * @author faeton, stevenfrog, MonicaMuranyi, isv
 * @version 1.7
 */
public class InfrastructureRequestData extends IdentifiableEntity {

    /**
     * General comment.
     */
    private String generalComment;

    /**
     * <p>
     * The dataMigrationServiceEnabled.
     * </p>
     */
    private boolean dataMigrationServiceEnabled;

    /**
     * <p>
     * The vnxClariionServiceEnabled.
     * </p>
     */
    private boolean vnxClariionServiceEnabled;

    /**
     * <p>
     * The cxReplicationServiceEnabled.
     * </p>
     */
    private boolean cxReplicationServiceEnabled;

    /**
     * <p>
     * The sanAssessmentServiceEnabled.
     * </p>
     */
    private boolean sanAssessmentServiceEnabled;

    /**
     * <p>
     * The arrayHealthCheckServiceEnabled.
     * </p>
     */
    private boolean arrayHealthCheckServiceEnabled;

    /**
     * <p>
     * The sanHealthCheckServiceEnabled.
     * </p>
     */
    private boolean sanHealthCheckServiceEnabled;

    /**
     * <p>
     * The environmentDetailsInformation.
     * </p>
     */
    private EnvironmentDetailsInformation environmentDetailsInformation;

    /**
     * <p>
     * The vnxClariionInformation.
     * </p>
     */
    private VnxClariionInformation vnxClariionInformation;

    /**
     * <p>
     * The dataMigrationInformation.
     * </p>
     */
    private DataMigrationInformation dataMigrationInformation;

    /**
     * <p>
     * The openReplicator.
     * </p>
     */
    private OpenReplicator openReplicator;

    /**
     * <p>A <code>SymmetrixMF</code> providing the value for symmetrixMF property.</p>
     *
     * @since 1.6
     */
    private SymmetrixMF symmetrixMF;

    /**
     * <p>A <code>SymmetrixOS</code> providing the value for symmetrixOS property.</p>
     *
     * @since 1.6
     */
    private SymmetrixOS symmetrixOS;

    /**
     * <p>A <code>boolean</code> providing the value for symmetrixMFServiceEnabled property.</p>
     * 
     * @since 1.6
     */
    private boolean symmetrixMFServiceEnabled;

    /**
     * <p>A <code>boolean</code> providing the value for symmetrixOSServiceEnabled property.</p>
     * 
     * @since 1.6
     */
    private boolean symmetrixOSServiceEnabled;

    /**
     * <p>A <code>boolean</code> providing the value for vplexServiceEnabled property.</p>
     */
    private boolean vplexServiceEnabled;

    /**
     * VPLEX information.
     */
    private Vplex vplex;

    /**
     * <p>
     * The default constructor.
     * </p>
     */
    public InfrastructureRequestData() {
        // Empty
    }

    /**
     * Getter method for property <tt>generalComment</tt>.
     * 
     * @return property value of generalComment
     */
    public String getGeneralComment() {
        return generalComment;
    }

    /**
     * Setter method for property <tt>generalComment</tt>.
     * 
     * @param generalComment
     *            value to be assigned to property generalComment
     */
    public void setGeneralComment(String generalComment) {
        this.generalComment = generalComment;
    }

    /**
     * <p>
     * Retrieves the dataMigrationServiceEnabled field.
     * </p>
     * 
     * @return the dataMigrationServiceEnabled
     */
    public boolean isDataMigrationServiceEnabled() {
        return dataMigrationServiceEnabled;
    }

    /**
     * <p>
     * Sets the value to dataMigrationServiceEnabled field.
     * </p>
     * 
     * @param dataMigrationServiceEnabled
     *            the dataMigrationServiceEnabled to set
     */
    public void setDataMigrationServiceEnabled(boolean dataMigrationServiceEnabled) {
        this.dataMigrationServiceEnabled = dataMigrationServiceEnabled;
    }

    /**
     * <p>
     * Retrieves the vnxClariionServiceEnabled field.
     * </p>
     * 
     * @return the vnxClariionServiceEnabled
     */
    public boolean isVnxClariionServiceEnabled() {
        return vnxClariionServiceEnabled;
    }

    /**
     * <p>
     * Sets the value to vnxClariionServiceEnabled field.
     * </p>
     * 
     * @param vnxClariionServiceEnabled
     *            the vnxClariionServiceEnabled to set
     */
    public void setVnxClariionServiceEnabled(boolean vnxClariionServiceEnabled) {
        this.vnxClariionServiceEnabled = vnxClariionServiceEnabled;
    }

    /**
     * <p>
     * Retrieves the cxReplicationServiceEnabled field.
     * </p>
     * 
     * @return the cxReplicationServiceEnabled
     */
    public boolean isCxReplicationServiceEnabled() {
        return cxReplicationServiceEnabled;
    }

    /**
     * <p>
     * Sets the value to cxReplicationServiceEnabled field.
     * </p>
     * 
     * @param cxReplicationServiceEnabled
     *            the cxReplicationServiceEnabled to set
     */
    public void setCxReplicationServiceEnabled(boolean cxReplicationServiceEnabled) {
        this.cxReplicationServiceEnabled = cxReplicationServiceEnabled;
    }

    /**
     * <p>
     * Retrieves the sanAssessmentServiceEnabled field.
     * </p>
     * 
     * @return the sanAssessmentServiceEnabled
     */
    public boolean isSanAssessmentServiceEnabled() {
        return sanAssessmentServiceEnabled;
    }

    /**
     * <p>
     * Sets the value to sanAssessmentServiceEnabled field.
     * </p>
     * 
     * @param sanAssessmentServiceEnabled
     *            the sanAssessmentServiceEnabled to set
     */
    public void setSanAssessmentServiceEnabled(boolean sanAssessmentServiceEnabled) {
        this.sanAssessmentServiceEnabled = sanAssessmentServiceEnabled;
    }

    /**
     * <p>
     * Retrieves the arrayHealthCheckServiceEnabled field.
     * </p>
     * 
     * @return the arrayHealthCheckServiceEnabled
     */
    public boolean isArrayHealthCheckServiceEnabled() {
        return arrayHealthCheckServiceEnabled;
    }

    /**
     * <p>
     * Sets the value to arrayHealthCheckServiceEnabled field.
     * </p>
     * 
     * @param arrayHealthCheckServiceEnabled
     *            the arrayHealthCheckServiceEnabled to set
     */
    public void setArrayHealthCheckServiceEnabled(boolean arrayHealthCheckServiceEnabled) {
        this.arrayHealthCheckServiceEnabled = arrayHealthCheckServiceEnabled;
    }

    /**
     * <p>
     * Retrieves the sanHealthCheckServiceEnabled field.
     * </p>
     * 
     * @return the sanHealthCheckServiceEnabled
     */
    public boolean isSanHealthCheckServiceEnabled() {
        return sanHealthCheckServiceEnabled;
    }

    /**
     * <p>
     * Sets the value to sanHealthCheckServiceEnabled field.
     * </p>
     * 
     * @param sanHealthCheckServiceEnabled
     *            the sanHealthCheckServiceEnabled to set
     */
    public void setSanHealthCheckServiceEnabled(boolean sanHealthCheckServiceEnabled) {
        this.sanHealthCheckServiceEnabled = sanHealthCheckServiceEnabled;
    }

    /**
     * <p>
     * Retrieves the environmentDetailsInformation field.
     * </p>
     * 
     * @return the environmentDetailsInformation
     */
    public EnvironmentDetailsInformation getEnvironmentDetailsInformation() {
        return environmentDetailsInformation;
    }

    /**
     * <p>
     * Sets the value to environmentDetailsInformation field.
     * </p>
     * 
     * @param environmentDetailsInformation
     *            the environmentDetailsInformation to set
     */
    public void setEnvironmentDetailsInformation(EnvironmentDetailsInformation environmentDetailsInformation) {
        this.environmentDetailsInformation = environmentDetailsInformation;
    }

    /**
     * <p>
     * Retrieves the vnxClariionInformation field.
     * </p>
     * 
     * @return the vnxClariionInformation
     */
    public VnxClariionInformation getVnxClariionInformation() {
        return vnxClariionInformation;
    }

    /**
     * <p>
     * Sets the value to vnxClariionInformation field.
     * </p>
     * 
     * @param vnxClariionInformation
     *            the vnxClariionInformation to set
     */
    public void setVnxClariionInformation(VnxClariionInformation vnxClariionInformation) {
        this.vnxClariionInformation = vnxClariionInformation;
    }

    /**
     * <p>
     * Retrieves the dataMigrationInformation field.
     * </p>
     * 
     * @return the dataMigrationInformation
     */
    public DataMigrationInformation getDataMigrationInformation() {
        return dataMigrationInformation;
    }

    /**
     * <p>
     * Sets the value to dataMigrationInformation field.
     * </p>
     * 
     * @param dataMigrationInformation
     *            the dataMigrationInformation to set
     */
    public void setDataMigrationInformation(DataMigrationInformation dataMigrationInformation) {
        this.dataMigrationInformation = dataMigrationInformation;
    }

    /**
     * <p>
     * Retrieves the openReplicator field.
     * </p>
     * 
     * @return the openReplicator
     */
    public OpenReplicator getOpenReplicator() {
        return openReplicator;
    }

    /**
     * <p>
     * Sets the value to openReplicator field.
     * </p>
     * 
     * @param openReplicator
     *            the openReplicator to set
     */
    public void setOpenReplicator(OpenReplicator openReplicator) {
        this.openReplicator = openReplicator;
    }

    /**
     * <p>Gets the symmetrixMF property.</p>
     *
     * @return a <code>SymmetrixMF</code> providing the value for symmetrixMF property.
     * @since 1.6
     */
    public SymmetrixMF getSymmetrixMF() {
        return this.symmetrixMF;
    }

    /**
     * <p>Sets the symmetrixMF property.</p>
     *
     * @param symmetrixMF a <code>SymmetrixMF</code> providing the value for symmetrixMF property.
     * @since 1.6
     */
    public void setSymmetrixMF(SymmetrixMF symmetrixMF) {
        this.symmetrixMF = symmetrixMF;
    }

    /**
     * <p>Gets the symmetrixOS property.</p>
     *
     * @return a <code>SymmetrixOS</code> providing the value for symmetrixOS property.
     * @since 1.6
     */
    public SymmetrixOS getSymmetrixOS() {
        return this.symmetrixOS;
    }

    /**
     * <p>Sets the symmetrixOS property.</p>
     *
     * @param symmetrixOS a <code>SymmetrixOS</code> providing the value for symmetrixOS property.
     * @since 1.6
     */
    public void setSymmetrixOS(SymmetrixOS symmetrixOS) {
        this.symmetrixOS = symmetrixOS;
    }

    /**
     * <p>Gets the symmetrixOSServiceEnabled property.</p>
     *
     * @return a <code>boolean</code> providing the value for symmetrixOSServiceEnabled property.
     * @since 1.6
     */
    public boolean getSymmetrixOSServiceEnabled() {
        return this.symmetrixOSServiceEnabled;
    }

    /**
     * <p>Sets the symmetrixOSServiceEnabled property.</p>
     *
     * @param symmetrixOSServiceEnabled a <code>boolean</code> providing the value for symmetrixOSServiceEnabled
     * property.
     * @since 1.6
     */
    public void setSymmetrixOSServiceEnabled(boolean symmetrixOSServiceEnabled) {
        this.symmetrixOSServiceEnabled = symmetrixOSServiceEnabled;
    }

    /**
     * <p>Gets the symmetrixMFServiceEnabled property.</p>
     *
     * @return a <code>boolean</code> providing the value for symmetrixMFServiceEnabled property.
     * @since 1.6
     */
    public boolean getSymmetrixMFServiceEnabled() {
        return this.symmetrixMFServiceEnabled;
    }

    /**
     * <p>Sets the symmetrixMFServiceEnabled property.</p>
     *
     * @param symmetrixMFServiceEnabled a <code>boolean</code> providing the value for symmetrixMFServiceEnabled
     * property.
     * @since 1.6
     */
    public void setSymmetrixMFServiceEnabled(boolean symmetrixMFServiceEnabled) {
        this.symmetrixMFServiceEnabled = symmetrixMFServiceEnabled;
    }

    /**
     * Getter method for property <tt>vplex</tt>.
     *
     * @return property value of vplex
     */
    public Vplex getVplex() {
        return vplex;
    }

    /**
     * Setter method for property <tt>vplex</tt>.
     *
     * @param vplex value to be assigned to property vplex
     */
    public void setVplex(Vplex vplex) {
        this.vplex = vplex;
    }

    /**
     * <p>Gets the vplexServiceEnabled property.</p>
     *
     * @return a <code>boolean</code> providing the value for vplexServiceEnabled property.
     */
    public boolean getVplexServiceEnabled() {
        return this.vplexServiceEnabled;
    }

    /**
     * <p>Sets the vplexServiceEnabled property.</p>
     *
     * @param vplexServiceEnabled a <code>boolean</code> providing the value for vplexServiceEnabled property.
     */
    public void setVplexServiceEnabled(boolean vplexServiceEnabled) {
        this.vplexServiceEnabled = vplexServiceEnabled;
    }

    /**
     * The toString method.
     * 
     * @return the string for this entity
     */
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("{").append(super.toString());
        sb.append(", vplexServiceEnabled:").append(vplexServiceEnabled);
        sb.append(", symmetrixMFServiceEnabled:").append(symmetrixMFServiceEnabled);
        sb.append(", symmetrixOSServiceEnabled:").append(symmetrixOSServiceEnabled);
        sb.append(", dataMigrationServiceEnabled:").append(dataMigrationServiceEnabled);
        sb.append(", vnxClariionServiceEnabled:").append(vnxClariionServiceEnabled);
        sb.append(", cxReplicationServiceEnabled:").append(cxReplicationServiceEnabled);
        sb.append(", sanAssessmentServiceEnabled:").append(sanAssessmentServiceEnabled);
        sb.append(", arrayHealthCheckServiceEnabled:").append(arrayHealthCheckServiceEnabled);
        sb.append(", sanHealthCheckServiceEnabled:").append(sanHealthCheckServiceEnabled).append("}");
        return sb.toString();
    }
}

/*
 * This code is copyright (c) 2013 - 2014 EMC Corporation.
 */
package com.emc.gs.tools.srf.model.mainframe;

/**
 * <p>
 * This is BooleanServiceData entity class.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safety.
 * </p>
 *
 * <p>
 * <strong>Changes:</strong>
 * <strong>SRT Release Assembly - Mainframe tab</strong>
 * <ul>
 * <li>allow null for 'enabled'</li>
 * </ul>
 * </p>
 * 
 * @author faeton, stevenfrog, TCSASSEMBLER
 * @version 1.1
 */
public class BooleanServiceData extends ServiceData {
    /**
     * <p>
     * The enabled.
     * </p>
     */
    private Boolean enabled;

    /**
     * <p>
     * The default constructor.
     * </p>
     */
    public BooleanServiceData() {
        // Empty
    }

    /**
     * The toString method.
     *
     * @return the string for this entity
     */
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("{").append(super.toString());
        sb.append(", enabled:").append(enabled).append("}");
        return sb.toString();
    }

    /**
     * Gets the value of the field <code>enabled</code>.
     * @return the enabled
     */
    public Boolean getEnabled() {
        return enabled;
    }

    /**
     * Sets the value of the field <code>enabled</code>.
     * @param enabled the enabled to set
     */
    public void setEnabled(Boolean enabled) {
        this.enabled = enabled;
    }
}

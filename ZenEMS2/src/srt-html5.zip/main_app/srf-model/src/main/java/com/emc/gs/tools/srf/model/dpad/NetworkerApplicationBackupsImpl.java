/*
 * This code is copyright (c) 2014 EMC Corporation
 */
package com.emc.gs.tools.srf.model.dpad;

/**
 * <p>
 * This is NetworkerApplicationBackupsImpl entity class.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safety.
 * </p>
 * 
 * @author TCSASSEMBLER
 * @version 1.0
 * @since SRT Phase 3-5 - BRS Tabs Part 3 Assembly
 */
public class NetworkerApplicationBackupsImpl extends NetworkerApplicationBackupsBase {

    /**
     * Include EMC VSS Hardware Provider.
     */
    private Boolean msSqlIncludeHardwareProvider;

    /**
     * # of Networker Modiule for Microsoft Proxy Nodes.
     */
    private Integer msSqlProxyNodesNum;

    /**
     * # of Microsoft SQL Server Cluster Nodes.
     */
    private Integer msSqlServerClusterNodesNum;

    /**
     * Include EMC VSS Hardware Provider.
     */
    private Boolean exchangeIncludeHardwareProvider;

    /**
     * # of Networker Modiule for Microsoft Proxy Nodes.
     */
    private Integer exchangeProxyNodesNum;

    /**
     * Average Size in GB of Exchange Database Stores.
     */
    private Integer exchangeDatabaseStoresAverageSize;

    /**
     * # of Exchange Cluster Nodes Included in this Engagement.
     */
    private Integer exchangeClusterNodesNum;

    /**
     * # of CCR Clusters Included in this Engagement.
     */
    private Integer ccrClustersNum;

    /**
     * Include EMC VSS Hardware Provider.
     */
    private Boolean sharePointIncludeHardwareProvider;

    /**
     * # of Networker Modiule for Microsoft Proxy Nodes.
     */
    private Integer sharePointProxyNodesNum;

    /**
     * # of Microsoft SQL Server Cluster Nodes.
     */
    private Integer sharePointMSSqlServerClusterNodesNum;

    /**
     * # of Physical Servers in SharePoint Environment.
     */
    private Integer sharePointPhysicalServersNum;

    /**
     * Include EMC VSS Hardware Provider.
     */
    private Boolean hypervIncludeHardwareProvider;

    /**
     * # of Networker Modiule for Microsoft Proxy Nodes.
     */
    private Integer hypervProxyNodesNum;

    /**
     * Will NMM be configured to backup an individual Hyper-V Machines?
     */
    private Boolean hypervNMMConfigured;

    /**
     * # of physical servers in Hyper-V Cluster.
     */
    private Integer hypervPhysicalServersNum;

    /**
     * # of Hyper-V virtual machines to be backed up individually.
     */
    private Integer hypervVirtualMachinesNum;

    /**
     * # of Physical Servers in Oracle Environment.
     */
    private Integer oraclePhysicalServersNum;

    /**
     * # of Physical Servers in MySQL Cluster.
     */
    private Integer mySqlPhysicalServersNum;

    /**
     * # of Physical Lotus Notes Servers.
     */
    private Integer lotusNotesPhysicalServersNum;

    /**
     * # of Physical Servers in the SAP Environment.
     */
    private Integer sapPhysicalServersNum;

    /**
     * <p>
     * The default constructor.
     * </p>
     */
    public NetworkerApplicationBackupsImpl() {
    }

    /**
     * Getter method for property <tt>msSqlIncludeHardwareProvider</tt>.
     * 
     * @return property value of msSqlIncludeHardwareProvider
     */
    public Boolean getMsSqlIncludeHardwareProvider() {
        return msSqlIncludeHardwareProvider;
    }

    /**
     * Setter method for property <tt>msSqlIncludeHardwareProvider</tt>.
     * 
     * @param msSqlIncludeHardwareProvider
     *            value to be assigned to property msSqlIncludeHardwareProvider
     */
    public void setMsSqlIncludeHardwareProvider(Boolean msSqlIncludeHardwareProvider) {
        this.msSqlIncludeHardwareProvider = msSqlIncludeHardwareProvider;
    }

    /**
     * Getter method for property <tt>msSqlProxyNodesNum</tt>.
     * 
     * @return property value of msSqlProxyNodesNum
     */
    public Integer getMsSqlProxyNodesNum() {
        return msSqlProxyNodesNum;
    }

    /**
     * Setter method for property <tt>msSqlProxyNodesNum</tt>.
     * 
     * @param msSqlProxyNodesNum
     *            value to be assigned to property msSqlProxyNodesNum
     */
    public void setMsSqlProxyNodesNum(Integer msSqlProxyNodesNum) {
        this.msSqlProxyNodesNum = msSqlProxyNodesNum;
    }

    /**
     * Getter method for property <tt>msSqlServerClusterNodesNum</tt>.
     * 
     * @return property value of msSqlServerClusterNodesNum
     */
    public Integer getMsSqlServerClusterNodesNum() {
        return msSqlServerClusterNodesNum;
    }

    /**
     * Setter method for property <tt>msSqlServerClusterNodesNum</tt>.
     * 
     * @param msSqlServerClusterNodesNum
     *            value to be assigned to property msSqlServerClusterNodesNum
     */
    public void setMsSqlServerClusterNodesNum(Integer msSqlServerClusterNodesNum) {
        this.msSqlServerClusterNodesNum = msSqlServerClusterNodesNum;
    }

    /**
     * Getter method for property <tt>exchangeIncludeHardwareProvider</tt>.
     * 
     * @return property value of exchangeIncludeHardwareProvider
     */
    public Boolean getExchangeIncludeHardwareProvider() {
        return exchangeIncludeHardwareProvider;
    }

    /**
     * Setter method for property <tt>exchangeIncludeHardwareProvider</tt>.
     * 
     * @param exchangeIncludeHardwareProvider
     *            value to be assigned to property exchangeIncludeHardwareProvider
     */
    public void setExchangeIncludeHardwareProvider(Boolean exchangeIncludeHardwareProvider) {
        this.exchangeIncludeHardwareProvider = exchangeIncludeHardwareProvider;
    }

    /**
     * Getter method for property <tt>exchangeProxyNodesNum</tt>.
     * 
     * @return property value of exchangeProxyNodesNum
     */
    public Integer getExchangeProxyNodesNum() {
        return exchangeProxyNodesNum;
    }

    /**
     * Setter method for property <tt>exchangeProxyNodesNum</tt>.
     * 
     * @param exchangeProxyNodesNum
     *            value to be assigned to property exchangeProxyNodesNum
     */
    public void setExchangeProxyNodesNum(Integer exchangeProxyNodesNum) {
        this.exchangeProxyNodesNum = exchangeProxyNodesNum;
    }

    /**
     * Getter method for property <tt>exchangeDatabaseStoresAverageSize</tt>.
     * 
     * @return property value of exchangeDatabaseStoresAverageSize
     */
    public Integer getExchangeDatabaseStoresAverageSize() {
        return exchangeDatabaseStoresAverageSize;
    }

    /**
     * Setter method for property <tt>exchangeDatabaseStoresAverageSize</tt>.
     * 
     * @param exchangeDatabaseStoresAverageSize
     *            value to be assigned to property exchangeDatabaseStoresAverageSize
     */
    public void setExchangeDatabaseStoresAverageSize(Integer exchangeDatabaseStoresAverageSize) {
        this.exchangeDatabaseStoresAverageSize = exchangeDatabaseStoresAverageSize;
    }

    /**
     * Getter method for property <tt>exchangeClusterNodesNum</tt>.
     * 
     * @return property value of exchangeClusterNodesNum
     */
    public Integer getExchangeClusterNodesNum() {
        return exchangeClusterNodesNum;
    }

    /**
     * Setter method for property <tt>exchangeClusterNodesNum</tt>.
     * 
     * @param exchangeClusterNodesNum
     *            value to be assigned to property exchangeClusterNodesNum
     */
    public void setExchangeClusterNodesNum(Integer exchangeClusterNodesNum) {
        this.exchangeClusterNodesNum = exchangeClusterNodesNum;
    }

    /**
     * Getter method for property <tt>ccrClustersNum</tt>.
     * 
     * @return property value of ccrClustersNum
     */
    public Integer getCcrClustersNum() {
        return ccrClustersNum;
    }

    /**
     * Setter method for property <tt>ccrClustersNum</tt>.
     * 
     * @param ccrClustersNum
     *            value to be assigned to property ccrClustersNum
     */
    public void setCcrClustersNum(Integer ccrClustersNum) {
        this.ccrClustersNum = ccrClustersNum;
    }

    /**
     * Getter method for property <tt>sharePointIncludeHardwareProvider</tt>.
     * 
     * @return property value of sharePointIncludeHardwareProvider
     */
    public Boolean getSharePointIncludeHardwareProvider() {
        return sharePointIncludeHardwareProvider;
    }

    /**
     * Setter method for property <tt>sharePointIncludeHardwareProvider</tt>.
     * 
     * @param sharePointIncludeHardwareProvider
     *            value to be assigned to property sharePointIncludeHardwareProvider
     */
    public void setSharePointIncludeHardwareProvider(Boolean sharePointIncludeHardwareProvider) {
        this.sharePointIncludeHardwareProvider = sharePointIncludeHardwareProvider;
    }

    /**
     * Getter method for property <tt>sharePointProxyNodesNum</tt>.
     * 
     * @return property value of sharePointProxyNodesNum
     */
    public Integer getSharePointProxyNodesNum() {
        return sharePointProxyNodesNum;
    }

    /**
     * Setter method for property <tt>sharePointProxyNodesNum</tt>.
     * 
     * @param sharePointProxyNodesNum
     *            value to be assigned to property sharePointProxyNodesNum
     */
    public void setSharePointProxyNodesNum(Integer sharePointProxyNodesNum) {
        this.sharePointProxyNodesNum = sharePointProxyNodesNum;
    }

    /**
     * Getter method for property <tt>sharePointMSSqlServerClusterNodesNum</tt>.
     * 
     * @return property value of sharePointMSSqlServerClusterNodesNum
     */
    public Integer getSharePointMSSqlServerClusterNodesNum() {
        return sharePointMSSqlServerClusterNodesNum;
    }

    /**
     * Setter method for property <tt>sharePointMSSqlServerClusterNodesNum</tt>.
     * 
     * @param sharePointMSSqlServerClusterNodesNum
     *            value to be assigned to property sharePointMSSqlServerClusterNodesNum
     */
    public void setSharePointMSSqlServerClusterNodesNum(Integer sharePointMSSqlServerClusterNodesNum) {
        this.sharePointMSSqlServerClusterNodesNum = sharePointMSSqlServerClusterNodesNum;
    }

    /**
     * Getter method for property <tt>sharePointPhysicalServersNum</tt>.
     * 
     * @return property value of sharePointPhysicalServersNum
     */
    public Integer getSharePointPhysicalServersNum() {
        return sharePointPhysicalServersNum;
    }

    /**
     * Setter method for property <tt>sharePointPhysicalServersNum</tt>.
     * 
     * @param sharePointPhysicalServersNum
     *            value to be assigned to property sharePointPhysicalServersNum
     */
    public void setSharePointPhysicalServersNum(Integer sharePointPhysicalServersNum) {
        this.sharePointPhysicalServersNum = sharePointPhysicalServersNum;
    }

    /**
     * Getter method for property <tt>hypervIncludeHardwareProvider</tt>.
     * 
     * @return property value of hypervIncludeHardwareProvider
     */
    public Boolean getHypervIncludeHardwareProvider() {
        return hypervIncludeHardwareProvider;
    }

    /**
     * Setter method for property <tt>hypervIncludeHardwareProvider</tt>.
     * 
     * @param hypervIncludeHardwareProvider
     *            value to be assigned to property hypervIncludeHardwareProvider
     */
    public void setHypervIncludeHardwareProvider(Boolean hypervIncludeHardwareProvider) {
        this.hypervIncludeHardwareProvider = hypervIncludeHardwareProvider;
    }

    /**
     * Getter method for property <tt>hypervProxyNodesNum</tt>.
     * 
     * @return property value of hypervProxyNodesNum
     */
    public Integer getHypervProxyNodesNum() {
        return hypervProxyNodesNum;
    }

    /**
     * Setter method for property <tt>hypervProxyNodesNum</tt>.
     * 
     * @param hypervProxyNodesNum
     *            value to be assigned to property hypervProxyNodesNum
     */
    public void setHypervProxyNodesNum(Integer hypervProxyNodesNum) {
        this.hypervProxyNodesNum = hypervProxyNodesNum;
    }

    /**
     * Getter method for property <tt>hypervNMMConfigured</tt>.
     * 
     * @return property value of hypervNMMConfigured
     */
    public Boolean getHypervNMMConfigured() {
        return hypervNMMConfigured;
    }

    /**
     * Setter method for property <tt>hypervNMMConfigured</tt>.
     * 
     * @param hypervNMMConfigured
     *            value to be assigned to property hypervNMMConfigured
     */
    public void setHypervNMMConfigured(Boolean hypervNMMConfigured) {
        this.hypervNMMConfigured = hypervNMMConfigured;
    }

    /**
     * Getter method for property <tt>hypervPhysicalServersNum</tt>.
     * 
     * @return property value of hypervPhysicalServersNum
     */
    public Integer getHypervPhysicalServersNum() {
        return hypervPhysicalServersNum;
    }

    /**
     * Setter method for property <tt>hypervPhysicalServersNum</tt>.
     * 
     * @param hypervPhysicalServersNum
     *            value to be assigned to property hypervPhysicalServersNum
     */
    public void setHypervPhysicalServersNum(Integer hypervPhysicalServersNum) {
        this.hypervPhysicalServersNum = hypervPhysicalServersNum;
    }

    /**
     * Getter method for property <tt>hypervVirtualMachinesNum</tt>.
     * 
     * @return property value of hypervVirtualMachinesNum
     */
    public Integer getHypervVirtualMachinesNum() {
        return hypervVirtualMachinesNum;
    }

    /**
     * Setter method for property <tt>hypervVirtualMachinesNum</tt>.
     * 
     * @param hypervVirtualMachinesNum
     *            value to be assigned to property hypervVirtualMachinesNum
     */
    public void setHypervVirtualMachinesNum(Integer hypervVirtualMachinesNum) {
        this.hypervVirtualMachinesNum = hypervVirtualMachinesNum;
    }

    /**
     * Getter method for property <tt>oraclePhysicalServersNum</tt>.
     * 
     * @return property value of oraclePhysicalServersNum
     */
    public Integer getOraclePhysicalServersNum() {
        return oraclePhysicalServersNum;
    }

    /**
     * Setter method for property <tt>oraclePhysicalServersNum</tt>.
     * 
     * @param oraclePhysicalServersNum
     *            value to be assigned to property oraclePhysicalServersNum
     */
    public void setOraclePhysicalServersNum(Integer oraclePhysicalServersNum) {
        this.oraclePhysicalServersNum = oraclePhysicalServersNum;
    }

    /**
     * Getter method for property <tt>mySqlPhysicalServersNum</tt>.
     * 
     * @return property value of mySqlPhysicalServersNum
     */
    public Integer getMySqlPhysicalServersNum() {
        return mySqlPhysicalServersNum;
    }

    /**
     * Setter method for property <tt>mySqlPhysicalServersNum</tt>.
     * 
     * @param mySqlPhysicalServersNum
     *            value to be assigned to property mySqlPhysicalServersNum
     */
    public void setMySqlPhysicalServersNum(Integer mySqlPhysicalServersNum) {
        this.mySqlPhysicalServersNum = mySqlPhysicalServersNum;
    }

    /**
     * Getter method for property <tt>lotusNotesPhysicalServersNum</tt>.
     * 
     * @return property value of lotusNotesPhysicalServersNum
     */
    public Integer getLotusNotesPhysicalServersNum() {
        return lotusNotesPhysicalServersNum;
    }

    /**
     * Setter method for property <tt>lotusNotesPhysicalServersNum</tt>.
     * 
     * @param lotusNotesPhysicalServersNum
     *            value to be assigned to property lotusNotesPhysicalServersNum
     */
    public void setLotusNotesPhysicalServersNum(Integer lotusNotesPhysicalServersNum) {
        this.lotusNotesPhysicalServersNum = lotusNotesPhysicalServersNum;
    }

    /**
     * Getter method for property <tt>sapPhysicalServersNum</tt>.
     * 
     * @return property value of sapPhysicalServersNum
     */
    public Integer getSapPhysicalServersNum() {
        return sapPhysicalServersNum;
    }

    /**
     * Setter method for property <tt>sapPhysicalServersNum</tt>.
     * 
     * @param sapPhysicalServersNum
     *            value to be assigned to property sapPhysicalServersNum
     */
    public void setSapPhysicalServersNum(Integer sapPhysicalServersNum) {
        this.sapPhysicalServersNum = sapPhysicalServersNum;
    }

}

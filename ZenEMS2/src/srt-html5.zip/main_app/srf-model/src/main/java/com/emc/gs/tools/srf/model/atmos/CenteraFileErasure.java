/*
 * This code is copyright (c) 2014 EMC Corporation
 */
package com.emc.gs.tools.srf.model.atmos;

import com.emc.gs.tools.srf.model.IdentifiableEntity;

/**
 * <p>
 * This is CenteraFileErasure entity class.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safety.
 * </p>
 * 
 * @author TCSASSEMBLER
 * @version 1.0
 * @since SRT Phase 3-1 - Atmos Centera and Vblock Tabs Assembly
 */
public class CenteraFileErasure extends IdentifiableEntity {

    /**
     * # of Centera Clips to be deleted (in millions) - MAX: 25 million.
     */
    private Integer clipsToDeleteNum;

    /**
     * <p>
     * The default constructor.
     * </p>
     */
    public CenteraFileErasure() {
    }

    /**
     * Getter method for property <tt>clipsToDeleteNum</tt>.
     * 
     * @return property value of clipsToDeleteNum
     */
    public Integer getClipsToDeleteNum() {
        return clipsToDeleteNum;
    }

    /**
     * Setter method for property <tt>clipsToDeleteNum</tt>.
     * 
     * @param clipsToDeleteNum
     *            value to be assigned to property clipsToDeleteNum
     */
    public void setClipsToDeleteNum(Integer clipsToDeleteNum) {
        this.clipsToDeleteNum = clipsToDeleteNum;
    }

}

/*
 * This code is copyright (c) 2013-2014 EMC Corporation.		
 */
package com.emc.gs.tools.srf.model.infrastructure;

import java.util.ArrayList;
import java.util.List;

import com.emc.gs.tools.srf.model.IdentifiableEntity;

/**
 * <p>
 * This is EnvironmentDetailsInformation entity class.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safety.
 * </p>
 *
 * <p>
 * <strong>Changes:</strong>
 * <strong>SRT Release Assembly - Mainframe tab</strong>
 * <ul>
 * <li>removed dcaAppliancesNumber2</li>
 * <li>renamed databaseNumber to numberOfClusters</li>
 * <li>renamed sunBootNumber to numberBootFromSan</li>
 * </ul>
 * </p>
 * 
 * <p>
 * <strong>Changes V1.2:</strong>
 * <strong>SRT Bug Fixes</strong>
 * <ul>
 * <li>Removed vsdGrabAnalysis24Required, vsdGrabAnalysis36Required and vsdGrabAnalysis55Required fields.</li>
 * </ul>
 * </p>
 * 
 * <p>
 * <strong>Changes V1.3:</strong>
 * <ul>
 * <li>Removed existingEccEnvironmentOption, currentCitiesNumber, emcDiscoverOption, citiesListString fields.</li>
 * </ul>
 * </p>
 * 
 * <p>
 * <strong>Changes V1.4:</strong>
 * <strong>https://apps.topcoder.com/bugs/browse/SRT-35</strong>
 * <ul>
 * <li>Added manufacturers, newHostNumber fields.</li>
 * </ul>
 * </p>
 *
 * <p>
 * Version 1.5 Change notes:
 *   <ol>
 *     <li>Changed the type of {@link #hostInformation} property from <code>Map</code> to <code>List</code>.</li>
 *   </ol>
 * </p>
 *
 * @author faeton, stevenfrog, TCSASSEMBLER, MonicaMuranyi, isv
 * @version 1.5
 */
public class EnvironmentDetailsInformation extends IdentifiableEntity {
    /**
     * <p>
     * The environmentGatherer.
     * </p>
     */
    private EnvironmentGatherer environmentGatherer;

    /**
     * <p>
     * The dcaAppliancesNumber1.
     * </p>
     */
    private Integer dcaAppliancesNumber1;

    /**
     * <p>
     * The hostSoftwareInstaller.
     * </p>
     */
    private HostSoftwareInstaller hostSoftwareInstaller;

    /**
     * <p>
     * The sanImplementator.
     * </p>
     */
    private SanImplementator sanImplementator;

    /**
     * <p>
     * The existingArrayTypes.
     * </p>
     */
    private List<EnvironmentArrayType> existingArrayTypes = new ArrayList<EnvironmentArrayType>();

    /**
     * <p>
     * The existingStorageLocations.
     * </p>
     */
    private List<String> existingStorageLocations = new ArrayList<String>();

    /**
     * <p>
     * The usableCapacities.
     * </p>
     */
    private List<Double> usableCapacities = new ArrayList<Double>();

    /**
     * <p>
     * The numberOfAttachedHosts.
     * </p>
     */
    private List<Integer> numberOfAttachedHosts = new ArrayList<Integer>();

    /**
     * <p>
     * The environmentDeviceTypes.
     * </p>
     */
    private List<EnvironmentDeviceType> environmentDeviceTypes = new ArrayList<EnvironmentDeviceType>();
    
    /**
     * <p>
     * The manufacturers.
     * </p>
     */
    private List<String> manufacturers = new ArrayList<String>();

    /**
     * <p>
     * The existingSanLocations.
     * </p>
     */
    private List<String> existingSanLocations = new ArrayList<String>();

    /**
     * <p>
     * The deviceQuantities.
     * </p>
     */
    private List<Double> deviceQuantities = new ArrayList<Double>();

    /**
     * <p>
     * The hostInformation.
     * </p>
     * @since SRT Release Assembly - BC Tab
     */
    private List<EnvironmentDetailsHostInfo> hostInformation;

    /**
     * <p>
     * The existingSanFabricsNumber.
     * </p>
     */
    private Integer existingSanFabricsNumber;

    /**
     * <p>
     * The default constructor.
     * </p>
     */
    public EnvironmentDetailsInformation() {
        // Empty
    }

    /**
     * <p>
     * Retrieves the environmentGatherer field.
     * </p>
     *
     * @return the environmentGatherer
     */
    public EnvironmentGatherer getEnvironmentGatherer() {
        return environmentGatherer;
    }

    /**
     * <p>
     * Sets the value to environmentGatherer field.
     * </p>
     *
     * @param environmentGatherer
     *            the environmentGatherer to set
     */
    public void setEnvironmentGatherer(EnvironmentGatherer environmentGatherer) {
        this.environmentGatherer = environmentGatherer;
    }

    /**
     * <p>
     * Retrieves the hostSoftwareInstaller field.
     * </p>
     *
     * @return the hostSoftwareInstaller
     */
    public HostSoftwareInstaller getHostSoftwareInstaller() {
        return hostSoftwareInstaller;
    }

    /**
     * <p>
     * Sets the value to hostSoftwareInstaller field.
     * </p>
     *
     * @param hostSoftwareInstaller
     *            the hostSoftwareInstaller to set
     */
    public void setHostSoftwareInstaller(HostSoftwareInstaller hostSoftwareInstaller) {
        this.hostSoftwareInstaller = hostSoftwareInstaller;
    }

    /**
     * <p>
     * Retrieves the sanImplementator field.
     * </p>
     *
     * @return the sanImplementator
     */
    public SanImplementator getSanImplementator() {
        return sanImplementator;
    }

    /**
     * <p>
     * Sets the value to sanImplementator field.
     * </p>
     *
     * @param sanImplementator
     *            the sanImplementator to set
     */
    public void setSanImplementator(SanImplementator sanImplementator) {
        this.sanImplementator = sanImplementator;
    }

    /**
     * <p>
     * Retrieves the existingArrayTypes field.
     * </p>
     *
     * @return the existingArrayTypes
     */
    public List<EnvironmentArrayType> getExistingArrayTypes() {
        return existingArrayTypes;
    }

    /**
     * <p>
     * Sets the value to existingArrayTypes field.
     * </p>
     *
     * @param existingArrayTypes
     *            the existingArrayTypes to set
     */
    public void setExistingArrayTypes(List<EnvironmentArrayType> existingArrayTypes) {
        this.existingArrayTypes = existingArrayTypes;
    }

    /**
     * <p>
     * Retrieves the existingStorageLocations field.
     * </p>
     *
     * @return the existingStorageLocations
     */
    public List<String> getExistingStorageLocations() {
        return existingStorageLocations;
    }

    /**
     * <p>
     * Sets the value to existingStorageLocations field.
     * </p>
     *
     * @param existingStorageLocations
     *            the existingStorageLocations to set
     */
    public void setExistingStorageLocations(List<String> existingStorageLocations) {
        this.existingStorageLocations = existingStorageLocations;
    }

    /**
     * <p>
     * Retrieves the usableCapacities field.
     * </p>
     *
     * @return the usableCapacities
     */
    public List<Double> getUsableCapacities() {
        return usableCapacities;
    }

    /**
     * <p>
     * Sets the value to usableCapacities field.
     * </p>
     *
     * @param usableCapacities
     *            the usableCapacities to set
     */
    public void setUsableCapacities(List<Double> usableCapacities) {
        this.usableCapacities = usableCapacities;
    }

    /**
     * <p>
     * Retrieves the numberOfAttachedHosts field.
     * </p>
     *
     * @return the numberOfAttachedHosts
     */
    public List<Integer> getNumberOfAttachedHosts() {
        return numberOfAttachedHosts;
    }

    /**
     * <p>
     * Sets the value to numberOfAttachedHosts field.
     * </p>
     *
     * @param numberOfAttachedHosts
     *            the numberOfAttachedHosts to set
     */
    public void setNumberOfAttachedHosts(List<Integer> numberOfAttachedHosts) {
        this.numberOfAttachedHosts = numberOfAttachedHosts;
    }
    
    /**
     * <p>
     * Retrieves the manufacturers field.
     * </p>
     *
     * @return the manufacturers
     */
    public List<String> getManufacturers() {
        return manufacturers;
    }
    
    /**
     * <p>
     * Sets the value to manufacturers field.
     * </p>
     *
     * @param manufacturers
     *            the manufacturers to set
     */
    public void setManufacturers(List<String> manufacturers) {
        this.manufacturers = manufacturers;
    }

    /**
     * <p>
     * Retrieves the environmentDeviceTypes field.
     * </p>
     *
     * @return the environmentDeviceTypes
     */
    public List<EnvironmentDeviceType> getEnvironmentDeviceTypes() {
        return environmentDeviceTypes;
    }

    /**
     * <p>
     * Sets the value to environmentDeviceTypes field.
     * </p>
     *
     * @param environmentDeviceTypes
     *            the environmentDeviceTypes to set
     */
    public void setEnvironmentDeviceTypes(List<EnvironmentDeviceType> environmentDeviceTypes) {
        this.environmentDeviceTypes = environmentDeviceTypes;
    }

    /**
     * <p>
     * Retrieves the existingSanLocations field.
     * </p>
     *
     * @return the existingSanLocations
     */
    public List<String> getExistingSanLocations() {
        return existingSanLocations;
    }

    /**
     * <p>
     * Sets the value to existingSanLocations field.
     * </p>
     *
     * @param existingSanLocations
     *            the existingSanLocations to set
     */
    public void setExistingSanLocations(List<String> existingSanLocations) {
        this.existingSanLocations = existingSanLocations;
    }

    /**
     * <p>
     * Retrieves the deviceQuantities field.
     * </p>
     *
     * @return the deviceQuantities
     */
    public List<Double> getDeviceQuantities() {
        return deviceQuantities;
    }

    /**
     * <p>
     * Sets the value to deviceQuantities field.
     * </p>
     *
     * @param deviceQuantities
     *            the deviceQuantities to set
     */
    public void setDeviceQuantities(List<Double> deviceQuantities) {
        this.deviceQuantities = deviceQuantities;
    }

    /**
     * <p>
     * Retrieves the existingSanFabricsNumber field.
     * </p>
     *
     * @return the existingSanFabricsNumber
     */
    public Integer getExistingSanFabricsNumber() {
        return existingSanFabricsNumber;
    }

    /**
     * <p>
     * Sets the value to existingSanFabricsNumber field.
     * </p>
     *
     * @param existingSanFabricsNumber
     *            the existingSanFabricsNumber to set
     */
    public void setExistingSanFabricsNumber(Integer existingSanFabricsNumber) {
        this.existingSanFabricsNumber = existingSanFabricsNumber;
    }

    /**
     * <p>
     * Retrieves the dcaAppliancesNumber1 field.
     * </p>
     *
     * @return the value of dcaAppliancesNumber1
     */
    public Integer getDcaAppliancesNumber1() {
        return dcaAppliancesNumber1;
    }

    /**
     * <p>
     * Sets the value to dcaAppliancesNumber1 field.
     * </p>
     *
     * @param dcaAppliancesNumber1
     *            the value of dcaAppliancesNumber1 to set
     */
    public void setDcaAppliancesNumber1(Integer dcaAppliancesNumber1) {
        this.dcaAppliancesNumber1 = dcaAppliancesNumber1;
    }

    /**
     * Getter method for property <tt>hostInformation</tt>.
     * @return property value of hostInformation
     */
    public List<EnvironmentDetailsHostInfo> getHostInformation() {
        return hostInformation;
    }

    /**
     * Setter method for property <tt>hostInformation</tt>.
     * @param hostInformation value to be assigned to property hostInformation
     */
    public void setHostInformation(List<EnvironmentDetailsHostInfo> hostInformation) {
        this.hostInformation = hostInformation;
    }

    /**
     * The toString method.
     *
     * @return the string for this entity
     */
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("{").append(super.toString());
        sb.append(", environmentGatherer:").append(environmentGatherer);
        sb.append(", dcaAppliancesNumber1:").append(dcaAppliancesNumber1);
        sb.append(", hostSoftwareInstaller:").append(hostSoftwareInstaller);
        sb.append(", sanImplementator:").append(sanImplementator);
        sb.append(", existingArrayTypes:").append(existingArrayTypes);
        sb.append(", existingStorageLocations:").append(existingStorageLocations);
        sb.append(", usableCapacities:").append(usableCapacities);
        sb.append(", numberOfAttachedHosts:").append(numberOfAttachedHosts);
        sb.append(", environmentDeviceTypes:").append(environmentDeviceTypes);
        sb.append(", manufacturers:").append(manufacturers);
        sb.append(", existingSanLocations:").append(existingSanLocations);
        sb.append(", deviceQuantities:").append(deviceQuantities);
        sb.append(", hostInformation:").append(hostInformation);
        sb.append(", existingSanFabricsNumber:").append(existingSanFabricsNumber).append("}");
        return sb.toString();
    }
}

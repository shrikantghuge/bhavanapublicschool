/*
 * This code is copyright (c) 2014 EMC Corporation
 */
package com.emc.gs.tools.srf.model.estimate;

import java.math.BigDecimal;

/**
 * <p>
 * This is ProjectStaff entity class.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safety.
 * </p>
 * 
 * @author TCSASSEMBLER
 * @version 1.0
 * @since SRT Phase 4 - ET Assembly 1
 */
public class ProjectStaff {

    /**
     * Long Role Description (up to 256 characters). This field should be used locally only.
     */
    private String longRoleDescription;

    /**
     * Skills (up to 140 characters).
     */
    private String skills;

    /**
     * Additional Comments (up to 140 characters).
     */
    private String additionalComments;

    /**
     * Potential Candidate.
     */
    private String potentialCandidate;

    /**
     * Tech Screeners/ Interviewers.
     */
    private String techScreeners;

    /**
     * Utilization Target %.
     */
    private BigDecimal utilizationTarget;

    /**
     * Resource Type.
     */
    private ResourceType resourceType;

    /**
     * Citizenship Required.
     */
    private Boolean citizenshipRequired;

    /**
     * Security Clearance Required.
     */
    private Boolean securityClearanceRequired;

    /**
     * Remote Work Allowed.
     */
    private Boolean remoteWorkAllowed;

    /**
     * Work Location(City, State).
     */
    private String workLocation;

    /**
     * Days/Week On Site.
     */
    private Integer daysWeekOnSite;

    /**
     * Screener/Interviewer.
     */
    private ScreenerInterviewer screenerInterviewer;

    /**
     * Project PDM.
     */
    private String projectPDM;

    /**
     * Project PM.
     */
    private String projectPM;

    /**
     * Project RM.
     */
    private String projectRM;

    /**
     * Notes.
     */
    private String notes;

    /**
     * Empty constructor.
     */
    public ProjectStaff() {
    }

    /**
     * Getter method for property <tt>longRoleDescription</tt>.
     * 
     * @return property value of longRoleDescription
     */
    public String getLongRoleDescription() {
        return longRoleDescription;
    }

    /**
     * Setter method for property <tt>longRoleDescription</tt>.
     * 
     * @param longRoleDescription
     *            value to be assigned to property longRoleDescription
     */
    public void setLongRoleDescription(String longRoleDescription) {
        this.longRoleDescription = longRoleDescription;
    }

    /**
     * Getter method for property <tt>skills</tt>.
     * 
     * @return property value of skills
     */
    public String getSkills() {
        return skills;
    }

    /**
     * Setter method for property <tt>skills</tt>.
     * 
     * @param skills
     *            value to be assigned to property skills
     */
    public void setSkills(String skills) {
        this.skills = skills;
    }

    /**
     * Getter method for property <tt>additionalComments</tt>.
     * 
     * @return property value of additionalComments
     */
    public String getAdditionalComments() {
        return additionalComments;
    }

    /**
     * Setter method for property <tt>additionalComments</tt>.
     * 
     * @param additionalComments
     *            value to be assigned to property additionalComments
     */
    public void setAdditionalComments(String additionalComments) {
        this.additionalComments = additionalComments;
    }

    /**
     * Getter method for property <tt>potentialCandidate</tt>.
     * 
     * @return property value of potentialCandidate
     */
    public String getPotentialCandidate() {
        return potentialCandidate;
    }

    /**
     * Setter method for property <tt>potentialCandidate</tt>.
     * 
     * @param potentialCandidate
     *            value to be assigned to property potentialCandidate
     */
    public void setPotentialCandidate(String potentialCandidate) {
        this.potentialCandidate = potentialCandidate;
    }

    /**
     * Getter method for property <tt>techScreeners</tt>.
     * 
     * @return property value of techScreeners
     */
    public String getTechScreeners() {
        return techScreeners;
    }

    /**
     * Setter method for property <tt>techScreeners</tt>.
     * 
     * @param techScreeners
     *            value to be assigned to property techScreeners
     */
    public void setTechScreeners(String techScreeners) {
        this.techScreeners = techScreeners;
    }

    /**
     * Getter method for property <tt>utilizationTarget</tt>.
     * 
     * @return property value of utilizationTarget
     */
    public BigDecimal getUtilizationTarget() {
        return utilizationTarget;
    }

    /**
     * Setter method for property <tt>utilizationTarget</tt>.
     * 
     * @param utilizationTarget
     *            value to be assigned to property utilizationTarget
     */
    public void setUtilizationTarget(BigDecimal utilizationTarget) {
        this.utilizationTarget = utilizationTarget;
    }

    /**
     * Getter method for property <tt>resourceType</tt>.
     * 
     * @return property value of resourceType
     */
    public ResourceType getResourceType() {
        return resourceType;
    }

    /**
     * Setter method for property <tt>resourceType</tt>.
     * 
     * @param resourceType
     *            value to be assigned to property resourceType
     */
    public void setResourceType(ResourceType resourceType) {
        this.resourceType = resourceType;
    }

    /**
     * Getter method for property <tt>citizenshipRequired</tt>.
     * 
     * @return property value of citizenshipRequired
     */
    public Boolean getCitizenshipRequired() {
        return citizenshipRequired;
    }

    /**
     * Setter method for property <tt>citizenshipRequired</tt>.
     * 
     * @param citizenshipRequired
     *            value to be assigned to property citizenshipRequired
     */
    public void setCitizenshipRequired(Boolean citizenshipRequired) {
        this.citizenshipRequired = citizenshipRequired;
    }

    /**
     * Getter method for property <tt>securityClearanceRequired</tt>.
     * 
     * @return property value of securityClearanceRequired
     */
    public Boolean getSecurityClearanceRequired() {
        return securityClearanceRequired;
    }

    /**
     * Setter method for property <tt>securityClearanceRequired</tt>.
     * 
     * @param securityClearanceRequired
     *            value to be assigned to property securityClearanceRequired
     */
    public void setSecurityClearanceRequired(Boolean securityClearanceRequired) {
        this.securityClearanceRequired = securityClearanceRequired;
    }

    /**
     * Getter method for property <tt>remoteWorkAllowed</tt>.
     * 
     * @return property value of remoteWorkAllowed
     */
    public Boolean getRemoteWorkAllowed() {
        return remoteWorkAllowed;
    }

    /**
     * Setter method for property <tt>remoteWorkAllowed</tt>.
     * 
     * @param remoteWorkAllowed
     *            value to be assigned to property remoteWorkAllowed
     */
    public void setRemoteWorkAllowed(Boolean remoteWorkAllowed) {
        this.remoteWorkAllowed = remoteWorkAllowed;
    }

    /**
     * Getter method for property <tt>workLocation</tt>.
     * 
     * @return property value of workLocation
     */
    public String getWorkLocation() {
        return workLocation;
    }

    /**
     * Setter method for property <tt>workLocation</tt>.
     * 
     * @param workLocation
     *            value to be assigned to property workLocation
     */
    public void setWorkLocation(String workLocation) {
        this.workLocation = workLocation;
    }

    /**
     * Getter method for property <tt>daysWeekOnSite</tt>.
     * 
     * @return property value of daysWeekOnSite
     */
    public Integer getDaysWeekOnSite() {
        return daysWeekOnSite;
    }

    /**
     * Setter method for property <tt>daysWeekOnSite</tt>.
     * 
     * @param daysWeekOnSite
     *            value to be assigned to property daysWeekOnSite
     */
    public void setDaysWeekOnSite(Integer daysWeekOnSite) {
        this.daysWeekOnSite = daysWeekOnSite;
    }

    /**
     * Getter method for property <tt>screenerInterviewer</tt>.
     * 
     * @return property value of screenerInterviewer
     */
    public ScreenerInterviewer getScreenerInterviewer() {
        return screenerInterviewer;
    }

    /**
     * Setter method for property <tt>screenerInterviewer</tt>.
     * 
     * @param screenerInterviewer
     *            value to be assigned to property screenerInterviewer
     */
    public void setScreenerInterviewer(ScreenerInterviewer screenerInterviewer) {
        this.screenerInterviewer = screenerInterviewer;
    }

    /**
     * Getter method for property <tt>projectPDM</tt>.
     * 
     * @return property value of projectPDM
     */
    public String getProjectPDM() {
        return projectPDM;
    }

    /**
     * Setter method for property <tt>projectPDM</tt>.
     * 
     * @param projectPDM
     *            value to be assigned to property projectPDM
     */
    public void setProjectPDM(String projectPDM) {
        this.projectPDM = projectPDM;
    }

    /**
     * Getter method for property <tt>projectPM</tt>.
     * 
     * @return property value of projectPM
     */
    public String getProjectPM() {
        return projectPM;
    }

    /**
     * Setter method for property <tt>projectPM</tt>.
     * 
     * @param projectPM
     *            value to be assigned to property projectPM
     */
    public void setProjectPM(String projectPM) {
        this.projectPM = projectPM;
    }

    /**
     * Getter method for property <tt>projectRM</tt>.
     * 
     * @return property value of projectRM
     */
    public String getProjectRM() {
        return projectRM;
    }

    /**
     * Setter method for property <tt>projectRM</tt>.
     * 
     * @param projectRM
     *            value to be assigned to property projectRM
     */
    public void setProjectRM(String projectRM) {
        this.projectRM = projectRM;
    }

    /**
     * Getter method for property <tt>notes</tt>.
     * 
     * @return property value of notes
     */
    public String getNotes() {
        return notes;
    }

    /**
     * Setter method for property <tt>notes</tt>.
     * 
     * @param notes
     *            value to be assigned to property notes
     */
    public void setNotes(String notes) {
        this.notes = notes;
    }

}

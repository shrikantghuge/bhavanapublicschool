/*
 * This code is copyright (c) 2014 EMC Corporation
 */
package com.emc.gs.tools.srf.model.dpad;

import com.emc.gs.tools.srf.model.IdentifiableEntity;

/**
 * <p>
 * This is DataDomainHealthCheck entity class.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safety.
 * </p>
 * 
 * @author TCSASSEMBLER
 * @version 1.0
 * @since SRT Phase 3-5 - BRS Tabs Part 2 Assembly
 */
public class DataDomainHealthCheck extends IdentifiableEntity {

    /**
     * # of Data Domain Appliances.
     */
    private Integer dataDomainAppliancesNum;

    /**
     * # of assessment interviews.
     */
    private Integer assessmentInterviewsNum;

    /**
     * <p>
     * The default constructor.
     * </p>
     */
    public DataDomainHealthCheck() {
    }

    /**
     * Getter method for property <tt>dataDomainAppliancesNum</tt>.
     * 
     * @return property value of dataDomainAppliancesNum
     */
    public Integer getDataDomainAppliancesNum() {
        return dataDomainAppliancesNum;
    }

    /**
     * Setter method for property <tt>dataDomainAppliancesNum</tt>.
     * 
     * @param dataDomainAppliancesNum
     *            value to be assigned to property dataDomainAppliancesNum
     */
    public void setDataDomainAppliancesNum(Integer dataDomainAppliancesNum) {
        this.dataDomainAppliancesNum = dataDomainAppliancesNum;
    }

    /**
     * Getter method for property <tt>assessmentInterviewsNum</tt>.
     * 
     * @return property value of assessmentInterviewsNum
     */
    public Integer getAssessmentInterviewsNum() {
        return assessmentInterviewsNum;
    }

    /**
     * Setter method for property <tt>assessmentInterviewsNum</tt>.
     * 
     * @param assessmentInterviewsNum
     *            value to be assigned to property assessmentInterviewsNum
     */
    public void setAssessmentInterviewsNum(Integer assessmentInterviewsNum) {
        this.assessmentInterviewsNum = assessmentInterviewsNum;
    }

}

/*
 * This code is copyright (c) 2014 EMC Corporation
 */
package com.emc.gs.tools.srf.model.atmos;

/**
 * The Centera protection type enum.
 * <p>
 * <strong>Thread safety</strong>: Enum is thread safety.
 * </p>
 * 
 * @author TCSASSEMBLER
 * @version 1.0
 * @since SRT Phase 3-1 - Atmos Centera and Vblock Tabs Assembly
 */
public enum CenteraProtectionType {

    /**
     * Mirrored.
     */
    Mirrored,

    /**
     * Parity.
     */
    Parity;
}

/*
 * This code is copyright (c) 2013 - 2014 EMC Corporation.
 */
package com.emc.gs.tools.srf.model.bc;

import java.util.Map;

import com.emc.gs.tools.srf.model.IdentifiableEntity;

/**
 * <p>
 * This is TimeFinderInformation entity class.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safety.
 * </p>
 *
 * <p>
 * <strong>Changes V1.1:</strong>
 * <strong>SRT Release Assembly - BC Tab</strong>
 * <ul>
 * <li>Remove bcvCloneOption property and add bcvToImplement/cloneToImplement/snapToImplement properties</li>
 * </ul>
 * </p>
 * 
 * <p>
 * <strong>Changes V1.2:</strong>
 * <strong>SRT Bug Fixes - F121, F153, F154, F162</strong>
 * <ul>
 * <li>Add knowledgeTransferHours field.</li>
 * </ul>
 * </p>
 * 
 * <p>
 * <strong>Changes V1.3:</strong>
 * <ul>
 * <li>Removed copiesNumber, areaSizingType, emcMapPointsOption fields.</li>
 * </ul>
 * </p>
 * 
 * <p>
 * <strong>Changes V1.4:</strong>
 * <strong>https://apps.topcoder.com/bugs/browse/SRT-35</strong>
 * <ul>
 * <li>Added vpSnapToImplement, nrOfVmaxArrays, nrOfCloneCopies, 
 * nrOfBcvCopies, nrOfSnapsCopies, nrOfVPSnapsCopies, nrOfSolutionEnablerHosts, nrOfClonePairs fields.</li>
 * </ul>
 * </p>
 *
 * <p>
 * <strong>Changes V1.5:</strong>
 * <strong>SRT Phase 4 - ET Assembly 3</strong>
 * <ul>
 * <li>Fix the wrong parameter name in the javaDoc of setNrOfVmaxArrays (from snapToImplement to nrOfVmaxArrays).</li>
 * </ul>
 * </p>
 *
 * <p>
 * Version 1.6 ( Assembly 1.0) Change notes:
 *   <ol>
 *     <li>Removed <code>nrOfVmaxArrays</code> property.</li>
 *     <li>Removed <code>databaseNumbers</code> property.</li>
 *   </ol>
 * </p>
 * 
 * @author faeton, stevenfrog, MonicaMuranyi, isv
 * @version 1.6
 */
public class TimeFinderInformation extends IdentifiableEntity {
    
    /**
     * <p>
     * The knowledgeTransferHours.
     * </p>
     */
    private String knowledgeTransferHours;
    
    /**
     * <p>
     * The Integer>.
     * </p>
     */
    private Map<String, Integer> hostNumbers;

    /**
     * <p>
     * The bcvToImplement.
     * </p>
     * @since SRT Release Assembly - BC Tab
     */
    private Boolean bcvToImplement;

    /**
     * <p>
     * The cloneToImplement.
     * </p>
     * @since SRT Release Assembly - BC Tab
     */
    private Boolean cloneToImplement;

    /**
     * <p>
     * The snapToImplement.
     * </p>
     * @since SRT Release Assembly - BC Tab
     */
    private Boolean snapToImplement;
    
    /**
     * <p>
     * The vpSnapToImplement.
     * </p>
     */
    private Boolean vpSnapToImplement;

    /**
     * <p>
     * The configChangeType.
     * </p>
     */
    private ConfigChangeType configChangeType;

    /**
     * <p>
     * The replicatedStorageSize.
     * </p>
     */
    private Integer replicatedStorageSize;

    /**
     * <p>
     * The scriptingLevel.
     * </p>
     */
    private ScriptingLevel scriptingLevel;
    
    /**
     * <p>
     * The areaSizingType.
     * </p>
     */
    private AreaSizingType areaSizingType;
    
    /**
     * <p>
     * The nrOfCloneCopies.
     * </p>
     */
    private Integer nrOfCloneCopies;
    
    /**
     * <p>
     * The nrOfBcvCopies.
     * </p>
     */
    private Integer nrOfBcvCopies;
    
    /**
     * <p>
     * The nrOfSnapsCopies.
     * </p>
     */
    private Integer nrOfSnapsCopies;
    
    /**
     * <p>
     * The nrOfVPSnapsCopies.
     * </p>
     */
    private Integer nrOfVPSnapsCopies;
    
    /**
     * <p>
     * The nrOfSolutionEnablerHosts.
     * </p>
     */
    private Integer nrOfSolutionEnablerHosts;
    
    /**
     * <p>
     * The nrOfClonePairs.
     * </p>
     */
    private Integer nrOfClonePairs;

    /**
     * <p>
     * The default constructor.
     * </p>
     */
    public TimeFinderInformation() {
        // Empty
    }
    
    /**
     * <p>
     * Retrieves the knowledgeTransferHours field.
     * </p>
     *
     * @return the knowledgeTransferHours
     */
    public String getKnowledgeTransferHours() {
        return knowledgeTransferHours;
    }

    /**
     * <p>
     * Sets the value to knowledgeTransferHours field.
     * </p>
     *
     * @param knowledgeTransferHours
     *            the knowledgeTransferHours to set
     */
    public void setKnowledgeTransferHours(String knowledgeTransferHours) {
        this.knowledgeTransferHours = knowledgeTransferHours;
    }

    /**
     * <p>
     * Retrieves the hostNumbers field.
     * </p>
     *
     * @return the hostNumbers
     */
    public Map<String, Integer> getHostNumbers() {
        return hostNumbers;
    }

    /**
     * <p>
     * Sets the value to hostNumbers field.
     * </p>
     *
     * @param hostNumbers
     *            the hostNumbers to set
     */
    public void setHostNumbers(Map<String, Integer> hostNumbers) {
        this.hostNumbers = hostNumbers;
    }

    /**
     * <p>
     * Retrieves the configChangeType field.
     * </p>
     *
     * @return the configChangeType
     */
    public ConfigChangeType getConfigChangeType() {
        return configChangeType;
    }

    /**
     * <p>
     * Sets the value to configChangeType field.
     * </p>
     *
     * @param configChangeType
     *            the configChangeType to set
     */
    public void setConfigChangeType(ConfigChangeType configChangeType) {
        this.configChangeType = configChangeType;
    }

    /**
     * <p>
     * Retrieves the replicatedStorageSize field.
     * </p>
     *
     * @return the replicatedStorageSize
     */
    public Integer getReplicatedStorageSize() {
        return replicatedStorageSize;
    }

    /**
     * <p>
     * Sets the value to replicatedStorageSize field.
     * </p>
     *
     * @param replicatedStorageSize
     *            the replicatedStorageSize to set
     */
    public void setReplicatedStorageSize(Integer replicatedStorageSize) {
        this.replicatedStorageSize = replicatedStorageSize;
    }

    /**
     * <p>
     * Retrieves the scriptingLevel field.
     * </p>
     *
     * @return the scriptingLevel
     */
    public ScriptingLevel getScriptingLevel() {
        return scriptingLevel;
    }

    /**
     * <p>
     * Sets the value to scriptingLevel field.
     * </p>
     *
     * @param scriptingLevel
     *            the scriptingLevel to set
     */
    public void setScriptingLevel(ScriptingLevel scriptingLevel) {
        this.scriptingLevel = scriptingLevel;
    }
    
    /**
     * <p>
     * Retrieves the areaSizingType field.
     * </p>
     *
     * @return the areaSizingType
     */
    public AreaSizingType getAreaSizingType() {
        return areaSizingType;
    }

    /**
     * <p>
     * Sets the value to areaSizingType field.
     * </p>
     *
     * @param areaSizingType
     *            the areaSizingType to set
     */
    public void setAreaSizingType(AreaSizingType areaSizingType) {
        this.areaSizingType = areaSizingType;
    }

    /**
     * Getter method for property <tt>bcvToImplement</tt>.
     * @return property value of bcvToImplement
     * @since SRT Release Assembly - BC Tab
     */
    public Boolean getBcvToImplement() {
        return bcvToImplement;
    }

    /**
     * Getter method for property <tt>cloneToImplement</tt>.
     * @return property value of cloneToImplement
     * @since SRT Release Assembly - BC Tab
     */
    public Boolean getCloneToImplement() {
        return cloneToImplement;
    }

    /**
     * Getter method for property <tt>snapToImplement</tt>.
     * @return property value of snapToImplement
     * @since SRT Release Assembly - BC Tab
     */
    public Boolean getSnapToImplement() {
        return snapToImplement;
    }
    
    /**
     * Getter method for property <tt>vpSnapToImplement</tt>.
     * @return property value of vpSnapToImplement
     */
    public Boolean getVpSnapToImplement() {
        return vpSnapToImplement;
    }
    
    /**
     * Setter method for property <tt>vpSnapToImplement</tt>.
     * @param vpSnapToImplement value to be assigned to property vpSnapToImplement
     */
    public void setVpSnapToImplement(Boolean vpSnapToImplement) {
        this.vpSnapToImplement = vpSnapToImplement;
    }

    /**
     * Setter method for property <tt>bcvToImplement</tt>.
     * @param bcvToImplement value to be assigned to property bcvToImplement
     * @since SRT Release Assembly - BC Tab
     */
    public void setBcvToImplement(Boolean bcvToImplement) {
        this.bcvToImplement = bcvToImplement;
    }

    /**
     * Setter method for property <tt>cloneToImplement</tt>.
     * @param cloneToImplement value to be assigned to property cloneToImplement
     * @since SRT Release Assembly - BC Tab
     */
    public void setCloneToImplement(Boolean cloneToImplement) {
        this.cloneToImplement = cloneToImplement;
    }

    /**
     * Setter method for property <tt>snapToImplement</tt>.
     * @param snapToImplement value to be assigned to property snapToImplement
     * @since SRT Release Assembly - BC Tab
     */
    public void setSnapToImplement(Boolean snapToImplement) {
        this.snapToImplement = snapToImplement;
    }

    /**
     * Getter method for property <tt>nrOfCloneCopies</tt>.
     * @return property value of nrOfCloneCopies
     */
    public Integer getNrOfCloneCopies() {
        return nrOfCloneCopies;
    }
    
    /**
     * Setter method for property <tt>nrOfCloneCopies</tt>.
     * @param nrOfCloneCopies value to be assigned to property nrOfCloneCopies
     */
    public void setNrOfCloneCopies(Integer nrOfCloneCopies) {
        this.nrOfCloneCopies = nrOfCloneCopies;
    }

    /**
     * Getter method for property <tt>nrOfBcvCopies</tt>.
     * @return property value of nrOfBcvCopies
     */
    public Integer getNrOfBcvCopies() {
        return nrOfBcvCopies;
    }

    /**
     * Setter method for property <tt>nrOfBcvCopies</tt>.
     * @param nrOfBcvCopies value to be assigned to property nrOfBcvCopies
     */
    public void setNrOfBcvCopies(Integer nrOfBcvCopies) {
        this.nrOfBcvCopies = nrOfBcvCopies;
    }

    /**
     * Getter method for property <tt>nrOfSnapsCopies</tt>.
     * @return property value of nrOfSnapsCopies
     */
    public Integer getNrOfSnapsCopies() {
        return nrOfSnapsCopies;
    }

    /**
     * Setter method for property <tt>nrOfSnapsCopies</tt>.
     * @param nrOfSnapsCopies value to be assigned to property nrOfSnapsCopies
     */
    public void setNrOfSnapsCopies(Integer nrOfSnapsCopies) {
        this.nrOfSnapsCopies = nrOfSnapsCopies;
    }

    /**
     * Getter method for property <tt>nrOfVPSnapsCopies</tt>.
     * @return property value of nrOfVPSnapsCopies
     */
    public Integer getNrOfVPSnapsCopies() {
        return nrOfVPSnapsCopies;
    }

    /**
     * Setter method for property <tt>nrOfVPSnapsCopies</tt>.
     * @param nrOfVPSnapsCopies value to be assigned to property nrOfVPSnapsCopies
     */
    public void setNrOfVPSnapsCopies(Integer nrOfVPSnapsCopies) {
        this.nrOfVPSnapsCopies = nrOfVPSnapsCopies;
    }

    /**
     * Getter method for property <tt>nrOfSolutionEnablerHosts</tt>.
     * @return property value of nrOfSolutionEnablerHosts
     */
    public Integer getNrOfSolutionEnablerHosts() {
        return nrOfSolutionEnablerHosts;
    }

    /**
     * Setter method for property <tt>nrOfSolutionEnablerHosts</tt>.
     * @param nrOfSolutionEnablerHosts value to be assigned to property nrOfSolutionEnablerHosts
     */
    public void setNrOfSolutionEnablerHosts(Integer nrOfSolutionEnablerHosts) {
        this.nrOfSolutionEnablerHosts = nrOfSolutionEnablerHosts;
    }

    /**
     * Getter method for property <tt>nrOfClonePairs</tt>.
     * @return property value of nrOfClonePairs
     */
    public Integer getNrOfClonePairs() {
        return nrOfClonePairs;
    }

    /**
     * Setter method for property <tt>nrOfClonePairs</tt>.
     * @param nrOfClonePairs value to be assigned to property nrOfClonePairs
     */
    public void setNrOfClonePairs(Integer nrOfClonePairs) {
        this.nrOfClonePairs = nrOfClonePairs;
    }

    /**
     * The toString method.
     *
     * @return the string for this entity
     */
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("{").append(super.toString());
        sb.append(", knowledgeTransferHours:").append(knowledgeTransferHours);
        sb.append(", hostNumbers:").append(hostNumbers);
        sb.append(", bcvToImplement:").append(bcvToImplement);
        sb.append(", cloneToImplement:").append(cloneToImplement);
        sb.append(", snapToImplement:").append(snapToImplement);
        sb.append(", vpSnapToImplement:").append(vpSnapToImplement);
        sb.append(", configChangeType:").append(configChangeType);
        sb.append(", replicatedStorageSize:").append(replicatedStorageSize);
        sb.append(", nrOfCloneCopies:").append(nrOfCloneCopies);
        sb.append(", nrOfBcvCopies:").append(nrOfBcvCopies);
        sb.append(", nrOfSnapsCopies:").append(nrOfSnapsCopies);
        sb.append(", nrOfVPSnapsCopies:").append(nrOfVPSnapsCopies);
        sb.append(", nrOfSolutionEnablerHosts:").append(nrOfSolutionEnablerHosts);
        sb.append(", nrOfClonePairs:").append(nrOfClonePairs);
        sb.append(", scriptingLevel:").append(scriptingLevel).append("}");
        return sb.toString();
    }
}

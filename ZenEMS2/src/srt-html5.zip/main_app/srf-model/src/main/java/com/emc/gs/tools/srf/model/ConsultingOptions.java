/*
 * This code is copyright (c) 2014 EMC Corporation.
 */
package com.emc.gs.tools.srf.model;

/**
 * <p>
 * This is ConsultingOptions entity class.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safety.
 * </p>
 * @author liuliquan
 * @version 1.0
 */
public class ConsultingOptions extends IdentifiableEntity {

    /**
     * <p>
     * The bluePrinting.
     * </p>
     */
    private boolean bluePrinting;

    /**
     * <p>
     * The dcm.
     * </p>
     */
    private boolean dcm;

    /**
     * <p>
     * The staff.
     * </p>
     */
    private boolean staff;

    /**
     * <p>
     * The p2v.
     * </p>
     */
    private boolean p2v;

    /**
     * <p>
     * The vmware.
     * </p>
     */
    private boolean vmware;

    /**
     * Empty constructor.
     */
    public ConsultingOptions() {
    }

    /**
     * Getter method for property <tt>bluePrinting</tt>.
     * @return property value of bluePrinting
     */
    public boolean isBluePrinting() {
        return bluePrinting;
    }

    /**
     * Setter method for property <tt>bluePrinting</tt>.
     * @param bluePrinting
     *            value to be assigned to property bluePrinting
     */
    public void setBluePrinting(boolean bluePrinting) {
        this.bluePrinting = bluePrinting;
    }

    /**
     * Getter method for property <tt>dcm</tt>.
     * @return property value of dcm
     */
    public boolean isDcm() {
        return dcm;
    }

    /**
     * Setter method for property <tt>dcm</tt>.
     * @param dcm
     *            value to be assigned to property dcm
     */
    public void setDcm(boolean dcm) {
        this.dcm = dcm;
    }

    /**
     * Getter method for property <tt>staff</tt>.
     * @return property value of staff
     */
    public boolean isStaff() {
        return staff;
    }

    /**
     * Setter method for property <tt>staff</tt>.
     * @param staff
     *            value to be assigned to property staff
     */
    public void setStaff(boolean staff) {
        this.staff = staff;
    }

    /**
     * Getter method for property <tt>p2v</tt>.
     * @return property value of p2v
     */
    public boolean isP2v() {
        return p2v;
    }

    /**
     * Setter method for property <tt>p2v</tt>.
     * @param p2v
     *            value to be assigned to property p2v
     */
    public void setP2v(boolean p2v) {
        this.p2v = p2v;
    }

    /**
     * Getter method for property <tt>vmware</tt>.
     * @return property value of vmware
     */
    public boolean isVmware() {
        return vmware;
    }

    /**
     * Setter method for property <tt>vmware</tt>.
     * @param vmware
     *            value to be assigned to property vmware
     */
    public void setVmware(boolean vmware) {
        this.vmware = vmware;
    }

    /**
     * The toString method.
     * @return the string for this entity
     */
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("{").append(super.toString());
        sb.append(", vmware:").append(vmware);
        sb.append(", p2v:").append(p2v);
        sb.append(", staff:").append(staff);
        sb.append(", dcm:").append(dcm);
        sb.append(", bluePrinting:").append(bluePrinting).append("}");
        return sb.toString();
    }
}

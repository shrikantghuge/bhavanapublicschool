/*
 * This code is copyright (c) 2014 EMC Corporation
 */
package com.emc.gs.tools.srf.model.isilon;

import com.emc.gs.tools.srf.model.IdentifiableEntity;

/**
 * <p>
 * This is IsilonHardwareUpgrade entity class.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safety.
 * </p>
 * 
 * @author TCSASSEMBLER
 * @version 1.0
 * @since SRT Phase 3-3 - Implement Isilon and ViPR Tabs Assembly
 */
public class IsilonHardwareUpgrade extends IdentifiableEntity {

    /**
     * Perform Pre and Post Upgrade Configuration?
     */
    private Boolean performConfig;

    /**
     * # of Isilon nodes to upgrade.
     */
    private Integer nodesNum;

    /**
     * <p>
     * The default constructor.
     * </p>
     */
    public IsilonHardwareUpgrade() {
    }

    /**
     * Getter method for property <tt>performConfig</tt>.
     * 
     * @return property value of performConfig
     */
    public Boolean getPerformConfig() {
        return performConfig;
    }

    /**
     * Setter method for property <tt>performConfig</tt>.
     * 
     * @param performConfig
     *            value to be assigned to property performConfig
     */
    public void setPerformConfig(Boolean performConfig) {
        this.performConfig = performConfig;
    }

    /**
     * Getter method for property <tt>nodesNum</tt>.
     * 
     * @return property value of nodesNum
     */
    public Integer getNodesNum() {
        return nodesNum;
    }

    /**
     * Setter method for property <tt>nodesNum</tt>.
     * 
     * @param nodesNum
     *            value to be assigned to property nodesNum
     */
    public void setNodesNum(Integer nodesNum) {
        this.nodesNum = nodesNum;
    }

}

/*
 * This code is copyright (c) 2014 EMC Corporation
 */
package com.emc.gs.tools.srf.model.mss;

import java.util.ArrayList;
import java.util.List;

import com.emc.gs.tools.srf.model.IdentifiableEntity;

/**
 * <p>
 * This is MSSRequestData (Disk Retention and Erasure Services) entity class.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safety.
 * </p>
 * <p>
 * <strong>Changes V1.1:</strong> <strong>SRT Phase 3-1 - CTA Rainfinity and MSS Tabs Update Assembly</strong>
 * <ul>
 * <li>Add serviceScopeDescription and generalComment fields.</li>
 * </ul>
 * </p>
 * 
 * @author TCSASSEMBLER
 * @version 1.1
 * @since SRT Phase 3-1 - CTA Rainfinity and MSS Tabs Assembly
 */
public class MSSRequestData extends IdentifiableEntity {

    /**
     * Service scope description.
     */
    private String serviceScopeDescription;

    /**
     * General comment.
     */
    private String generalComment;

    /**
     * Duration (Months).
     */
    private DurationMonths durationMonths;

    /**
     * The array of Disk Retention and Erasure Services.
     */
    private List<MSSArray> mssArray = new ArrayList<MSSArray>();

    /**
     * <p>
     * The default constructor.
     * </p>
     */
    public MSSRequestData() {
    }

    /**
     * Getter method for property <tt>durationMonths</tt>.
     * 
     * @return property value of durationMonths
     */
    public DurationMonths getDurationMonths() {
        return durationMonths;
    }

    /**
     * Setter method for property <tt>durationMonths</tt>.
     * 
     * @param durationMonths
     *            value to be assigned to property durationMonths
     */
    public void setDurationMonths(DurationMonths durationMonths) {
        this.durationMonths = durationMonths;
    }

    /**
     * Getter method for property <tt>mssArray</tt>.
     * 
     * @return property value of mssArray
     */
    public List<MSSArray> getMssArray() {
        return mssArray;
    }

    /**
     * Setter method for property <tt>mssArray</tt>.
     * 
     * @param mssArray
     *            value to be assigned to property mssArray
     */
    public void setMssArray(List<MSSArray> mssArray) {
        this.mssArray = mssArray;
    }

    /**
     * Getter method for property <tt>serviceScopeDescription</tt>.
     * 
     * @return property value of serviceScopeDescription
     */
    public String getServiceScopeDescription() {
        return serviceScopeDescription;
    }

    /**
     * Setter method for property <tt>serviceScopeDescription</tt>.
     * 
     * @param serviceScopeDescription
     *            value to be assigned to property serviceScopeDescription
     */
    public void setServiceScopeDescription(String serviceScopeDescription) {
        this.serviceScopeDescription = serviceScopeDescription;
    }

    /**
     * Getter method for property <tt>generalComment</tt>.
     * 
     * @return property value of generalComment
     */
    public String getGeneralComment() {
        return generalComment;
    }

    /**
     * Setter method for property <tt>generalComment</tt>.
     * 
     * @param generalComment
     *            value to be assigned to property generalComment
     */
    public void setGeneralComment(String generalComment) {
        this.generalComment = generalComment;
    }

}

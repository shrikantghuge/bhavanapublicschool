/*
 * This code is copyright (c) 2014 EMC Corporation
 */
package com.emc.gs.tools.srf.model.mss;

import com.emc.gs.tools.srf.model.IdentifiableEntity;

/**
 * <p>
 * This is GREENPLUM of MSSArray entity class.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safe.
 * </p>
 * 
 * @author TCSASSEMBLER
 * @version 1.0
 * @since SRT Phase 3-1 - CTA Rainfinity and MSS Tabs Update Assembly
 */
public class MSSGreenplum extends IdentifiableEntity {

    /**
     * 2.5 600GB(SAS) 10K disk drives.
     */
    private String greenplum25Inch600GB10K;

    /**
     * 3.5 in 600GB(SAS) 15K disk drives.
     */
    private String greenplum35Inch600GB15K;

    /**
     * 3.5 in 2TB(SATA) disk drives.
     */
    private String greenplum35Inch2TB;

    /**
     * <p>
     * The default constructor.
     * </p>
     */
    public MSSGreenplum() {
    }

    /**
     * Getter method for property <tt>greenplum25Inch600GB10K</tt>.
     * 
     * @return property value of greenplum25Inch600GB10K
     */
    public String getGreenplum25Inch600GB10K() {
        return greenplum25Inch600GB10K;
    }

    /**
     * Setter method for property <tt>greenplum25Inch600GB10K</tt>.
     * 
     * @param greenplum25Inch600GB10K
     *            value to be assigned to property greenplum25Inch600GB10K
     */
    public void setGreenplum25Inch600GB10K(String greenplum25Inch600GB10K) {
        this.greenplum25Inch600GB10K = greenplum25Inch600GB10K;
    }

    /**
     * Getter method for property <tt>greenplum35Inch600GB15K</tt>.
     * 
     * @return property value of greenplum35Inch600GB15K
     */
    public String getGreenplum35Inch600GB15K() {
        return greenplum35Inch600GB15K;
    }

    /**
     * Setter method for property <tt>greenplum35Inch600GB15K</tt>.
     * 
     * @param greenplum35Inch600GB15K
     *            value to be assigned to property greenplum35Inch600GB15K
     */
    public void setGreenplum35Inch600GB15K(String greenplum35Inch600GB15K) {
        this.greenplum35Inch600GB15K = greenplum35Inch600GB15K;
    }

    /**
     * Getter method for property <tt>greenplum35Inch2TB</tt>.
     * 
     * @return property value of greenplum35Inch2TB
     */
    public String getGreenplum35Inch2TB() {
        return greenplum35Inch2TB;
    }

    /**
     * Setter method for property <tt>greenplum35Inch2TB</tt>.
     * 
     * @param greenplum35Inch2TB
     *            value to be assigned to property greenplum35Inch2TB
     */
    public void setGreenplum35Inch2TB(String greenplum35Inch2TB) {
        this.greenplum35Inch2TB = greenplum35Inch2TB;
    }

}

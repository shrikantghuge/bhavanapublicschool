/*
 * This code is copyright (c) 2014 EMC Corporation.
 */
package com.emc.gs.tools.srf.model;

/**
 * <p>
 * This is DeliveryGeography entity class.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safety.
 * </p>
 *
 * @author MonicaMuranyi
 * @since SRT 1.1 DEC 2014 Updates Assembly
 * @version 1.0
 */
public class DeliveryGeography extends LookupCodeEntity {
    /**
     * <p>
     * The default constructor.
     * </p>
     */
    public DeliveryGeography() {
        // Empty
    }
}

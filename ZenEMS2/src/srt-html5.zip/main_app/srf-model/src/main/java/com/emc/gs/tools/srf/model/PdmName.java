/*
 * This code is copyright (c) 2013 - 2014 EMC Corporation.
 */
package com.emc.gs.tools.srf.model;


/**
 * <p>
 * This is PdmName entity class.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safety.
 * </p>
 *
 * <p>
 * <strong>Changes:</strong>
 * <strong>SRT Release Assembly - Base</strong>
 * <ul>
 * <li>Release_assembly_tasks.xls Row#9: Added new properties</li>
 * </ul>
 * </p>
 *
 * @author faeton, stevenfrog, TCSASSEMBLER
 * @version 1.1
 */
public class PdmName extends IdentifiableEntity {
	/**
	 * <p>
	 * The division;
	 * </p>
	 * @since 1.1
	 */
	private Division division;
    /**
     * <p>
     * The pdmName.
     * </p>
     */
    private String pdmName;
    /**
     * <p>
     * The title.
     * </p>
	 * @since 1.1
     */
    private String title;
    /**
     * <p>
     * The address1.
     * </p>
	 * @since 1.1
     */
    private String address1;
    /**
     * <p>
     * The address2.
     * </p>
	 * @since 1.1
     */
    private String address2;
    /**
     * <p>
     * The city.
     * </p>
	 * @since 1.1
     */
    private String city;
    /**
     * <p>
     * The state.
     * </p>
	 * @since 1.1
     */
    private String state;
    /**
     * <p>
     * The postalCode.
     * </p>
	 * @since 1.1
     */
    private String postalCode;
    /**
     * <p>
     * The officeNumber.
     * </p>
	 * @since 1.1
     */
    private String officeNumber;
    /**
     * <p>
     * The faxNumber.
     * </p>
	 * @since 1.1
     */
    private String faxNumber;
    /**
     * <p>
     * The mobileNumber.
     * </p>
	 * @since 1.1
     */
    private String mobileNumber;
    /**
     * <p>
     * The emailAddress.
     * </p>
	 * @since 1.1
     */
    private String emailAddress;

    /**
     * <p>
     * The default constructor.
     * </p>
     */
    public PdmName() {
        // Empty
    }

    /**
     * <p>
     * Retrieves the division field.
     * </p>
     *
     * @return the division
     */
    public Division getDivision() {
        return division;
    }

    /**
     * <p>
     * Sets the value to division field.
     * </p>
     *
     * @param division
     *            the division to set
     */
    public void setDivision(Division division) {
        this.division = division;
    }

    /**
     * <p>
     * Retrieves the pdmName field.
     * </p>
     *
     * @return the pdmName
     */
    public String getPdmName() {
        return pdmName;
    }

    /**
     * <p>
     * Sets the value to pdmName field.
     * </p>
     *
     * @param pdmName
     *            the pdmName to set
     */
    public void setPdmName(String pdmName) {
        this.pdmName = pdmName;
    }

    /**
     * <p>
     * Retrieves the title field.
     * </p>
     *
     * @return the title
     */
    public String getTitle() {
        return title;
    }

    /**
     * <p>
     * Sets the value to title field.
     * </p>
     *
     * @param title
     *            the title to set
     */
    public void setTitle(String title) {
        this.title = title;
    }

    /**
     * <p>
     * Retrieves the address1 field.
     * </p>
     *
     * @return the address1
     */
    public String getAddress1() {
        return address1;
    }

    /**
     * <p>
     * Sets the value to address1 field.
     * </p>
     *
     * @param address1
     *            the address1 to set
     */
    public void setAddress1(String address1) {
        this.address1 = address1;
    }

    /**
     * <p>
     * Retrieves the address2 field.
     * </p>
     *
     * @return the address2
     */
    public String getAddress2() {
        return address2;
    }

    /**
     * <p>
     * Sets the value to address2 field.
     * </p>
     *
     * @param address2
     *            the address2 to set
     */
    public void setAddress2(String address2) {
        this.address2 = address2;
    }

    /**
     * <p>
     * Retrieves the city field.
     * </p>
     *
     * @return the city
     */
    public String getCity() {
        return city;
    }

    /**
     * <p>
     * Sets the value to city field.
     * </p>
     *
     * @param city
     *            the city to set
     */
    public void setCity(String city) {
        this.city = city;
    }

    /**
     * <p>
     * Retrieves the state field.
     * </p>
     *
     * @return the state
     */
    public String getState() {
        return state;
    }

    /**
     * <p>
     * Sets the value to state field.
     * </p>
     *
     * @param state
     *            the state to set
     */
    public void setState(String state) {
        this.state = state;
    }

    /**
     * <p>
     * Retrieves the postalCode field.
     * </p>
     *
     * @return the postalCode
     */
    public String getPostalCode() {
        return postalCode;
    }

    /**
     * <p>
     * Sets the value to postalCode field.
     * </p>
     *
     * @param postalCode
     *            the postalCode to set
     */
    public void setPostalCode(String postalCode) {
        this.postalCode = postalCode;
    }

    /**
     * <p>
     * Retrieves the officeNumber field.
     * </p>
     *
     * @return the officeNumber
     */
    public String getOfficeNumber() {
        return officeNumber;
    }

    /**
     * <p>
     * Sets the value to officeNumber field.
     * </p>
     *
     * @param officeNumber
     *            the officeNumber to set
     */
    public void setOfficeNumber(String officeNumber) {
        this.officeNumber = officeNumber;
    }

    /**
     * <p>
     * Retrieves the faxNumber field.
     * </p>
     *
     * @return the faxNumber
     */
    public String getFaxNumber() {
        return faxNumber;
    }

    /**
     * <p>
     * Sets the value to faxNumber field.
     * </p>
     *
     * @param faxNumber
     *            the faxNumber to set
     */
    public void setFaxNumber(String faxNumber) {
        this.faxNumber = faxNumber;
    }

    /**
     * <p>
     * Retrieves the mobileNumber field.
     * </p>
     *
     * @return the mobileNumber
     */
    public String getMobileNumber() {
        return mobileNumber;
    }

    /**
     * <p>
     * Sets the value to mobileNumber field.
     * </p>
     *
     * @param mobileNumber
     *            the mobileNumber to set
     */
    public void setMobileNumber(String mobileNumber) {
        this.mobileNumber = mobileNumber;
    }

    /**
     * <p>
     * Retrieves the emailAddress field.
     * </p>
     *
     * @return the emailAddress
     */
    public String getEmailAddress() {
        return emailAddress;
    }

    /**
     * <p>
     * Sets the value to emailAddress field.
     * </p>
     *
     * @param emailAddress
     *            the emailAddress to set
     */
    public void setEmailAddress(String emailAddress) {
        this.emailAddress = emailAddress;
    }

    /**
     * The toString method.
     *
     * @return the string for this entity
     */
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("{").append(super.toString());
        sb.append(", division:").append(division);
        sb.append(", pdmName:").append(pdmName);
        sb.append(", title:").append(title);
        sb.append(", address1:").append(address1);
        sb.append(", address2:").append(address2);
        sb.append(", city:").append(city);
        sb.append(", state:").append(state);
        sb.append(", postalCode:").append(postalCode);
        sb.append(", officeNumber:").append(officeNumber);
        sb.append(", faxNumber:").append(faxNumber);
        sb.append(", mobileNumber:").append(mobileNumber);
        sb.append(", emailAddress:").append(emailAddress).append("}");
        return sb.toString();
    }
}

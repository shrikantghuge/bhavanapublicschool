/*
 * This code is copyright (c) 2014 EMC Corporation
 */
package com.emc.gs.tools.srf.model.dpad;

import com.emc.gs.tools.srf.model.IdentifiableEntity;

/**
 * <p>
 * The base entity class contains common fields of AvamarDesign and AvamarImplementation.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safety.
 * </p>
 * 
 * @author TCSASSEMBLER
 * @version 1.0
 * @since SRT Phase 3-5 - BRS Tabs Part 1 Assembly
 */
public abstract class AvamarDesignImplBase extends IdentifiableEntity {

    /**
     * Avamar plugins data.
     */
    private AvamarPlugins plugins;

    /**
     * Avamar Options data.
     */
    private AvamarOptions options;

    /**
     * # of Avamar Servers(Count one per AVE,Single Node and/or Grid).
     */
    private Integer serversNum;

    /**
     * # of Avamar clients in design.
     */
    private Integer clientsNum;

    /**
     * # of ESX Servers for Avamar Integration.
     */
    private Integer esxServersNum;

    /**
     * # of Avamar Image Level Backups to Configure.
     */
    private Integer imageLevelBackupsNum;

    /**
     * <p>
     * The default constructor.
     * </p>
     */
    public AvamarDesignImplBase() {
    }

    /**
     * Getter method for property <tt>plugins</tt>.
     * 
     * @return property value of plugins
     */
    public AvamarPlugins getPlugins() {
        return plugins;
    }

    /**
     * Setter method for property <tt>plugins</tt>.
     * 
     * @param plugins
     *            value to be assigned to property plugins
     */
    public void setPlugins(AvamarPlugins plugins) {
        this.plugins = plugins;
    }

    /**
     * Getter method for property <tt>options</tt>.
     * 
     * @return property value of options
     */
    public AvamarOptions getOptions() {
        return options;
    }

    /**
     * Setter method for property <tt>options</tt>.
     * 
     * @param options
     *            value to be assigned to property options
     */
    public void setOptions(AvamarOptions options) {
        this.options = options;
    }

    /**
     * Getter method for property <tt>serversNum</tt>.
     * 
     * @return property value of serversNum
     */
    public Integer getServersNum() {
        return serversNum;
    }

    /**
     * Setter method for property <tt>serversNum</tt>.
     * 
     * @param serversNum
     *            value to be assigned to property serversNum
     */
    public void setServersNum(Integer serversNum) {
        this.serversNum = serversNum;
    }

    /**
     * Getter method for property <tt>clientsNum</tt>.
     * 
     * @return property value of clientsNum
     */
    public Integer getClientsNum() {
        return clientsNum;
    }

    /**
     * Setter method for property <tt>clientsNum</tt>.
     * 
     * @param clientsNum
     *            value to be assigned to property clientsNum
     */
    public void setClientsNum(Integer clientsNum) {
        this.clientsNum = clientsNum;
    }

    /**
     * Getter method for property <tt>esxServersNum</tt>.
     * 
     * @return property value of esxServersNum
     */
    public Integer getEsxServersNum() {
        return esxServersNum;
    }

    /**
     * Setter method for property <tt>esxServersNum</tt>.
     * 
     * @param esxServersNum
     *            value to be assigned to property esxServersNum
     */
    public void setEsxServersNum(Integer esxServersNum) {
        this.esxServersNum = esxServersNum;
    }

    /**
     * Getter method for property <tt>imageLevelBackupsNum</tt>.
     * 
     * @return property value of imageLevelBackupsNum
     */
    public Integer getImageLevelBackupsNum() {
        return imageLevelBackupsNum;
    }

    /**
     * Setter method for property <tt>imageLevelBackupsNum</tt>.
     * 
     * @param imageLevelBackupsNum
     *            value to be assigned to property imageLevelBackupsNum
     */
    public void setImageLevelBackupsNum(Integer imageLevelBackupsNum) {
        this.imageLevelBackupsNum = imageLevelBackupsNum;
    }

}

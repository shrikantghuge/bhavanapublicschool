/*
 * This code is copyright (c) 2014 EMC Corporation.
 */
package com.emc.gs.tools.srf.model.change;

import java.util.Map;

import com.emc.gs.tools.srf.model.IdentifiableEntity;

/**
 * Role group record.
 *
 * <p>
 * <strong>Changes V1.1:</strong>
 * <strong>SRT Phase 4 - ET Assembly 2</strong>
 * <ul>
 * <li>Change hours field from List to Map type.</li>
 * </ul>
 * </p>
 * 
 * @author TCSASSEMBLER
 * @version 1.1
 * @since SRT Phase 3-2 - Move Request and Change Request Tabs Assembly
 */
public class RoleHoursByMonth extends IdentifiableEntity {

    /**
     * Select Role.
     */
    private String role;

    /**
     * Total Number of Hours.
     */
    private Map<Integer, String> hours;

    /**
     * Empty constructor.
     */
    public RoleHoursByMonth() {
    }

    /**
     * Gets the value of the field <code>role</code>.
     * @return the role
     */
    public String getRole() {
        return role;
    }

    /**
     * Sets the value of the field <code>role</code>.
     * @param role the role to set
     */
    public void setRole(String role) {
        this.role = role;
    }

    /**
     * Gets the value of the field <code>hours</code>.
     * @return the hours
     */
    public Map<Integer, String> getHours() {
        return hours;
    }

    /**
     * Sets the value of the field <code>hours</code>.
     * @param hours the hours to set
     */
    public void setHours(Map<Integer, String> hours) {
        this.hours = hours;
    }

    /**
     * Generates a string representation of this entity.
     * 
     * @return the properties of this object.
     */
    @Override
    public String toString() {
        return "RoleHoursByMonth [role=" + role + ", hours=" + hours + ", getId()=" + getId() + "]";
    }
}

/*
 * This code is copyright (c) 2014 EMC Corporation
 */
package com.emc.gs.tools.srf.model.dpad;

import com.emc.gs.tools.srf.model.IdentifiableEntity;

/**
 * <p>
 * This is NetworkerApplicationBackupsBase entity class.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safety.
 * </p>
 *
 * <p>
 * Version 1.1 ( Assembly 1.0) Change notes:
 *   <ol>
 *     <li>Added {@link #meditech} property.</li>
 *   </ol>
 * </p>
 * 
 * @author isv
 * @version 1.1
 * @since SRT Phase 3-5 - BRS Tabs Part 3 Assembly
 */
public abstract class NetworkerApplicationBackupsBase extends IdentifiableEntity {

    /**
     * Represents whether "Microsoft SQL" application is selected.
     */
    private boolean msSql;

    /**
     * Represents whether "Microsoft Exchange" application is selected.
     */
    private boolean exchange;

    /**
     * Represents whether "Microsoft Sharepoint" application is selected.
     */
    private boolean sharePoint;

    /**
     * Represents whether "Microsoft Hyper-V" application is selected.
     */
    private boolean hyperv;

    /**
     * Represents whether "Oracle" application is selected.
     */
    private boolean oracle;

    /**
     * Represents whether "MySQL" application is selected.
     */
    private boolean mySql;

    /**
     * Represents whether "Lotus Notes" application is selected.
     */
    private boolean lotusNotes;

    /**
     * Represents whether "SAP" application is selected.
     */
    private boolean sap;

    /**
     * Include Microsoft SQL Server Cluster?
     */
    private Boolean includeMSSqlServerCluster;

    /**
     * # of Microsoft SQL Servers.
     */
    private Integer msSqlServersNum;

    /**
     * Do you want Exchange Granular Backups to Be Implemented?
     */
    private Boolean implementExchangeGranularBackups;

    /**
     * Include Clustered Exchange Servers?
     */
    private Boolean includeClusteredExchangeServers;

    /**
     * # of Microsoft Exchange Mailbox Servers.
     */
    private Integer exchangeMailboxServersNum;

    /**
     * # of Microsoft Exchange Database Stores.
     */
    private Integer exchangeDatabaseStoresNum;

    /**
     * Include Microsoft SQL Server Cluster?
     */
    private Boolean sharePointIncludeMSSqlServerCluster;

    /**
     * Include Granular SharePoint Backups?
     */
    private Boolean includeGranularSharePointBackups;

    /**
     * Include SharePoint Distributed Environment?
     */
    private Boolean includeSharePointDistributedEnv;

    /**
     * # of Microsoft SQL Servers.
     */
    private Integer sharePointMSSqlServersNum;

    /**
     * # of SharePoint Farms.
     */
    private Integer sharePointFarmsNum;

    /**
     * # of SharePoint Web Applications.
     */
    private Integer sharePointWebAppsNum;

    /**
     * # of SharePoint Sites.
     */
    private Integer sharePointSitesNum;

    /**
     * # of SharePoint Sub-Sites.
     */
    private Integer sharePointSubSitesNum;

    /**
     * Are any of the Hyper-V Environments Clustered?
     */
    private Boolean hypervEnvClustered;

    /**
     * # of Microsoft Hyper-V Servers to be Backed Up with NMM.
     */
    private Integer hypervServersNum;

    /**
     * Are there any clustered Oracle Servers to be backed up?
     */
    private Boolean clusteredOracleServers;

    /**
     * # of Oracle Database Servers for RMAN Backup.
     */
    private Integer oracleRMANBackupServersNum;

    /**
     * # of Oracle Databases for Backup Configuration.
     */
    private Integer oracleBackupConfigDatabasesNum;

    /**
     * MySql Environment Clustered?
     */
    private Boolean mySqlEnvClustered;

    /**
     * # of MySQL Servers.
     */
    private Integer mySqlServersNum;

    /**
     * Are any of the Lotus Notes Applications Clustered?
     */
    private Boolean lotusNotesAppsClustered;

    /**
     * # of IBM Lotus Domino Instances.
     */
    private Integer lotusDominoInstancesNum;

    /**
     * Is SAP Environment Clustered?
     */
    private Boolean sapEnvClustered;

    /**
     * # of SAP Application Servers.
     */
    private Integer sapAppServersNum;

    /**
     * <p>A <code>boolean</code> providing the value for meditech property.</p>
     * 
     * @since 1.1
     */
    private boolean meditech;

    /**
     * <p>
     * The default constructor.
     * </p>
     */
    protected NetworkerApplicationBackupsBase() {
    }

    /**
     * Getter method for property <tt>msSql</tt>.
     * 
     * @return property value of msSql
     */
    public boolean isMsSql() {
        return msSql;
    }

    /**
     * Setter method for property <tt>msSql</tt>.
     * 
     * @param msSql
     *            value to be assigned to property msSql
     */
    public void setMsSql(boolean msSql) {
        this.msSql = msSql;
    }

    /**
     * Getter method for property <tt>exchange</tt>.
     * 
     * @return property value of exchange
     */
    public boolean isExchange() {
        return exchange;
    }

    /**
     * Setter method for property <tt>exchange</tt>.
     * 
     * @param exchange
     *            value to be assigned to property exchange
     */
    public void setExchange(boolean exchange) {
        this.exchange = exchange;
    }

    /**
     * Getter method for property <tt>sharePoint</tt>.
     * 
     * @return property value of sharePoint
     */
    public boolean isSharePoint() {
        return sharePoint;
    }

    /**
     * Setter method for property <tt>sharePoint</tt>.
     * 
     * @param sharePoint
     *            value to be assigned to property sharePoint
     */
    public void setSharePoint(boolean sharePoint) {
        this.sharePoint = sharePoint;
    }

    /**
     * Getter method for property <tt>hyperv</tt>.
     * 
     * @return property value of hyperv
     */
    public boolean isHyperv() {
        return hyperv;
    }

    /**
     * Setter method for property <tt>hyperv</tt>.
     * 
     * @param hyperv
     *            value to be assigned to property hyperv
     */
    public void setHyperv(boolean hyperv) {
        this.hyperv = hyperv;
    }

    /**
     * Getter method for property <tt>oracle</tt>.
     * 
     * @return property value of oracle
     */
    public boolean isOracle() {
        return oracle;
    }

    /**
     * Setter method for property <tt>oracle</tt>.
     * 
     * @param oracle
     *            value to be assigned to property oracle
     */
    public void setOracle(boolean oracle) {
        this.oracle = oracle;
    }

    /**
     * Getter method for property <tt>mySql</tt>.
     * 
     * @return property value of mySql
     */
    public boolean isMySql() {
        return mySql;
    }

    /**
     * Setter method for property <tt>mySql</tt>.
     * 
     * @param mySql
     *            value to be assigned to property mySql
     */
    public void setMySql(boolean mySql) {
        this.mySql = mySql;
    }

    /**
     * Getter method for property <tt>lotusNotes</tt>.
     * 
     * @return property value of lotusNotes
     */
    public boolean isLotusNotes() {
        return lotusNotes;
    }

    /**
     * Setter method for property <tt>lotusNotes</tt>.
     * 
     * @param lotusNotes
     *            value to be assigned to property lotusNotes
     */
    public void setLotusNotes(boolean lotusNotes) {
        this.lotusNotes = lotusNotes;
    }

    /**
     * Getter method for property <tt>sap</tt>.
     * 
     * @return property value of sap
     */
    public boolean isSap() {
        return sap;
    }

    /**
     * Setter method for property <tt>sap</tt>.
     * 
     * @param sap
     *            value to be assigned to property sap
     */
    public void setSap(boolean sap) {
        this.sap = sap;
    }

    /**
     * Getter method for property <tt>includeMSSqlServerCluster</tt>.
     * 
     * @return property value of includeMSSqlServerCluster
     */
    public Boolean getIncludeMSSqlServerCluster() {
        return includeMSSqlServerCluster;
    }

    /**
     * Setter method for property <tt>includeMSSqlServerCluster</tt>.
     * 
     * @param includeMSSqlServerCluster
     *            value to be assigned to property includeMSSqlServerCluster
     */
    public void setIncludeMSSqlServerCluster(Boolean includeMSSqlServerCluster) {
        this.includeMSSqlServerCluster = includeMSSqlServerCluster;
    }

    /**
     * Getter method for property <tt>msSqlServersNum</tt>.
     * 
     * @return property value of msSqlServersNum
     */
    public Integer getMsSqlServersNum() {
        return msSqlServersNum;
    }

    /**
     * Setter method for property <tt>msSqlServersNum</tt>.
     * 
     * @param msSqlServersNum
     *            value to be assigned to property msSqlServersNum
     */
    public void setMsSqlServersNum(Integer msSqlServersNum) {
        this.msSqlServersNum = msSqlServersNum;
    }

    /**
     * Getter method for property <tt>implementExchangeGranularBackups</tt>.
     * 
     * @return property value of implementExchangeGranularBackups
     */
    public Boolean getImplementExchangeGranularBackups() {
        return implementExchangeGranularBackups;
    }

    /**
     * Setter method for property <tt>implementExchangeGranularBackups</tt>.
     * 
     * @param implementExchangeGranularBackups
     *            value to be assigned to property implementExchangeGranularBackups
     */
    public void setImplementExchangeGranularBackups(Boolean implementExchangeGranularBackups) {
        this.implementExchangeGranularBackups = implementExchangeGranularBackups;
    }

    /**
     * Getter method for property <tt>includeClusteredExchangeServers</tt>.
     * 
     * @return property value of includeClusteredExchangeServers
     */
    public Boolean getIncludeClusteredExchangeServers() {
        return includeClusteredExchangeServers;
    }

    /**
     * Setter method for property <tt>includeClusteredExchangeServers</tt>.
     * 
     * @param includeClusteredExchangeServers
     *            value to be assigned to property includeClusteredExchangeServers
     */
    public void setIncludeClusteredExchangeServers(Boolean includeClusteredExchangeServers) {
        this.includeClusteredExchangeServers = includeClusteredExchangeServers;
    }

    /**
     * Getter method for property <tt>exchangeMailboxServersNum</tt>.
     * 
     * @return property value of exchangeMailboxServersNum
     */
    public Integer getExchangeMailboxServersNum() {
        return exchangeMailboxServersNum;
    }

    /**
     * Setter method for property <tt>exchangeMailboxServersNum</tt>.
     * 
     * @param exchangeMailboxServersNum
     *            value to be assigned to property exchangeMailboxServersNum
     */
    public void setExchangeMailboxServersNum(Integer exchangeMailboxServersNum) {
        this.exchangeMailboxServersNum = exchangeMailboxServersNum;
    }

    /**
     * Getter method for property <tt>exchangeDatabaseStoresNum</tt>.
     * 
     * @return property value of exchangeDatabaseStoresNum
     */
    public Integer getExchangeDatabaseStoresNum() {
        return exchangeDatabaseStoresNum;
    }

    /**
     * Setter method for property <tt>exchangeDatabaseStoresNum</tt>.
     * 
     * @param exchangeDatabaseStoresNum
     *            value to be assigned to property exchangeDatabaseStoresNum
     */
    public void setExchangeDatabaseStoresNum(Integer exchangeDatabaseStoresNum) {
        this.exchangeDatabaseStoresNum = exchangeDatabaseStoresNum;
    }

    /**
     * Getter method for property <tt>sharePointIncludeMSSqlServerCluster</tt>.
     * 
     * @return property value of sharePointIncludeMSSqlServerCluster
     */
    public Boolean getSharePointIncludeMSSqlServerCluster() {
        return sharePointIncludeMSSqlServerCluster;
    }

    /**
     * Setter method for property <tt>sharePointIncludeMSSqlServerCluster</tt>.
     * 
     * @param sharePointIncludeMSSqlServerCluster
     *            value to be assigned to property sharePointIncludeMSSqlServerCluster
     */
    public void setSharePointIncludeMSSqlServerCluster(Boolean sharePointIncludeMSSqlServerCluster) {
        this.sharePointIncludeMSSqlServerCluster = sharePointIncludeMSSqlServerCluster;
    }

    /**
     * Getter method for property <tt>includeGranularSharePointBackups</tt>.
     * 
     * @return property value of includeGranularSharePointBackups
     */
    public Boolean getIncludeGranularSharePointBackups() {
        return includeGranularSharePointBackups;
    }

    /**
     * Setter method for property <tt>includeGranularSharePointBackups</tt>.
     * 
     * @param includeGranularSharePointBackups
     *            value to be assigned to property includeGranularSharePointBackups
     */
    public void setIncludeGranularSharePointBackups(Boolean includeGranularSharePointBackups) {
        this.includeGranularSharePointBackups = includeGranularSharePointBackups;
    }

    /**
     * Getter method for property <tt>includeSharePointDistributedEnv</tt>.
     * 
     * @return property value of includeSharePointDistributedEnv
     */
    public Boolean getIncludeSharePointDistributedEnv() {
        return includeSharePointDistributedEnv;
    }

    /**
     * Setter method for property <tt>includeSharePointDistributedEnv</tt>.
     * 
     * @param includeSharePointDistributedEnv
     *            value to be assigned to property includeSharePointDistributedEnv
     */
    public void setIncludeSharePointDistributedEnv(Boolean includeSharePointDistributedEnv) {
        this.includeSharePointDistributedEnv = includeSharePointDistributedEnv;
    }

    /**
     * Getter method for property <tt>sharePointMSSqlServersNum</tt>.
     * 
     * @return property value of sharePointMSSqlServersNum
     */
    public Integer getSharePointMSSqlServersNum() {
        return sharePointMSSqlServersNum;
    }

    /**
     * Setter method for property <tt>sharePointMSSqlServersNum</tt>.
     * 
     * @param sharePointMSSqlServersNum
     *            value to be assigned to property sharePointMSSqlServersNum
     */
    public void setSharePointMSSqlServersNum(Integer sharePointMSSqlServersNum) {
        this.sharePointMSSqlServersNum = sharePointMSSqlServersNum;
    }

    /**
     * Getter method for property <tt>sharePointFarmsNum</tt>.
     * 
     * @return property value of sharePointFarmsNum
     */
    public Integer getSharePointFarmsNum() {
        return sharePointFarmsNum;
    }

    /**
     * Setter method for property <tt>sharePointFarmsNum</tt>.
     * 
     * @param sharePointFarmsNum
     *            value to be assigned to property sharePointFarmsNum
     */
    public void setSharePointFarmsNum(Integer sharePointFarmsNum) {
        this.sharePointFarmsNum = sharePointFarmsNum;
    }

    /**
     * Getter method for property <tt>sharePointWebAppsNum</tt>.
     * 
     * @return property value of sharePointWebAppsNum
     */
    public Integer getSharePointWebAppsNum() {
        return sharePointWebAppsNum;
    }

    /**
     * Setter method for property <tt>sharePointWebAppsNum</tt>.
     * 
     * @param sharePointWebAppsNum
     *            value to be assigned to property sharePointWebAppsNum
     */
    public void setSharePointWebAppsNum(Integer sharePointWebAppsNum) {
        this.sharePointWebAppsNum = sharePointWebAppsNum;
    }

    /**
     * Getter method for property <tt>sharePointSitesNum</tt>.
     * 
     * @return property value of sharePointSitesNum
     */
    public Integer getSharePointSitesNum() {
        return sharePointSitesNum;
    }

    /**
     * Setter method for property <tt>sharePointSitesNum</tt>.
     * 
     * @param sharePointSitesNum
     *            value to be assigned to property sharePointSitesNum
     */
    public void setSharePointSitesNum(Integer sharePointSitesNum) {
        this.sharePointSitesNum = sharePointSitesNum;
    }

    /**
     * Getter method for property <tt>sharePointSubSitesNum</tt>.
     * 
     * @return property value of sharePointSubSitesNum
     */
    public Integer getSharePointSubSitesNum() {
        return sharePointSubSitesNum;
    }

    /**
     * Setter method for property <tt>sharePointSubSitesNum</tt>.
     * 
     * @param sharePointSubSitesNum
     *            value to be assigned to property sharePointSubSitesNum
     */
    public void setSharePointSubSitesNum(Integer sharePointSubSitesNum) {
        this.sharePointSubSitesNum = sharePointSubSitesNum;
    }

    /**
     * Getter method for property <tt>hypervEnvClustered</tt>.
     * 
     * @return property value of hypervEnvClustered
     */
    public Boolean getHypervEnvClustered() {
        return hypervEnvClustered;
    }

    /**
     * Setter method for property <tt>hypervEnvClustered</tt>.
     * 
     * @param hypervEnvClustered
     *            value to be assigned to property hypervEnvClustered
     */
    public void setHypervEnvClustered(Boolean hypervEnvClustered) {
        this.hypervEnvClustered = hypervEnvClustered;
    }

    /**
     * Getter method for property <tt>hypervServersNum</tt>.
     * 
     * @return property value of hypervServersNum
     */
    public Integer getHypervServersNum() {
        return hypervServersNum;
    }

    /**
     * Setter method for property <tt>hypervServersNum</tt>.
     * 
     * @param hypervServersNum
     *            value to be assigned to property hypervServersNum
     */
    public void setHypervServersNum(Integer hypervServersNum) {
        this.hypervServersNum = hypervServersNum;
    }

    /**
     * Getter method for property <tt>clusteredOracleServers</tt>.
     * 
     * @return property value of clusteredOracleServers
     */
    public Boolean getClusteredOracleServers() {
        return clusteredOracleServers;
    }

    /**
     * Setter method for property <tt>clusteredOracleServers</tt>.
     * 
     * @param clusteredOracleServers
     *            value to be assigned to property clusteredOracleServers
     */
    public void setClusteredOracleServers(Boolean clusteredOracleServers) {
        this.clusteredOracleServers = clusteredOracleServers;
    }

    /**
     * Getter method for property <tt>oracleRMANBackupServersNum</tt>.
     * 
     * @return property value of oracleRMANBackupServersNum
     */
    public Integer getOracleRMANBackupServersNum() {
        return oracleRMANBackupServersNum;
    }

    /**
     * Setter method for property <tt>oracleRMANBackupServersNum</tt>.
     * 
     * @param oracleRMANBackupServersNum
     *            value to be assigned to property oracleRMANBackupServersNum
     */
    public void setOracleRMANBackupServersNum(Integer oracleRMANBackupServersNum) {
        this.oracleRMANBackupServersNum = oracleRMANBackupServersNum;
    }

    /**
     * Getter method for property <tt>oracleBackupConfigDatabasesNum</tt>.
     * 
     * @return property value of oracleBackupConfigDatabasesNum
     */
    public Integer getOracleBackupConfigDatabasesNum() {
        return oracleBackupConfigDatabasesNum;
    }

    /**
     * Setter method for property <tt>oracleBackupConfigDatabasesNum</tt>.
     * 
     * @param oracleBackupConfigDatabasesNum
     *            value to be assigned to property oracleBackupConfigDatabasesNum
     */
    public void setOracleBackupConfigDatabasesNum(Integer oracleBackupConfigDatabasesNum) {
        this.oracleBackupConfigDatabasesNum = oracleBackupConfigDatabasesNum;
    }

    /**
     * Getter method for property <tt>mySqlEnvClustered</tt>.
     * 
     * @return property value of mySqlEnvClustered
     */
    public Boolean getMySqlEnvClustered() {
        return mySqlEnvClustered;
    }

    /**
     * Setter method for property <tt>mySqlEnvClustered</tt>.
     * 
     * @param mySqlEnvClustered
     *            value to be assigned to property mySqlEnvClustered
     */
    public void setMySqlEnvClustered(Boolean mySqlEnvClustered) {
        this.mySqlEnvClustered = mySqlEnvClustered;
    }

    /**
     * Getter method for property <tt>mySqlServersNum</tt>.
     * 
     * @return property value of mySqlServersNum
     */
    public Integer getMySqlServersNum() {
        return mySqlServersNum;
    }

    /**
     * Setter method for property <tt>mySqlServersNum</tt>.
     * 
     * @param mySqlServersNum
     *            value to be assigned to property mySqlServersNum
     */
    public void setMySqlServersNum(Integer mySqlServersNum) {
        this.mySqlServersNum = mySqlServersNum;
    }

    /**
     * Getter method for property <tt>lotusNotesAppsClustered</tt>.
     * 
     * @return property value of lotusNotesAppsClustered
     */
    public Boolean getLotusNotesAppsClustered() {
        return lotusNotesAppsClustered;
    }

    /**
     * Setter method for property <tt>lotusNotesAppsClustered</tt>.
     * 
     * @param lotusNotesAppsClustered
     *            value to be assigned to property lotusNotesAppsClustered
     */
    public void setLotusNotesAppsClustered(Boolean lotusNotesAppsClustered) {
        this.lotusNotesAppsClustered = lotusNotesAppsClustered;
    }

    /**
     * Getter method for property <tt>lotusDominoInstancesNum</tt>.
     * 
     * @return property value of lotusDominoInstancesNum
     */
    public Integer getLotusDominoInstancesNum() {
        return lotusDominoInstancesNum;
    }

    /**
     * Setter method for property <tt>lotusDominoInstancesNum</tt>.
     * 
     * @param lotusDominoInstancesNum
     *            value to be assigned to property lotusDominoInstancesNum
     */
    public void setLotusDominoInstancesNum(Integer lotusDominoInstancesNum) {
        this.lotusDominoInstancesNum = lotusDominoInstancesNum;
    }

    /**
     * Getter method for property <tt>sapEnvClustered</tt>.
     * 
     * @return property value of sapEnvClustered
     */
    public Boolean getSapEnvClustered() {
        return sapEnvClustered;
    }

    /**
     * Setter method for property <tt>sapEnvClustered</tt>.
     * 
     * @param sapEnvClustered
     *            value to be assigned to property sapEnvClustered
     */
    public void setSapEnvClustered(Boolean sapEnvClustered) {
        this.sapEnvClustered = sapEnvClustered;
    }

    /**
     * Getter method for property <tt>sapAppServersNum</tt>.
     * 
     * @return property value of sapAppServersNum
     */
    public Integer getSapAppServersNum() {
        return sapAppServersNum;
    }

    /**
     * Setter method for property <tt>sapAppServersNum</tt>.
     * 
     * @param sapAppServersNum
     *            value to be assigned to property sapAppServersNum
     */
    public void setSapAppServersNum(Integer sapAppServersNum) {
        this.sapAppServersNum = sapAppServersNum;
    }

    /**
     * <p>Gets the meditech property.</p>
     *
     * @return a <code>boolean</code> providing the value for meditech property.
     * @since 1.1
     */
    public boolean isMeditech() {
        return this.meditech;
    }

    /**
     * <p>Sets the meditech property.</p>
     *
     * @param meditech a <code>boolean</code> providing the value for meditech property.
     * @since 1.1
     */
    public void setMeditech(boolean meditech) {
        this.meditech = meditech;
    }

}

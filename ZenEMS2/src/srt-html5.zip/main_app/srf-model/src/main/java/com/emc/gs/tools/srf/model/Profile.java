/*
 * This code is copyright (c) 2013 - 2015 EMC Corporation.
 */
package com.emc.gs.tools.srf.model;

/**
 * <p>
 * This model represents Profile data model.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safety.
 * </p>
 *
 * <p>
 * <strong>Changes V1.1:</strong>
 * <strong>SRT Release Assembly - Unified Tab</strong>
 * <ul>
 * <li>Add defaultProfile:boolean field.</li>
 * </ul>
 * </p>
 * 
 * <p>
 * <strong>Changes V1.2:</strong>
 * <strong>SRT Bug Fixes</strong>
 * <ul>
 * <li>Add countryCode field.</li>
 * </ul>
 * </p>
 * 
 * <p>
 * <strong>Changes V1.3:</strong>
 * <strong>SRT Bug Fixes - F157, F158, F159, F160, F161</strong>
 * <ul>
 * <li>Add fromEmailAddress field.</li>
 * </ul>
 * </p>
 *
 * <p>
 * <strong>Changes V1.4:</strong>
 * <strong>SRT Phase 2 Release Assembly</strong>
 * <ul>
 * <li>Change officePhone/mobilePhone/fax fields to Phone type</li>
 * </ul>
 * </p>
 *
 * <p>
 * <strong>Changes V1.5:</strong>
 * <strong>SRT Phase 4 - ET Assembly 2</strong>
 * <ul>
 * <li>Change to extend from CorrelatedIdentifiableEntity.</li>
 * </ul>
 * </p>
 *
 * <p>
 * Version 1.6 Change notes:
 *   <ol>
 *     <li>Removed <code>testSubmitEmailAddress</code> property.</li>
 *     <li>Removed <code>emailOptions</code> property.</li>
 *   </ol>
 * </p>
 *
 * <p>
 * Changes in version 1.7 (SRT 1.1 FEB 2015 Updates - Template Folder Assembly):
 * <ul>
 * <li>Added {@link #templatePermission} property.</li>
 * </ul>
 * <p>
 * 
 * <p>
 * Changes in version 1.8 (SRT 1.1 Approval Process Assembly):
 * <ul>
 * <li>Added {@link #submitter} property.</li>
 * <li>Added {@link #approver} property.</li>
 * </ul>
 * <p>
 *
 * <p>
 * Version 1.9 Change notes:
 *   <ol>
 *     <li>Removed <code>submitter</code> property. All users who are not approvers are treated as submitters.</li>
 *     <li>Added {@link #seCsdName} property.</li>
 *     <li>Added {@link #seCsdPhone} property.</li>
 *     <li>Added {@link #seManagerName} property.</li>
 *   </ol>
 * </p>
 *
 * @author faeton, stevenfrog, isv, duxiaoyang, MonicaMuranyi
 * @version 1.9
 */
public class Profile extends CorrelatedIdentifiableEntity {
    /**
     * <p>
     * The firstName.
     * </p>
     */
    private String firstName;

    /**
     * <p>
     * The lastName.
     * </p>
     */
    private String lastName;

    /**
     * <p>
     * The jobTitle.
     * </p>
     */
    private String jobTitle;
    
    /**
     * <p>
     * The countryCode.
     * </p>
     */
    private String countryCode;

    /**
     * <p>
     * The officePhone.
     * </p>
     */
    private Phone officePhone;

    /**
     * <p>
     * The mobilePhone.
     * </p>
     */
    private Phone mobilePhone;

    /**
     * <p>
     * The fax.
     * </p>
     */
    private Phone fax;

    /**
     * <p>
     * The email.
     * </p>
     */
    private String email;

    /**
     * <p>
     * The division.
     * </p>
     */
    private Division division;

    /**
     * <p>
     * The salesDistrict.
     * </p>
     */
    private SalesDistrict salesDistrict;

    /**
     * <p>
     * The defaultProfile.
     * </p>
     */
    private boolean defaultProfile;

    /**
     * <p>
     * The templatePermission.
     * </p>
     * @since 1.7
     */
    private boolean templatePermission;
    
    /**
     * <p>
     * The approver.
     * </p>
     * @since 1.8
     */
    private boolean approver;
    
    /**
     * <p> The seCsdName. </p>
     * 
     * @since 1.9
     */
    private String seCsdName;

    /**
     * <p> The seCsdPhone. </p>
     * 
     * @since 1.9
     */
    private Phone seCsdPhone;

    /**
     * <p> The seManagerName. </p>
     * 
     * @since 1.9
     */
    private String seManagerName;
    
    /**
     * <p>
     * The default constructor.
     * </p>
     */
    public Profile() {
        // Empty
    }

    /**
     * <p>
     * Retrieves the firstName field.
     * </p>
     *
     * @return the firstName
     */
    public String getFirstName() {
        return firstName;
    }

    /**
     * <p>
     * Sets the value to firstName field.
     * </p>
     *
     * @param firstName
     *            the firstName to set
     */
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    /**
     * <p>
     * Retrieves the lastName field.
     * </p>
     *
     * @return the lastName
     */
    public String getLastName() {
        return lastName;
    }

    /**
     * <p>
     * Sets the value to lastName field.
     * </p>
     *
     * @param lastName
     *            the lastName to set
     */
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    /**
     * <p>
     * Retrieves the jobTitle field.
     * </p>
     *
     * @return the jobTitle
     */
    public String getJobTitle() {
        return jobTitle;
    }

    /**
     * <p>
     * Sets the value to jobTitle field.
     * </p>
     *
     * @param jobTitle
     *            the jobTitle to set
     */
    public void setJobTitle(String jobTitle) {
        this.jobTitle = jobTitle;
    }
    
    /**
     * <p>
     * Retrieves the countryCode field.
     * </p>
     *
     * @return the countryCode
     */
    public String getCountryCode() {
        return countryCode;
    }

    /**
     * <p>
     * Sets the value to countryCode field.
     * </p>
     *
     * @param countryCode
     *            the countryCode to set
     */
    public void setCountryCode(String countryCode) {
        this.countryCode = countryCode;
    }

    /**
     * <p>
     * Retrieves the officePhone field.
     * </p>
     *
     * @return the officePhone
     */
    public Phone getOfficePhone() {
        return officePhone;
    }

    /**
     * <p>
     * Sets the value to officePhone field.
     * </p>
     *
     * @param officePhone
     *            the officePhone to set
     */
    public void setOfficePhone(Phone officePhone) {
        this.officePhone = officePhone;
    }

    /**
     * <p>
     * Retrieves the mobilePhone field.
     * </p>
     *
     * @return the mobilePhone
     */
    public Phone getMobilePhone() {
        return mobilePhone;
    }

    /**
     * <p>
     * Sets the value to mobilePhone field.
     * </p>
     *
     * @param mobilePhone
     *            the mobilePhone to set
     */
    public void setMobilePhone(Phone mobilePhone) {
        this.mobilePhone = mobilePhone;
    }

    /**
     * <p>
     * Retrieves the fax field.
     * </p>
     *
     * @return the fax
     */
    public Phone getFax() {
        return fax;
    }

    /**
     * <p>
     * Sets the value to fax field.
     * </p>
     *
     * @param fax
     *            the fax to set
     */
    public void setFax(Phone fax) {
        this.fax = fax;
    }

    /**
     * <p>
     * Retrieves the email field.
     * </p>
     *
     * @return the email
     */
    public String getEmail() {
        return email;
    }

    /**
     * <p>
     * Sets the value to email field.
     * </p>
     *
     * @param email
     *            the email to set
     */
    public void setEmail(String email) {
        this.email = email;
    }

    /**
     * <p>
     * Retrieves the division field.
     * </p>
     *
     * @return the division
     */
    public Division getDivision() {
        return division;
    }

    /**
     * <p>
     * Sets the value to division field.
     * </p>
     *
     * @param division
     *            the division to set
     */
    public void setDivision(Division division) {
        this.division = division;
    }

    /**
     * <p>
     * Retrieves the salesDistrict field.
     * </p>
     *
     * @return the salesDistrict
     */
    public SalesDistrict getSalesDistrict() {
        return salesDistrict;
    }

    /**
     * <p>
     * Sets the value to salesDistrict field.
     * </p>
     *
     * @param salesDistrict
     *            the salesDistrict to set
     */
    public void setSalesDistrict(SalesDistrict salesDistrict) {
        this.salesDistrict = salesDistrict;
    }

    /**
     * Getter method for property <tt>defaultProfile</tt>.
     * @return property value of defaultProfile
     */
    public boolean isDefaultProfile() {
        return defaultProfile;
    }

    /**
     * Setter method for property <tt>defaultProfile</tt>.
     * @param defaultProfile value to be assigned to property defaultProfile
     */
    public void setDefaultProfile(boolean defaultProfile) {
        this.defaultProfile = defaultProfile;
    }

    /**
     * Getter method for property <tt>templatePermission</tt>.
     * @return property value of templatePermission
     * @since 1.7
     */
    public boolean isTemplatePermission() {
        return templatePermission;
    }

    /**
     * Setter method for property <tt>templatePermission</tt>.
     * @param templatePermission value to be assigned to property templatePermission
     * @since 1.7
     */
    public void setTemplatePermission(boolean templatePermission) {
        this.templatePermission = templatePermission;
    }

    /**
     * <p>Checks if this user is a submitter. All users who are not granted <code>Approver</code> role are treated as
     * submitters.</p>
     *
     * @return a <code>true</code> if user is submitter; <code>false</code> otherwise.
     * @since 1.8
     */
    public boolean isSubmitter() {
        return !isApprover();
    }
    
    /**
     * A dummy setter for readonly "submitter" property.
     * 
     * @param submitter ignored.
     */
    public void setSubmitter(boolean submitter) {
    }

    /**
     * Getter method for property <tt>templatePermission</tt>.
     * @return property value of templatePermission
     * @since 1.8
     */
    public boolean isApprover() {
        return approver;
    }
    
    /**
     * Setter method for property <tt>templatePermission</tt>.
     * @param approver value to be assigned to property templatePermission
     * @since 1.8
     */
    public void setApprover(boolean approver) {
        this.approver = approver;
    }

    /**
     * <p> Retrieves the seCsdName field. </p>
     *
     * @return the seCsdName
     * @since 1.9
     */
    public String getSeCsdName() {
        return seCsdName;
    }

    /**
     * <p> Sets the value to seCsdName field. </p>
     *
     * @param seCsdName the seCsdName to set
     * @since 1.9
     */
    public void setSeCsdName(String seCsdName) {
        this.seCsdName = seCsdName;
    }

    /**
     * <p> Retrieves the seCsdPhone field. </p>
     *
     * @return the seCsdPhone
     * @since 1.9
     */
    public Phone getSeCsdPhone() {
        return seCsdPhone;
    }

    /**
     * <p> Sets the value to seCsdPhone field. </p>
     *
     * @param seCsdPhone the seCsdPhone to set
     * @since 1.9
     */
    public void setSeCsdPhone(Phone seCsdPhone) {
        this.seCsdPhone = seCsdPhone;
    }

    /**
     * <p> Retrieves the seManagerName field. </p>
     *
     * @return the seManagerName
     * @since 1.9
     */
    public String getSeManagerName() {
        return seManagerName;
    }

    /**
     * <p> Sets the value to seManagerName field. </p>
     *
     * @param seManagerName the seManagerName to set
     * @since 1.9
     */
    public void setSeManagerName(String seManagerName) {
        this.seManagerName = seManagerName;
    }

    /**
     * The toString method.
     *
     * @return the string of this entity
     */
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("{").append(super.toString());
        sb.append(", defaultProfile:").append(defaultProfile);
        sb.append(", firstName:").append(firstName);
        sb.append(", lastName:").append(lastName);
        sb.append(", jobTitle:").append(jobTitle);
        sb.append(", countryCode:").append(countryCode);
        sb.append(", officePhone:").append(officePhone);
        sb.append(", mobilePhone:").append(mobilePhone);
        sb.append(", fax:").append(fax);
        sb.append(", email:").append(email);
        sb.append(", approver:").append(approver);
        sb.append(", templatePermission:").append(templatePermission);
        sb.append(", seCsdName:").append(seCsdName);
        sb.append(", seCsdPhone:").append(seCsdPhone);
        sb.append(", seManagerName:").append(seManagerName);
        sb.append("}");
        return sb.toString();
    }
}

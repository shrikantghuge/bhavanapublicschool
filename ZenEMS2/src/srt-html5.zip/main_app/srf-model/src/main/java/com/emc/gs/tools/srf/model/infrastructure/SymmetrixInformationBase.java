/*
 * This code is copyright (c) 2014 EMC Corporation.
 */
package com.emc.gs.tools.srf.model.infrastructure;

import com.emc.gs.tools.srf.model.IdentifiableEntity;

/**
 * <p>This is SymmetrixInformationBase base class.</p>
 *
 * <p><strong>Thread safety</strong>: This class is mutable, it is not thread safety.</p>
 *
 * @author isv
 * @version 1.0
 */
public abstract class SymmetrixInformationBase extends IdentifiableEntity {

    /**
     * <p> The knowledgeTransferHours. </p>
     */
    private String knowledgeTransferHours;

    /**
     * <p> The vmaxArraysNumber. </p>
     */
    private Integer vmaxArraysNumber;

    /**
     * <p> The dmxArraysNumber. </p>
     */
    private Integer dmxArraysNumber;

    /**
     * <p> The vmaxArraysUpgradeNumber. </p>
     */
    private Integer vmaxArraysUpgradeNumber;

    /**
     * <p> The dmxArraysUpgradeNumber. </p>
     */
    private Integer dmxArraysUpgradeNumber;

    /**
     * <p> The srdfArraysNumber. </p>
     */
    private Integer srdfArraysNumber;

    /**
     * <p> The srdfAArraysNumber. </p>
     */
    private Integer srdfAArraysNumber;

    /**
     * <p> The virtualProvisioningArraysNumber. </p>
     */
    private Integer virtualProvisioningArraysNumber;

    /**
     * <p> The thinDevicesHostNumber. </p>
     */
    private Integer thinDevicesHostNumber;

    /**
     * <p> The lunToDmxHostNumber. </p>
     */
    private Integer lunToDmxHostNumber;

    /**
     * <p> The autoProvisioingToDmxHostNumber. </p>
     */
    private Integer autoProvisioingToDmxHostNumber;

    /**
     * <p> The advancedFastArraysNumber. </p>
     */
    private Integer advancedFastArraysNumber;

    /**
     * <p> The deinstallOpenSystemsVmaxNumber. </p>
     */
    private Integer deinstallOpenSystemsVmaxNumber;

    /**
     * <p> The vmaxArraysNum. </p>
     */
    private Integer vmaxArraysNum;

    /**
     * <p> The vmaxGroupsNum. </p>
     */
    private Integer vmaxGroupsNum;

    /**
     * <p> The vmaxCombinationsNum. </p>
     */
    private Integer vmaxCombinationsNum;

    /**
     * <p> The vmaxTiersNum. </p>
     */
    private Integer vmaxTiersNum;

    /**
     * <p> The vmaxPoliciesNum. </p>
     */
    private Integer vmaxPoliciesNum;

    /**
     * <p> The vmaxPerformanceWindowsNum. </p>
     */
    private Integer vmaxPerformanceWindowsNum;

    /**
     * <p> The vmaxDMWindowsNum. </p>
     */
    private Integer vmaxDMWindowsNum;

    /**
     * <p> The vmaxAdditionalHoursCreateDevTestsNum. </p>
     */
    private Integer vmaxAdditionalHoursCreateDevTestsNum;

    /**
     * <p> The vmaxAdditionalHoursExecuteDevTestsNum. </p>
     */
    private Integer vmaxAdditionalHoursExecuteDevTestsNum;

    /**
     * <p> The vpStorageGroupsNum. </p>
     */
    private Integer vpStorageGroupsNum;

    /**
     * <p> The vpDiskCombinationsNum. </p>
     */
    private Integer vpDiskCombinationsNum;

    /**
     * <p> The tdevNum. </p>
     */
    private Integer tdevNum;

    /**
     * <p> The tdatNum. </p>
     */
    private Integer tdatNum;

    /**
     * <p> The vpThinPoolsNum. </p>
     */
    private Integer vpThinPoolsNum;

    /**
     * <p> The fastVpPerformanceTimeWindowsNum. </p>
     */
    private Integer fastVpPerformanceTimeWindowsNum;

    /**
     * <p> The fastVpMoveTimeWindowsNum. </p>
     */
    private Integer fastVpMoveTimeWindowsNum;

    /**
     * <p> The fastVpTiersNum. </p>
     */
    private Integer fastVpTiersNum;

    /**
     * <p> The fastVpPoliciesNum. </p>
     */
    private Integer fastVpPoliciesNum;

    /**
     * <p> The engagementAddingFastVP. </p>
     */
    private Boolean engagementAddingFastVP;

    /**
     * <p>Constructs new <code>SymmetrixInformationBase</code> instance. This implementation does nothing.</p>
     */
    protected SymmetrixInformationBase() {
    }

    /**
     * <p> Retrieves the knowledgeTransferHours field. </p>
     *
     * @return the knowledgeTransferHours
     */
    public String getKnowledgeTransferHours() {
        return knowledgeTransferHours;
    }

    /**
     * <p> Sets the value to knowledgeTransferHours field. </p>
     *
     * @param knowledgeTransferHours the knowledgeTransferHours to set
     */
    public void setKnowledgeTransferHours(String knowledgeTransferHours) {
        this.knowledgeTransferHours = knowledgeTransferHours;
    }

    /**
     * <p> Retrieves the vmaxArraysNumber field. </p>
     *
     * @return the vmaxArraysNumber
     */
    public Integer getVmaxArraysNumber() {
        return vmaxArraysNumber;
    }

    /**
     * <p> Sets the value to vmaxArraysNumber field. </p>
     *
     * @param vmaxArraysNumber the vmaxArraysNumber to set
     */
    public void setVmaxArraysNumber(Integer vmaxArraysNumber) {
        this.vmaxArraysNumber = vmaxArraysNumber;
    }

    /**
     * <p> Retrieves the dmxArraysNumber field. </p>
     *
     * @return the dmxArraysNumber
     */
    public Integer getDmxArraysNumber() {
        return dmxArraysNumber;
    }

    /**
     * <p> Sets the value to dmxArraysNumber field. </p>
     *
     * @param dmxArraysNumber the dmxArraysNumber to set
     */
    public void setDmxArraysNumber(Integer dmxArraysNumber) {
        this.dmxArraysNumber = dmxArraysNumber;
    }

    /**
     * <p> Retrieves the vmaxArraysUpgradeNumber field. </p>
     *
     * @return the vmaxArraysUpgradeNumber
     */
    public Integer getVmaxArraysUpgradeNumber() {
        return vmaxArraysUpgradeNumber;
    }

    /**
     * <p> Sets the value to vmaxArraysUpgradeNumber field. </p>
     *
     * @param vmaxArraysUpgradeNumber the vmaxArraysUpgradeNumber to set
     */
    public void setVmaxArraysUpgradeNumber(Integer vmaxArraysUpgradeNumber) {
        this.vmaxArraysUpgradeNumber = vmaxArraysUpgradeNumber;
    }

    /**
     * <p> Retrieves the dmxArraysUpgradeNumber field. </p>
     *
     * @return the dmxArraysUpgradeNumber
     */
    public Integer getDmxArraysUpgradeNumber() {
        return dmxArraysUpgradeNumber;
    }

    /**
     * <p> Sets the value to dmxArraysUpgradeNumber field. </p>
     *
     * @param dmxArraysUpgradeNumber the dmxArraysUpgradeNumber to set
     */
    public void setDmxArraysUpgradeNumber(Integer dmxArraysUpgradeNumber) {
        this.dmxArraysUpgradeNumber = dmxArraysUpgradeNumber;
    }

    /**
     * <p> Retrieves the srdfArraysNumber field. </p>
     *
     * @return the srdfArraysNumber
     */
    public Integer getSrdfArraysNumber() {
        return srdfArraysNumber;
    }

    /**
     * <p> Sets the value to srdfArraysNumber field. </p>
     *
     * @param srdfArraysNumber the srdfArraysNumber to set
     */
    public void setSrdfArraysNumber(Integer srdfArraysNumber) {
        this.srdfArraysNumber = srdfArraysNumber;
    }

    /**
     * <p> Retrieves the srdfAArraysNumber field. </p>
     *
     * @return the srdfAArraysNumber
     */
    public Integer getSrdfAArraysNumber() {
        return srdfAArraysNumber;
    }

    /**
     * <p> Sets the value to srdfAArraysNumber field. </p>
     *
     * @param srdfAArraysNumber the srdfAArraysNumber to set
     */
    public void setSrdfAArraysNumber(Integer srdfAArraysNumber) {
        this.srdfAArraysNumber = srdfAArraysNumber;
    }

    /**
     * <p> Retrieves the virtualProvisioningArraysNumber field. </p>
     *
     * @return the virtualProvisioningArraysNumber
     */
    public Integer getVirtualProvisioningArraysNumber() {
        return virtualProvisioningArraysNumber;
    }

    /**
     * <p> Sets the value to virtualProvisioningArraysNumber field. </p>
     *
     * @param virtualProvisioningArraysNumber the virtualProvisioningArraysNumber to set
     */
    public void setVirtualProvisioningArraysNumber(Integer virtualProvisioningArraysNumber) {
        this.virtualProvisioningArraysNumber = virtualProvisioningArraysNumber;
    }

    /**
     * <p> Retrieves the thinDevicesHostNumber field. </p>
     *
     * @return the thinDevicesHostNumber
     */
    public Integer getThinDevicesHostNumber() {
        return thinDevicesHostNumber;
    }

    /**
     * <p> Sets the value to thinDevicesHostNumber field. </p>
     *
     * @param thinDevicesHostNumber the thinDevicesHostNumber to set
     */
    public void setThinDevicesHostNumber(Integer thinDevicesHostNumber) {
        this.thinDevicesHostNumber = thinDevicesHostNumber;
    }

    /**
     * <p> Retrieves the lunToDmxHostNumber field. </p>
     *
     * @return the lunToDmxHostNumber
     */
    public Integer getLunToDmxHostNumber() {
        return lunToDmxHostNumber;
    }

    /**
     * <p> Sets the value to lunToDmxHostNumber field. </p>
     *
     * @param lunToDmxHostNumber the lunToDmxHostNumber to set
     */
    public void setLunToDmxHostNumber(Integer lunToDmxHostNumber) {
        this.lunToDmxHostNumber = lunToDmxHostNumber;
    }

    /**
     * <p> Retrieves the autoProvisioingToDmxHostNumber field. </p>
     *
     * @return the autoProvisioingToDmxHostNumber
     */
    public Integer getAutoProvisioingToDmxHostNumber() {
        return autoProvisioingToDmxHostNumber;
    }

    /**
     * <p> Sets the value to autoProvisioingToDmxHostNumber field. </p>
     *
     * @param autoProvisioingToDmxHostNumber the autoProvisioingToDmxHostNumber to set
     */
    public void setAutoProvisioingToDmxHostNumber(Integer autoProvisioingToDmxHostNumber) {
        this.autoProvisioingToDmxHostNumber = autoProvisioingToDmxHostNumber;
    }

    /**
     * <p> Retrieves the advancedFastArraysNumber field. </p>
     *
     * @return the advancedFastArraysNumber
     */
    public Integer getAdvancedFastArraysNumber() {
        return advancedFastArraysNumber;
    }

    /**
     * <p> Sets the value to advancedFastArraysNumber field. </p>
     *
     * @param advancedFastArraysNumber the advancedFastArraysNumber to set
     */
    public void setAdvancedFastArraysNumber(Integer advancedFastArraysNumber) {
        this.advancedFastArraysNumber = advancedFastArraysNumber;
    }

    /**
     * <p> Retrieves the deinstallOpenSystemsVmaxNumber field. </p>
     *
     * @return the deinstallOpenSystemsVmaxNumber
     */
    public Integer getDeinstallOpenSystemsVmaxNumber() {
        return deinstallOpenSystemsVmaxNumber;
    }

    /**
     * <p> Sets the value to deinstallOpenSystemsVmaxNumber field. </p>
     *
     * @param deinstallOpenSystemsVmaxNumber the deinstallOpenSystemsVmaxNumber to set
     */
    public void setDeinstallOpenSystemsVmaxNumber(Integer deinstallOpenSystemsVmaxNumber) {
        this.deinstallOpenSystemsVmaxNumber = deinstallOpenSystemsVmaxNumber;
    }

    /**
     * <p> Retrieves the vmaxArraysNum field. </p>
     *
     * @return the vmaxArraysNum
     */
    public Integer getVmaxArraysNum() {
        return vmaxArraysNum;
    }

    /**
     * <p> Sets the value to vmaxArraysNum field. </p>
     *
     * @param vmaxArraysNum the vmaxArraysNum to set
     */
    public void setVmaxArraysNum(Integer vmaxArraysNum) {
        this.vmaxArraysNum = vmaxArraysNum;
    }

    /**
     * <p> Retrieves the vmaxGroupsNum field. </p>
     *
     * @return the vmaxGroupsNum
     */
    public Integer getVmaxGroupsNum() {
        return vmaxGroupsNum;
    }

    /**
     * <p> Sets the value to vmaxGroupsNum field. </p>
     *
     * @param vmaxGroupsNum the vmaxGroupsNum to set
     */
    public void setVmaxGroupsNum(Integer vmaxGroupsNum) {
        this.vmaxGroupsNum = vmaxGroupsNum;
    }

    /**
     * <p> Retrieves the vmaxCombinationsNum field. </p>
     *
     * @return the vmaxCombinationsNum
     */
    public Integer getVmaxCombinationsNum() {
        return vmaxCombinationsNum;
    }

    /**
     * <p> Sets the value to vmaxCombinationsNum field. </p>
     *
     * @param vmaxCombinationsNum the vmaxCombinationsNum to set
     */
    public void setVmaxCombinationsNum(Integer vmaxCombinationsNum) {
        this.vmaxCombinationsNum = vmaxCombinationsNum;
    }

    /**
     * <p> Retrieves the vmaxTiersNum field. </p>
     *
     * @return the vmaxTiersNum
     */
    public Integer getVmaxTiersNum() {
        return vmaxTiersNum;
    }

    /**
     * <p> Sets the value to vmaxTiersNum field. </p>
     *
     * @param vmaxTiersNum the vmaxTiersNum to set
     */
    public void setVmaxTiersNum(Integer vmaxTiersNum) {
        this.vmaxTiersNum = vmaxTiersNum;
    }

    /**
     * <p> Retrieves the vmaxPoliciesNum field. </p>
     *
     * @return the vmaxPoliciesNum
     */
    public Integer getVmaxPoliciesNum() {
        return vmaxPoliciesNum;
    }

    /**
     * <p> Sets the value to vmaxPoliciesNum field. </p>
     *
     * @param vmaxPoliciesNum the vmaxPoliciesNum to set
     */
    public void setVmaxPoliciesNum(Integer vmaxPoliciesNum) {
        this.vmaxPoliciesNum = vmaxPoliciesNum;
    }

    /**
     * <p> Retrieves the vmaxPerformanceWindowsNum field. </p>
     *
     * @return the vmaxPerformanceWindowsNum
     */
    public Integer getVmaxPerformanceWindowsNum() {
        return vmaxPerformanceWindowsNum;
    }

    /**
     * <p> Sets the value to vmaxPerformanceWindowsNum field. </p>
     *
     * @param vmaxPerformanceWindowsNum the vmaxPerformanceWindowsNum to set
     */
    public void setVmaxPerformanceWindowsNum(Integer vmaxPerformanceWindowsNum) {
        this.vmaxPerformanceWindowsNum = vmaxPerformanceWindowsNum;
    }

    /**
     * <p> Retrieves the vmaxDMWindowsNum field. </p>
     *
     * @return the vmaxDMWindowsNum
     */
    public Integer getVmaxDMWindowsNum() {
        return vmaxDMWindowsNum;
    }

    /**
     * <p> Sets the value to vmaxDMWindowsNum field. </p>
     *
     * @param vmaxDMWindowsNum the vmaxDMWindowsNum to set
     */
    public void setVmaxDMWindowsNum(Integer vmaxDMWindowsNum) {
        this.vmaxDMWindowsNum = vmaxDMWindowsNum;
    }

    /**
     * <p> Retrieves the vmaxAdditionalHoursCreateDevTestsNum field. </p>
     *
     * @return the vmaxAdditionalHoursCreateDevTestsNum
     */
    public Integer getVmaxAdditionalHoursCreateDevTestsNum() {
        return vmaxAdditionalHoursCreateDevTestsNum;
    }

    /**
     * <p> Sets the value to vmaxAdditionalHoursCreateDevTestsNum field. </p>
     *
     * @param vmaxAdditionalHoursCreateDevTestsNum the vmaxAdditionalHoursCreateDevTestsNum to set
     */
    public void setVmaxAdditionalHoursCreateDevTestsNum(Integer vmaxAdditionalHoursCreateDevTestsNum) {
        this.vmaxAdditionalHoursCreateDevTestsNum = vmaxAdditionalHoursCreateDevTestsNum;
    }

    /**
     * <p> Retrieves the vmaxAdditionalHoursExecuteDevTestsNum field. </p>
     *
     * @return the vmaxAdditionalHoursExecuteDevTestsNum
     */
    public Integer getVmaxAdditionalHoursExecuteDevTestsNum() {
        return vmaxAdditionalHoursExecuteDevTestsNum;
    }

    /**
     * <p> Sets the value to vmaxAdditionalHoursExecuteDevTestsNum field. </p>
     *
     * @param vmaxAdditionalHoursExecuteDevTestsNum the vmaxAdditionalHoursExecuteDevTestsNum to set
     */
    public void setVmaxAdditionalHoursExecuteDevTestsNum(Integer vmaxAdditionalHoursExecuteDevTestsNum) {
        this.vmaxAdditionalHoursExecuteDevTestsNum = vmaxAdditionalHoursExecuteDevTestsNum;
    }

    /**
     * <p> Retrieves the vpStorageGroupsNum field. </p>
     *
     * @return the vpStorageGroupsNum
     */
    public Integer getVpStorageGroupsNum() {
        return vpStorageGroupsNum;
    }

    /**
     * <p> Sets the value to vpStorageGroupsNum field. </p>
     *
     * @param vpStorageGroupsNum the vpStorageGroupsNum to set
     */
    public void setVpStorageGroupsNum(Integer vpStorageGroupsNum) {
        this.vpStorageGroupsNum = vpStorageGroupsNum;
    }

    /**
     * <p> Retrieves the vpDiskCombinationsNum field. </p>
     *
     * @return the vpDiskCombinationsNum
     */
    public Integer getVpDiskCombinationsNum() {
        return vpDiskCombinationsNum;
    }

    /**
     * <p> Sets the value to vpDiskCombinationsNum field. </p>
     *
     * @param vpDiskCombinationsNum the vpDiskCombinationsNum to set
     */
    public void setVpDiskCombinationsNum(Integer vpDiskCombinationsNum) {
        this.vpDiskCombinationsNum = vpDiskCombinationsNum;
    }

    /**
     * <p> Retrieves the tdevNum field. </p>
     *
     * @return the tdevNum
     */
    public Integer getTdevNum() {
        return tdevNum;
    }

    /**
     * <p> Sets the value to tdevNum field. </p>
     *
     * @param tdevNum the tdevNum to set
     */
    public void setTdevNum(Integer tdevNum) {
        this.tdevNum = tdevNum;
    }

    /**
     * <p> Retrieves the tdatNum field. </p>
     *
     * @return the tdatNum
     */
    public Integer getTdatNum() {
        return tdatNum;
    }

    /**
     * <p> Sets the value to tdatNum field. </p>
     *
     * @param tdatNum the tdatNum to set
     */
    public void setTdatNum(Integer tdatNum) {
        this.tdatNum = tdatNum;
    }

    /**
     * <p> Retrieves the vpThinPoolsNum field. </p>
     *
     * @return the vpThinPoolsNum
     */
    public Integer getVpThinPoolsNum() {
        return vpThinPoolsNum;
    }

    /**
     * <p> Sets the value to vpThinPoolsNum field. </p>
     *
     * @param vpThinPoolsNum the vpThinPoolsNum to set
     */
    public void setVpThinPoolsNum(Integer vpThinPoolsNum) {
        this.vpThinPoolsNum = vpThinPoolsNum;
    }

    /**
     * <p> Retrieves the fastVpPerformanceTimeWindowsNum field. </p>
     *
     * @return the fastVpPerformanceTimeWindowsNum
     */
    public Integer getFastVpPerformanceTimeWindowsNum() {
        return fastVpPerformanceTimeWindowsNum;
    }

    /**
     * <p> Sets the value to fastVpPerformanceTimeWindowsNum field. </p>
     *
     * @param fastVpPerformanceTimeWindowsNum the fastVpPerformanceTimeWindowsNum to set
     */
    public void setFastVpPerformanceTimeWindowsNum(Integer fastVpPerformanceTimeWindowsNum) {
        this.fastVpPerformanceTimeWindowsNum = fastVpPerformanceTimeWindowsNum;
    }

    /**
     * <p> Retrieves the fastVpMoveTimeWindowsNum field. </p>
     *
     * @return the fastVpMoveTimeWindowsNum
     */
    public Integer getFastVpMoveTimeWindowsNum() {
        return fastVpMoveTimeWindowsNum;
    }

    /**
     * <p> Sets the value to fastVpMoveTimeWindowsNum field. </p>
     *
     * @param fastVpMoveTimeWindowsNum the fastVpMoveTimeWindowsNum to set
     */
    public void setFastVpMoveTimeWindowsNum(Integer fastVpMoveTimeWindowsNum) {
        this.fastVpMoveTimeWindowsNum = fastVpMoveTimeWindowsNum;
    }

    /**
     * <p> Retrieves the fastVpTiersNum field. </p>
     *
     * @return the fastVpTiersNum
     */
    public Integer getFastVpTiersNum() {
        return fastVpTiersNum;
    }

    /**
     * <p> Sets the value to fastVpTiersNum field. </p>
     *
     * @param fastVpTiersNum the fastVpTiersNum to set
     */
    public void setFastVpTiersNum(Integer fastVpTiersNum) {
        this.fastVpTiersNum = fastVpTiersNum;
    }

    /**
     * <p> Retrieves the fastVpPoliciesNum field. </p>
     *
     * @return the fastVpPoliciesNum
     */
    public Integer getFastVpPoliciesNum() {
        return fastVpPoliciesNum;
    }

    /**
     * <p> Sets the value to fastVpPoliciesNum field. </p>
     *
     * @param fastVpPoliciesNum the fastVpPoliciesNum to set
     */
    public void setFastVpPoliciesNum(Integer fastVpPoliciesNum) {
        this.fastVpPoliciesNum = fastVpPoliciesNum;
    }

    /**
     * <p> Retrieves the engagementAddingFastVP field. </p>
     *
     * @return the engagementAddingFastVP
     */
    public Boolean getEngagementAddingFastVP() {
        return engagementAddingFastVP;
    }

    /**
     * <p> Sets the value to engagementAddingFastVP field. </p>
     *
     * @param engagementAddingFastVP the engagementAddingFastVP to set
     */
    public void setEngagementAddingFastVP(Boolean engagementAddingFastVP) {
        this.engagementAddingFastVP = engagementAddingFastVP;
    }

    /**
     * The toString method.
     *
     * @return the string for this entity
     */
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("{").append(super.toString());
        sb.append(", knowledgeTransferHours:").append(knowledgeTransferHours);
        sb.append(", vmaxArraysNumber:").append(vmaxArraysNumber);
        sb.append(", dmxArraysNumber:").append(dmxArraysNumber);
        sb.append(", vmaxArraysUpgradeNumber:").append(vmaxArraysUpgradeNumber);
        sb.append(", dmxArraysUpgradeNumber:").append(dmxArraysUpgradeNumber);
        sb.append(", srdfArraysNumber:").append(srdfArraysNumber);
        sb.append(", srdfAArraysNumber:").append(srdfAArraysNumber);
        sb.append(", virtualProvisioningArraysNumber:").append(virtualProvisioningArraysNumber);
        sb.append(", thinDevicesHostNumber:").append(thinDevicesHostNumber);
        sb.append(", lunToDmxHostNumber:").append(lunToDmxHostNumber);
        sb.append(", autoProvisioingToDmxHostNumber:").append(autoProvisioingToDmxHostNumber);
        sb.append(", advancedFastArraysNumber:").append(advancedFastArraysNumber);
        sb.append(", deinstallOpenSystemsVmaxNumber:").append(deinstallOpenSystemsVmaxNumber);
        sb.append(", vmaxArraysNum:").append(vmaxArraysNum);
        sb.append(", vmaxGroupsNum:").append(vmaxGroupsNum);
        sb.append(", vmaxCombinationsNum:").append(vmaxCombinationsNum);
        sb.append(", vmaxTiersNum:").append(vmaxTiersNum);
        sb.append(", vmaxPoliciesNum:").append(vmaxPoliciesNum);
        sb.append(", vmaxPerformanceWindowsNum:").append(vmaxPerformanceWindowsNum);
        sb.append(", vmaxDMWindowsNum:").append(vmaxDMWindowsNum);
        sb.append(", vmaxAdditionalHoursCreateDevTestsNum:").append(vmaxAdditionalHoursCreateDevTestsNum);
        sb.append(", vmaxAdditionalHoursExecuteDevTestsNum:").append(vmaxAdditionalHoursExecuteDevTestsNum);
        sb.append(", vpStorageGroupsNum:").append(vpStorageGroupsNum);
        sb.append(", vpDiskCombinationsNum:").append(vpDiskCombinationsNum);
        sb.append(", tdevNum:").append(tdevNum);
        sb.append(", tdatNum:").append(tdatNum);
        sb.append(", vpThinPoolsNum:").append(vpThinPoolsNum);
        sb.append(", fastVpPerformanceTimeWindowsNum:").append(fastVpPerformanceTimeWindowsNum);
        sb.append(", fastVpMoveTimeWindowsNum:").append(fastVpMoveTimeWindowsNum);
        sb.append(", fastVpTiersNum:").append(fastVpTiersNum);
        sb.append(", fastVpPoliciesNum:").append(fastVpPoliciesNum);
        sb.append(", engagementAddingFastVP:").append(engagementAddingFastVP);
        return sb.toString();
    }
}

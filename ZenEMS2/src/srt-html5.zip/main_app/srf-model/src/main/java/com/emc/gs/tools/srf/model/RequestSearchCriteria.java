/*
 * This code is copyright (c) 2013 - 2015 EMC Corporation.
 */
package com.emc.gs.tools.srf.model;

import java.util.List;

/**
 * <p>
 * This is RequestSearchRequest entity class.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safety.
 * </p>
 * 
 * <p>
 * <strong>Changes V1.1:</strong>
 * <strong>SRT Bug Fixes</strong>
 * <ul>
 * <li>Removed startDateSubmitted and endDateSubmitted fields.</li>
 * </ul>
 * </p>
 *
 * <p>
 * Changes in version 1.2 (SRT 1.1 FEB 2015 Updates - Template Folder Assembly):
 * <ul>
 * <li>Added {@link #lob}, {@link #theater}, and {@link #currency} properties.</li>
 * </ul>
 * <p>
 *
 * <p>
 * Changes in version 1.3 (SRT 1.1 Approval Process Assembly):
 * <ul>
 * <li>Replaced requestStatus field name with requestStatuses which is a list now.</li>
 * </ul>
 * <p>
 *
 * <p>
 * Version 1.4 Change notes:
 *   <ol>
 *     <li>Added {@link #targetTab} property.</li>
 *   </ol>
 * </p>
 *
 * @author faeton, stevenfrog, duxiaoyang, MonicaMuranyi
 * @version 1.4
 */
public class RequestSearchCriteria extends BaseSearchParams {

    /**
     * <p>A <code>String</code> providing the logical name for <code>Drafts</code> tab.</p>
     * 
     * @since 1.4
     */
    public static final String DRAFTS_TAB = "drafts";

    /**
     * <p>A <code>String</code> providing the logical name for <code>Submitted</code> tab.</p>
     *
     * @since 1.4
     */
    public static final String SUBMITTED_TAB = "submitted";

    /**
     * <p>
     * The requestId.
     * </p>
     */
    private String requestId;

    /**
     * <p>
     * The requestType.
     * </p>
     */
    private String requestType;

    /**
     * <p>
     * The projectName.
     * </p>
     */
    private String projectName;

    /**
     * <p>
     * The projectType.
     * </p>
     */
    private String projectType;

    /**
     * <p>
     * The customerName.
     * </p>
     */
    private String customerName;

    /**
     * <p>
     * The requestStatus.
     * </p>
     * @since 1.3
     */
    private List<RequestStatus> requestStatuses;
    
    /**
     * <p>
     * The LOB.
     * </p>
     */
    private String lob;

    /**
     * <p>
     * The theater.
     * </p>
     */
    private String theater;

    /**
     * <p>
     * The currency.
     * </p>
     */
    private String currency;

    /**
     * <p>A <code>String</code> providing the value for targetTab property.</p>
     * 
     * @since 1.4
     */
    private String targetTab;

    /**
     * <p>
     * The default constructor.
     * </p>
     */
    public RequestSearchCriteria() {
        // Empty
    }

    /**
     * <p>
     * Retrieves the requestId field.
     * </p>
     *
     * @return the requestId
     */
    public String getRequestId() {
        return requestId;
    }

    /**
     * <p>
     * Sets the value to requestId field.
     * </p>
     *
     * @param requestId
     *            the requestId to set
     */
    public void setRequestId(String requestId) {
        this.requestId = requestId;
    }

    /**
     * <p>
     * Retrieves the requestType field.
     * </p>
     *
     * @return the requestType
     */
    public String getRequestType() {
        return requestType;
    }

    /**
     * <p>
     * Sets the value to requestType field.
     * </p>
     *
     * @param requestType
     *            the requestType to set
     */
    public void setRequestType(String requestType) {
        this.requestType = requestType;
    }

    /**
     * <p>
     * Retrieves the projectName field.
     * </p>
     *
     * @return the projectName
     */
    public String getProjectName() {
        return projectName;
    }

    /**
     * <p>
     * Sets the value to projectName field.
     * </p>
     *
     * @param projectName
     *            the projectName to set
     */
    public void setProjectName(String projectName) {
        this.projectName = projectName;
    }

    /**
     * <p>
     * Retrieves the projectType field.
     * </p>
     *
     * @return the projectType
     */
    public String getProjectType() {
        return projectType;
    }

    /**
     * <p>
     * Sets the value to projectType field.
     * </p>
     *
     * @param projectType
     *            the projectType to set
     */
    public void setProjectType(String projectType) {
        this.projectType = projectType;
    }

    /**
     * <p>
     * Retrieves the customerName field.
     * </p>
     *
     * @return the customerName
     */
    public String getCustomerName() {
        return customerName;
    }

    /**
     * <p>
     * Sets the value to customerName field.
     * </p>
     *
     * @param customerName
     *            the customerName to set
     */
    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    /**
     * <p>
     * Retrieves the requestStatuses field.
     * </p>
     *
     * @return the requestStatuses
     * @since 1.3
     */
    public List<RequestStatus> getRequestStatuses() {
        return requestStatuses;
    }

    /**
     * <p>
     * Sets the value to requestStatuses field.
     * </p>
     *
     * @param requestStatuses
     *            the requestStatuses to set
     * @since 1.3
     */
    public void setRequestStatuses(List<RequestStatus> requestStatuses) {
        this.requestStatuses = requestStatuses;
    }
    
    /**
     * <p>
     * Retrieves the lob field.
     * </p>
     *
     * @return the lob
     */
    public String getLob() {
        return lob;
    }

    /**
     * <p>
     * Sets the value to lob field.
     * </p>
     *
     * @param lob
     *            the lob to set
     */
    public void setLob(String lob) {
        this.lob = lob;
    }

    /**
     * <p>
     * Retrieves the theater field.
     * </p>
     *
     * @return the theater
     */
    public String getTheater() {
        return theater;
    }

    /**
     * <p>
     * Sets the value to theater field.
     * </p>
     *
     * @param theater
     *            the theater to set
     */
    public void setTheater(String theater) {
        this.theater = theater;
    }

    /**
     * <p>
     * Retrieves the currency field.
     * </p>
     *
     * @return the currency
     */
    public String getCurrency() {
        return currency;
    }

    /**
     * <p>
     * Sets the value to currency field.
     * </p>
     *
     * @param currency
     *            the currency to set
     */
    public void setCurrency(String currency) {
        this.currency = currency;
    }

    /**
     * <p>Gets the targetTab property.</p>
     *
     * @return a <code>String</code> providing the value for targetTab property.
     * @since 1.4
     */
    public String getTargetTab() {
        return this.targetTab;
    }

    /**
     * <p>Sets the targetTab property.</p>
     *
     * @param targetTab a <code>String</code> providing the value for targetTab property.
     * @since 1.4
     */
    public void setTargetTab(String targetTab) {
        this.targetTab = targetTab;
    }

    /**
     * The toString method.
     *
     * @return the string for this entity
     */
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("{").append(super.toString());
        sb.append(", requestId:").append(requestId);
        sb.append(", requestType:").append(requestType);
        sb.append(", projectName:").append(projectName);
        sb.append(", projectType:").append(projectType);
        sb.append(", customerName:").append(customerName);
        sb.append(", requestStatuses:").append(requestStatuses);
        sb.append(", lob:").append(lob);
        sb.append(", theater:").append(theater);
        sb.append(", targetTab:").append(targetTab);
        sb.append(", currency:").append(currency).append("}");
        return sb.toString();
    }
}

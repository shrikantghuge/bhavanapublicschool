/*
 * This code is copyright (c) 2013 - 2014 EMC Corporation.
 */
package com.emc.gs.tools.srf.model;

/**
 * <p>
 * This is OtherRequestOptions entity class.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safety.
 * </p>
 * <p>
 * <strong>Changes V1.1:</strong>
 * <strong>SRT Phase 3-4 - ASD and Healthcheck Tabs Assembly</strong>
 * <ul>
 * <li>Add healthChecks field.</li>
 * </ul>
 * </p>
 *
 * <p>
 * Version 1.2 Change notes:
 *   <ol>
 *     <li>Added {@link #notListed} property.</li>
 *   </ol>
 * </p>
 * 
 * @author faeton, stevenfrog, TCSASSEMBLER
 * @version 1.2
 */
public class OtherRequestOptions extends IdentifiableEntity {
    /**
     * <p>
     * The residency.
     * </p>
     */
    private boolean residency;

    /**
     * <p>
     * The iSeries.
     * </p>
     */
    private boolean iSeries;

    /**
     * <p>
     * The diskRetention.
     * </p>
     */
    private boolean diskRetention;

    /**
     * <p>
     * The moveRequest.
     * </p>
     */
    private boolean moveRequest;

    /**
     * <p>
     * The healthChecks.
     * </p>
     * @since SRT Phase 3-4 - ASD and Healthcheck Tabs Assembly
     */
    private boolean healthChecks;

    /**
     * <p>A <code>boolean</code> providing the value for notListed property.</p>
     * 
     * @since 1.2
     */
    private boolean notListed;

    /**
     * <p>
     * The default constructor.
     * </p>
     */
    public OtherRequestOptions() {
        // Empty
    }

    /**
     * <p>
     * Retrieves the residency field.
     * </p>
     * 
     * @return the residency
     */
    public boolean isResidency() {
        return residency;
    }

    /**
     * <p>
     * Sets the value to residency field.
     * </p>
     * 
     * @param residency
     *            the residency to set
     */
    public void setResidency(boolean residency) {
        this.residency = residency;
    }

    /**
     * <p>
     * Retrieves the iSeries field.
     * </p>
     * 
     * @return the iSeries
     */
    public boolean isiSeries() {
        return iSeries;
    }

    /**
     * <p>
     * Sets the value to iSeries field.
     * </p>
     * 
     * @param iSeries
     *            the iSeries to set
     */
    public void setiSeries(boolean iSeries) {
        this.iSeries = iSeries;
    }

    /**
     * <p>
     * Retrieves the diskRetention field.
     * </p>
     * 
     * @return the diskRetention
     */
    public boolean isDiskRetention() {
        return diskRetention;
    }

    /**
     * <p>
     * Sets the value to diskRetention field.
     * </p>
     * 
     * @param diskRetention
     *            the diskRetention to set
     */
    public void setDiskRetention(boolean diskRetention) {
        this.diskRetention = diskRetention;
    }

    /**
     * <p>
     * Retrieves the moveRequest field.
     * </p>
     * 
     * @return the moveRequest
     */
    public boolean isMoveRequest() {
        return moveRequest;
    }

    /**
     * <p>
     * Sets the value to moveRequest field.
     * </p>
     * 
     * @param moveRequest
     *            the moveRequest to set
     */
    public void setMoveRequest(boolean moveRequest) {
        this.moveRequest = moveRequest;
    }

    /**
     * Getter method for property <tt>healthChecks</tt>.
     * 
     * @return property value of healthChecks
     * @since SRT Phase 3-4 - ASD and Healthcheck Tabs Assembly
     */
    public boolean isHealthChecks() {
        return healthChecks;
    }

    /**
     * Setter method for property <tt>healthChecks</tt>.
     * 
     * @param healthChecks
     *            value to be assigned to property healthChecks
     * @since SRT Phase 3-4 - ASD and Healthcheck Tabs Assembly
     */
    public void setHealthChecks(boolean healthChecks) {
        this.healthChecks = healthChecks;
    }

    /**
     * <p>Gets the notListed property.</p>
     *
     * @return a <code>boolean</code> providing the value for notListed property.
     * @since 1.2
     */
    public boolean getNotListed() {
        return this.notListed;
    }

    /**
     * <p>Sets the notListed property.</p>
     *
     * @param notListed a <code>boolean</code> providing the value for notListed property.
     * @since 1.2
     */
    public void setNotListed(boolean notListed) {
        this.notListed = notListed;
    }

    /**
     * The toString method.
     * 
     * @return the string for this entity
     */
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("{").append(super.toString());
        sb.append(", residency:").append(residency);
        sb.append(", iSeries:").append(iSeries);
        sb.append(", diskRetention:").append(diskRetention);
        sb.append(", healthChecks:").append(healthChecks);
        sb.append(", notListed:").append(notListed);
        sb.append(", moveRequest:").append(moveRequest).append("}");
        return sb.toString();
    }
}

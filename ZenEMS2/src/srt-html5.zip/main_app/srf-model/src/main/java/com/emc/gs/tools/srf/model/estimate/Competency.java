/*
 * This code is copyright (c) 2014 EMC Corporation.
 */
package com.emc.gs.tools.srf.model.estimate;

import com.emc.gs.tools.srf.model.LookupCodeEntity;

/**
 * <p>
 * This is Competency entity class.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safety.
 * </p>
 *
 * <p>
 * Version 1.1 Change notes:
 *   <ol>
 *     <li>The class implements <code>Comparable</code> interface.</li>
 *   </ol>
 * </p>
 * 
 * @author TCSASSEMBLER, isv
 * @version 1.1
 * @since SRT Phase 4 - ET Assembly 1
 */
public class Competency extends LookupCodeEntity implements Comparable<Competency> {

    /**
     * The LOB id this competency belongs to.
     */
    private long lobId;

    /**
     * Empty constructor.
     */
    public Competency() {
    }

    /**
     * Getter method for property <tt>lobId</tt>.
     * 
     * @return property value of lobId
     */
    public long getLobId() {
        return lobId;
    }

    /**
     * Setter method for property <tt>lobId</tt>.
     * 
     * @param lobId
     *            value to be assigned to property lobId
     */
    public void setLobId(long lobId) {
        this.lobId = lobId;
    }

    /**
     * <p>Compares this competency to specified one based on the name.</p>
     *
     * @param o a <code>Competency</code> to compare this competency to.
     * @return an <code>int</code> representing the result of comparison.
     */
    @Override
    public int compareTo(Competency o) {
        if (o == null) {
            return 1;
        } else {
            return getName().compareTo(o.getName());
        }
    }
}

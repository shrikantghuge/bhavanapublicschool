/*
 * This code is copyright (c) 2014 EMC Corporation.
 */
package com.emc.gs.tools.srf.model.estimate;

import com.emc.gs.tools.srf.model.LookupCodeEntity;

/**
 * <p>This is ResourceType entity class.</p>
 *
 * <p><strong>Thread safety</strong>: This class is mutable, it is not thread safety.</p>
 *
 * @author isv
 * @version 1.0
 */
public class ResourceType extends LookupCodeEntity {

    /**
     * <p>Constructs new <code>ResourceType</code> instance. This implementation does nothing.</p>
     */
    public ResourceType() {
    }

}

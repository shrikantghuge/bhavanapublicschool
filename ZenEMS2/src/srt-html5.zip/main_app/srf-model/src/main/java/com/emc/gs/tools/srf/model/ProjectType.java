/*
 * This code is copyright (c) 2013 - 2014 EMC Corporation.
 */
package com.emc.gs.tools.srf.model;

/**
 * <p>
 * This is ProjectType entity class.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safety.
 * </p>
 * 
 * <p>
 * <strong>Changes V1.1:</strong>
 * <strong>SRT Phase 4 - ET Assembly 1</strong>
 * <ul>
 * <li>Changed to extend from LookupCodeEntity.</li>
 * </ul>
 * </p>
 *
 * @author faeton, stevenfrog
 * @version 1.1
 */
public class ProjectType extends LookupCodeEntity {
    /**
     * <p>
     * The default constructor.
     * </p>
     */
    public ProjectType() {
        // Empty
    }
}

/*
 * This code is copyright (c) 2014 EMC Corporation.
 */
package com.emc.gs.tools.srf.model.estimate;

import com.emc.gs.tools.srf.model.LookupEntity;

import java.util.List;

/**
 * <p>This is DiscountFloorGroup entity class.</p>
 *
 * <p><strong>Thread safety</strong>: This class is mutable, it is not thread safety.</p>
 *
 * @author isv
 */
public class DiscountFloorGroup extends LookupEntity {

    /**
     * <p>A <code>List</code> providing the value for floors property.</p>
     */
    private List<DiscountFloor> floors;

    /**
     * <p>Constructs new <code>DiscountFloorGroup</code> instance. This implementation does nothing.</p>
     */
    public DiscountFloorGroup() {
    }

    /**
     * <p>Gets the floors property.</p>
     *
     * @return a <code>List</code> providing the value for floors property.
     */
    public List<DiscountFloor> getFloors() {
        return this.floors;
    }

    /**
     * <p>Sets the floors property.</p>
     *
     * @param floors a <code>List</code> providing the value for floors property.
     */
    public void setFloors(List<DiscountFloor> floors) {
        this.floors = floors;
    }

}

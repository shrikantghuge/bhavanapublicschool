/*
 * This code is copyright (c) 2014 EMC Corporation
 */
package com.emc.gs.tools.srf.model.dpad;

import com.emc.gs.tools.srf.model.IdentifiableEntity;

import java.math.BigDecimal;

/**
 * <p>This is MozyCustom entity class.</p>
 *
 * <p><strong>Thread safety</strong>: This class is mutable, it is not thread safety.</p>
 *
 * @author TCSASSEMBLER
 * @version 1.0
 * @since SRT Phase 3 Pilot - Mozy and Xtrem and Vipr Tabs Assembly
 */
public class MozyCustom extends IdentifiableEntity {

    /**
     * <p>A <code>boolean</code> providing the value for Account Setup and Structure Configuration flag.</p>
     */
    private boolean accountSetupAndStructureConfiguration;

    /**
     * <p>A <code>boolean</code> providing the value for Solutions Assurance flag.</p>
     */
    private boolean solutionsAssurance;

    /**
     * <p>A <code>boolean</code> providing the value for Branding flag.</p>
     */
    private boolean branding;

    /**
     * <p>A <code>boolean</code> providing the value for Federated ID Configuration flag.</p>
     */
    private boolean federatedIDConfiguration;

    /**
     * <p>A <code>boolean</code> providing the value for Develop Beta Plan and Assist with Rollout flag.</p>
     */
    private boolean developBetaPlanAndAssistWithRollout;

    /**
     * <p>A <code>boolean</code> providing the value for Administration Training flag.</p>
     */
    private boolean administrationTraining;

    /**
     * <p>A <code>boolean</code> providing the value for API workshop flag.</p>
     */
    private boolean apiWorkshop;

    /**
     * <p>A <code>boolean</code> providing the value for L1 Support Training flag.</p>
     */
    private boolean l1SupportTraining;

    /**
     * <p>A <code>BigDecimal</code> providing the value for Hours for API Workshop Planning property.</p>
     */
    private BigDecimal hoursForAPIWorkshopPlanning;

    /**
     * <p>A <code>BigDecimal</code> providing the value for Hours to Assist With Pilot Rollout property.</p>
     */
    private BigDecimal hoursToAssistWithPilotRollout;

    /**
     * <p>A <code>BigDecimal</code> providing the value for Hours for Mozy Administration Training property.</p>
     */
    private BigDecimal hoursForAdministrationTraining;

    /**
     * <p>A <code>BigDecimal</code> providing the value for Hours for Client Branding property.</p>
     */
    private BigDecimal hoursForClientBranding;

    /**
     * <p>A <code>BigDecimal</code> providing the value for Hours for Administration Console Branding property.</p>
     */
    private BigDecimal hoursForAdminConsoleBranding;

    /**
     * <p>A <code>BigDecimal</code> providing the value for Hours for Web Acces Branding property.</p>
     */
    private BigDecimal hoursForWebAccessBranding;

    /**
     * <p>A <code>BigDecimal</code> providing the value for Hours for Mozy API Workshop property.</p>
     */
    private BigDecimal hoursForAPIWorkshop;

    /**
     * <p>A <code>BigDecimal</code> providing the value for L1 Support Training Hours property.</p>
     */
    private BigDecimal hoursForL1SupportTraining;

    /**
     * <p>Constructs new <code>MozyCustom</code> instance. This implementation does nothing.</p>
     */
    public MozyCustom() {
    }

    /**
     * <p>Gets the value for L1 Support Training Hours property.</p>
     *
     * @return a <code>BigDecimal</code> providing the value for L1 Support Training Hours property.
     */
    public BigDecimal getHoursForL1SupportTraining() {
        return this.hoursForL1SupportTraining;
    }

    /**
     * <p>Sets the value for L1 Support Training Hours property.</p>
     *
     * @param hoursForL1SupportTraining a <code>BigDecimal</code> providing the value for L1 Support Training Hours
     * property.
     */
    public void setHoursForL1SupportTraining(BigDecimal hoursForL1SupportTraining) {
        this.hoursForL1SupportTraining = hoursForL1SupportTraining;
    }

    /**
     * <p>Gets the value for Hours for Mozy API Workshop property.</p>
     *
     * @return a <code>BigDecimal</code> providing the value for Hours for Mozy API Workshop property.
     */
    public BigDecimal getHoursForAPIWorkshop() {
        return this.hoursForAPIWorkshop;
    }

    /**
     * <p>Sets the value for Hours for Mozy API Workshop property.</p>
     *
     * @param hoursForAPIWorkshop a <code>BigDecimal</code> providing the value for Hours for Mozy API Workshop
     * property.
     */
    public void setHoursForAPIWorkshop(BigDecimal hoursForAPIWorkshop) {
        this.hoursForAPIWorkshop = hoursForAPIWorkshop;
    }

    /**
     * <p>Gets the value for Hours for Web Acces Branding property.</p>
     *
     * @return a <code>BigDecimal</code> providing the value for Hours for Web Acces Branding property.
     */
    public BigDecimal getHoursForWebAccessBranding() {
        return this.hoursForWebAccessBranding;
    }

    /**
     * <p>Sets the value for Hours for Web Acces Branding property.</p>
     *
     * @param hoursForWebAccessBranding a <code>BigDecimal</code> providing the value for Hours for Web Acces Branding
     * property.
     */
    public void setHoursForWebAccessBranding(BigDecimal hoursForWebAccessBranding) {
        this.hoursForWebAccessBranding = hoursForWebAccessBranding;
    }

    /**
     * <p>Gets the value for Hours for Administration Console Branding property.</p>
     *
     * @return a <code>BigDecimal</code> providing the value for Hours for Administration Console Branding property.
     */
    public BigDecimal getHoursForAdminConsoleBranding() {
        return this.hoursForAdminConsoleBranding;
    }

    /**
     * <p>Sets the value for Hours for Administration Console Branding property.</p>
     *
     * @param hoursForAdminConsoleBranding a <code>BigDecimal</code> providing the value for Hours for Administration
     * Console Branding property.
     */
    public void setHoursForAdminConsoleBranding(BigDecimal hoursForAdminConsoleBranding) {
        this.hoursForAdminConsoleBranding = hoursForAdminConsoleBranding;
    }

    /**
     * <p>Gets the value for Hours for Client Branding property.</p>
     *
     * @return a <code>BigDecimal</code> providing the value for Hours for Client Branding property.
     */
    public BigDecimal getHoursForClientBranding() {
        return this.hoursForClientBranding;
    }

    /**
     * <p>Sets the value for Hours for Client Branding property.</p>
     *
     * @param hoursForClientBranding a <code>BigDecimal</code> providing the value for Hours for Client Branding
     * property.
     */
    public void setHoursForClientBranding(BigDecimal hoursForClientBranding) {
        this.hoursForClientBranding = hoursForClientBranding;
    }

    /**
     * <p>Gets the value for Hours for Mozy Administration Training property.</p>
     *
     * @return a <code>BigDecimal</code> providing the value for Hours for Mozy Administration Training property.
     */
    public BigDecimal getHoursForAdministrationTraining() {
        return this.hoursForAdministrationTraining;
    }

    /**
     * <p>Sets the value for Hours for Mozy Administration Training property.</p>
     *
     * @param hoursForAdministrationTraining a <code>BigDecimal</code> providing the value for Hours for Mozy
     * Administration Training property.
     */
    public void setHoursForAdministrationTraining(BigDecimal hoursForAdministrationTraining) {
        this.hoursForAdministrationTraining = hoursForAdministrationTraining;
    }

    /**
     * <p>Gets the value for Hours to Assist With Pilot Rollout property.</p>
     *
     * @return a <code>BigDecimal</code> providing the value for Hours to Assist With Pilot Rollout property.
     */
    public BigDecimal getHoursToAssistWithPilotRollout() {
        return this.hoursToAssistWithPilotRollout;
    }

    /**
     * <p>Sets the value for Hours to Assist With Pilot Rollout property.</p>
     *
     * @param hoursToAssistWithPilotRollout a <code>BigDecimal</code> providing the value for Hours to Assist With Pilot
     * Rollout property.
     */
    public void setHoursToAssistWithPilotRollout(BigDecimal hoursToAssistWithPilotRollout) {
        this.hoursToAssistWithPilotRollout = hoursToAssistWithPilotRollout;
    }

    /**
     * <p>Gets the value for Hours for API Workshop Planning property.</p>
     *
     * @return a <code>BigDecimal</code> providing the value for Hours for API Workshop Planning property.
     */
    public BigDecimal getHoursForAPIWorkshopPlanning() {
        return this.hoursForAPIWorkshopPlanning;
    }

    /**
     * <p>Sets the value for Hours for API Workshop Planning property.</p>
     *
     * @param hoursForAPIWorkshopPlanning a <code>BigDecimal</code> providing the value for Hours for API Workshop
     * Planning property.
     */
    public void setHoursForAPIWorkshopPlanning(BigDecimal hoursForAPIWorkshopPlanning) {
        this.hoursForAPIWorkshopPlanning = hoursForAPIWorkshopPlanning;
    }

    /**
     * <p>Gets the value for L1 Support Training flag.</p>
     *
     * @return a <code>boolean</code> providing the value for L1 Support Training flag.
     */
    public boolean getL1SupportTraining() {
        return this.l1SupportTraining;
    }

    /**
     * <p>Sets the value for L1 Support Training flag.</p>
     *
     * @param l1SupportTraining a <code>boolean</code> providing the value for L1 Support Training flag.
     */
    public void setL1SupportTraining(boolean l1SupportTraining) {
        this.l1SupportTraining = l1SupportTraining;
    }

    /**
     * <p>Gets the value for API workshop flag.</p>
     *
     * @return a <code>boolean</code> providing the value for API workshop flag.
     */
    public boolean getApiWorkshop() {
        return this.apiWorkshop;
    }

    /**
     * <p>Sets the value for API workshop flag.</p>
     *
     * @param apiWorkshop a <code>boolean</code> providing the value for API workshop flag.
     */
    public void setApiWorkshop(boolean apiWorkshop) {
        this.apiWorkshop = apiWorkshop;
    }

    /**
     * <p>Gets the value for Administration Training flag.</p>
     *
     * @return a <code>boolean</code> providing the value for Administration Training flag.
     */
    public boolean getAdministrationTraining() {
        return this.administrationTraining;
    }

    /**
     * <p>Sets the value for Administration Training flag.</p>
     *
     * @param administrationTraining a <code>boolean</code> providing the value for Administration Training flag.
     */
    public void setAdministrationTraining(boolean administrationTraining) {

        this.administrationTraining = administrationTraining;
    }

    /**
     * <p>Gets the value for Develop Beta Plan and Assist with Rollout flag.</p>
     *
     * @return a <code>boolean</code> providing the value for Develop Beta Plan and Assist with Rollout flag.
     */
    public boolean getDevelopBetaPlanAndAssistWithRollout() {
        return this.developBetaPlanAndAssistWithRollout;
    }

    /**
     * <p>Sets the value for Develop Beta Plan and Assist with Rollout flag.</p>
     *
     * @param developBetaPlanAndAssistWithRollout a <code>boolean</code> providing the value for Develop Beta Plan and
     * Assist with Rollout flag.
     */
    public void setDevelopBetaPlanAndAssistWithRollout(boolean developBetaPlanAndAssistWithRollout) {
        this.developBetaPlanAndAssistWithRollout = developBetaPlanAndAssistWithRollout;
    }

    /**
     * <p>Gets the value for Federated ID Configuration flag.</p>
     *
     * @return a <code>boolean</code> providing the value for Federated ID Configuration flag.
     */
    public boolean getFederatedIDConfiguration() {
        return this.federatedIDConfiguration;
    }

    /**
     * <p>Sets the value for Federated ID Configuration flag.</p>
     *
     * @param federatedIDConfiguration a <code>boolean</code> providing the value for Federated ID Configuration flag.
     */
    public void setFederatedIDConfiguration(boolean federatedIDConfiguration) {
        this.federatedIDConfiguration = federatedIDConfiguration;
    }

    /**
     * <p>Gets the value for Branding flag.</p>
     *
     * @return a <code>boolean</code> providing the value for Branding flag.
     */
    public boolean getBranding() {
        return this.branding;
    }

    /**
     * <p>Sets the value for Branding flag.</p>
     *
     * @param branding a <code>boolean</code> providing the value for Branding flag.
     */
    public void setBranding(boolean branding) {
        this.branding = branding;
    }

    /**
     * <p>Gets the value for Solutions Assurance flag.</p>
     *
     * @return a <code>boolean</code> providing the value for Solutions Assurance flag.
     */
    public boolean getSolutionsAssurance() {
        return this.solutionsAssurance;
    }

    /**
     * <p>Sets the value for Solutions Assurance flag.</p>
     *
     * @param solutionsAssurance a <code>boolean</code> providing the value for Solutions Assurance flag.
     */
    public void setSolutionsAssurance(boolean solutionsAssurance) {
        this.solutionsAssurance = solutionsAssurance;
    }

    /**
     * <p>Gets the value for Account Setup and Structure Configuration flag.</p>
     *
     * @return a <code>boolean</code> providing the value for Account Setup and Structure Configuration flag.
     */
    public boolean getAccountSetupAndStructureConfiguration() {
        return this.accountSetupAndStructureConfiguration;
    }

    /**
     * <p>Sets the value for Account Setup and Structure Configuration flag.</p>
     *
     * @param accountSetupAndStructureConfiguration a <code>boolean</code> providing the value for Account Setup and
     * Structure Configuration flag.
     */
    public void setAccountSetupAndStructureConfiguration(boolean accountSetupAndStructureConfiguration) {
        this.accountSetupAndStructureConfiguration = accountSetupAndStructureConfiguration;
    }

}

/*
 * This code is copyright (c) 2014 EMC Corporation
 */
package com.emc.gs.tools.srf.model.dpad;

import com.emc.gs.tools.srf.model.IdentifiableEntity;

/**
 * <p>
 * This is NetworkerMediaDevices entity class.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safety.
 * </p>
 * 
 * @author TCSASSEMBLER
 * @version 1.0
 * @since SRT Phase 3-5 - BRS Tabs Part 3 Assembly
 */
public class NetworkerMediaDevices extends IdentifiableEntity {

    /**
     * Represents whether "Auto Changer" device is selected.
     */
    private boolean autoChanger;

    /**
     * Represents whether "DD Boost" device is selected.
     */
    private boolean ddBoost;

    /**
     * Represents whether "Tape Device" device is selected.
     */
    private boolean tapeDevice;

    /**
     * Represents whether "ATMOS" device is selected.
     */
    private boolean atmos;

    /**
     * Represents whether "Advanced File Type Device" device is selected.
     */
    private boolean advancedFileTypeDevice;

    /**
     * # of Networker Auto Changers.
     */
    private Integer autoChangersNum;

    /**
     * # of Networker Tape Devices.
     */
    private Integer tapeDevicesNum;

    /**
     * # of Networker Advanced File Type Devices.
     */
    private Integer advancedFileTypeDevicesNum;

    /**
     * # of Networker DD Boost Devices.
     */
    private Integer ddBoostDevicesNum;

    /**
     * # of Networker ATMOS Devices.
     */
    private Integer atmosDevicesNum;

    /**
     * <p>
     * The default constructor.
     * </p>
     */
    public NetworkerMediaDevices() {
    }

    /**
     * Getter method for property <tt>autoChanger</tt>.
     * 
     * @return property value of autoChanger
     */
    public boolean isAutoChanger() {
        return autoChanger;
    }

    /**
     * Setter method for property <tt>autoChanger</tt>.
     * 
     * @param autoChanger
     *            value to be assigned to property autoChanger
     */
    public void setAutoChanger(boolean autoChanger) {
        this.autoChanger = autoChanger;
    }

    /**
     * Getter method for property <tt>ddBoost</tt>.
     * 
     * @return property value of ddBoost
     */
    public boolean isDdBoost() {
        return ddBoost;
    }

    /**
     * Setter method for property <tt>ddBoost</tt>.
     * 
     * @param ddBoost
     *            value to be assigned to property ddBoost
     */
    public void setDdBoost(boolean ddBoost) {
        this.ddBoost = ddBoost;
    }

    /**
     * Getter method for property <tt>tapeDevice</tt>.
     * 
     * @return property value of tapeDevice
     */
    public boolean isTapeDevice() {
        return tapeDevice;
    }

    /**
     * Setter method for property <tt>tapeDevice</tt>.
     * 
     * @param tapeDevice
     *            value to be assigned to property tapeDevice
     */
    public void setTapeDevice(boolean tapeDevice) {
        this.tapeDevice = tapeDevice;
    }

    /**
     * Getter method for property <tt>atmos</tt>.
     * 
     * @return property value of atmos
     */
    public boolean isAtmos() {
        return atmos;
    }

    /**
     * Setter method for property <tt>atmos</tt>.
     * 
     * @param atmos
     *            value to be assigned to property atmos
     */
    public void setAtmos(boolean atmos) {
        this.atmos = atmos;
    }

    /**
     * Getter method for property <tt>advancedFileTypeDevice</tt>.
     * 
     * @return property value of advancedFileTypeDevice
     */
    public boolean isAdvancedFileTypeDevice() {
        return advancedFileTypeDevice;
    }

    /**
     * Setter method for property <tt>advancedFileTypeDevice</tt>.
     * 
     * @param advancedFileTypeDevice
     *            value to be assigned to property advancedFileTypeDevice
     */
    public void setAdvancedFileTypeDevice(boolean advancedFileTypeDevice) {
        this.advancedFileTypeDevice = advancedFileTypeDevice;
    }

    /**
     * Getter method for property <tt>autoChangersNum</tt>.
     * 
     * @return property value of autoChangersNum
     */
    public Integer getAutoChangersNum() {
        return autoChangersNum;
    }

    /**
     * Setter method for property <tt>autoChangersNum</tt>.
     * 
     * @param autoChangersNum
     *            value to be assigned to property autoChangersNum
     */
    public void setAutoChangersNum(Integer autoChangersNum) {
        this.autoChangersNum = autoChangersNum;
    }

    /**
     * Getter method for property <tt>tapeDevicesNum</tt>.
     * 
     * @return property value of tapeDevicesNum
     */
    public Integer getTapeDevicesNum() {
        return tapeDevicesNum;
    }

    /**
     * Setter method for property <tt>tapeDevicesNum</tt>.
     * 
     * @param tapeDevicesNum
     *            value to be assigned to property tapeDevicesNum
     */
    public void setTapeDevicesNum(Integer tapeDevicesNum) {
        this.tapeDevicesNum = tapeDevicesNum;
    }

    /**
     * Getter method for property <tt>advancedFileTypeDevicesNum</tt>.
     * 
     * @return property value of advancedFileTypeDevicesNum
     */
    public Integer getAdvancedFileTypeDevicesNum() {
        return advancedFileTypeDevicesNum;
    }

    /**
     * Setter method for property <tt>advancedFileTypeDevicesNum</tt>.
     * 
     * @param advancedFileTypeDevicesNum
     *            value to be assigned to property advancedFileTypeDevicesNum
     */
    public void setAdvancedFileTypeDevicesNum(Integer advancedFileTypeDevicesNum) {
        this.advancedFileTypeDevicesNum = advancedFileTypeDevicesNum;
    }

    /**
     * Getter method for property <tt>ddBoostDevicesNum</tt>.
     * 
     * @return property value of ddBoostDevicesNum
     */
    public Integer getDdBoostDevicesNum() {
        return ddBoostDevicesNum;
    }

    /**
     * Setter method for property <tt>ddBoostDevicesNum</tt>.
     * 
     * @param ddBoostDevicesNum
     *            value to be assigned to property ddBoostDevicesNum
     */
    public void setDdBoostDevicesNum(Integer ddBoostDevicesNum) {
        this.ddBoostDevicesNum = ddBoostDevicesNum;
    }

    /**
     * Getter method for property <tt>atmosDevicesNum</tt>.
     * 
     * @return property value of atmosDevicesNum
     */
    public Integer getAtmosDevicesNum() {
        return atmosDevicesNum;
    }

    /**
     * Setter method for property <tt>atmosDevicesNum</tt>.
     * 
     * @param atmosDevicesNum
     *            value to be assigned to property atmosDevicesNum
     */
    public void setAtmosDevicesNum(Integer atmosDevicesNum) {
        this.atmosDevicesNum = atmosDevicesNum;
    }

}

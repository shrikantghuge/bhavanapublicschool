/*
 * This code is copyright (c) 2014 EMC Corporation
 */
package com.emc.gs.tools.srf.model.isilon;

import com.emc.gs.tools.srf.model.IdentifiableEntity;

/**
 * <p>
 * This is IsilonDesignAndImpl entity class.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safety.
 * </p>
 *
 * <p>
 * Version 1.1 (SRT 4 OCT2014 Updates Part 2 Assembly) Change notes:
 *   <ol>
 *     <li>Added {@link #include1UInfiniBandSwitchInstall} property.</li>
 *     <li>Added {@link #include12UNodeInstall} property.</li>
 *     <li>Added {@link #include4UInfiniBandChassisInstall} property.</li>
 *     <li>Added {@link #include4UNodeInstall} property.</li>
 *   </ol>
 * </p>
 * 
 * @author isv
 * @version 1.1
 * @since SRT Phase 3-3 - Implement Isilon and ViPR Tabs Assembly
 */
public class IsilonDesignAndImpl extends IdentifiableEntity {

    /**
     * Install Isilon Hardware(New Cluster or Node Expansion)?
     */
    private Boolean installHardware;

    /**
     * Include Isilon Technology Refresh?
     */
    private Boolean includeTechRefresh;

    /**
     * New Isilon Cluster?
     */
    private Boolean newCluster;

    /**
     * # of Isilon subnets to configure.
     */
    private Integer subnetsNum;

    /**
     * # of Isilon Smart Connect Zones to Configure.
     */
    private Integer smartConnectZonesNum;

    /**
     * # of Authentication Methods to Configure.
     */
    private Integer authMethodsNum;

    /**
     * # of Isilon Shares / Exports to Configure.
     */
    private Integer sharesExportsNum;

    /**
     * # of Isilon Smart Quotas to Configure.
     */
    private Integer smartQuotasNum;

    /**
     * # of Snapshots IQ Entries to Configure.
     */
    private Integer snapshotsIQEntriesNum;

    /**
     * Include Email and Support IQ Configuration?
     */
    private Boolean includeEmail;

    /**
     * Include subnet configuration?
     */
    private Boolean includeSubnet;

    /**
     * Include advice on data protection levels?
     */
    private Boolean includeAdvice;

    /**
     * Include smart connect configuration?
     */
    private Boolean includeSmartConnect;

    /**
     * Include authentication configuration?
     */
    private Boolean includeAuth;

    /**
     * Include File System Shares / Export Configuration?
     */
    private Boolean includeFileSystemShares;

    /**
     * Install Insight IQ?
     */
    private Boolean installInsightIQ;

    /**
     * Include Configuration of Smart Quotas?
     */
    private Boolean includeSmartQuotas;

    /**
     * Include Configuration of Isilon Snapshots?
     */
    private Boolean includeSnapshots;

    /**
     * Include NDMP Configuration?
     */
    private Boolean includeNDMP;

    /**
     * Include SmartLock Configuration?
     */
    private Boolean includeSmartLock;

    /**
     * <p>A <code>Boolean</code> providing the value for "Include 1U InfiniBand Switch Installation?" property.</p>
     *
     * @since 1.1
     */
    private Boolean include1UInfiniBandSwitchInstall;

    /**
     * <p>A <code>Boolean</code> providing the value for "Include InfiniBand 4U Chassis Installation?" property.</p>
     *
     * @since 1.1
     */
    private Boolean include4UInfiniBandChassisInstall;

    /**
     * <p>A <code>Boolean</code> providing the value for "Include 1-2U Node Installation?" property.</p>
     *
     * @since 1.1
     */
    private Boolean include12UNodeInstall;

    /**
     * <p>A <code>Boolean</code> providing the value for "Include 4U Node Installation?" property.</p>
     *
     * @since 1.1
     */
    private Boolean include4UNodeInstall;

    /**
     * <p>Gets the "Include 4U Node Installation?" property.</p>
     *
     * @return a <code>Boolean</code> providing the value for "Include 4U Node Installation?" property.
     * @since 1.1
     */
    public Boolean getInclude4UNodeInstall() {
        return this.include4UNodeInstall;
    }

    /**
     * <p>Sets the "Include 4U Node Installation?" property.</p>
     *
     * @param include4UNodeInstall a <code>Boolean</code> providing the value for "Include 4U Node Installation?"
     * property.
     * @since 1.1
     */
    public void setInclude4UNodeInstall(Boolean include4UNodeInstall) {
        this.include4UNodeInstall = include4UNodeInstall;
    }

    /**
     * <p>Gets the "Include 1-2U Node Installation?" property.</p>
     *
     * @return a <code>Boolean</code> providing the value for "Include 1-2U Node Installation?" property.
     * @since 1.1
     */
    public Boolean getInclude12UNodeInstall() {
        return this.include12UNodeInstall;
    }

    /**
     * <p>Sets the "Include 1-2U Node Installation?" property.</p>
     *
     * @param include12UNodeInstall a <code>Boolean</code> providing the value for "Include 1-2U Node Installation?"
     * property.
     * @since 1.1
     */
    public void setInclude12UNodeInstall(Boolean include12UNodeInstall) {
        this.include12UNodeInstall = include12UNodeInstall;
    }

    /**
     * <p>Gets the "Include InfiniBand 4U Chassis Installation?" property.</p>
     *
     * @return a <code>Boolean</code> providing the value for "Include InfiniBand 4U Chassis Installation?" property.
     * @since 1.1
     */
    public Boolean getInclude4UInfiniBandChassisInstall() {
        return this.include4UInfiniBandChassisInstall;
    }

    /**
     * <p>Sets the "Include InfiniBand 4U Chassis Installation?" property.</p>
     *
     * @param include4UInfiniBandChassisInstall a <code>Boolean</code> providing the value for "Include InfiniBand 4U
     * Chassis Installation?" property.
     * @since 1.1
     */
    public void setInclude4UInfiniBandChassisInstall(Boolean include4UInfiniBandChassisInstall) {
        this.include4UInfiniBandChassisInstall = include4UInfiniBandChassisInstall;
    }

    /**
     * <p>Gets the "Include 1U InfiniBand Switch Installation?" property.</p>
     *
     * @return a <code>Boolean</code> providing the value for "Include 1U InfiniBand Switch Installation?" property.
     * @since 1.1
     */
    public Boolean getInclude1UInfiniBandSwitchInstall() {
        return this.include1UInfiniBandSwitchInstall;
    }

    /**
     * <p>Sets the "Include 1U InfiniBand Switch Installation?" property.</p>
     *
     * @param include1UInfiniBandSwitchInstall a <code>Boolean</code> providing the value for "Include 1U InfiniBand
     * Switch Installation?" property.
     * @since 1.1
     */
    public void setInclude1UInfiniBandSwitchInstall(Boolean include1UInfiniBandSwitchInstall) {
        this.include1UInfiniBandSwitchInstall = include1UInfiniBandSwitchInstall;
    }

    /**
     * <p>
     * The default constructor.
     * </p>
     */
    public IsilonDesignAndImpl() {
    }

    /**
     * Getter method for property <tt>installHardware</tt>.
     * 
     * @return property value of installHardware
     */
    public Boolean getInstallHardware() {
        return installHardware;
    }

    /**
     * Setter method for property <tt>installHardware</tt>.
     * 
     * @param installHardware
     *            value to be assigned to property installHardware
     */
    public void setInstallHardware(Boolean installHardware) {
        this.installHardware = installHardware;
    }

    /**
     * Getter method for property <tt>includeTechRefresh</tt>.
     * 
     * @return property value of includeTechRefresh
     */
    public Boolean getIncludeTechRefresh() {
        return includeTechRefresh;
    }

    /**
     * Setter method for property <tt>includeTechRefresh</tt>.
     * 
     * @param includeTechRefresh
     *            value to be assigned to property includeTechRefresh
     */
    public void setIncludeTechRefresh(Boolean includeTechRefresh) {
        this.includeTechRefresh = includeTechRefresh;
    }

    /**
     * Getter method for property <tt>newCluster</tt>.
     * 
     * @return property value of newCluster
     */
    public Boolean getNewCluster() {
        return newCluster;
    }

    /**
     * Setter method for property <tt>newCluster</tt>.
     * 
     * @param newCluster
     *            value to be assigned to property newCluster
     */
    public void setNewCluster(Boolean newCluster) {
        this.newCluster = newCluster;
    }

    /**
     * Getter method for property <tt>subnetsNum</tt>.
     * 
     * @return property value of subnetsNum
     */
    public Integer getSubnetsNum() {
        return subnetsNum;
    }

    /**
     * Setter method for property <tt>subnetsNum</tt>.
     * 
     * @param subnetsNum
     *            value to be assigned to property subnetsNum
     */
    public void setSubnetsNum(Integer subnetsNum) {
        this.subnetsNum = subnetsNum;
    }

    /**
     * Getter method for property <tt>smartConnectZonesNum</tt>.
     * 
     * @return property value of smartConnectZonesNum
     */
    public Integer getSmartConnectZonesNum() {
        return smartConnectZonesNum;
    }

    /**
     * Setter method for property <tt>smartConnectZonesNum</tt>.
     * 
     * @param smartConnectZonesNum
     *            value to be assigned to property smartConnectZonesNum
     */
    public void setSmartConnectZonesNum(Integer smartConnectZonesNum) {
        this.smartConnectZonesNum = smartConnectZonesNum;
    }

    /**
     * Getter method for property <tt>authMethodsNum</tt>.
     * 
     * @return property value of authMethodsNum
     */
    public Integer getAuthMethodsNum() {
        return authMethodsNum;
    }

    /**
     * Setter method for property <tt>authMethodsNum</tt>.
     * 
     * @param authMethodsNum
     *            value to be assigned to property authMethodsNum
     */
    public void setAuthMethodsNum(Integer authMethodsNum) {
        this.authMethodsNum = authMethodsNum;
    }

    /**
     * Getter method for property <tt>sharesExportsNum</tt>.
     * 
     * @return property value of sharesExportsNum
     */
    public Integer getSharesExportsNum() {
        return sharesExportsNum;
    }

    /**
     * Setter method for property <tt>sharesExportsNum</tt>.
     * 
     * @param sharesExportsNum
     *            value to be assigned to property sharesExportsNum
     */
    public void setSharesExportsNum(Integer sharesExportsNum) {
        this.sharesExportsNum = sharesExportsNum;
    }

    /**
     * Getter method for property <tt>smartQuotasNum</tt>.
     * 
     * @return property value of smartQuotasNum
     */
    public Integer getSmartQuotasNum() {
        return smartQuotasNum;
    }

    /**
     * Setter method for property <tt>smartQuotasNum</tt>.
     * 
     * @param smartQuotasNum
     *            value to be assigned to property smartQuotasNum
     */
    public void setSmartQuotasNum(Integer smartQuotasNum) {
        this.smartQuotasNum = smartQuotasNum;
    }

    /**
     * Getter method for property <tt>snapshotsIQEntriesNum</tt>.
     * 
     * @return property value of snapshotsIQEntriesNum
     */
    public Integer getSnapshotsIQEntriesNum() {
        return snapshotsIQEntriesNum;
    }

    /**
     * Setter method for property <tt>snapshotsIQEntriesNum</tt>.
     * 
     * @param snapshotsIQEntriesNum
     *            value to be assigned to property snapshotsIQEntriesNum
     */
    public void setSnapshotsIQEntriesNum(Integer snapshotsIQEntriesNum) {
        this.snapshotsIQEntriesNum = snapshotsIQEntriesNum;
    }

    /**
     * Getter method for property <tt>includeEmail</tt>.
     * 
     * @return property value of includeEmail
     */
    public Boolean getIncludeEmail() {
        return includeEmail;
    }

    /**
     * Setter method for property <tt>includeEmail</tt>.
     * 
     * @param includeEmail
     *            value to be assigned to property includeEmail
     */
    public void setIncludeEmail(Boolean includeEmail) {
        this.includeEmail = includeEmail;
    }

    /**
     * Getter method for property <tt>includeSubnet</tt>.
     * 
     * @return property value of includeSubnet
     */
    public Boolean getIncludeSubnet() {
        return includeSubnet;
    }

    /**
     * Setter method for property <tt>includeSubnet</tt>.
     * 
     * @param includeSubnet
     *            value to be assigned to property includeSubnet
     */
    public void setIncludeSubnet(Boolean includeSubnet) {
        this.includeSubnet = includeSubnet;
    }

    /**
     * Getter method for property <tt>includeAdvice</tt>.
     * 
     * @return property value of includeAdvice
     */
    public Boolean getIncludeAdvice() {
        return includeAdvice;
    }

    /**
     * Setter method for property <tt>includeAdvice</tt>.
     * 
     * @param includeAdvice
     *            value to be assigned to property includeAdvice
     */
    public void setIncludeAdvice(Boolean includeAdvice) {
        this.includeAdvice = includeAdvice;
    }

    /**
     * Getter method for property <tt>includeSmartConnect</tt>.
     * 
     * @return property value of includeSmartConnect
     */
    public Boolean getIncludeSmartConnect() {
        return includeSmartConnect;
    }

    /**
     * Setter method for property <tt>includeSmartConnect</tt>.
     * 
     * @param includeSmartConnect
     *            value to be assigned to property includeSmartConnect
     */
    public void setIncludeSmartConnect(Boolean includeSmartConnect) {
        this.includeSmartConnect = includeSmartConnect;
    }

    /**
     * Getter method for property <tt>includeAuth</tt>.
     * 
     * @return property value of includeAuth
     */
    public Boolean getIncludeAuth() {
        return includeAuth;
    }

    /**
     * Setter method for property <tt>includeAuth</tt>.
     * 
     * @param includeAuth
     *            value to be assigned to property includeAuth
     */
    public void setIncludeAuth(Boolean includeAuth) {
        this.includeAuth = includeAuth;
    }

    /**
     * Getter method for property <tt>includeFileSystemShares</tt>.
     * 
     * @return property value of includeFileSystemShares
     */
    public Boolean getIncludeFileSystemShares() {
        return includeFileSystemShares;
    }

    /**
     * Setter method for property <tt>includeFileSystemShares</tt>.
     * 
     * @param includeFileSystemShares
     *            value to be assigned to property includeFileSystemShares
     */
    public void setIncludeFileSystemShares(Boolean includeFileSystemShares) {
        this.includeFileSystemShares = includeFileSystemShares;
    }

    /**
     * Getter method for property <tt>installInsightIQ</tt>.
     * 
     * @return property value of installInsightIQ
     */
    public Boolean getInstallInsightIQ() {
        return installInsightIQ;
    }

    /**
     * Setter method for property <tt>installInsightIQ</tt>.
     * 
     * @param installInsightIQ
     *            value to be assigned to property installInsightIQ
     */
    public void setInstallInsightIQ(Boolean installInsightIQ) {
        this.installInsightIQ = installInsightIQ;
    }

    /**
     * Getter method for property <tt>includeSmartQuotas</tt>.
     * 
     * @return property value of includeSmartQuotas
     */
    public Boolean getIncludeSmartQuotas() {
        return includeSmartQuotas;
    }

    /**
     * Setter method for property <tt>includeSmartQuotas</tt>.
     * 
     * @param includeSmartQuotas
     *            value to be assigned to property includeSmartQuotas
     */
    public void setIncludeSmartQuotas(Boolean includeSmartQuotas) {
        this.includeSmartQuotas = includeSmartQuotas;
    }

    /**
     * Getter method for property <tt>includeSnapshots</tt>.
     * 
     * @return property value of includeSnapshots
     */
    public Boolean getIncludeSnapshots() {
        return includeSnapshots;
    }

    /**
     * Setter method for property <tt>includeSnapshots</tt>.
     * 
     * @param includeSnapshots
     *            value to be assigned to property includeSnapshots
     */
    public void setIncludeSnapshots(Boolean includeSnapshots) {
        this.includeSnapshots = includeSnapshots;
    }

    /**
     * Getter method for property <tt>includeNDMP</tt>.
     * 
     * @return property value of includeNDMP
     */
    public Boolean getIncludeNDMP() {
        return includeNDMP;
    }

    /**
     * Setter method for property <tt>includeNDMP</tt>.
     * 
     * @param includeNDMP
     *            value to be assigned to property includeNDMP
     */
    public void setIncludeNDMP(Boolean includeNDMP) {
        this.includeNDMP = includeNDMP;
    }

    /**
     * Getter method for property <tt>includeSmartLock</tt>.
     * 
     * @return property value of includeSmartLock
     */
    public Boolean getIncludeSmartLock() {
        return includeSmartLock;
    }

    /**
     * Setter method for property <tt>includeSmartLock</tt>.
     * 
     * @param includeSmartLock
     *            value to be assigned to property includeSmartLock
     */
    public void setIncludeSmartLock(Boolean includeSmartLock) {
        this.includeSmartLock = includeSmartLock;
    }

}

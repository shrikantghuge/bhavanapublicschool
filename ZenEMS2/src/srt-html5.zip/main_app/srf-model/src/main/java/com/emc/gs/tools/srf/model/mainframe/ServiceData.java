/*
 * This code is copyright (c) 2013 - 2014 EMC Corporation.
 */
package com.emc.gs.tools.srf.model.mainframe;

import com.emc.gs.tools.srf.model.IdentifiableEntity;

/**
 * <p>
 * This is ServiceData entity class.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safety.
 * </p>
 *
 * @author faeton, stevenfrog
 * @version 1.0
 */
public abstract class ServiceData extends IdentifiableEntity {
    /**
     * <p>
     * The serviceName.
     * </p>
     */
    private String serviceName;

    /**
     * <p>
     * The description.
     * </p>
     */
    private String description;

    /**
     * <p>
     * The default constructor.
     * </p>
     */
    protected ServiceData() {
        // Empty

    }

    /**
     * <p>
     * Retrieves the serviceName field.
     * </p>
     *
     * @return the serviceName
     */
    public String getServiceName() {
        return serviceName;
    }

    /**
     * <p>
     * Sets the value to serviceName field.
     * </p>
     *
     * @param serviceName
     *            the serviceName to set
     */
    public void setServiceName(String serviceName) {
        this.serviceName = serviceName;
    }

    /**
     * <p>
     * Retrieves the description field.
     * </p>
     *
     * @return the description
     */
    public String getDescription() {
        return description;
    }

    /**
     * <p>
     * Sets the value to description field.
     * </p>
     *
     * @param description
     *            the description to set
     */
    public void setDescription(String description) {
        this.description = description;
    }

    /**
     * The toString method.
     *
     * @return the string for this entity
     */
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("{").append(super.toString());
        sb.append(", serviceName:").append(serviceName);
        sb.append(", description:").append(description).append("}");
        return sb.toString();
    }
}

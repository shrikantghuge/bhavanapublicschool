/*
 * This code is copyright (c) 2014 EMC Corporation
 */
package com.emc.gs.tools.srf.model.mss;

import com.emc.gs.tools.srf.model.IdentifiableEntity;

/**
 * <p>
 * This is Data Domain of MSSArray entity class.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safe.
 * </p>
 * <p>
 * <strong>Changes V1.1:</strong> <strong>SRT Phase 3-1 - CTA Rainfinity and MSS Tabs Update Assembly</strong>
 * <ul>
 * <li>Add numRetentionDrives field.</li>
 * </ul>
 * </p>
 * 
 * @author TCSASSEMBLER
 * @version 1.1
 * @since SRT Phase 3-1 - CTA Rainfinity and MSS Tabs Assembly
 */
public class MSSDataDomain extends IdentifiableEntity {

    /**
     * Model type.
     */
    private String modelType;

    /**
     * Serial number.
     */
    private String serialNumber;

    /**
     * Number of drives for retention.
     */
    private Integer numRetentionDrives;

    /**
     * <p>
     * The default constructor.
     * </p>
     */
    public MSSDataDomain() {
    }

    /**
     * Getter method for property <tt>modelType</tt>.
     * 
     * @return property value of modelType
     */
    public String getModelType() {
        return modelType;
    }

    /**
     * Setter method for property <tt>modelType</tt>.
     * 
     * @param modelType
     *            value to be assigned to property modelType
     */
    public void setModelType(String modelType) {
        this.modelType = modelType;
    }

    /**
     * Getter method for property <tt>serialNumber</tt>.
     * 
     * @return property value of serialNumber
     */
    public String getSerialNumber() {
        return serialNumber;
    }

    /**
     * Setter method for property <tt>serialNumber</tt>.
     * 
     * @param serialNumber
     *            value to be assigned to property serialNumber
     */
    public void setSerialNumber(String serialNumber) {
        this.serialNumber = serialNumber;
    }

    /**
     * Getter method for property <tt>numRetentionDrives</tt>.
     * 
     * @return property value of numRetentionDrives
     */
    public Integer getNumRetentionDrives() {
        return numRetentionDrives;
    }

    /**
     * Setter method for property <tt>numRetentionDrives</tt>.
     * 
     * @param numRetentionDrives
     *            value to be assigned to property numRetentionDrives
     */
    public void setNumRetentionDrives(Integer numRetentionDrives) {
        this.numRetentionDrives = numRetentionDrives;
    }

}

/*
 * This code is copyright (c) 2013 - 2014 EMC Corporation.
 */
package com.emc.gs.tools.srf.model;

import java.util.Date;

/**
 * <p>
 * This is RequestContractData entity class.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safety.
 * </p>
 *
 * <p>
 * <strong>Changes:</strong>
 * <strong>SRT Release Assembly - Base</strong>
 * <ul>
 * <li>Release_assembly_tasks.xls Row#7: Renamed CustomerContractData to RequestContractData</li>
 * <li>Release_assembly_tasks.xls Row#8: Fixed sowType</li>
 * </ul>
 * </p>
 * 
 * <p>
 * <strong>Changes V1.2:</strong>
 * <strong>SRT Bug Fixes</strong>
 * <ul>
 * <li>Removed poNumber and soNumber fields</li>
 * </ul>
 * </p>
 * 
 * <p>
 * <strong>Changes V1.3:</strong>
 * <ul>
 * <li>Removed businessObjectives field.</li>
 * </ul>
 * </p>
 *
 * @author faeton, stevenfrog, MonicaMuranyi
 * @version 1.3
 */
public class RequestContractData extends IdentifiableEntity {
    /**
     * <p>
     * The sowType.
     * </p>
     */
    private SowType sowType;

    /**
     * <p>
     * The customerFormatRequired.
     * </p>
     */
    private boolean customerFormatRequired;

    /**
     * <p>
     * The servicesAgreementType.
     * </p>
     */
    private ServicesAgreementType servicesAgreementType;

    /**
     * <p>
     * The servicesAgreementDate.
     * </p>
     */
    private Date servicesAgreementDate;

    /**
     * <p>
     * The partnerInformation.
     * </p>
     */
    private String partnerInformation;

    /**
     * <p>
     * The default constructor.
     * </p>
     */
    public RequestContractData() {
        // Empty
    }

    /**
     * <p>
     * Retrieves the sowType field.
     * </p>
     *
     * @return the sowType
     */
    public SowType getSowType() {
        return sowType;
    }

    /**
     * <p>
     * Sets the value to sowType field.
     * </p>
     *
     * @param sowType
     *            the sowType to set
     */
    public void setSowType(SowType sowType) {
        this.sowType = sowType;
    }

    /**
     * <p>
     * Retrieves the customerFormatRequired field.
     * </p>
     *
     * @return the customerFormatRequired
     */
    public boolean isCustomerFormatRequired() {
        return customerFormatRequired;
    }

    /**
     * <p>
     * Sets the value to customerFormatRequired field.
     * </p>
     *
     * @param customerFormatRequired
     *            the customerFormatRequired to set
     */
    public void setCustomerFormatRequired(boolean customerFormatRequired) {
        this.customerFormatRequired = customerFormatRequired;
    }

    /**
     * <p>
     * Retrieves the servicesAgreementType field.
     * </p>
     *
     * @return the servicesAgreementType
     */
    public ServicesAgreementType getServicesAgreementType() {
        return servicesAgreementType;
    }

    /**
     * <p>
     * Sets the value to servicesAgreementType field.
     * </p>
     *
     * @param servicesAgreementType
     *            the servicesAgreementType to set
     */
    public void setServicesAgreementType(ServicesAgreementType servicesAgreementType) {
        this.servicesAgreementType = servicesAgreementType;
    }

    /**
     * <p>
     * Retrieves the servicesAgreementDate field.
     * </p>
     *
     * @return the servicesAgreementDate
     */
    public Date getServicesAgreementDate() {
        return servicesAgreementDate;
    }

    /**
     * <p>
     * Sets the value to servicesAgreementDate field.
     * </p>
     *
     * @param servicesAgreementDate
     *            the servicesAgreementDate to set
     */
    public void setServicesAgreementDate(Date servicesAgreementDate) {
        this.servicesAgreementDate = servicesAgreementDate;
    }

    /**
     * <p>
     * Retrieves the partnerInformation field.
     * </p>
     *
     * @return the partnerInformation
     */
    public String getPartnerInformation() {
        return partnerInformation;
    }

    /**
     * <p>
     * Sets the value to partnerInformation field.
     * </p>
     *
     * @param partnerInformation
     *            the partnerInformation to set
     */
    public void setPartnerInformation(String partnerInformation) {
        this.partnerInformation = partnerInformation;
    }

    /**
     * The toString method.
     *
     * @return the string for this entity
     */
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("{").append(super.toString());
        sb.append(", sowType:").append(sowType);
        sb.append(", customerFormatRequired:").append(customerFormatRequired);
        sb.append(", servicesAgreementType:").append(servicesAgreementType);
        sb.append(", servicesAgreementDate:").append(servicesAgreementDate);
        sb.append(", partnerInformation:").append(partnerInformation).append("}");
        return sb.toString();
    }
}

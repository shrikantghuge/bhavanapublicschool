/*
 * This code is copyright (c) 2014 EMC Corporation.
 */
package com.emc.gs.tools.srf.model.infrastructure;

/**
 * <p>
 * This is array information for DataMigrationInformation entity.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safety.
 * </p>
 *
 * <p>
 * Version 1.1 (SRT 4 OCT2014 Updates Part 1 Assembly) Change notes:
 *   <ol>
 *     <li>Removed <code>topology</code> property.</li>
 *   </ol>
 * </p>
 * 
 * @author liuliquan, isv
 * @version 1.1
 */
public class DataMigrationInformationArray {

    /**
     * <p>
     * The array type.
     * </p>
     */
    private EnvironmentArrayType environmentArrayType;

    /**
     * <p>
     * The location.
     * </p>
     */
    private String location;

    /**
     * <p>
     * The number of Non-ESX hosts.
     * </p>
     */
    private Integer numberOfNonEsxHosts;

    /**
     * <p>
     * The number of ESX hosts.
     * </p>
     */
    private Integer numberOfEsxHosts;

    /**
     * <p>
     * The number of Virtual Machines.
     * </p>
     */
    private Integer numberOfVirtualMachines;

    /**
     * <p>
     * The swing box.
     * </p>
     */
    private boolean swingBox;

    /**
     * <p>
     * The array type (Source/Target).
     * </p>
     */
    private String arrayType;

    /**
     * <p>
     * The capacity (TB).
     * </p>
     */
    private Double capacity;

    /**
     * Empty constructor.
     */
    public DataMigrationInformationArray() {
    }

    /**
     * Getter method for property <tt>environmentArrayType</tt>.
     * @return property value of environmentArrayType
     */
    public EnvironmentArrayType getEnvironmentArrayType() {
        return environmentArrayType;
    }

    /**
     * Setter method for property <tt>environmentArrayType</tt>.
     * @param environmentArrayType value to be assigned to property environmentArrayType
     */
    public void setEnvironmentArrayType(EnvironmentArrayType environmentArrayType) {
        this.environmentArrayType = environmentArrayType;
    }

    /**
     * Getter method for property <tt>location</tt>.
     * @return property value of location
     */
    public String getLocation() {
        return location;
    }

    /**
     * Setter method for property <tt>location</tt>.
     * @param location
     *            value to be assigned to property location
     */
    public void setLocation(String location) {
        this.location = location;
    }

    /**
     * Getter method for property <tt>numberOfNonEsxHosts</tt>.
     * @return property value of numberOfNonEsxHosts
     */
    public Integer getNumberOfNonEsxHosts() {
        return numberOfNonEsxHosts;
    }

    /**
     * Setter method for property <tt>numberOfNonEsxHosts</tt>.
     * @param numberOfNonEsxHosts
     *            value to be assigned to property numberOfNonEsxHosts
     */
    public void setNumberOfNonEsxHosts(Integer numberOfNonEsxHosts) {
        this.numberOfNonEsxHosts = numberOfNonEsxHosts;
    }

    /**
     * Getter method for property <tt>numberOfEsxHosts</tt>.
     * @return property value of numberOfEsxHosts
     */
    public Integer getNumberOfEsxHosts() {
        return numberOfEsxHosts;
    }

    /**
     * Setter method for property <tt>numberOfEsxHosts</tt>.
     * @param numberOfEsxHosts
     *            value to be assigned to property numberOfEsxHosts
     */
    public void setNumberOfEsxHosts(Integer numberOfEsxHosts) {
        this.numberOfEsxHosts = numberOfEsxHosts;
    }

    /**
     * Getter method for property <tt>numberOfVirtualMachines</tt>.
     * @return property value of numberOfVirtualMachines
     */
    public Integer getNumberOfVirtualMachines() {
        return numberOfVirtualMachines;
    }

    /**
     * Setter method for property <tt>numberOfVirtualMachines</tt>.
     * @param numberOfVirtualMachines
     *            value to be assigned to property numberOfVirtualMachines
     */
    public void setNumberOfVirtualMachines(Integer numberOfVirtualMachines) {
        this.numberOfVirtualMachines = numberOfVirtualMachines;
    }

    /**
     * Getter method for property <tt>swingBox</tt>.
     * @return property value of swingBox
     */
    public boolean isSwingBox() {
        return swingBox;
    }

    /**
     * Setter method for property <tt>swingBox</tt>.
     * @param swingBox
     *            value to be assigned to property swingBox
     */
    public void setSwingBox(boolean swingBox) {
        this.swingBox = swingBox;
    }

    /**
     * Getter method for property <tt>capacity</tt>.
     * @return property value of capacity
     */
    public Double getCapacity() {
        return capacity;
    }

    /**
     * Setter method for property <tt>capacity</tt>.
     * @param capacity
     *            value to be assigned to property capacity
     */
    public void setCapacity(Double capacity) {
        this.capacity = capacity;
    }

    /**
     * Getter method for property <tt>arrayType</tt>.
     * @return property value of arrayType
     */
    public String getArrayType() {
        return arrayType;
    }

    /**
     * Setter method for property <tt>arrayType</tt>.
     * @param arrayType value to be assigned to property arrayType
     */
    public void setArrayType(String arrayType) {
        this.arrayType = arrayType;
    }

    /**
     * The toString method.
     *
     * @return the string for this entity
     */
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("{");
        sb.append("location:").append(location);
        sb.append(", environmentArrayType:").append(environmentArrayType);
        sb.append(", numberOfEsxHosts:").append(numberOfEsxHosts);
        sb.append(", numberOfNonEsxHosts:").append(numberOfNonEsxHosts);
        sb.append(", numberOfVirtualMachines:").append(numberOfVirtualMachines);
        sb.append(", swingBox:").append(swingBox);
        sb.append(", arrayType:").append(arrayType);
        sb.append(", capacity:").append(capacity).append("}");
        return sb.toString();
    }
}

/*
 * This code is copyright (c) 2014 EMC Corporation.
 */
package com.emc.gs.tools.srf.model.move;

import com.emc.gs.tools.srf.model.IdentifiableEntity;

/**
 * <p>
 * This is Site Information entity class.
 * </p>
 *
 * @author TCSASSEMBLER
 * @version 1.0
 * @since SRT Phase 3-2 - Implement SRM and Update Change Request and Move Request Tabs Assembly
 */
public class SiteInformation extends IdentifiableEntity {
    
    /**
     * Site 1 Address (moving from) **ZIP CODE REQUIRED**.
     */
    private String address;
    /**
     * Site 1 have trailer access.
     */
    private Boolean trailerAccess;
    /**
     * Site 1 have loading docks.
     */
    private Boolean loadingDocks;
    /**
     * Equipment on second floor? If so Elevator available?
     */
    private Boolean equipmentOnSecondFloor;
    /**
     * Is a truck lift gate required.
     */
    private Boolean truckLiftGateRequired;

    /**
     * When does packaging material need to be onsite.
     */
    private String packingMaterialsOnsiteDate;
    /**
     * When is the equipment to be picked up for transport.
     */
    private String pickupDate;
    /**
     * When is the equipment to be delivered.
     */
    private String deliveryDate;

    /**
     * Empty constructor.
     */
    public SiteInformation() {
    }

    /**
     * Gets the value of the field <code>address</code>.
     * @return the address
     */
    public String getAddress() {
        return address;
    }

    /**
     * Sets the value of the field <code>address</code>.
     * @param address the address to set
     */
    public void setAddress(String address) {
        this.address = address;
    }

    /**
     * Gets the value of the field <code>trailerAccess</code>.
     * @return the trailerAccess
     */
    public Boolean getTrailerAccess() {
        return trailerAccess;
    }

    /**
     * Sets the value of the field <code>trailerAccess</code>.
     * @param trailerAccess the trailerAccess to set
     */
    public void setTrailerAccess(Boolean trailerAccess) {
        this.trailerAccess = trailerAccess;
    }

    /**
     * Gets the value of the field <code>loadingDocks</code>.
     * @return the loadingDocks
     */
    public Boolean getLoadingDocks() {
        return loadingDocks;
    }

    /**
     * Sets the value of the field <code>loadingDocks</code>.
     * @param loadingDocks the loadingDocks to set
     */
    public void setLoadingDocks(Boolean loadingDocks) {
        this.loadingDocks = loadingDocks;
    }

    /**
     * Gets the value of the field <code>equipmentOnSecondFloor</code>.
     * @return the equipmentOnSecondFloor
     */
    public Boolean getEquipmentOnSecondFloor() {
        return equipmentOnSecondFloor;
    }

    /**
     * Sets the value of the field <code>equipmentOnSecondFloor</code>.
     * @param equipmentOnSecondFloor the equipmentOnSecondFloor to set
     */
    public void setEquipmentOnSecondFloor(Boolean equipmentOnSecondFloor) {
        this.equipmentOnSecondFloor = equipmentOnSecondFloor;
    }

    /**
     * Gets the value of the field <code>truckLiftGateRequired</code>.
     * @return the truckLiftGateRequired
     */
    public Boolean getTruckLiftGateRequired() {
        return truckLiftGateRequired;
    }

    /**
     * Sets the value of the field <code>truckLiftGateRequired</code>.
     * @param truckLiftGateRequired the truckLiftGateRequired to set
     */
    public void setTruckLiftGateRequired(Boolean truckLiftGateRequired) {
        this.truckLiftGateRequired = truckLiftGateRequired;
    }

    /**
     * Gets the value of the field <code>packingMaterialsOnsiteDate</code>.
     * @return the packingMaterialsOnsiteDate
     */
    public String getPackingMaterialsOnsiteDate() {
        return packingMaterialsOnsiteDate;
    }

    /**
     * Sets the value of the field <code>packingMaterialsOnsiteDate</code>.
     * @param packingMaterialsOnsiteDate the packingMaterialsOnsiteDate to set
     */
    public void setPackingMaterialsOnsiteDate(String packingMaterialsOnsiteDate) {
        this.packingMaterialsOnsiteDate = packingMaterialsOnsiteDate;
    }

    /**
     * Gets the value of the field <code>pickupDate</code>.
     * @return the pickupDate
     */
    public String getPickupDate() {
        return pickupDate;
    }

    /**
     * Sets the value of the field <code>pickupDate</code>.
     * @param pickupDate the pickupDate to set
     */
    public void setPickupDate(String pickupDate) {
        this.pickupDate = pickupDate;
    }

    /**
     * Gets the value of the field <code>deliveryDate</code>.
     * @return the deliveryDate
     */
    public String getDeliveryDate() {
        return deliveryDate;
    }

    /**
     * Sets the value of the field <code>deliveryDate</code>.
     * @param deliveryDate the deliveryDate to set
     */
    public void setDeliveryDate(String deliveryDate) {
        this.deliveryDate = deliveryDate;
    }

    /**
     * Generates a string representation of this entity.
     * 
     * @return the properties of this object.
     */
    @Override
    public String toString() {
        return "SiteInformation [address=" + address + ", trailerAccess=" + trailerAccess + ", loadingDocks="
            + loadingDocks + ", equipmentOnSecondFloor=" + equipmentOnSecondFloor + ", truckLiftGateRequired="
            + truckLiftGateRequired + ", packingMaterialsOnsiteDate=" + packingMaterialsOnsiteDate + ", pickupDate="
            + pickupDate + ", deliveryDate=" + deliveryDate + "]";
    }
}

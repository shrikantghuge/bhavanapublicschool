/*
 * This code is copyright (c) 2013 - 2014 EMC Corporation.
 */
package com.emc.gs.tools.srf.model.mainframe;


/**
 * <p>
 * This is StringServiceData entity class.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safety.
 * </p>
 *
 * @author faeton, stevenfrog
 * @version 1.0
 */
public class StringServiceData extends ServiceData {
    /**
     * <p>
     * The value.
     * </p>
     */
    private String value;

    /**
     * <p>
     * The default constructor.
     * </p>
     */
    public StringServiceData() {
        // Empty
    }

    /**
     * <p>
     * Retrieves the value field.
     * </p>
     *
     * @return the value
     */
    public String getValue() {
        return value;
    }

    /**
     * <p>
     * Sets the value to value field.
     * </p>
     *
     * @param value
     *            the value to set
     */
    public void setValue(String value) {
        this.value = value;
    }

    /**
     * The toString method.
     *
     * @return the string for this entity
     */
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("{").append(super.toString());
        sb.append(", value:").append(value).append("}");
        return sb.toString();
    }
}

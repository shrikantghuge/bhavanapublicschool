/*
 * This code is copyright (c) 2014 EMC Corporation
 */
package com.emc.gs.tools.srf.model.mss;

import com.emc.gs.tools.srf.model.LookupEntity;

/**
 * <p>
 * This is MSSPlatform entity class.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safety.
 * </p>
 * 
 * @author TCSASSEMBLER
 * @version 1.0
 * @since SRT Phase 3-1 - CTA Rainfinity and MSS Tabs Assembly
 */
public class MSSPlatform extends LookupEntity {

    /**
     * <p>
     * The default constructor.
     * </p>
     */
    public MSSPlatform() {
    }

}

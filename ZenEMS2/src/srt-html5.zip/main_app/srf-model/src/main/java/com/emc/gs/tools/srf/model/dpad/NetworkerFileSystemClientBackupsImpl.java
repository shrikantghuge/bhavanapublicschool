/*
 * This code is copyright (c) 2014 EMC Corporation
 */
package com.emc.gs.tools.srf.model.dpad;

/**
 * <p>
 * This is NetworkerFileSystemClientBackupsImpl entity class.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safety.
 * </p>
 * 
 * @author TCSASSEMBLER
 * @version 1.0
 * @since SRT Phase 3-5 - BRS Tabs Part 3 Assembly
 */
public class NetworkerFileSystemClientBackupsImpl extends NetworkerFileSystemClientBackupsBase {

    /**
     * Networker Firewall Support?
     */
    private Boolean firewallSupport;

    /**
     * <p>
     * The default constructor.
     * </p>
     */
    public NetworkerFileSystemClientBackupsImpl() {
    }

    /**
     * Getter method for property <tt>firewallSupport</tt>.
     * 
     * @return property value of firewallSupport
     */
    public Boolean getFirewallSupport() {
        return firewallSupport;
    }

    /**
     * Setter method for property <tt>firewallSupport</tt>.
     * 
     * @param firewallSupport
     *            value to be assigned to property firewallSupport
     */
    public void setFirewallSupport(Boolean firewallSupport) {
        this.firewallSupport = firewallSupport;
    }

}

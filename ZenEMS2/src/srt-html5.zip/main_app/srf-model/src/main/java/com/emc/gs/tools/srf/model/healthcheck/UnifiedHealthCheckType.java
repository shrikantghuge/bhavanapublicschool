/*
 * This code is copyright (c) 2014 EMC Corporation
 */
package com.emc.gs.tools.srf.model.healthcheck;

import com.emc.gs.tools.srf.model.LookupEntity;

/**
 * <p>
 * This is UnifiedHealthCheckType entity class.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safety.
 * </p>
 * <p>
 * 
 * @author TCSASSEMBLER
 * @version 1.0
 * @since SRT Phase 3-4 - ASD and Healthcheck Tabs Assembly
 */
public class UnifiedHealthCheckType extends LookupEntity {

    /**
     * <p>
     * The default constructor.
     * </p>
     */
    public UnifiedHealthCheckType() {
    }

}

/*
 * This code is copyright (c) 2013 - 2014 EMC Corporation.
 */
package com.emc.gs.tools.srf.model.mainframe;

import com.emc.gs.tools.srf.model.IdentifiableEntity;

/**
 * <p>
 * This is MainframeServicesScope entity class.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safety.
 * </p>
 *
 * @author faeton, stevenfrog
 * @version 1.0
 */
public class MainframeServicesScope extends IdentifiableEntity {
    /**
     * <p>
     * The dataAnalyticsHealthcheck.
     * </p>
     */
    private boolean dataAnalyticsHealthcheck;

    /**
     * <p>
     * The ezsmEccInfoMover.
     * </p>
     */
    private boolean ezsmEccInfoMover;

    /**
     * <p>
     * The dmxVmaxDataMigration.
     * </p>
     */
    private boolean dmxVmaxDataMigration;

    /**
     * <p>
     * The dmxVmaxHardwareImplementation.
     * </p>
     */
    private boolean dmxVmaxHardwareImplementation;

    /**
     * <p>
     * The dmxVmaxSrdf.
     * </p>
     */
    private boolean dmxVmaxSrdf;

    /**
     * <p>
     * The dmxVmaxTimeFinder.
     * </p>
     */
    private boolean dmxVmaxTimeFinder;

    /**
     * <p>
     * The dmxVmaxAutoswapGddr.
     * </p>
     */
    private boolean dmxVmaxAutoswapGddr;

    /**
     * <p>
     * The dlmDataMigration.
     * </p>
     */
    private boolean dlmDataMigration;

    /**
     * <p>
     * The dlmHealthcheck.
     * </p>
     */
    private boolean dlmHealthcheck;

    /**
     * <p>
     * The dlmCustomRequirements.
     * </p>
     */
    private boolean dlmCustomRequirements;

    /**
     * <p>
     * The dlmImplementUpgrade.
     * </p>
     */
    private boolean dlmImplementUpgrade;

    /**
     * <p>
     * The dlmReconfigureAddMove.
     * </p>
     */
    private boolean dlmReconfigureAddMove;

    /**
     * <p>
     * The dlmScripting.
     * </p>
     */
    private boolean dlmScripting;

    /**
     * <p>
     * The dlmServices.
     * </p>
     */
    private boolean dlmServices;

    /**
     * <p>
     * The dlmImplementation.
     * </p>
     */
    private boolean dlmImplementation;

    /**
     * <p>
     * The default constructor.
     * </p>
     */
    public MainframeServicesScope() {
        // Empty
    }

    /**
     * <p>
     * Retrieves the dataAnalyticsHealthcheck field.
     * </p>
     *
     * @return the dataAnalyticsHealthcheck
     */
    public boolean isDataAnalyticsHealthcheck() {
        return dataAnalyticsHealthcheck;
    }

    /**
     * <p>
     * Sets the value to dataAnalyticsHealthcheck field.
     * </p>
     *
     * @param dataAnalyticsHealthcheck
     *            the dataAnalyticsHealthcheck to set
     */
    public void setDataAnalyticsHealthcheck(boolean dataAnalyticsHealthcheck) {
        this.dataAnalyticsHealthcheck = dataAnalyticsHealthcheck;
    }

    /**
     * <p>
     * Retrieves the ezsmEccInfoMover field.
     * </p>
     *
     * @return the ezsmEccInfoMover
     */
    public boolean isEzsmEccInfoMover() {
        return ezsmEccInfoMover;
    }

    /**
     * <p>
     * Sets the value to ezsmEccInfoMover field.
     * </p>
     *
     * @param ezsmEccInfoMover
     *            the ezsmEccInfoMover to set
     */
    public void setEzsmEccInfoMover(boolean ezsmEccInfoMover) {
        this.ezsmEccInfoMover = ezsmEccInfoMover;
    }

    /**
     * <p>
     * Retrieves the dmxVmaxDataMigration field.
     * </p>
     *
     * @return the dmxVmaxDataMigration
     */
    public boolean isDmxVmaxDataMigration() {
        return dmxVmaxDataMigration;
    }

    /**
     * <p>
     * Sets the value to dmxVmaxDataMigration field.
     * </p>
     *
     * @param dmxVmaxDataMigration
     *            the dmxVmaxDataMigration to set
     */
    public void setDmxVmaxDataMigration(boolean dmxVmaxDataMigration) {
        this.dmxVmaxDataMigration = dmxVmaxDataMigration;
    }

    /**
     * <p>
     * Retrieves the dmxVmaxHardwareImplementation field.
     * </p>
     *
     * @return the dmxVmaxHardwareImplementation
     */
    public boolean isDmxVmaxHardwareImplementation() {
        return dmxVmaxHardwareImplementation;
    }

    /**
     * <p>
     * Sets the value to dmxVmaxHardwareImplementation field.
     * </p>
     *
     * @param dmxVmaxHardwareImplementation
     *            the dmxVmaxHardwareImplementation to set
     */
    public void setDmxVmaxHardwareImplementation(boolean dmxVmaxHardwareImplementation) {
        this.dmxVmaxHardwareImplementation = dmxVmaxHardwareImplementation;
    }

    /**
     * <p>
     * Retrieves the dmxVmaxSrdf field.
     * </p>
     *
     * @return the dmxVmaxSrdf
     */
    public boolean isDmxVmaxSrdf() {
        return dmxVmaxSrdf;
    }

    /**
     * <p>
     * Sets the value to dmxVmaxSrdf field.
     * </p>
     *
     * @param dmxVmaxSrdf
     *            the dmxVmaxSrdf to set
     */
    public void setDmxVmaxSrdf(boolean dmxVmaxSrdf) {
        this.dmxVmaxSrdf = dmxVmaxSrdf;
    }

    /**
     * <p>
     * Retrieves the dmxVmaxTimeFinder field.
     * </p>
     *
     * @return the dmxVmaxTimeFinder
     */
    public boolean isDmxVmaxTimeFinder() {
        return dmxVmaxTimeFinder;
    }

    /**
     * <p>
     * Sets the value to dmxVmaxTimeFinder field.
     * </p>
     *
     * @param dmxVmaxTimeFinder
     *            the dmxVmaxTimeFinder to set
     */
    public void setDmxVmaxTimeFinder(boolean dmxVmaxTimeFinder) {
        this.dmxVmaxTimeFinder = dmxVmaxTimeFinder;
    }

    /**
     * <p>
     * Retrieves the dmxVmaxAutoswapGddr field.
     * </p>
     *
     * @return the dmxVmaxAutoswapGddr
     */
    public boolean isDmxVmaxAutoswapGddr() {
        return dmxVmaxAutoswapGddr;
    }

    /**
     * <p>
     * Sets the value to dmxVmaxAutoswapGddr field.
     * </p>
     *
     * @param dmxVmaxAutoswapGddr
     *            the dmxVmaxAutoswapGddr to set
     */
    public void setDmxVmaxAutoswapGddr(boolean dmxVmaxAutoswapGddr) {
        this.dmxVmaxAutoswapGddr = dmxVmaxAutoswapGddr;
    }

    /**
     * <p>
     * Retrieves the dlmDataMigration field.
     * </p>
     *
     * @return the dlmDataMigration
     */
    public boolean isDlmDataMigration() {
        return dlmDataMigration;
    }

    /**
     * <p>
     * Sets the value to dlmDataMigration field.
     * </p>
     *
     * @param dlmDataMigration
     *            the dlmDataMigration to set
     */
    public void setDlmDataMigration(boolean dlmDataMigration) {
        this.dlmDataMigration = dlmDataMigration;
    }

    /**
     * <p>
     * Retrieves the dlmHealthcheck field.
     * </p>
     *
     * @return the dlmHealthcheck
     */
    public boolean isDlmHealthcheck() {
        return dlmHealthcheck;
    }

    /**
     * <p>
     * Sets the value to dlmHealthcheck field.
     * </p>
     *
     * @param dlmHealthcheck
     *            the dlmHealthcheck to set
     */
    public void setDlmHealthcheck(boolean dlmHealthcheck) {
        this.dlmHealthcheck = dlmHealthcheck;
    }

    /**
     * <p>
     * Retrieves the dlmCustomRequirements field.
     * </p>
     *
     * @return the dlmCustomRequirements
     */
    public boolean isDlmCustomRequirements() {
        return dlmCustomRequirements;
    }

    /**
     * <p>
     * Sets the value to dlmCustomRequirements field.
     * </p>
     *
     * @param dlmCustomRequirements
     *            the dlmCustomRequirements to set
     */
    public void setDlmCustomRequirements(boolean dlmCustomRequirements) {
        this.dlmCustomRequirements = dlmCustomRequirements;
    }

    /**
     * <p>
     * Retrieves the dlmImplementUpgrade field.
     * </p>
     *
     * @return the dlmImplementUpgrade
     */
    public boolean isDlmImplementUpgrade() {
        return dlmImplementUpgrade;
    }

    /**
     * <p>
     * Sets the value to dlmImplementUpgrade field.
     * </p>
     *
     * @param dlmImplementUpgrade
     *            the dlmImplementUpgrade to set
     */
    public void setDlmImplementUpgrade(boolean dlmImplementUpgrade) {
        this.dlmImplementUpgrade = dlmImplementUpgrade;
    }

    /**
     * <p>
     * Retrieves the dlmReconfigureAddMove field.
     * </p>
     *
     * @return the dlmReconfigureAddMove
     */
    public boolean isDlmReconfigureAddMove() {
        return dlmReconfigureAddMove;
    }

    /**
     * <p>
     * Sets the value to dlmReconfigureAddMove field.
     * </p>
     *
     * @param dlmReconfigureAddMove
     *            the dlmReconfigureAddMove to set
     */
    public void setDlmReconfigureAddMove(boolean dlmReconfigureAddMove) {
        this.dlmReconfigureAddMove = dlmReconfigureAddMove;
    }

    /**
     * <p>
     * Retrieves the dlmScripting field.
     * </p>
     *
     * @return the dlmScripting
     */
    public boolean isDlmScripting() {
        return dlmScripting;
    }

    /**
     * <p>
     * Sets the value to dlmScripting field.
     * </p>
     *
     * @param dlmScripting
     *            the dlmScripting to set
     */
    public void setDlmScripting(boolean dlmScripting) {
        this.dlmScripting = dlmScripting;
    }

    /**
     * <p>
     * Retrieves the dlmServices field.
     * </p>
     *
     * @return the dlmServices
     */
    public boolean isDlmServices() {
        return dlmServices;
    }

    /**
     * <p>
     * Sets the value to dlmServices field.
     * </p>
     *
     * @param dlmServices
     *            the dlmServices to set
     */
    public void setDlmServices(boolean dlmServices) {
        this.dlmServices = dlmServices;
    }

    /**
     * <p>
     * Retrieves the dlmImplementation field.
     * </p>
     *
     * @return the dlmImplementation
     */
    public boolean isDlmImplementation() {
        return dlmImplementation;
    }

    /**
     * <p>
     * Sets the value to dlmImplementation field.
     * </p>
     *
     * @param dlmImplementation
     *            the dlmImplementation to set
     */
    public void setDlmImplementation(boolean dlmImplementation) {
        this.dlmImplementation = dlmImplementation;
    }

    /**
     * The toString method.
     *
     * @return the string for this entity
     */
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("{").append(super.toString());
        sb.append(", dataAnalyticsHealthcheck:").append(dataAnalyticsHealthcheck);
        sb.append(", ezsmEccInfoMover:").append(ezsmEccInfoMover);
        sb.append(", dmxVmaxDataMigration:").append(dmxVmaxDataMigration);
        sb.append(", dmxVmaxHardwareImplementation:").append(dmxVmaxHardwareImplementation);
        sb.append(", dmxVmaxSrdf:").append(dmxVmaxSrdf);
        sb.append(", dmxVmaxTimeFinder:").append(dmxVmaxTimeFinder);
        sb.append(", dmxVmaxAutoswapGddr:").append(dmxVmaxAutoswapGddr);
        sb.append(", dlmDataMigration:").append(dlmDataMigration);
        sb.append(", dlmHealthcheck:").append(dlmHealthcheck);
        sb.append(", dlmCustomRequirements:").append(dlmCustomRequirements);
        sb.append(", dlmImplementUpgrade:").append(dlmImplementUpgrade);
        sb.append(", dlmReconfigureAddMove:").append(dlmReconfigureAddMove);
        sb.append(", dlmScripting:").append(dlmScripting);
        sb.append(", dlmServices:").append(dlmServices);
        sb.append(", dlmImplementation:").append(dlmImplementation).append("}");
        return sb.toString();
    }
}

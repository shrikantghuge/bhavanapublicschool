/*
 * This code is copyright (c) 2014 EMC Corporation
 */
package com.emc.gs.tools.srf.model.dpad;

import com.emc.gs.tools.srf.model.LookupEntity;

/**
 * <p>This is IntelligentFabricMigrationMethod entity class.</p>
 *
 * <p><strong>Thread safety</strong>: This class is mutable, it is not thread safety.</p>
 * 
 * 
 * @author isv
 * @version 1.0 (SRT 4 OCT2014 Updates Part 2)
 */
public class IntelligentFabricMigrationMethod extends LookupEntity {

    /**
     * <p>Constructs new <code>IntelligentFabricMigrationMethod</code> instance. This implementation does nothing.</p>
     */
    public IntelligentFabricMigrationMethod() {
    }
}

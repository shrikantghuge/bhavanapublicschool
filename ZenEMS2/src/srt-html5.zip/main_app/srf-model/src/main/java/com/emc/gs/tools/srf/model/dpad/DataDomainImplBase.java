/*
 * This code is copyright (c) 2014 EMC Corporation
 */
package com.emc.gs.tools.srf.model.dpad;

import com.emc.gs.tools.srf.model.IdentifiableEntity;

/**
 * <p>
 * This is DataDomainImplBase entity class.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safety.
 * </p>
 * 
 * @author TCSASSEMBLER
 * @version 1.0
 * @since SRT Phase 3-5 - BRS Tabs Part 2 Assembly
 */
public abstract class DataDomainImplBase extends IdentifiableEntity {

    /**
     * Select the backup application server for DD Boost Configuration.
     */
    private DataDomainBoostBackupServer boostBackupServer;

    /**
     * Integration with SAP HANA Studio?
     */
    private Boolean integrateSapHana;

    /**
     * Select to plan,design,and implement VTL?
     */
    private Boolean planDesignImplementVTL;

    /**
     * Include IBM iSeries BRMS Integration.
     */
    private Boolean includeIBMiseriesBRMS;

    /**
     * # of IBM i PARs for Backup Configuration.
     */
    private Integer ibmPARsNum;

    /**
     * # of Data Domain Appliances for VTL.
     */
    private Integer vtlAppliancesNum;

    /**
     * # of Data Domain Fibre Cards to install.
     */
    private Integer installFibreCardsNum;

    /**
     * # of Data Domain Emulated VTLs to Create.
     */
    private Integer createVTLsNum;

    /**
     * # of backup servers(includes storage nodes/media servers).
     */
    private Integer backupServersNum;

    /**
     * # of Data Domain Appliances for DD Boost Implementation.
     */
    private Integer appliancesForDDBoostNum;

    /**
     * # of Oracle Database Servers for RMAN Backup.
     */
    private Integer oracleRMANBackupServersNum;

    /**
     * # of Oracle Databases for Backup Configuration.
     */
    private Integer oracleBackupConfigServersNum;

    /**
     * # of SAP Hana Database Targeted for Backup.
     */
    private Integer sapHanaDatabasesNum;

    /**
     * <p>
     * The default constructor.
     * </p>
     */
    protected DataDomainImplBase() {
    }

    /**
     * Getter method for property <tt>boostBackupServer</tt>.
     * 
     * @return property value of boostBackupServer
     */
    public DataDomainBoostBackupServer getBoostBackupServer() {
        return boostBackupServer;
    }

    /**
     * Setter method for property <tt>boostBackupServer</tt>.
     * 
     * @param boostBackupServer
     *            value to be assigned to property boostBackupServer
     */
    public void setBoostBackupServer(DataDomainBoostBackupServer boostBackupServer) {
        this.boostBackupServer = boostBackupServer;
    }

    /**
     * Getter method for property <tt>integrateSapHana</tt>.
     * 
     * @return property value of integrateSapHana
     */
    public Boolean getIntegrateSapHana() {
        return integrateSapHana;
    }

    /**
     * Setter method for property <tt>integrateSapHana</tt>.
     * 
     * @param integrateSapHana
     *            value to be assigned to property integrateSapHana
     */
    public void setIntegrateSapHana(Boolean integrateSapHana) {
        this.integrateSapHana = integrateSapHana;
    }

    /**
     * Getter method for property <tt>planDesignImplementVTL</tt>.
     * 
     * @return property value of planDesignImplementVTL
     */
    public Boolean getPlanDesignImplementVTL() {
        return planDesignImplementVTL;
    }

    /**
     * Setter method for property <tt>planDesignImplementVTL</tt>.
     * 
     * @param planDesignImplementVTL
     *            value to be assigned to property planDesignImplementVTL
     */
    public void setPlanDesignImplementVTL(Boolean planDesignImplementVTL) {
        this.planDesignImplementVTL = planDesignImplementVTL;
    }

    /**
     * Getter method for property <tt>includeIBMiseriesBRMS</tt>.
     * 
     * @return property value of includeIBMiseriesBRMS
     */
    public Boolean getIncludeIBMiseriesBRMS() {
        return includeIBMiseriesBRMS;
    }

    /**
     * Setter method for property <tt>includeIBMiseriesBRMS</tt>.
     * 
     * @param includeIBMiseriesBRMS
     *            value to be assigned to property includeIBMiseriesBRMS
     */
    public void setIncludeIBMiseriesBRMS(Boolean includeIBMiseriesBRMS) {
        this.includeIBMiseriesBRMS = includeIBMiseriesBRMS;
    }

    /**
     * Getter method for property <tt>ibmPARsNum</tt>.
     * 
     * @return property value of ibmPARsNum
     */
    public Integer getIbmPARsNum() {
        return ibmPARsNum;
    }

    /**
     * Setter method for property <tt>ibmPARsNum</tt>.
     * 
     * @param ibmPARsNum
     *            value to be assigned to property ibmPARsNum
     */
    public void setIbmPARsNum(Integer ibmPARsNum) {
        this.ibmPARsNum = ibmPARsNum;
    }

    /**
     * Getter method for property <tt>vtlAppliancesNum</tt>.
     * 
     * @return property value of vtlAppliancesNum
     */
    public Integer getVtlAppliancesNum() {
        return vtlAppliancesNum;
    }

    /**
     * Setter method for property <tt>vtlAppliancesNum</tt>.
     * 
     * @param vtlAppliancesNum
     *            value to be assigned to property vtlAppliancesNum
     */
    public void setVtlAppliancesNum(Integer vtlAppliancesNum) {
        this.vtlAppliancesNum = vtlAppliancesNum;
    }

    /**
     * Getter method for property <tt>installFibreCardsNum</tt>.
     * 
     * @return property value of installFibreCardsNum
     */
    public Integer getInstallFibreCardsNum() {
        return installFibreCardsNum;
    }

    /**
     * Setter method for property <tt>installFibreCardsNum</tt>.
     * 
     * @param installFibreCardsNum
     *            value to be assigned to property installFibreCardsNum
     */
    public void setInstallFibreCardsNum(Integer installFibreCardsNum) {
        this.installFibreCardsNum = installFibreCardsNum;
    }

    /**
     * Getter method for property <tt>createVTLsNum</tt>.
     * 
     * @return property value of createVTLsNum
     */
    public Integer getCreateVTLsNum() {
        return createVTLsNum;
    }

    /**
     * Setter method for property <tt>createVTLsNum</tt>.
     * 
     * @param createVTLsNum
     *            value to be assigned to property createVTLsNum
     */
    public void setCreateVTLsNum(Integer createVTLsNum) {
        this.createVTLsNum = createVTLsNum;
    }

    /**
     * Getter method for property <tt>backupServersNum</tt>.
     * 
     * @return property value of backupServersNum
     */
    public Integer getBackupServersNum() {
        return backupServersNum;
    }

    /**
     * Setter method for property <tt>backupServersNum</tt>.
     * 
     * @param backupServersNum
     *            value to be assigned to property backupServersNum
     */
    public void setBackupServersNum(Integer backupServersNum) {
        this.backupServersNum = backupServersNum;
    }

    /**
     * Getter method for property <tt>appliancesForDDBoostNum</tt>.
     * 
     * @return property value of appliancesForDDBoostNum
     */
    public Integer getAppliancesForDDBoostNum() {
        return appliancesForDDBoostNum;
    }

    /**
     * Setter method for property <tt>appliancesForDDBoostNum</tt>.
     * 
     * @param appliancesForDDBoostNum
     *            value to be assigned to property appliancesForDDBoostNum
     */
    public void setAppliancesForDDBoostNum(Integer appliancesForDDBoostNum) {
        this.appliancesForDDBoostNum = appliancesForDDBoostNum;
    }

    /**
     * Getter method for property <tt>oracleRMANBackupServersNum</tt>.
     * 
     * @return property value of oracleRMANBackupServersNum
     */
    public Integer getOracleRMANBackupServersNum() {
        return oracleRMANBackupServersNum;
    }

    /**
     * Setter method for property <tt>oracleRMANBackupServersNum</tt>.
     * 
     * @param oracleRMANBackupServersNum
     *            value to be assigned to property oracleRMANBackupServersNum
     */
    public void setOracleRMANBackupServersNum(Integer oracleRMANBackupServersNum) {
        this.oracleRMANBackupServersNum = oracleRMANBackupServersNum;
    }

    /**
     * Getter method for property <tt>oracleBackupConfigServersNum</tt>.
     * 
     * @return property value of oracleBackupConfigServersNum
     */
    public Integer getOracleBackupConfigServersNum() {
        return oracleBackupConfigServersNum;
    }

    /**
     * Setter method for property <tt>oracleBackupConfigServersNum</tt>.
     * 
     * @param oracleBackupConfigServersNum
     *            value to be assigned to property oracleBackupConfigServersNum
     */
    public void setOracleBackupConfigServersNum(Integer oracleBackupConfigServersNum) {
        this.oracleBackupConfigServersNum = oracleBackupConfigServersNum;
    }

    /**
     * Getter method for property <tt>sapHanaDatabasesNum</tt>.
     * 
     * @return property value of sapHanaDatabasesNum
     */
    public Integer getSapHanaDatabasesNum() {
        return sapHanaDatabasesNum;
    }

    /**
     * Setter method for property <tt>sapHanaDatabasesNum</tt>.
     * 
     * @param sapHanaDatabasesNum
     *            value to be assigned to property sapHanaDatabasesNum
     */
    public void setSapHanaDatabasesNum(Integer sapHanaDatabasesNum) {
        this.sapHanaDatabasesNum = sapHanaDatabasesNum;
    }

}

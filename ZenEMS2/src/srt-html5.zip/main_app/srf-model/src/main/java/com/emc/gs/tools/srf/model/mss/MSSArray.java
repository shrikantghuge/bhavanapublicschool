/*
 * This code is copyright (c) 2014 EMC Corporation
 */
package com.emc.gs.tools.srf.model.mss;

import com.emc.gs.tools.srf.model.IdentifiableEntity;

/**
 * <p>
 * This is MSSArray entity class.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safe.
 * </p>
 * <p>
 * <strong>Changes V1.1:</strong> <strong>SRT Phase 3-1 - CTA Rainfinity and MSS Tabs Update Assembly</strong>
 * <ul>
 * <li>Add atmos/greenplum fields.</li>
 * </ul>
 * </p>
 * 
 * @author TCSASSEMBLER
 * @version 1.1
 * @since SRT Phase 3-1 - CTA Rainfinity and MSS Tabs Assembly
 */
public class MSSArray extends IdentifiableEntity {

    /**
     * Location.
     */
    private String location;

    /**
     * Service.
     */
    private MSSService service;

    /**
     * Platform.
     */
    private MSSPlatform platform;

    /**
     * FC / ATA Drives.
     */
    private MSSFcAtaDrives fcAtaDrives;

    /**
     * Flash Drives.
     */
    private MSSFlashDrives flashDrives;

    /**
     * VNX SAS Drives.
     */
    private MSSVnxSasDrives vnxSasDrives;

    /**
     * CLARiiON AX4 Drives.
     */
    private MSSClariionAx4Drives clariionAx4Drives;

    /**
     * Centera Nodes.
     */
    private MSSCenteraNodes centeraNodes;

    /**
     * Avamar Nodes.
     */
    private MSSAvamarNodes avamarNodes;

    /**
     * ATMOS.
     */
    private MSSAtmos atmos;

    /**
     * Data Domain.
     */
    private MSSDataDomain dataDomain;

    /**
     * GREENPLUM.
     */
    private MSSGreenplum greenplum;

    /**
     * <p>
     * The default constructor.
     * </p>
     */
    public MSSArray() {
    }

    /**
     * Getter method for property <tt>location</tt>.
     * 
     * @return property value of location
     */
    public String getLocation() {
        return location;
    }

    /**
     * Setter method for property <tt>location</tt>.
     * 
     * @param location
     *            value to be assigned to property location
     */
    public void setLocation(String location) {
        this.location = location;
    }

    /**
     * Getter method for property <tt>service</tt>.
     * 
     * @return property value of service
     */
    public MSSService getService() {
        return service;
    }

    /**
     * Setter method for property <tt>service</tt>.
     * 
     * @param service
     *            value to be assigned to property service
     */
    public void setService(MSSService service) {
        this.service = service;
    }

    /**
     * Getter method for property <tt>platform</tt>.
     * 
     * @return property value of platform
     */
    public MSSPlatform getPlatform() {
        return platform;
    }

    /**
     * Setter method for property <tt>platform</tt>.
     * 
     * @param platform
     *            value to be assigned to property platform
     */
    public void setPlatform(MSSPlatform platform) {
        this.platform = platform;
    }

    /**
     * Getter method for property <tt>fcAtaDrives</tt>.
     * 
     * @return property value of fcAtaDrives
     */
    public MSSFcAtaDrives getFcAtaDrives() {
        return fcAtaDrives;
    }

    /**
     * Setter method for property <tt>fcAtaDrives</tt>.
     * 
     * @param fcAtaDrives
     *            value to be assigned to property fcAtaDrives
     */
    public void setFcAtaDrives(MSSFcAtaDrives fcAtaDrives) {
        this.fcAtaDrives = fcAtaDrives;
    }

    /**
     * Getter method for property <tt>flashDrives</tt>.
     * 
     * @return property value of flashDrives
     */
    public MSSFlashDrives getFlashDrives() {
        return flashDrives;
    }

    /**
     * Setter method for property <tt>flashDrives</tt>.
     * 
     * @param flashDrives
     *            value to be assigned to property flashDrives
     */
    public void setFlashDrives(MSSFlashDrives flashDrives) {
        this.flashDrives = flashDrives;
    }

    /**
     * Getter method for property <tt>vnxSasDrives</tt>.
     * 
     * @return property value of vnxSasDrives
     */
    public MSSVnxSasDrives getVnxSasDrives() {
        return vnxSasDrives;
    }

    /**
     * Setter method for property <tt>vnxSasDrives</tt>.
     * 
     * @param vnxSasDrives
     *            value to be assigned to property vnxSasDrives
     */
    public void setVnxSasDrives(MSSVnxSasDrives vnxSasDrives) {
        this.vnxSasDrives = vnxSasDrives;
    }

    /**
     * Getter method for property <tt>clariionAx4Drives</tt>.
     * 
     * @return property value of clariionAx4Drives
     */
    public MSSClariionAx4Drives getClariionAx4Drives() {
        return clariionAx4Drives;
    }

    /**
     * Setter method for property <tt>clariionAx4Drives</tt>.
     * 
     * @param clariionAx4Drives
     *            value to be assigned to property clariionAx4Drives
     */
    public void setClariionAx4Drives(MSSClariionAx4Drives clariionAx4Drives) {
        this.clariionAx4Drives = clariionAx4Drives;
    }

    /**
     * Getter method for property <tt>centeraNodes</tt>.
     * 
     * @return property value of centeraNodes
     */
    public MSSCenteraNodes getCenteraNodes() {
        return centeraNodes;
    }

    /**
     * Setter method for property <tt>centeraNodes</tt>.
     * 
     * @param centeraNodes
     *            value to be assigned to property centeraNodes
     */
    public void setCenteraNodes(MSSCenteraNodes centeraNodes) {
        this.centeraNodes = centeraNodes;
    }

    /**
     * Getter method for property <tt>avamarNodes</tt>.
     * 
     * @return property value of avamarNodes
     */
    public MSSAvamarNodes getAvamarNodes() {
        return avamarNodes;
    }

    /**
     * Setter method for property <tt>avamarNodes</tt>.
     * 
     * @param avamarNodes
     *            value to be assigned to property avamarNodes
     */
    public void setAvamarNodes(MSSAvamarNodes avamarNodes) {
        this.avamarNodes = avamarNodes;
    }

    /**
     * Getter method for property <tt>atmos</tt>.
     * 
     * @return property value of atmos
     */
    public MSSAtmos getAtmos() {
        return atmos;
    }

    /**
     * Setter method for property <tt>atmos</tt>.
     * 
     * @param atmos
     *            value to be assigned to property atmos
     */
    public void setAtmos(MSSAtmos atmos) {
        this.atmos = atmos;
    }

    /**
     * Getter method for property <tt>dataDomain</tt>.
     * 
     * @return property value of dataDomain
     */
    public MSSDataDomain getDataDomain() {
        return dataDomain;
    }

    /**
     * Setter method for property <tt>dataDomain</tt>.
     * 
     * @param dataDomain
     *            value to be assigned to property dataDomain
     */
    public void setDataDomain(MSSDataDomain dataDomain) {
        this.dataDomain = dataDomain;
    }

    /**
     * Getter method for property <tt>greenplum</tt>.
     * 
     * @return property value of greenplum
     */
    public MSSGreenplum getGreenplum() {
        return greenplum;
    }

    /**
     * Setter method for property <tt>greenplum</tt>.
     * 
     * @param greenplum
     *            value to be assigned to property greenplum
     */
    public void setGreenplum(MSSGreenplum greenplum) {
        this.greenplum = greenplum;
    }
}

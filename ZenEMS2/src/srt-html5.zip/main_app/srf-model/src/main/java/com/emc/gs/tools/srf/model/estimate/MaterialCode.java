/*
 * This code is copyright (c) 2014 EMC Corporation.
 */
package com.emc.gs.tools.srf.model.estimate;

import com.emc.gs.tools.srf.model.LookupCodeEntity;

/**
 * <p>
 * This is MaterialCode entity class.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safety.
 * </p>
 * 
 * <p>
 * <strong>Changes V1.1:</strong>
 * <strong>SRT 1.1 DEC 2014 Updates Assembly</strong>
 * <ul>
 * <li>Added expenseModel field.</li>
 * </ul>
 * </p>
 *
 * <p>
 * Version 1.2 Change notes:
 *   <ol>
 *     <li>Added {@link #discountFloors} property.</li>
 *   </ol>
 * </p>
 * 
 * @author TCSASSEMBLER, MonicaMuranyi, isv
 * @version 1.2
 * @since SRT Phase 4 - ET Assembly 1
 */
public class MaterialCode extends LookupCodeEntity {

    /**
     * The LOB id this material code belongs to.
     */
    private long lobId;
    
    /**
     * The expense model.
     */
    private String expenseModel;

    /**
     * <p>A <code>DiscountFloorGroup</code> providing the value for discountFloors property.</p>
     * 
     * @since 1.2
     */
    private DiscountFloorGroup discountFloors;

    /**
     * Empty constructor.
     */
    public MaterialCode() {
    }

    /**
     * Getter method for property <tt>lobId</tt>.
     * 
     * @return property value of lobId
     */
    public long getLobId() {
        return lobId;
    }

    /**
     * Setter method for property <tt>lobId</tt>.
     * 
     * @param lobId
     *            value to be assigned to property lobId
     */
    public void setLobId(long lobId) {
        this.lobId = lobId;
    }

    /**
     * Getter method for property <tt>expenseModel</tt>.
     * 
     * @return property value of expenseModel
     */
    public String getExpenseModel() {
        return expenseModel;
    }

    /**
     * Setter method for property <tt>expenseModel</tt>.
     * 
     * @param expenseModel
     *            value to be assigned to property expenseModel
     */
    public void setExpenseModel(String expenseModel) {
        this.expenseModel = expenseModel;
    }

    /**
     * <p>Gets the discountFloors property.</p>
     *
     * @return a <code>DiscountFloorGroup</code> providing the value for discountFloors property.
     * @since 1.2
     */
    public DiscountFloorGroup getDiscountFloors() {
        return this.discountFloors;
    }

    /**
     * <p>Sets the discountFloors property.</p>
     *
     * @param discountFloors a <code>DiscountFloorGroup</code> providing the value for discountFloors property.
     * @since 1.2
     */
    public void setDiscountFloors(DiscountFloorGroup discountFloors) {
        this.discountFloors = discountFloors;
    }
}

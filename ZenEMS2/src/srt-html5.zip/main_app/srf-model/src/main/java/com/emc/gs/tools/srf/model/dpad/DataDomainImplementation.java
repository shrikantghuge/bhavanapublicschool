/*
 * This code is copyright (c) 2014 EMC Corporation
 */
package com.emc.gs.tools.srf.model.dpad;

import java.util.Map;

/**
 * <p>
 * This is DataDomainImplementation entity class.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safety.
 * </p>
 * 
 * @author TCSASSEMBLER
 * @version 1.0
 * @since SRT Phase 3-5 - BRS Tabs Part 2 Assembly
 */
public class DataDomainImplementation extends DataDomainImplBase {

    /**
     * Data Domain Appliance Models that are part of the engagement.
     */
    private Map<String, DataDomainImplApplianceModel> applianceModels;

    /**
     * <p>
     * The default constructor.
     * </p>
     */
    public DataDomainImplementation() {
    }

    /**
     * Getter method for property <tt>applianceModels</tt>.
     * 
     * @return property value of applianceModels
     */
    public Map<String, DataDomainImplApplianceModel> getApplianceModels() {
        return applianceModels;
    }

    /**
     * Setter method for property <tt>applianceModels</tt>.
     * 
     * @param applianceModels
     *            value to be assigned to property applianceModels
     */
    public void setApplianceModels(Map<String, DataDomainImplApplianceModel> applianceModels) {
        this.applianceModels = applianceModels;
    }

}

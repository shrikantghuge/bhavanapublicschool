/*
 * This code is copyright (c) 2014 EMC Corporation
 */
package com.emc.gs.tools.srf.model.atmos;

import com.emc.gs.tools.srf.model.IdentifiableEntity;

/**
 * <p>
 * This is CenteraToAtmosMigration entity class.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safety.
 * </p>
 * 
 * @author TCSASSEMBLER
 * @version 1.0
 * @since SRT Phase 3-1 - Atmos Centera and Vblock Tabs Assembly
 */
public class CenteraToAtmosMigration extends IdentifiableEntity {

    /**
     * # of applications to be migrated to Atmos.
     */
    private Integer applicationsNum;

    /**
     * Choose Centera Protection Type.
     */
    private CenteraProtectionType protectionType;

    /**
     * Amount of data (in TB) to be migrated to Atmos.
     */
    private Integer dataAmount;

    /**
     * <p>
     * The default constructor.
     * </p>
     */
    public CenteraToAtmosMigration() {
    }

    /**
     * Getter method for property <tt>applicationsNum</tt>.
     * 
     * @return property value of applicationsNum
     */
    public Integer getApplicationsNum() {
        return applicationsNum;
    }

    /**
     * Setter method for property <tt>applicationsNum</tt>.
     * 
     * @param applicationsNum
     *            value to be assigned to property applicationsNum
     */
    public void setApplicationsNum(Integer applicationsNum) {
        this.applicationsNum = applicationsNum;
    }

    /**
     * Getter method for property <tt>protectionType</tt>.
     * 
     * @return property value of protectionType
     */
    public CenteraProtectionType getProtectionType() {
        return protectionType;
    }

    /**
     * Setter method for property <tt>protectionType</tt>.
     * 
     * @param protectionType
     *            value to be assigned to property protectionType
     */
    public void setProtectionType(CenteraProtectionType protectionType) {
        this.protectionType = protectionType;
    }

    /**
     * Getter method for property <tt>dataAmount</tt>.
     * 
     * @return property value of dataAmount
     */
    public Integer getDataAmount() {
        return dataAmount;
    }

    /**
     * Setter method for property <tt>dataAmount</tt>.
     * 
     * @param dataAmount
     *            value to be assigned to property dataAmount
     */
    public void setDataAmount(Integer dataAmount) {
        this.dataAmount = dataAmount;
    }

}

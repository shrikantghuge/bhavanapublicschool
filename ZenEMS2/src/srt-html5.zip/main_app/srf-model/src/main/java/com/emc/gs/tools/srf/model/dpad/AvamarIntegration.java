/*
 * This code is copyright (c) 2014 EMC Corporation
 */
package com.emc.gs.tools.srf.model.dpad;

import com.emc.gs.tools.srf.model.IdentifiableEntity;

/**
 * <p>
 * This is AvamarIntegration entity class.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safety.
 * </p>
 * 
 * @author TCSASSEMBLER
 * @version 1.0
 * @since SRT Phase 3-5 - BRS Tabs Part 1 Assembly
 */
public class AvamarIntegration extends IdentifiableEntity {

    /**
     * Design Workshop?
     */
    private Boolean workshop;

    /**
     * Pilot?
     */
    private Boolean pilot;

    /**
     * # of Avamar Desktop / Laptop Clients.
     */
    private Integer clientsNum;

    /**
     * # of Clients to be Configured as part of the Avamar Desktop/Laptop Pilot Rollout.
     */
    private Integer configuredClientsNum;

    /**
     * Will the DTLT Clients be activated by Batch Script?
     */
    private Boolean dtltClientsActivated;

    /**
     * # of Avamar Grids.
     */
    private Integer gridsNum;

    /**
     * <p>
     * The default constructor.
     * </p>
     */
    public AvamarIntegration() {
    }

    /**
     * Getter method for property <tt>workshop</tt>.
     * 
     * @return property value of workshop
     */
    public Boolean getWorkshop() {
        return workshop;
    }

    /**
     * Setter method for property <tt>workshop</tt>.
     * 
     * @param workshop
     *            value to be assigned to property workshop
     */
    public void setWorkshop(Boolean workshop) {
        this.workshop = workshop;
    }

    /**
     * Getter method for property <tt>pilot</tt>.
     * 
     * @return property value of pilot
     */
    public Boolean getPilot() {
        return pilot;
    }

    /**
     * Setter method for property <tt>pilot</tt>.
     * 
     * @param pilot
     *            value to be assigned to property pilot
     */
    public void setPilot(Boolean pilot) {
        this.pilot = pilot;
    }

    /**
     * Getter method for property <tt>clientsNum</tt>.
     * 
     * @return property value of clientsNum
     */
    public Integer getClientsNum() {
        return clientsNum;
    }

    /**
     * Setter method for property <tt>clientsNum</tt>.
     * 
     * @param clientsNum
     *            value to be assigned to property clientsNum
     */
    public void setClientsNum(Integer clientsNum) {
        this.clientsNum = clientsNum;
    }

    /**
     * Getter method for property <tt>configuredClientsNum</tt>.
     * 
     * @return property value of configuredClientsNum
     */
    public Integer getConfiguredClientsNum() {
        return configuredClientsNum;
    }

    /**
     * Setter method for property <tt>configuredClientsNum</tt>.
     * 
     * @param configuredClientsNum
     *            value to be assigned to property configuredClientsNum
     */
    public void setConfiguredClientsNum(Integer configuredClientsNum) {
        this.configuredClientsNum = configuredClientsNum;
    }

    /**
     * Getter method for property <tt>dtltClientsActivated</tt>.
     * 
     * @return property value of dtltClientsActivated
     */
    public Boolean getDtltClientsActivated() {
        return dtltClientsActivated;
    }

    /**
     * Setter method for property <tt>dtltClientsActivated</tt>.
     * 
     * @param dtltClientsActivated
     *            value to be assigned to property dtltClientsActivated
     */
    public void setDtltClientsActivated(Boolean dtltClientsActivated) {
        this.dtltClientsActivated = dtltClientsActivated;
    }

    /**
     * Getter method for property <tt>gridsNum</tt>.
     * 
     * @return property value of gridsNum
     */
    public Integer getGridsNum() {
        return gridsNum;
    }

    /**
     * Setter method for property <tt>gridsNum</tt>.
     * 
     * @param gridsNum
     *            value to be assigned to property gridsNum
     */
    public void setGridsNum(Integer gridsNum) {
        this.gridsNum = gridsNum;
    }

}

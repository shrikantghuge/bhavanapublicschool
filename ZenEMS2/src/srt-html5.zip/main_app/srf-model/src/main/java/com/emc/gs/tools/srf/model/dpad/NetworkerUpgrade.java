/*
 * This code is copyright (c) 2014 EMC Corporation
 */
package com.emc.gs.tools.srf.model.dpad;

import com.emc.gs.tools.srf.model.IdentifiableEntity;

/**
 * <p>
 * This is NetworkerUpgrade entity class.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safety.
 * </p>
 * 
 * @author TCSASSEMBLER
 * @version 1.0
 * @since SRT Phase 3-5 - BRS Tabs Part 3 Assembly
 */
public class NetworkerUpgrade extends IdentifiableEntity {

    /**
     * Represents whether "Networker Server" component is selected.
     */
    private boolean server;

    /**
     * Represents whether "Networker Storage Nodes" component is selected.
     */
    private boolean storageNodes;

    /**
     * Represents whether "Networker Clients" component is selected.
     */
    private boolean clients;

    /**
     * Represents whether "Networker Management Console" component is selected.
     */
    private boolean managementConsole;

    /**
     * Select the Current Networker Version.
     */
    private NetworkerCurrentVersion currentVersion;

    /**
     * Select the Networker Version to Upgrade to.
     */
    private NetworkerUpgradeVersion upgradeVersion;

    /**
     * Will the Networker Server Be Upgraded to New Hardware?
     */
    private Boolean upgradeToNewHardware;

    /**
     * # of Networker Servers to Be Upgraded.
     */
    private Integer serversNum;

    /**
     * # of Networker Storage Nodes to Be Upgraded.
     */
    private Integer storageNodesNum;

    /**
     * # of Networker Clients to Be Upgraded.
     */
    private Integer clientsNum;

    /**
     * # of Networker Management Consoles to Be Upgraded.
     */
    private Integer managementConsolesNum;

    /**
     * <p>
     * The default constructor.
     * </p>
     */
    public NetworkerUpgrade() {
    }

    /**
     * Getter method for property <tt>server</tt>.
     * 
     * @return property value of server
     */
    public boolean isServer() {
        return server;
    }

    /**
     * Setter method for property <tt>server</tt>.
     * 
     * @param server
     *            value to be assigned to property server
     */
    public void setServer(boolean server) {
        this.server = server;
    }

    /**
     * Getter method for property <tt>storageNodes</tt>.
     * 
     * @return property value of storageNodes
     */
    public boolean isStorageNodes() {
        return storageNodes;
    }

    /**
     * Setter method for property <tt>storageNodes</tt>.
     * 
     * @param storageNodes
     *            value to be assigned to property storageNodes
     */
    public void setStorageNodes(boolean storageNodes) {
        this.storageNodes = storageNodes;
    }

    /**
     * Getter method for property <tt>clients</tt>.
     * 
     * @return property value of clients
     */
    public boolean isClients() {
        return clients;
    }

    /**
     * Setter method for property <tt>clients</tt>.
     * 
     * @param clients
     *            value to be assigned to property clients
     */
    public void setClients(boolean clients) {
        this.clients = clients;
    }

    /**
     * Getter method for property <tt>managementConsole</tt>.
     * 
     * @return property value of managementConsole
     */
    public boolean isManagementConsole() {
        return managementConsole;
    }

    /**
     * Setter method for property <tt>managementConsole</tt>.
     * 
     * @param managementConsole
     *            value to be assigned to property managementConsole
     */
    public void setManagementConsole(boolean managementConsole) {
        this.managementConsole = managementConsole;
    }

    /**
     * Getter method for property <tt>currentVersion</tt>.
     * 
     * @return property value of currentVersion
     */
    public NetworkerCurrentVersion getCurrentVersion() {
        return currentVersion;
    }

    /**
     * Setter method for property <tt>currentVersion</tt>.
     * 
     * @param currentVersion
     *            value to be assigned to property currentVersion
     */
    public void setCurrentVersion(NetworkerCurrentVersion currentVersion) {
        this.currentVersion = currentVersion;
    }

    /**
     * Getter method for property <tt>upgradeVersion</tt>.
     * 
     * @return property value of upgradeVersion
     */
    public NetworkerUpgradeVersion getUpgradeVersion() {
        return upgradeVersion;
    }

    /**
     * Setter method for property <tt>upgradeVersion</tt>.
     * 
     * @param upgradeVersion
     *            value to be assigned to property upgradeVersion
     */
    public void setUpgradeVersion(NetworkerUpgradeVersion upgradeVersion) {
        this.upgradeVersion = upgradeVersion;
    }

    /**
     * Getter method for property <tt>upgradeToNewHardware</tt>.
     * 
     * @return property value of upgradeToNewHardware
     */
    public Boolean getUpgradeToNewHardware() {
        return upgradeToNewHardware;
    }

    /**
     * Setter method for property <tt>upgradeToNewHardware</tt>.
     * 
     * @param upgradeToNewHardware
     *            value to be assigned to property upgradeToNewHardware
     */
    public void setUpgradeToNewHardware(Boolean upgradeToNewHardware) {
        this.upgradeToNewHardware = upgradeToNewHardware;
    }

    /**
     * Getter method for property <tt>serversNum</tt>.
     * 
     * @return property value of serversNum
     */
    public Integer getServersNum() {
        return serversNum;
    }

    /**
     * Setter method for property <tt>serversNum</tt>.
     * 
     * @param serversNum
     *            value to be assigned to property serversNum
     */
    public void setServersNum(Integer serversNum) {
        this.serversNum = serversNum;
    }

    /**
     * Getter method for property <tt>storageNodesNum</tt>.
     * 
     * @return property value of storageNodesNum
     */
    public Integer getStorageNodesNum() {
        return storageNodesNum;
    }

    /**
     * Setter method for property <tt>storageNodesNum</tt>.
     * 
     * @param storageNodesNum
     *            value to be assigned to property storageNodesNum
     */
    public void setStorageNodesNum(Integer storageNodesNum) {
        this.storageNodesNum = storageNodesNum;
    }

    /**
     * Getter method for property <tt>clientsNum</tt>.
     * 
     * @return property value of clientsNum
     */
    public Integer getClientsNum() {
        return clientsNum;
    }

    /**
     * Setter method for property <tt>clientsNum</tt>.
     * 
     * @param clientsNum
     *            value to be assigned to property clientsNum
     */
    public void setClientsNum(Integer clientsNum) {
        this.clientsNum = clientsNum;
    }

    /**
     * Getter method for property <tt>managementConsolesNum</tt>.
     * 
     * @return property value of managementConsolesNum
     */
    public Integer getManagementConsolesNum() {
        return managementConsolesNum;
    }

    /**
     * Setter method for property <tt>managementConsolesNum</tt>.
     * 
     * @param managementConsolesNum
     *            value to be assigned to property managementConsolesNum
     */
    public void setManagementConsolesNum(Integer managementConsolesNum) {
        this.managementConsolesNum = managementConsolesNum;
    }

}

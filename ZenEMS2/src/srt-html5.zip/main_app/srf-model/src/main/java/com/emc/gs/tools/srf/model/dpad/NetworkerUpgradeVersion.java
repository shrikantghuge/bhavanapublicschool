/*
 * This code is copyright (c) 2014 EMC Corporation
 */
package com.emc.gs.tools.srf.model.dpad;

/**
 * The networker upgrade version enum.
 * <p>
 * <strong>Thread safety</strong>: Enum is thread safety.
 * </p>
 * 
 * @author TCSASSEMBLER
 * @version 1.0
 * @since SRT Phase 3-5 - BRS Tabs Part 3 Assembly
 */
public enum NetworkerUpgradeVersion {

    /**
     * Networker 8.0.
     */
    NETWORKER_8_0("Networker 8.0"),

    /**
     * Networker 8.1.
     */
    NETWORKER_8_1("Networker 8.1");

    /**
     * The description.
     */
    private final String description;

    /**
     * <p>
     * The constructor with description.
     * </p>
     * 
     * @param description
     *            the description
     */
    private NetworkerUpgradeVersion(String description) {
        this.description = description;
    }

    /**
     * Override the toString method.
     * 
     * @return the description
     */
    @Override
    public String toString() {
        return description;
    }

}

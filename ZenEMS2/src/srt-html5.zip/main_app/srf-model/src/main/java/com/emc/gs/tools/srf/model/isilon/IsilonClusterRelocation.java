/*
 * This code is copyright (c) 2014 EMC Corporation
 */
package com.emc.gs.tools.srf.model.isilon;

import com.emc.gs.tools.srf.model.IdentifiableEntity;

/**
 * <p>
 * This is IsilonClusterRelocation entity class.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safety.
 * </p>
 * 
 * @author TCSASSEMBLER
 * @version 1.0
 * @since SRT Phase 3-3 - Implement Isilon and ViPR Tabs Assembly
 */
public class IsilonClusterRelocation extends IdentifiableEntity {

    /**
     * # of 1-2U Isilon Servers to Install.
     */
    private Integer isilon12UServersNum;

    /**
     * # of Isilon 4U Servers to Install.
     */
    private Integer isilon4UServersNum;

    /**
     * # of 1U Infiniband Switches to Install.
     */
    private Integer infinibandSwitchesNum;

    /**
     * # of Isilon Infiniband Chassis to install(Non-1U Switches).
     */
    private Integer infinibandChassisNum;

    /**
     * <p>
     * The default constructor.
     * </p>
     */
    public IsilonClusterRelocation() {
    }

    /**
     * Getter method for property <tt>isilon12UServersNum</tt>.
     * 
     * @return property value of isilon12UServersNum
     */
    public Integer getIsilon12UServersNum() {
        return isilon12UServersNum;
    }

    /**
     * Setter method for property <tt>isilon12UServersNum</tt>.
     * 
     * @param isilon12UServersNum
     *            value to be assigned to property isilon12UServersNum
     */
    public void setIsilon12UServersNum(Integer isilon12uServersNum) {
        isilon12UServersNum = isilon12uServersNum;
    }

    /**
     * Getter method for property <tt>isilon4UServersNum</tt>.
     * 
     * @return property value of isilon4UServersNum
     */
    public Integer getIsilon4UServersNum() {
        return isilon4UServersNum;
    }

    /**
     * Setter method for property <tt>isilon4UServersNum</tt>.
     * 
     * @param isilon4UServersNum
     *            value to be assigned to property isilon4UServersNum
     */
    public void setIsilon4UServersNum(Integer isilon4uServersNum) {
        isilon4UServersNum = isilon4uServersNum;
    }

    /**
     * Getter method for property <tt>infinibandSwitchesNum</tt>.
     * 
     * @return property value of infinibandSwitchesNum
     */
    public Integer getInfinibandSwitchesNum() {
        return infinibandSwitchesNum;
    }

    /**
     * Setter method for property <tt>infinibandSwitchesNum</tt>.
     * 
     * @param infinibandSwitchesNum
     *            value to be assigned to property infinibandSwitchesNum
     */
    public void setInfinibandSwitchesNum(Integer infinibandSwitchesNum) {
        this.infinibandSwitchesNum = infinibandSwitchesNum;
    }

    /**
     * Getter method for property <tt>infinibandChassisNum</tt>.
     * 
     * @return property value of infinibandChassisNum
     */
    public Integer getInfinibandChassisNum() {
        return infinibandChassisNum;
    }

    /**
     * Setter method for property <tt>infinibandChassisNum</tt>.
     * 
     * @param infinibandChassisNum
     *            value to be assigned to property infinibandChassisNum
     */
    public void setInfinibandChassisNum(Integer infinibandChassisNum) {
        this.infinibandChassisNum = infinibandChassisNum;
    }

}

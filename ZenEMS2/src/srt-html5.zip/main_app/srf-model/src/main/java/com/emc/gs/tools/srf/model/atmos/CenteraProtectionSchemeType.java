/*
 * This code is copyright (c) 2014 EMC Corporation
 */
package com.emc.gs.tools.srf.model.atmos;

import com.emc.gs.tools.srf.model.LookupEntity;

/**
 * <p>
 * This is CenteraProtectionSchemeType entity class.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safety.
 * </p>
 * 
 * @author TCSASSEMBLER
 * @version 1.0
 * @since SRT Phase 3-1 - Atmos Centera and Vblock Tabs Assembly
 */
public class CenteraProtectionSchemeType extends LookupEntity {

    /**
     * <p>
     * The default constructor.
     * </p>
     */
    public CenteraProtectionSchemeType() {
    }

}

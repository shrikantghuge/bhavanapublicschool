/*
 * This code is copyright (c) 2014 EMC Corporation.
 */
package com.emc.gs.tools.srf.model.estimate;

import com.emc.gs.tools.srf.model.IdentifiableEntity;

/**
 * <p>
 * This is LOBCountry entity class.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safety.
 * </p>
 * 
 * @author TCSASSEMBLER
 * @version 1.0
 * @since SRT Phase 4 - ET Assembly 1
 */
public class LOBCountry extends IdentifiableEntity {

    /**
     * The LOB id.
     */
    private long lobId;

    /**
     * The country code.
     */
    private String countryCode;

    /**
     * The company code. E.g "US10".
     */
    private String companyCode;

    /**
     * The cost center code. E.g "US1080018".
     */
    private String costCenterCode;

    /**
     * Empty constructor.
     */
    public LOBCountry() {
    }

    /**
     * Getter method for property <tt>lobId</tt>.
     * 
     * @return property value of lobId
     */
    public long getLobId() {
        return lobId;
    }

    /**
     * Setter method for property <tt>lobId</tt>.
     * 
     * @param lobId
     *            value to be assigned to property lobId
     */
    public void setLobId(long lobId) {
        this.lobId = lobId;
    }

    /**
     * Getter method for property <tt>countryCode</tt>.
     * 
     * @return property value of countryCode
     */
    public String getCountryCode() {
        return countryCode;
    }

    /**
     * Setter method for property <tt>countryCode</tt>.
     * 
     * @param countryCode
     *            value to be assigned to property countryCode
     */
    public void setCountryCode(String countryCode) {
        this.countryCode = countryCode;
    }

    /**
     * Getter method for property <tt>companyCode</tt>.
     * 
     * @return property value of companyCode
     */
    public String getCompanyCode() {
        return companyCode;
    }

    /**
     * Setter method for property <tt>companyCode</tt>.
     * 
     * @param companyCode
     *            value to be assigned to property companyCode
     */
    public void setCompanyCode(String companyCode) {
        this.companyCode = companyCode;
    }

    /**
     * Getter method for property <tt>costCenterCode</tt>.
     * 
     * @return property value of costCenterCode
     */
    public String getCostCenterCode() {
        return costCenterCode;
    }

    /**
     * Setter method for property <tt>costCenterCode</tt>.
     * 
     * @param costCenterCode
     *            value to be assigned to property costCenterCode
     */
    public void setCostCenterCode(String costCenterCode) {
        this.costCenterCode = costCenterCode;
    }

}

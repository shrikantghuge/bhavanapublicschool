/*
 * This code is copyright (c) 2014 EMC Corporation.
 */
package com.emc.gs.tools.srf.model;

/**
 * <p>
 * This is Operation enum class.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: It's immutable and thread safe.
 * </p>
 *
 * @author zsudraco, TCSASSEMBLER
 * @version 1.0
 * @since SRT Cloud Synchronization - Cloud App Assembly
 */
public enum Operation {
    /**
     * <p>
     * The CREATE.
     * </p>
     */
    CREATE,

    /**
     * <p>
     * The UPDATE.
     * </p>
     */
    UPDATE,

    /**
     * <p>
     * The DELETE.
     * </p>
     */
    DELETE
}

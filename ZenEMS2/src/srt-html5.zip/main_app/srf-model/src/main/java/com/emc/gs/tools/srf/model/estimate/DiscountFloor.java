/*
 * This code is copyright (c) 2014 EMC Corporation.
 */
package com.emc.gs.tools.srf.model.estimate;

import com.emc.gs.tools.srf.model.IdentifiableEntity;

/**
 * <p>This is DiscountFloor entity class.</p>
 *
 * <p><strong>Thread safety</strong>: This class is mutable, it is not thread safety.</p>
 *
 * @author isv
 */
public class DiscountFloor extends IdentifiableEntity {

    /**
     * <p>A <code>DiscountFloorType</code> providing the value for type property.</p>
     */
    private DiscountFloorType type;

    /**
     * <p>A <code>Double</code> providing the value for limit property.</p>
     */
    private Double limit;

    /**
     * <p>Constructs new <code>DiscountFloor</code> instance. This implementation does nothing.</p>
     */
    public DiscountFloor() {
    }

    /**
     * <p>Gets the limit property.</p>
     *
     * @return a <code>Double</code> providing the value for limit property.
     */
    public Double getLimit() {
        return this.limit;
    }

    /**
     * <p>Sets the limit property.</p>
     *
     * @param limit a <code>Double</code> providing the value for limit property.
     */
    public void setLimit(Double limit) {
        this.limit = limit;
    }

    /**
     * <p>Gets the type property.</p>
     *
     * @return a <code>DiscountFloorType</code> providing the value for type property.
     */
    public DiscountFloorType getType() {
        return this.type;
    }

    /**
     * <p>Sets the type property.</p>
     *
     * @param type a <code>DiscountFloorType</code> providing the value for type property.
     */
    public void setType(DiscountFloorType type) {
        this.type = type;
    }

}

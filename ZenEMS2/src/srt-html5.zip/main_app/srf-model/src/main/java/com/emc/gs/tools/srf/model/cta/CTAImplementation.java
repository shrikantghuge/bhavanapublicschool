/*
 * This code is copyright (c) 2014 EMC Corporation
 */
package com.emc.gs.tools.srf.model.cta;

import java.util.ArrayList;
import java.util.List;

import com.emc.gs.tools.srf.model.IdentifiableEntity;

/**
 * <p>
 * This is CTAImplementation entity class.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safety.
 * </p>
 * 
 * @author TCSASSEMBLER
 * @version 1.0
 * @since SRT Phase 3-1 - CTA Rainfinity and MSS Tabs Assembly
 */
public class CTAImplementation extends IdentifiableEntity {

    /**
     * Provide a brief explanation of customer expectations.
     */
    private String customerExpectations;

    /**
     * CTA implementation array.
     */
    private List<CTAImplementationArray> array = new ArrayList<CTAImplementationArray>();

    /**
     * <p>
     * The default constructor.
     * </p>
     */
    public CTAImplementation() {
    }

    /**
     * Getter method for property <tt>customerExpectations</tt>.
     * 
     * @return property value of customerExpectations
     */
    public String getCustomerExpectations() {
        return customerExpectations;
    }

    /**
     * Setter method for property <tt>customerExpectations</tt>.
     * 
     * @param customerExpectations
     *            value to be assigned to property customerExpectations
     */
    public void setCustomerExpectations(String customerExpectations) {
        this.customerExpectations = customerExpectations;
    }

    /**
     * Getter method for property <tt>array</tt>.
     * 
     * @return property value of array
     */
    public List<CTAImplementationArray> getArray() {
        return array;
    }

    /**
     * Setter method for property <tt>array</tt>.
     * 
     * @param array
     *            value to be assigned to property array
     */
    public void setArray(List<CTAImplementationArray> array) {
        this.array = array;
    }

}

/*
 * This code is copyright (c) 2014 EMC Corporation
 */
package com.emc.gs.tools.srf.model.cta;

import java.math.BigDecimal;

import com.emc.gs.tools.srf.model.IdentifiableEntity;

/**
 * <p>
 * This is CTARaininfinity entity class.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safety.
 * </p>
 * 
 * @author TCSASSEMBLER
 * @version 1.0
 * @since SRT Phase 3-1 - CTA Rainfinity and MSS Tabs Update Assembly
 */
public class CTARaininfinity extends IdentifiableEntity {

    /**
     * Include File Virtualization Appliance Clustered Deployment.
     */
    private boolean includeClusteredDeployment;

    /**
     * Will hardware conversion from a Rainfinity Global File Virtualization (GFV) appliance to a File Virtualization
     * Appliance (FVA) will be implemented.
     */
    private boolean hardwareConversion;

    /**
     * Will Rainfinity File Virtualization Appliance (FVA) multi-instances spanning tree protocol (MSTP) will be
     * implemented.
     */
    private boolean mstp;

    /**
     * Will Rainfinity FVA cross-functional migration will be implemented.
     */
    private boolean crossFunctionalMigration;

    /**
     * # of billable hours for Solutions Architect to complete Solutions Qualifiers.
     */
    private BigDecimal billableHoursNum;

    /**
     * # of File Virtualization Appliances to be deployed.
     */
    private Integer appliancesDeployedNum;

    /**
     * # of file servers in the File Virtualization Appliance environment.
     */
    private Integer fileServersNum;

    /**
     * # of file systems in the File Virtualization Appliance environment.
     */
    private Integer fileSystemsNum;

    /**
     * Include File Virtualization Appliance SID Translator Utility.
     */
    private Boolean includeSID;

    /**
     * # of local user and group objects.
     */
    private Integer localUserObjectsNum;

    /**
     * Include File Virtualization Appliance Windows Proxy Service.
     */
    private Boolean includeWindowsProxy;

    /**
     * Include File Virtualization Appliance remote migration implementation.
     */
    private Boolean includeRemoteMigration;

    /**
     * # of Rainfinity Global File Virtualization appliances.
     */
    private Integer rainfinityAppliancesNum;

    /**
     * # of Rainfinity FVA VLANs for the MSTP configuration.
     */
    private Integer rainfinityVLANsNum;

    /**
     * # of Domains for File Virtualization Appliance (FVA) cross-functional migration implementation.
     */
    private Integer domainsNum;

    /**
     * Is switch configuration required for the File Virtualization Appliance implementation?
     */
    private Boolean switchConfigRequired;

    /**
     * Include File Virtualization Appliance local migration implementation.
     */
    private Boolean includeLocalMigration;

    /**
     * Amount of data in GB to be migrated by the Rainfinity File Virtualization Appliance.
     */
    private Integer migrateDataAmount;

    /**
     * <p>
     * The default constructor.
     * </p>
     */
    public CTARaininfinity() {
    }

    /**
     * Getter method for property <tt>includeClusteredDeployment</tt>.
     * 
     * @return property value of includeClusteredDeployment
     */
    public boolean isIncludeClusteredDeployment() {
        return includeClusteredDeployment;
    }

    /**
     * Setter method for property <tt>includeClusteredDeployment</tt>.
     * 
     * @param includeClusteredDeployment
     *            value to be assigned to property includeClusteredDeployment
     */
    public void setIncludeClusteredDeployment(boolean includeClusteredDeployment) {
        this.includeClusteredDeployment = includeClusteredDeployment;
    }

    /**
     * Getter method for property <tt>hardwareConversion</tt>.
     * 
     * @return property value of hardwareConversion
     */
    public boolean isHardwareConversion() {
        return hardwareConversion;
    }

    /**
     * Setter method for property <tt>hardwareConversion</tt>.
     * 
     * @param hardwareConversion
     *            value to be assigned to property hardwareConversion
     */
    public void setHardwareConversion(boolean hardwareConversion) {
        this.hardwareConversion = hardwareConversion;
    }

    /**
     * Getter method for property <tt>mstp</tt>.
     * 
     * @return property value of mstp
     */
    public boolean isMstp() {
        return mstp;
    }

    /**
     * Setter method for property <tt>mstp</tt>.
     * 
     * @param mstp
     *            value to be assigned to property mstp
     */
    public void setMstp(boolean mstp) {
        this.mstp = mstp;
    }

    /**
     * Getter method for property <tt>crossFunctionalMigration</tt>.
     * 
     * @return property value of crossFunctionalMigration
     */
    public boolean isCrossFunctionalMigration() {
        return crossFunctionalMigration;
    }

    /**
     * Setter method for property <tt>crossFunctionalMigration</tt>.
     * 
     * @param crossFunctionalMigration
     *            value to be assigned to property crossFunctionalMigration
     */
    public void setCrossFunctionalMigration(boolean crossFunctionalMigration) {
        this.crossFunctionalMigration = crossFunctionalMigration;
    }

    /**
     * Getter method for property <tt>billableHoursNum</tt>.
     * 
     * @return property value of billableHoursNum
     */
    public BigDecimal getBillableHoursNum() {
        return billableHoursNum;
    }

    /**
     * Setter method for property <tt>billableHoursNum</tt>.
     * 
     * @param billableHoursNum
     *            value to be assigned to property billableHoursNum
     */
    public void setBillableHoursNum(BigDecimal billableHoursNum) {
        this.billableHoursNum = billableHoursNum;
    }

    /**
     * Getter method for property <tt>appliancesDeployedNum</tt>.
     * 
     * @return property value of appliancesDeployedNum
     */
    public Integer getAppliancesDeployedNum() {
        return appliancesDeployedNum;
    }

    /**
     * Setter method for property <tt>appliancesDeployedNum</tt>.
     * 
     * @param appliancesDeployedNum
     *            value to be assigned to property appliancesDeployedNum
     */
    public void setAppliancesDeployedNum(Integer appliancesDeployedNum) {
        this.appliancesDeployedNum = appliancesDeployedNum;
    }

    /**
     * Getter method for property <tt>fileServersNum</tt>.
     * 
     * @return property value of fileServersNum
     */
    public Integer getFileServersNum() {
        return fileServersNum;
    }

    /**
     * Setter method for property <tt>fileServersNum</tt>.
     * 
     * @param fileServersNum
     *            value to be assigned to property fileServersNum
     */
    public void setFileServersNum(Integer fileServersNum) {
        this.fileServersNum = fileServersNum;
    }

    /**
     * Getter method for property <tt>fileSystemsNum</tt>.
     * 
     * @return property value of fileSystemsNum
     */
    public Integer getFileSystemsNum() {
        return fileSystemsNum;
    }

    /**
     * Setter method for property <tt>fileSystemsNum</tt>.
     * 
     * @param fileSystemsNum
     *            value to be assigned to property fileSystemsNum
     */
    public void setFileSystemsNum(Integer fileSystemsNum) {
        this.fileSystemsNum = fileSystemsNum;
    }

    /**
     * Getter method for property <tt>includeSID</tt>.
     * 
     * @return property value of includeSID
     */
    public Boolean getIncludeSID() {
        return includeSID;
    }

    /**
     * Setter method for property <tt>includeSID</tt>.
     * 
     * @param includeSID
     *            value to be assigned to property includeSID
     */
    public void setIncludeSID(Boolean includeSID) {
        this.includeSID = includeSID;
    }

    /**
     * Getter method for property <tt>localUserObjectsNum</tt>.
     * 
     * @return property value of localUserObjectsNum
     */
    public Integer getLocalUserObjectsNum() {
        return localUserObjectsNum;
    }

    /**
     * Setter method for property <tt>localUserObjectsNum</tt>.
     * 
     * @param localUserObjectsNum
     *            value to be assigned to property localUserObjectsNum
     */
    public void setLocalUserObjectsNum(Integer localUserObjectsNum) {
        this.localUserObjectsNum = localUserObjectsNum;
    }

    /**
     * Getter method for property <tt>includeWindowsProxy</tt>.
     * 
     * @return property value of includeWindowsProxy
     */
    public Boolean getIncludeWindowsProxy() {
        return includeWindowsProxy;
    }

    /**
     * Setter method for property <tt>includeWindowsProxy</tt>.
     * 
     * @param includeWindowsProxy
     *            value to be assigned to property includeWindowsProxy
     */
    public void setIncludeWindowsProxy(Boolean includeWindowsProxy) {
        this.includeWindowsProxy = includeWindowsProxy;
    }

    /**
     * Getter method for property <tt>includeRemoteMigration</tt>.
     * 
     * @return property value of includeRemoteMigration
     */
    public Boolean getIncludeRemoteMigration() {
        return includeRemoteMigration;
    }

    /**
     * Setter method for property <tt>includeRemoteMigration</tt>.
     * 
     * @param includeRemoteMigration
     *            value to be assigned to property includeRemoteMigration
     */
    public void setIncludeRemoteMigration(Boolean includeRemoteMigration) {
        this.includeRemoteMigration = includeRemoteMigration;
    }

    /**
     * Getter method for property <tt>rainfinityAppliancesNum</tt>.
     * 
     * @return property value of rainfinityAppliancesNum
     */
    public Integer getRainfinityAppliancesNum() {
        return rainfinityAppliancesNum;
    }

    /**
     * Setter method for property <tt>rainfinityAppliancesNum</tt>.
     * 
     * @param rainfinityAppliancesNum
     *            value to be assigned to property rainfinityAppliancesNum
     */
    public void setRainfinityAppliancesNum(Integer rainfinityAppliancesNum) {
        this.rainfinityAppliancesNum = rainfinityAppliancesNum;
    }

    /**
     * Getter method for property <tt>rainfinityVLANsNum</tt>.
     * 
     * @return property value of rainfinityVLANsNum
     */
    public Integer getRainfinityVLANsNum() {
        return rainfinityVLANsNum;
    }

    /**
     * Setter method for property <tt>rainfinityVLANsNum</tt>.
     * 
     * @param rainfinityVLANsNum
     *            value to be assigned to property rainfinityVLANsNum
     */
    public void setRainfinityVLANsNum(Integer rainfinityVLANsNum) {
        this.rainfinityVLANsNum = rainfinityVLANsNum;
    }

    /**
     * Getter method for property <tt>domainsNum</tt>.
     * 
     * @return property value of domainsNum
     */
    public Integer getDomainsNum() {
        return domainsNum;
    }

    /**
     * Setter method for property <tt>domainsNum</tt>.
     * 
     * @param domainsNum
     *            value to be assigned to property domainsNum
     */
    public void setDomainsNum(Integer domainsNum) {
        this.domainsNum = domainsNum;
    }

    /**
     * Getter method for property <tt>switchConfigRequired</tt>.
     * 
     * @return property value of switchConfigRequired
     */
    public Boolean getSwitchConfigRequired() {
        return switchConfigRequired;
    }

    /**
     * Setter method for property <tt>switchConfigRequired</tt>.
     * 
     * @param switchConfigRequired
     *            value to be assigned to property switchConfigRequired
     */
    public void setSwitchConfigRequired(Boolean switchConfigRequired) {
        this.switchConfigRequired = switchConfigRequired;
    }

    /**
     * Getter method for property <tt>includeLocalMigration</tt>.
     * 
     * @return property value of includeLocalMigration
     */
    public Boolean getIncludeLocalMigration() {
        return includeLocalMigration;
    }

    /**
     * Setter method for property <tt>includeLocalMigration</tt>.
     * 
     * @param includeLocalMigration
     *            value to be assigned to property includeLocalMigration
     */
    public void setIncludeLocalMigration(Boolean includeLocalMigration) {
        this.includeLocalMigration = includeLocalMigration;
    }

    /**
     * Getter method for property <tt>migrateDataAmount</tt>.
     * 
     * @return property value of migrateDataAmount
     */
    public Integer getMigrateDataAmount() {
        return migrateDataAmount;
    }

    /**
     * Setter method for property <tt>migrateDataAmount</tt>.
     * 
     * @param migrateDataAmount
     *            value to be assigned to property migrateDataAmount
     */
    public void setMigrateDataAmount(Integer migrateDataAmount) {
        this.migrateDataAmount = migrateDataAmount;
    }

}

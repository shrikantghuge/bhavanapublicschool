/*
 * This code is copyright (c) 2014 EMC Corporation
 */
package com.emc.gs.tools.srf.model.cta;

import com.emc.gs.tools.srf.model.IdentifiableEntity;

/**
 * <p>
 * This is CTAImplementationArray entity class.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safety.
 * </p>
 * <p>
 * <strong>Changes V1.1:</strong> <strong>SRT Phase 3-1 - CTA Rainfinity and MSS Tabs Update Assembly</strong>
 * <ul>
 * <li>Remove dataSourcesNum/fileSystemsNum/archiveDataSource/archiveDataTarget fields.</li>
 * <li>Add sourceFileServerType/sourceExportsSharesNum/multiTierArchiving/multiTierSitesNum/securityHardening/
 * nasDestination/archivePoliciesNum/migrationPoliciesNum fields.</li>
 * </ul>
 * </p>
 * 
 * @author TCSASSEMBLER
 * @version 1.1
 * @since SRT Phase 3-1 - CTA Rainfinity and MSS Tabs Assembly
 */
public class CTAImplementationArray extends IdentifiableEntity {

    /**
     * Location (City, State).
     */
    private String location;

    /**
     * Appliance Type.
     */
    private CTAApplianceType applianceType;

    /**
     * Clustered Appliance?
     */
    private Boolean clusteredAppliance;

    /**
     * # of clusters.
     */
    private Integer clustersNum;

    /**
     * Select the source file server type.
     */
    private CTASourceFileServerType sourceFileServerType;

    /**
     * # of source exports/shares.
     */
    private Integer sourceExportsSharesNum;

    /**
     * Muti-tier archiving will be implemented?
     */
    private Boolean multiTierArchiving;

    /**
     * # of Multi-tier sites?
     */
    private Integer multiTierSitesNum;

    /**
     * Will security hardening will be implemented?
     */
    private Boolean securityHardening;

    /**
     * Select the type(s) of NAS destination for the Cloud Tiering Appliance implementation.
     */
    private NASDestination nasDestination;

    /**
     * # of archive policies?
     */
    private Integer archivePoliciesNum;

    /**
     * # Number of migration policies?
     */
    private Integer migrationPoliciesNum;

    /**
     * Use Cloud Tiering Appliance for capacity management? - FVA only.
     */
    private Boolean capacityManagement;

    /**
     * <p>
     * The default constructor.
     * </p>
     */
    public CTAImplementationArray() {
    }

    /**
     * Getter method for property <tt>location</tt>.
     * 
     * @return property value of location
     */
    public String getLocation() {
        return location;
    }

    /**
     * Setter method for property <tt>location</tt>.
     * 
     * @param location
     *            value to be assigned to property location
     */
    public void setLocation(String location) {
        this.location = location;
    }

    /**
     * Getter method for property <tt>applianceType</tt>.
     * 
     * @return property value of applianceType
     */
    public CTAApplianceType getApplianceType() {
        return applianceType;
    }

    /**
     * Setter method for property <tt>applianceType</tt>.
     * 
     * @param applianceType
     *            value to be assigned to property applianceType
     */
    public void setApplianceType(CTAApplianceType applianceType) {
        this.applianceType = applianceType;
    }

    /**
     * Getter method for property <tt>clusteredAppliance</tt>.
     * 
     * @return property value of clusteredAppliance
     */
    public Boolean getClusteredAppliance() {
        return clusteredAppliance;
    }

    /**
     * Setter method for property <tt>clusteredAppliance</tt>.
     * 
     * @param clusteredAppliance
     *            value to be assigned to property clusteredAppliance
     */
    public void setClusteredAppliance(Boolean clusteredAppliance) {
        this.clusteredAppliance = clusteredAppliance;
    }

    /**
     * Getter method for property <tt>clustersNum</tt>.
     * 
     * @return property value of clustersNum
     */
    public Integer getClustersNum() {
        return clustersNum;
    }

    /**
     * Setter method for property <tt>clustersNum</tt>.
     * 
     * @param clustersNum
     *            value to be assigned to property clustersNum
     */
    public void setClustersNum(Integer clustersNum) {
        this.clustersNum = clustersNum;
    }

    /**
     * Getter method for property <tt>sourceFileServerType</tt>.
     * 
     * @return property value of sourceFileServerType
     */
    public CTASourceFileServerType getSourceFileServerType() {
        return sourceFileServerType;
    }

    /**
     * Setter method for property <tt>sourceFileServerType</tt>.
     * 
     * @param sourceFileServerType
     *            value to be assigned to property sourceFileServerType
     */
    public void setSourceFileServerType(CTASourceFileServerType sourceFileServerType) {
        this.sourceFileServerType = sourceFileServerType;
    }

    /**
     * Getter method for property <tt>sourceExportsSharesNum</tt>.
     * 
     * @return property value of sourceExportsSharesNum
     */
    public Integer getSourceExportsSharesNum() {
        return sourceExportsSharesNum;
    }

    /**
     * Setter method for property <tt>sourceExportsSharesNum</tt>.
     * 
     * @param sourceExportsSharesNum
     *            value to be assigned to property sourceExportsSharesNum
     */
    public void setSourceExportsSharesNum(Integer sourceExportsSharesNum) {
        this.sourceExportsSharesNum = sourceExportsSharesNum;
    }

    /**
     * Getter method for property <tt>multiTierArchiving</tt>.
     * 
     * @return property value of multiTierArchiving
     */
    public Boolean getMultiTierArchiving() {
        return multiTierArchiving;
    }

    /**
     * Setter method for property <tt>multiTierArchiving</tt>.
     * 
     * @param multiTierArchiving
     *            value to be assigned to property multiTierArchiving
     */
    public void setMultiTierArchiving(Boolean multiTierArchiving) {
        this.multiTierArchiving = multiTierArchiving;
    }

    /**
     * Getter method for property <tt>multiTierSitesNum</tt>.
     * 
     * @return property value of multiTierSitesNum
     */
    public Integer getMultiTierSitesNum() {
        return multiTierSitesNum;
    }

    /**
     * Setter method for property <tt>multiTierSitesNum</tt>.
     * 
     * @param multiTierSitesNum
     *            value to be assigned to property multiTierSitesNum
     */
    public void setMultiTierSitesNum(Integer multiTierSitesNum) {
        this.multiTierSitesNum = multiTierSitesNum;
    }

    /**
     * Getter method for property <tt>securityHardening</tt>.
     * 
     * @return property value of securityHardening
     */
    public Boolean getSecurityHardening() {
        return securityHardening;
    }

    /**
     * Setter method for property <tt>securityHardening</tt>.
     * 
     * @param securityHardening
     *            value to be assigned to property securityHardening
     */
    public void setSecurityHardening(Boolean securityHardening) {
        this.securityHardening = securityHardening;
    }

    /**
     * Getter method for property <tt>nasDestination</tt>.
     * 
     * @return property value of nasDestination
     */
    public NASDestination getNasDestination() {
        return nasDestination;
    }

    /**
     * Setter method for property <tt>nasDestination</tt>.
     * 
     * @param nasDestination
     *            value to be assigned to property nasDestination
     */
    public void setNasDestination(NASDestination nasDestination) {
        this.nasDestination = nasDestination;
    }

    /**
     * Getter method for property <tt>archivePoliciesNum</tt>.
     * 
     * @return property value of archivePoliciesNum
     */
    public Integer getArchivePoliciesNum() {
        return archivePoliciesNum;
    }

    /**
     * Setter method for property <tt>archivePoliciesNum</tt>.
     * 
     * @param archivePoliciesNum
     *            value to be assigned to property archivePoliciesNum
     */
    public void setArchivePoliciesNum(Integer archivePoliciesNum) {
        this.archivePoliciesNum = archivePoliciesNum;
    }

    /**
     * Getter method for property <tt>migrationPoliciesNum</tt>.
     * 
     * @return property value of migrationPoliciesNum
     */
    public Integer getMigrationPoliciesNum() {
        return migrationPoliciesNum;
    }

    /**
     * Setter method for property <tt>migrationPoliciesNum</tt>.
     * 
     * @param migrationPoliciesNum
     *            value to be assigned to property migrationPoliciesNum
     */
    public void setMigrationPoliciesNum(Integer migrationPoliciesNum) {
        this.migrationPoliciesNum = migrationPoliciesNum;
    }

    /**
     * Getter method for property <tt>capacityManagement</tt>.
     * 
     * @return property value of capacityManagement
     */
    public Boolean getCapacityManagement() {
        return capacityManagement;
    }

    /**
     * Setter method for property <tt>capacityManagement</tt>.
     * 
     * @param capacityManagement
     *            value to be assigned to property capacityManagement
     */
    public void setCapacityManagement(Boolean capacityManagement) {
        this.capacityManagement = capacityManagement;
    }

}

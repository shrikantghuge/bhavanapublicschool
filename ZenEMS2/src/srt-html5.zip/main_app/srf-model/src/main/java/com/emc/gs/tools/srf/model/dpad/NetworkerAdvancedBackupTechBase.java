/*
 * This code is copyright (c) 2014 EMC Corporation
 */
package com.emc.gs.tools.srf.model.dpad;

import com.emc.gs.tools.srf.model.IdentifiableEntity;

/**
 * <p>
 * This is NetworkerAdvancedBackupTechBase entity class.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safety.
 * </p>
 * 
 * @author TCSASSEMBLER
 * @version 1.0
 * @since SRT Phase 3-5 - BRS Tabs Part 3 Assembly
 */
public abstract class NetworkerAdvancedBackupTechBase extends IdentifiableEntity {

    /**
     * Represents whether "SNMP" application is selected.
     */
    private boolean snmp;

    /**
     * Represents whether "VMWARE" application is selected.
     */
    private boolean vmware;

    /**
     * Represents whether "Snapshot Management" application is selected.
     */
    private boolean snapshotManagement;

    /**
     * Represents whether "NAS (Includes NDMP and Snapshot Management for NAS)" application is selected.
     */
    private boolean nas;

    /**
     * Include Networker VMWare Protection Backups?
     */
    private Boolean includeVmwareProtectionBackups;

    /**
     * # of VMWare Backup Appliances.
     */
    private Integer vmwareBackupAppliancesNum;

    /**
     * # of Networker Snapshot Management Application Hosts.
     */
    private Integer snapshotManagementAppHostsNum;

    /**
     * # of Networker Snapshot Management Mount Hosts.
     */
    private Integer snapshotManagementMountHostsNum;

    /**
     * # of NAS DataMovers to be Backed Up via NDMP.
     */
    private Integer nasDataMoversNum;

    /**
     * <p>
     * The default constructor.
     * </p>
     */
    protected NetworkerAdvancedBackupTechBase() {
    }

    /**
     * Getter method for property <tt>snmp</tt>.
     * 
     * @return property value of snmp
     */
    public boolean isSnmp() {
        return snmp;
    }

    /**
     * Setter method for property <tt>snmp</tt>.
     * 
     * @param snmp
     *            value to be assigned to property snmp
     */
    public void setSnmp(boolean snmp) {
        this.snmp = snmp;
    }

    /**
     * Getter method for property <tt>vmware</tt>.
     * 
     * @return property value of vmware
     */
    public boolean isVmware() {
        return vmware;
    }

    /**
     * Setter method for property <tt>vmware</tt>.
     * 
     * @param vmware
     *            value to be assigned to property vmware
     */
    public void setVmware(boolean vmware) {
        this.vmware = vmware;
    }

    /**
     * Getter method for property <tt>snapshotManagement</tt>.
     * 
     * @return property value of snapshotManagement
     */
    public boolean isSnapshotManagement() {
        return snapshotManagement;
    }

    /**
     * Setter method for property <tt>snapshotManagement</tt>.
     * 
     * @param snapshotManagement
     *            value to be assigned to property snapshotManagement
     */
    public void setSnapshotManagement(boolean snapshotManagement) {
        this.snapshotManagement = snapshotManagement;
    }

    /**
     * Getter method for property <tt>nas</tt>.
     * 
     * @return property value of nas
     */
    public boolean isNas() {
        return nas;
    }

    /**
     * Setter method for property <tt>nas</tt>.
     * 
     * @param nas
     *            value to be assigned to property nas
     */
    public void setNas(boolean nas) {
        this.nas = nas;
    }

    /**
     * Getter method for property <tt>includeVmwareProtectionBackups</tt>.
     * 
     * @return property value of includeVmwareProtectionBackups
     */
    public Boolean getIncludeVmwareProtectionBackups() {
        return includeVmwareProtectionBackups;
    }

    /**
     * Setter method for property <tt>includeVmwareProtectionBackups</tt>.
     * 
     * @param includeVmwareProtectionBackups
     *            value to be assigned to property includeVmwareProtectionBackups
     */
    public void setIncludeVmwareProtectionBackups(Boolean includeVmwareProtectionBackups) {
        this.includeVmwareProtectionBackups = includeVmwareProtectionBackups;
    }

    /**
     * Getter method for property <tt>vmwareBackupAppliancesNum</tt>.
     * 
     * @return property value of vmwareBackupAppliancesNum
     */
    public Integer getVmwareBackupAppliancesNum() {
        return vmwareBackupAppliancesNum;
    }

    /**
     * Setter method for property <tt>vmwareBackupAppliancesNum</tt>.
     * 
     * @param vmwareBackupAppliancesNum
     *            value to be assigned to property vmwareBackupAppliancesNum
     */
    public void setVmwareBackupAppliancesNum(Integer vmwareBackupAppliancesNum) {
        this.vmwareBackupAppliancesNum = vmwareBackupAppliancesNum;
    }

    /**
     * Getter method for property <tt>snapshotManagementAppHostsNum</tt>.
     * 
     * @return property value of snapshotManagementAppHostsNum
     */
    public Integer getSnapshotManagementAppHostsNum() {
        return snapshotManagementAppHostsNum;
    }

    /**
     * Setter method for property <tt>snapshotManagementAppHostsNum</tt>.
     * 
     * @param snapshotManagementAppHostsNum
     *            value to be assigned to property snapshotManagementAppHostsNum
     */
    public void setSnapshotManagementAppHostsNum(Integer snapshotManagementAppHostsNum) {
        this.snapshotManagementAppHostsNum = snapshotManagementAppHostsNum;
    }

    /**
     * Getter method for property <tt>snapshotManagementMountHostsNum</tt>.
     * 
     * @return property value of snapshotManagementMountHostsNum
     */
    public Integer getSnapshotManagementMountHostsNum() {
        return snapshotManagementMountHostsNum;
    }

    /**
     * Setter method for property <tt>snapshotManagementMountHostsNum</tt>.
     * 
     * @param snapshotManagementMountHostsNum
     *            value to be assigned to property snapshotManagementMountHostsNum
     */
    public void setSnapshotManagementMountHostsNum(Integer snapshotManagementMountHostsNum) {
        this.snapshotManagementMountHostsNum = snapshotManagementMountHostsNum;
    }

    /**
     * Getter method for property <tt>nasDataMoversNum</tt>.
     * 
     * @return property value of nasDataMoversNum
     */
    public Integer getNasDataMoversNum() {
        return nasDataMoversNum;
    }

    /**
     * Setter method for property <tt>nasDataMoversNum</tt>.
     * 
     * @param nasDataMoversNum
     *            value to be assigned to property nasDataMoversNum
     */
    public void setNasDataMoversNum(Integer nasDataMoversNum) {
        this.nasDataMoversNum = nasDataMoversNum;
    }

}

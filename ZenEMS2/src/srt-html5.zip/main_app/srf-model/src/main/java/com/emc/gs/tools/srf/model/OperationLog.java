/*
 * This code is copyright (c) 2014 EMC Corporation.
 */
package com.emc.gs.tools.srf.model;

/**
 * <p>
 * This is the OperationLog entity class.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safe.
 * </p>
 *
 * <p>
 * <strong>Changes V1.1:</strong>
 * <strong>SRT Phase 4 - ET Assembly 2</strong>
 * <ul>
 * <li>Change to extend from BaseOperationLog.</li>
 * </ul>
 * </p>
 *
 * @author zsudraco, TCSASSEMBLER
 * @version 1.1
 * @since SRT Cloud Synchronization - Cloud App Assembly
 */
public class OperationLog extends BaseOperationLog {

}

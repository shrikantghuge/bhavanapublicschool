/*
 * This code is copyright (c) 2014 EMC Corporation
 */
package com.emc.gs.tools.srf.model.mss;

import com.emc.gs.tools.srf.model.IdentifiableEntity;

/**
 * <p>
 * This is VNX SAS Drives of MSSArray entity class.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safe.
 * </p>
 * <p>
 * <strong>Changes V1.1:</strong> <strong>SRT Phase 3-1 - CTA Rainfinity and MSS Tabs Update Assembly</strong>
 * <ul>
 * <li>Add vnxSas25Inch900GB/vnxSas35Inch900GB/vnxSas1TB/vnxSas3TB fields.</li>
 * </ul>
 * </p>
 * 
 * @author TCSASSEMBLER
 * @version 1.1
 * @since SRT Phase 3-1 - CTA Rainfinity and MSS Tabs Assembly
 */
public class MSSVnxSasDrives extends IdentifiableEntity {

    /**
     * VNX SAS Drives 300GB.
     */
    private String vnxSas300GB;

    /**
     * VNX SAS Drives 2.5" 300GB.
     */
    private String vnxSas25Inch300GB;

    /**
     * VNX SAS Drives 600GB.
     */
    private String vnxSas600GB;

    /**
     * VNX SAS Drives 2.5" 600GB.
     */
    private String vnxSas25Inch600GB;

    /**
     * VNX SAS Drives 2.5" 900GB.
     */
    private String vnxSas25Inch900GB;

    /**
     * VNX SAS Drives 3.5" 900GB.
     */
    private String vnxSas35Inch900GB;

    /**
     * VNX SAS Drives 1TB.
     */
    private String vnxSas1TB;

    /**
     * VNX SAS Drives 2TB.
     */
    private String vnxSas2TB;

    /**
     * VNX SAS Drives 3TB.
     */
    private String vnxSas3TB;

    /**
     * VNX SAS Drives 100GB SAS Flash.
     */
    private String vnxSas100GBFlash;

    /**
     * VNX SAS Drives 200GB SAS Flash.
     */
    private String vnxSas200GBFlash;

    /**
     * Other VNX SAS Drives.
     */
    private String vnxSasOther;

    /**
     * <p>
     * The default constructor.
     * </p>
     */
    public MSSVnxSasDrives() {
    }

    /**
     * Getter method for property <tt>vnxSas300GB</tt>.
     * 
     * @return property value of vnxSas300GB
     */
    public String getVnxSas300GB() {
        return vnxSas300GB;
    }

    /**
     * Setter method for property <tt>vnxSas300GB</tt>.
     * 
     * @param vnxSas300GB
     *            value to be assigned to property vnxSas300GB
     */
    public void setVnxSas300GB(String vnxSas300GB) {
        this.vnxSas300GB = vnxSas300GB;
    }

    /**
     * Getter method for property <tt>vnxSas25Inch300GB</tt>.
     * 
     * @return property value of vnxSas25Inch300GB
     */
    public String getVnxSas25Inch300GB() {
        return vnxSas25Inch300GB;
    }

    /**
     * Setter method for property <tt>vnxSas25Inch300GB</tt>.
     * 
     * @param vnxSas25Inch300GB
     *            value to be assigned to property vnxSas25Inch300GB
     */
    public void setVnxSas25Inch300GB(String vnxSas25Inch300GB) {
        this.vnxSas25Inch300GB = vnxSas25Inch300GB;
    }

    /**
     * Getter method for property <tt>vnxSas600GB</tt>.
     * 
     * @return property value of vnxSas600GB
     */
    public String getVnxSas600GB() {
        return vnxSas600GB;
    }

    /**
     * Setter method for property <tt>vnxSas600GB</tt>.
     * 
     * @param vnxSas600GB
     *            value to be assigned to property vnxSas600GB
     */
    public void setVnxSas600GB(String vnxSas600GB) {
        this.vnxSas600GB = vnxSas600GB;
    }

    /**
     * Getter method for property <tt>vnxSas25Inch600GB</tt>.
     * 
     * @return property value of vnxSas25Inch600GB
     */
    public String getVnxSas25Inch600GB() {
        return vnxSas25Inch600GB;
    }

    /**
     * Setter method for property <tt>vnxSas25Inch600GB</tt>.
     * 
     * @param vnxSas25Inch600GB
     *            value to be assigned to property vnxSas25Inch600GB
     */
    public void setVnxSas25Inch600GB(String vnxSas25Inch600GB) {
        this.vnxSas25Inch600GB = vnxSas25Inch600GB;
    }

    /**
     * Getter method for property <tt>vnxSas25Inch900GB</tt>.
     * 
     * @return property value of vnxSas25Inch900GB
     */
    public String getVnxSas25Inch900GB() {
        return vnxSas25Inch900GB;
    }

    /**
     * Setter method for property <tt>vnxSas25Inch900GB</tt>.
     * 
     * @param vnxSas25Inch900GB
     *            value to be assigned to property vnxSas25Inch900GB
     */
    public void setVnxSas25Inch900GB(String vnxSas25Inch900GB) {
        this.vnxSas25Inch900GB = vnxSas25Inch900GB;
    }

    /**
     * Getter method for property <tt>vnxSas35Inch900GB</tt>.
     * 
     * @return property value of vnxSas35Inch900GB
     */
    public String getVnxSas35Inch900GB() {
        return vnxSas35Inch900GB;
    }

    /**
     * Setter method for property <tt>vnxSas35Inch900GB</tt>.
     * 
     * @param vnxSas35Inch900GB
     *            value to be assigned to property vnxSas35Inch900GB
     */
    public void setVnxSas35Inch900GB(String vnxSas35Inch900GB) {
        this.vnxSas35Inch900GB = vnxSas35Inch900GB;
    }

    /**
     * Getter method for property <tt>vnxSas1TB</tt>.
     * 
     * @return property value of vnxSas1TB
     */
    public String getVnxSas1TB() {
        return vnxSas1TB;
    }

    /**
     * Setter method for property <tt>vnxSas1TB</tt>.
     * 
     * @param vnxSas1TB
     *            value to be assigned to property vnxSas1TB
     */
    public void setVnxSas1TB(String vnxSas1TB) {
        this.vnxSas1TB = vnxSas1TB;
    }

    /**
     * Getter method for property <tt>vnxSas2TB</tt>.
     * 
     * @return property value of vnxSas2TB
     */
    public String getVnxSas2TB() {
        return vnxSas2TB;
    }

    /**
     * Setter method for property <tt>vnxSas2TB</tt>.
     * 
     * @param vnxSas2TB
     *            value to be assigned to property vnxSas2TB
     */
    public void setVnxSas2TB(String vnxSas2TB) {
        this.vnxSas2TB = vnxSas2TB;
    }

    /**
     * Getter method for property <tt>vnxSas3TB</tt>.
     * 
     * @return property value of vnxSas3TB
     */
    public String getVnxSas3TB() {
        return vnxSas3TB;
    }

    /**
     * Setter method for property <tt>vnxSas3TB</tt>.
     * 
     * @param vnxSas3TB
     *            value to be assigned to property vnxSas3TB
     */
    public void setVnxSas3TB(String vnxSas3TB) {
        this.vnxSas3TB = vnxSas3TB;
    }

    /**
     * Getter method for property <tt>vnxSas100GBFlash</tt>.
     * 
     * @return property value of vnxSas100GBFlash
     */
    public String getVnxSas100GBFlash() {
        return vnxSas100GBFlash;
    }

    /**
     * Setter method for property <tt>vnxSas100GBFlash</tt>.
     * 
     * @param vnxSas100GBFlash
     *            value to be assigned to property vnxSas100GBFlash
     */
    public void setVnxSas100GBFlash(String vnxSas100GBFlash) {
        this.vnxSas100GBFlash = vnxSas100GBFlash;
    }

    /**
     * Getter method for property <tt>vnxSas200GBFlash</tt>.
     * 
     * @return property value of vnxSas200GBFlash
     */
    public String getVnxSas200GBFlash() {
        return vnxSas200GBFlash;
    }

    /**
     * Setter method for property <tt>vnxSas200GBFlash</tt>.
     * 
     * @param vnxSas200GBFlash
     *            value to be assigned to property vnxSas200GBFlash
     */
    public void setVnxSas200GBFlash(String vnxSas200GBFlash) {
        this.vnxSas200GBFlash = vnxSas200GBFlash;
    }

    /**
     * Getter method for property <tt>vnxSasOther</tt>.
     * 
     * @return property value of vnxSasOther
     */
    public String getVnxSasOther() {
        return vnxSasOther;
    }

    /**
     * Setter method for property <tt>vnxSasOther</tt>.
     * 
     * @param vnxSasOther
     *            value to be assigned to property vnxSasOther
     */
    public void setVnxSasOther(String vnxSasOther) {
        this.vnxSasOther = vnxSasOther;
    }

}

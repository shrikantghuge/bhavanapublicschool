/*
 * This code is copyright (c) 2014 EMC Corporation
 */
package com.emc.gs.tools.srf.model.mss;

import com.emc.gs.tools.srf.model.IdentifiableEntity;

/**
 * <p>
 * This is Avamar nodes of MSSArray entity class.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safe.
 * </p>
 * <p>
 * <strong>Changes V1.1:</strong> <strong>SRT Phase 3-1 - CTA Rainfinity and MSS Tabs Update Assembly</strong>
 * <ul>
 * <li>Remove smallAcceleratorNodesGen3/largeAcceleratorNodesGen3 fields.</li>
 * <li>Add utilityNodesGen4/acceleratorNodesGen3Gen4/storageNodes13TBGen4/storageNodes26TBGen4
 * /storageNodes39TBGen4/storageNodes78TBGen4 fields.</li>
 * </ul>
 * </p>
 * 
 * @author TCSASSEMBLER
 * @version 1.1
 * @since SRT Phase 3-1 - CTA Rainfinity and MSS Tabs Assembly
 */
public class MSSAvamarNodes extends IdentifiableEntity {

    /**
     * 1TB Storage Nodes.
     */
    private String storageNodes1TB;

    /**
     * 2TB Storage Nodes.
     */
    private String storageNodes2TB;

    /**
     * 3.3TB Storage Nodes.
     */
    private String storageNodes33TB;

    /**
     * Utility Nodes (Gen 1).
     */
    private String utilityNodesGen1;

    /**
     * Utility Nodes (Gen 2/Gen 3).
     */
    private String utilityNodesGen2Gen3;

    /**
     * Utility Nodes (Gen 4).
     */
    private String utilityNodesGen4;

    /**
     * Accelerator Nodes (Gen 1).
     */
    private String acceleratorNodesGen1;

    /**
     * Small Accelerator Nodes (Gen 2).
     */
    private String smallAcceleratorNodesGen2;

    /**
     * Large Accelerator Nodes (Gen 2).
     */
    private String largeAcceleratorNodesGen2;

    /**
     * Accelerator Nodes for Gen 3&4 Hardware.
     */
    private String acceleratorNodesGen3Gen4;

    /**
     * 1.3TB storage Nodes for Gen4.
     */
    private String storageNodes13TBGen4;

    /**
     * 2.6TB storage Nodes for Gen4.
     */
    private String storageNodes26TBGen4;

    /**
     * 3.9TB storage Nodes for Gen4.
     */
    private String storageNodes39TBGen4;

    /**
     * 7.8TB storage Nodes for Gen4.
     */
    private String storageNodes78TBGen4;

    /**
     * Other Avamar Nodes.
     */
    private String otherAvamarNodes;

    /**
     * <p>
     * The default constructor.
     * </p>
     */
    public MSSAvamarNodes() {
    }

    /**
     * Getter method for property <tt>storageNodes1TB</tt>.
     * 
     * @return property value of storageNodes1TB
     */
    public String getStorageNodes1TB() {
        return storageNodes1TB;
    }

    /**
     * Setter method for property <tt>storageNodes1TB</tt>.
     * 
     * @param storageNodes1TB
     *            value to be assigned to property storageNodes1TB
     */
    public void setStorageNodes1TB(String storageNodes1TB) {
        this.storageNodes1TB = storageNodes1TB;
    }

    /**
     * Getter method for property <tt>storageNodes2TB</tt>.
     * 
     * @return property value of storageNodes2TB
     */
    public String getStorageNodes2TB() {
        return storageNodes2TB;
    }

    /**
     * Setter method for property <tt>storageNodes2TB</tt>.
     * 
     * @param storageNodes2TB
     *            value to be assigned to property storageNodes2TB
     */
    public void setStorageNodes2TB(String storageNodes2TB) {
        this.storageNodes2TB = storageNodes2TB;
    }

    /**
     * Getter method for property <tt>storageNodes33TB</tt>.
     * 
     * @return property value of storageNodes33TB
     */
    public String getStorageNodes33TB() {
        return storageNodes33TB;
    }

    /**
     * Setter method for property <tt>storageNodes33TB</tt>.
     * 
     * @param storageNodes33TB
     *            value to be assigned to property storageNodes33TB
     */
    public void setStorageNodes33TB(String storageNodes33TB) {
        this.storageNodes33TB = storageNodes33TB;
    }

    /**
     * Getter method for property <tt>utilityNodesGen1</tt>.
     * 
     * @return property value of utilityNodesGen1
     */
    public String getUtilityNodesGen1() {
        return utilityNodesGen1;
    }

    /**
     * Setter method for property <tt>utilityNodesGen1</tt>.
     * 
     * @param utilityNodesGen1
     *            value to be assigned to property utilityNodesGen1
     */
    public void setUtilityNodesGen1(String utilityNodesGen1) {
        this.utilityNodesGen1 = utilityNodesGen1;
    }

    /**
     * Getter method for property <tt>utilityNodesGen2Gen3</tt>.
     * 
     * @return property value of utilityNodesGen2Gen3
     */
    public String getUtilityNodesGen2Gen3() {
        return utilityNodesGen2Gen3;
    }

    /**
     * Setter method for property <tt>utilityNodesGen2Gen3</tt>.
     * 
     * @param utilityNodesGen2Gen3
     *            value to be assigned to property utilityNodesGen2Gen3
     */
    public void setUtilityNodesGen2Gen3(String utilityNodesGen2Gen3) {
        this.utilityNodesGen2Gen3 = utilityNodesGen2Gen3;
    }

    /**
     * Getter method for property <tt>acceleratorNodesGen1</tt>.
     * 
     * @return property value of acceleratorNodesGen1
     */
    public String getAcceleratorNodesGen1() {
        return acceleratorNodesGen1;
    }

    /**
     * Setter method for property <tt>acceleratorNodesGen1</tt>.
     * 
     * @param acceleratorNodesGen1
     *            value to be assigned to property acceleratorNodesGen1
     */
    public void setAcceleratorNodesGen1(String acceleratorNodesGen1) {
        this.acceleratorNodesGen1 = acceleratorNodesGen1;
    }

    /**
     * Getter method for property <tt>smallAcceleratorNodesGen2</tt>.
     * 
     * @return property value of smallAcceleratorNodesGen2
     */
    public String getSmallAcceleratorNodesGen2() {
        return smallAcceleratorNodesGen2;
    }

    /**
     * Setter method for property <tt>smallAcceleratorNodesGen2</tt>.
     * 
     * @param smallAcceleratorNodesGen2
     *            value to be assigned to property smallAcceleratorNodesGen2
     */
    public void setSmallAcceleratorNodesGen2(String smallAcceleratorNodesGen2) {
        this.smallAcceleratorNodesGen2 = smallAcceleratorNodesGen2;
    }

    /**
     * Getter method for property <tt>largeAcceleratorNodesGen2</tt>.
     * 
     * @return property value of largeAcceleratorNodesGen2
     */
    public String getLargeAcceleratorNodesGen2() {
        return largeAcceleratorNodesGen2;
    }

    /**
     * Setter method for property <tt>largeAcceleratorNodesGen2</tt>.
     * 
     * @param largeAcceleratorNodesGen2
     *            value to be assigned to property largeAcceleratorNodesGen2
     */
    public void setLargeAcceleratorNodesGen2(String largeAcceleratorNodesGen2) {
        this.largeAcceleratorNodesGen2 = largeAcceleratorNodesGen2;
    }

    /**
     * Getter method for property <tt>utilityNodesGen4</tt>.
     * 
     * @return property value of utilityNodesGen4
     */
    public String getUtilityNodesGen4() {
        return utilityNodesGen4;
    }

    /**
     * Setter method for property <tt>utilityNodesGen4</tt>.
     * 
     * @param utilityNodesGen4
     *            value to be assigned to property utilityNodesGen4
     */
    public void setUtilityNodesGen4(String utilityNodesGen4) {
        this.utilityNodesGen4 = utilityNodesGen4;
    }

    /**
     * Getter method for property <tt>acceleratorNodesGen3Gen4</tt>.
     * 
     * @return property value of acceleratorNodesGen3Gen4
     */
    public String getAcceleratorNodesGen3Gen4() {
        return acceleratorNodesGen3Gen4;
    }

    /**
     * Setter method for property <tt>acceleratorNodesGen3Gen4</tt>.
     * 
     * @param acceleratorNodesGen3Gen4
     *            value to be assigned to property acceleratorNodesGen3Gen4
     */
    public void setAcceleratorNodesGen3Gen4(String acceleratorNodesGen3Gen4) {
        this.acceleratorNodesGen3Gen4 = acceleratorNodesGen3Gen4;
    }

    /**
     * Getter method for property <tt>storageNodes13TBGen4</tt>.
     * 
     * @return property value of storageNodes13TBGen4
     */
    public String getStorageNodes13TBGen4() {
        return storageNodes13TBGen4;
    }

    /**
     * Setter method for property <tt>storageNodes13TBGen4</tt>.
     * 
     * @param storageNodes13TBGen4
     *            value to be assigned to property storageNodes13TBGen4
     */
    public void setStorageNodes13TBGen4(String storageNodes13TBGen4) {
        this.storageNodes13TBGen4 = storageNodes13TBGen4;
    }

    /**
     * Getter method for property <tt>storageNodes26TBGen4</tt>.
     * 
     * @return property value of storageNodes26TBGen4
     */
    public String getStorageNodes26TBGen4() {
        return storageNodes26TBGen4;
    }

    /**
     * Setter method for property <tt>storageNodes26TBGen4</tt>.
     * 
     * @param storageNodes26TBGen4
     *            value to be assigned to property storageNodes26TBGen4
     */
    public void setStorageNodes26TBGen4(String storageNodes26TBGen4) {
        this.storageNodes26TBGen4 = storageNodes26TBGen4;
    }

    /**
     * Getter method for property <tt>storageNodes39TBGen4</tt>.
     * 
     * @return property value of storageNodes39TBGen4
     */
    public String getStorageNodes39TBGen4() {
        return storageNodes39TBGen4;
    }

    /**
     * Setter method for property <tt>storageNodes39TBGen4</tt>.
     * 
     * @param storageNodes39TBGen4
     *            value to be assigned to property storageNodes39TBGen4
     */
    public void setStorageNodes39TBGen4(String storageNodes39TBGen4) {
        this.storageNodes39TBGen4 = storageNodes39TBGen4;
    }

    /**
     * Getter method for property <tt>storageNodes78TBGen4</tt>.
     * 
     * @return property value of storageNodes78TBGen4
     */
    public String getStorageNodes78TBGen4() {
        return storageNodes78TBGen4;
    }

    /**
     * Setter method for property <tt>storageNodes78TBGen4</tt>.
     * 
     * @param storageNodes78TBGen4
     *            value to be assigned to property storageNodes78TBGen4
     */
    public void setStorageNodes78TBGen4(String storageNodes78TBGen4) {
        this.storageNodes78TBGen4 = storageNodes78TBGen4;
    }

    /**
     * Getter method for property <tt>otherAvamarNodes</tt>.
     * 
     * @return property value of otherAvamarNodes
     */
    public String getOtherAvamarNodes() {
        return otherAvamarNodes;
    }

    /**
     * Setter method for property <tt>otherAvamarNodes</tt>.
     * 
     * @param otherAvamarNodes
     *            value to be assigned to property otherAvamarNodes
     */
    public void setOtherAvamarNodes(String otherAvamarNodes) {
        this.otherAvamarNodes = otherAvamarNodes;
    }

}

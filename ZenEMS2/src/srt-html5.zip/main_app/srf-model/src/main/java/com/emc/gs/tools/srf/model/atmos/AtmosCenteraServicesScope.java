/*
 * This code is copyright (c) 2014 EMC Corporation
 */
package com.emc.gs.tools.srf.model.atmos;

import com.emc.gs.tools.srf.model.IdentifiableEntity;

/**
 * <p>
 * This is AtmosCenteraServicesScope entity class.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safety.
 * </p>
 * 
 * @author TCSASSEMBLER
 * @version 1.0
 * @since SRT Phase 3-1 - Atmos Centera and Vblock Tabs Assembly
 */
public class AtmosCenteraServicesScope extends IdentifiableEntity {

    /**
     * Represents whether Centera Design & Implementation service is in scope.
     */
    private boolean centeraDesignImpl;

    /**
     * Represents whether ATMOS Design & Implementation service is in scope.
     */
    private boolean atmosDesignImpl;

    /**
     * Represents whether Centera to Atmos Data Migration service is in scope.
     */
    private boolean centeraToAtmosMig;

    /**
     * Represents whether Atmos Cloud Delivery Platform (ACDP) service is in scope.
     */
    private boolean acdp;

    /**
     * Represents whether Centera Virtual Archive (CVA) service is in scope.
     */
    private boolean cva;

    /**
     * Represents whether Centera Universal Access (CUA) service is in scope.
     */
    private boolean cua;

    /**
     * Represents whether Centera Intra Cluster Migration (CICM) service is in scope.
     */
    private boolean cicm;

    /**
     * Represents whether Centera File Erasure service is in scope.
     */
    private boolean centeraFileErasure;

    /**
     * Represents whether Expansion Node Only service is in scope.
     */
    private boolean expansionNodeOnly;

    /**
     * <p>
     * The default constructor.
     * </p>
     */
    public AtmosCenteraServicesScope() {
    }

    /**
     * Getter method for property <tt>centeraDesignImpl</tt>.
     * 
     * @return property value of centeraDesignImpl
     */
    public boolean isCenteraDesignImpl() {
        return centeraDesignImpl;
    }

    /**
     * Setter method for property <tt>centeraDesignImpl</tt>.
     * 
     * @param centeraDesignImpl
     *            value to be assigned to property centeraDesignImpl
     */
    public void setCenteraDesignImpl(boolean centeraDesignImpl) {
        this.centeraDesignImpl = centeraDesignImpl;
    }

    /**
     * Getter method for property <tt>atmosDesignImpl</tt>.
     * 
     * @return property value of atmosDesignImpl
     */
    public boolean isAtmosDesignImpl() {
        return atmosDesignImpl;
    }

    /**
     * Setter method for property <tt>atmosDesignImpl</tt>.
     * 
     * @param atmosDesignImpl
     *            value to be assigned to property atmosDesignImpl
     */
    public void setAtmosDesignImpl(boolean atmosDesignImpl) {
        this.atmosDesignImpl = atmosDesignImpl;
    }

    /**
     * Getter method for property <tt>centeraToAtmosMig</tt>.
     * 
     * @return property value of centeraToAtmosMig
     */
    public boolean isCenteraToAtmosMig() {
        return centeraToAtmosMig;
    }

    /**
     * Setter method for property <tt>centeraToAtmosMig</tt>.
     * 
     * @param centeraToAtmosMig
     *            value to be assigned to property centeraToAtmosMig
     */
    public void setCenteraToAtmosMig(boolean centeraToAtmosMig) {
        this.centeraToAtmosMig = centeraToAtmosMig;
    }

    /**
     * Getter method for property <tt>acdp</tt>.
     * 
     * @return property value of acdp
     */
    public boolean isAcdp() {
        return acdp;
    }

    /**
     * Setter method for property <tt>acdp</tt>.
     * 
     * @param acdp
     *            value to be assigned to property acdp
     */
    public void setAcdp(boolean acdp) {
        this.acdp = acdp;
    }

    /**
     * Getter method for property <tt>cva</tt>.
     * 
     * @return property value of cva
     */
    public boolean isCva() {
        return cva;
    }

    /**
     * Setter method for property <tt>cva</tt>.
     * 
     * @param cva
     *            value to be assigned to property cva
     */
    public void setCva(boolean cva) {
        this.cva = cva;
    }

    /**
     * Getter method for property <tt>cua</tt>.
     * 
     * @return property value of cua
     */
    public boolean isCua() {
        return cua;
    }

    /**
     * Setter method for property <tt>cua</tt>.
     * 
     * @param cua
     *            value to be assigned to property cua
     */
    public void setCua(boolean cua) {
        this.cua = cua;
    }

    /**
     * Getter method for property <tt>cicm</tt>.
     * 
     * @return property value of cicm
     */
    public boolean isCicm() {
        return cicm;
    }

    /**
     * Setter method for property <tt>cicm</tt>.
     * 
     * @param cicm
     *            value to be assigned to property cicm
     */
    public void setCicm(boolean cicm) {
        this.cicm = cicm;
    }

    /**
     * Getter method for property <tt>centeraFileErasure</tt>.
     * 
     * @return property value of centeraFileErasure
     */
    public boolean isCenteraFileErasure() {
        return centeraFileErasure;
    }

    /**
     * Setter method for property <tt>centeraFileErasure</tt>.
     * 
     * @param centeraFileErasure
     *            value to be assigned to property centeraFileErasure
     */
    public void setCenteraFileErasure(boolean centeraFileErasure) {
        this.centeraFileErasure = centeraFileErasure;
    }

    /**
     * Getter method for property <tt>expansionNodeOnly</tt>.
     * 
     * @return property value of expansionNodeOnly
     */
    public boolean isExpansionNodeOnly() {
        return expansionNodeOnly;
    }

    /**
     * Setter method for property <tt>expansionNodeOnly</tt>.
     * 
     * @param expansionNodeOnly
     *            value to be assigned to property expansionNodeOnly
     */
    public void setExpansionNodeOnly(boolean expansionNodeOnly) {
        this.expansionNodeOnly = expansionNodeOnly;
    }

}

/*
 * This code is copyright (c) 2014 EMC Corporation.
 */
package com.emc.gs.tools.srf.services.estimate.dto;

import java.math.BigDecimal;

/**
 * <p>
 * This is PricingOverview DTO class.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safety.
 * </p>
 * 
 * @author TCSASSEMBLER
 * @version 1.0
 * @since SRT Phase 4 - ET Assembly 1
 */
public class PricingOverview {

    /**
     * Services Fees @ Standard.
     */
    private BigDecimal servicesFees = BigDecimal.ZERO;

    /**
     * Less Discount.
     */
    private BigDecimal discount = BigDecimal.ZERO;

    /**
     * Total Fees.
     */
    private BigDecimal totalFees = BigDecimal.ZERO;

    /**
     * Expense Recovery.
     */
    private BigDecimal expenseRecovery = BigDecimal.ZERO;

    /**
     * Total Revenue.
     */
    private BigDecimal totalRevenue = BigDecimal.ZERO;

    /**
     * Cost of Services.
     */
    private BigDecimal servicesCost = BigDecimal.ZERO;

    /**
     * Cost of Expenses.
     */
    private BigDecimal expensesCost = BigDecimal.ZERO;

    /**
     * Total Gross Margin.
     */
    private BigDecimal totalGrossMargin = BigDecimal.ZERO;

    /**
     * Total Gross Margin %.
     */
    private BigDecimal totalGrossMarginPercent = BigDecimal.ZERO;

    /**
     * IP Amount.
     */
    private BigDecimal ipAmount = BigDecimal.ZERO;

    /**
     * Edu Amount.
     */
    private BigDecimal eduAmount = BigDecimal.ZERO;

    /**
     * Total Gross Margin w/IP/EDU.
     */
    private BigDecimal totalGrossMarginWithIpEdu = BigDecimal.ZERO;

    /**
     * Grand Total.
     */
    private BigDecimal grandTotal = BigDecimal.ZERO;

    /**
     * Fee-only margin%.
     */
    private BigDecimal feeOnlyMarginPercent = BigDecimal.ZERO;

    /**
     * Discount Only %.
     */
    private BigDecimal discountOnlyPercent = BigDecimal.ZERO;

    /**
     * Billable Expense as % Fees.
     */
    private BigDecimal billableExpensePercent = BigDecimal.ZERO;

    /**
     * Margin loss due to Expense Cap.
     */
    private BigDecimal marginLossPercent = BigDecimal.ZERO;

    /**
     * Total Work Effort in Days.
     */
    private BigDecimal totalDays = BigDecimal.ZERO;

    /**
     * Total Work Effort in Hours.
     */
    private BigDecimal totalHours = BigDecimal.ZERO;

    /**
     * Avg Daily Rate (ADR) fees only.
     */
    private BigDecimal adrFees = BigDecimal.ZERO;

    /**
     * Avg Daily Rate (ADR) all Revenue.
     */
    private BigDecimal adrRevenue = BigDecimal.ZERO;

    /**
     * Avg Hourly Rate (AHR) Fees only.
     */
    private BigDecimal ahrFees = BigDecimal.ZERO;

    /**
     * Avg Hourly Rate (AHR) all Revenue.
     */
    private BigDecimal ahrRevenue = BigDecimal.ZERO;

    /**
     * Empty constructor.
     */
    public PricingOverview() {
    }

    /**
     * Getter method for property <tt>servicesFees</tt>.
     * 
     * @return property value of servicesFees
     */
    public BigDecimal getServicesFees() {
        return servicesFees;
    }

    /**
     * Setter method for property <tt>servicesFees</tt>.
     * 
     * @param servicesFees
     *            value to be assigned to property servicesFees
     */
    public void setServicesFees(BigDecimal servicesFees) {
        this.servicesFees = servicesFees;
    }

    /**
     * Getter method for property <tt>discount</tt>.
     * 
     * @return property value of discount
     */
    public BigDecimal getDiscount() {
        return discount;
    }

    /**
     * Setter method for property <tt>discount</tt>.
     * 
     * @param discount
     *            value to be assigned to property discount
     */
    public void setDiscount(BigDecimal discount) {
        this.discount = discount;
    }

    /**
     * Getter method for property <tt>totalFees</tt>.
     * 
     * @return property value of totalFees
     */
    public BigDecimal getTotalFees() {
        return totalFees;
    }

    /**
     * Setter method for property <tt>totalFees</tt>.
     * 
     * @param totalFees
     *            value to be assigned to property totalFees
     */
    public void setTotalFees(BigDecimal totalFees) {
        this.totalFees = totalFees;
    }

    /**
     * Getter method for property <tt>expenseRecovery</tt>.
     * 
     * @return property value of expenseRecovery
     */
    public BigDecimal getExpenseRecovery() {
        return expenseRecovery;
    }

    /**
     * Setter method for property <tt>expenseRecovery</tt>.
     * 
     * @param expenseRecovery
     *            value to be assigned to property expenseRecovery
     */
    public void setExpenseRecovery(BigDecimal expenseRecovery) {
        this.expenseRecovery = expenseRecovery;
    }

    /**
     * Getter method for property <tt>totalRevenue</tt>.
     * 
     * @return property value of totalRevenue
     */
    public BigDecimal getTotalRevenue() {
        return totalRevenue;
    }

    /**
     * Setter method for property <tt>totalRevenue</tt>.
     * 
     * @param totalRevenue
     *            value to be assigned to property totalRevenue
     */
    public void setTotalRevenue(BigDecimal totalRevenue) {
        this.totalRevenue = totalRevenue;
    }

    /**
     * Getter method for property <tt>servicesCost</tt>.
     * 
     * @return property value of servicesCost
     */
    public BigDecimal getServicesCost() {
        return servicesCost;
    }

    /**
     * Setter method for property <tt>servicesCost</tt>.
     * 
     * @param servicesCost
     *            value to be assigned to property servicesCost
     */
    public void setServicesCost(BigDecimal servicesCost) {
        this.servicesCost = servicesCost;
    }

    /**
     * Getter method for property <tt>expensesCost</tt>.
     * 
     * @return property value of expensesCost
     */
    public BigDecimal getExpensesCost() {
        return expensesCost;
    }

    /**
     * Setter method for property <tt>expensesCost</tt>.
     * 
     * @param expensesCost
     *            value to be assigned to property expensesCost
     */
    public void setExpensesCost(BigDecimal expensesCost) {
        this.expensesCost = expensesCost;
    }

    /**
     * Getter method for property <tt>totalGrossMargin</tt>.
     * 
     * @return property value of totalGrossMargin
     */
    public BigDecimal getTotalGrossMargin() {
        return totalGrossMargin;
    }

    /**
     * Setter method for property <tt>totalGrossMargin</tt>.
     * 
     * @param totalGrossMargin
     *            value to be assigned to property totalGrossMargin
     */
    public void setTotalGrossMargin(BigDecimal totalGrossMargin) {
        this.totalGrossMargin = totalGrossMargin;
    }

    /**
     * Getter method for property <tt>totalGrossMarginPercent</tt>.
     * 
     * @return property value of totalGrossMarginPercent
     */
    public BigDecimal getTotalGrossMarginPercent() {
        return totalGrossMarginPercent;
    }

    /**
     * Setter method for property <tt>totalGrossMarginPercent</tt>.
     * 
     * @param totalGrossMarginPercent
     *            value to be assigned to property totalGrossMarginPercent
     */
    public void setTotalGrossMarginPercent(BigDecimal totalGrossMarginPercent) {
        this.totalGrossMarginPercent = totalGrossMarginPercent;
    }

    /**
     * Getter method for property <tt>ipAmount</tt>.
     * 
     * @return property value of ipAmount
     */
    public BigDecimal getIpAmount() {
        return ipAmount;
    }

    /**
     * Setter method for property <tt>ipAmount</tt>.
     * 
     * @param ipAmount
     *            value to be assigned to property ipAmount
     */
    public void setIpAmount(BigDecimal ipAmount) {
        this.ipAmount = ipAmount;
    }

    /**
     * Getter method for property <tt>eduAmount</tt>.
     * 
     * @return property value of eduAmount
     */
    public BigDecimal getEduAmount() {
        return eduAmount;
    }

    /**
     * Setter method for property <tt>eduAmount</tt>.
     * 
     * @param eduAmount
     *            value to be assigned to property eduAmount
     */
    public void setEduAmount(BigDecimal eduAmount) {
        this.eduAmount = eduAmount;
    }

    /**
     * Getter method for property <tt>totalGrossMarginWithIpEdu</tt>.
     * 
     * @return property value of totalGrossMarginWithIpEdu
     */
    public BigDecimal getTotalGrossMarginWithIpEdu() {
        return totalGrossMarginWithIpEdu;
    }

    /**
     * Setter method for property <tt>totalGrossMarginWithIpEdu</tt>.
     * 
     * @param totalGrossMarginWithIpEdu
     *            value to be assigned to property totalGrossMarginWithIpEdu
     */
    public void setTotalGrossMarginWithIpEdu(BigDecimal totalGrossMarginWithIpEdu) {
        this.totalGrossMarginWithIpEdu = totalGrossMarginWithIpEdu;
    }

    /**
     * Getter method for property <tt>grandTotal</tt>.
     * 
     * @return property value of grandTotal
     */
    public BigDecimal getGrandTotal() {
        return grandTotal;
    }

    /**
     * Setter method for property <tt>grandTotal</tt>.
     * 
     * @param grandTotal
     *            value to be assigned to property grandTotal
     */
    public void setGrandTotal(BigDecimal grandTotal) {
        this.grandTotal = grandTotal;
    }

    /**
     * Getter method for property <tt>feeOnlyMarginPercent</tt>.
     * 
     * @return property value of feeOnlyMarginPercent
     */
    public BigDecimal getFeeOnlyMarginPercent() {
        return feeOnlyMarginPercent;
    }

    /**
     * Setter method for property <tt>feeOnlyMarginPercent</tt>.
     * 
     * @param feeOnlyMarginPercent
     *            value to be assigned to property feeOnlyMarginPercent
     */
    public void setFeeOnlyMarginPercent(BigDecimal feeOnlyMarginPercent) {
        this.feeOnlyMarginPercent = feeOnlyMarginPercent;
    }

    /**
     * Getter method for property <tt>discountOnlyPercent</tt>.
     * 
     * @return property value of discountOnlyPercent
     */
    public BigDecimal getDiscountOnlyPercent() {
        return discountOnlyPercent;
    }

    /**
     * Setter method for property <tt>discountOnlyPercent</tt>.
     * 
     * @param discountOnlyPercent
     *            value to be assigned to property discountOnlyPercent
     */
    public void setDiscountOnlyPercent(BigDecimal discountOnlyPercent) {
        this.discountOnlyPercent = discountOnlyPercent;
    }

    /**
     * Getter method for property <tt>billableExpensePercent</tt>.
     * 
     * @return property value of billableExpensePercent
     */
    public BigDecimal getBillableExpensePercent() {
        return billableExpensePercent;
    }

    /**
     * Setter method for property <tt>billableExpensePercent</tt>.
     * 
     * @param billableExpensePercent
     *            value to be assigned to property billableExpensePercent
     */
    public void setBillableExpensePercent(BigDecimal billableExpensePercent) {
        this.billableExpensePercent = billableExpensePercent;
    }

    /**
     * Getter method for property <tt>marginLossPercent</tt>.
     * 
     * @return property value of marginLossPercent
     */
    public BigDecimal getMarginLossPercent() {
        return marginLossPercent;
    }

    /**
     * Setter method for property <tt>marginLossPercent</tt>.
     * 
     * @param marginLossPercent
     *            value to be assigned to property marginLossPercent
     */
    public void setMarginLossPercent(BigDecimal marginLossPercent) {
        this.marginLossPercent = marginLossPercent;
    }

    /**
     * Getter method for property <tt>totalDays</tt>.
     * 
     * @return property value of totalDays
     */
    public BigDecimal getTotalDays() {
        return totalDays;
    }

    /**
     * Setter method for property <tt>totalDays</tt>.
     * 
     * @param totalDays
     *            value to be assigned to property totalDays
     */
    public void setTotalDays(BigDecimal totalDays) {
        this.totalDays = totalDays;
    }

    /**
     * Getter method for property <tt>totalHours</tt>.
     * 
     * @return property value of totalHours
     */
    public BigDecimal getTotalHours() {
        return totalHours;
    }

    /**
     * Setter method for property <tt>totalHours</tt>.
     * 
     * @param totalHours
     *            value to be assigned to property totalHours
     */
    public void setTotalHours(BigDecimal totalHours) {
        this.totalHours = totalHours;
    }

    /**
     * Getter method for property <tt>adrFees</tt>.
     * 
     * @return property value of adrFees
     */
    public BigDecimal getAdrFees() {
        return adrFees;
    }

    /**
     * Setter method for property <tt>adrFees</tt>.
     * 
     * @param adrFees
     *            value to be assigned to property adrFees
     */
    public void setAdrFees(BigDecimal adrFees) {
        this.adrFees = adrFees;
    }

    /**
     * Getter method for property <tt>adrRevenue</tt>.
     * 
     * @return property value of adrRevenue
     */
    public BigDecimal getAdrRevenue() {
        return adrRevenue;
    }

    /**
     * Setter method for property <tt>adrRevenue</tt>.
     * 
     * @param adrRevenue
     *            value to be assigned to property adrRevenue
     */
    public void setAdrRevenue(BigDecimal adrRevenue) {
        this.adrRevenue = adrRevenue;
    }

    /**
     * Getter method for property <tt>ahrFees</tt>.
     * 
     * @return property value of ahrFees
     */
    public BigDecimal getAhrFees() {
        return ahrFees;
    }

    /**
     * Setter method for property <tt>ahrFees</tt>.
     * 
     * @param ahrFees
     *            value to be assigned to property ahrFees
     */
    public void setAhrFees(BigDecimal ahrFees) {
        this.ahrFees = ahrFees;
    }

    /**
     * Getter method for property <tt>ahrRevenue</tt>.
     * 
     * @return property value of ahrRevenue
     */
    public BigDecimal getAhrRevenue() {
        return ahrRevenue;
    }

    /**
     * Setter method for property <tt>ahrRevenue</tt>.
     * 
     * @param ahrRevenue
     *            value to be assigned to property ahrRevenue
     */
    public void setAhrRevenue(BigDecimal ahrRevenue) {
        this.ahrRevenue = ahrRevenue;
    }

}

/*
 * This code is copyright (c) 2014 EMC Corporation.
 */
package com.emc.gs.tools.srf.services;

import java.lang.annotation.*;


/**
 * <p>
 * The annotation to turn on synchronization up.
 * </p>
 *
 * @author TCSASSEMBLER
 * @version 1.0
 * @since SRT Phase 4 - ET Assembly 2
 */
@Documented
@Retention(value = RetentionPolicy.RUNTIME)
@Target(value = ElementType.METHOD)
public @interface SyncUp {

    /**
     * The entity type.
     */
    String entityType();
}

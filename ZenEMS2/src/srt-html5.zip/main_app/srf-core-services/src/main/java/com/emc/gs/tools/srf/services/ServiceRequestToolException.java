/*
 * This code is copyright (c) 2013 - 2014 EMC Corporation.
 */
package com.emc.gs.tools.srf.services;

/**
 * <p>
 * This exception is thrown when there is any problem when working with application general services.
 * </p>
 *
 * <p>
 * <strong>Thread safety</strong>: exception class is not thread safety.
 * </p>
 *
 * @author faeton, stevenfrog
 * @version 1.0
 */
public class ServiceRequestToolException extends Exception {
    /**
     * The serial version UID.
     */
    private static final long serialVersionUID = -8346467240096164290L;

    /**
     * Creates the exception with the provided message.
     *
     * @param message
     *            the error message.
     */
    public ServiceRequestToolException(String message) {
        super(message);
    }

    /**
     * Creates the exception with the provided message and cause.
     *
     * @param message
     *            the error message.
     * @param cause
     *            the error cause.
     */
    public ServiceRequestToolException(String message, Throwable cause) {
        super(message, cause);
    }
}

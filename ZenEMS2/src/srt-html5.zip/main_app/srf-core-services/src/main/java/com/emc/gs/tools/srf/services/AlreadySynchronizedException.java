/*
 * This code is copyright (c) 2014 EMC Corporation.
 */
package com.emc.gs.tools.srf.services;

import com.emc.gs.tools.srf.model.SynchronizedOperationLog;

/**
 * <p>
 * This exception is thrown if an operation log is already synchronized.
 * </p>
 *
 * <p>
 * <strong>Thread safety</strong>: exception class is not thread safety.
 * </p>
 *
 * @author TCSASSEMBLER
 * @version 1.0
 * @since SRT Phase 4 - ET Assembly 2
 */
public class AlreadySynchronizedException extends ServiceRequestToolException {

    /**
     * The serial version UID.
     */
    private static final long serialVersionUID = -6415308661222774548L;

    /**
     * The synchronized operation log.
     */
    private final SynchronizedOperationLog synchronizedLog;

    /**
     * Creates the exception with the provided message and synchronized operation log.
     *
     * @param synchronizedLog
     *            the synchronized operation log.
     * @param message
     *            the error message.
     */
    public AlreadySynchronizedException(SynchronizedOperationLog synchronizedLog, String message) {
        super(message);
        this.synchronizedLog = synchronizedLog;
    }

    /**
     * Getter method for property <tt>synchronizedLog</tt>.
     *
     * @return property value of synchronizedLog
     */
    public SynchronizedOperationLog getSynchronizedLog() {
        return synchronizedLog;
    }

}

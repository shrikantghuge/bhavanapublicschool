/*
 * This code is copyright (c) 2014-2015 EMC Corporation.
 */
package com.emc.gs.tools.srf.services.impl;

import static com.emc.gs.tools.srf.services.impl.Helper.HUNDRED;
import static com.emc.gs.tools.srf.services.impl.Helper.getLookupCode;
import static com.emc.gs.tools.srf.services.impl.Helper.lookupEntity2String;
import static com.emc.gs.tools.srf.services.impl.Helper.trimToEmpty;

import java.io.OutputStream;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.annotation.PostConstruct;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;

import com.emc.gs.tools.srf.model.ExpenseType;
import com.emc.gs.tools.srf.model.estimate.Competency;
import com.emc.gs.tools.srf.model.estimate.IPEDUOption;
import com.emc.gs.tools.srf.model.estimate.IPEDURecord;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.time.DateUtils;
import org.apache.log4j.Logger;

import com.emc.gs.tools.srf.ServiceRequestToolConfigurationException;
import com.emc.gs.tools.srf.model.Customer;
import com.emc.gs.tools.srf.model.CustomerSearchCriteria;
import com.emc.gs.tools.srf.model.CustomerWorkSite;
import com.emc.gs.tools.srf.model.Request;
import com.emc.gs.tools.srf.model.ServiceContext;
import com.emc.gs.tools.srf.model.StartRequestData;
import com.emc.gs.tools.srf.model.engagement.EngagementTypeData;
import com.emc.gs.tools.srf.model.estimate.DealCurrency;
import com.emc.gs.tools.srf.model.estimate.EstimatesData;
import com.emc.gs.tools.srf.model.estimate.LOBCountry;
import com.emc.gs.tools.srf.model.estimate.LOBLookupData;
import com.emc.gs.tools.srf.model.estimate.ProjectStaff;
import com.emc.gs.tools.srf.model.estimate.WBS;
import com.emc.gs.tools.srf.services.CustomerService;
import com.emc.gs.tools.srf.services.EstimatesService;
import com.emc.gs.tools.srf.services.ExportServiceException;
import com.emc.gs.tools.srf.services.LookupService;
import com.emc.gs.tools.srf.services.RatesService;
import com.emc.gs.tools.srf.services.ServiceRequestToolException;
import com.emc.gs.tools.srf.services.estimate.dto.EstimatedLOB;
import com.emc.gs.tools.srf.services.estimate.dto.EstimatedResource;
import com.emc.gs.tools.srf.services.estimate.dto.EstimatedResult;
import com.emc.gs.tools.srf.services.estimate.dto.PricingOverview;
import com.emc.gs.tools.srf.services.estimate.jaxb.MonthlyEffort;
import com.emc.gs.tools.srf.services.estimate.jaxb.PSProject;
import com.emc.gs.tools.srf.services.estimate.jaxb.Role;
import com.emc.gs.tools.srf.services.estimate.jaxb.RolePFP;
import com.emc.gs.tools.srf.services.estimate.jaxb.RoleSkillSet;
import com.emc.gs.tools.srf.services.estimate.jaxb.Roles;
import com.emc.gs.tools.srf.services.estimate.jaxb.WBSRecord;
import com.emc.gs.tools.srf.services.estimate.jaxb.WBSRecords;

/**
 * <p>
 * This is the implementation of EstimatesService.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is thread safe. The inner cache in suitable for concurrent access.
 * </p>
 *
 * <p>
 * Version 1.1 (SRT Phase 4 - ET Release Assembly) Change notes:
 *   <ol>
 *     <li>Updated {@link #convertToPsProject(Request)} method to copy newly defined "projectRegulatoryType", 
 *     "oraclePartyID" properties of request.</li>
 *   </ol>
 * </p>
 * 
 * <p>
 * Version 1.2 (SRT 1.1 DEC 2014 Updates Assembly) Change notes:
 *   <ol>
 *     <li>Updated {@link #convertToPsProject(Request)} and 
 *     {@link #com.emc.gs.tools.srf.services.impl.EstimatesServiceImpl.convertToWBSRecord(EstimatedLOB, 
 *     EstimatedResult, String, String, String)} methods to modify/include some new fields in the export.</li>
 *     <li>Added ET, EXPENSE_CONTRACT_TYPE, MS_LOB_NAME, EXPENSE_RECORD_TYPE, EXPENSE_RECORD_TNM_FLAG, 
 *     EXPENSE_ROLE_NAME, EXPENSE_ROLE_NO_OF_CONS, EXPENSE_ROLE_ROLE_LIST_PRICE, EXPENSE_ROLE_ROLE_COST, and 
 *     EXPENSE_ROLE_ROLE_SELLING_PRICE constants.</li>
 *     <li>Added customerService field.</li>
 *     <li>Added {@link #convertToExpenseWBSRecord(EstimatedResult, String, String, String)} method.</li>
 *     <li>Added {@link #convertToMSExpenseWBSRecords(EstimatedResult, String, String, String)} method.</li>
 *     <li>Added {@link #getExpenseToRole(String, String, Date, String, String)} method.</li>
 *   </ol>
 * </p>
 *
 * <p>
 * Version 1.3 Change notes:
 *   <ol>
 *     <li>Updated {@link #convertToPsProject(Request)} method to set <code>ZzprojectDesc</code> field with project
 *     description.</li>
 *   </ol>
 * </p>
 *
 * <p>
 * Version 1.4 Change notes:
 *   <ol>
 *     <li>Updated {@link #calculateResourceFee(EstimatedResource, EstimatedLOB, LOBCountry, EstimatedResult)} method
 *     to set resource's standard cost with 0 if hourly standard rate is unavailable.</li>
 *     <li>Updated {@link #convertToRole(EstimatedResource, EstimatedLOB)} method to evaluate RoleListPrice based on
 *     Standard Bill Rate and evaluate RoleSellingPrice in same way.</li>
 *   </ol>
 * </p>
 *
 * <p>
 * Version 1.5 Change notes:
 *   <ol>
 *     <li>QuoteLineItemID is always empty.</li>
 *     <li>RequestingCountryID is set with Booking Country code but not country code from customer work site.</li>
 *     <li>Set empty RoleSkillSet for Expense WBS record.</li>
 *   </ol>
 * </p>
 *
 * <p>
 * Version 1.6 Change notes:
 *   <ol>
 *     <li>Changed the visibility of some fields/methods to be re-used in export service.</li>
 *   </ol>
 * </p>
 *
 * <p>
 * Version 1.7 Change notes:
 *   <ol>
 *     <li>Updated {@link #convertToExpenseWBSRecord(EstimatedResult, String, String, String, String, boolean)} method
 *     to set ZwbsNumber field for Expense record.</li>
 *   </ol>
 * </p>
 *
 * <p>
 * Version 1.7 Change notes:
 *   <ol>
 *     <li>Fixed bug in {@link #convertToPsProject(Request)} method with matching work cities to customer site.</li>
 *     <li>Set <code>QuoteLineItemID</code> field for WBS records.</li>
 *   </ol>
 * </p>
 *
 * <p>
 * Version 1.8 Change notes:
 *   <ol>
 *     <li>Set <code>ZzpssowNumber</code> and <code>ZzcontractNumber</code> fields of <code>PSProject</code>.</li>
 *     <li>Updated calculation logic for <code>RoleListPrice</code> and <code>RoleSellingPrice</code> XML fields.</li>
 *     <li>IP/EDU amounts are properly calculated.</li>
 *     <li>Expense Cost and Expense Recovery are calculated as 0 if Expense Type is None.</li>
 *     <li>Fixed a bug with setting QuoteLineItemID in {@link #convertToMSExpenseWBSRecords} method.</li>
 *     <li>Updated {@link #convertToMSExpenseWBSRecords} method to set QuoteLineItemID just for record with highest 
 *     expense.</li>
 *   </ol>
 * </p>
 * 
 * @author TCSASSEMBLER, isv, MonicaMuranyi
 * @version 1.8
 * @since SRT Phase 4 - ET Assembly 1
 */
public class EstimatesServiceImpl extends BaseLoggerService implements EstimatesService {

    /**
     * <p>
     * Represents the class name.
     * </p>
     */
    private static final String CLASSNAME = EstimatesServiceImpl.class.getName();

    /**
     * The default date format.
     */
    private static final String DEFAULT_DATE_FORMAT = "yyyy-MM-dd";

    /**
     * Work hours per one day.
     */
    private static final BigDecimal WORK_HOURS_PER_DAY = new BigDecimal(8);

    /**
     * Estimation tool abbreviation.
     */
    public static final String ET = "ET";

    /**
     * Service Request Tool abbreviation.
     * 
     * @since 1.3
     */
    public static final String SRT = "SRT";

    /**
     * The value to export as <ContractType> for the expense record.
     */
    public static final String EXPENSE_CONTRACT_TYPE = "05";
    
    /**
     * The value to export as <Type> for the expense record.
     */
    public static final String EXPENSE_RECORD_TYPE = "2";
    
    /**
     * The value to export as <TnmFlag> for the expense record.
     */
    public static final String EXPENSE_RECORD_TNM_FLAG = "N";
    
    /**
     * The expense role name.
     */
    public static final String EXPENSE_ROLE_NAME = "Expense";
    
    /**
     * The value to export as <NoOfCons> for the expense role record.
     */
    public static final String EXPENSE_ROLE_NO_OF_CONS = "1";
    
    /**
     * The value to export as <RoleListPrice> for the expense role record.
     */
    public static final String EXPENSE_ROLE_ROLE_LIST_PRICE = "1";

    /**
     * The value to export as <RoleCost> for the expense role record.
     */
    public static final String EXPENSE_ROLE_ROLE_COST = "1";
    
    /**
     * The value to export as <RoleSellingPrice> for the expense role record.
     */
    public static final String EXPENSE_ROLE_ROLE_SELLING_PRICE = "1";
    
    /**
     * The MS lob name.
     */
    public static final String MS_LOB_NAME = "MS";
    
    /**
     * Represents the LookupService instance for retrieving lookup data. It is modified by setter. It is injected by
     * Spring. It can not be null after injected.
     */
    private LookupService lookupService;

    /**
     * Represents the RatesService instance for retrieving rates data. It is modified by setter. It is injected by
     * Spring. It can not be null after injected.
     */
    private RatesService ratesService;
    
    /**
     * Represents the CustomerService instance for retrieving customer data. It is modified by setter. It is injected by
     * Spring. It can not be null after injected.
     */
    private CustomerService customerService;

    /**
     * Empty constructor.
     */
    public EstimatesServiceImpl() {
    }

    /**
     * Exports SRT4 path request to XML.
     * 
     * @param request
     *            A SRT4 path request.
     * @param stream
     *            the output stream
     * @throws IllegalArgumentException
     *             if any argument is null.
     * @throws ExportServiceException
     *             if there is any problem when performing operation.
     */
    public void exportRequest(Request request, OutputStream stream) throws ExportServiceException {
        final String signature = CLASSNAME + "#exportRequest(Request request, OutputStream stream)";
        Logger logger = getLogger();

        // Log entry
        Helper.logEntrance(logger, signature, new String[] {"request"}, new Object[] {request});

        Helper.checkNull(logger, signature, request, "request");
        Helper.checkNull(logger, signature, stream, "stream");

        try {
            // Convert entity
            PSProject project = convertToPsProject(request);

            // Marshal XML
            JAXBContext context = JAXBContext.newInstance(PSProject.class);
            Marshaller marshaller = context.createMarshaller();
            marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
            marshaller.marshal(project, stream);

            // Log exit
            Helper.logExit(logger, signature, null);
        } catch (JAXBException e) {
            // Log exception
            throw Helper.logException(logger, signature, new ExportServiceException("Export error occurs.", e));
        } catch (ServiceRequestToolException e) {
            // Log exception
            throw Helper.logException(logger, signature, new ExportServiceException("Service error occurs.", e));
        }
    }

    /**
     * Convert request to PSProject.
     * 
     * @param request
     *            the request to convert.
     * @return converted PSProject
     * @throws ServiceRequestToolException
     *             if error occurs when estimating request.
     */
    private PSProject convertToPsProject(Request request) throws ServiceRequestToolException {

        // Not populated:
        //  CustomerId
        //  ProjectFinancialAdministrator
        //  CemId
        //  ProjectAccountant
        //  ProjectResourceManager
        //  ZzpresalesRfDesc

        PSProject project = new PSProject();

        String userIdentifier = ServiceContext.getCurrentUser().getUserIdentifier();
        project.setOwnerName(userIdentifier);
        project.setDatafrom(SRT);
        project.setZmultiTool("N");
        project.setZprojType(getLookupCode(request.getProjectType()));
        project.setProjectRegulatoryType(getLookupCode(request.getProjectRegulatoryType()));
        project.setPresalesOwnerId(userIdentifier);
        
        StartRequestData startRequestData = request.getStartRequestData();
        boolean expensesIncluded = false;
        if (startRequestData != null) {
            project.setName(trimToEmpty(startRequestData.getCustomerName()));
            if (startRequestData.getOraclePartyID() != null) {
                project.setCustomerId(trimToEmpty(String.valueOf(startRequestData.getOraclePartyID())));
            } else {
                project.setCustomerId("");
            }
            project.setCustomerName(trimToEmpty(startRequestData.getCustomerName()));
            project.setProjectPM(trimToEmpty(startRequestData.getPmName()));
            project.setZquoteno(trimToEmpty(startRequestData.getDxQuoteNumber()));
            project.setZoppnumber(trimToEmpty(startRequestData.getSfdcNumber()));
            project.setZzpresalesRf(getLookupCode(startRequestData.getRiskLevel()));
            expensesIncluded = (startRequestData.getExpenseType() != null) 
                && (startRequestData.getExpenseType().getId() == 1);
        }

        EstimatesData estimatesData = request.getEstimatesData();

        if (estimatesData != null) {
            project.setZzpssowNumber(estimatesData.getSowNumber());
            project.setZzcontractNumber(estimatesData.getContractNumber());
            project.setZapiActivityCode(getLookupCode(estimatesData.getDeliverAction()));
            EngagementTypeData engagementTypeData = request.getEngagementTypeData();
            if(engagementTypeData != null){
                project.setZtheater(getLookupCode(engagementTypeData.getDeliveryCountry().getGeography()));
            }
            project.setDealCurrency(lookupEntity2String(estimatesData.getDealCurrency()));
            project.setZzprojectDesc(trimToEmpty(request.getProjectDescription()));

            EstimatedResult estimatedResult = estimate(request);

            if (estimatedResult.getProjectStartDate() != null) {
                project.setZzpsvalidFrom(new SimpleDateFormat(DEFAULT_DATE_FORMAT).format(estimatedResult
                        .getProjectStartDate()));
            }
            if (estimatedResult.getProjectEndDate() != null) {
                project.setZzpsvalidTo(new SimpleDateFormat(DEFAULT_DATE_FORMAT).format(estimatedResult
                        .getProjectEndDate()));
            }
            if (estimatedResult.getProjectStartDate() != null && estimatedResult.getProjectEndDate() != null) {
                long duration = estimatedResult.getProjectEndDate().getTime()
                        - estimatedResult.getProjectStartDate().getTime();
                project.setZprojDuration(divide(new BigDecimal(duration), new BigDecimal(DateUtils.MILLIS_PER_DAY)).intValue() + "");
            }

            project.setWBSRecords(new WBSRecords());
            CustomerSearchCriteria criteria = new CustomerSearchCriteria();
            criteria.setFormalName(startRequestData.getCustomerName());
            List<Customer> customers = customerService.search(criteria).getValues();
            String countryCode = "";
            String stateCode = "";
            String deliveryCity = "";
            String workCity = startRequestData.getWorkCity().split(",")[0].trim();
            if(!StringUtils.isEmpty(workCity)){
                for (int i = 0; i < customers.size(); i++) {
                    List<CustomerWorkSite> customerWorkSites = customers.get(0).getCustomerWorkSites();
                    boolean siteFound = false;
                    for (int j = 0; j < customerWorkSites.size(); j++) {
                        CustomerWorkSite customerWorkSite = customerWorkSites.get(j);
                        if(workCity.equals(customerWorkSite.getDeliveryCity())){
                            countryCode = getLookupCode(customerWorkSite.getDeliveryCountry());
                            stateCode = getLookupCode(customerWorkSite.getDeliveryRegion());
                            deliveryCity = customerWorkSite.getDeliveryCity();
                            siteFound = true;
                            break;
                        }
                    }
                    if(siteFound){
                        break;
                    }
                }
            }
            
            // Grouped estimated lobs based on their material code
            Map<String, List<EstimatedLOB>> groupedEstimatedLobs = new LinkedHashMap<String, List<EstimatedLOB>>();
            
            boolean msLobExists = false;
            boolean nonMSLobExists = false;
            EstimatedLOB maxFeeLob = null;
            
            List<EstimatedLOB> estimatedLOBs = estimatedResult.getEstimatedLOBs();
            for (EstimatedLOB lob : estimatedLOBs) {
                if (maxFeeLob == null || lob.getStandardFees().compareTo(maxFeeLob.getStandardFees()) == 1) {
                    maxFeeLob = lob;
                }
                if(lob.getLob().getName().equals(MS_LOB_NAME)){
                    msLobExists = true;
                } else {
                    nonMSLobExists = true;
                }
                String key = getLookupCode(lob.getMaterialCode());
                if(groupedEstimatedLobs.containsKey(key)){
                    List<EstimatedLOB> value = groupedEstimatedLobs.get(key);
                    value.add(lob);
                } else {
                    List<EstimatedLOB> value = new ArrayList<EstimatedLOB>();
                    value.add(lob);
                    groupedEstimatedLobs.put(key, value);
                }
            }

            if (maxFeeLob != null) {
                project.setZprimaryCompetencyPs(getLookupCode(maxFeeLob.getCompetency()));
            }


            String deliveryCountryCode = "";
            if(engagementTypeData != null){
                deliveryCountryCode = getLookupCode(engagementTypeData.getDeliveryCountry());
            }
            // Lobs with the same material code will be merged into one WBSRecord
            for (Entry<String, List<EstimatedLOB>> entry : groupedEstimatedLobs.entrySet()) {
                WBSRecord wbsRecord = convertToWBSRecord(entry.getValue(), estimatedResult, deliveryCountryCode,
                    countryCode, stateCode, deliveryCity, expensesIncluded);
                project.getWBSRecords().getWBSRecord().add(wbsRecord);
            }
            // The consolidated expense record for EMC, ECD, and RSA lobs
            if(nonMSLobExists){
                project.getWBSRecords().getWBSRecord().add(convertToExpenseWBSRecord(estimatedResult, deliveryCountryCode, countryCode, stateCode, deliveryCity,
                    expensesIncluded));
            }
            // The separate expense records for MS lobs
            if(msLobExists){
                project.getWBSRecords().getWBSRecord().addAll(convertToMSExpenseWBSRecords(estimatedResult,
                    deliveryCountryCode, countryCode, stateCode, deliveryCity, expensesIncluded));
            }
            
        }
        return project;
    }
    
    /**
     * Convert EstimatedLOB to WBSRecord.
     * 
     *
     * @param estimatedResult
     *            the estimates result containing the LOB. 
     * @param countryCode The primary work site country code
     * @param stateCode The primary work site state code
     * @param workCity The primary work site city
     * @param expensesIncluded <<code>true</code> if expenses included; <code>false</code> otherwise.
     * @return converted WBSRecord
     */
    private WBSRecord convertToWBSRecord(List<EstimatedLOB> lobs, EstimatedResult estimatedResult,
                                         String deliveryCountryCode, String countryCode, String stateCode,
                                         String workCity, boolean expensesIncluded) {

        // Not populated:
        //  ZInterviewer
        //  ProjectPrimedBy
        //  ProjectMgrId
        //  ResourceMgrId
        //  DeliveryOwnerPDM
        //  TnmFlag
        //  ZplannedUnits
        //  Notes
        
        WBSRecord wbsRecord = new WBSRecord();
        wbsRecord.setRoles(new Roles());
        wbsRecord.setOrderProb("N");
        wbsRecord.setResponsibleRmOrg("15");
        wbsRecord.setInclusiveOfExpenses(bool2String(expensesIncluded));
        
        // The index of the lob with the highest standard fees
        int maxFeesLobIdx = 0;
        BigDecimal maxStandardFees = new BigDecimal(0);
        
        BigDecimal totalHours = new BigDecimal(0);
        long startTime = Long.MAX_VALUE;
        long endTime = Long.MIN_VALUE;
        BigDecimal listPrice = new BigDecimal(0);
        BigDecimal discount = new BigDecimal(0);
        BigDecimal sellingPrice = new BigDecimal(0);
        BigDecimal margin = new BigDecimal(0);
        BigDecimal costRate = new BigDecimal(0);
        BigDecimal expenseCap = new BigDecimal(0);
        BigDecimal expensePercent = new BigDecimal(0);
        BigDecimal expenseInCurrencyByModelName = new BigDecimal(0);
        BigDecimal expenseCost = new BigDecimal(0);
        BigDecimal totalCost = new BigDecimal(0);
        
        for (int i = 0; i < lobs.size(); i++) {
            EstimatedLOB lob = lobs.get(i);
            if(lob.getStandardFees().compareTo(maxStandardFees) == 1){
                maxStandardFees = lob.getStandardFees();
                maxFeesLobIdx = i;
            }
            totalHours = totalHours.add(lob.getTotalHours());
            if(lob.getLobStartDate() != null){
                startTime = Math.min(startTime, lob.getLobStartDate().getTime());
            }
            if(lob.getLobEndDate() != null){
                endTime = Math.max(endTime, lob.getLobEndDate().getTime());
            }
            PricingOverview overview = lob.getPricingOverview();
            listPrice = listPrice.add(overview.getServicesFees());
            discount = discount.add(overview.getDiscount().negate());
            sellingPrice = sellingPrice.add(overview.getTotalFees());
            margin = margin.add(overview.getTotalGrossMargin());
            costRate = costRate.add(overview.getServicesCost());
            expenseCap = expenseCap.add(overview.getExpenseRecovery());
            expensePercent = expensePercent.add(overview.getBillableExpensePercent());
            expenseInCurrencyByModelName = expenseInCurrencyByModelName.add(overview.getExpensesCost());
            expenseCost = expenseCost.add(overview.getExpensesCost());
            totalCost = totalCost.add(overview.getTotalFees());
            for (EstimatedResource resource : lob.getEstimatedResources()) {
                Role role = convertToRole(resource, lob);
                role.setRoleListPriceCurrency(lookupEntity2String(estimatedResult.getDealCurrency()));
                role.setRoleCostCurrency(lookupEntity2String(estimatedResult.getDealCurrency()));
                wbsRecord.getRoles().getRole().add(role);
            }
        }
        expensePercent.divide(new BigDecimal(lobs.size()));
        EstimatedLOB maxFeesLob = lobs.get(maxFeesLobIdx);
        wbsRecord.setZprimaryCompetencyWbs(getLookupCode(maxFeesLob.getCompetency())); 

        wbsRecord.setContractType(getLookupCode(maxFeesLob.getBillingType()));
        wbsRecord.setZzcountry(deliveryCountryCode);
        wbsRecord.setTotalBoeHrs(decimal2String(
                estimatedResult.getTotalOverview().getTotalHours(), 2));
        wbsRecord.setRequestingCountryId(deliveryCountryCode);

        if (maxFeesLob.getLob() != null) {
            wbsRecord.setType(getLookupCode(maxFeesLob.getLob()));
        }
        wbsRecord.setZmaterial(getLookupCode(maxFeesLob.getMaterialCode()));
        wbsRecord.setZdlvrycity(workCity);
        wbsRecord.setZdlvrystate(stateCode);
        
        wbsRecord.setZbudghrs(decimal2String(totalHours, 2));
        wbsRecord.setZzwbsValidFrom(startTime == Long.MAX_VALUE ? "" : new SimpleDateFormat(DEFAULT_DATE_FORMAT)
                .format(new Date(startTime)));
        wbsRecord.setZzwbsValidTo(endTime == Long.MIN_VALUE ? "" : new SimpleDateFormat(DEFAULT_DATE_FORMAT)
                .format(new Date(endTime)));
        wbsRecord.setTnmFlag(maxFeesLob.getBillingType().getId() == 1 ? "Y" : "N");
        
        wbsRecord.setListPrice(decimal2String(listPrice, 2));
        wbsRecord.setDiscount(decimal2String(discount, 2));
        wbsRecord.setSellingPrice(decimal2String(sellingPrice, 2));
        wbsRecord.setMargin(decimal2String(margin, 2));
        wbsRecord.setCostRate(decimal2String(costRate, 2));
        wbsRecord.setExpenseCap(decimal2String(expenseCap, 2));
        
        wbsRecord.setExpenseAsPercentage(decimal2String(divide(expenseCost, totalCost).multiply(HUNDRED), 2));
        
        wbsRecord.setExpenseInCurrencyByModelName(decimal2String(expenseInCurrencyByModelName, 2));

        WBS wbs = maxFeesLob.getWbs();
        if (wbs != null) {
            wbsRecord.setQuoteLineItemID(trimToEmpty(wbs.getSalesOrderItemNumber()));
            wbsRecord.setZwbsNumber(trimToEmpty(wbs.getWbsNumber()));
        }
        return wbsRecord;
    }
    
    /**
     * Generates the expense WBSRecord.
     * 
     *
     * @param estimatedResult
     *            the estimates result containing the LOB. 
     * @param countryCode The primary work site country code
     * @param stateCode The primary work site state code
     * @param workCity The primary work site city
     * @param expensesIncluded <code>true</code> if expenses included; <code>false</code> otherwise.
     * @return the expense WBSRecord
     */
    private WBSRecord convertToExpenseWBSRecord(EstimatedResult estimatedResult, String deliveryCountryCode, String 
        countryCode, String stateCode, String workCity, boolean expensesIncluded) {

        // Not populated:
        //  ZInterviewer
        //  ProjectPrimedBy
        //  ProjectMgrId
        //  ResourceMgrId
        //  DeliveryOwnerPDM
        //  ZplannedUnits
        //  Discount
        //  Notes
        
        WBSRecord wbsRecord = new WBSRecord();
        wbsRecord.setContractType(EXPENSE_CONTRACT_TYPE);
        wbsRecord.setOrderProb("N");
        wbsRecord.setResponsibleRmOrg("15");
        wbsRecord.setInclusiveOfExpenses(bool2String(expensesIncluded));
        wbsRecord.setZzcountry(deliveryCountryCode);
        wbsRecord.setRequestingCountryId(deliveryCountryCode);
        wbsRecord.setType(EXPENSE_RECORD_TYPE);
        wbsRecord.setZdlvrycity(workCity);
        wbsRecord.setZdlvrystate(stateCode);
        Date projectStartDate = estimatedResult.getProjectStartDate();
        String validFrom = projectStartDate == null ? "" : new SimpleDateFormat(DEFAULT_DATE_FORMAT)
                .format(projectStartDate);
        wbsRecord.setZzwbsValidFrom(validFrom);
        Date projectEndDate = estimatedResult.getProjectEndDate();
        String validTo = projectEndDate == null ? "" : new SimpleDateFormat(DEFAULT_DATE_FORMAT)
                .format(projectEndDate);
        wbsRecord.setZzwbsValidTo(validTo);
        wbsRecord.setTnmFlag(EXPENSE_RECORD_TNM_FLAG);
        
        BigDecimal expenseCapSum = new BigDecimal(0);
        BigDecimal expensePercent = new BigDecimal(0);
        List<EstimatedLOB> lobs = estimatedResult.getEstimatedLOBs();
        wbsRecord.setZmaterial(lobs.get(0).getMaterialCode().getExpenseModel());

        BigDecimal expenseCost = new BigDecimal(0);
        BigDecimal totalCost = new BigDecimal(0);

        // Scan through all lobs and find LOB with maximum fee and expense WBS Number (which is expected to be set just
        // for a single LOB)
        EstimatedLOB maxFeeLob = null;
        for (int i = 0; i < lobs.size(); i++) {
            EstimatedLOB lob = lobs.get(i);
            PricingOverview overview = lob.getPricingOverview();
            expenseCapSum = expenseCapSum.add(overview.getExpenseRecovery());
            expensePercent = expensePercent.add(overview.getBillableExpensePercent());
            expenseCost = expenseCost.add(overview.getExpensesCost());
            totalCost = totalCost.add(overview.getTotalFees());
            if (maxFeeLob == null || lob.getStandardFees().compareTo(maxFeeLob.getStandardFees()) == 1) {
                maxFeeLob = lob;
            }
            WBS wbs = lob.getWbs();
            if (wbs != null) {
                String expenseWBSNumber = wbs.getExpenseWBSNumber();
                if (expenseWBSNumber != null && expenseWBSNumber.trim().length() > 0) {
                    wbsRecord.setZwbsNumber(expenseWBSNumber);
                }
                String expenseSalesOrderItemNumber = wbs.getExpenseSalesOrderItemNumber();
                if (expenseSalesOrderItemNumber != null && expenseSalesOrderItemNumber.trim().length() > 0) {
                    wbsRecord.setQuoteLineItemID(expenseSalesOrderItemNumber);
                }
            }
        }
        if (maxFeeLob != null) {
            wbsRecord.setZprimaryCompetencyWbs(getLookupCode(maxFeeLob.getCompetency())); 
        }
        
        String expenseCapSum1 = decimal2String(expenseCapSum, 0);
        wbsRecord.setTotalBoeHrs(expenseCapSum1);
        wbsRecord.setZbudghrs(expenseCapSum1);
        String expenseCapSum2 = decimal2String(expenseCapSum, 2);
        wbsRecord.setListPrice(expenseCapSum2);
        wbsRecord.setSellingPrice(expenseCapSum2);
        wbsRecord.setExpenseCap(expenseCapSum2);
        
        wbsRecord.setExpenseAsPercentage(decimal2String(divide(expenseCost, totalCost).multiply(HUNDRED), 2));
        wbsRecord.setExpenseInCurrencyByModelName(expenseCapSum2);
        wbsRecord.setRoles(new Roles());
        String currency = estimatedResult.getDealCurrency().getName();
        wbsRecord.getRoles().getRole().add(getExpenseToRole(decimal2String(expenseCapSum, 1), expenseCapSum2, projectStartDate, validTo, currency));
        return wbsRecord;
    }
    
    /**
     * Generates the MS expense WBSRecords.
     * 
     *
     * @param estimatedResult
     *            the estimates result containing the LOB. 
     * @param countryCode The primary work site country code
     * @param stateCode The primary work site state code
     * @param workCity The primary work site city
     * @param expensesIncluded <code>true</code> if expenses included; <code>false</code> otherwise.
     * @return the expense WBSRecord
     */
    private List<WBSRecord> convertToMSExpenseWBSRecords(EstimatedResult estimatedResult, String deliveryCountryCode,
                                                         String countryCode, String stateCode, String workCity,
                                                         boolean expensesIncluded) {

        // Not populated:
        //  ZInterviewer
        //  ProjectPrimedBy
        //  ProjectMgrId
        //  ResourceMgrId
        //  DeliveryOwnerPDM
        //  ZplannedUnits
        //  Discount
        //  Notes
        
        List<WBSRecord> wbsRecords = new ArrayList<WBSRecord>();
        List<EstimatedLOB> lobs = estimatedResult.getEstimatedLOBs();

        EstimatedLOB maxFeeLob = null;
        String expenseSalesOrderItemNumber = null;
        for (int i = 0; i < lobs.size(); i++) {
            EstimatedLOB lob = lobs.get(i);
            if (lob.getLob().getName().equals(MS_LOB_NAME)) {
            	if (maxFeeLob == null || lob.getStandardFees().compareTo(maxFeeLob.getStandardFees()) == 1) {
                    maxFeeLob = lob;
                }
                WBS wbs = lob.getWbs();
                if (wbs != null) {
                    if (wbs.getExpenseSalesOrderItemNumber() != null 
                        && wbs.getExpenseSalesOrderItemNumber().trim().length() > 0) {
                        expenseSalesOrderItemNumber = wbs.getExpenseSalesOrderItemNumber();
                    }
                }
            }
        }

        for (int i = 0; i < lobs.size(); i++) {
            EstimatedLOB lob = lobs.get(i);
            if(lob.getLob().getName().equals(MS_LOB_NAME)){
                PricingOverview overview = lob.getPricingOverview();
                WBSRecord wbsRecord = new WBSRecord();
                wbsRecord.setOrderProb("N");
                wbsRecord.setResponsibleRmOrg("15");
                wbsRecord.setInclusiveOfExpenses(bool2String(expensesIncluded));
                wbsRecord.setZprimaryCompetencyWbs(getLookupCode(lob.getCompetency())); 
                wbsRecord.setContractType(EXPENSE_CONTRACT_TYPE);
                wbsRecord.setZzcountry(deliveryCountryCode);
                wbsRecord.setRequestingCountryId(deliveryCountryCode);
                wbsRecord.setType(EXPENSE_RECORD_TYPE);
                wbsRecord.setZmaterial(lob.getMaterialCode().getExpenseModel());
                wbsRecord.setZdlvrycity(workCity);
                wbsRecord.setZdlvrystate(stateCode);
                WBS wbs = lob.getWbs();
                if (wbs != null && lob == maxFeeLob) {
                    wbsRecord.setQuoteLineItemID(trimToEmpty(expenseSalesOrderItemNumber));
                    wbsRecord.setZwbsNumber(trimToEmpty(wbs.getWbsNumber()));
                }


                Date projectStartDate = estimatedResult.getProjectStartDate();
                String validFrom = projectStartDate == null ? "" : new SimpleDateFormat(DEFAULT_DATE_FORMAT)
                .format(projectStartDate);
                wbsRecord.setZzwbsValidFrom(validFrom);
                Date projectEndDate = estimatedResult.getProjectEndDate();
                String validTo = projectEndDate == null ? "" : new SimpleDateFormat(DEFAULT_DATE_FORMAT)
                .format(projectEndDate);
                wbsRecord.setZzwbsValidTo(validTo);
                wbsRecord.setTnmFlag(EXPENSE_RECORD_TNM_FLAG);
                
                BigDecimal expenseCapSum = overview.getExpenseRecovery();
                String expenseCapSum1 = decimal2String(expenseCapSum, 0);
                wbsRecord.setTotalBoeHrs(expenseCapSum1);
                wbsRecord.setZbudghrs(expenseCapSum1);
                String expenseCapSum2 = decimal2String(expenseCapSum, 2);
                wbsRecord.setListPrice(expenseCapSum2);
                wbsRecord.setSellingPrice(expenseCapSum2);
                wbsRecord.setExpenseCap(expenseCapSum2);
                wbsRecord.setExpenseAsPercentage(decimal2String(divide(overview.getExpensesCost(), overview.getTotalFees()).multiply(HUNDRED), 2));
                wbsRecord.setExpenseInCurrencyByModelName(expenseCapSum2);
                wbsRecord.setRoles(new Roles());
                String currency = estimatedResult.getDealCurrency().getName();
                wbsRecord.getRoles().getRole().add(getExpenseToRole(decimal2String(expenseCapSum, 1), expenseCapSum2, projectStartDate, validTo, currency));
                wbsRecords.add(wbsRecord);
            }
        }
        return wbsRecords;
    }
    
    /**
     * Generates the WBS role associated with the expense record.
     * @param totalEffort the expense total effort
     * @param hours total hours
     * @param validTo valid from date
     * @param validFrom valid to date as string
     * @param dealCurrency the deal currency
     * 
     * @return expense record WBS role.
     */
    private Role getExpenseToRole(String totalEffort, String hours,  Date validFrom, String validTo, String dealCurrency) {

        // Not populated:
        //  Citizenship
        //  PotentialCandidates
        //  CommentsInternal
        //  CommentsQualifications
        //  SecurityClearance
        //  JobTextId
        //  Competency
        //  CompetencyDesc
        //  ProjectLocation
        //  Zutiltarg
        //  Notes
        //  RoleListPriceScheduleName
        //  RoleCostScheduleName
        //  RemoteWork
        //  ResourceType

        Role role = new Role();
        
        role.setRoleLongDescription(EXPENSE_ROLE_NAME);
        role.setTotalEffort(totalEffort);
        role.setValidFrom(validFrom == null ? "" : new SimpleDateFormat(DEFAULT_DATE_FORMAT)
        .format(validFrom));
        role.setValidTo(validTo);
        role.setNoOfCons(EXPENSE_ROLE_NO_OF_CONS);
        role.setRoleName(EXPENSE_ROLE_NAME);
        role.setRoleListPrice(EXPENSE_ROLE_ROLE_LIST_PRICE);
        role.setRoleListPriceCurrency(dealCurrency);
        role.setRoleCost(EXPENSE_ROLE_ROLE_COST);
        role.setRoleCostCurrency(dealCurrency);
        role.setRoleSellingPrice(EXPENSE_ROLE_ROLE_SELLING_PRICE);
        role.setRolePFP(new RolePFP());
        MonthlyEffort effort = new MonthlyEffort();
        effort.setMonth(new SimpleDateFormat("MM.yyyy").format(validFrom));
        effort.setHours(hours);
        role.getRolePFP().getMonthlyEffort().add(effort);
        role.setRoleSkillSet(new RoleSkillSet());
        return role;
    }


    /**
     * Convert estimated resource to WBS role.
     * 
     * @param resource
     *            the estimated resource to convert.
     * @param lob
     *            the lob containing the resource to convert.
     * @return converted WBS role.
     */
    private Role convertToRole(EstimatedResource resource, EstimatedLOB lob) {

        // Not populated:
        //  JobTextId
        //  RoleListPriceScheduleName
        //  RoleCostScheduleName

        Role role = new Role();

        role.setCompetency(getLookupCode(resource.getCompetency()));
        role.setCompetencyDesc(lookupEntity2String(resource.getCompetency()));
        role.setRoleTypeId(getLookupCode(resource.getRole()));
        String roleName = lookupEntity2String(resource.getRole());
        role.setRoleName(roleName);
        role.setRoleLongDescription(roleName);
        role.setTotalEffort(decimal2String(resource.getBudgetedHours(), 1));

        ProjectStaff staff = resource.getProjectStaff();
        if (staff != null) {
            role.setCitizenship(bool2String(staff.getCitizenshipRequired()));
            role.setSecurityClearance(bool2String(staff.getSecurityClearanceRequired()));
            role.setRemoteWork(bool2String(staff.getRemoteWorkAllowed()));
            role.setCommentsQualifications(trimToEmpty(staff.getSkills()));
            role.setCommentsInternal(trimToEmpty(staff.getAdditionalComments()));
            role.setProjectLocation(trimToEmpty(staff.getWorkLocation()));
            role.setPotentialCandidates(trimToEmpty(staff.getPotentialCandidate()));
            role.setNotes(trimToEmpty(staff.getNotes()));
            role.setResourceType(getLookupCode(staff.getResourceType()));
        }

        role.setValidFrom(resource.getStartDate() == null ? "" : new SimpleDateFormat(DEFAULT_DATE_FORMAT)
                .format(resource.getStartDate()));
        role.setValidTo(resource.getEndDate() == null ? "" : new SimpleDateFormat(DEFAULT_DATE_FORMAT)
                .format(resource.getEndDate()));

        Date firstMonth = resource.getStartDate() == null ? new Date() : resource.getStartDate();
        firstMonth = DateUtils.setDays(firstMonth, 1);

        Integer monthsNum = lob.getMonthsNum();
        if (monthsNum == null) {
            monthsNum = 6;
        }
        Map<Integer, Integer> monthHours = resource.getMonthHours();
        if (monthHours == null) {
            monthHours = Collections.emptyMap();
        }

        role.setRolePFP(new RolePFP());

        for (int i = 1; i <= monthsNum; i++) {
            BigDecimal hours = BigDecimal.ZERO;
            if (monthHours.containsKey(i)) {
                hours = new BigDecimal(monthHours.get(i));
            }
            MonthlyEffort effort = new MonthlyEffort();
            effort.setMonth(new SimpleDateFormat("MM.yyyy").format(DateUtils.addMonths(firstMonth, i - 1)));
            effort.setHours(decimal2String(hours, 2));
            role.getRolePFP().getMonthlyEffort().add(effort);
        }
         
        role.setRoleListPrice(decimal2String(resource.getStandardBillRate(), 2));
        if (resource.getBillRateOverride() != null) {
            role.setRoleSellingPrice(decimal2String(resource.getBillRateOverride(), 2));
        } else {
            role.setRoleSellingPrice(decimal2String(resource.getStandardBillRate(), 2));
        }

        if (!lob.getLob().getName().equalsIgnoreCase("EMC") && resource.getHourlyStdCostRate() != null) {
            role.setRoleCost(decimal2String(resource.getHourlyStdCostRate(), 2));
        } else {
            role.setRoleCost(decimal2String(BigDecimal.ZERO, 2));
        }
        role.setNoOfCons(EXPENSE_ROLE_NO_OF_CONS);
        role.setRoleSkillSet(new RoleSkillSet());
        return role;
    }

    /**
     * Transfer boolean to string.
     * 
     * @param flag
     *            the boolean
     * @return the string
     */
    private static String bool2String(Boolean flag) {
        if (flag == null) {
            return "";
        }
        return flag ? "Y" : "N";
    }

    /**
     * Convert decimal to string.
     * 
     * @param value
     *            the decimal value
     * @param fraction
     *            the fraction digits
     * @return decimal string
     */
    private static String decimal2String(BigDecimal value, int fraction) {
        return Helper.decimal2GroupedString(value, fraction, false);
    }

    /**
     * Estimates request.
     * 
     * @param request
     *            the request to estimate.
     * @return the estimate result DTO. Null is returned if given request does not have estimate data.
     * @throws IllegalArgumentException
     *             if any argument is null.
     * @throws ServiceRequestToolException
     *             if error occurs when estimating request.
     */
    public EstimatedResult estimate(Request request) throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#estimate(Request request)";
        Logger logger = getLogger();

        // Log entry
        Helper.logEntrance(logger, signature, new String[] {"request"}, new Object[] {request});

        Helper.checkNull(logger, signature, request, "request");

        EstimatesData estimatesData = request.getEstimatesData();

        if (estimatesData == null) {
            // No estimates data, return null
            Helper.logExit(logger, signature, new Object[]{null});
            return null;
        }

        EstimatedResult result = new EstimatedResult(estimatesData);

        // Populate LOB lookup data map
        List<LOBLookupData> lobLookupDatas = lookupService.getLookupEnities(LOBLookupData.class);
        Map<Long, LOBLookupData> lobLookupDataMap = new HashMap<Long, LOBLookupData>();
        for (LOBLookupData data : lobLookupDatas) {
            lobLookupDataMap.put(data.getId(), data);
        }

        // Delivery country code
        String countryCode = getLookupCode(request.getEngagementTypeData() == null ? null : request
                .getEngagementTypeData().getDeliveryCountry());

        for (EstimatedLOB lob : result.getEstimatedLOBs()) {

            // Calculate each LOB fee
            LOBCountry lobCountry = getLOBCountry(lobLookupDataMap, lob, countryCode);

            for (EstimatedResource resource : lob.getEstimatedResources()) {
                // Calculate each resource fee
            	calculateResourceFee(request, resource, lob, lobCountry, result);

                lob.setStandardFees(add(lob.getStandardFees(), resource.getStandardFees()));
                lob.setDiscountedFees(add(lob.getDiscountedFees(), resource.getDiscountedFees()));

                if (resource.getStandardCost() != null) {
                    if (lob.getStandardCost() == null) {
                        lob.setStandardCost(BigDecimal.ZERO);
                    }
                    lob.setStandardCost(add(lob.getStandardCost(), resource.getStandardCost()));
                }

                lob.setTotalHours(add(lob.getTotalHours(), resource.getBudgetedHours()));

                // Set start/end date of LOB
                if (lob.getLobStartDate() == null
                        || (resource.getStartDate() != null && resource.getStartDate().before(lob.getLobStartDate()))) {
                    lob.setLobStartDate(resource.getStartDate());
                }

                if (lob.getLobEndDate() == null
                        || (resource.getEndDate() != null && resource.getEndDate().after(lob.getLobEndDate()))) {
                    lob.setLobEndDate(resource.getEndDate());
                }
            }

            // Set start/end date of project
            if (result.getProjectStartDate() == null
                    || (lob.getLobStartDate() != null && lob.getLobStartDate().before(result.getProjectStartDate()))) {
                result.setProjectStartDate(lob.getLobStartDate());
            }

            if (result.getProjectEndDate() == null
                    || (lob.getLobEndDate() != null && lob.getLobEndDate().after(result.getProjectEndDate()))) {
                result.setProjectEndDate(lob.getLobEndDate());
            }

            // Calculate gross margin
            if (lob.getStandardCost() != null) {
                BigDecimal grossMargin = subtract(lob.getStandardFees(), lob.getStandardCost());
                lob.setGrossMargin(grossMargin);
                lob.setGrossMarginPercent(divide(grossMargin.multiply(HUNDRED), lob.getStandardFees()));
            }

            // Calculate discount for "Fixed Price" LOB
            if ("Fixed Price".equals(lookupEntity2String(lob.getBillingType()))) {
                if (lob.getDiscountAmount() != null) {
                    lob.setDiscountedFees(subtract(lob.getStandardFees(), lob.getDiscountAmount()));
                } else if (lob.getDiscountPercent() != null) {
                    lob.setDiscountedFees(divideHundred(lob.getStandardFees().multiply(
                            subtract(HUNDRED, lob.getDiscountPercent()))));
                } else {
                    lob.setDiscountedFees(lob.getStandardFees());
                }
            } else {
                // Ensure data consistency
                lob.setDiscountAmount(null);
                lob.setDiscountPercent(null);
            }

            // Calculate pricing overview
            calculatePricingOverview(lob, result, request);

            // Sum total overview
            sumTotalPricingOverview(result.getTotalOverview(), lob.getPricingOverview());
        }

        Helper.logExit(logger, signature, new Object[]{result});

        return result;
    }

    /**
     * Sum total pricing overview.
     * 
     * @param totalOverview
     *            the total overview.
     * @param lobOverview
     *            the LOB overview to be summed.
     */
    private void sumTotalPricingOverview(PricingOverview totalOverview, PricingOverview lobOverview) {
        totalOverview.setServicesFees(add(totalOverview.getServicesFees(), lobOverview.getServicesFees()));
        totalOverview.setTotalFees(add(totalOverview.getTotalFees(), lobOverview.getTotalFees()));
        totalOverview.setDiscount(subtract(totalOverview.getTotalFees(), totalOverview.getServicesFees()));
        totalOverview
                .setExpenseRecovery(add(totalOverview.getExpenseRecovery(), lobOverview.getExpenseRecovery()));
        totalOverview.setTotalRevenue(add(totalOverview.getTotalRevenue(), lobOverview.getTotalRevenue()));
        totalOverview.setServicesCost(add(totalOverview.getServicesCost(), lobOverview.getServicesCost()));
        totalOverview.setExpensesCost(add(totalOverview.getExpensesCost(), lobOverview.getExpensesCost()));
        totalOverview.setIpAmount(add(totalOverview.getIpAmount(), lobOverview.getIpAmount()));
        totalOverview.setEduAmount(add(totalOverview.getEduAmount(), lobOverview.getEduAmount()));
        totalOverview.setGrandTotal(add(totalOverview.getGrandTotal(), lobOverview.getGrandTotal()));

        totalOverview.setTotalGrossMargin(add(totalOverview.getTotalGrossMargin(),
                lobOverview.getTotalGrossMargin()));
        totalOverview.setTotalGrossMarginPercent(divide(totalOverview.getTotalGrossMargin().multiply(HUNDRED),
                totalOverview.getTotalRevenue()));
        totalOverview.setTotalGrossMarginWithIpEdu(add(totalOverview.getTotalGrossMarginWithIpEdu(),
                lobOverview.getTotalGrossMarginWithIpEdu()));

        totalOverview.setFeeOnlyMarginPercent(divide(
                subtract(totalOverview.getTotalFees(), totalOverview.getServicesCost()).multiply(HUNDRED),
                totalOverview.getTotalFees()));
        totalOverview.setDiscountOnlyPercent(divide(
                totalOverview.getDiscount().negate().multiply(HUNDRED),
                totalOverview.getServicesFees()));
        totalOverview.setBillableExpensePercent(divide(
                totalOverview.getExpenseRecovery().multiply(HUNDRED),
                totalOverview.getTotalFees()));
        totalOverview.setMarginLossPercent(divide(
                totalOverview.getTotalFees().multiply(HUNDRED),
                add(totalOverview.getTotalFees(), totalOverview.getExpensesCost())));

        totalOverview.setTotalHours(add(totalOverview.getTotalHours(), lobOverview.getTotalHours()));
        totalOverview.setTotalDays(divide(totalOverview.getTotalHours(), WORK_HOURS_PER_DAY));

        totalOverview.setAhrFees(divide(
                subtract(totalOverview.getTotalFees(), totalOverview.getServicesCost()),
                totalOverview.getTotalHours()));
        totalOverview.setAhrRevenue(divide(totalOverview.getGrandTotal(), totalOverview.getTotalHours()));
        totalOverview.setAdrFees(totalOverview.getAhrFees().multiply(WORK_HOURS_PER_DAY));
        totalOverview.setAdrRevenue(totalOverview.getAhrRevenue().multiply(WORK_HOURS_PER_DAY));
    }

    /**
     * Get LOB country from lookup data.
     * 
     * @param lobLookupDataMap
     *            The LOBs lookup data map.
     * @param lob
     *            The LOB.
     * @param countryCode
     *            The country code.
     * @return LOB country. May be null if not found.
     */
    private static LOBCountry getLOBCountry(Map<Long, LOBLookupData> lobLookupDataMap, EstimatedLOB lob,
            String countryCode) {

        if (lob.getLob() == null) {
            return null;
        }

        LOBLookupData lobLookupData = lobLookupDataMap.get(lob.getLob().getId());

        if (lobLookupData == null) {
            return null;
        }

        LOBCountry lobCountry = lobLookupData.getCountries().get(countryCode);

        return lobCountry;
    }

    /**
     * Calculate pricing overview.
     *
     * @param lob
     *            the LOB to calculate its pricing overview.
     * @param result
     * @param request
     */
    private void calculatePricingOverview(EstimatedLOB lob, EstimatedResult result, Request request) {
        PricingOverview overview = lob.getPricingOverview();

        overview.setServicesFees(lob.getStandardFees());
        overview.setTotalFees(lob.getDiscountedFees());
        overview.setDiscount(subtract(overview.getTotalFees(), overview.getServicesFees()));

        BigDecimal servicesCost = lob.getStandardCost() == null ? BigDecimal.ZERO : lob.getStandardCost();
        overview.setServicesCost(servicesCost);

        ExpenseType expenseType = request.getStartRequestData().getExpenseType();
        boolean countExpense = expenseType == null || expenseType.getId() != 3;
        BigDecimal expenseAmount;
        if (countExpense) {
            expenseAmount = lob.getExpenseAmount();
            if (expenseAmount == null) {
                expenseAmount = result.getExpenseAmount();
            }
            if (expenseAmount == null) {
                BigDecimal expenseEstimatedAt = getEstimatedAt(result);
                expenseAmount = divideHundred(overview.getTotalFees().multiply(expenseEstimatedAt));
            }
        } else {
            expenseAmount = BigDecimal.ZERO;
        }
        overview.setExpensesCost(expenseAmount);

        if (countExpense) {
            BigDecimal cappedAt = result.getCappedPercent();
            if (cappedAt == null) {
                overview.setExpenseRecovery(overview.getExpensesCost());
            } else {
                overview.setExpenseRecovery(divideHundred(overview.getServicesFees().multiply(cappedAt)));
            }
        } else {
            overview.setExpenseRecovery(BigDecimal.ZERO);
        }

        overview.setTotalRevenue(add(overview.getTotalFees(), overview.getExpenseRecovery()));

        overview.setIpAmount(BigDecimal.ZERO);
        overview.setEduAmount(BigDecimal.ZERO);

        if (lob.getLob() != null) {
            boolean isECD = lob.getLob().getId() == 2;
            if (isECD) {
                List<IPEDURecord> ipEduData = result.getIpEduData();
                Competency lobCompetency = lob.getCompetency();
                for (IPEDURecord ipeduRecord : ipEduData) {
                    if (ipeduRecord.getCompetency() != null) {
                        if (ipeduRecord.getCompetency().getId() == lobCompetency.getId()) {
                            if (ipeduRecord.getType() == IPEDUOption.IP) {
                                overview.setIpAmount(add(overview.getIpAmount(), ipeduRecord.getAmount()));
                            } else if (ipeduRecord.getType() == IPEDUOption.EDU) {
                                overview.setEduAmount(add(overview.getEduAmount(), ipeduRecord.getAmount()));
                            }
                        }
                    }
                }
            }
        }


        boolean isEMC = "EMC".equals(lookupEntity2String(lob.getLob()));
        if (isEMC) {
            overview.setTotalGrossMargin(BigDecimal.ZERO);
            overview.setTotalGrossMarginWithIpEdu(BigDecimal.ZERO);
            overview.setTotalGrossMarginPercent(BigDecimal.ZERO);
        } else {
            BigDecimal totalGrossMargin = subtract(overview.getTotalFees(), servicesCost);
            overview.setTotalGrossMargin(totalGrossMargin);
            overview.setTotalGrossMarginWithIpEdu(add(add(totalGrossMargin, overview.getIpAmount()),
                    overview.getEduAmount()));
            overview.setTotalGrossMarginPercent(divide(totalGrossMargin.multiply(HUNDRED),
                    overview.getTotalRevenue()));
        }

        overview.setGrandTotal(add(add(overview.getTotalRevenue(), overview.getIpAmount()), overview.getEduAmount()));

        overview.setFeeOnlyMarginPercent(divide(
                subtract(overview.getTotalFees(), servicesCost).multiply(HUNDRED),
                overview.getTotalFees()));
        overview.setDiscountOnlyPercent(divide(
                overview.getDiscount().negate().multiply(HUNDRED),
                overview.getServicesFees()));
        overview.setBillableExpensePercent(divide(
                overview.getExpenseRecovery().multiply(HUNDRED),
                overview.getTotalFees()));
        overview.setMarginLossPercent(divide(
                overview.getTotalFees().multiply(HUNDRED),
                add(overview.getTotalFees(), overview.getExpensesCost())));

        overview.setTotalHours(lob.getTotalHours());
        overview.setTotalDays(divide(lob.getTotalHours(), WORK_HOURS_PER_DAY));

        overview.setAhrFees(divide(subtract(overview.getTotalFees(), servicesCost), lob.getTotalHours()));
        overview.setAhrRevenue(divide(overview.getGrandTotal(), lob.getTotalHours()));
        overview.setAdrFees(overview.getAhrFees().multiply(WORK_HOURS_PER_DAY));
        overview.setAdrRevenue(overview.getAhrRevenue().multiply(WORK_HOURS_PER_DAY));
    }

    /**
     * Calculates resource.
     * 
     * @param resource
     *            the resource to calculate fee.
     * @param lob
     *            the LOB containing the resource.
     * @param lobCountry
     *            the LOB country.
     * @param result
     *            the estimates result data containing the LOB.
     * @throws ServiceRequestToolException
     *             if error occurs when estimating resource.
     */
    private void calculateResourceFee(Request request, EstimatedResource resource, EstimatedLOB lob, LOBCountry lobCountry,
            EstimatedResult result) throws ServiceRequestToolException {

        // Sum budgeted hours
        BigDecimal budgetedHours = BigDecimal.ZERO;

        Map<Integer, Integer> monthHours = resource.getMonthHours();
        if (monthHours != null) {
            for (Integer hours : monthHours.values()) {
                budgetedHours = add(budgetedHours, new BigDecimal(hours));
            }
        }

        // Apply contingency
        BigDecimal contingency = resource.getContingencyPercent();
        if (contingency != null) {
            budgetedHours = divideHundred(budgetedHours.multiply(HUNDRED.add(contingency)));
        }
        resource.setBudgetedHours(budgetedHours);

        Map<String, BigDecimal> billRates = ratesService.retrieveStandardBillRates();
        Map<String, BigDecimal> costRates = ratesService.retrieveHourlyStdCostRates();
        BigDecimal exchangeRate = getExchangeRate(request, result);

        // Standard billing rate
        BigDecimal standardBillRate = lobCountry == null ? null : billRates.get(
                lobCountry.getCompanyCode() + "|"
                + getLookupCode(resource.getCompetency()) + "|"
                + getLookupCode(resource.getRole()) + "|"
                + getLookupCode(lob.getMaterialCode()));
        if (standardBillRate == null) {
            // Try to lookup without material code
            standardBillRate = lobCountry == null ? null : billRates.get(
                    lobCountry.getCompanyCode() + "|"
                    + getLookupCode(resource.getCompetency()) + "|"
                    + getLookupCode(resource.getRole()) + "|");
        }
        if (standardBillRate == null) {
            standardBillRate = BigDecimal.ZERO; // Default standard billing rate to zero
        }
        standardBillRate = divide(standardBillRate, exchangeRate);
        resource.setStandardBillRate(standardBillRate);

        // Standard cost rate
        BigDecimal hourlyStdCostRate = lobCountry == null ? null : costRates.get(lobCountry.getCostCenterCode()
                + "|" + getLookupCode(resource.getRole()));
        if (hourlyStdCostRate != null) {
            hourlyStdCostRate = divide(hourlyStdCostRate, exchangeRate);
        }
        resource.setHourlyStdCostRate(hourlyStdCostRate);

        // Calculate standard fees
        resource.setStandardFees(standardBillRate.multiply(budgetedHours));

        // Calculate standard cost, gross margin
        if (hourlyStdCostRate != null) {
            resource.setStandardCost(hourlyStdCostRate.multiply(budgetedHours));
            BigDecimal grossMargin = subtract(resource.getStandardFees(), resource.getStandardCost());
            resource.setGrossMargin(grossMargin);
            resource.setGrossMarginPercent(divide(grossMargin.multiply(HUNDRED), resource.getStandardFees()));
        } else {
            resource.setStandardCost(BigDecimal.ZERO);
        }

        BigDecimal expenseEstimatedAt = getEstimatedAt(result);

        // Only resource with "Time and Materials" billing type can have bill rate override in effect
        BigDecimal billRateOverride = "Time and Materials".equals(lookupEntity2String(lob.getBillingType())) ? resource
                .getBillRateOverride() : null;

        // Calculate bill rate override, bill rate with expense, discounted fee
        if (billRateOverride != null) {
            resource.setBillRateOverridePercent(divide(billRateOverride.multiply(HUNDRED), standardBillRate));
            resource.setBillRateWithExpense(divideHundred(expenseEstimatedAt.add(HUNDRED).multiply(
                    billRateOverride)));
            resource.setDiscountedFees(billRateOverride.multiply(budgetedHours));
        } else {
            resource.setBillRateOverridePercent(null);
            resource.setBillRateWithExpense(divideHundred(expenseEstimatedAt.multiply(standardBillRate)));
            resource.setDiscountedFees(resource.getStandardFees());
            // Ensure data consistency
            resource.setBillRateOverride(null);
        }
    }

    /**
     * Divide by 100.
     * 
     * @param dividend the dividend
     * @return the divided value
     */
    public static BigDecimal divideHundred(BigDecimal dividend) {
        return dividend == null ? BigDecimal.ZERO : dividend.divide(HUNDRED, RoundingMode.HALF_UP);
    }

    /**
     * Divide.
     * 
     * @param dividend the dividend
     * @param divisor the divisor
     * @return the divided value
     */
    public static BigDecimal divide(BigDecimal dividend, BigDecimal divisor) {
        if (divisor == null || divisor.compareTo(BigDecimal.ZERO) == 0) {
            return BigDecimal.ZERO;
        }
        return dividend == null ? BigDecimal.ZERO : dividend.divide(divisor, RoundingMode.HALF_UP);
    }

    /**
     * Add two decimals.
     * 
     * @param one
     *            One decimal
     * @param two
     *            Another decimal
     * @return the summed value
     */
    private static BigDecimal add(BigDecimal one, BigDecimal two) {
        if (one == null) {
            return two;
        }
        if (two == null) {
            return one;
        }
        return one.add(two);
    }

    /**
     * Subtract two decimals.
     * 
     * @param one
     *            One decimal
     * @param two
     *            Another decimal
     * @return the subtracted value
     */
    public static BigDecimal subtract(BigDecimal one, BigDecimal two) {
        if (one == null) {
            one = BigDecimal.ZERO;
        }
        if (two == null) {
            two = BigDecimal.ZERO;
        }
        return one.subtract(two);
    }

    /**
     * Get exchange rate.
     * 
     * @param estimatesData
     *            the estimates data.
     * @return the exchange rate.
     */
    private static BigDecimal getExchangeRate(Request request, EstimatesData estimatesData) {
        DealCurrency baseCurrency = request.getEngagementTypeData().getDeliveryCountry().getDealCurrency();
        DealCurrency dealCurrency = estimatesData.getDealCurrency();

        BigDecimal dealCurrencyExchangeRate = dealCurrency == null ? null : dealCurrency.getExchangeRate();
        if (dealCurrencyExchangeRate == null) {
            dealCurrencyExchangeRate = BigDecimal.ONE;
        }
        return dealCurrencyExchangeRate.divide(baseCurrency.getExchangeRate(), RoundingMode.HALF_UP);
    }

    /**
     * Get estimated at percent.
     * 
     * @param estimatesData
     *            the estimates data.
     * @return the estimated at percent.
     */
    private static BigDecimal getEstimatedAt(EstimatesData estimatesData) {

        BigDecimal estimatedAt = estimatesData.getEstimatedPercent();
        if (estimatedAt == null) {
            estimatedAt = new BigDecimal(15);
        }
        return estimatedAt;
    }

    /**
     * This method checks whether the instance of the class was initialized properly.
     *
     * @throws ServiceRequestToolConfigurationException
     *             if lookupService/ratesService is null
     */
    @PostConstruct
    protected void checkInit() {
        Helper.checkState(lookupService == null, "'lookupService' can't be null.");
        Helper.checkState(ratesService == null, "'ratesService' can't be null.");
        Helper.checkState(customerService == null, "'customerService' can't be null.");
    }

    /**
     * <p>
     * Sets the value to lookupService field.
     * </p>
     * 
     * @param lookupService
     *            the value of lookupService to set
     */
    public void setLookupService(LookupService lookupService) {
        this.lookupService = lookupService;
    }

    /**
     * <p>
     * Sets the value to ratesService field.
     * </p>
     * 
     * @param ratesService
     *            the value of ratesService to set
     */
    public void setRatesService(RatesService ratesService) {
        this.ratesService = ratesService;
    }

    /**
     * <p>
     * Sets the value to customerService field.
     * </p>
     * 
     * @param customerService
     *            the value of customerService to set
     */
    public void setCustomerService(CustomerService customerService) {
        this.customerService = customerService;
    }
}

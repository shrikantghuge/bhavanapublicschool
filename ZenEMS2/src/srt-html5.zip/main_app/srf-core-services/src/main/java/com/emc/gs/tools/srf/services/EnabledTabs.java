/*
 * This code is copyright (c) 2014 EMC Corporation
 */
package com.emc.gs.tools.srf.services;

/**
 * The class contains the information about whether tabs are enabled.
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safety.
 * </p>
 *
 * <p>
 * <strong>Changes V1.1:</strong>
 * <strong>SRT Phase 3-3 - Remove BRS and Isilon and Update Residency and Implement
 * SourceOne Tabs Assembly</strong>
 * <ul>
 * <li>Remove enableBRS/enableIsilon fields.</li>
 * <li>Add enableSourceOne field.</li>
 * </ul>
 * </p>
 *
 * <p>
 * <strong>Changes V1.2:</strong>
 * <strong>SRT Phase 3-4 - ASD and Healthcheck Tabs Assembly</strong>
 * <ul>
 * <li>Add enableASD/enableHealthCheck fields.</li>
 * </ul>
 * </p>
 *
 * <p>
 * <strong>Changes V1.3:</strong>
 * <strong>SRT Phase 3-3 - Implement Isilon and ViPR Tabs Assembly</strong>
 * <ul>
 * <li>Add enableIsilon/enableViPR fields.</li>
 * </ul>
 * </p>
 *
 * <p>
 * <strong>Changes V1.4:</strong>
 * <strong>SRT Phase 3-1 - Atmos Centera and Vblock Tabs Assembly</strong>
 * <ul>
 * <li>Add enableAtmos/enableVblock fields.</li>
 * </ul>
 * </p>
 *
 * <p>
 * <strong>Changes V1.5:</strong>
 * <strong>SRT Phase 3-5 - BRS Tabs Part 1 Assembly</strong>
 * <ul>
 * <li>Add enableDPAD field.</li>
 * </ul>
 * </p>
 *
 * <p>
 * <strong>Changes V1.6:</strong>
 * <strong>SRT Phase 3-1 - Implement VMWare Tab Assembly</strong>
 * <ul>
 * <li>Add enableVMWare field.</li>
 * </ul>
 * </p>
 *
 * <p>
 * <strong>Changes V1.7:</strong>
 * <strong>SRT Phase 3 Merge Assembly</strong>
 * <ul>
 * <li>Add enableMoveRequest/enableChangeRequest/enableW4N/enableSRM fields.</li>
 * </ul>
 * </p>
 *
 * <p>
 * Version 1.8 (SRT Phase 3 Pilot - Mozy and Xtrem and Vipr Tabs Assembly) Change notes:
 *   <ol>
 *     <li>Added {@link #enableXtreme} property.</li>
 *   </ol>
 * </p>
 *
 * @author TCSASSEMBLER
 * @version 1.8
 * @since SRT Phase 3-3 - Isilon and Residency Tabs Assembly
 */
public class EnabledTabs {

    /**
     * Represents whether MSS tab is enabled.
     */
    private boolean enableMSS;

    /**
     * Represents whether CTA tab is enabled.
     */
    private boolean enableCTA;

    /**
     * Represents whether Residency tab is enabled.
     */
    private boolean enableResidency;

    /**
     * Represents whether SourceOne tab is enabled.
     *
     * @since SRT Phase 3-3 - Remove BRS and Isilon and Update Residency and Implement SourceOne Tabs Assembly
     */
    private boolean enableSourceOne;

    /**
     * Represents whether ASD tab is enabled.
     *
     * @since SRT Phase 3-4 - ASD and Healthcheck Tabs Assembly
     */
    private boolean enableASD;

    /**
     * Represents whether HealthCheck tab is enabled.
     *
     * @since SRT Phase 3-4 - ASD and Healthcheck Tabs Assembly
     */
    private boolean enableHealthCheck;

    /**
     * Represents whether Isilon tab is enabled.
     *
     * @since SRT Phase 3-3 - Implement Isilon and ViPR Tabs Assembly
     */
    private boolean enableIsilon;

    /**
     * Represents whether ViPR tab is enabled.
     *
     * @since SRT Phase 3-3 - Implement Isilon and ViPR Tabs Assembly
     */
    private boolean enableViPR;

    /**
     * Represents whether Atmos - Centera tab is enabled.
     *
     * @since SRT Phase 3-1 - Atmos Centera and Vblock Tabs Assembly
     */
    private boolean enableAtmos;

    /**
     * Represents whether Vblock tab is enabled.
     *
     * @since SRT Phase 3-1 - Atmos Centera and Vblock Tabs Assembly
     */
    private boolean enableVblock;

    /**
     * Represents whether DPAD tab is enabled.
     *
     * @since SRT Phase 3-5 - BRS Tabs Part 1 Assembly
     */
    private boolean enableDPAD;

    /**
     * Represents whether VMWare tab is enabled.
     *
     * @since SRT Phase 3-1 - Implement VMWare Tab Assembly
     */
    private boolean enableVMWare;

    /**
     * Represents whether Move Request tab is enabled.
     *
     * @since SRT Phase 3 Merge Assembly
     */
    private boolean enableMoveRequest;

    /**
     * Represents whether Change Request tab is enabled.
     *
     * @since SRT Phase 3 Merge Assembly
     */
    private boolean enableChangeRequest;

    /**
     * Represents whether W4N tab is enabled.
     *
     * @since SRT Phase 3 Merge Assembly
     */
    private boolean enableW4N;

    /**
     * Represents whether SRM tab is enabled.
     *
     * @since SRT Phase 3 Merge Assembly
     */
    private boolean enableSRM;

    /**
     * <p>A <code>boolean</code> providing the flag indicating if Xtreme tab is enabled or not.</p>
     * 
     * @since 1.8
     */
    private boolean enableXtreme;

    /**
     * <p>
     * The default constructor.
     * </p>
     */
    public EnabledTabs() {
    }

    /**
     * Getter method for property <tt>enableMSS</tt>.
     *
     * @return property value of enableMSS
     */
    public boolean isEnableMSS() {
        return enableMSS;
    }

    /**
     * Setter method for property <tt>enableMSS</tt>.
     *
     * @param enableMSS
     *            value to be assigned to property enableMSS
     */
    public void setEnableMSS(boolean enableMSS) {
        this.enableMSS = enableMSS;
    }

    /**
     * Getter method for property <tt>enableCTA</tt>.
     *
     * @return property value of enableCTA
     */
    public boolean isEnableCTA() {
        return enableCTA;
    }

    /**
     * Setter method for property <tt>enableCTA</tt>.
     *
     * @param enableCTA
     *            value to be assigned to property enableCTA
     */
    public void setEnableCTA(boolean enableCTA) {
        this.enableCTA = enableCTA;
    }

    /**
     * Getter method for property <tt>enableResidency</tt>.
     *
     * @return property value of enableResidency
     */
    public boolean isEnableResidency() {
        return enableResidency;
    }

    /**
     * Setter method for property <tt>enableResidency</tt>.
     *
     * @param enableResidency
     *            value to be assigned to property enableResidency
     */
    public void setEnableResidency(boolean enableResidency) {
        this.enableResidency = enableResidency;
    }

    /**
     * Getter method for property <tt>enableSourceOne</tt>.
     *
     * @return property value of enableSourceOne
     * @since SRT Phase 3-3 - Remove BRS and Isilon and Update Residency and Implement SourceOne Tabs Assembly
     */
    public boolean isEnableSourceOne() {
        return enableSourceOne;
    }

    /**
     * Setter method for property <tt>enableSourceOne</tt>.
     *
     * @param enableSourceOne
     *            value to be assigned to property enableSourceOne
     * @since SRT Phase 3-3 - Remove BRS and Isilon and Update Residency and Implement SourceOne Tabs Assembly
     */
    public void setEnableSourceOne(boolean enableSourceOne) {
        this.enableSourceOne = enableSourceOne;
    }

    /**
     * Getter method for property <tt>enableASD</tt>.
     *
     * @return property value of enableASD
     * @since SRT Phase 3-4 - ASD and Healthcheck Tabs Assembly
     */
    public boolean isEnableASD() {
        return enableASD;
    }

    /**
     * Setter method for property <tt>enableASD</tt>.
     *
     * @param enableASD
     *            value to be assigned to property enableASD
     * @since SRT Phase 3-4 - ASD and Healthcheck Tabs Assembly
     */
    public void setEnableASD(boolean enableASD) {
        this.enableASD = enableASD;
    }

    /**
     * Getter method for property <tt>enableHealthCheck</tt>.
     *
     * @return property value of enableHealthCheck
     * @since SRT Phase 3-4 - ASD and Healthcheck Tabs Assembly
     */
    public boolean isEnableHealthCheck() {
        return enableHealthCheck;
    }

    /**
     * Setter method for property <tt>enableHealthCheck</tt>.
     *
     * @param enableHealthCheck
     *            value to be assigned to property enableHealthCheck
     * @since SRT Phase 3-4 - ASD and Healthcheck Tabs Assembly
     */
    public void setEnableHealthCheck(boolean enableHealthCheck) {
        this.enableHealthCheck = enableHealthCheck;
    }

    /**
     * Getter method for property <tt>enableIsilon</tt>.
     *
     * @return property value of enableIsilon
     * @since SRT Phase 3-3 - Implement Isilon and ViPR Tabs Assembly
     */
    public boolean isEnableIsilon() {
        return enableIsilon;
    }

    /**
     * Setter method for property <tt>enableIsilon</tt>.
     *
     * @param enableIsilon
     *            value to be assigned to property enableIsilon
     * @since SRT Phase 3-3 - Implement Isilon and ViPR Tabs Assembly
     */
    public void setEnableIsilon(boolean enableIsilon) {
        this.enableIsilon = enableIsilon;
    }

    /**
     * Getter method for property <tt>enableViPR</tt>.
     *
     * @return property value of enableViPR
     * @since SRT Phase 3-3 - Implement Isilon and ViPR Tabs Assembly
     */
    public boolean isEnableViPR() {
        return enableViPR;
    }

    /**
     * Setter method for property <tt>enableViPR</tt>.
     *
     * @param enableViPR
     *            value to be assigned to property enableViPR
     * @since SRT Phase 3-3 - Implement Isilon and ViPR Tabs Assembly
     */
    public void setEnableViPR(boolean enableViPR) {
        this.enableViPR = enableViPR;
    }

    /**
     * Getter method for property <tt>enableAtmos</tt>.
     *
     * @return property value of enableAtmos
     * @since SRT Phase 3-1 - Atmos Centera and Vblock Tabs Assembly
     */
    public boolean isEnableAtmos() {
        return enableAtmos;
    }

    /**
     * Setter method for property <tt>enableAtmos</tt>.
     *
     * @param enableAtmos
     *            value to be assigned to property enableAtmos
     * @since SRT Phase 3-1 - Atmos Centera and Vblock Tabs Assembly
     */
    public void setEnableAtmos(boolean enableAtmos) {
        this.enableAtmos = enableAtmos;
    }

    /**
     * Getter method for property <tt>enableVblock</tt>.
     *
     * @return property value of enableVblock
     * @since SRT Phase 3-1 - Atmos Centera and Vblock Tabs Assembly
     */
    public boolean isEnableVblock() {
        return enableVblock;
    }

    /**
     * Setter method for property <tt>enableVblock</tt>.
     *
     * @param enableVblock
     *            value to be assigned to property enableVblock
     * @since SRT Phase 3-1 - Atmos Centera and Vblock Tabs Assembly
     */
    public void setEnableVblock(boolean enableVblock) {
        this.enableVblock = enableVblock;
    }

    /**
     * Getter method for property <tt>enableDPAD</tt>.
     *
     * @return property value of enableDPAD
     * @since SRT Phase 3-5 - BRS Tabs Part 1 Assembly
     */
    public boolean isEnableDPAD() {
        return enableDPAD;
    }

    /**
     * Setter method for property <tt>enableDPAD</tt>.
     *
     * @param enableDPAD
     *            value to be assigned to property enableDPAD
     * @since SRT Phase 3-5 - BRS Tabs Part 1 Assembly
     */
    public void setEnableDPAD(boolean enableDPAD) {
        this.enableDPAD = enableDPAD;
    }

    /**
     * Getter method for property <tt>enableVMWare</tt>.
     *
     * @return property value of enableVMWare
     * @since SRT Phase 3-1 - Implement VMWare Tab Assembly
     */
    public boolean isEnableVMWare() {
        return enableVMWare;
    }

    /**
     * Setter method for property <tt>enableVMWare</tt>.
     *
     * @param enableVMWare
     *            value to be assigned to property enableVMWare
     * @since SRT Phase 3-1 - Implement VMWare Tab Assembly
     */
    public void setEnableVMWare(boolean enableVMWare) {
        this.enableVMWare = enableVMWare;
    }

    /**
     * Getter method for property <tt>enableMoveRequest</tt>.
     *
     * @return property value of enableMoveRequest
     * @since SRT Phase 3 Merge Assembly
     */
    public boolean isEnableMoveRequest() {
        return enableMoveRequest;
    }

    /**
     * Setter method for property <tt>enableMoveRequest</tt>.
     *
     * @param enableMoveRequest
     *            value to be assigned to property enableMoveRequest
     * @since SRT Phase 3 Merge Assembly
     */
    public void setEnableMoveRequest(boolean enableMoveRequest) {
        this.enableMoveRequest = enableMoveRequest;
    }

    /**
     * Getter method for property <tt>enableChangeRequest</tt>.
     *
     * @return property value of enableChangeRequest
     * @since SRT Phase 3 Merge Assembly
     */
    public boolean isEnableChangeRequest() {
        return enableChangeRequest;
    }

    /**
     * Setter method for property <tt>enableChangeRequest</tt>.
     *
     * @param enableChangeRequest
     *            value to be assigned to property enableChangeRequest
     * @since SRT Phase 3 Merge Assembly
     */
    public void setEnableChangeRequest(boolean enableChangeRequest) {
        this.enableChangeRequest = enableChangeRequest;
    }

    /**
     * Getter method for property <tt>enableW4N</tt>.
     *
     * @return property value of enableW4N
     * @since SRT Phase 3 Merge Assembly
     */
    public boolean isEnableW4N() {
        return enableW4N;
    }

    /**
     * Setter method for property <tt>enableW4N</tt>.
     *
     * @param enableW4N
     *            value to be assigned to property enableW4N
     * @since SRT Phase 3 Merge Assembly
     */
    public void setEnableW4N(boolean enableW4N) {
        this.enableW4N = enableW4N;
    }

    /**
     * Getter method for property <tt>enableSRM</tt>.
     *
     * @return property value of enableSRM
     * @since SRT Phase 3 Merge Assembly
     */
    public boolean isEnableSRM() {
        return enableSRM;
    }

    /**
     * Setter method for property <tt>enableSRM</tt>.
     *
     * @param enableSRM
     *            value to be assigned to property enableSRM
     * @since SRT Phase 3 Merge Assembly
     */
    public void setEnableSRM(boolean enableSRM) {
        this.enableSRM = enableSRM;
    }

    /**
     * <p>Gets the flag indicating if Xtreme tab is enabled or not.</p>
     *
     * @return a <code>boolean</code> providing the flag indicating if Xtreme tab is enabled or not.
     * @since 1.8
     */
    public boolean isEnableXtreme() {
        return this.enableXtreme;
    }

    /**
     * <p>Sets the flag indicating if Xtreme tab is enabled or not.</p>
     *
     * @param enableXtreme a <code>boolean</code> providing the flag indicating if Xtreme tab is enabled or not.
     * @since 1.8
     */
    public void setEnableXtreme(boolean enableXtreme) {
        this.enableXtreme = enableXtreme;
    }
}

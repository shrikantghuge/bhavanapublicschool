/*
 * This code is copyright (c) 2013 - 2014 EMC Corporation.
 */
package com.emc.gs.tools.srf.services;

import com.emc.gs.tools.srf.model.Customer;
import com.emc.gs.tools.srf.model.CustomerSearchCriteria;
import com.emc.gs.tools.srf.model.SearchResult;

/**
 * <p>
 * This interface defines a contract for managing a customer. It is simply extends GenericService to provide necessary
 * create, update, delete and get methods and additionally provides a search method based on criteria.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: The implementation are required to be thread safe.
 * </p>
 *
 * @author faeton, stevenfrog
 * @version 1.0
 */
public interface CustomerService extends GenericService<Customer> {
    /**
     * Search customers based on the search criteria.
     *
     * @throws IllegalArgumentException
     *             if criteria is null, or if criteria.pageNumber is positive, criteria.pageSize is not positive
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     * @param criteria
     *            the search criteria
     * @return the search result
     */
    public SearchResult<Customer> search(CustomerSearchCriteria criteria) throws ServiceRequestToolException;
}

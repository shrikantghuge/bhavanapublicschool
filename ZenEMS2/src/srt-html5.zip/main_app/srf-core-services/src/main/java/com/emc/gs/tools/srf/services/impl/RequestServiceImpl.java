/*
 * This code is copyright (c) 2013 - 2015 EMC Corporation.
 */
package com.emc.gs.tools.srf.services.impl;

import com.emc.gs.tools.srf.AuthorizationException;
import com.emc.gs.tools.srf.model.Attachment;
import com.emc.gs.tools.srf.model.Customer;
import com.emc.gs.tools.srf.model.IdentifiableEntity;
import com.emc.gs.tools.srf.model.Operation;
import com.emc.gs.tools.srf.model.Profile;
import com.emc.gs.tools.srf.model.ProfileSearchCriteria;
import com.emc.gs.tools.srf.model.Request;
import com.emc.gs.tools.srf.model.RequestSearchCriteria;
import com.emc.gs.tools.srf.model.RequestStatus;
import com.emc.gs.tools.srf.model.SearchResult;
import com.emc.gs.tools.srf.model.ServiceContext;
import com.emc.gs.tools.srf.model.SortOrder;
import com.emc.gs.tools.srf.model.StartRequestData;
import com.emc.gs.tools.srf.model.User;
import com.emc.gs.tools.srf.model.bc.BcRequestData;
import com.emc.gs.tools.srf.model.engagement.SRTPath;
import com.emc.gs.tools.srf.model.infrastructure.InfrastructureRequestData;
import com.emc.gs.tools.srf.model.mainframe.MainframeRequestData;
import com.emc.gs.tools.srf.model.unified.UnifiedRequestData;
import com.emc.gs.tools.srf.services.*;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.support.TransactionSynchronizationAdapter;
import org.springframework.transaction.support.TransactionSynchronizationManager;

import javax.annotation.PostConstruct;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceException;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * <p>
 * This class is the implementation of the RequestService. It utilizes JPA EntityManager for necessary
 * operations.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is effectively thread safe after configuration, the
 * configuration is done in a thread safe manner.
 * </p>
 *
 * <p>
 * <strong>Changes:</strong>
 * <strong>SRT Release Assembly - Base</strong>
 * <ul>
 * <li>Release_assembly_tasks.xls Row#5: Renamed name to contactName</li>
 * </ul>
 * </p>
 *
 * <p>
 * <strong>Change 1.2:</strong>
 * <strong>BUGR-10829</strong>
 * <ul>
 * <li>change setQueryByCriteria to support case insensitive search</li>
 * </ul>
 * </p>
 *
 * <p>
 * <strong>Changes V1.3:</strong>
 * <strong>SRT Bug Fixes</strong>
 * <ul>
 * <li>Modified setQueryByCriteria() method: removed startDateSubmitted and endDateSubmitted criteria.</li>
 * <li>Modified setParaByCriteria() method: removed startDateSubmitted and endDateSubmitted criteria.</li>
 * </ul>
 * </p>
 *
 * <p>
 * <strong>Changes V1.4:</strong>
 * <strong>SRT Phase 2 Release Assembly</strong>
 * <ul>
 * <li>Add submitRequest() method</li>
 * </ul>
 * </p>
 *
 * <p>
 * <strong>Change 1.5:</strong>
 * <strong>SRT Cloud Synchronization - Cloud App Assembly</strong>
 * <ul>
 * <li>added create, update, get and delete methods</li>
 * <li>added userIdentifier parameter to setQueryByCriteria and setParaByCriteria</li>
 * </ul>
 * </p>
 *
 * <p>
 * <strong>Changes V1.6:</strong>
 * <strong>SRT Phase 4 - ET Assembly 1</strong>
 * <ul>
 * <li>Change Search() method to return only necessary request fields</li>
 * </ul>
 * </p>
 *
 * <p>
 * <strong>Changes V1.7:</strong>
 * <strong>SRT Phase 4 - ET Assembly 2</strong>
 * <ul>
 * <li>Extend from BaseCorrelatedEntityService.</li>
 * </ul>
 * </p>
 *
 * <p>
 * <strong>Changes V1.8:</strong>
 * <strong>SRT Phase 4 - ET Assembly 3</strong>
 * <ul>
 * <li>Moved the handleUploadFiles and deleteAttachmentFiles from RequestController to here. No matter who creates,
 * updates, or deletes a request, we need to handle the related attachments.
 * So it makes more sense to move them here. And this way, it can be reused by SynchronizationServiceImpl.</li>
 * </ul>
 * <ul>
 * <li>Make sure we only delete the attachments when the transaction is committed.
 * Deleting needed files is much worse than leaving the unused files.
 * So we need to delete only after the transaction is committed.</li>
 * <li>Fixed the hql in isAttachmentFileInUse to find attachments being used.</li>
 * </ul>
 * </p>
 *
 * <p>
 * Version 1.9 Change notes:
 *   <ol>
 *     <li>Added {@link #ftpService} property.</li>
 *     <li>Updated {@link #submitRequest(Request, File)} method to send request files to FTP server for SRT4 path.</li>
 *   </ol>
 * </p>
 *
 * <p>
 * Changes in version 1.10 (SRT 1.1 FEB 2015 Updates - Template Folder Assembly):
 * <ul>
 * <li>Updated query and added filtering by LOB, theater, and currency.</li>
 * <li>Added riskCalculationData and estimatesData returned in {@link #search(RequestSearchCriteria)} method.</li>
 * <li>Modified search method to skip userIdentifier if request type is template.</li>
 * <li>Added {@link #afterGet(Request)} to skip permission check if request status is template.</li>
 * </ul>
 * </p>
 *
 * <p>
 * Version 1.11 Change notes:
 *   <ol>
 *     <li>Updated SQL_QUERY_REQUEST and SQL_QUERY_REQUEST_COUNT fields to handle approvers/additional recipients.</li>
 *     <li>Updated setQueryByCriteria and setParaByCriteria methods to handle multiple request statuses.</li>
 *     <li>Added submitRequestForApproval method.</li>
 *     <li>Added overriding hasPrivilegesToAccess method.</li>
 *     <li>Added canAccessSubmittedRequest method.</li>
 *   </ol>
 * </p>
 *
 * <p>
 * Version 1.12 Change notes:
 *   <ol>
 *     <li>Updated <code>search</code> logic to support requests searching per tabs requirements.</li>
 *   </ol>
 * </p>
 * 
 * <p>
 * <strong>Changes V1.13:</strong>
 * <strong>SRT HTML5 ET Production Fixes Part 2 Assembly 1.0</strong>
 * <ul>
 * <li>Fix the search method to support the sort by fields.</li>
 * </ul>
 * </p>
 * @author faeton, stevenfrog, isv, duxiaoyang, MonicaMuranyi, TCSASSEMBLER
 * @version 1.13
 */
public class RequestServiceImpl extends BaseCorrelatedEntityService<Request> implements RequestService {
    /**
     * The query string to get StartRequestData.
     */
    private static final String SQL_QUERY_STARTREQUESTDATA = "SELECT r.startRequestData FROM"
            + " Request r WHERE r.id = :requestId";

    /**
     * The query string to get BcRequestData.
     */
    private static final String SQL_QUERY_BCREQUESTDATA = "SELECT r.bcRequestData FROM"
            + " Request r WHERE r.id = :requestId";

    /**
     * The query string to get MainframeRequestData.
     */
    private static final String SQL_QUERY_MAINFRAMEREQUESTDATA = "SELECT r.mainframeRequestData FROM"
            + " Request r WHERE r.id = :requestId";

    /**
     * The query string to get UnifiedRequestData.
     */
    private static final String SQL_QUERY_UNIFIEDREQUESTDATA = "SELECT r.unifiedRequestData FROM"
            + " Request r WHERE r.id = :requestId";

    /**
     * The query string to get InfrastuctureRequestData.
     */
    private static final String SQL_QUERY_INFRASTUCTUREREQUESTDATA = "SELECT r.infrastuctureRequestData FROM"
            + " Request r WHERE r.id = :requestId";

    /**
     * The query string to get Request.
     */
    private static final String SQL_QUERY_REQUEST = "SELECT distinct r, _sortBy_ FROM Request r left join r.requestType rqt left join r.riskCalculationData.theater t"
            + " left join r.estimatesData.dealCurrency c left join r.engagementTypeData e left join r.approver a"
            + " left join r.additionalRecipients adr WHERE 1 = 1";

    /**
     * The query string to get Request's total size.
     */
    private static final String SQL_QUERY_REQUEST_COUNT = "SELECT COUNT(distinct r) FROM Request r"
            + " left join r.riskCalculationData.theater t left join r.estimatesData.dealCurrency c"
            + " left join r.engagementTypeData e left join r.approver a left join r.additionalRecipients adr WHERE 1 = 1";

    /**
     * <p>
     * Represents the class name.
     * </p>
     */
    private static final String CLASSNAME = RequestServiceImpl.class.getName();

    /**
     * The thread local for the attachments to delete.
     * Used in beforeUpdate, afterUpdate, beforeDelete and afterDelete.
     */
    public static final ThreadLocal<List<String>> ATTACHMENTS_TO_DELETE = new ThreadLocal<List<String>>();

    /**
     * Represents the NotificationService instance for sending the request. It is modified by setter. It is
     * injected by Spring. It can not be null after injected.
     *
     * @since SRT Phase 2 Release Assembly
     */
    private NotificationService notificationService;

    /**
     * Represents the ProfileService instance for retrieving email options of currently logged user. It is
     * modified by setter. It is injected by Spring. It can not be null after injected.
     *
     * @since SRT Phase 2 Release Assembly
     */
    private ProfileService profileService;

    /**
     * Represents the upload folder for attachments. It is modified by setter. It is injected by Spring. It can not be
     * null or empty after injected.
     */
    private String attachmentUploadFolder;

    /**
     * <p>A <code>FTPService</code> providing the value for ftpService property.</p>
     * 
     * @since 1.9
     */
    private FTPService ftpService;

    /**
     * Creates instance of the class.
     */
    public RequestServiceImpl() {
        super(Request.class);
    }

    /**
     * Returns StartRequestData instance for the request id.
     *
     * @param requestId
     *         the request id to retrieve request data
     * @return the request data details
     * @throws IllegalArgumentException
     *         if requestId is not positive
     * @throws ServiceRequestToolException
     *         if any other error occurred during the operation
     */
    public StartRequestData getStartRequestData(long requestId) throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#getStartRequestData(long requestId)";

        return getEnity(getLogger(), signature, SQL_QUERY_STARTREQUESTDATA, StartRequestData.class,
                requestId);
    }

    /**
     * Returns BcRequestData instance for the request id.
     *
     * @param requestId
     *         the request id to retrieve request data
     * @return the request data details
     * @throws IllegalArgumentException
     *         if requestId is not positive
     * @throws ServiceRequestToolException
     *         if any other error occurred during the operation
     */
    public BcRequestData getBcRequestData(long requestId) throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#getBcRequestData(long requestId)";

        return getEnity(getLogger(), signature, SQL_QUERY_BCREQUESTDATA, BcRequestData.class, requestId);
    }

    /**
     * Returns MainframeRequestData instance for the request id.
     *
     * @param requestId
     *         the request id to retrieve request data
     * @return the request data details
     * @throws IllegalArgumentException
     *         if requestId is not positive
     * @throws ServiceRequestToolException
     *         if any other error occurred during the operation
     */
    public MainframeRequestData getMainframeRequestData(long requestId) throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#getMainframeRequestData(long requestId)";

        return getEnity(getLogger(), signature, SQL_QUERY_MAINFRAMEREQUESTDATA,
                MainframeRequestData.class, requestId);
    }

    /**
     * Returns UnifiedRequestData instance for the request id.
     *
     * @param requestId
     *         the request id to retrieve request data
     * @return the request data details
     * @throws IllegalArgumentException
     *         if requestId is not positive
     * @throws ServiceRequestToolException
     *         if any other error occurred during the operation
     */
    public UnifiedRequestData getUnifiedRequestData(long requestId) throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#getUnifiedRequestData(long requestId)";

        return getEnity(getLogger(), signature, SQL_QUERY_UNIFIEDREQUESTDATA,
                UnifiedRequestData.class, requestId);
    }

    /**
     * Returns InsfrastructureRequestData instance for the request id.
     *
     * @param requestId
     *         the request id to retrieve request data
     * @return the request data details
     * @throws IllegalArgumentException
     *         if requestId is not positive
     * @throws ServiceRequestToolException
     *         if any other error occurred during the operation
     */
    public InfrastructureRequestData getInfrastructureRequestData(long requestId)
            throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#getInfrastructureRequestData(long requestId)";

        return getEnity(getLogger(), signature, SQL_QUERY_INFRASTUCTUREREQUESTDATA,
                InfrastructureRequestData.class, requestId);
    }

    /**
     * Get the entity from DB.
     *
     * @param <T>
     *         the class type
     * @param logger
     *         the logger
     * @param signature
     *         the signature
     * @param queryStr
     *         the query string
     * @param clazz
     *         the class
     * @param id
     *         the param id
     * @return the entity
     * @throws ServiceRequestToolException
     *         if any error occurs
     */
    private <T extends IdentifiableEntity> T getEnity(Logger logger, String signature, String queryStr,
                                                      Class<T> clazz, long id) throws ServiceRequestToolException {
        // Log entry
        Helper.logEntrance(logger, signature, new String[]{"requestId"}, new Object[]{id});

        Helper.checkPositive(logger, signature, id, "requestId");

        try {
            EntityManager entityManager = getEntityManager();
            TypedQuery<T> query = entityManager.createQuery(queryStr, clazz);
            query.setParameter("requestId", id);

            T result = query.getSingleResult();

            // Log exit
            Helper.logExit(logger, signature, new Object[]{result});

            return result;
        } catch (IllegalStateException e) {
            // Log exception
            throw Helper.logException(logger, signature, new ServiceRequestToolException(
                    "The entity manager has been closed.", e));
        } catch (PersistenceException e) {
            // Log exception
            throw Helper.logException(logger, signature, new ServiceRequestToolException(
                    "An error has occurred while accessing the persistence.", e));
        }
    }

    /**
     * Search requests based on the search criteria.
     *
     * @param criteria
     *         the search criteria
     * @return the search result
     * @throws IllegalArgumentException
     *         if criteria is null, or if criteria.pageNumber is positive and criteria.pageSize is not positive
     * @throws ServiceRequestToolException
     *         if any other error occurred during the operation
     */
    public SearchResult<Request> search(RequestSearchCriteria criteria) throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#search(RequestSearchCriteria criteria)";
        Logger logger = getLogger();

        // Log entry
        Helper.logEntrance(logger, signature, new String[]{"criteria"}, new Object[]{criteria});

        Helper.checkNull(logger, signature, criteria, "criteria");
        if (criteria.getPageNumber() > 0 && criteria.getPageSize() <= 0) {
            // Log exception
            throw Helper.logException(logger, signature, new IllegalArgumentException(
                    "'criteria.pageSize' must be positive when criteria.pageNumber is positive."));
        }

        try {
            // Set default sorting order and column
            if (criteria.getSortBy() == null) {
                criteria.setSortBy("r.id");
            }
            if (criteria.getSortOrder() == null) {
                criteria.setSortOrder(SortOrder.DESC);
            }

            EntityManager entityManager = getEntityManager();

            // Create the query string
            StringBuffer sb = new StringBuffer(SQL_QUERY_REQUEST);
            setQueryByCriteria(criteria, sb);

            sb.append(" ORDER BY ").append(criteria.getSortBy().replaceAll("SORTORDER", criteria.getSortOrder().name()))
                    .append(" ").append(criteria.getSortOrder().name());

            String sql = sb.toString().replace("_sortBy_", criteria.getSortBy().replaceAll("SORTORDER", ""));
            Query q = entityManager.createQuery(sql);
            setParaByCriteria(criteria, q);
            if (criteria.getPageNumber() > 0) {
                q.setMaxResults(criteria.getPageSize());
                q.setFirstResult((criteria.getPageNumber() - 1) * criteria.getPageSize());
            }
            
            List<Request> records = new ArrayList<Request>();
            List<?> res = q.getResultList();
            
            for (Object obj : res) {
            	Object[] as = (Object[]) obj;
            	records.add((Request) as[0]); 
            }

            
            SearchResult<Request> result = new SearchResult<Request>();
            result.setValues(records);
            result.setPageNumber(criteria.getPageNumber());
            result.setPageSize(criteria.getPageSize());

            if (criteria.getPageNumber() > 0) {
                // get total page count
                sb = new StringBuffer(SQL_QUERY_REQUEST_COUNT);
                setQueryByCriteria(criteria, sb);

                // Create query
                TypedQuery<Long> countQuery = entityManager.createQuery(sb.toString(), Long.class);

                setParaByCriteria(criteria, countQuery);

                int totalCount = countQuery.getSingleResult().intValue();
                int totalPageCount = (totalCount + criteria.getPageSize() - 1) / criteria.getPageSize();
                result.setTotalItems(totalCount);
                result.setTotalPages(totalPageCount);
            } else {
                result.setTotalItems(records.size());
                result.setTotalPages(1);
            }

            // Reduce the time to convert to json
            List<Request> requests = new ArrayList<Request>();
            for (Request request : result.getValues()) {
                Request copyRequest = new Request();
                copyRequest.setId(request.getId());
                copyRequest.setProjectName(request.getProjectName());
                copyRequest.setProjectType(request.getProjectType());
                copyRequest.setRequestType(request.getRequestType());
                copyRequest.setRequestStatus(request.getRequestStatus());
                copyRequest.setCustomer(request.getCustomer());
                copyRequest.setStartRequestData(request.getStartRequestData());
                copyRequest.setEngagementTypeData(request.getEngagementTypeData());
                copyRequest.setRiskCalculationData(request.getRiskCalculationData());
                copyRequest.setEstimatesData(request.getEstimatesData());
                copyRequest.setUserIdentifier(request.getUserIdentifier());
                requests.add(copyRequest);
            }
            result.setValues(requests);

            // Log exit
            Helper.logExit(logger, signature, new Object[]{result});

            return result;
        } catch (IllegalStateException e) {
        	e.printStackTrace();
            // Log exception
            throw Helper.logException(logger, signature, new ServiceRequestToolException(
                    "The entity manager has been closed.", e));
        } catch (PersistenceException e) {
        	e.printStackTrace();
            // Log exception
            throw Helper.logException(logger, signature, new ServiceRequestToolException(
                    "An error has occurred while accessing the persistence.", e));
        }
    }

    /**
     * Set the query string by criteria.
     *
     * @param criteria
     *         the criteria
     * @param sb
     *         the string builder
     * @since 1.2
     */
    private void setQueryByCriteria(RequestSearchCriteria criteria, StringBuffer sb) {
        if (criteria.getRequestId() != null) {
            if (getAppService().isCloudApp()) {
                sb.append(" AND LOWER(TO_CHAR(r.id, 'FM9999999999999999999')) LIKE :requestId");
            } else {
                sb.append(" AND LOWER(convert(r.id, varchar(64))) LIKE :requestId");
            }
        }
        if (criteria.getRequestType() != null) {
            sb.append(" AND LOWER(r.requestType.name) LIKE :requestType");
        }
        if (criteria.getProjectName() != null) {
            sb.append(" AND LOWER(r.projectName) LIKE :projectName");
        }
        if (criteria.getProjectType() != null) {
            sb.append(" AND LOWER(r.projectType.name) LIKE :projectType");
        }
        if (criteria.getCustomerName() != null) {
            sb.append(" AND LOWER(r.startRequestData.customerName) LIKE :customerName");
        }
        if (criteria.getRequestStatuses() != null) {
            sb.append(" AND r.requestStatus IN :requestStatus");
            User currentUser = ServiceContext.getCurrentUser();
            if (criteria.getRequestStatuses().contains(RequestStatus.SUBMITTED) ||
                criteria.getRequestStatuses().contains(RequestStatus.PENDING)) {
                if (currentUser != null && !Helper.isStringNullOrEmpty(currentUser.getUserIdentifier())) {
                    sb.append(
                        " AND (r.userIdentifier = :userIdentifier OR a.userIdentifier = :userIdentifier OR adr.userIdentifier = :userIdentifier)");
                }
            } else if (!criteria.getRequestStatuses().contains(RequestStatus.TEMPLATE)) {
                if (currentUser != null && !Helper.isStringNullOrEmpty(currentUser.getUserIdentifier())) {
                    sb.append(" AND r.userIdentifier = :userIdentifier");
                }
            }
        }
        if (criteria.getTheater() != null) {
            sb.append(" AND LOWER(r.riskCalculationData.theater.name) LIKE :theater ");
        }
        if (criteria.getCurrency() != null) {
            sb.append(" AND LOWER(r.estimatesData.dealCurrency.name) LIKE :currency ");
        }
        if (criteria.getTargetTab() != null) {
            if (RequestSearchCriteria.DRAFTS_TAB.equals(criteria.getTargetTab())) {
                sb.append(" AND (r.userIdentifier = :userIdentifier AND r.requestStatus =:draftRequestStatus OR a.userIdentifier = :userIdentifier AND r.requestStatus = :pendingRequestStatus) ");
            } else if (RequestSearchCriteria.SUBMITTED_TAB.equals(criteria.getTargetTab())) {
                sb.append(" AND ((r.userIdentifier = :userIdentifier OR adr.userIdentifier = :userIdentifier) AND r.requestStatus =:pendingRequestStatus OR r.requestStatus = :submittedRequestStatus AND (r.userIdentifier = :userIdentifier OR a.userIdentifier = :userIdentifier OR adr.userIdentifier = :userIdentifier)) ");
            }
        }
        if (criteria.getLob() != null) {
            String[] lobs = criteria.getLob().toLowerCase().split("\\s*,\\s*");
            for (String lob : lobs) {
                if (lob.trim().equals("emc")) {
                    sb.append(" AND r.engagementTypeData.emc = true ");
                } else if (lob.trim().equals("ecd")) {
                    sb.append(" AND r.engagementTypeData.ecd = true ");
                } else if (lob.trim().equals("ms")) {
                    sb.append(" AND r.engagementTypeData.ms = true ");
                } else if (lob.trim().equals("rsa")) {
                    sb.append(" AND r.engagementTypeData.rsa = true ");
                } else {
                	sb.append(" AND 1 <> 1 ");
                }
            }
        }
    }

    /**
     * Set the parameter for query by criteria.
     *
     * @param criteria
     *         the criteria
     * @param query
     *         the query
     */
    private void setParaByCriteria(RequestSearchCriteria criteria, Query query) {
        if (criteria.getRequestId() != null) {
            query.setParameter("requestId", Helper.fixStringForLike(criteria.getRequestId()));
        }
        if (criteria.getRequestType() != null) {
            query.setParameter("requestType", Helper.fixStringForLike(criteria.getRequestType()));
        }
        if (criteria.getProjectName() != null) {
            query.setParameter("projectName", Helper.fixStringForLike(criteria.getProjectName()));
        }
        if (criteria.getProjectType() != null) {
            query.setParameter("projectType", Helper.fixStringForLike(criteria.getProjectType()));
        }
        if (criteria.getCustomerName() != null) {
            query.setParameter("customerName", Helper.fixStringForLike(criteria.getCustomerName()));
        }
        User currentUser = ServiceContext.getCurrentUser();
        if (criteria.getRequestStatuses() != null) {
            query.setParameter("requestStatus", criteria.getRequestStatuses());
            if (criteria.getRequestStatuses() != null && !criteria.getRequestStatuses().contains(RequestStatus.TEMPLATE)) {
                if (currentUser != null && !Helper.isStringNullOrEmpty(currentUser.getUserIdentifier())) {
                    query.setParameter("userIdentifier", currentUser.getUserIdentifier());
                }
            }
        }
        if (criteria.getTheater() != null) {
            query.setParameter("theater", Helper.fixStringForLike(criteria.getTheater()));
        }
        if (criteria.getCurrency() != null) {
            query.setParameter("currency", Helper.fixStringForLike(criteria.getCurrency()));
        }
        if (criteria.getTargetTab() != null) {
            if (RequestSearchCriteria.DRAFTS_TAB.equals(criteria.getTargetTab())) {
                query.setParameter("draftRequestStatus", RequestStatus.DRAFT);
                query.setParameter("pendingRequestStatus", RequestStatus.PENDING);
                if (currentUser != null && !Helper.isStringNullOrEmpty(currentUser.getUserIdentifier())) {
                    query.setParameter("userIdentifier", currentUser.getUserIdentifier());
                }
            } else if (RequestSearchCriteria.SUBMITTED_TAB.equals(criteria.getTargetTab())) {
                query.setParameter("submittedRequestStatus", RequestStatus.SUBMITTED);
                query.setParameter("pendingRequestStatus", RequestStatus.PENDING);
                if (currentUser != null && !Helper.isStringNullOrEmpty(currentUser.getUserIdentifier())) {
                    query.setParameter("userIdentifier", currentUser.getUserIdentifier());
                }
            }
        }
    }

    /**
     * Checks whether the attachment file is in use (referenced by any Attachment entity).
     *
     * @param attachmentFile
     *         the attachment file to check if it is in use.
     * @return true if the attachment file is in use; false otherwise.
     * @throws IllegalArgumentException
     *         if attachmentFile is null or empty
     * @throws ServiceRequestToolException
     *         if any other error occurred during the operation
     */
    public boolean isAttachmentFileInUse(String attachmentFile) throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#isAttachmentFileInUse(String attachmentFile)";
        Logger logger = getLogger();

        // Log entry
        Helper.logEntrance(logger, signature, new String[]{"attachmentFile"}, new Object[]{attachmentFile});

        Helper.checkStrNullEmpty(logger, signature, attachmentFile, "attachmentFile");

        try {
            // NOTE: Due to the Helper.zeroEntityId methods during the synchronization,
            // there would be orphan records. e.g. StartRequestData not linked to a Request.
            // so here we need to make sure the Attachment is actually used by a Request instead of being orphan.
            Number fileUsedCount = (Number) getEntityManager().createQuery(
                    "select count(a.id) from Request r " +
                            "join r.startRequestData s " +
                            "join s.attachments a " +
                            "where a.attachmentFilepath = :attachmentFilepath")
                    .setParameter("attachmentFilepath", attachmentFile)
                    .getSingleResult();

            boolean inUse = fileUsedCount.intValue() > 0;

            // Log exit
            Helper.logExit(logger, signature, new Object[]{inUse});

            return inUse;
        } catch (IllegalStateException e) {
            // Log exception
            throw Helper.logException(logger, signature, new ServiceRequestToolException(
                    "The entity manager has been closed.", e));
        } catch (PersistenceException e) {
            // Log exception
            throw Helper.logException(logger, signature, new ServiceRequestToolException(
                    "An error has occurred while accessing the persistence.", e));
        }
    }

    /**
     * Submits a request.
     *
     * @param request
     *         the request to be submitted
     * @param exportedRequest
     *         the PDF file of exported request. It is set as an attachment.
     * @return the result request
     * @param additionalFile additional files to attach.
     * @throws IllegalArgumentException
     *         request/exportedRequest is null.
     * @throws AuthorizationException
     *         if user is not allowed to submit.
     * @throws NotificationServiceException
     *         if there is any problem when sending email.
     * @throws ServiceRequestToolException
     *         if there is any problem updating the request.
     * @since SRT Phase 2 Release Assembly
     */
    @Transactional(rollbackFor = {ServiceRequestToolException.class, NotificationServiceException.class})
    @SyncUp(entityType = "Request")
    public Request submitRequest(Request request, File exportedRequest, File additionalFile)
            throws ServiceRequestToolException, NotificationServiceException {
        final String signature = CLASSNAME + "#submitRequest(Request request, File exportedRequest)";
        Logger logger = getLogger();

        // Log entry
        Helper.logEntrance(logger, signature, new String[]{"request", "exportedRequest", "additionalFile"},
                new Object[]{request, exportedRequest, additionalFile});

        Helper.checkNull(logger, signature, request, "request");
        Helper.checkNull(logger, signature, exportedRequest, "exportedRequest");
        if (!getAppService().isStandaloneMode()) {
            Helper.checkNull(logger, signature, ServiceContext.getCurrentUser(),
                    "User must be logged in to submit request");
        }

        // Get profile email options and send the notification
        Profile profile = null;
        if(request.getRequestStatus().equals(RequestStatus.PENDING)){
            ProfileSearchCriteria criteria = new ProfileSearchCriteria();
            criteria.setUserIdentifier(request.getUserIdentifier());
            SearchResult<Profile> search = profileService.search(criteria);
            List<Profile> values = search.getValues();
            if(!values.isEmpty()){
                profile = values.get(0);
            }
        } else {
            profile = profileService.getDefaultProfile();
        }
        if(profile != null){
        	notificationService.sendRequest(request, exportedRequest, profile, additionalFile);
        }
        
        // For SRT4 path send request file to FTP server
        if (request.getEngagementTypeData().calculateSRTPath() == SRTPath.SRT4) {
            ftpService.sendRequest(request, exportedRequest);
        }

        // Update the request status
        request.setRequestStatus(RequestStatus.SUBMITTED);

        StartRequestData startRequestData = request.getStartRequestData();
        if (startRequestData != null && startRequestData.getAttachments() != null) {
            // Clear attachment entities
            startRequestData.getAttachments().clear();
        }

        request = update(request); // update will remove the attachments

        // Log exit
        Helper.logExit(logger, signature, new Object[]{request});
        return request;
    }
    
    /**
     * Submits a request for approval.
     *
     * @param request
     *         the request to be submitted for approval
     * @param exportedRequest
     *         the PDF file of exported request. It is set as an attachment.
     * @return the result request
     * @throws IllegalArgumentException
     *         request/exportedRequest is null.
     * @throws AuthorizationException
     *         if user is not allowed to submit.
     * @throws NotificationServiceException
     *         if there is any problem when sending email.
     * @throws ServiceRequestToolException
     *         if there is any problem updating the request.
     * @since 1.11
     */
    @Transactional(rollbackFor = {ServiceRequestToolException.class, NotificationServiceException.class})
    @SyncUp(entityType = "Request")
    public Request submitRequestForApproval(Request request, File exportedRequest)
            throws ServiceRequestToolException, NotificationServiceException {
        final String signature = CLASSNAME + "#submitRequestForApproval(Request request, File exportedRequest)";
        Logger logger = getLogger();

        // Log entry
        Helper.logEntrance(logger, signature, new String[]{"request", "exportedRequest"}, new Object[]{request,
                exportedRequest});

        Helper.checkNull(logger, signature, request, "request");
        Helper.checkNull(logger, signature, exportedRequest, "exportedRequest");
        if (!getAppService().isStandaloneMode()) {
            Helper.checkNull(logger, signature, ServiceContext.getCurrentUser(),
                    "User must be logged in to submit the request for approval");
        }

        // Get profile email options and send the notification
        Profile profile = profileService.getDefaultProfile();
        
        String approverEmail = request.getApprover() != null ? request.getApprover().getEmail() : null;
        List<String> additionalRecipientsEmails = new ArrayList<String>();
        List<Profile> additionalRecipients = request.getAdditionalRecipients();
        if(additionalRecipients != null){
            for (Profile recipient : additionalRecipients) {
                additionalRecipientsEmails.add(recipient.getEmail());
            }
        }
        
        notificationService.sendRequestApprovalEmails(approverEmail, additionalRecipientsEmails, request, exportedRequest, profile);
        
        // Update the request status
        request.setRequestStatus(RequestStatus.PENDING);

        StartRequestData startRequestData = request.getStartRequestData();
        if (startRequestData != null && startRequestData.getAttachments() != null) {
            // Clear attachment entities
            startRequestData.getAttachments().clear();
        }

        request = update(request); // update will remove the attachments
        // Log exit
        Helper.logExit(logger, signature, new Object[]{request});
        return request;
    }

    /**
     * Checks user privilege before create. Also sets the user identifier.
     *
     * @param entity
     *         the entity to be created
     * @throws AuthorizationException
     *         if user is not allowed to create
     * @throws AlreadySynchronizedException
     *         if operation log is already synchronized
     * @throws ServiceRequestToolException
     *         if any error occurs.
     */
    @Override
    protected void beforeCreate(Request entity) throws AlreadySynchronizedException, ServiceRequestToolException {
        super.beforeCreate(entity);

        Customer newCustomer = entity.getCustomer();
        if (newCustomer != null && !getAppService().isStandaloneMode()) {
            newCustomer.setUserIdentifier(ServiceContext.getCurrentUser().getUserIdentifier());
            // Customer entity associated with request is managed along within that request,
            // that means such customer entity does not need be separately synchronized.
            // So let the correlated id be 0, and no operation log needed for such Customer.
            newCustomer.setCorrelatedId(0);
        }

        // Handle uploaded attachment files
        handleUploadFiles(entity);
    }

    /**
     * Checks user privilege before update. Also sets the user identifier.
     *
     * @param entity
     *         the entity to be updated
     * @throws AuthorizationException
     *         if user is not allowed to update
     * @throws AlreadySynchronizedException
     *         if operation log is already synchronized
     * @throws EntityNotFoundException
     *         if the entity does not exist
     * @throws ServiceRequestToolException
     *         if any other error occurs
     */
    @Override
    protected void beforeUpdate(Request entity) throws ServiceRequestToolException {
        super.beforeUpdate(entity);

        Customer newCustomer = entity.getCustomer();

        if (newCustomer != null && !getAppService().isStandaloneMode()) {
            newCustomer.setUserIdentifier(ServiceContext.getCurrentUser().getUserIdentifier());
            // Customer entity associated with request is managed along within that request,
            // that means such customer entity does not need be separately synchronized.
            // So let the correlated id be 0, and no operation log needed for such Customer.
            newCustomer.setCorrelatedId(0);
        }

        // Handle uploaded attachment files
        handleUploadFiles(entity);

        // Collect the new attachments
        Set<String> newAttachmentFiles = new HashSet<String>();
        if (entity.getStartRequestData() != null && entity.getStartRequestData().getAttachments() != null) {
            for (Attachment attachment : entity.getStartRequestData().getAttachments()) {
                newAttachmentFiles.add(attachment.getAttachmentFilepath());
            }
        }

        // Collect the old attachments which need be deleted
        List<String> attachmentsToDelete = new ArrayList<String>();
        Request existingRequest = get(entity.getId());
        if (existingRequest.getStartRequestData() != null
                && existingRequest.getStartRequestData().getAttachments() != null) {
            for (Attachment attachment : existingRequest.getStartRequestData().getAttachments()) {
                if (!newAttachmentFiles.contains(attachment.getAttachmentFilepath())) {
                    attachmentsToDelete.add(attachment.getAttachmentFilepath());
                }
            }
        }

        ATTACHMENTS_TO_DELETE.set(attachmentsToDelete);
    }

    /**
     * Decides if the current user has access permissions on the entity
     * 
     * @param entity
     *            The entity
     * @return true if the current user has update permissions
     * @throws ServiceRequestToolException If any exception occurs
     * @since 1.11
     */
    @Override
    protected boolean hasPrivilegesToAccess(Request request) throws ServiceRequestToolException {
        Profile defaultProfile = profileService.getDefaultProfile();
        if(request.getRequestStatus() == RequestStatus.PENDING){
            Profile approver = request.getApprover();
            if(approver != null && approver.getId() == defaultProfile.getId()){
                return true;
            }
        }
        return super.hasPrivilegesToAccess(request);
    }
    
    /**
     * Adds operation log after update. It deletes the attachments as well.
     *
     * @param entity
     *            the entity updated
     * @throws ServiceRequestToolException
     *             if any error occurs
     */
    @Override
    protected void afterUpdate(Request entity) throws ServiceRequestToolException {
        super.afterUpdate(entity);

        List<String> attachmentsToDelete = ATTACHMENTS_TO_DELETE.get();
        // Delete attachment files
        deleteAttachmentFiles(attachmentsToDelete);
    }

    /**
     * Checks user privilege before delete. If checks the attachments to delete as well.
     *
     * @param id
     *            the id of entity to be deleted
     * @return the existing entity to be deleted
     * @throws AuthorizationException
     *             if user is not allowed to delete
     * @throws AlreadySynchronizedException
     *             if operation log is already synchronized
     * @throws EntityNotFoundException
     *             if the entity does not exist
     * @throws ServiceRequestToolException
     *             if any other error occurs
     */
    @Override
    protected Request beforeDelete(long id) throws ServiceRequestToolException {
        Request request = super.beforeDelete(id);

        // Collect the attachment files which need be deleted
        List<String> attachmentsToDelete = new ArrayList<String>();
        if (request.getStartRequestData() != null
                && request.getStartRequestData().getAttachments() != null) {
            for (Attachment attachment : request.getStartRequestData().getAttachments()) {
                attachmentsToDelete.add(attachment.getAttachmentFilepath());
            }
        }

        ATTACHMENTS_TO_DELETE.set(attachmentsToDelete);
        return request;
    }

    /**
     * Adds operation log after delete. It deletes the attachments as well.
     *
     * @param entity
     *            the entity deleted
     * @throws ServiceRequestToolException
     *             if any error occurs
     */
    @Override
    protected void afterDelete(Request entity) throws ServiceRequestToolException {
        super.afterDelete(entity);

        List<String> attachmentsToDelete = ATTACHMENTS_TO_DELETE.get();

        // Delete attachment files
        deleteAttachmentFiles(attachmentsToDelete);
    }

    /**
     * Skips permission check if request status is template.
     *
     * @param entity
     *            the entity got
     * @throws ServiceRequestToolException
     *             if any error occurs
     */
    @Override
    protected void afterGet(Request entity) throws ServiceRequestToolException {
        if (entity.getRequestStatus() != RequestStatus.TEMPLATE) {
            if (entity.getRequestStatus() == RequestStatus.PENDING
                    || entity.getRequestStatus() == RequestStatus.SUBMITTED) {
                if (!canAccessSubmittedRequest(entity)) {
                    throw new AuthorizationException("You do not have access to view this request");
                }
            } else {
                super.afterGet(entity);
            }
        }
    }

    /**
     * Checks if the current user can access a submitted/pending request which
     * was submitted for approval.
     * 
     * @param request
     *            The request to be checked
     * 
     * @return true if the current user can access the request; false otherwise
     * @since 1.11
     */
    private boolean canAccessSubmittedRequest(Request request) {
        Profile approver = request.getApprover();
        if (approver != null) {
            User currentUser = ServiceContext.getCurrentUser();
            String userIdentifier = currentUser.getUserIdentifier();
            if (userIdentifier.equals(request.getUserIdentifier())
                    || userIdentifier.equals(approver.getUserIdentifier())) {
                return true;
            }
            List<Profile> additionalRecipients = request.getAdditionalRecipients();
            for (Profile profile : additionalRecipients) {
                if (userIdentifier.equals(profile.getUserIdentifier())) {
                    return true;
                }
            }
            return false;
        }
        return true;
    }

    /**
     * This method checks the attachment files exist, and renames any temporary uploaded file by removing the
     * TMP_UPLOAD_SUFFIX.
     *
     * @param request
     *         The request to create/update
     * @throws ServiceRequestToolException
     *         if there is any problem executing the request.
     */
    private void handleUploadFiles(Request request) throws ServiceRequestToolException {
        if (request.getStartRequestData() != null && request.getStartRequestData().getAttachments() != null) {
            for (Attachment attachment : request.getStartRequestData().getAttachments()) {

                String attachmentFilepath = attachment.getAttachmentFilepath();

                if (StringUtils.isBlank(attachmentFilepath)) {
                    throw new ServiceRequestToolException("Attachment file name can not be null/empty.");
                }

                File attachmentFile = new File(attachmentUploadFolder, attachmentFilepath);

                // See if the file name has TMP_UPLOAD_SUFFIX
                if (attachmentFilepath.endsWith(Helper.TMP_UPLOAD_SUFFIX)) {
                    // The persistent file with TMP_UPLOAD_SUFFIX removed
                    String persistFileName = attachmentFilepath.substring(0, attachmentFilepath.length()
                            - Helper.TMP_UPLOAD_SUFFIX.length());

                    File persistFile = new File(attachmentUploadFolder, persistFileName);

                    if (persistFile.exists()) {
                        // Persistent file already exists
                        attachment.setAttachmentFilepath(persistFileName);
                        continue;
                    }

                    // Check the temporary file exists
                    if (!attachmentFile.exists()) {
                        throw new ServiceRequestToolException("Attachment file does not exist.");
                    }

                    if (!attachmentFile.renameTo(persistFile)) {
                        // Rename failed, fall back to copy
                        try {
                            FileUtils.copyFile(attachmentFile, persistFile);
                        } catch (IOException e) {
                            throw new ServiceRequestToolException("Failed to copy attachment file.", e);
                        }
                    }

                    attachment.setAttachmentFilepath(persistFileName);
                } else if (!attachmentFile.exists()) {
                    throw new ServiceRequestToolException("Attachment does not exist.");
                }
            }
        }
    }

    /**
     * Deletes attachment files.
     *
     * @param attachmentsToDelete
     *         List of attachment files to delete
     * @throws ServiceRequestToolException
     *         if attachmentsToDelete is null, or there is any problem failed to check if the file can be deleted.
     */
    private void deleteAttachmentFiles(List<String> attachmentsToDelete) throws ServiceRequestToolException {

        if (attachmentsToDelete == null) {
            throw new ServiceRequestToolException("attachmentsToDelete is null");
        }

        if (attachmentsToDelete.size() == 0) {
            return;
        }

        final List<File> filesToDelete = new ArrayList<File>();

        for (String attachmentFile : attachmentsToDelete) {

            // The attachment file can be deleted only if it is not used by any Attachment entity
            if (StringUtils.isBlank(attachmentFile) || isAttachmentFileInUse(attachmentFile)) {
                // The attachment may still be in use because of request coping
                // , so do NOT delete it from file system
                continue;
            }

            filesToDelete.add(new File(attachmentUploadFolder, attachmentFile));
        }

        if (filesToDelete.size() != 0) {
            // only delete the files after the transaction is really committed.
            TransactionSynchronizationManager.registerSynchronization(
                    new TransactionSynchronizationAdapter() {
                        @Override
                        public void afterCommit() {
                            for (File toDelete : filesToDelete) {
                                if (!toDelete.delete()) {
                                    // Just a warn message
                                    getLogger().warn("Attachment file can not be deleted: " + toDelete);
                                }
                            }
                        }
                    }
            );
        }
    }

    /**
     * This method checks whether the instance of the class was initialized properly.
     *
     * @throws com.emc.gs.tools.srf.ServiceRequestToolConfigurationException
     *         if notificationService/profileService is null
     * @since SRT Phase 2 Release Assembly
     */
    @PostConstruct
    protected void checkInit() {
        super.checkInit();
        Helper.checkState(notificationService == null, "'notificationService' can't be null.");
        Helper.checkState(profileService == null, "'profileService' can't be null.");

        Helper.checkState(StringUtils.isBlank(attachmentUploadFolder),
                "'attachmentUploadFolder' can't be null/empty.");

        File folder = new File(attachmentUploadFolder);
        getLogger().info("AttachmentUploadFolder is: " + folder.getAbsolutePath());

        if (!folder.exists()) {
            Helper.checkState(!folder.mkdirs(), "Unable to create 'attachmentUploadFolder'");
        }
    }

    /**
     * <p>
     * Sets the value to notificationService field.
     * </p>
     *
     * @param notificationService
     *         the value of notificationService to set
     * @since SRT Phase 2 Release Assembly
     */
    public void setNotificationService(NotificationService notificationService) {
        this.notificationService = notificationService;
    }

    /**
     * <p>
     * Sets the value to profileService field.
     * </p>
     *
     * @param profileService
     *         the value of profileService to set
     * @since SRT Phase 2 Release Assembly
     */
    public void setProfileService(ProfileService profileService) {
        this.profileService = profileService;
    }

    /**
     * Setter method for property <tt>attachmentUploadFolder</tt>.
     *
     * @param attachmentUploadFolder
     *         value to be assigned to property attachmentUploadFolder
     */
    public void setAttachmentUploadFolder(String attachmentUploadFolder) {
        this.attachmentUploadFolder = attachmentUploadFolder;
    }

    /**
     * <p>Sets the ftpService property.</p>
     *
     * @param ftpService a <code>FTPService</code> providing the value for ftpService property.
     * @since 1.9
     */
    public void setFtpService(FTPService ftpService) {
        this.ftpService = ftpService;
    }

}

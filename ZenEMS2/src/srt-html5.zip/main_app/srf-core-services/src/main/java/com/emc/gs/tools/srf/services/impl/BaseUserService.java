/*
 * This code is copyright (c) 2014-2015 EMC Corporation.
 */
package com.emc.gs.tools.srf.services.impl;

import javax.persistence.PersistenceException;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.transaction.annotation.Transactional;

import com.emc.gs.tools.srf.AuthorizationException;
import com.emc.gs.tools.srf.model.User;
import com.emc.gs.tools.srf.services.ServiceRequestToolException;
import com.emc.gs.tools.srf.services.UserService;

/**
 * <p>
 * This is the base implementation of UserService. It implements the common authentication logic
 * for both cloud and local app.
 * </p>
 *
 * <p>
 * <strong>Thread safety</strong>: The implementation are required to be thread safe.
 * </p>
 *
 * <p>
 * Version 1.1 Change notes:
 *   <ol>
 *     <li>Supporting new Job Title and Country properties for User entity.</li>
 *   </ol>
 * </p>
 * 
 * <p>
 * Version 1.2 Change notes:
 *   <ol>
 *     <li>Modified authenticate method to validate first login and don't update the profile.</li>
 *   </ol>
 * </p>
 * 
 * @author isv, MonicaMuranyi
 * @version 1.2
 * @since SRT Phase 4 - ET Assembly 2
 */
public abstract class BaseUserService extends BasePersistenceService implements UserService {

    /**
     * Empty constructor.
     */
    protected BaseUserService() {
    }

    /**
     * Authenticate given user.
     * 
     * @param user
     *            the user to be authenticated
     * @return the authenticated user
     * @throws IllegalArgumentException
     *             if given user is null, or if its userIdentifier is null or empty
     * @throws AuthorizationException
     *             if given user is not authorized
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     */
    @Transactional(rollbackFor = {AuthorizationException.class, ServiceRequestToolException.class})
    public User authenticate(User user) throws ServiceRequestToolException {
        final String signature = getClass().getName() + "#authenticate(User user)";
        Logger logger = getLogger();

        // Log entry
        Helper.logEntrance(logger, signature, new String[] {"user"}, new Object[] {user});

        // Check given user
        Helper.checkNull(logger, signature, user, "user");

        // User identifier must be present
        Helper.checkStrNullEmpty(logger, signature, user.getUserIdentifier(), "userIdentifier");

        try {
            // Get matched user
            User matchedUser = getMatchedUser(user);

            String firstName = user.getFirstName();
            String country = user.getCountry();
            if (matchedUser == null) {
                // Create new user
                String lastName = user.getLastName();
                String email = user.getEmail();
                if (StringUtils.isBlank(firstName) || StringUtils.isBlank(lastName) || StringUtils.isBlank(country)
                        || StringUtils.isBlank(email)) {
                    throw Helper.logException(logger, signature, new ServiceRequestToolException(
                            "First Name, Last Name, Country and Email are required for first login."));
                }
                logger.info("Create new user: " + user.getUserIdentifier());
                getEntityManager().persist(user);
                matchedUser = user;
            }

            // Log exit
            Helper.logExit(logger, signature, new Object[] {matchedUser});

            return matchedUser;
        } catch (IllegalStateException e) {
            // Log exception
            throw Helper.logException(logger, signature, new ServiceRequestToolException(
                    "The entity manager has been closed.", e));
        } catch (PersistenceException e) {
            // Log exception
            throw Helper.logException(logger, signature, new ServiceRequestToolException(
                    "An error has occurred while accessing the persistence.", e));
        } catch (AuthorizationException e) {
            // Log exception
            throw Helper.logException(logger, signature, e);
        } catch (ServiceRequestToolException e) {
            // Log exception
            throw Helper.logException(logger, signature, e);
        }
    }

    /**
     * Gets matched user.
     * 
     * @param user
     *            the user to be authenticated
     * @return the matched user
     * @throws AuthorizationException
     *             if current user does not match given user
     * @throws ServiceRequestToolException
     *             if any error occurred during the operation
     */
    protected abstract User getMatchedUser(User user) throws ServiceRequestToolException;
}

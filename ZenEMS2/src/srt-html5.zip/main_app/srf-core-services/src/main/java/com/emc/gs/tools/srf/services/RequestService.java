/*
 * This code is copyright (c) 2013 - 2015 EMC Corporation.
 */
package com.emc.gs.tools.srf.services;

import java.io.File;

import com.emc.gs.tools.srf.AuthorizationException;
import com.emc.gs.tools.srf.model.Request;
import com.emc.gs.tools.srf.model.RequestSearchCriteria;
import com.emc.gs.tools.srf.model.SearchResult;
import com.emc.gs.tools.srf.model.StartRequestData;
import com.emc.gs.tools.srf.model.bc.BcRequestData;
import com.emc.gs.tools.srf.model.infrastructure.InfrastructureRequestData;
import com.emc.gs.tools.srf.model.mainframe.MainframeRequestData;
import com.emc.gs.tools.srf.model.unified.UnifiedRequestData;

/**
 * <p>
 * This interface defines a contract for managing a request. It is simply extends GenericService to provide
 * necessary create, update, delete and get methods and additionally provides a search method based on
 * criteria.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: The implementation are required to be thread safe.
 * </p>
 *
 * <p>
 * <strong>Changes V1.1:</strong>
 * <strong>SRT Phase 2 Release Assembly</strong>
 * <ul>
 * <li>Add submitRequest() method</li>
 * </ul>
 * </p>
 *
 * <p>
 * Version 1.2 Change notes:
 *   <ol>
 *     <li>Added submitRequestForApproval method.</li>
 *   </ol>
 * </p>
 *
 * @author faeton, stevenfrog, MonicaMuranyi
 * @version 1.2
 */
public interface RequestService extends GenericService<Request> {

    /**
     * Checks whether the attachment file is in use (referenced by any Attachment entity).
     *
     * @param attachmentFile
     *            the attachment file to check if it is in use.
     * @return true if the attachment file is in use; false otherwise.
     * @throws IllegalArgumentException
     *             if attachmentFile is null or empty
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     */
    public boolean isAttachmentFileInUse(String attachmentFile) throws ServiceRequestToolException;

    /**
     * Returns StartRequestData instance for the request id.
     *
     * @param requestId
     *            the request id to retrieve request data
     * @return the request data details
     * @throws IllegalArgumentException
     *             if requestId is not positive
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     */
    public StartRequestData getStartRequestData(long requestId) throws ServiceRequestToolException;

    /**
     * Returns BcRequestData instance for the request id.
     *
     * @param requestId
     *            the request id to retrieve request data
     * @return the request data details
     * @throws IllegalArgumentException
     *             if requestId is not positive
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     */
    public BcRequestData getBcRequestData(long requestId) throws ServiceRequestToolException;

    /**
     * Returns MainframeRequestData instance for the request id.
     *
     * @param requestId
     *            the request id to retrieve request data
     * @return the request data details
     * @throws IllegalArgumentException
     *             if requestId is not positive
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     */
    public MainframeRequestData getMainframeRequestData(long requestId) throws ServiceRequestToolException;

    /**
     * Returns UnifiedRequestData instance for the request id.
     *
     * @param requestId
     *            the request id to retrieve request data
     * @return the request data details
     * @throws IllegalArgumentException
     *             if requestId is not positive
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     */
    public UnifiedRequestData getUnifiedRequestData(long requestId) throws ServiceRequestToolException;

    /**
     * Returns InsfrastructureRequestData instance for the request id.
     *
     * @param requestId
     *            the request id to retrieve request data
     * @return the request data details
     * @throws IllegalArgumentException
     *             if requestId is not positive
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     */
    public InfrastructureRequestData getInfrastructureRequestData(long requestId)
        throws ServiceRequestToolException;

    /**
     * Search requests based on the search criteria.
     *
     * @param criteria
     *            the search criteria
     * @return the search result
     * @throws IllegalArgumentException
     *             if criteria is null, or if criteria.pageNumber is positive and criteria.pageSize is not
     *             positive
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     */
    public SearchResult<Request> search(RequestSearchCriteria criteria) throws ServiceRequestToolException;

    /**
     * Submits a request.
     * @param request
     *            the request to be submitted
     * @param exportedRequest
     *            the PDF file of exported request. It is set as an attachment.
     * @param additionalFile additional files to attach.           
     * @return the result request
     * @throws IllegalArgumentException
     *             request/exportedRequest is null.
     * @throws NotificationServiceException
     *             if there is any problem when sending email.
     * @throws ServiceRequestToolException
     *             if there is any problem updating the request.
     * @since SRT Phase 2 Release Assembly
     */
    @SyncUp(entityType = "Request")
    public Request submitRequest(Request request, File exportedRequest, File additionalFile)
            throws ServiceRequestToolException, NotificationServiceException;

    /**
     * Submits a request for approval.
     *
     * @param request
     *         the request to be submitted for approval
     * @param exportedRequest
     *         the PDF file of exported request. It is set as an attachment.
     * @return the result request
     * @throws IllegalArgumentException
     *         request/exportedRequest is null.
     * @throws AuthorizationException
     *         if user is not allowed to submit.
     * @throws NotificationServiceException
     *         if there is any problem when sending email.
     * @throws ServiceRequestToolException
     *         if there is any problem updating the request.
     * @since 1.2
     */
    @SyncUp(entityType = "Request")
    public Request submitRequestForApproval(Request request, File exportedRequest) throws ServiceRequestToolException,
            NotificationServiceException;
}

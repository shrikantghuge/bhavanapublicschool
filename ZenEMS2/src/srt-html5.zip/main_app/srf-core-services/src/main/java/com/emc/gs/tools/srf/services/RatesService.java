/*
 * This code is copyright (c) 2014 EMC Corporation.
 */
package com.emc.gs.tools.srf.services;

import java.math.BigDecimal;
import java.util.Map;

/**
 * <p>
 * This interface defines a contract to manage rates data.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: The implementation are required to be thread safe.
 * </p>
 * @author TCSASSEMBLER
 * @version 1.0
 * @since SRT Phase 4 - ET Assembly 1
 */
public interface RatesService {

    /**
     * Retrieves standard bill rates data.
     * 
     * @return the standard bill rates data.
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     */
    public Map<String, BigDecimal> retrieveStandardBillRates() throws ServiceRequestToolException;

    /**
     * Retrieves hourly standard cost rates data.
     * 
     * @return the hourly standard cost rates data.
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     */
    public Map<String, BigDecimal> retrieveHourlyStdCostRates() throws ServiceRequestToolException;

    /**
     * Refreshes rates data.
     * 
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     */
    public void refreshRates() throws ServiceRequestToolException;
}

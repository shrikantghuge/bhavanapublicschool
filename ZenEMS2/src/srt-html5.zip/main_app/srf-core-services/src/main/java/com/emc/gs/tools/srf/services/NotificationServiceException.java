/*
 * This code is copyright (c) 2013 - 2014 EMC Corporation.
 */
package com.emc.gs.tools.srf.services;

/**
 * <p>
 * This exception is thrown when there is any problem when sending notification.
 * </p>
 *
 * <p>
 * <strong>Thread safety</strong>: exception class is not thread safety.
 * </p>
 *
 * @author faeton, stevenfrog
 * @version 1.0
 */
public class NotificationServiceException extends Exception {
    /**
     * The serial version UID.
     */
    private static final long serialVersionUID = -879572719811555840L;

    /**
     * Creates the exception with the provided message.
     *
     * @param message
     *            the error message.
     */
    public NotificationServiceException(String message) {
        super(message);
    }

    /**
     * Creates the exception with the provided message and cause.
     *
     * @param message
     *            the error message.
     * @param cause
     *            the error cause.
     */
    public NotificationServiceException(String message, Throwable cause) {
        super(message, cause);
    }
}

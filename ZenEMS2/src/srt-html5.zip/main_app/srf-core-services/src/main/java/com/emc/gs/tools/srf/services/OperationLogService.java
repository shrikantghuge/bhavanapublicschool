/*
 * This code is copyright (c) 2014-2015 EMC Corporation.
 */
package com.emc.gs.tools.srf.services;

import java.util.List;

import com.emc.gs.tools.srf.AuthorizationException;
import com.emc.gs.tools.srf.model.OperationLog;

/**
 * <p>
 * TThis service defines methods to manage operation logs.
 * </p>
 *
 * <p>
 * <strong>Thread safety</strong>: The implementation are required to be thread safe.
 * </p>
 *
 * <p>
 * <strong>Changes V1.1:</strong>
 * <strong>SRT Phase 4 - ET Assembly 2</strong>
 * <ul>
 * <li>Change get()/add() methods to require the current user present.</li>
 * <li>Change get() method to accept entity id and begin sequence parameters.</li>
 * <li>Add getLastSynchronizedSequence() method to get last sequence of synchronized operation logs.</li>
 * <li>Add operationLogSynchronizedDown() method to process logs after it is synchronized down.</li>
 * <li>Add operationLogSynchronizedUp() method to process logs after it is synchronized up.</li>
 * </ul>
 * </p>
 *
 * <p>
 * <strong>Changes V1.2:</strong>
 * <strong>SRT 1.1 Approval Process Assembly</strong>
 * <ul>
 * <li>Added allUserLogs param to get method.</li>
 * </ul>
 * </p>
 *
 * @author zsudraco, MonicaMuranyi
 * @version 1.2
 */
public interface OperationLogService {

    /**
     * Adds an operation log.
     *
     * @param log
     *            the log to create
     * @return The created log
     * @throws IllegalArgumentException
     *             if log is null
     * @throws AuthorizationException
     *             if user is not allowed to add operation log
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     */
    public void add(OperationLog log) throws ServiceRequestToolException;

    /**
     * Gets all logs for the specified entity type, entity ID and begin sequence.
     *
     * @param entityType
     *            the entityTyp of the logs to retrieve
     * @param entityId
     *            the entityId for the search, if present then only
     *            log for that entity ID will be returned
     * @param beginSeq
     *            the begin sequence for the search, if present then only
     *            logs newer than this sequence will be returned
     * @param allUserLogs flag indicating whether to get all the logs, not only the ones related to the current user
     * @return The list of the matching operation logs
     * @throws IllegalArgumentException
     *             if entityType is null or empty
     * @throws AuthorizationException
     *             if user is not allowed to get operation log
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     */
    public List<OperationLog> get(String entityType, Long entityId, Long beginSeq, boolean allUserLogs) throws ServiceRequestToolException;

    /**
     * Gets last synchronized sequence for the specified entity type.
     * 
     * @param entityType
     *            the entityTyp retrieve last synchronized sequence
     * @return The last synchronized sequence for the specified entity type
     * @throws IllegalArgumentException
     *             if entityType is null or empty
     * @throws AuthorizationException
     *             if user is not allowed to get last synchronized sequence
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     */
    public Long getLastSynchronizedSequence(String entityType) throws ServiceRequestToolException;

    /**
     * Processes operation log after it is synchronized down.
     *
     * @param log
     *            the log to process after it is synchronized down
     * @throws IllegalArgumentException
     *             if log is null
     * @throws AuthorizationException
     *             if user is not allowed to process operation log
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     */
    public void operationLogSynchronizedDown(OperationLog log) throws ServiceRequestToolException;

    /**
     * Processes operation log after it is synchronized up.
     *
     * @param log
     *            the log to process after it is synchronized up
     * @throws IllegalArgumentException
     *             if log is null
     * @throws AuthorizationException
     *             if user is not allowed to process operation log
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     */
    public void operationLogSynchronizedUp(OperationLog log) throws ServiceRequestToolException;
}

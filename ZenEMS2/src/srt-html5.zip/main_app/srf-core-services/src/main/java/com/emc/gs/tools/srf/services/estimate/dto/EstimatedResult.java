/*
 * This code is copyright (c) 2014 EMC Corporation.
 */
package com.emc.gs.tools.srf.services.estimate.dto;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.emc.gs.tools.srf.model.estimate.EstimatesData;
import com.emc.gs.tools.srf.model.estimate.LOBResources;

/**
 * <p>
 * This is EstimatedResult DTO class. It extends form EstimatesData.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safety.
 * </p>
 * 
 * @author TCSASSEMBLER
 * @version 1.0
 * @since SRT Phase 4 - ET Assembly 1
 */
public class EstimatedResult extends EstimatesData {

    /**
     * The list of estimated LOBs.
     */
    private List<EstimatedLOB> estimatedLOBs = new ArrayList<EstimatedLOB>();

    /**
     * The total pricing overview.
     */
    private PricingOverview totalOverview = new PricingOverview();

    /**
     * The project start date.
     */
    private Date projectStartDate;

    /**
     * The project end date.
     */
    private Date projectEndDate;

    /**
     * Empty constructor.
     */
    public EstimatedResult() {    
    }

    /**
     * Constructor with estimates data.
     * 
     * @param estimatesData
     *            the estimates data
     */
    public EstimatedResult(EstimatesData estimatesData) {

        // Copy all properties
        super.setId(estimatesData.getId());
        super.setDealCurrency(estimatesData.getDealCurrency());
        super.setDeliverAction(estimatesData.getDeliverAction());
        super.setDeliverDescription(estimatesData.getDeliverDescription());
        super.setExpenseAmount(estimatesData.getExpenseAmount());
        super.setClientPricingOverride(estimatesData.getClientPricingOverride());
        super.setEstimatedPercent(estimatesData.getEstimatedPercent());
        super.setCappedPercent(estimatesData.getCappedPercent());
        super.setIpEduData(estimatesData.getIpEduData());

        if (estimatesData.getLobResources() != null) {
            for (LOBResources lob : estimatesData.getLobResources()) {
                estimatedLOBs.add(new EstimatedLOB(lob));
            }
        }
    }

    /**
     * Getter method for property <tt>estimatedLOBs</tt>.
     * 
     * @return property value of estimatedLOBs
     */
    public List<EstimatedLOB> getEstimatedLOBs() {
        return estimatedLOBs;
    }

    /**
     * Setter method for property <tt>estimatedLOBs</tt>.
     * 
     * @param estimatedLOBs
     *            value to be assigned to property estimatedLOBs
     */
    public void setEstimatedLOBs(List<EstimatedLOB> estimatedLOBs) {
        this.estimatedLOBs = estimatedLOBs;
    }

    /**
     * Getter method for property <tt>totalOverview</tt>.
     * 
     * @return property value of totalOverview
     */
    public PricingOverview getTotalOverview() {
        return totalOverview;
    }

    /**
     * Setter method for property <tt>totalOverview</tt>.
     * 
     * @param totalOverview
     *            value to be assigned to property totalOverview
     */
    public void setTotalOverview(PricingOverview totalOverview) {
        this.totalOverview = totalOverview;
    }

    /**
     * Getter method for property <tt>projectStartDate</tt>.
     * 
     * @return property value of projectStartDate
     */
    public Date getProjectStartDate() {
        return projectStartDate;
    }

    /**
     * Setter method for property <tt>projectStartDate</tt>.
     * 
     * @param projectStartDate
     *            value to be assigned to property projectStartDate
     */
    public void setProjectStartDate(Date projectStartDate) {
        this.projectStartDate = projectStartDate;
    }

    /**
     * Getter method for property <tt>projectEndDate</tt>.
     * 
     * @return property value of projectEndDate
     */
    public Date getProjectEndDate() {
        return projectEndDate;
    }

    /**
     * Setter method for property <tt>projectEndDate</tt>.
     * 
     * @param projectEndDate
     *            value to be assigned to property projectEndDate
     */
    public void setProjectEndDate(Date projectEndDate) {
        this.projectEndDate = projectEndDate;
    }

}

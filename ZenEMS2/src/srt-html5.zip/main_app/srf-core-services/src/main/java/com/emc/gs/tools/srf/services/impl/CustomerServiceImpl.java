/*
 * This code is copyright (c) 2013 - 2015 EMC Corporation.
 */
package com.emc.gs.tools.srf.services.impl;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceException;
import javax.persistence.TypedQuery;

import org.apache.log4j.Logger;

import com.emc.gs.tools.srf.model.Customer;
import com.emc.gs.tools.srf.model.CustomerSearchCriteria;
import com.emc.gs.tools.srf.model.SearchResult;
import com.emc.gs.tools.srf.model.ServiceContext;
import com.emc.gs.tools.srf.model.SortOrder;
import com.emc.gs.tools.srf.model.User;
import com.emc.gs.tools.srf.services.CustomerService;
import com.emc.gs.tools.srf.services.ServiceRequestToolException;

/**
 * <p>
 * This class is the implementation of the CustomerService. It utilizes JPA EntityManager for necessary
 * operations.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is effectively thread safe after configuration, the
 * configuration is done in a thread safe manner.
 * </p>
 *
 * <p>
 * <strong>Changes:</strong>
 * <strong>SRT Release Assembly - Base</strong>
 * <ul>
 * <li>Changed customer name field</li>
 * </ul>
 * </p>
 * 
 * <p>
 * <strong>Change 1.2:</strong>
 * <strong>BUGR-10829</strong>
 * <ul>
 * <li>change setQueryByCriteria to support case insensitive search</li>
 * </ul>
 * </p>
 * 
 * <p>
 * <strong>Changes V1.3:</strong>
 * <ul>
 * <li>Removed shortName field handling.</li>
 * </ul>
 * </p>
 *
 * <p>
 * <strong>Change 1.4:</strong>
 * <strong>SRT Cloud Synchronization - Cloud App Assembly</strong>
 * <ul>
 * <li>added create, update, get and delete methods</li>
 * <li>added userIdentifier parameter to setQueryByCriteria and setParaByCriteria</li>
 * </ul>
 * </p>
 *
 * <p>
 * <strong>Changes V1.5:</strong>
 * <strong>SRT Phase 4 - ET Assembly 2</strong>
 * <ul>
 * <li>Extend from BaseCorrelatedEntityService.</li>
 * </ul>
 * </p>
 * 
 * <p>
 * <strong>Changes V1.6:</strong>
 * <strong>SRT 1.1 DEC 2014 Updates Assembly</strong>
 * <ul>
 * <li>Replaced customer "geoState" field name with "region".</li>
 * </ul>
 * </p>
 * 
 * <p>
 * <strong>Changes V1.7:</strong>
 * <strong>SRT HTML5 ET Production Fixes Part 2 Assembly 1.0</strong>
 * <ul>
 * <li>Add the search by country for the search method</li>
 * </ul>
 * </p>
 * @author faeton, stevenfrog, TCSASSEMBLER, MonicaMuranyi
 * @version 1.7
 */
public class CustomerServiceImpl extends BaseCorrelatedEntityService<Customer> implements CustomerService {
    /**
     * <p>
     * Represents the class name.
     * </p>
     */
    private static final String CLASSNAME = CustomerServiceImpl.class.getName();

    /**
     * The query string to get template Customer.
     */
    private static final String SQL_CUSTOMER_REQUEST = "SELECT c FROM Customer c WHERE c.template = true";

    /**
     * The query string to get template Customer's total size.
     */
    private static final String SQL_QUERY_CUSTOMER_COUNT = "SELECT COUNT(c) FROM Customer c WHERE c.template = true";

    /**
     * Creates instance of the class.
     */
    public CustomerServiceImpl() {
        super(Customer.class);
    }

    /**
     * Search template customers based on the search criteria.
     *
     * @throws IllegalArgumentException
     *             if criteria is null, or if criteria.pageNumber is positive, criteria.pageSize is not
     *             positive
     * @throws com.emc.gs.tools.srf.services.ServiceRequestToolException
     *             if any other error occurred during the operation
     * @param criteria
     *            the search criteria
     * @return the search result
     */
    public SearchResult<Customer> search(CustomerSearchCriteria criteria) throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#search(CustomerSearchCriteria criteria)";
        Logger logger = getLogger();

        // Log entry
        Helper.logEntrance(logger, signature, new String[]{"criteria"}, new Object[]{criteria});

        Helper.checkNull(logger, signature, criteria, "criteria");
        if (criteria.getPageNumber() > 0 && criteria.getPageSize() <= 0) {
            // Log exception
            throw Helper.logException(logger, signature, new IllegalArgumentException(
                    "'criteria.pageSize' must be positive when criteria.pageNumber is positive."));
        }

        try {
            // Set default sorting order and column
            if (criteria.getSortBy() == null) {
                criteria.setSortBy("id");
            }
            if (criteria.getSortOrder() == null) {
                criteria.setSortOrder(SortOrder.DESC);
            }

            EntityManager entityManager = getEntityManager();

            // Create the query string
            StringBuffer sb = new StringBuffer(SQL_CUSTOMER_REQUEST);
            setQueryByCriteria(criteria, sb);

            sb.append(" ORDER BY ").append(criteria.getSortBy()).append(" ")
                .append(criteria.getSortOrder().name());

            // Create query
            TypedQuery<Customer> query = entityManager.createQuery(sb.toString(), Customer.class);

            setParaByCriteria(criteria, query);

            // Set paging
            if (criteria.getPageNumber() > 0) {
                query.setMaxResults(criteria.getPageSize());
                query.setFirstResult((criteria.getPageNumber() - 1) * criteria.getPageSize());
            }

            List<Customer> records = query.getResultList();

            SearchResult<Customer> result = new SearchResult<Customer>();
            result.setValues(records);
            result.setPageNumber(criteria.getPageNumber());
            result.setPageSize(criteria.getPageSize());

            if (criteria.getPageNumber() > 0) {
                // get total page count
                sb = new StringBuffer(SQL_QUERY_CUSTOMER_COUNT);
                setQueryByCriteria(criteria, sb);

                // Create query
                TypedQuery<Long> countQuery = entityManager.createQuery(sb.toString(), Long.class);

                setParaByCriteria(criteria, countQuery);

                int totalCount = countQuery.getSingleResult().intValue();
                int totalPageCount = (totalCount + criteria.getPageSize() - 1) / criteria.getPageSize();

                result.setTotalItems(totalCount);
                result.setTotalPages(totalPageCount);
            } else {
                result.setTotalItems(records.size());
                result.setTotalPages(1);
            }

            // Log exit
            Helper.logExit(logger, signature, new Object[]{result});

            return result;

        } catch (IllegalStateException e) {
            // Log exception
            throw Helper.logException(logger, signature, new ServiceRequestToolException(
                    "The entity manager has been closed.", e));
        } catch (PersistenceException e) {
            // Log exception
            throw Helper.logException(logger, signature, new ServiceRequestToolException(
                    "An error has occurred while accessing the persistence.", e));
        }
    }

    /**
     * Set the query string by criteria.
     *
     * @param criteria
     *            the criteria
     * @param sb
     *            the string builder
     *
     * @since 1.2
     */
    private void setQueryByCriteria(CustomerSearchCriteria criteria, StringBuffer sb) {
        if (criteria.getName() != null) {
            sb.append(" AND LOWER(c.contactName) LIKE :name");
        }
        if (criteria.getFormalName() != null) {
            sb.append(" AND LOWER(c.formalName) LIKE :formalName");
        }
        if (criteria.getAddress() != null) {
            sb.append(" AND (LOWER(c.address1) LIKE :address OR LOWER(c.address2) LIKE :address)");
        }
        if (criteria.getCity() != null) {
            sb.append(" AND LOWER(c.city) LIKE :city");
        }
        if (criteria.getState() != null) {
            sb.append(" AND LOWER(c.region.name) LIKE :state");
        }
        if (criteria.getZip() != null) {
            sb.append(" AND LOWER(c.zip) LIKE :zip");
        }
        
        if (criteria.getCountry() != null) {
            sb.append(" AND LOWER(c.country.name) LIKE :country");
        }
        
        User currentUser = ServiceContext.getCurrentUser();
        if (currentUser != null && !Helper.isStringNullOrEmpty(currentUser.getUserIdentifier())) {
            sb.append(" AND c.userIdentifier = :userIdentifier");
        }
    }

    /**
     * Set the parameter for query by criteria.
     *
     * @param criteria
     *            the criteria
     * @param query
     *            the query
     */
    private void setParaByCriteria(CustomerSearchCriteria criteria, TypedQuery<?> query) {
        if (criteria.getName() != null) {
            query.setParameter("name", Helper.fixStringForLike(criteria.getName()));
        }
        if (criteria.getFormalName() != null) {
            query.setParameter("formalName", Helper.fixStringForLike(criteria.getFormalName()));
        }
        if (criteria.getAddress() != null) {
            query.setParameter("address", Helper.fixStringForLike(criteria.getAddress()));
        }
        if (criteria.getCity() != null) {
            query.setParameter("city", Helper.fixStringForLike(criteria.getCity()));
        }
        if (criteria.getState() != null) {
            query.setParameter("state", Helper.fixStringForLike(criteria.getState()));
        }
        if (criteria.getCountry() != null) {
            query.setParameter("country", Helper.fixStringForLike(criteria.getCountry()));
        }
        if (criteria.getZip() != null) {
            query.setParameter("zip", Helper.fixStringForLike(criteria.getZip()));
        }
        User currentUser = ServiceContext.getCurrentUser();
        if (currentUser != null && !Helper.isStringNullOrEmpty(currentUser.getUserIdentifier())) {
            query.setParameter("userIdentifier", currentUser.getUserIdentifier());
        }
    }
}

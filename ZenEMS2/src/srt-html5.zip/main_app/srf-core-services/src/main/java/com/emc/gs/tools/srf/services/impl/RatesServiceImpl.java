/*
 * This code is copyright (c) 2014 EMC Corporation.
 */
package com.emc.gs.tools.srf.services.impl;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import javax.annotation.PostConstruct;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.TransactionCallbackWithoutResult;
import org.springframework.transaction.support.TransactionTemplate;

import com.emc.gs.tools.srf.ServiceRequestToolConfigurationException;
import com.emc.gs.tools.srf.model.estimate.BaseRate;
import com.emc.gs.tools.srf.model.estimate.HourlyStdCostRate;
import com.emc.gs.tools.srf.model.estimate.StandardBillRate;
import com.emc.gs.tools.srf.services.RatesService;
import com.emc.gs.tools.srf.services.ServiceRequestToolException;

/**
 * <p>
 * This is the implementation of RatesService.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is thread safe. The inner cache in suitable for concurrent access.
 * </p>
 * 
 * @author TCSASSEMBLER
 * @version 1.0
 * @since SRT Phase 4 - ET Assembly 1
 */
public class RatesServiceImpl extends BasePersistenceService implements RatesService {

    /**
     * The lightweight rates cache. The rate data is some small data piece and the count of rates data is some fixed
     * number so this cache should not consume much memory. The cache map is suitable for concurrent read/write access.
     * In future it can be changed to some sophisticated cache mechanism if desired.
     */
    private static final Map<String, Map<String, BigDecimal>> RATES_CACHE = new ConcurrentHashMap<String, Map<String, BigDecimal>>();

    /**
     * The transaction manager.
     */
    @Autowired
    private JpaTransactionManager transactionManager;

    /**
     * Empty constructor.
     */
    public RatesServiceImpl() {
    }

    /**
     * Retrieves standard bill rates data.
     * 
     * @return the standard bill rates data.
     * @throws ServiceRequestToolException
     *             if any error occurred during the operation
     */
    public Map<String, BigDecimal> retrieveStandardBillRates() throws ServiceRequestToolException {

        return RATES_CACHE.get(StandardBillRate.class.getName());
    }

    /**
     * Retrieves hourly standard cost rates data.
     * 
     * @return the hourly standard cost rates data.
     * @throws ServiceRequestToolException
     *             if any error occurred during the operation
     */
    public Map<String, BigDecimal> retrieveHourlyStdCostRates() throws ServiceRequestToolException {

        return RATES_CACHE.get(HourlyStdCostRate.class.getName());
    }

    /**
     * <p>
     * Refresh rates.
     * </p>
     * <p>
     * The refresh is configured to run automatically on application startup and then scheduled to run every day at
     * midnight.
     * </p>
     * 
     * @throws ServiceRequestToolConfigurationException
     *             if entityManager/transactionManager is null
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     */
    @PostConstruct
    public void refreshRates() throws ServiceRequestToolException {
        super.checkInit();
        Helper.checkState(transactionManager == null, "'transactionManager' can't be null.");

        Logger logger = getLogger();

        logger.info("Start refresh rates...");

        Map<String, BigDecimal> billRates;
        boolean billRatesFromLocalDB = false;
        try {
            // Query bill rates data from external WebService
            billRates = retrieveStandardBillRatesFromWS();
            logger.info("Retrieved bill rates from WebService.");
        } catch (ServiceRequestToolException e) {
            logger.warn("Failed to retrieve bill rates from WebService, fall back to local DB. WS Error: "
                    + e.getMessage());
            // Error, maybe not inside EMC firewall, fall back to local DB
            billRates = retrieveRatesFromLocalDB(StandardBillRate.class);
            billRatesFromLocalDB = true;
        }

        Map<String, BigDecimal> costRates;
        boolean costRatesFromLocalDB = false;
        try {
            // Query cost rates data from external WebService
            costRates = retrieveHourlyStdCostRatesFromWS();
            logger.info("Retrieved cost rates from WebService.");
        } catch (ServiceRequestToolException e) {
            logger.warn("Failed to retrieve cost rates from WebService, fall back to local DB. WS Error: "
                    + e.getMessage());
            // Error, maybe not inside EMC firewall, fall back to local DB
            costRates = retrieveRatesFromLocalDB(HourlyStdCostRate.class);
            costRatesFromLocalDB = true;
        }

        // Put rates data into cache
        RATES_CACHE.put(StandardBillRate.class.getName(), billRates);
        RATES_CACHE.put(HourlyStdCostRate.class.getName(), costRates);
        logger.info("Rates cached.");

        // Store rates data within local DB
        if (!billRatesFromLocalDB) {
            storeBillRatesInLocalDB(billRates);
            logger.info("Stored bill rates in local DB.");
        }
        if (!costRatesFromLocalDB) {
            storeCostRatesInLocalDB(costRates);
            logger.info("Stored cost rates in local DB.");
        }

        logger.info("End refresh rates.");
    }

    /**
     * Stores bill rates in local DB.
     * 
     * @param billRates
     *            bill rates to be stored in local DB
     */
    private void storeBillRatesInLocalDB(final Map<String, BigDecimal> billRates) {

        new TransactionTemplate(transactionManager).execute(new TransactionCallbackWithoutResult() {
            @Override
            protected void doInTransactionWithoutResult(TransactionStatus status) {
                getEntityManager().createQuery("DELETE from StandardBillRate").executeUpdate();
                for (String billRateKey : billRates.keySet()) {
                    StandardBillRate billRate = new StandardBillRate();
                    billRate.setLookupKey(billRateKey);
                    billRate.setRate(billRates.get(billRateKey));
                    getEntityManager().persist(billRate);
                }
            }
        });
    }

    /**
     * Stores cost rates in local DB.
     * 
     * @param costRates
     *            cost rates to be stored in local DB
     */
    private void storeCostRatesInLocalDB(final Map<String, BigDecimal> costRates) {
        new TransactionTemplate(transactionManager).execute(new TransactionCallbackWithoutResult() {
            @Override
            protected void doInTransactionWithoutResult(TransactionStatus status) {
                getEntityManager().createQuery("DELETE from HourlyStdCostRate").executeUpdate();
                for (String costRateKey : costRates.keySet()) {
                    HourlyStdCostRate costRate = new HourlyStdCostRate();
                    costRate.setLookupKey(costRateKey);
                    costRate.setRate(costRates.get(costRateKey));
                    getEntityManager().persist(costRate);
                }
            }
        });
    }

    /**
     * Retrieve rates from local DB.
     * 
     * @param clazz
     *            The rate class.
     * @return the map from lookup key to the rate.
     * @throws ServiceRequestToolException
     *             if error occurs when retrieving rates from local DB
     */
    @SuppressWarnings("unchecked")
    private Map<String, BigDecimal> retrieveRatesFromLocalDB(Class<? extends BaseRate> clazz)
            throws ServiceRequestToolException {

        // Query local DB
        List<? extends BaseRate> rates = getEntityManager().createQuery("from " + clazz.getName()).getResultList();

        Map<String, BigDecimal> result = new HashMap<String, BigDecimal>();
        for (BaseRate rate : rates) {
            result.put(rate.getLookupKey(), rate.getRate());
        }

        return result;
    }

    /**
     * Retrieves standard bill rates data from WebService.
     * 
     * @return the standard bill rates data.
     * @throws ServiceRequestToolException
     *             if any error occurred during the operation
     */
    private Map<String, BigDecimal> retrieveStandardBillRatesFromWS() throws ServiceRequestToolException {
        // TODO: Change following implementation to retrieve the bill rates data from WebService
        throw new ServiceRequestToolException("Not implemented");
    }

    /**
     * Retrieves hourly standard cost rates data from WebService.
     * 
     * @return the hourly standard cost rates data.
     * @throws ServiceRequestToolException
     *             if any error occurred during the operation
     */
    private Map<String, BigDecimal> retrieveHourlyStdCostRatesFromWS() throws ServiceRequestToolException {
        // TODO: Change following implementation to retrieve the cost rates data from WebService
        throw new ServiceRequestToolException("Not implemented");
    }
}

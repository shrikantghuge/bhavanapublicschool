/*
 * This code is copyright (c) 2013 - 2014 EMC Corporation.
 */
package com.emc.gs.tools.srf.web;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.emc.gs.tools.srf.services.impl.Helper;

/**
 * <p>
 * This class represents the help controller.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is effectively thread safe after configuration, the
 * configuration is done in a thread safe manner.
 * </p>
 *
 * @author faeton, TCSASSEMBLER
 * @version 1.0
 */
@Controller
public class HelpController extends BaseController {
    /**
     * <p>
     * Represents the class name.
     * </p>
     */
    private static final String CLASSNAME = HelpController.class.getName();

    /**
     * Creates instance of the class.
     */
    public HelpController() {
        // Empty
    }

    /**
     * Shows user help.
     *
     * @return the view name
     */
    @RequestMapping(value = "help", method = RequestMethod.GET)
    public String view() {
        final String signature = CLASSNAME + "#view()";

        // Log entry
        Helper.logEntrance(getLogger(), signature, null, null);

        String result = "help";

        // Log exit
        Helper.logExit(getLogger(), signature, new Object[] {result});

        return result;
    }
}

/*
 * This code is copyright (c) 2013 - 2015 EMC Corporation.
 */
package com.emc.gs.tools.srf.web;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.emc.gs.tools.srf.model.Customer;
import com.emc.gs.tools.srf.model.CustomerSearchCriteria;
import com.emc.gs.tools.srf.model.CustomerWorkSite;
import com.emc.gs.tools.srf.model.SearchResult;
import com.emc.gs.tools.srf.services.CustomerService;
import com.emc.gs.tools.srf.services.ServiceRequestToolException;
import com.emc.gs.tools.srf.services.SyncDown;
import com.emc.gs.tools.srf.services.SyncUp;
import com.emc.gs.tools.srf.services.impl.Helper;

/**
 * <p>
 * This class represents the controller to manage customer data.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is effectively thread safe after configuration, the
 * configuration is done in a thread safe manner.
 * </p>
 * 
 * <p>
 * <strong>Changes V1.1:</strong>
 * <strong>SRT Bug Fixes</strong>
 * <ul>
 * <li>Added copyCustomer() method.</li>
 * </ul>
 * </p>
 * 
 * <p>
 * <strong>Changes V1.2:</strong>
 * <strong>SRT Bug Fixes - F121, F153, F154, F162</strong>
 * <ul>
 * <li>Fixed copyCustomer method.</li>
 * </ul>
 * </p>
 * 
 * <p>
 * <strong>Changes V1.3:</strong>
 * <ul>
 * <li>Removed shortName field handling.</li>
 * </ul>
 * </p>
 *
 * <p>
 * <strong>Changes V1.4:</strong>
 * <strong>SRT Phase 2 Release Assembly</strong>
 * <ul>
 * <li>Update validateCustomer() method</li>
 * </ul>
 * </p>
 *
 * <p>
 * <strong>Changes V1.5:</strong>
 * <strong>SRT Cloud Synchronization - Cloud App Assembly</strong>
 * <ul>
 * <li>Added get(long id) method</li>
 * </ul>
 * </p>
 *
 * <p>
 * <strong>Changes V1.6:</strong>
 * <strong>SRT 1.1 DEC 2014 Updates Assembly</strong>
 * <ul>
 * <li>Updated copyCustomer() method to handle the new customer work site fields.</li>
 * <li>Relaxed validation for "Services Agreement Type", "Services Agreement Number" and "Services Agreement Date" fields.</li>
 * </ul>
 * </p>
 *
 * <p>
 * <strong>Changes V1.7:</strong>
 * <strong>SRT 1.1 Approval Process Assembly</strong>
 * <ul>
 * <li>Removed unused import.</li>
 * </ul>
 * </p>
 * 
 * <p>
 * <strong>Changes V1.8:</strong>
 * <strong>SRT HTML5 SRT4 Path and Base Assembly</strong>
 * <ul>
 * <li>Added copy(long id) method</li>
 * </ul>
 * </p>
 * 
 * <p>
 * <strong>Changes V1.9:</strong>
 * <strong>SRT HTML5 ET Production Fixes Part 2 Assembly 1.0</strong>
 * <ul>
 * <li>refactor the copy and copyCustomer methods to use Helper.copyCustomer method</li>
 * </ul>
 * </p>
 * @author faeton, TCSASSEMBLER, MonicaMuranyi, TCSASSEMBLER
 * @version 1.9
 */
@Controller
public class CustomerController extends BaseController {
    /**
     * <p>
     * Represents the class name.
     * </p>
     */
    private static final String CLASSNAME = CustomerController.class.getName();

    /**
     * Represents the CustomerService instance for managing customers. It is modified by setter. It is
     * injected by Spring. It can not be null after injected.
     */
    private CustomerService customerService;

    /**
     * Creates instance of the class.
     */
    public CustomerController() {
        // Empty
    }

    /**
     * Get customer by id.
     *
     * @param id
     *            the id of the customer to get
     * @return the serialized Customer in JSON format
     * @throws IllegalArgumentException
     *             if criteria is null.
     * @throws com.emc.gs.tools.srf.services.ServiceRequestToolException
     *             if there is any problem executing the request.
     * @since 1.5
     */
    @SyncDown(entityType = "Customer")
    @RequestMapping(value = "getCustomer/{id}", method = RequestMethod.GET)
    @ResponseBody
    public Customer get(@PathVariable long id) throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#get(long id)";
        Logger logger = getLogger();

        // Log entry
        Helper.logEntrance(logger, signature, new String[]{"id"}, new Object[]{id});

        Customer result = customerService.get(id);

        // Log exit
        Helper.logExit(logger, signature, new Object[]{result});

        return result;
    }
    
    /**
     * Copy customer by id.
     *
     * @param id
     *            the id of the customer to copy
     * @return the serialized copied Customer in JSON format
     * @throws IllegalArgumentException
     *             if criteria is null.
     * @throws com.emc.gs.tools.srf.services.ServiceRequestToolException
     *             if there is any problem executing the request.
     * @since 1.8
     */
    @SyncDown(entityType = "Customer")
    @RequestMapping(value = "copyCustomer/{id}", method = RequestMethod.GET)
    @ResponseBody
    public Customer copy(@PathVariable long id) throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#copy(long id)";
        Logger logger = getLogger();

        // Log entry
        Helper.logEntrance(logger, signature, new String[]{"id"}, new Object[]{id});

        Customer customer = customerService.get(id);
        Customer copiedCustomer = Helper.copyCustomer(customer);
        // Log exit
        Helper.logExit(logger, signature, new Object[]{copiedCustomer});

        return copiedCustomer;
    }

    /**
     * Views the customers page.
     *
     * @return the view name.
     */
    @SyncDown(entityType = "Customer", syncDownAll = true)
    @RequestMapping(value = "customers", method = RequestMethod.GET)
    public String viewCustomers() {
        final String signature = CLASSNAME + "#viewCustomers()";
        Logger logger = getLogger();

        // Log entry
        Helper.logEntrance(logger, signature, null, null);

        String result = "viewCustomers";

        // Log exit
        Helper.logExit(logger, signature, new Object[]{result});

        return result;
    }

    /**
     * Views the customers page.
     *
     * @return the view name.
     */
    @RequestMapping(value = "addCustomer", method = RequestMethod.GET)
    public String addCustomer() {
        final String signature = CLASSNAME + "#addCustomer()";
        Logger logger = getLogger();

        // Log entry
        Helper.logEntrance(logger, signature, null, null);

        String result = "addCustomer";

        // Log exit
        Helper.logExit(logger, signature, new Object[]{result});

        return result;
    }

    /**
     * Searches the customers based on the criteria.
     *
     * @param criteria
     *            the search criteria
     * @return the serialized SearchResult in JSON format
     * @throws IllegalArgumentException
     *             if criteria is null.
     * @throws com.emc.gs.tools.srf.services.ServiceRequestToolException
     *             if there is any problem executing the request.
     */
    @RequestMapping(value = "customers/search", method = RequestMethod.POST)
    @ResponseBody
    public SearchResult<Customer> search(@RequestBody CustomerSearchCriteria criteria)
        throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#search(CustomerSearchCriteria criteria)";
        Logger logger = getLogger();

        // Log entry
        Helper.logEntrance(logger, signature, new String[]{"criteria"}, new Object[]{criteria});

        SearchResult<Customer> result = customerService.search(criteria);

        // Log exit
        Helper.logExit(logger, signature, new Object[]{result});

        return result;
    }

    /**
     * Get the customer for id.
     *
     * @param id
     *            the customer id
     * @param model
     *            Spring MVC model
     * @return the view name for customer
     * @throws IllegalArgumentException
     *             if id is not positive
     * @throws com.emc.gs.tools.srf.services.ServiceRequestToolException
     *             if there is any problem executing the request.
     */
    @SyncDown(entityType = "Customer")
    @RequestMapping(value = "customer/{id}", method = RequestMethod.GET)
    public String getCustomer(@PathVariable long id, Model model) throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#getCustomer(long id, Model model)";
        Logger logger = getLogger();

        // Log entry
        Helper.logEntrance(logger, signature, new String[]{"id", "model"}, new Object[]{id, model});

        Helper.checkPositive(logger, signature, id, "id");

        model.addAttribute("customer", customerService.get(id));

        String result = "customer";

        // Log exit
        Helper.logExit(logger, signature, new Object[]{result});

        return result;
    }

    /**
     * Edit the customer for id.
     *
     * @param id
     *            the customer id
     * @param model
     *            Spring MVC model
     * @return the view name for customer
     * @throws IllegalArgumentException
     *             if id is not positive
     * @throws com.emc.gs.tools.srf.services.ServiceRequestToolException
     *             if there is any problem executing the request.
     */
    @SyncDown(entityType = "Customer")
    @RequestMapping(value = "editCustomer/{id}", method = RequestMethod.GET)
    public String editCustomer(@PathVariable long id, Model model) throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#editCustomer(long id, Model model)";
        Logger logger = getLogger();

        // Log entry
        Helper.logEntrance(logger, signature, new String[]{"id", "model"}, new Object[]{id, model});

        Helper.checkPositive(logger, signature, id, "id");

        model.addAttribute("customer", customerService.get(id));

        String result = "editCustomer";

        // Log exit
        Helper.logExit(logger, signature, new Object[]{result});

        return result;
    }

    /**
     * Copy the customer with given id and opens it for edit.
     *
     * @param id
     *            the customer id
     * @param model
     *            Spring MVC model
     * @return the view name for customer edit
     * @throws IllegalArgumentException
     *             if id is not positive
     * @throws com.emc.gs.tools.srf.services.ServiceRequestToolException
     *             if there is any problem executing the request.
     */
    @SyncDown(entityType = "Customer")
    @RequestMapping(value = "customer/{id}/copy", method = RequestMethod.GET)
    public String copyCustomer(@PathVariable long id, Model model) throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#editCustomer(long id, Model model)";
        Logger logger = getLogger();

        // Log entry
        Helper.logEntrance(logger, signature, new String[]{"id", "model"}, new Object[]{id, model});

        Helper.checkPositive(logger, signature, id, "id");

        Customer customer = customerService.get(id);
        Customer copiedCustomer = Helper.copyCustomer(customer);

        model.addAttribute("customer", copiedCustomer);

        String result = "copyCustomer";

        // Log exit
        Helper.logExit(logger, signature, new Object[]{result});

        return result;
    }

    /**
     * Creates the customer.
     *
     * @param customer
     *            the customer to create
     * @return the serialized customer in JSON format
     * @throws IllegalArgumentException
     *             if customer is null.
     * @throws com.emc.gs.tools.srf.services.ServiceRequestToolException
     *             if there is any problem executing the request.
     */
    @SyncUp(entityType = "Customer")
    @RequestMapping(value = "customer", method = RequestMethod.POST)
    @ResponseBody
    public Customer create(@RequestBody Customer customer) throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#create(Customer customer)";
        Logger logger = getLogger();

        // Log entry
        Helper.logEntrance(logger, signature, new String[]{"customer"}, new Object[]{customer});
        validateCustomer(customer, signature, logger);

        Customer result = customerService.create(customer);

        // Log exit
        Helper.logExit(logger, signature, new Object[]{result});

        return result;
    }

    /**
     * Updates the customer.
     *
     * @param id
     *            the id of customer to update
     * @param customer
     *            the customer to update
     * @throws IllegalArgumentException
     *             if customer is null, id is not positive or is not the id of customer
     * @throws com.emc.gs.tools.srf.services.ServiceRequestToolException
     *             if there is any problem executing the request.
     */
    @SyncUp(entityType = "Customer")
    @RequestMapping(value = "customer/{id}", method = RequestMethod.PUT)
    @ResponseBody
    public void update(@PathVariable long id, @RequestBody Customer customer) throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#update(long id, Customer customer)";
        Logger logger = getLogger();

        // Log entry
        Helper.logEntrance(logger, signature, new String[]{"id", "customer"}, new Object[]{id, customer});

        Helper.checkPositive(logger, signature, id, "id");
        Helper.checkNull(logger, signature, customer, "customer");
        validateCustomer(customer, signature, logger);

        if (id != customer.getId()) {
            throw Helper.logException(logger, signature, new IllegalArgumentException(
                    "The update id is not same as customer id"));
        }

        customerService.update(customer);

        // Log exit
        Helper.logExit(logger, signature, null);
    }

    /**
     * Deletes the customer.
     *
     * @param id
     *            the id of customer to delete
     * @throws IllegalArgumentException
     *             if id is not positive.
     * @throws com.emc.gs.tools.srf.services.ServiceRequestToolException
     *             if there is any problem executing the request.
     */
    @SyncUp(entityType = "Customer")
    @RequestMapping(value = "customer/{id}", method = RequestMethod.DELETE)
    @ResponseBody
    public void delete(@PathVariable long id) throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#delete(long id)";
        Logger logger = getLogger();

        // Log entry
        Helper.logEntrance(logger, signature, new String[]{"id"}, new Object[]{id});

        customerService.delete(new long[] {id});

        // Log exit
        Helper.logExit(logger, signature, null);
    }

    /**
     * This method checks whether the instance of the class was initialized properly.
     *
     * @throws com.emc.gs.tools.srf.ServiceRequestToolConfigurationException
     *             if customerService is null
     */
    @PostConstruct
    protected void checkInit() {
        Helper.checkState(customerService == null, "'customerService' can't be null.");
    }

    /**
     * <p>
     * Sets the value to customerService field.
     * </p>
     *
     * @param customerService
     *            the value of customerService to set
     */
    public void setCustomerService(CustomerService customerService) {
        this.customerService = customerService;
    }
    
    /**
     * <p>
     * Validates the customer fields.
     * </p>
     * @param customer
     *            the customer to validate
     * @param signature
     *            the signature of the method to be logged
     * @param logger
     *            the logger object
     * @throws IllegalArgumentException
     *             if customer is invalid
     */
    private void validateCustomer(Customer customer, final String signature, Logger logger) {
        Helper.checkStrNullEmpty(logger, signature, customer.getFormalName(), "Customer Name");
        Helper.checkStrNullEmpty(logger, signature, customer.getAddress1(), "Address Line 1");
        Helper.checkStrNullEmpty(logger, signature, customer.getCity(), "City");
        Helper.checkStrNullEmpty(logger, signature, customer.getZip(), "Zip");
        Helper.checkStrNullEmpty(logger, signature, customer.getEmail(), "Email");
    }
}

/*
 * This code is copyright (c) 2013 - 2015 EMC Corporation.
 */
package com.emc.gs.tools.srf.web;

import com.emc.gs.tools.srf.AuthorizationException;
import com.emc.gs.tools.srf.model.*;
import com.emc.gs.tools.srf.model.asd.ASDAppSync;
import com.emc.gs.tools.srf.model.asd.ASDRequestData;
import com.emc.gs.tools.srf.model.asd.ASDUIM;
import com.emc.gs.tools.srf.model.asd.UIMType;
import com.emc.gs.tools.srf.model.atmos.*;
import com.emc.gs.tools.srf.model.bc.*;
import com.emc.gs.tools.srf.model.change.ChangeRequestData;
import com.emc.gs.tools.srf.model.change.HoursByMonth;
import com.emc.gs.tools.srf.model.change.RoleHoursByMonth;
import com.emc.gs.tools.srf.model.cta.*;
import com.emc.gs.tools.srf.model.deal.*;
import com.emc.gs.tools.srf.model.dpad.*;
import com.emc.gs.tools.srf.model.engagement.DeliveryCountry;
import com.emc.gs.tools.srf.model.engagement.EngagementTypeData;
import com.emc.gs.tools.srf.model.engagement.SRTPath;
import com.emc.gs.tools.srf.model.estimate.*;
import com.emc.gs.tools.srf.model.healthcheck.*;
import com.emc.gs.tools.srf.model.infrastructure.*;
import com.emc.gs.tools.srf.model.isilon.*;
import com.emc.gs.tools.srf.model.mainframe.*;
import com.emc.gs.tools.srf.model.move.MoveRequestData;
import com.emc.gs.tools.srf.model.mss.*;
import com.emc.gs.tools.srf.model.residency.ResidencyPaymentType;
import com.emc.gs.tools.srf.model.residency.ResidencyRequestData;
import com.emc.gs.tools.srf.model.residency.ResidencyRoleSkillLevels;
import com.emc.gs.tools.srf.model.residency.RoleSkillLevel;
import com.emc.gs.tools.srf.model.sourceone.*;
import com.emc.gs.tools.srf.model.srm.SRMRequestData;
import com.emc.gs.tools.srf.model.unfunded.UnfundedProjectData;
import com.emc.gs.tools.srf.model.unified.*;
import com.emc.gs.tools.srf.model.vblock.*;
import com.emc.gs.tools.srf.model.vipr.HostBasedMigrationTool;
import com.emc.gs.tools.srf.model.vipr.ViprImplementation;
import com.emc.gs.tools.srf.model.vipr.ViprRequestData;
import com.emc.gs.tools.srf.model.vmware.*;
import com.emc.gs.tools.srf.model.w4n.W4NData;
import com.emc.gs.tools.srf.model.xtreme.*;
import com.emc.gs.tools.srf.services.*;
import com.emc.gs.tools.srf.services.estimate.dto.EstimatedLOB;
import com.emc.gs.tools.srf.services.estimate.dto.EstimatedResource;
import com.emc.gs.tools.srf.services.estimate.dto.EstimatedResult;
import com.emc.gs.tools.srf.services.impl.Helper;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.core.task.TaskExecutor;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.ExtendedModelMap;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.PostConstruct;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import java.io.*;
import java.math.BigDecimal;
import java.util.*;
import java.util.Map.Entry;

import static com.emc.gs.tools.srf.services.impl.Helper.*;

/**
 * <p>
 * This class represents the controller to manage request data.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is effectively thread safe after configuration, the configuration is done
 * in a thread safe manner.
 * </p>
 * <p>
 * <strong>Changes V1.1:</strong> <strong>SRT Release Assembly - Base</strong>
 * <ul>
 * <li>Release_assembly_tasks.xls Row#7: Renamed CustomerContractData to RequestContractData</li>
 * <li>addes some null checks on copy</li>
 * </ul>
 * </p>
 * <p>
 * <strong>Changes V1.2:</strong> <strong>SRT Release Assembly - BC Tab</strong>
 * <ul>
 * <li>Add zeroId() method to fix NPE on copy</li>
 * </ul>
 * </p>
 * <p>
 * <strong>Changes V1.3:</strong> <strong>SRT Release Assembly - Unified Tab</strong>
 * <ul>
 * <li>Set "viewMode" attribute to true in getRequest() method.</li>
 * <li>Add path mapping to root "/" in viewRequests() method.</li>
 * <li>Remove defaultProfileId configuration, use {@link com.emc.gs.tools.srf.services.ProfileService#getDefaultProfile()} instead.</li>
 * </ul>
 * </p>
 * <p>
 * <strong>Changes V1.4:</strong> <strong>SRT Bug Fixes</strong>
 * <ul>
 * <li>Modified uploadAttachment() method to support multiple uploads.</li>
 * <li>Renamed/Removed some of the request fields.</li>
 * </ul>
 * </p>
 * <p>
 * <strong>Changes V1.5:</strong> <strong>Commercial / Mid-Market Division Special Handling Logic</strong>
 * <ul>
 * <li>Added validation for "Mid-Marked" division in validateProjectInfo() method.</li>
 * </ul>
 * </p>
 * <p>
 * <strong>Changes V1.6:</strong> <strong>SRT Bug Fixes: F120 - F162</strong>
 * <ul>
 * <li>Added validateAttachments() method.</li>
 * </ul>
 * </p>
 * <p>
 * <strong>Changes V1.7:</strong> <strong>SRT Bug Fixes - F121, F153, F154, F162</strong>
 * <ul>
 * <li>Change "# days of knowledge transfer" label to "# hours of knowledge transfer".</li>
 * <li>Add validation logic for "# hours of knowledge transfer" field from all sub-sections.</li>
 * </ul>
 * </p>
 * <p>
 * <strong>Changes V1.8:</strong>
 * <ul>
 * <li>Removed logic related to removed fields/sections.</li>
 * </ul>
 * </p>
 * <p>
 * <strong>Changes V1.9:</strong>
 * <ul>
 * <li>Added logic related to removed fields/sections.</li>
 * </ul>
 * </p>
 * <p>
 * <strong>Changes V1.9:</strong> <strong>SRT Phase 3-3 - BRS Tab Assembly</strong>
 * <ul>
 * <li>Change copy() method to zero ids of BRS request data.</li>
 * </ul>
 * </p>
 * <p>
 * <strong>Changes V2.0:</strong> <strong>SRT Phase 3-1 - CTA Rainfinity and MSS Tabs Assembly</strong>
 * <ul>
 * <li>Change copy() method to zero ids of MSS/CTA request data.</li>
 * <li>Add validateMSS() method to validate MSS request data.</li>
 * <li>Add validateCTA() method to validate CTA request data.</li>
 * </ul>
 * </p>
 * <p>
 * <strong>Changes V2.1:</strong> <strong>SRT Phase 3-3 - Isilon and Residency Tabs Assembly</strong>
 * <ul>
 * <li>Change copy() method to zero ids of Isilon/Residency request data.</li>
 * <li>Add validateIsilon() method to validate Isilon request data.</li>
 * <li>Add validateResidency() method to validate Residency request data.</li>
 * </ul>
 * </p>
 * <p>
 * <strong>Changes V2.2:</strong> <strong>SRT Phase 3-1 - CTA Rainfinity and MSS Tabs Update Assembly</strong>
 * <ul>
 * <li>Update copy/validate methods for CTA/MSS tabs.</li>
 * </ul>
 * </p>
 * <p>
 * <strong>Changes V2.3:</strong>
 * <strong>SRT Phase 3-3 - Remove BRS and Isilon and Update Residency and Implement SourceOne Tabs Assembly</strong>
 * <ul>
 * <li>Update copy/validate methods to remove BRS/Isilon tabs.</li>
 * <li>Update copy/validate methods for SourceOne tab.</li>
 * </ul>
 * </p>
 * <p>
 * <strong>Changes V2.4:</strong>
 * <strong>SRT Phase 3-4 - ASD and Healthcheck Tabs Assembly</strong>
 * <ul>
 * <li>Change copy() method to zero ids of ASD/HealthCheck request data.</li>
 * <li>Add validateASD() method to validate ASD request data.</li>
 * <li>Add validateHealthCheck() method to validate HealthCheck request data.</li>
 * </ul>
 * </p>
 * <p>
 * <strong>Changes V2.5:</strong>
 * <strong>SRT Phase 3-3 - Implement Isilon and ViPR Tabs Assembly</strong>
 * <ul>
 * <li>Change copy() method to zero ids of Isilon/ViPR request data.</li>
 * <li>Add validateIsilon() method to validate Isilon request data.</li>
 * <li>Add validateVipr() method to validate ViPR request data.</li>
 * </ul>
 * </p>
 * <p>
 * <strong>Changes V2.6:</strong>
 * <strong>SRT Phase 3-1 - Atmos Centera and Vblock Tabs Assembly</strong>
 * <ul>
 * <li>Change copy() method to zero ids of Atmos/Vblock request data.</li>
 * <li>Add validateAtmos() method to validate Atmos request data.</li>
 * <li>Add validateVblock() method to validate Vblock request data.</li>
 * </ul>
 * </p>
 * <p>
 * <strong>Changes V2.7:</strong>
 * <strong>SRT Phase 3-5 - BRS Tabs Part 1 Assembly</strong>
 * <ul>
 * <li>Change copy() method to zero ids of DPAD request data.</li>
 * <li>Add validateDPAD() method to validate DPAD request data.</li>
 * </ul>
 * </p>
 * <p>
 * <strong>Changes V2.8:</strong>
 * <strong>SRT Phase 3-1 - Implement VMWare Tab Assembly</strong>
 * <ul>
 * <li>Change copy() method to zero ids of VMWare request data.</li>
 * <li>Add validateVMWare() method to validate VMWare request data.</li>
 * </ul>
 * </p>
 * <p>
 * <strong>Changes V2.9:</strong>
 * <strong>SRT Phase 3-5 - BRS Tabs Part 2 Assembly</strong>
 * <ul>
 * <li>Change copy() method to zero ids of DataDomain/DPA request data.</li>
 * <li>Add validateDataDomain/validateDPA methods to validate DataDomain/DPA request data.</li>
 * </ul>
 * </p>
 * <p>
 * <strong>Changes V3.0:</strong>
 * <strong>SRT Phase 3-5 - BRS Tabs Part 3 Assembly</strong>
 * <ul>
 * <li>Change copy() method to zero ids of Networker request data.</li>
 * <li>Add validateNetworker() method to validate Networker request data.</li>
 * </ul>
 * </p>
 * <p>
 * <strong>Changes V3.1:</strong>
 * <strong>SRT Phase 3 Merge Assembly</strong>
 * <ul>
 * <li>Change copy() method to zero ids of MoveRequest/ChangeRequest/W4N/Unfunded/SRM data.</li>
 * <li>Add validations method to validate MoveRequest/ChangeRequest/W4N/Unfunded/SRM data.</li>
 * </ul>
 * </p>
 * <p>
 * <strong>Changes V3.2:</strong>
 * <strong>SRT Cloud Synchronization - Cloud App Assembly</strong>
 * <ul>
 * <li>Added operationLogService field with corresponding setter and validation in checkInit().</li>
 * <li>Updated create, update, delete and doSubmitRequest to create operationLogs
 * using private createOperationLog helper method.</li>
 * </ul>
 * </p>
 *
 * <p>
 * Version 3.3 (SRT Phase 3 Pilot - Mozy and Xtrem and Vipr Tabs Assembly) Change notes:
 * <ol>
 * <li>Added support for Mozy tab.</li>
 * <li>Added support for Xtreme tab.</li>
 * <li>Removed validation for Project Manager Name field from {@link #validateProjectInfo(String, StartRequestData)}
 * method.</li>
 * <li>Updated {@link #addLookupEntities(Model)} method to support newly defined lookup entities.</li>
 * </ol>
 * </p>
 *
 * <p>
 * <strong>Changes V3.4:</strong>
 * <strong>SRT Phase 4 - ET Assembly 1</strong>
 * <ul>
 * <li>Change copy() method to zero ids of Estimates data.</li>
 * <li>Add validations method to validate Estimates data.</li>
 * </ul>
 * </p>
 *
 * <p>
 * <strong>Changes V3.5:</strong>
 * <strong>SRT Phase 4 - ET Assembly 2</strong>
 * <ul>
 * <li>The operation log functions added in V3.2 are moved to the service implementations.</li>
 * </ul>
 * </p>
 *
 * <p>
 * <strong>Changes V3.6:</strong>
 * <strong>SRT Phase 4 - ET Assembly 3</strong>
 * <ul>
 * <li>Moved TMP_UPLOAD_SUFFIX to Helper.</li>
 * <li>Moved handleUploadFiles to RequestService</li>
 * <li>Moved deleteAttachmentFiles to RequestService</li>
 * <li>Added request/checkAttachment REST API</li>
 * <li>Uploaded uploadAttachment to recognize the attachment with pattern PERSISTENT_ATTACHMENT_PATTERN,
 * and use the filename directly since this is an attachment synchronzied up from a local app.</li>
 * </ul>
 * </p>
 *
 * <p>
 * Version 3.7 (SRT Phase 4 - ET Release Assembly) Change notes:
 *   <ol>
 *     <li>Updated {@link #validateProjectInfo(String, StartRequestData)} method to validate "Expense Type" field.</li>
 *     <li>Updated {@link #validateEstimates(EstimatesData, SRTPath)} method to skip validating "Project Staffing" tab
 *     data.</li>
 *   </ol>
 * </p>
 *
 * <p>
 * Version 3.8 (SRT 4 OCT2014 Updates Part 1 Assembly) Change notes:
 *   <ol>
 *     <li>Updated {@link #validateBC(BcRequestData, UnifiedRequestData)} to add new validation rules, remove validation
 *     rules for TimeFinder-Database/Application Information section.</li>
 *     <li>Updated {@link #validateResidency(ResidencyRequestData)} to remove validation rules for maxHours property.
 *     </li>
 *     <li>Updated {@link #validateXtreme(XtremeRequestData)} method to add new validation rules.</li>
 *     <li>Updated {@link #validateNetworker(Networker)} method to add new validation rules.</li>
 *     <li>Updated {@link #addLookupEntities(Model)} to bind list of available networker datazone sizes to request.</li>
 *   </ol>
 * </p>
 *
 * <p>
 * Version 3.9 (SRT 4 OCT2014 Updates Part 2 Assembly) Change notes:
 *   <ol>
 *     <li>Updated {@link #addLookupEntities(Model)} method to bind lists of newly defined lookup entities to request.
 *     <li>Updated {@link #addLookupEntities(Model)} method to reflect the deletion of some VBlock related lookup
 *     entities.</li>
 *     <li>Updated {@link #validateResidency(ResidencyRequestData)} method as <code>RoleSkillLevel#rate</code> property
 *     has been removed and add validation for newly defined properties.</li>
 *     <li>Updated {@link #validateVblock(VblockRequestData)} method to add validation for newly added properties.</li>
 *     <li>Updated {@link #validateRecoverPoint(VblockRequestData)} method to follow new design for <code>RecoverPoint
 *     </code> class.</li>
 *   </ol>
 * </p>
 *
 * <p>
 * Version 3.10 (SRT 1.1 DEC 2014 Updates Assembly) Change notes:
 *   <ol>
 *     <li>Added {@link #generateExportFileName(Request)} method.</li>
 *     <li>Added {@link #get4DigitsSuffix(String)} method.</li>
 *     <li>Added DELIVERY_ACTION_FIELD_NAME, DXP_OPPORTUNITY_NUMBER_FIELD_NAME, 
 *     DIRECT_EXPRESS_DX_QUOTE_NUMBER_FIELD_NAME constants.</li>
 *   </ol>
 * </p>
 *
 * <p>
 * Version 3.11 (SRT 1.1 DEC 2014 Risk Calculation Assembly) Change notes:
 *   <ol>
 *     <li>Updated {@link #addLookupEntities(Model)} method to bind list of varios risk calculation related lookup data
 *     to request.</li>
 *     <li>Relaxed validation for "Oracle Party ID" and "Sales Force Case Number" fields.</li>
 *   </ol>
 * </p>
 *
 * <p>
 * Version 3.12 Change notes:
 *   <ol>
 *     <li>Added {@link #validateSAN(SanTanInformation)} method.</li>
 *   </ol>
 * </p>
 *
 * <p>
 * Version 3.13 Change notes:
 *   <ol>
 *     <li>Added support for Symm MF , Symm OS data.</li>
 *   </ol>
 * </p>
 *
 * <p>
 * Version 3.14 Change notes:
 *   <ol>
 *     <li>Added {@link #leftPad(String, int, char)} method.</li>
 *     <li>Updated {@link #generateExportFileName(Request)} method to use current timestamp instead of request ID.</li>
 *   </ol>
 * </p>
 *
 * <p>
 * Version 3.15 Change notes:
 *   <ol>
 *     <li>Moved <code>generateExportFileName</code> into {@link Helper} class.</li>
 *   </ol>
 * </p>
 *
 * <p>
 * Version 3.16 Change notes:
 *   <ol>
 *     <li>Updated {@link #validateProjectInfo(Request)} method to implement validation requirements from client.</li>
 *   </ol>
 * </p>
 *
 * <p>
 * Version 3.17 Change notes (SRT 1.1 FEB 2015 Updates - Template Folder Assembly):
 *   <ol>
 *     <li>Added {@link #viewTemplateFolder()} method to view global template folder page.</li>
 *     <li>Added {@link #createTemplateRequest(Model)} method to view create template request page.</li>
 *     <li>Added {@link #editTemplateRequest(long, Model)} method to view edit template request page.</li>
 *     <li>Added user's template permission on {@link #create(Request)}, {@link #update(long, Request)} and
 *     {@link #delete(long)} methods.</li>
 *   </ol>
 * </p>
 *
 * <p>
 * Version 3.18 Change notes (SRT 1.1 Approval Process Assembly):
 * <ol>
 * <li>Modified editRequest method to export "submitted" property for UI.</li>
 * <li>Modified getRequest method to export "submitted" and
 * "approvePendingRequest" properties for UI.</li>
 * <li>Modified update method, extend the "already submitted" validation logic
 * to handle PENDING requests.</li>
 * <li>Modified submit method to verify if the PENDING request is submitted by
 * the approver.</li>
 * <li>Modified doSubmitRequest method, added support to export ET path as PDF.</li>
 * <li>Modified validateRequest method, extended validation for PENDING
 * requests.</li>
 * </ol>
 * </p>
 *
 * <p>
 * Version 3.19 Change notes:
 *   <ol>
 *     <li>Updated {@link #delete(long)} method to prevent deletion of submitted requests.</li>
 *   </ol>
 * </p>
 *
 * <p>
 * Version 3.20 Change notes:
 *   <ol>
 *     <li>Changed the type of {@link EnvironmentDetailsInformation#hostInformation} property from <code>Map</code> to 
 *     <code>List</code>.</li>
 *     <li>Removed <code>Symmetrix</code> data from <code>Core</code> tab.</li>
 *     <li>Moved <code>VPLEX</code> data from <code>DPAD</code> to <code>Core</code> tab.</li>
 *     <li>Expanded DataDomainDesign entity with same set of properties as DataDomainImplementation entity.</li>
 *   </ol>
 * </p>
 *
 * <p>
 * Version 3.21 Change notes:
 *   <ol>
 *     <li>Implemented latest validation requirements from client (WBS numbers, sales order item numbers)</li>
 *     <li>Skipping validation for deliver action related fields (WBS numbers, sales order item numbers) for submissions
 *     from users with <code>Submitter</code> role and requests of SRT4 path.</li>
 *   </ol>
 * </p>
 *
 * <p>
 * Version 3.22 Change notes:
 *   <ol>
 *     <li>Estimates tab "Months of Entry" is extended up to 7 years (84 months).</li>
 *     <li>Renamed "DXP Opportunity Number" field to "Opportunity Number".</li>
 *     <li>Added validation for "SOW Number" and "Contract Number" fields of Estimates data.</li>
 *     <li>Added validation for Risk Calculation data.</li>
 *     <li>Binding materialDiscountFloors attribute to request.</li>
 *     <li>Renamed "Direct Express (DX) Quote Number" field to "Quote Number".</li>
 *     <li>Removed validation for "SOW Number" and "Contract Number" fields of Estimates data.</li>
 *     <li>Updated {@link #update(long, Request)} method to allow approvers to update pending requests.</li>
 *     <li>Updated {@link #addLookupEntities(Model)} method to bind competencies for ECD LOB to request.</li>
 *     <li>Updated {@link #validateEstimates(Request, SRTPath)} method to validate delivery action.</li>
 *     <li>Updated {@link #validateProjectInfo(Request)} method to validate <code>Oracle Party ID</code> and 
 *     <code>Opportunity Number</code> fields only for Service Led requests.</li>
 *     <code>"deliveryCountries" list is sorted by country names.</li>
 *     <code>Updated {@link #validateVipr(ViprRequestData)} method to validate <code>impl</code> proeprty only if 
 *     respective flag is set.</li>
 *     <li>Updated {@link #validateProjectInfo(Request)} method to skip validation for Quote Number and Oracle Party ID
 *     for RSA requests.</li>
 *     <li>Updated {@link #export(String, HttpServletResponse)} method to include project name to name of generated PDF
 *     file (if there is just a single request exported).</li>
 *   </ol>
 * </p>
 * 
 * <p>
 * <strong>Changes V3.23:</strong>
 * <strong>SRT HTML5 ET Production Fixes Part 1 Assembly 1.0</strong>
 * <ul>
 * <li>add the copy/get request method for the html5 ajax call.</li>
 * </ul>
 * </p>
 * 
 * @author faeton, stevenfrog, isv, duxiaoyang, MonicaMuranyi, TCSASSEMBLER
 * @version 3.23
 */
@Controller
public class RequestController extends BaseController {
    /**
     * <p>
     * Represents the class name.
     * </p>
     */
    private static final String CLASSNAME = RequestController.class.getName();

    /**
     * List of unfunded project types.
     *
     * @since SRT Phase 3-2 - W4N and Unfunded Project Tabs Assembly
     */
    private static final List<Long> UNFUNDED_TYPES = Arrays.asList(3L, 4L, 5L, 6L);

    /**
     * Represents the RequestService instance for managing requests. It is modified by setter. It is injected by Spring.
     * It can not be null after injected.
     */
    private RequestService requestService;

    /**
     * Represents the ExportService instance for performing export. It is modified by setter. It is injected by Spring.
     * It can not be null after injected.
     */
    private ExportService exportService;

    /**
     * Represents the StartRequestDataService instance for managing additional data for requests. It is modified by
     * setter. It is injected by Spring. It can not be null after injected.
     */
    private StartRequestDataService startRequestDataService;

    /**
     * Represents the ProfileService instance for retrieving email options of currently logged user. It is modified by
     * setter. It is injected by Spring. It can not be null after injected.
     */
    private ProfileService profileService;

    /**
     * Represents the LookupService instance for retrieving data. It is modified by setter. It is injected by Spring. It
     * can not be null after injected.
     */
    private LookupService lookupService;

    /**
     * Represents the EstimatesService instance for managing estimates data. It is modified by setter. It is injected by
     * Spring. It can not be null after injected.
     */
    private EstimatesService estimatesService;

    /**
     * Represents the RatesService instance for retrieving rates data. It is modified by setter. It is injected by
     * Spring. It can not be null after injected.
     */
    private RatesService ratesService;

    /**
     * Represents the TaskExecutor instance for submitting request task. It is modified by setter. It is
     * injected by Spring. It can not be null after injected.
     *
     * @since SRT Phase 2 Release Assembly
     */
    private TaskExecutor submitTaskExecutor;

    /**
     * Represents the upload folder for attachments. It is modified by setter. It is injected by Spring. It can not be
     * null or empty after injected.
     */
    private String attachmentUploadFolder;

    /**
     * Represents the tabs enabled. It is modified by setter. It is injected by Spring. It can not be null or empty
     * after injected.
     */
    private EnabledTabs enabledTabs;

    /**
     * Creates instance of the class.
     */
    public RequestController() {
        // Empty
    }

    /**
     * Views the requests page.
     *
     * @return the view name
     */
    @SyncDown(entityType = "Request", syncDownAll = true)
    @RequestMapping(value = {"/", "/requests"}, method = RequestMethod.GET)
    public String viewRequests() {
        final String signature = CLASSNAME + "#viewRequests()";
        Logger logger = getLogger();

        // Log entry
        Helper.logEntrance(logger, signature, null, null);

        String result = "viewRequests";

        // Log exit
        Helper.logExit(logger, signature, new Object[]{result});

        return result;
    }

    /**
     * Add lookup entities to model.
     *
     * @param model
     *         the spring model
     * @throws ServiceRequestToolException
     *         if there is any problem executing the request.
     */
    private void addLookupEntities(Model model) throws ServiceRequestToolException {
        model.addAttribute("sitesInvolved", lookupService.getLookupEnities(SitesInvolved.class));
        model.addAttribute("knowledgeTransferLevels", lookupService.getLookupEnities(KnowledgeTransferLevel.class));
        model.addAttribute("acceptancePlanTypes", lookupService.getLookupEnities(TestAcceptancePlanType.class));
        model.addAttribute("durationMonths", lookupService.getLookupEnities(DurationMonths.class));
        model.addAttribute("mssServices", lookupService.getLookupEnities(MSSService.class));
        model.addAttribute("mssPlatforms", lookupService.getLookupEnities(MSSPlatform.class));
        model.addAttribute("ctaApplianceTypes", lookupService.getLookupEnities(CTAApplianceType.class));
        model.addAttribute("ctaSourceFileServerTypes",
                lookupService.getLookupEnities(CTASourceFileServerType.class));
        model.addAttribute("weekDays", lookupService.getLookupEnities(WeekDay.class));
        model.addAttribute("residencyPaymentTypes", lookupService.getLookupEnities(ResidencyPaymentType.class));
        model.addAttribute("uimTypes", lookupService.getLookupEnities(UIMType.class));
        model.addAttribute("viprHostBasedMigrationTools", lookupService.getLookupEnities(HostBasedMigrationTool.class));
        model.addAttribute("xtremeHostBasedMigrationTools",
                lookupService.getLookupEnities(XtremeHostBasedMigrationTool.class));
        model.addAttribute("xtremeDataMobilityTypes", lookupService.getLookupEnities(XtremeDataMobilityType.class));
        model.addAttribute("unifiedHealthCheckTypes", lookupService.getLookupEnities(UnifiedHealthCheckType.class));
        model.addAttribute("centeraArrayActionTypes", lookupService.getLookupEnities(CenteraArrayActionType.class));
        model.addAttribute("centeraEditionTypes", lookupService.getLookupEnities(CenteraEditionType.class));
        model.addAttribute("centeraGenerationTypes", lookupService.getLookupEnities(CenteraGenerationType.class));
        model.addAttribute("centeraHealthCheckTypes", lookupService.getLookupEnities(CenteraHealthCheckType.class));
        model.addAttribute("centeraReplicationTypes", lookupService.getLookupEnities(CenteraReplicationType.class));
        model.addAttribute("centeraProtectionSchemeTypes",
                lookupService.getLookupEnities(CenteraProtectionSchemeType.class));
        model.addAttribute("centeraShippingArrangers",
                lookupService.getLookupEnities(CenteraShippingArranger.class));
        model.addAttribute("cuaHardwareTypes", lookupService.getLookupEnities(CUAHardwareType.class));
        model.addAttribute("vplexDataMobilityTypes", lookupService.getLookupEnities(VplexDataMobilityType.class));
        model.addAttribute("scriptingLevels", lookupService.getLookupEnities(ScriptingLevel.class));
        model.addAttribute("recoverPointSplitterTypes",
                lookupService.getLookupEnities(RecoverPointSplitterType.class));
        model.addAttribute("avamarServerTypes", lookupService.getLookupEnities(AvamarServerType.class));
        model.addAttribute("dataDomainBoostTypes", lookupService.getLookupEnities(DataDomainBoostType.class));
        model.addAttribute("dataDomainDeviceTypes", lookupService.getLookupEnities(DataDomainDeviceType.class));
        model.addAttribute("dataDomainPreRackTypes", lookupService.getLookupEnities(DataDomainPreRackType.class));
        model.addAttribute("dataDomainUpgradeTypes", lookupService.getLookupEnities(DataDomainUpgradeType.class));
        model.addAttribute("dataDomainMigrationTypes", lookupService.getLookupEnities(DataDomainMigrationType.class));
        model.addAttribute("dataDomainIntegrationTypes",
                lookupService.getLookupEnities(DataDomainIntegrationType.class));
        model.addAttribute("dataDomainDataStagingTypes",
                lookupService.getLookupEnities(DataDomainDataStagingType.class));
        model.addAttribute("dataDomainMaxBackupWindowTimes",
                lookupService.getLookupEnities(DataDomainMaxBackupWindowTime.class));

        model.addAttribute("contractStructures", lookupService.getLookupEnities(ContractStructure.class));
        model.addAttribute("dealQuestionSections", lookupService.getLookupEnities(DealQuestionSection.class));
        model.addAttribute("screenerInterviewers", lookupService.getLookupEnities(ScreenerInterviewer.class));
        model.addAttribute("resourceTypes", lookupService.getLookupEnities(ResourceType.class));
        List<DeliveryCountry> deliveryCountries = lookupService.getLookupEnities(DeliveryCountry.class);
        Collections.sort(deliveryCountries, LookupCodeEntityComparator.BY_NAME);
        model.addAttribute("deliveryCountries", deliveryCountries);
        model.addAttribute("dealCurrencies", lookupService.getLookupEnities(DealCurrency.class));
        model.addAttribute("billingTypes", lookupService.getLookupEnities(BillingType.class));
        model.addAttribute("deliverActions", lookupService.getLookupEnities(DeliverAction.class));
        model.addAttribute("networkerDatazoneSizes", lookupService.getLookupEnities(NetworkerDatazoneSize.class));
        model.addAttribute("meditechBackupTypes", lookupService.getLookupEnities(MeditechBackupType.class));
        model.addAttribute("intelligentFabricMigrationMethods", lookupService.getLookupEnities(IntelligentFabricMigrationMethod.class));
        model.addAttribute("recoverPointOptions", lookupService.getLookupEnities(RecoverPointOption.class));
        model.addAttribute("geographies", lookupService.getLookupEnities(Geography.class));
        model.addAttribute("divisions", lookupService.getLookupEnities(Division.class));
        model.addAttribute("multipleTheatersLanguagesInvolvementOptions",
            lookupService.getLookupEnities(MultipleTheatersLanguagesInvolvementOption.class));
        model.addAttribute("multipleWorkgroupsDisciplinesOptions",
            lookupService.getLookupEnities(MultipleWorkgroupsDisciplinesOption.class));
        model.addAttribute("emcClientOptions", lookupService.getLookupEnities(EMCClientOption.class));
        model.addAttribute("emcClientRelationshipOptions",
            lookupService.getLookupEnities(EMCClientRelationshipOption.class));
        model.addAttribute("processStaffMaturityOptions",
            lookupService.getLookupEnities(ProcessStaffMaturityOption.class));
        model.addAttribute("clientEnvironmentDocumentationOptions",
            lookupService.getLookupEnities(ClientEnvironmentDocumentationQualityOption.class));
        model.addAttribute("projectScopeUnderstandingOptions", lookupService.getLookupEnities(ProjectScopeUnderstandingOption.class));
        model.addAttribute("projectImpactOptions", lookupService.getLookupEnities(ProjectImpactOption.class));
        model.addAttribute("projectSponsorInvolvementOptions", lookupService.getLookupEnities(ProjectSponsorInvolvementOption.class));
        model.addAttribute("offeringMaturityOptions", lookupService.getLookupEnities(OfferingMaturityOption.class));
        model.addAttribute("projectComplexityLevelOptions", lookupService.getLookupEnities(ProjectComplexityLevelOption.class));
        model.addAttribute("externalFactorsOptions", lookupService.getLookupEnities(ExternalFactorsOption.class));
        model.addAttribute("emcStaffAvailabilityOptions", lookupService.getLookupEnities(EMCStaffAvailabilityOption.class));
        model.addAttribute("partnerStaffAvailabilityOptions", lookupService.getLookupEnities(PartnerStaffAvailabilityOption.class));
        model.addAttribute("riskLevelOptions", lookupService.getLookupEnities(RiskLevelOption.class));
        model.addAttribute("emcFederatedCompaniesInvolvementOptions", lookupService.getLookupEnities(EMCFederatedCompaniesInvolvementOption.class));
        model.addAttribute("thirdPartyInvolvementOptions", lookupService.getLookupEnities(ThirdPartyInvolvementOption.class));
        model.addAttribute("tmBillingUsageOptions", lookupService.getLookupEnities(TMBillingUsageOption.class));
        model.addAttribute("emcAccountabilityOptions", lookupService.getLookupEnities(EMCAccountabilityOption.class));
        model.addAttribute("programManagementUseCaseOptions", lookupService.getLookupEnities(ProgramManagementUseCaseOption.class));

        List<LOBLookupData> lobLookupData = lookupService.getLookupEnities(LOBLookupData.class);
        Map<Long, LOBLookupData> lobLookupDataMap = new LinkedHashMap<Long, LOBLookupData>();
        for (LOBLookupData data : lobLookupData) {
            lobLookupDataMap.put(data.getId(), data);
        }
        model.addAttribute("lobLookupDataMap", lobLookupDataMap);
        model.addAttribute("standardBillRates", ratesService.retrieveStandardBillRates());
        model.addAttribute("hourlyStdCostRates", ratesService.retrieveHourlyStdCostRates());
        
        Map<Long, DiscountFloorGroup> materialDiscountFloors = new HashMap<Long, DiscountFloorGroup>();
        List<MaterialCode> materialCodes = lookupService.getLookupEnities(MaterialCode.class);
        for (MaterialCode materialCode : materialCodes) {
            materialDiscountFloors.put(materialCode.getId(), materialCode.getDiscountFloors());
        }
        model.addAttribute("materialDiscountFloors", materialDiscountFloors);
    }

    /**
     * Create the request page.
     *
     * @param model
     *         the spring model
     * @return the view name
     * @throws ServiceRequestToolException
     *         if there is any problem executing the request.
     */
    @RequestMapping(value = "createRequest", method = RequestMethod.GET)
    public String createRequest(Model model) throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#createRequest(Model model)";
        Logger logger = getLogger();

        // Log entry
        Helper.logEntrance(logger, signature, new String[]{"model"}, new Object[]{model});

        String result = "createRequest";

        Profile profile = profileService.getDefaultProfile();
        model.addAttribute("profile", profile);
        model.addAttribute("estimatedResult", estimateRequest(null));
        addLookupEntities(model);

        // Log exit
        Helper.logExit(logger, signature, new Object[]{result});

        return result;
    }

    /**
     * Create the template request page.
     *
     * @param model
     *         the spring model
     * @return the view name
     * @throws ServiceRequestToolException
     *         if there is any problem executing the request.
     */
    @RequestMapping(value = "createTemplateRequest", method = RequestMethod.GET)
    public String createTemplateRequest(Model model) throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#createTemplateRequest(Model model)";
        Logger logger = getLogger();

        // Log entry
        Helper.logEntrance(logger, signature, new String[]{"model"}, new Object[]{model});

        String result = "createTemplateRequest";

        Profile profile = profileService.getDefaultProfile();
        model.addAttribute("profile", profile);
        model.addAttribute("estimatedResult", estimateRequest(null));
        model.addAttribute("template", true);
        addLookupEntities(model);

        // Log exit
        Helper.logExit(logger, signature, new Object[]{result});

        return result;
    }

    /**
     * Edit the request page.
     *
     * @param id
     *         the entity id
     * @param model
     *         the spring model
     * @return the view name
     * @throws ServiceRequestToolException
     *         if there is any problem executing the request.
     */
    @SyncDown(entityType = "Request")
    @RequestMapping(value = "editRequest/{id}", method = RequestMethod.GET)
    public String editRequest(@PathVariable long id, Model model) throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#editRequest(long id, Model model)";
        Logger logger = getLogger();

        // Log entry
        Helper.logEntrance(logger, signature, new String[]{"id", "model"}, new Object[]{id, model});

        String result = "editRequest";

        Request request = requestService.get(id);
        model.addAttribute("request", request);
        model.addAttribute("estimatedResult", estimateRequest(request));
        if (request.getRequestStatus() == RequestStatus.PENDING
                || request.getRequestStatus() == RequestStatus.SUBMITTED) {
            model.addAttribute("submitted", true);
        }

        if (request.getRequestStatus() == RequestStatus.PENDING) {
            Profile defaultProfile = profileService.getDefaultProfile();
            Profile approver = request.getApprover();
            if (approver != null && approver.getId() == defaultProfile.getId()) {
                model.addAttribute("approvePendingRequest", true);
            }
        }

        addLookupEntities(model);

        // Log exit
        Helper.logExit(logger, signature, new Object[]{result});

        return result;
    }

    /**
     * Edit the template request page.
     *
     * @param id
     *         the entity id
     * @param model
     *         the spring model
     * @return the view name
     * @throws ServiceRequestToolException
     *         if there is any problem executing the request.
     */
    @SyncDown(entityType = "Request")
    @RequestMapping(value = "editTemplateRequest/{id}", method = RequestMethod.GET)
    public String editTemplateRequest(@PathVariable long id, Model model) throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#editTemplateRequest(long id, Model model)";
        Logger logger = getLogger();

        // Log entry
        Helper.logEntrance(logger, signature, new String[]{"id", "model"}, new Object[]{id, model});

        String result = "editRequest";

        Request request = requestService.get(id);
        model.addAttribute("request", request);
        model.addAttribute("estimatedResult", estimateRequest(request));
        model.addAttribute("template", true);
        addLookupEntities(model);

        // Log exit
        Helper.logExit(logger, signature, new Object[]{result});

        return result;
    }

    /**
     * Views the requests page.
     *
     * @return the view name
     */
    @SyncDown(entityType = "Request", syncDownAll = true)
    @RequestMapping(value = "submittedrequests", method = RequestMethod.GET)
    public String viewSubmittedRequests() {
        final String signature = CLASSNAME + "#viewSubmittedRequests()";
        Logger logger = getLogger();

        // Log entry
        Helper.logEntrance(logger, signature, null, null);

        String result = "viewSubmittedRequests";

        // Log exit
        Helper.logExit(logger, signature, new Object[]{result});

        return result;
    }

    /**
     * Views the template folder page.
     *
     * @return the view name
     */
    @SyncDown(entityType = "Request", syncDownAll = true)
    @RequestMapping(value = "templaterequests", method = RequestMethod.GET)
    public String viewTemplateRequests() {
        final String signature = CLASSNAME + "#viewTemplateRequests()";
        Logger logger = getLogger();

        // Log entry
        Helper.logEntrance(logger, signature, null, null);

        String result = "viewTemplateRequests";

        // Log exit
        Helper.logExit(logger, signature, new Object[] { result });

        return result;
    }

    /**
     * Searches the requests based on the criteria.
     *
     * @param criteria
     *         the search criteria.
     * @return the serialized SearchResult in JSON format
     * @throws IllegalArgumentException
     *         if criteria is null.
     * @throws ServiceRequestToolException
     *         if there is any problem executing the request.
     */
    @RequestMapping(value = "requests/search", method = RequestMethod.POST)
    @ResponseBody
    public SearchResult<Request> search(@RequestBody RequestSearchCriteria criteria)
            throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#search(RequestSearchCriteria criteria)";
        Logger logger = getLogger();

        // Log entry
        Helper.logEntrance(logger, signature, new String[]{"criteria"}, new Object[]{criteria});

        SearchResult<Request> result = requestService.search(criteria);

        // Log exit
        Helper.logExit(logger, signature, new Object[]{result});

        return result;
    }

    
    /**
     * Copy the request with given id and sends back as JSON.
     *
     * @param id
     *         the request id to copy
     * @return the view name for single request.
     * @throws IllegalArgumentException
     *         if id is not positive
     * @throws com.emc.gs.tools.srf.services.ServiceRequestToolException
     *         if there is any problem executing the request.
     *         
     * @since 3.23
     */
    @SyncDown(entityType = "Request")
    @RequestMapping(value = "copyRequest/{id}", method = RequestMethod.GET)
    @ResponseBody
    public Request copy(@PathVariable long id) throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#copy(long id)";
        Logger logger = getLogger();

        // Log entry
        Helper.logEntrance(logger, signature, new String[]{"id"}, new Object[]{id});

        Request request = requestService.get(id);

        // Copy request
        Request copiedRequest = Helper.copyRequest(request, enabledTabs);

        // Log exit
        Helper.logExit(logger, signature, new Object[]{copiedRequest});

        return copiedRequest;
    }
    
    /**
     * Get the request for id.
     *
     * @param id
     *         the request id
     * @param model
     *         Spring MVC model
     * @return the view name for single request
     * @throws IllegalArgumentException
     *         if id is not positive
     * @throws ServiceRequestToolException
     *         if there is any problem executing the request.
     */
    @SyncDown(entityType = "Request")
    @RequestMapping(value = "request/{id}", method = RequestMethod.GET)
    public String getRequest(@PathVariable long id, Model model) throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#getRequest(long id, Model model)";
        Logger logger = getLogger();

        // Log entry
        Helper.logEntrance(logger, signature, new String[]{"id"}, new Object[]{id});

        Request request = requestService.get(id);
        model.addAttribute("request", request);
        model.addAttribute("estimatedResult", estimateRequest(request));
        model.addAttribute("viewMode", true);
        if (request.getRequestStatus() == RequestStatus.TEMPLATE) {
            model.addAttribute("template", true);
        }
        if (request.getRequestStatus() == RequestStatus.PENDING
                || request.getRequestStatus() == RequestStatus.SUBMITTED) {
            model.addAttribute("submitted", true);
        }
 
        if (request.getRequestStatus() == RequestStatus.PENDING) {
            Profile defaultProfile = profileService.getDefaultProfile();
            Profile approver = request.getApprover();
            if (approver != null && approver.getId() == defaultProfile.getId()) {
                model.addAttribute("approvePendingRequest", true);
            }
        }
        addLookupEntities(model);

        String result = "request";

        // Log exit
        Helper.logExit(logger, signature, new Object[]{result});

        return result;
    }

    /**
     * Copy the request with given id and opens it for edit.
     *
     * @param id
     *         the request id to copy
     * @param model
     *         spring MVC model
     * @return the view name for single request.
     * @throws IllegalArgumentException
     *         if id is not positive
     * @throws ServiceRequestToolException
     *         if there is any problem executing the request.
     */
    @SyncDown(entityType = "Request")
    @RequestMapping(value = "request/{id}/copy", method = RequestMethod.GET)
    public String copy(@PathVariable long id, Model model) throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#copy(long id, Model model)";
        Logger logger = getLogger();

        // Log entry
        Helper.logEntrance(logger, signature, new String[]{"id"}, new Object[]{id});

        Request request = requestService.get(id);

        // Copy request
        Request copiedRequest = Helper.copyRequest(request, enabledTabs);

        // Edit copied request
        model.addAttribute("request", copiedRequest);
        model.addAttribute("estimatedResult", estimateRequest(copiedRequest));
        addLookupEntities(model);

        String result = "copyRequest";

        // Log exit
        Helper.logExit(logger, signature, new Object[]{result});

        return result;
    }

    /**
     * Estimate request, get the estimated result.
     *
     * @param request
     *         the request to estimate
     * @return the estimated result.
     * @throws ServiceRequestToolException
     *         if there is any error estimating the request
     */
    private EstimatedResult estimateRequest(Request request) throws ServiceRequestToolException {
        EstimatedResult result = request == null ? null : estimatesService.estimate(request);
        if (result == null) {
            result = new EstimatedResult();
        }
        if (result.getEstimatedLOBs().isEmpty()) {
            // Add dummy LOB for UI render
            LOBResources lob = new LOBResources();
            lob.setBillingType(new BillingType());
            lob.getBillingType().setId(1);
            lob.getBillingType().setName("Time and Materials");
            result.getEstimatedLOBs().add(new EstimatedLOB(lob));
        }
        for (EstimatedLOB lob : result.getEstimatedLOBs()) {
            if (lob.getEstimatedResources().isEmpty()) {
                // Add dummy resource for UI render
                lob.getEstimatedResources().add(new EstimatedResource(new LOBResource()));
            }
        }
        return result;
    }

    /**
     * Creates the request.
     *
     * @param request
     *         the request to create
     * @return the serialized request in JSON format
     * @throws IllegalArgumentException
     *         if request is null.
     * @throws ServiceRequestToolException
     *         if there is any problem executing the request.
     */
    @SyncUp(entityType = "Request")
    @RequestMapping(value = "request", method = RequestMethod.POST)
    @ResponseBody
    @Transactional(rollbackFor = ServiceRequestToolException.class)
    public Request create(@RequestBody Request request) throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#create(Request request)";
        Logger logger = getLogger();

        // Log entry
        Helper.logEntrance(logger, signature, new String[]{"request"}, new Object[]{request});

        User currentUser = ServiceContext.getCurrentUser();
        if (request.getRequestStatus() != RequestStatus.TEMPLATE || currentUser.isTemplatePermission()) {
            request = requestService.create(request);
        } else {
            logger.info("User does not have permission to edit template, skip creation.");
        }

        // Log exit
        Helper.logExit(logger, signature, new Object[]{request});

        return request;
    }

    /**
     * Updates the request.
     *
     * @param id
     *         the id of request to update.
     * @param request
     *         the request to update
     * @return the serialized request in JSON format
     * @throws IllegalArgumentException
     *         if request is null, id is not positive or is not the id of request
     * @throws ServiceRequestToolException
     *         if there is any problem executing the request.
     */
    @SyncUp(entityType = "Request")
    @RequestMapping(value = "request/{id}", method = RequestMethod.PUT)
    @ResponseBody
    @Transactional(rollbackFor = ServiceRequestToolException.class)
    public Request update(@PathVariable long id, @RequestBody Request request) throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#update(long id, Request request)";
        Logger logger = getLogger();

        // Log entry
        Helper.logEntrance(logger, signature, new String[]{"id", "request"}, new Object[]{id, request});

        Helper.checkPositive(logger, signature, id, "id");
        Helper.checkNull(logger, signature, request, "request");
        if (id != request.getId()) {
            throw Helper.logException(logger, signature, new IllegalArgumentException(
                    "The update id is not same as customer id"));
        }

        User currentUser = ServiceContext.getCurrentUser();
        
        Request existingRequest = requestService.get(id);
        if (existingRequest != null) {
            if (existingRequest.getRequestStatus() == RequestStatus.SUBMITTED) {
                throw Helper.logException(logger, signature, new IllegalArgumentException(
                        "The request is already submitted"));
            }
            if (existingRequest.getRequestStatus() == RequestStatus.PENDING) {
                Profile defaultProfile = profileService.getDefaultProfile();
                Profile approver = existingRequest.getApprover();
                if (approver == null || approver.getId() != defaultProfile.getId()) {
                    throw Helper.logException(logger, signature, new IllegalArgumentException(
                        "You cannot update the pending request because you are not the approver"));
                } else {
                    request.setUserIdentifier(existingRequest.getUserIdentifier());
                    request.setRequestStatus(RequestStatus.PENDING);
                    request.setApprover(existingRequest.getApprover());
                    request.setAdditionalRecipients(existingRequest.getAdditionalRecipients());
                }
            }
        }


        if (request.getRequestStatus() != RequestStatus.TEMPLATE || currentUser.isTemplatePermission()) {
            request = requestService.update(request);
        } else {
            logger.info("User does not have permission to edit template, skip creation.");
        }

        // Log exit
        Helper.logExit(logger, signature, new Object[]{request});

        return request;
    }

    /**
     * Deletes the request.
     *
     * @param id
     *         the request id
     * @throws IllegalArgumentException
     *         if id is not positive.
     * @throws ServiceRequestToolException
     *         if there is any problem executing the request.
     */
    @SyncUp(entityType = "Request")
    @RequestMapping(value = "request/{id}", method = RequestMethod.DELETE)
    @ResponseBody
    @Transactional(rollbackFor = ServiceRequestToolException.class)
    public void delete(@PathVariable long id) throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#delete(long id)";
        Logger logger = getLogger();

        // Log entry
        Helper.logEntrance(logger, signature, new String[]{"id"}, new Object[]{id});

        User currentUser = ServiceContext.getCurrentUser();
        Request request = requestService.get(id);
        if (request.getRequestStatus() != RequestStatus.TEMPLATE || currentUser.isTemplatePermission()) {
            if (request.getRequestStatus() == RequestStatus.SUBMITTED) {
                throw new ServiceRequestToolException("Submitted request can not be deleted");
            }
            requestService.delete(new long[]{id});
        } else {
            logger.info("User does not have permission to edit template, skip creation.");
        }

        // Log exit
        Helper.logExit(logger, signature, null);
    }


    /**
     * Checks the attachments. Check whether they exist or not.
     *
     * <p>
     * It returns a list of Boolean to indicate the existent of each attachment.
     * </p>
     *
     * @param files
     *            the files to check
     * @return the list of Boolean.
     * @throws IllegalArgumentException
     *             if files is null
     * @throws ServiceRequestToolException
     *             if there is any problem executing the request.
     */
    @RequestMapping(value = "request/checkAttachment", method = RequestMethod.POST)
    @ResponseBody
    public List<Boolean> checkAttachment(@RequestParam("files[]") List<String> files)
            throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#checkAttachment(List<String> files)";
        Logger logger = getLogger();

        // Log entry
        Helper.logEntrance(logger, signature, new String[]{"files"}, new Object[]{files});

        Helper.checkNull(logger, signature, files, "files");

        List<Boolean> results = new ArrayList<Boolean>();

        if (files != null) {
            for (String file : files) {
                File localFile = new File(attachmentUploadFolder, file);

                if (localFile.exists()) {
                    if (localFile.isFile()) {
                        results.add(true);
                    } else {
                        throw Helper.logException(logger, signature, new ServiceRequestToolException(
                                "Path is not a file: " + localFile));
                    }
                } else {
                    results.add(false);
                }
            }
        }

        // Log exit
        Helper.logExit(logger, signature, new Object[] {results});
        return results;
    }


    /**
     * Uploads the attachments.
     * <p>
     * This method only uploads temporary attachment files. The persist of in-use attachment files are handled by
     * create/update request methods.
     * </p>
     *
     * @param files
     *            the files to attach
     * @return the attachment list
     * @throws IllegalArgumentException
     *             if files is null
     * @throws ServiceRequestToolException
     *             if there is any problem executing the request.
     */
    @RequestMapping(value = "request/uploadAttachment", method = RequestMethod.POST, produces = "text/xml")
    @ResponseBody
    public AttachmentList uploadAttachment(@RequestParam("files[]") List<MultipartFile> files)
            throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#uploadAttachment(List<MultipartFile> files)";
        Logger logger = getLogger();

        // Log entry
        Helper.logEntrance(logger, signature, new String[]{"files"}, new Object[]{files});

        Helper.checkNull(logger, signature, files, "files");

        // Copy to local temp file
        List<Attachment> attachments = new ArrayList<Attachment>();
        if (files != null) {
            for (MultipartFile file : files) {
                try {
                    String uniqueFileName;

                    if (Helper.PERSISTENT_ATTACHMENT_PATTERN.matcher(file.getOriginalFilename()).matches()) {
                        // if the file path pattern matches, it means this file is synchronized up from local app.
                        // use it directly. It's impossible for local app to hack as the file name contains a guid.
                        uniqueFileName = file.getOriginalFilename();
                        File localFile = new File(attachmentUploadFolder, uniqueFileName);

                        if (!localFile.exists()) {
                            // skip if already exists. the persist file is immutable.
                            file.transferTo(localFile);
                        }
                    } else {
                        // Generate unique file name, with ".tmpupload" suffix
                        uniqueFileName = file.getOriginalFilename() + "." + System.currentTimeMillis() + "."
                                + UUID.randomUUID() + Helper.TMP_UPLOAD_SUFFIX;

                        File localFile = new File(attachmentUploadFolder, uniqueFileName);
                        file.transferTo(localFile);
                    }

                    // Return attachment data
                    Attachment attachment = new Attachment();
                    attachment.setAttachmentSize(file.getSize());
                    attachment.setAttachmentFilename(file.getOriginalFilename());
                    attachment.setAttachmentFilepath(uniqueFileName);

                    attachments.add(attachment);
                } catch (IOException e) {
                    throw Helper.logException(logger, signature, new ServiceRequestToolException(
                            "Failed to upload attachment", e));
                }
            }
        }

        AttachmentList response = new AttachmentList(attachments);

        // Log exit
        Helper.logExit(logger, signature, new Object[] {response});
        return response;
    }

    /**
     * Removes the temporarily uploaded attachment.
     * <p>
     * This method only removes temporarily uploaded attachment. The delete of in-use attachment files are handled by
     * update/delete request methods.
     * </p>
     *
     * @param tempAttachFile
     *         the temporarily uploaded file name of attachment to delete.
     * @throws IllegalArgumentException
     *         if attachment file name is null or empty.
     * @throws com.emc.gs.tools.srf.services.ServiceRequestToolException
     *         if there is any problem executing the request.
     */
    @RequestMapping(value = "request/removeTempAttachment", method = RequestMethod.DELETE)
    @ResponseBody
    public void removeTempAttachment(@RequestParam String tempAttachFile) throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#removeTempAttachment(String tempAttachFile)";
        Logger logger = getLogger();

        // Log entry
        Helper.logEntrance(logger, signature, new String[]{"tempAttachFile"}, new Object[]{tempAttachFile});

        Helper.checkStrNullEmpty(logger, signature, tempAttachFile, "tempAttachFile");

        // Here we only delete temporary uploaded file (persistent files are handled by update/delete request methods)
        if (!tempAttachFile.endsWith(Helper.TMP_UPLOAD_SUFFIX)) {
            return;
        }

        // Quietly delete, do not raise any error, it's just temporary uploaded file
        FileUtils.deleteQuietly(new File(attachmentUploadFolder, tempAttachFile));

        // Log exit
        Helper.logExit(logger, signature, null);
    }

    /**
     * Downloads attachment.
     *
     * @param attachmentPath
     *         Attachment file path.
     * @param attachmentName
     *         Attachment file name.
     * @param response
     *         HTTP response.
     * @throws IllegalArgumentException
     *         if any string is null or empty.
     * @throws com.emc.gs.tools.srf.services.ServiceRequestToolException
     *         if there is any problem executing the request.
     */
    @RequestMapping(value = "request/downloadAttachment", method = RequestMethod.POST)
    public void downloadAttachment(@RequestParam String attachmentPath, @RequestParam String attachmentName,
                                   HttpServletResponse response) throws ServiceRequestToolException {
        final String signature = CLASSNAME
                + "#downloadAttachment(String attachmentPath, String attachmentName, HttpServletResponse response)";
        Logger logger = getLogger();

        // Log entry
        Helper.logEntrance(logger, signature, new String[]{"attachmentPath", "attachmentName", "response"},
                new Object[]{attachmentPath, attachmentName, response});

        Helper.checkStrNullEmpty(logger, signature, attachmentPath, "attachmentPath");
        Helper.checkStrNullEmpty(logger, signature, attachmentName, "attachmentName");

        File localFile = new File(attachmentUploadFolder, attachmentPath);

        if (!localFile.exists() && attachmentPath.endsWith(Helper.TMP_UPLOAD_SUFFIX)) {
            // Try persistent file
            String persistFileName = attachmentPath.substring(0,
                    attachmentPath.length() - Helper.TMP_UPLOAD_SUFFIX.length());
            localFile = new File(attachmentUploadFolder, persistFileName);
        }

        if (!localFile.exists()) {
            // Still not exist, raise exception
            throw Helper.logException(logger, signature, new ServiceRequestToolException(
                    "Attachment file is not found"));
        }

        FileInputStream input = null;
        try {
            response.setHeader("Content-Type", "application/x-download");
            response.setHeader("Content-Disposition", "attachment;filename=" + attachmentName);

            input = new FileInputStream(localFile);
            OutputStream os = response.getOutputStream();
            IOUtils.copy(input, os);
            os.flush();

            // Log exit
            Helper.logExit(logger, signature, null);
        } catch (IOException e) {
            // Ignore
            Helper.logException(logger, signature, e);
        } finally {
            IOUtils.closeQuietly(input);
        }
    }

    /**
     * Exports the requests.
     *
     * @param response
     *         the http servlet response to write export data to.
     * @param requestIds
     *         request ids to export.
     * @throws com.emc.gs.tools.srf.services.ExportServiceException
     *         if there is any problem when performing export.
     * @throws com.emc.gs.tools.srf.services.ServiceRequestToolException
     *         if there is any problem exporting the request.
     */
    @RequestMapping(value = "request/export", method = RequestMethod.GET)
    public void export(@RequestParam String requestIds, HttpServletResponse response)
            throws ExportServiceException, ServiceRequestToolException {
        final String signature = CLASSNAME + "#export(long[] requestIds, HttpServletResponse response)";
        Logger logger = getLogger();

        // Log entry
        Helper.logEntrance(logger, signature, new String[]{"requestIds", "response"}, new Object[]{requestIds,
                response});

        try {
            String[] ids = requestIds.split(",");
            Request[] requests = new Request[ids.length];
            for (int i = 0; i < ids.length; i++) {
                requests[i] = requestService.get(Long.parseLong(ids[i]));
            }

            if (requests.length == 1 && requests[0].getEngagementTypeData() != null
                    && requests[0].getEngagementTypeData().calculateSRTPath() == SRTPath.SRT4) {
                response.setContentType("application/x-download");
                response.addHeader("Content-Disposition", "attachment;filename=" 
                    + Helper.generateExportFileName(requests[0]) + ".xml");
                OutputStream os = response.getOutputStream();
                estimatesService.exportRequest(requests[0], os);
                os.flush();
            } else {
            	String fileName = "requests.pdf";
                if (requests.length == 1) {
                    fileName = "request-" + requests[0].getProjectName() + ".pdf";
                }
                response.setContentType("application/x-download");
                response.addHeader("Content-Disposition", "attachment;filename=" + fileName);
                OutputStream os = response.getOutputStream();
                exportService.exportRequests(Arrays.asList(requests), os);
                os.flush();
            }

            // Log exit
            Helper.logExit(logger, signature, null);
        } catch (IOException e) {
            // Ignore
            Helper.logException(logger, signature, e);
        } catch (Throwable e) {
            // Ignore
            Helper.logException(logger, signature, e);
        }
    }
    
    /**
     * Retrieves the last 4 digits of the request id used when generating the export file name.
     * 
     * @param requestId The request id.
     * @return The last 4 digits of the request id.
     */
    private String get4DigitsSuffix(String requestId){
        return requestId != null ? StringUtils.leftPad(StringUtils.right(requestId, 4), 4, '0') : "";
    }


    /**
     * Get submit result.
     *
     * @param submitId
     *         The submit ID
     * @param httpRequest
     *         The HTTP request
     * @return The submit result
     * @throws IllegalArgumentException
     *         if submit ID null or empty.
     * @since SRT Phase 2 Release Assembly
     */
    @RequestMapping(value = "submit/result", method = RequestMethod.GET)
    @ResponseBody
    public SubmitResult getSubmitResult(@RequestParam String submitId, HttpServletRequest httpRequest) {
        final String signature = CLASSNAME + "#getSubmitResult(String submitId)";
        Logger logger = getLogger();

        // Log entry
        Helper.logEntrance(logger, signature, new String[]{"submitId"}, new Object[]{submitId});
        Helper.checkStrNullEmpty(logger, signature, submitId, "submitId");

        HttpSession session = httpRequest.getSession(true);
        SubmitResult submitResult = (SubmitResult) session.getAttribute(submitId);
        if (submitResult != null && submitResult.isFinished()) {
            session.removeAttribute(submitId);
        }

        // Log exit
        Helper.logExit(logger, signature, new Object[]{submitResult});
        return submitResult;
    }

    /**
     * Submits the request.
     *
     * @param id
     *         the id of request to update.
     * @param request
     *         the request to submit.
     * @param httpRequest
     *         the HTTP Servlet request
     * @return the submit result
     * @throws IllegalArgumentException
     *         if request is null, id is not positive.
     * @throws com.emc.gs.tools.srf.services.ExportServiceException
     *         if there is any problem when exporting the request.
     * @throws com.emc.gs.tools.srf.services.ServiceRequestToolException
     *         if there is any problem updating the request.
     */
    @RequestMapping(value = "request/{id}/submit", method = RequestMethod.POST)
    @ResponseBody
    @Transactional(rollbackFor = ServiceRequestToolException.class)
    public SubmitResult submit(@PathVariable long id, @RequestBody Request request, HttpServletRequest httpRequest)
            throws ExportServiceException, ServiceRequestToolException {
        final String signature = CLASSNAME + "#submit(long id, Request request)";
        Logger logger = getLogger();

        // Log entry
        Helper.logEntrance(logger, signature, new String[]{"id", "request"}, new Object[]{id, request});

        Helper.checkPositive(logger, signature, id, "id");
        Helper.checkNull(logger, signature, request, "request");

        if (request.getId() == 0) {
            // If submit is from list page, there is no request body
            request = Helper.deepCloneEntity(requestService.get(id)); // make a copy so that it is a detached entity.
        } else {
            if (id != request.getId()) {
                throw Helper.logException(logger, signature, new IllegalArgumentException(
                        "The update id is not same as request id"));
            }
        }

        Request existingRequest = requestService.get(id);
        if (existingRequest != null && request.getRequestStatus() == RequestStatus.SUBMITTED) {
            throw Helper.logException(logger, signature, new IllegalArgumentException(
                    "The request is already submitted"));
        }
        
        Profile defaultProfile = profileService.getDefaultProfile();
        if (existingRequest != null && existingRequest.getRequestStatus() == RequestStatus.PENDING) {
            Profile approver = existingRequest.getApprover();
            if (approver == null || approver.getId() != defaultProfile.getId()) {
                throw Helper.logException(logger, signature, new IllegalArgumentException(
                        "You cannot submit the pending request because you are not the approver"));
            } else {
                request.setUserIdentifier(existingRequest.getUserIdentifier());
                request.setRequestStatus(RequestStatus.PENDING);
                request.setApprover(existingRequest.getApprover());
                request.setAdditionalRecipients(existingRequest.getAdditionalRecipients());
            }
        }

        SubmitResult submitResult = new SubmitResult("SubmitID-" + UUID.randomUUID().toString());
        submitResult.setValidationMessages(new ArrayList<String>());

        // Validate request
        try {
            validateRequest(request);
        } catch (IllegalArgumentException iae) {
            submitResult.getValidationMessages().add(iae.getMessage());
        }

        if (submitResult.getValidationMessages().isEmpty()) {
            // Just be safe to save the request here because possibly need handle attachment file upload
            if (request.getRequestStatus() == RequestStatus.PENDING) {
                request = requestService.update(request);
            } else {
                request = update(id, request);
            }

            // Put to session
            httpRequest.getSession(true).setAttribute(submitResult.getSubmitId(), submitResult);

            // Do submit request
            doSubmitRequest(submitResult, Arrays.asList(request));
        }

        // Log exit
        Helper.logExit(logger, signature, new Object[]{submitResult});

        return submitResult;
    }

    /**
     * Do submit requests.
     *
     * @param submitResult
     *         The submit result
     * @param validatedRequests
     *         The validated requests to submit
     * @throws com.emc.gs.tools.srf.services.ExportServiceException
     *         if there is any problem when exporting the request.
     * @throws com.emc.gs.tools.srf.services.ServiceRequestToolException
     *         if there is any problem updating the request.
     * @since SRT Phase 2 Release Assembly
     */
    private void doSubmitRequest(final SubmitResult submitResult, final List<Request> validatedRequests)
            throws ExportServiceException, ServiceRequestToolException {
        final String signature = CLASSNAME
                + "#doSubmitRequest(SubmitResult submitResult, List<Request> validatedRequests)";

        long totalSize = 0; // Total size of exported request PDF and attachments

        final Map<Long, File> exportedRequests = new HashMap<Long, File>();
        final Map<Long, File> additionalFiles = new HashMap<Long, File>();
        
        final User currentUser = ServiceContext.getCurrentUser();

        // For each validated request
        for (Request validatedRequest : validatedRequests) {
            long requestId = validatedRequest.getId();

            OutputStream output = null;
            try {
             // Create the temporary file and export the request to it
                File tempFile = File.createTempFile("request_" + requestId, ".temp");
                output = new FileOutputStream(tempFile);
                if (currentUser.isSubmitter()
                        && validatedRequest.getEngagementTypeData().calculateSRTPath() == SRTPath.SRT4
                        && validatedRequest.getRequestStatus().equals(RequestStatus.DRAFT)) {
                    exportService.exportETRequest(validatedRequest, output);
                } else if (validatedRequest.getEngagementTypeData().calculateSRTPath() == SRTPath.SRT4) {
                    estimatesService.exportRequest(validatedRequest, output);
                } else {
                    exportService.exportRequests(Arrays.asList(new Request[] { validatedRequest }), output);
                }
                output.close();
                if (validatedRequest.getRequestStatus() == RequestStatus.PENDING) {
                    File tempFile2 = File.createTempFile("request_" + requestId, ".temp");
                    output = new FileOutputStream(tempFile2);
                    exportService.exportETRequest(validatedRequest, output);
                    additionalFiles.put(requestId, tempFile2);
                    totalSize += tempFile2.length();
                }
                // Amount to total size
                totalSize += tempFile.length();
                exportedRequests.put(requestId, tempFile);
            } catch (IOException e) {
                throw Helper.logException(getLogger(), signature,
                        new ServiceRequestToolException("Failed to export request", e));
            } finally {
                IOUtils.closeQuietly(output);
            }

            // Amount attachments size to total size
            StartRequestData startRequestData = validatedRequest.getStartRequestData();
            if (startRequestData != null && startRequestData.getAttachments() != null) {
                for (Attachment attachment : startRequestData.getAttachments()) {
                    File localFile = new File(attachmentUploadFolder, attachment.getAttachmentFilepath());
                    if (localFile.exists()) {
                        totalSize += localFile.length();
                    } else {
                        getLogger().warn("Missing attachment: " + localFile);
                    }
                }
            }
        }

        // Set total size
        submitResult.setTotalSize(totalSize);

        // Execute the submit task
        submitTaskExecutor.execute(new Runnable() {
            @Override
            @Transactional(rollbackFor = ServiceRequestToolException.class)
            public void run() {
                // Put SubmitResult to thread local
                SubmitResult.SUBMIT_RESULT.set(submitResult);
                ServiceContext.setCurrentUser(currentUser);

               List<Long> submittedRequestIds = new ArrayList<Long>();
                try {
                    // Submit each validated request
                    for (Request validatedRequest : validatedRequests) {
                        long requestId = validatedRequest.getId();

                        // previous requestService.update and the next requestService.submitRequest
                        // will make currentOperationLog non-null,
                        // we need to clear the currentOperationLog to avoid the possible overhead.
                        ServiceContext.setCurrentOperationLog(null);

                        if (currentUser.isSubmitter()
                                && validatedRequest.getEngagementTypeData().calculateSRTPath() == SRTPath.SRT4
                                && validatedRequest.getRequestStatus().equals(RequestStatus.DRAFT)) {
                            // Submit request for approval
                            requestService.submitRequestForApproval(validatedRequest, exportedRequests.get(requestId));
                        } else {
                            // Submit request
                        	requestService.submitRequest(validatedRequest, exportedRequests.get(requestId), 
                                    additionalFiles.get(requestId));
                        }

                        submittedRequestIds.add(requestId);
                    }
                } catch (AuthorizationException e) {
                    submitResult.setErrorMessage(e.getMessage());
                } catch (ServiceRequestToolException e) {
                    submitResult.setErrorMessage(e.getMessage());
                } catch (NotificationServiceException e) {
                    submitResult.setErrorMessage(e.getMessage());
                } finally {

                    // Set the submitted request ids
                    submitResult.setSubmittedRequestIds(submittedRequestIds);

                    // Mark as finished
                    submitResult.setFinished(true);

                    // Remove SubmitResult from thread local
                    SubmitResult.SUBMIT_RESULT.remove();
                    ServiceContext.clear();

                    // Delete temporary files
                    for (File exportedRequest : exportedRequests.values()) {
                        exportedRequest.delete();
                    }
                }
            }
        });
    }

    /**
     * Validates engagement type.
     *
     * @param engagementTypeData
     *         the engagement type data to validate
     * @return the determined SRT path
     * @throws IllegalArgumentException
     *         if validation error occurs
     * @since SRT Phase 4 - ET Assembly 1
     */
    private SRTPath validateEngagementType(EngagementTypeData engagementTypeData) {

        final String signature = CLASSNAME + "#validateEngagementType(EngagementTypeData engagementTypeData)";
        Logger logger = getLogger();

        Helper.checkNull(logger, signature, engagementTypeData, "Engagement type");
        Helper.checkNull(logger, signature, engagementTypeData.getDeliveryCountry(), "Delivery country");

        if (!engagementTypeData.isProductLead() && !engagementTypeData.isServiceLead()) {

            throw new IllegalArgumentException("Engagement type is not selected");
        }
        if (!engagementTypeData.isEmc() && !engagementTypeData.isEcd() && !engagementTypeData.isMs()
                && !engagementTypeData.isRsa()) {
            throw new IllegalArgumentException("Line of business is not selected");
        }

        SRTPath path = engagementTypeData.calculateSRTPath();
        if (path == SRTPath.UNKNOWN) {
            throw new IllegalArgumentException("Cannot determine SRT path");
        }
        return path;
    }

    /**
     * Validates deal governance.
     *
     * @param dealGovernanceData
     *         the deal governance data to validate
     * @param path
     *         the SRT path
     * @throws IllegalArgumentException
     *         if validation error occurs
     * @since SRT Phase 4 - ET Assembly 1
     */
    private void validateDealGovernance(DealGovernanceData dealGovernanceData, SRTPath path) {
        if (path != SRTPath.SRT4 && path != SRTPath.SRT_HYBRID) {
            return;
        }

        final String signature = CLASSNAME + "#validateDealGovernance(DealGovernanceData dealGovernanceData)";
        Logger logger = getLogger();

        Helper.checkNull(logger, signature, dealGovernanceData, "Deal GovernanceData type");

        Helper.checkStrNullEmpty(logger, signature, dealGovernanceData.getOpportunityName(),
                "Opportunity Name (client then project name)");
        Helper.checkStrNullEmpty(logger, signature, dealGovernanceData.getPrimaryDeliveryOrg(),
                "Who is Primary Delivery Org?");
        Helper.checkNull(logger, signature, dealGovernanceData.getEstimatedStartDate(), "Estimated Start Date");
        Helper.checkStrNullEmpty(logger, signature, dealGovernanceData.getBriefDescription(),
                "Provide a brief description of scope/deliverables");
        Helper.checkNull(logger, signature, dealGovernanceData.getContractStructure(), "Contract Structure");
        Helper.checkStrNullEmpty(logger, signature, dealGovernanceData.getApproverNotes(), "Approver Notes");

        Map<Long, DealAnswer> dealAnswers = dealGovernanceData.getDealAnswers();
        Helper.checkNull(logger, signature, dealAnswers, "Deal answers");

        try {
            List<DealQuestionSection> sections = lookupService.getLookupEnities(DealQuestionSection.class);
            for (DealQuestionSection section : sections) {
                List<DealQuestion> questions = section.getQuestions();
                for (DealQuestion question : questions) {
                    DealAnswer answer = dealAnswers.get(question.getId());
                    if (answer != null && answer.getYesNo() != null
                            && answer.getYesNo().booleanValue() == question.isCommentCondition()) {
                        Helper.checkStrNullEmpty(logger, signature, answer.getComment(), question.getName());
                    }
                }
            }
        } catch (ServiceRequestToolException e) {
            logger.error("Failed to validate deal governance", e);
            throw new IllegalArgumentException("System validation error");
        }
    }

    /**
     * Validates risk calculation data.
     *
     * @param riskCalculationData the risk calculation data to validate.
     * @throws IllegalArgumentException if validation error occurs.
     */
    private void validateRiskCalculationData(RiskCalculationData riskCalculationData) {
        final String signature = CLASSNAME + "#validateRiskCalculationData(RiskCalculationData riskCalculationData)";
        Logger logger = getLogger();

        Helper.checkNull(logger, signature, riskCalculationData, "Risk Calculation");
        
        Helper.checkNull(logger, signature, riskCalculationData.getTheater(), "Theater");
        Helper.checkNull(logger, signature, riskCalculationData.getDivision(), "Division");
        
        // Organizational
        Helper.checkNull(logger, signature, riskCalculationData.getMultipleTheatresLanguagesInvolvement(), 
            "Will delivery involve multiple Theaters or Languages?");
        Helper.checkNull(logger, signature, riskCalculationData.getEmcFederatedCompaniesInvolvement(),
            "Will delivery involve any EMC Federated companies?");
        Helper.checkNull(logger, signature, riskCalculationData.getMultipleWorkgroupsDisciplinesInvolvement(),
            "Will delivery involve multiple Workgroups or Disciplines?");
        Helper.checkNull(logger, signature, riskCalculationData.getThirdPartyInvolvement(),
            "Is there a 3rd Party between us and the end Client?");
        
        // Client
        Helper.checkNull(logger, signature, riskCalculationData.getEmcClientType(),
            "Is this a new or existing EMC Client?");
        Helper.checkNull(logger, signature, riskCalculationData.getEmcClientRelationshipType(),
            "What is the state of the EMC relationship with this Client?");
        Helper.checkNull(logger, signature, riskCalculationData.getClientProcessStaffMaturityType(),
            "What is the client's process and staff maturity?");
        Helper.checkNull(logger, signature, riskCalculationData.getClientEnvironmentDocumentationType(),
            "How well is the client's environment documented?");
        Helper.checkNull(logger, signature, riskCalculationData.getProjectScopeUnderstandingType(),
            "Does EMC and the client fully understand the Project Scope?");
        Helper.checkNull(logger, signature, riskCalculationData.getProjectImpactType(),
            "How strategic is the Project to EMC and Client?");
        Helper.checkNull(logger, signature, riskCalculationData.getProjectSponsorInvolvementType(),
            "How involved will the client project sponsor be?");
        
        // Contractual
        Helper.checkPositive(logger, signature, riskCalculationData.getListPrice(),
            "What is the list price ($) of this opportunity?");
        Helper.checkPositive(logger, signature, riskCalculationData.getPotentialValue(),
            "What is the potential value of subsequent phases?");
        Helper.checkNull(logger, signature, riskCalculationData.getTmBillingUsageType(),
            "Will standard T&M billing will be used?");
        Helper.checkNull(logger, signature, riskCalculationData.getEmcAccountabilityType(),
            "Will EMC be accountable for any deliverables?");
        
        // Delivery
        Helper.checkNull(logger, signature, riskCalculationData.getOfferingMaturityType(),
            "What is the maturity of the offering being proposed?");
        Helper.checkNull(logger, signature, riskCalculationData.getProjectComplexityLevel(),
            "What is the expected complexity level of the project?");
        Helper.checkNull(logger, signature, riskCalculationData.getExternalFactorsType(),
            "Are there any external factors impacting the project schedule?");
        Helper.checkNull(logger, signature, riskCalculationData.getEmcStaffAvailability(),
            "What is the availability of EMC staff to deliver this?");
        Helper.checkNull(logger, signature, riskCalculationData.getPartnerStaffAvailability(),
            "What is the availability of partner staff to deliver this?");
        Helper.checkNull(logger, signature, riskCalculationData.getAdditionalRiskLevel(),
            "Any additional risks not mentioned above? (use only if additional unspecified risk factors apply)");

        Helper.checkPositiveOrZero(logger, signature, riskCalculationData.getAdjustment(), false,
            "Adjustment");
        Helper.checkNull(logger, signature, riskCalculationData.getProgramManagementUseCaseType(),
            "Does Opportunity Meet PgM Use Case(s");
    }

    /**
     * Validates estimates.
     *
     * @param request
     *         the request data to validate
     * @param path
     *         the SRT path
     * @throws IllegalArgumentException
     *         if validation error occurs
     * @since SRT Phase 4 - ET Assembly 1
     */
    private void validateEstimates(Request request, SRTPath path) {
        if (path != SRTPath.SRT4 && path != SRTPath.SRT_HYBRID) {
            return;
        }
        EstimatesData estimatesData = request.getEstimatesData();

        final String signature = CLASSNAME + "#validateEstimates(EstimatesData estimatesData)";
        Logger logger = getLogger();

        Helper.checkNull(logger, signature, estimatesData, "Estimates data");
        Helper.checkNull(logger, signature, estimatesData.getDealCurrency(), "Deal currency");
        Helper.checkNull(logger, signature, estimatesData.getDeliverAction(), "DeliveryAction");
        Helper.checkDecimalInterval(logger, signature, estimatesData.getEstimatedPercent(), BigDecimal.ZERO,
            Helper.HUNDRED, 2, false, "Estimated at percent");
        Helper.checkDecimalInterval(logger, signature, estimatesData.getCappedPercent(), BigDecimal.ZERO,
            Helper.HUNDRED, 2, false, "Capped at percent");
        Helper.checkPositiveOrZero(logger, signature, estimatesData.getExpenseAmount(), 2, false, "Expense Amount");
        Helper.checkPositiveOrZero(logger, signature, estimatesData.getClientPricingOverride(), 2, false,
            "Client Pricing Override");

        List<LOBResources> lobResourcesList = estimatesData.getLobResources();

        Helper.checkNull(logger, signature, lobResourcesList, "Estimate LOBs");

        if (lobResourcesList.size() < 1) {
            throw new IllegalArgumentException("At least one LOB is required");
        }

        User currentUser = ServiceContext.getCurrentUser();
        boolean checkDeliveryActionRelatedFields 
            = !(path == SRTPath.SRT4 && currentUser.getUserIdentifier().equals(request.getUserIdentifier()));
        long deliverActionId = 0;
        if (checkDeliveryActionRelatedFields) {
            DeliverAction deliverAction = estimatesData.getDeliverAction();
            if (deliverAction != null) {
                deliverActionId = deliverAction.getId();
            }
        }

        boolean expenseWBSNumberSet = false;
        boolean expenseSalesOrderItemNumberSet = false;
        for (LOBResources lobResources : lobResourcesList) {
            LOB lob = lobResources.getLob();
            Helper.checkNull(logger, signature, lob, "LOB");
            Helper.checkNull(logger, signature, lobResources.getMaterialCode(), "Material Code");
            Helper.checkNull(logger, signature, lobResources.getCompetency(), "Competency");
            Helper.checkNull(logger, signature, lobResources.getBillingType(), "Billing Type");
            Helper.checkIntegerInterval(logger, signature, lobResources.getMonthsNum(), 6, 84,
                    true, "Months of Entry");
            Helper.checkPositiveOrZero(logger, signature, lobResources.getExpenseAmount(),
                    2, false, "Expense Amount");
            if (lobResources.getBillingType().getId() == 2) {
                Helper.checkDecimalInterval(logger, signature, lobResources.getDiscountPercent(), BigDecimal.ZERO,
                        Helper.HUNDRED, 2, false, "Discount percent");
                Helper.checkPositiveOrZero(logger, signature, lobResources.getDiscountAmount(),
                        2, false, "Discount Amount");
            }
            
            
            if (checkDeliveryActionRelatedFields && deliverActionId > 0) {
                WBS wbs = lobResources.getWbs();
                boolean isMS = lob.getId() == 4;
                
                if (deliverActionId >= 8 && deliverActionId <= 11) {
                	Helper.checkNull(logger, signature, wbs, "WBS");
                    Helper.checkSalesOrderItemNumber(logger, signature, wbs.getSalesOrderItemNumber(), "Sales Order Item Number");
                    String expenseSalesOrderItemNumber = wbs.getExpenseSalesOrderItemNumber();
                    if (expenseSalesOrderItemNumber != null && !expenseSalesOrderItemNumber.trim().isEmpty()) {
                        if (expenseSalesOrderItemNumberSet) {
                            throw new IllegalArgumentException("Just a single Expense Sales Order Item Number is allowed");
                        } else {
                            Helper.checkSalesOrderItemNumber(logger, signature, expenseSalesOrderItemNumber, "Expense Sales Order Item Number");
                            expenseSalesOrderItemNumberSet = true;
                        }
                    }
                }
                if (deliverActionId == 5 || deliverActionId == 7 || deliverActionId == 10 || deliverActionId == 11) {
                	Helper.checkNull(logger, signature, wbs, "WBS");
                    Helper.checkWBSNumber(logger, signature, wbs.getWbsNumber(), "WBS Number", isMS);
                    String expenseWBSNumber = wbs.getExpenseWBSNumber();
                    if (expenseWBSNumber != null && !expenseWBSNumber.trim().isEmpty()) {
                        if (expenseWBSNumberSet) {
                            throw new IllegalArgumentException("Just a single Expense WBS Number is allowed");
                        } else {
                            Helper.checkWBSNumber(logger, signature, expenseWBSNumber, "Expense WBS Number", isMS);
                            expenseWBSNumberSet = true;
                        }
                    }
                }
            }

            List<LOBResource> resources = lobResources.getResources();
            Helper.checkNull(logger, signature, resources, "LOB resources");

            if (resources.size() < 1) {
                throw new IllegalArgumentException("At least one resource is required");
            }

            for (LOBResource resource : resources) {
                Helper.checkNull(logger, signature, resource.getRole(), "Resource role");
                Helper.checkNull(logger, signature, resource.getCompetency(), "Resource competency");
                if (lobResources.getBillingType().getId() == 1) {
                    Helper.checkPositiveOrZero(logger, signature, resource.getBillRateOverride(),
                            2, false, "Bill rate override");
                }
                Helper.checkDecimalInterval(logger, signature, resource.getContingencyPercent(), BigDecimal.ZERO,
                        Helper.HUNDRED, 2, false, "Contingency");
                Helper.checkNull(logger, signature, resource.getStartDate(), "Start date");
                Helper.checkNull(logger, signature, resource.getEndDate(), "End date");
                if (resource.getStartDate().after(resource.getEndDate())) {
                    throw new IllegalArgumentException("Start date must be earlier than end date");
                }

                Map<Integer, Integer> hours = resource.getMonthHours();
                Helper.checkNull(logger, signature, hours, "Month hours");
                int totalHours = 0;
                for (Integer hour : hours.values()) {
                    Helper.checkPositive(logger, signature, hour, "Month hour");
                    totalHours += hour;
                }
                if (totalHours <= 0) {
                    throw new IllegalArgumentException("Working hours of the resource is required (positive)");
                }
            }
        }

        if (checkDeliveryActionRelatedFields) {
            if (deliverActionId == 5 || deliverActionId == 7 || deliverActionId == 10 || deliverActionId == 11) {
                if (!expenseWBSNumberSet) {
                    throw new IllegalArgumentException("Expense WBS Number is required");
                }
            }
            if (deliverActionId >= 8 && deliverActionId <= 11) {
                if (!expenseSalesOrderItemNumberSet) {
                    throw new IllegalArgumentException("Expense Sales Order Item Number is required");
                }
            }
        }
    }

    /**
     * Validates a request.
     *
     * @param request
     *         the request to be validated
     * @throws IllegalArgumentException
     *         if a validation error occurs
     */
    private void validateRequest(Request request) throws ServiceRequestToolException {

        final String signature = CLASSNAME + "#validateRequest()";
        Logger logger = getLogger();

        // Project Info
        StartRequestData startRequestData = validateProjectInfo(request);

        // Engagement Type
        EngagementTypeData engagementTypeData = request.getEngagementTypeData();
        SRTPath path = validateEngagementType(engagementTypeData);

        // Deal Governance
        // Commented out validation for Deal Governance as per requirements for SRT Phase 4 - ET Release Assembly
        // validateDealGovernance(request.getDealGovernanceData(), path);
        // If just RSA or ECD LOBs are selected than no Risk Calculation data is required
        if (Helper.isRiskCalculationRequired(request)) {
            validateRiskCalculationData(request.getRiskCalculationData());
        }

        // Estimates
        validateEstimates(request, path);

        if (path == SRTPath.SRT4) {
            // If the user is a non-submitter check that an approver is chosen
            User currentUser = ServiceContext.getCurrentUser();
            Boolean isSubmitter = currentUser.isSubmitter();
            Profile approver = request.getApprover();
            if (isSubmitter && request.getRequestStatus().equals(RequestStatus.DRAFT)) {
                Helper.checkNull(logger, signature, approver, "Approver");
            }
            List<Profile> additionalRecipients = request.getAdditionalRecipients();
            if (additionalRecipients != null) {
                for (int i = 0; i < additionalRecipients.size(); i++) {
                    Profile profile = additionalRecipients.get(i);
                    if (profile.getId() == approver.getId()) {
                        throw logException(logger, signature, new IllegalArgumentException(
                                "Additional Receivers should not contain the approver."));
                    }
                }
            }
            // For SRT4 path, no need validate Service Request Info and Service
            // Activities
            return;
        }

        // Service Request Info
        validateServiceRequestInfo(request.getRequestType(), request.getCustomer(), startRequestData);

        CoreOptions coreOptions = startRequestData.getCoreOptions();
        DPADOptions dpadOptions = startRequestData.getDpadOptions();
        ASDOptions asdOptions = startRequestData.getAsdOptions();
        OtherRequestOptions otherOptions = startRequestData.getOtherRequestOptions();
        AffinityOptions affinityOptions = startRequestData.getAffinityOptions();
        Helper.checkNull(logger, signature, coreOptions, "Request Data Core options");
        Helper.checkNull(logger, signature, dpadOptions, "Request Data DPAD options");
        Helper.checkNull(logger, signature, asdOptions, "Request Data ASD options");
        Helper.checkNull(logger, signature, otherOptions, "Request Data Other options");
        Helper.checkNull(logger, signature, affinityOptions, "Request Data Affinity options");

        boolean unified = coreOptions.isUnified() || coreOptions.isVblock();
        boolean mainframe = coreOptions.isMainframe();
        boolean san = coreOptions.isSan();
        boolean symmMF = coreOptions.isSymmMf();
        boolean symmOS = coreOptions.isSymmOs();
        boolean vplex = coreOptions.isVplex();
        boolean replication = coreOptions.isReplication();
        boolean xtreme = enabledTabs.isEnableXtreme() && coreOptions.isXtremeIO();
        boolean mss = enabledTabs.isEnableMSS() && otherOptions.isDiskRetention();
        boolean cta = enabledTabs.isEnableCTA() && coreOptions.isCta();
        boolean residency = enabledTabs.isEnableResidency() && otherOptions.isResidency();
        boolean sourceOne = enabledTabs.isEnableSourceOne() && dpadOptions.isSourceOne();
        boolean asd = enabledTabs.isEnableASD() && (asdOptions.isAppSync() || asdOptions.isUim());
        boolean healthCheck = enabledTabs.isEnableHealthCheck() && otherOptions.isHealthChecks();
        boolean notListed = otherOptions.getNotListed();
        boolean isilon = enabledTabs.isEnableIsilon() && coreOptions.isIsilon();
        boolean vipr = enabledTabs.isEnableViPR() && asdOptions.isVipr();
        boolean atmos = enabledTabs.isEnableAtmos() && (asdOptions.isAtmos() || asdOptions.isCentera());
        boolean vblock = enabledTabs.isEnableVblock() && coreOptions.isVblock();
        boolean dpad = enabledTabs.isEnableDPAD() && (dpadOptions.isAvamar() || dpadOptions.isDataDomain()
                || dpadOptions.isEdl() || dpadOptions.isNetworker()
                || dpadOptions.isDpa() || dpadOptions.isRecoverPoint() || dpadOptions.isMozy());
        boolean vmware = enabledTabs.isEnableVMWare() && affinityOptions.isVmware();

        boolean changeRequest = enabledTabs.isEnableChangeRequest() && coreOptions.isChangeRequest();
        boolean moveRequest = enabledTabs.isEnableMoveRequest() && otherOptions.isMoveRequest();
        boolean w4n = enabledTabs.isEnableW4N() && asdOptions.isW4n();
        boolean srm = enabledTabs.isEnableSRM() && asdOptions.isSrm();
        boolean isUnfundedProject = request.getProjectType() != null
                && UNFUNDED_TYPES.contains(request.getProjectType().getId());

        if (dpad && request.getDpadRequestData() != null && request.getDpadRequestData().getServicesScope() != null
                && request.getDpadRequestData().getServicesScope().isDlm()) {
            mainframe = true;
        }

        if (!unified && !mainframe && !xtreme && !replication && !cta && !mss && !residency && !sourceOne
                && !asd && !healthCheck && !isilon && !vipr && !atmos && !vblock && !dpad && !vmware
                && !changeRequest && !moveRequest && !w4n && !srm && !isUnfundedProject && !san && !symmMF && !symmOS 
                && !vplex && !notListed) {
            throw new IllegalArgumentException("Must choose at least 1 service activity checkbox");
        }

        if (mss) {
            validateMSS(request.getMssRequestData());
        }
        
        if (san) {
            validateSAN(request.getSanTanInformation());
        }

        if (cta) {
            validateCTA(request.getCtaRequestData());
        }

        if (residency) {
            validateResidency(request.getResidencyRequestData());
        }

        if (sourceOne) {
            validateSourceOne(request.getSourceOneRequestData());
        }

        if (asd) {
            validateASD(request.getAsdRequestData());
        }

        if (healthCheck) {
            validateHealthCheck(request.getHealthCheckRequestData());
        }

        if (isilon) {
            validateIsilon(request.getIsilonRequestData());
        }

        if (vipr) {
            validateVipr(request.getViprRequestData());
        }

        if (vblock) {
            validateVblock(request.getVblockRequestData());
        }

        if (atmos) {
            validateAtmos(request.getAtmosRequestData());
        }

        if (dpad) {
            validateDPAD(request.getDpadRequestData());
        }

        if (vmware) {
            validateVMWare(request.getVmwareRequestData());
        }

        if (changeRequest) {
            validateCR(request.getChangeRequestData());
        }

        if (moveRequest) {
            validateMR(request.getMoveRequestData());
        }

        if (w4n) {
            validateW4N(request.getW4nData());
        }

        if (srm) {
            validateSRM(request.getSrmRequestData());
        }

        if (isUnfundedProject) {
            validateUnfundedProject(request.getUnfundedProjectData());
        }

        if (xtreme) {
            validateXtreme(request.getXtremeRequestData());
        }
        
        

        // FIXME: F202: Infrastructure, Unified, BC, and Mainframe tabs. - Remove ALL field validation that prevents
        // them from
        // proceeding to the next screen. I would suggest that the client and server side validation logic be disabled
        // in the code for the short term until the pilot is over in case they change their mind again
        /*
         * InfrastructureRequestData infrastructureRequestData = request.getInfrastuctureRequestData(); boolean
         * showInfrastructure = unified || mainframe || replication; boolean showMainframe = mainframe; boolean
         * showUnified = unified; boolean showBC = replication; // Infrastructure if(showInfrastructure){
         * validateInfrastructure(infrastructureRequestData); } // Mainframe if(showMainframe){
         * validateMainframe(request.getMainframeRequestData()); } // Unified if (showInfrastructure) {
         * VnxClariionInformation vnxClariionInformation = infrastructureRequestData.getVnxClariionInformation(); if
         * (vnxClariionInformation != null) { VnxInstallProtocolType vnxProtocol =
         * vnxClariionInformation.getVnxInstallProtocolType(); if (vnxProtocol != null) { if
         * ("File Only (CIFS/NFS)".equals(vnxProtocol.getName()) || "BOTH".equals(vnxProtocol.getName())) { showUnified
         * = true; } else if ("Block Only (FC/ISCSI)".equals(vnxProtocol.getName())) { showUnified = false; } } } }
         * UnifiedRequestData unifiedRequestData = request.getUnifiedRequestData(); if(showUnified){
         * validateUnified(unifiedRequestData, infrastructureRequestData); } // BC if(showBC || (showUnified &&
         * unifiedRequestData.getServicesScope().isNasIpReplication()) || (showInfrastructure &&
         * infrastructureRequestData.isVplexServiceEnabled() &&
         * infrastructureRequestData.getVplexInformation().isRecoverPointInstalledOption())){
         * validateBC(request.getBcRequestData(), request.getUnifiedRequestData()); }
         */
    }

    /**
     * <p>Validates data for <code>SAN / Connectivity</code> section.</p>
     * 
     * @param sanTanInformation a <code>SanTanInformation</code> to be validated. 
     * @since 3.12
     */
    private void validateSAN(SanTanInformation sanTanInformation) {
        final String signature = CLASSNAME + "#validateSAN()";
        Logger logger = getLogger();
        Helper.checkNull(logger, signature, sanTanInformation, "SAN / Connectivity Data");


        Helper.checkNull(logger, signature, sanTanInformation, "San Tan Information");
        Helper.checkDecimal(logger, signature, sanTanInformation.getKnowledgeTransferHours(), 1,
            "# hours of knowledge transfer (SAN / Connectivity)");
        boolean sanMigrationInScopeOption = sanTanInformation.isSanMigrationInScopeOption();
        Helper.checkNull(logger, signature, sanMigrationInScopeOption, "Is SAN migration in scope?");
        if (sanMigrationInScopeOption) {
            Helper.checkPositive(logger, signature, sanTanInformation.getTotalPortsToMigrate(),
                "# of total ports to migrate?");
        }
        Helper.checkPositiveOrZero(logger, signature, sanTanInformation.getSanDirectorsNumber(), true,
            "# of SAN directors to install");
        Helper.checkPositiveOrZero(logger, signature, sanTanInformation.getSanSwitchesNumber(), true,
            "# of SAN switches to install");
        Helper.checkPositiveOrZero(logger, signature, sanTanInformation.getBladesNumber(), true,
            "# of blades to install in existing directors and switches");
        Helper.checkPositiveOrZero(logger, signature, sanTanInformation.getFcoeSwitchesNumber(), true,
            "# of FCoE switches to install");
        Helper.checkPositiveOrZero(logger, signature, sanTanInformation.getFcoeVlanNumber(), true,
            "# of FCoE VLANs to configure per switch");
        Helper.checkPositiveOrZero(logger, signature, sanTanInformation.getFcoeChannelNumber(), true,
            "# of FCoE port channels/trunks to configure per switch");
        Helper.checkPositiveOrZero(logger, signature, sanTanInformation.getSanExtensionDevicesNumber(), true,
            "# of SAN extension devices to be installed");
        Helper.checkPositiveOrZero(logger, signature, sanTanInformation.getNasToCxUnitsNumber(), true,
            "# of new NAS units to connect to SAN and CX");
        Helper.checkPositiveOrZero(logger, signature, sanTanInformation.getNasToSymmetrixUnitsNumber(), true,
            "# of new NAS units to connect to SAN and Symmetrix");
        Helper.checkPositiveOrZero(logger, signature, sanTanInformation.getNasToCxHostsNumber(), true,
            "# of new physical hosts to connect to SAN and CX");
        Helper.checkPositiveOrZero(logger, signature, sanTanInformation.getNasToSymmetrixHostsNumber(), true,
            "# of new physical hosts to connect to SAN and Symmetrix");
        Helper.checkPositiveOrZero(logger, signature, sanTanInformation.getVerifyMajorOutageConnectivityHostsNumber(),
            true, "# of hosts to verify connectivity after major outage (not migrations)");
        Helper.checkPositiveOrZero(logger, signature, sanTanInformation.getDeinstalledSanDirectorsNumber(), true,
            "# of SAN directors to be deinstalled");
        Helper.checkPositiveOrZero(logger, signature, sanTanInformation.getDeinstalledSanSwitchesNumber(), true,
            "# of SAN switches/appliances to be deinstalled");
        Helper.checkPositiveOrZero(logger, signature, sanTanInformation.getDeinstalledSanExtensionDevicesNumber(), true,
            "# of SAN extension devices to be deinstalled");
    }

    /**
     * Validates the SRM request data.
     *
     * @param srmRequestData
     *         the data to validate
     * @throws IllegalArgumentException
     *         if the data provided is not valid
     * @since SRT Phase 3 Merge Assembly
     */
    private void validateSRM(SRMRequestData srmRequestData) {
        final String signature = CLASSNAME + "#validateSRM(SRMRequestData srmRequestData)";
        Logger logger = getLogger();
        Helper.checkNull(logger, signature, srmRequestData, "SRM Request Data");

        Helper.checkPositiveOrZero(logger, signature, srmRequestData.getAixVio(),
                false, "# of AIX VIO");
        Helper.checkPositiveOrZero(logger, signature, srmRequestData.getBrocade(),
                false, "# of Brocade");
        Helper.checkPositiveOrZero(logger, signature, srmRequestData.getCiscoMds(),
                false, "# of Cisco MDS");
        Helper.checkPositiveOrZero(logger, signature, srmRequestData.getCiscoUcs(),
                false, "# of Cisco UCS");
        Helper.checkPositiveOrZero(logger, signature, srmRequestData.getConvergedInfrastracture(),
                false, "# of Converged Infrastructure");
        Helper.checkPositiveOrZero(logger, signature, srmRequestData.getDataCenters(),
                false, "# of Data Centers");
        Helper.checkPositiveOrZero(logger, signature, srmRequestData.getDataDomain(),
                false, "# of Data Domain");
        Helper.checkPositiveOrZero(logger, signature, srmRequestData.getEmcAtmos(),
                false, "# of EMC Atmos");
        Helper.checkPositiveOrZero(logger, signature, srmRequestData.getEmcAvamar(),
                false, "# of EMC Avamar");
        Helper.checkPositiveOrZero(logger, signature, srmRequestData.getEmcCentera(),
                false, "# of EMC Centera");
        Helper.checkPositiveOrZero(logger, signature, srmRequestData.getEmcDataProtectionAdvisor(),
                false, "# of EMC Data Protection Advisor");
        Helper.checkPositiveOrZero(logger, signature, srmRequestData.getEmcIsilonNas(),
                false, "# of EMC Isilon/NAS");
        Helper.checkPositiveOrZero(logger, signature, srmRequestData.getEmcRecoverPoint(),
                false, "# of EMC Recover Point");
        Helper.checkPositiveOrZero(logger, signature, srmRequestData.getEmcVipr(),
                false, "# of EMC ViPR");
        Helper.checkPositiveOrZero(logger, signature, srmRequestData.getEmcVmaxSymmetrix(),
                false, "# of EMC VMAX/Symmetrix");
        Helper.checkPositiveOrZero(logger, signature, srmRequestData.getEmcVnxBlock(),
                false, "# of EMC VNX Block");
        Helper.checkPositiveOrZero(logger, signature, srmRequestData.getEmcVnxFileNas(),
                false, "# of EMC VNX File/NAS");
        Helper.checkPositiveOrZero(logger, signature, srmRequestData.getEmcVplex(),
                false, "# of EMC Vplex");
        Helper.checkPositiveOrZero(logger, signature, srmRequestData.getVmwareEsxServers(),
                false, "# of VMWare ESX Servers");
        Helper.checkPositiveOrZero(logger, signature, srmRequestData.getXtremIo(),
                false, "# of XtremIO");
        Helper.checkPositiveOrZero(logger, signature, srmRequestData.getHitachiDeviceManager(),
                false, "# of Hitachi Device Manager");
        Helper.checkPositiveOrZero(logger, signature, srmRequestData.getHp3ParStoreServ(),
                false, "# of HP 3Par Store Serv");
        Helper.checkPositiveOrZero(logger, signature, srmRequestData.getHpEva(),
                false, "# of HP EVA");
        Helper.checkPositiveOrZero(logger, signature, srmRequestData.getHpStorageWorks(),
                false, "# of HP StorageWorks 9000");
        Helper.checkPositiveOrZero(logger, signature, srmRequestData.getHyperV(),
                false, "# of Hyper-V");
        Helper.checkPositiveOrZero(logger, signature, srmRequestData.getIbmDsSeries(),
                false, "# of IBM DS Series");
        Helper.checkPositiveOrZero(logger, signature, srmRequestData.getIbmSanVolumeControllers(),
                false, "# of IBM SAN Volume Controllers");
        Helper.checkPositiveOrZero(logger, signature, srmRequestData.getIbmSvc(),
                false, "# of IBM SVC/V7000");
        Helper.checkPositiveOrZero(logger, signature, srmRequestData.getIbmXiv(),
                false, "# of IBM XIV");
        Helper.checkPositiveOrZero(logger, signature, srmRequestData.getNetAppFilerNas(),
                false, "# of NetApp Filer/NAS");
        Helper.checkPositiveOrZero(logger, signature, srmRequestData.getOracle(),
                false, "# of Oracle");
        Helper.checkPositiveOrZero(logger, signature, srmRequestData.getPhysicalHosts(),
                false, "# of Physical Hosts");
        Helper.checkPositiveOrZero(logger, signature, srmRequestData.getSanPorts(),
                false, "# of SAN Ports");
        Helper.checkPositiveOrZero(logger, signature, srmRequestData.getViSanPerfProbes(),
                false, "# of VI Virtual Instrumetns SAN Performance Probes");
    }

    /**
     * Validates the Unfunded project request data.
     *
     * @param unfundedProjectData
     *         the data to validate
     * @throws IllegalArgumentException
     *         if the data provided is not valid
     * @since SRT Phase 3-2 - W4N and Unfunded Project Tabs Assembly
     */
    private void validateUnfundedProject(UnfundedProjectData unfundedProjectData) {
        final String signature = CLASSNAME + "#validateUnfundedProject()";
        Logger logger = getLogger();
        Helper.checkNull(logger, signature, unfundedProjectData, "Unfunded Project Data");

        if (unfundedProjectData.getStartDate() != null && unfundedProjectData.getEndDate() != null) {
            if (unfundedProjectData.getStartDate().after(unfundedProjectData.getEndDate())) {
                throw Helper.logException(logger, signature, new IllegalArgumentException(
                        "'Start Date' should not be after 'End Date'."));
            }
        }
    }

    /**
     * Validates the W4N request data.
     *
     * @param w4nData
     *         the data to validate
     * @throws IllegalArgumentException
     *         if the data provided is not valid
     * @since SRT Phase 3-2 - W4N and Unfunded Project Tabs Assembly
     */
    private void validateW4N(W4NData w4nData) {
        final String signature = CLASSNAME + "#validateW4N(W4NData w4nData)";
        Logger logger = getLogger();
        Helper.checkNull(logger, signature, w4nData, "W4N Data");

        if (w4nData.getTotalManagedDevices() != null) {
            Helper.checkPositiveOrZero(logger, signature, w4nData.getTotalManagedDevices(), false,
                    "Total Managed Devices");
        }

        if (w4nData.isExistingSmartsCustomer()) {
            if (w4nData.getTotalManagedPandI() != null) {
                Helper.checkPositiveOrZero(logger, signature, w4nData.getTotalManagedPandI(), false,
                        "Total Managed P&I");
            }
        } else {
            // these fields should not be available to the user
            if (w4nData.getTotalManagedPandI() != null && w4nData.getTotalManagedPandI() != 0) {
                throw Helper.logException(logger, signature, new IllegalArgumentException(
                        "'Total Managed P&I' should not be present."));
            }
            if (w4nData.getOtherSPNotListed() != null && w4nData.getOtherSPNotListed().trim().length() > 0) {
                throw Helper.logException(logger, signature, new IllegalArgumentException(
                        "'Other SP / Coll / RP not Listed' should not be present."));
            }
            if (w4nData.getSmartsDomainTypes() != null && w4nData.getSmartsDomainTypes().size() > 0) {
                throw Helper.logException(logger, signature, new IllegalArgumentException(
                        "'Smart Domain Types' should not be present."));
            }
        }

        if (w4nData.getEnabledFlowsCount() != null) {
            Helper.checkPositiveOrZero(logger, signature, w4nData.getEnabledFlowsCount(), false,
                    "# of Flow enabled Routers");
        }
        if (w4nData.getNumberOfLUNS() != null) {
            Helper.checkPositiveOrZero(logger, signature, w4nData.getNumberOfLUNS(), false, "# of LUNS");
        }
        if (w4nData.getNumberOfDisks() != null) {
            Helper.checkPositiveOrZero(logger, signature, w4nData.getNumberOfDisks(), false, "# of Disks");
        }
        if (w4nData.getNumberOfArrays() != null) {
            Helper.checkPositiveOrZero(logger, signature, w4nData.getNumberOfArrays(), false, "# of Arrays");
        }
    }

    /**
     * Validates the move request data.
     *
     * @param moveRequestData
     *         the data to validate
     * @since SRT Phase 3-2 - Move Request and Change Request Tabs Assembly
     */
    private void validateMR(MoveRequestData moveRequestData) {
        final String signature = CLASSNAME + "#validateMR(MoveRequestData moveRequestData)";
        Logger logger = getLogger();
        Helper.checkNull(logger, signature, moveRequestData, "Move Request Data");

        Helper.checkNull(logger, signature, moveRequestData.getAfterHoursMSSNeeded(),
                "Are after-hours, holiday, or weekend services needed?");
        if (moveRequestData.isMoveServices()) {
            Helper.checkNull(logger, signature, moveRequestData.getEquipmentUnderMaintenance(),
                    "Is this equipment under an EMC Maintenance contract?");
            Helper
                    .checkNull(logger, signature, moveRequestData.getEmcMoveServicesNeeded(), "Are EMC move services needed?");
            Helper.checkNull(logger, signature, moveRequestData.getPickupAfterHours(),
                    "Does the pickup/delivery need to be completed after-business hours?");
            Helper.checkNull(logger, signature, moveRequestData.getSingleEvent(),
                    "Will the move take place as a single event?");
            Helper.checkNull(logger, signature, moveRequestData.getEachPieceNeedsNetCfgReset(),
                    "Does each piece of equipment need networking configuration reset?");
            Helper.checkNull(logger, signature, moveRequestData.getEmcPackingMaterialsNeeded(),
                    "Is EMC packaging material needed?");
        }
    }

    /**
     * Validates the change request data.
     *
     * @param changeRequestData
     *         the data to validate
     * @since SRT Phase 3-2 - Move Request and Change Request Tabs Assembly
     */
    private void validateCR(ChangeRequestData changeRequestData) {
        final String signature = CLASSNAME + "#validateCR(ChangeRequestData changeRequestData)";
        Logger logger = getLogger();
        Helper.checkNull(logger, signature, changeRequestData, "Change Request Data");

        Helper.checkNull(logger, signature, changeRequestData.getNumberOfMonths(), "# of Months");
        Helper.checkIntegerInterval(logger, signature, changeRequestData.getNumberOfMonths(), 6, 24, false,
                "# of Months");

        List<HoursByMonth> rows = changeRequestData.getRows();
        Helper.checkNull(logger, signature, rows, "Hours By Month Grid");

        if (rows.isEmpty()) {
            throw Helper.logException(logger, signature, new IllegalArgumentException(
                    "'Hours By Month Grid' should not be empty."));
        }

        for (HoursByMonth row : rows) {
            //Helper.checkStrNullEmpty(logger, signature, row.getCurrentSAPWBSElementNo(), "Current SAP WBS Element No");
        	Helper.checkWBSNumber(logger, signature, row.getCurrentSAPWBSElementNo(), "Current SAP WBS Element No", false);

            List<RoleHoursByMonth> roleRows = row.getRows();
            Helper.checkNull(logger, signature, roleRows, "Hours By Month Grid Rows");

            if (roleRows.isEmpty()) {
                throw Helper.logException(logger, signature, new IllegalArgumentException(
                        "Each 'Hours By Month Grid' should have at least one row."));
            }

            for (RoleHoursByMonth role : roleRows) {
                Helper.checkStrNullEmpty(logger, signature, role.getRole(), "Role");
                Collection<String> hours = role.getHours().values();
                for (String hour : hours) {
                    if (hour != null && hour.trim().length() > 0) {
                        Helper.checkNumeric(logger, signature, hour, "Hours");
                    }
                }
            }
        }
    }

    /**
     * Validates the VMWare assessment request data.
     *
     * @param assessment
     *         the VMWare assessment request data
     * @throws IllegalArgumentException
     *         if VMWare assessment request data is invalid
     * @since SRT Phase 3-1 - Implement VMWare Tab Assembly
     */
    private void validateVMWareAssessment(VMwareAssessment assessment) {
        final String signature = CLASSNAME + "#validateVMWareAssessment(VMWareAssessment assessment)";
        Logger logger = getLogger();

        Helper.checkNull(logger, signature, assessment, "VMWare Assessment data");

        if (assessment.getAssessmentType() == VMwareAssessmentType.CAPACITY_PLANNER) {
            if (assessment.getIncludeMultipleConfig() != null && assessment.getIncludeMultipleConfig()) {

                Helper.checkPositiveOrZero(logger, signature, assessment.getCapacityPlannerSitesNum(), false,
                        "# of VMware Capacity Planner sites?");
                Helper.checkPositiveOrZero(logger, signature, assessment.getCapacityPlannerCollectorsNum(), false,
                        "# of VMware Capacity Planner Data Manager Collectors?");
                Helper.checkPositiveOrZero(logger, signature, assessment.getDaysToCaptureCollectionData(), false,
                        "# of days to capture collection data for this engagement?");
                Helper.checkPositiveOrZero(logger, signature, assessment.getAdditionalServersNum(), false,
                        "# of additional servers to be analyzed beyond the initial 200?");
            }
        } else if (assessment.getAssessmentType() == VMwareAssessmentType.STORAGE_FOR_VCENTER
                || assessment.getAssessmentType() == VMwareAssessmentType.STORAGE_FOR_VSPHERE) {

            Helper.checkPositiveOrZero(logger, signature, assessment.getVsphereClustersNum(), false,
                    "# of VMware vSphere Clusters to be analyzed as part of this engagement?");
        }
    }

    /**
     * Validates the VMWare backup and recovery request data.
     *
     * @param backupRecovery
     *         the VMWare backup and recovery request data
     * @throws IllegalArgumentException
     *         if VMWare backup and recovery request data is invalid
     * @since SRT Phase 3-1 - Implement VMWare Tab Assembly
     */
    private void validateVMWareBackupRecovery(VMwareBackupRecovery backupRecovery) {
        final String signature = CLASSNAME + "#validateVMWareBackupRecovery(VMWareBackupRecovery backupRecovery)";
        Logger logger = getLogger();

        Helper.checkNull(logger, signature, backupRecovery, "VMWare Backup And Recovery data");

        Helper.checkPositiveOrZero(logger, signature, backupRecovery.getVirtualCenterInstallationsNum(), false,
                "# of existing VirtualCenter installations?");
        Helper.checkPositiveOrZero(logger, signature, backupRecovery.getEsxServersNum(), false,
                "# of existing ESX/ESXi Servers?");
        Helper.checkPositiveOrZero(logger, signature, backupRecovery.getVirtualHostsNum(), false,
                "# of existing VMware virtual hosts?");
        Helper.checkPositiveOrZero(logger, signature, backupRecovery.getAssessmentInterviewsNum(), false,
                "# of assessment interviews?");
    }

    /**
     * Validates the VMWare health checks request data.
     *
     * @param healthChecks
     *         the VMWare health checks request data
     * @throws IllegalArgumentException
     *         if VMWare health checks request data is invalid
     * @since SRT Phase 3-1 - Implement VMWare Tab Assembly
     */
    private void validateVMWareHealthChecks(VMwareHealthChecks healthChecks) {
        final String signature = CLASSNAME + "#validateVMWareHealthChecks(VMWareHealthChecks healthChecks)";
        Logger logger = getLogger();

        Helper.checkNull(logger, signature, healthChecks, "VMWare Health Checks data");

        Helper.checkPositiveOrZero(logger, signature, healthChecks.getAssessmentInterviewsNum(), false,
                "# of assessment interviews?");
        Helper.checkPositiveOrZero(logger, signature, healthChecks.getEsxServersNum(), false,
                "# of existing ESX/ESXi Servers?");
        Helper.checkPositiveOrZero(logger, signature, healthChecks.getVirtualHostsNum(), false,
                "# of existing VMware virtual hosts?");
    }

    /**
     * Validates the VMWare TCO assessment request data.
     *
     * @param tcoAssessment
     *         the VMWare TCO assessment request data
     * @throws IllegalArgumentException
     *         if VMWare TCO assessment request data is invalid
     * @since SRT Phase 3-1 - Implement VMWare Tab Assembly
     */
    private void validateVMWareTCOAssessment(VMwareTCOAssessment tcoAssessment) {
        final String signature = CLASSNAME + "#validateVMWareTCOAssessment(VMWareTCOAssessment tcoAssessment)";
        Logger logger = getLogger();

        Helper.checkNull(logger, signature, tcoAssessment, "VMWare TCO Assessment data");

        Helper.checkPositiveOrZero(logger, signature, tcoAssessment.getDataCenterLocationsNum(), false,
                "# of Data Center Locations under analysis?");
        Helper.checkPositiveOrZero(logger, signature, tcoAssessment.getConductedInterviewsNum(), false,
                "# of interviews to be conducted for engagement?");
    }

    /**
     * Validates the VMWare replication request data.
     *
     * @param replication
     *         the VMWare replication request data
     * @throws IllegalArgumentException
     *         if VMWare replication request data is invalid
     * @since SRT Phase 3-1 - Implement VMWare Tab Assembly
     */
    private void validateVMWareReplication(VMwareReplication replication) {
        final String signature = CLASSNAME + "#validateVMWareReplication(VMWareReplication replication)";
        Logger logger = getLogger();

        Helper.checkNull(logger, signature, replication, "VMWare Replication data");

        if (replication.getInstallSRM() != null && replication.getInstallSRM()) {
            Helper.checkPositiveOrZero(logger, signature, replication.getSrmAdoptersNum(), false,
                    "# of VMware SRM Site Recovery Adopters (SRAs)?");
            Helper.checkPositiveOrZero(logger, signature, replication.getSrmPlansNum(), false,
                    "# of VMware SRM Recovery Plans for Protection Groups?");
        }

        if (replication.isSymmetrixSRDF()) {
            Helper.checkPositiveOrZero(logger, signature, replication.getNewSymmetrixNum(), false,
                    "# of new Symmetrix using SRDF A/S in VMware SRM environment?");
            Helper.checkPositiveOrZero(logger, signature, replication.getExistingSymmetrixNum(), false,
                    "# of existing Symmetrix using SRDF A/S in VMware SRM environment?");
        }

        if (replication.isVnxBlock()) {
            Helper.checkPositiveOrZero(logger, signature, replication.getNewVNXBlockNum(), false,
                    "# of New VNX Block arrays Using Mirror View/S in VMware SRM environment?");
            Helper.checkPositiveOrZero(logger, signature, replication.getExistingVNXBlockNum(), false,
                    "# of Existing VNX Block Using Mirror View/S in VMware SRM environment?");
        }

        if (replication.isRecoverPoint()) {
            Helper.checkPositiveOrZero(logger, signature, replication.getNewRecoverPointClustersNum(), false,
                    "# of New RecoverPoint Clusters in VMware SRM environment?");
            Helper.checkPositiveOrZero(logger, signature, replication.getExistingRecoverPointClustersNum(), false,
                    "# of Existing RecoverPoint Clusters in VMware SRM environment?");
        }

        if (replication.isCelerraIP()) {
            Helper.checkPositiveOrZero(logger, signature, replication.getNewUnifiedFileServersNum(), false,
                    "# of New Unified File network servers using IP Replicator in a VMware SRM environment?");
            Helper.checkPositiveOrZero(logger, signature, replication.getExistingCelerraFileServersNum(), false,
                    "# of Existing Celerra File Servers using IP Replicator in VMware SRM environment?");
        }
    }

    /**
     * Validates the VMWare vblock request data.
     *
     * @param vblock
     *         the VMWare vblock request data
     * @throws IllegalArgumentException
     *         if VMWare vblock request data is invalid
     * @since SRT Phase 3-1 - Implement VMWare Tab Assembly
     */
    private void validateVMWareVblock(VMwareVblock vblock) {
        final String signature = CLASSNAME + "#validateVMWareVblock(VMWareVblock vblock)";
        Logger logger = getLogger();

        Helper.checkNull(logger, signature, vblock, "VMWare Vblock data");

        if (vblock.isDesignImpl()) {
            VMwareVblockDesignImpl designImpl = vblock.getVblockDesignImpl();

            Helper.checkNull(logger, signature, designImpl, "VMWare Vblock Design Implementation data");

            if (designImpl.getIncludePartnerLOE() != null && designImpl.getIncludePartnerLOE()) {
                if (designImpl.isCisco()) {
                    Helper.checkPositiveOrZero(logger, signature, designImpl.getCiscoPartnerHours(), 2, false,
                            "# of hours for Vblock Cisco partner");
                }
                if (designImpl.isVmware()) {
                    Helper.checkPositiveOrZero(logger, signature, designImpl.getVmwarePartnerHours(), 2, false,
                            "# of hours for Vblock VMware partner");
                }
            }

            if (designImpl.isType1()) {
                Helper.checkPositiveOrZero(logger, signature, designImpl.getType1VblocksNum(), false,
                        "# of Type 1 Vblocks (VNX Block)");
                Helper.checkPositiveOrZero(logger, signature, designImpl.getType1LUNsNum(), false,
                        "# of Type 1 LUNs (estimate)");
                Helper.checkPositiveOrZero(logger, signature, designImpl.getType1VsphereServersNum(), false,
                        "# of Type 1 Vsphere Servers");
            }

            if (designImpl.isType2()) {
                Helper.checkPositiveOrZero(logger, signature, designImpl.getType2VblocksNum(), false,
                        "# of Type 2 Vblocks (VNX Block)");
                Helper.checkPositiveOrZero(logger, signature, designImpl.getType2LUNsNum(), false,
                        "# of Type 2 LUNs (estimate)");
                Helper.checkPositiveOrZero(logger, signature, designImpl.getType2VsphereServersNum(), false,
                        "# of Type 2 Vsphere Servers");
            }

            if (designImpl.getIncludeUnifiedFileOptions() != null && designImpl.getIncludeUnifiedFileOptions()) {
                Helper.checkPositiveOrZero(logger, signature, designImpl.getUnifiedFileTypeVG2Num(), false,
                        "# of Unified File Type 1 (VG2)");
                Helper.checkPositiveOrZero(logger, signature, designImpl.getUnifiedFileTypeVG8Num(), false,
                        "# of Unified File Type 2 (VG8)");
            }
        }

        if (vblock.isInfraImpl()) {
            VMwareVblockInfraImpl infraImpl = vblock.getVblockInfraImpl();

            Helper.checkNull(logger, signature, infraImpl, "VMWare Vblock Infrastructure Implementation data");

            Helper.checkPositiveOrZero(logger, signature, infraImpl.getVblock300SeriesNum(), false,
                    "# of Vblock 300 Series to be installed");
            Helper.checkPositiveOrZero(logger, signature, infraImpl.getVblock700SeriesNum(), false,
                    "# of Vblock 700 Series to be installed");
        }

        if (vblock.isInfraTechAssessment()) {
            VMwareVblockInfraTechAssessment tech = vblock.getVblockInfraTechAssessment();

            Helper.checkNull(logger, signature, tech, "VMWare Vblock Infrastructure Technical Assessment data");

            Helper.checkPositiveOrZero(logger, signature, tech.getAssessedSitesNum(), false,
                    "# of sites to be Assessed");
            Helper.checkPositiveOrZero(logger, signature, tech.getIdentifiedServersNum(), false,
                    "# of Servers identified for VMWare consolidation");
        }
    }

    /**
     * Validates the VMWare converter request data.
     *
     * @param converter
     *         the VMWare converter request data
     * @throws IllegalArgumentException
     *         if VMWare converter request data is invalid
     * @since SRT Phase 3-1 - Implement VMWare Tab Assembly
     */
    private void validateVMWareConverter(VMwareConverter converter) {
        final String signature = CLASSNAME + "#validateVMWareConverter(VMWareConverter converter)";
        Logger logger = getLogger();

        Helper.checkNull(logger, signature, converter, "VMWare Converter data");

        Helper.checkPositiveOrZero(logger, signature, converter.getInstallsNum(), false,
                "# of VMware Converter Installs");
        Helper.checkPositiveOrZero(logger, signature, converter.getServersNum(), false,
                "# of Servers to P2V-V2V-B2V");

        Helper.checkPositiveOrZero(logger, signature, converter.getAdditionalHours(), 2, false,
                "# of additional hours needed for P2V, V2V and B2V (To be determined by Field)");
        Helper.checkPositiveOrZero(logger, signature, converter.getBillableHoursPerSTR(), 2, false,
                "# of billable hours per STR that an Implementation Specialist will monitor the"
                        + " replication or migration activity");
        Helper.checkPositiveOrZero(logger, signature, converter.getBillableHoursForTesting(), 2, false,
                "# of billable hours for additional testing to be done by an Implementation Specialist");
    }

    /**
     * Validates the VMWare SvMotion request data.
     *
     * @param svMotion
     *         the VMWare SvMotion request data
     * @throws IllegalArgumentException
     *         if VMWare SvMotion request data is invalid
     * @since SRT Phase 3-1 - Implement VMWare Tab Assembly
     */
    private void validateVMWareSvMotion(VMwareSvMotion svMotion) {
        final String signature = CLASSNAME + "#validateVMWareSvMotion(VMWareSvMotion svMotion)";
        Logger logger = getLogger();

        Helper.checkNull(logger, signature, svMotion, "VMWare SvMotion data");

        Helper.checkPositiveOrZero(logger, signature, svMotion.getVirtualMachinesNum(), false,
                "# of VMware Virtual Machines to Storage vMotion");

        Helper.checkPositiveOrZero(logger, signature, svMotion.getAdditionalHours(), 2, false,
                "# of additional hours needed for Storage vMotion (To be determined by Field)");
    }

    /**
     * Validates the VMWare view request data.
     *
     * @param view
     *         the VMWare view request data
     * @throws IllegalArgumentException
     *         if VMWare view request data is invalid
     * @since SRT Phase 3-1 - Implement VMWare Tab Assembly
     */
    private void validateVMWareView(VMwareView view) {
        final String signature = CLASSNAME + "#validateVMWareView(VMWareView view)";
        Logger logger = getLogger();

        Helper.checkNull(logger, signature, view, "VMWare View data");

        if (view.isDesign()) {
            VMwareViewDesign design = view.getViewDesign();
            Helper.checkNull(logger, signature, design, "VMWare View Design data");

            Helper.checkPositiveOrZero(logger, signature, design.getEsxServersNum(), false,
                    "# of existing ESX/ESXi Servers");
            Helper.checkPositiveOrZero(logger, signature, design.getVirtualCenterInstallationsNum(), false,
                    "# of existing VirtualCenter installations");
            Helper.checkPositiveOrZero(logger, signature, design.getAutomatedDesktopPoolsNum(), false,
                    "# of VMware View Automated Desktop Pools");
            Helper.checkPositiveOrZero(logger, signature, design.getManualDesktopPoolsNum(), false,
                    "# of VMware View Manual Desktop Pools");
            Helper.checkPositiveOrZero(logger, signature, design.getManagerConnectionServersNum(), false,
                    "# of VMware View Manager (Standard) Connection Servers");
            Helper.checkPositiveOrZero(logger, signature, design.getManagerReplicaServersNum(), false,
                    "# of VMware View Manager Replica Servers");
            Helper.checkPositiveOrZero(logger, signature, design.getManagerPodsNum(), false,
                    "# of VMware View Manager Pods");
            Helper.checkPositiveOrZero(logger, signature, design.getManagerPartitionsNum(), false,
                    "# of VMware View Manager Partitions");
            Helper.checkPositiveOrZero(logger, signature, design.getDesktopProfilesNum(), false,
                    "# of Desktop Profiles to Baseline and Document in the Configuration Guide");
            Helper.checkPositiveOrZero(logger, signature, design.getApplicationProfilesNum(), false,
                    "# of Application Profiles to Baseline and Document in the Configuration Guide");
            Helper.checkPositiveOrZero(logger, signature, design.getVirtualDesktopsPerESXHostNum(), false,
                    "# of VMware View Virtual Desktops Per ESX/ESXi Host");
            Helper.checkPositiveOrZero(logger, signature, design.getComposerInstancesNum(), false,
                    "# of VMware View Composer Instances");

            if (design.getIncludeMSSQL() != null && design.getIncludeMSSQL()) {
                Helper.checkPositiveOrZero(logger, signature, design.getSqlDatabasesNum(), false,
                        "# of Micrsoft SQL Databases to Configure");
            }
            if (design.getIncludeOracle() != null && design.getIncludeOracle()) {
                Helper.checkPositiveOrZero(logger, signature, design.getOracleDatabasesNum(), false,
                        "# of Oracle Databases to Configure");
            }
        }

        if (view.isImpl()) {
            VMwareViewImpl impl = view.getViewImpl();
            Helper.checkNull(logger, signature, impl, "VMWare View Implementation data");

            Helper.checkPositiveOrZero(logger, signature, impl.getManagerConnectionServersNum(), false,
                    "# of VMware View Manager (Standard) Connection Servers");
            Helper.checkPositiveOrZero(logger, signature, impl.getComposerInstancesNum(), false,
                    "# of VMware View Composer Instances");
            Helper.checkPositiveOrZero(logger, signature, impl.getVirtualCenterInstallationsNum(), false,
                    "# of existing VirtualCenter installations");
            Helper.checkPositiveOrZero(logger, signature, impl.getManagerReplicaServersNum(), false,
                    "# of VMware View Manager Replica Servers");
            Helper.checkPositiveOrZero(logger, signature, impl.getAutomatedDesktopPoolsNum(), false,
                    "# of VMware View Automated Desktop Pools");
            Helper.checkPositiveOrZero(logger, signature, impl.getManualDesktopPoolsNum(), false,
                    "# of VMware View Manual Desktop Pools");
            Helper.checkPositiveOrZero(logger, signature, impl.getEsxServersNum(), false,
                    "# of existing ESX/ESXi Servers");

            Helper.checkPositiveOrZero(logger, signature, impl.getBillableHoursForTesting(), 2, false,
                    "# of billable hours for additional testing to be done by an IS");

            if (impl.getIncludeMSSQL() != null && impl.getIncludeMSSQL()) {
                Helper.checkPositiveOrZero(logger, signature, impl.getSqlDatabasesNum(), false,
                        "# of Micrsoft SQL Databases to Configure");
            }
            if (impl.getIncludeOracle() != null && impl.getIncludeOracle()) {
                Helper.checkPositiveOrZero(logger, signature, impl.getOracleDatabasesNum(), false,
                        "# of Oracle Databases to Configure");
            }
        }
    }

    /**
     * Validates the VMWare virtual infrastructure request data.
     *
     * @param virtualInfra
     *         the VMWare virtual infrastructure request data
     * @throws IllegalArgumentException
     *         if VMWare virtual infrastructure request data is invalid
     * @since SRT Phase 3-1 - Implement VMWare Tab Assembly
     */
    private void validateVMWareVirtualInfra(VMwareVirtualInfra virtualInfra) {
        final String signature = CLASSNAME + "#validateVMWareVirtualInfra(VMWareVirtualInfra virtualInfra)";
        Logger logger = getLogger();

        Helper.checkNull(logger, signature, virtualInfra, "VMWare Virtual Infrastructure data");

        if (virtualInfra.isServerStorageDesignService()) {
            VMwareVirtualInfraServerStorageDesign ssd = virtualInfra.getServerStorageDesign();
            Helper.checkNull(logger, signature, ssd, "VMWare Design for Server and Storage Virtualization data");

            Helper.checkPositiveOrZero(logger, signature, ssd.getStorageConfigVarietiesNum(), false,
                    "# of storage configuration varieties for VMWare");
            Helper.checkPositiveOrZero(logger, signature, ssd.getEsxHostsNum(), false,
                    "# of ESX hosts proposed by CapacityPlanner");
            Helper.checkPositiveOrZero(logger, signature, ssd.getIdentifiedServersNum(), false,
                    "# of servers identified for VMWare consolidation");
        }

        if (virtualInfra.isInfraImplService()) {
            VMwareVirtualInfraImpl impl = virtualInfra.getInfraImpl();
            Helper.checkNull(logger, signature, impl, "VMWare Virtual Infrastructure Implementation data");

            Helper.checkIntegerInterval(logger, signature, impl.getVcenterServersNum(), 1, Integer.MAX_VALUE, false,
                    "# of VMware vCenter servers to install (minimum of one)");
            Helper.checkPositiveOrZero(logger, signature, impl.getEsxiServersNum(), false,
                    "# of VMware ESXi servers to install");
            Helper.checkPositiveOrZero(logger, signature, impl.getEsxiClustersNum(), false,
                    "# of VMware ESX/ESXi Clusters");
        }

        if (virtualInfra.isDesignImplJumpStartService()) {
            VMwareVirtualInfraDesignImplJumpStart jumpStart = virtualInfra.getDesignImplJumpStart();
            Helper.checkNull(logger, signature, jumpStart,
                    "VMWare Virtual Infrastructure Design and Implementation with Jumpstart Workshop data");

            Helper.checkIntegerInterval(logger, signature, jumpStart.getVcenterServersNum(), 1, Integer.MAX_VALUE,
                    false, "# of VMware vCenter servers to install (minimum of one)");
            Helper.checkIntegerInterval(logger, signature, jumpStart.getEsxClustersNum(), 2, Integer.MAX_VALUE, false,
                    "# of VMware ESX clusters to create (minimum of two)");
            Helper.checkIntegerInterval(logger, signature, jumpStart.getEsxServersNum(), 10, Integer.MAX_VALUE, false,
                    "# of VMware ESX servers to install (minimum of ten)");
            Helper.checkPositiveOrZero(logger, signature, jumpStart.getBillableHoursForTesting(), 2, false,
                    "# of billable hours for additional testing to be done by an IS");
        }

        if (virtualInfra.isDesignImplService()) {
            VMwareVirtualInfraDesignImpl designImpl = virtualInfra.getDesignImpl();
            Helper.checkNull(logger, signature, designImpl,
                    "VMWare Virtual Infrastructure Design and Implementation data");

            Helper.checkIntegerInterval(logger, signature, designImpl.getVcenterServersNum(), 1, Integer.MAX_VALUE,
                    false, "# of VMware vCenter servers to install (minimum of one)");
            Helper.checkIntegerInterval(logger, signature, designImpl.getEsxClustersNum(), 2, Integer.MAX_VALUE, false,
                    "# of VMware ESX clusters to create (minimum of two)");
            Helper.checkIntegerInterval(logger, signature, designImpl.getEsxServersNum(), 10, Integer.MAX_VALUE, false,
                    "# of VMware ESX servers to install (minimum of ten)");
        }
    }

    /**
     * Validates the VMWare VSphere request data.
     *
     * @param vsphere
     *         the VMWare VSphere request data
     * @throws IllegalArgumentException
     *         if VMWare VSphere request data is invalid
     * @since SRT Phase 3-1 - Implement VMWare Tab Assembly
     */
    private void validateVMWareVSphere(VMwareVSphere vsphere) {
        final String signature = CLASSNAME + "#validateVMWareVSphere(VMWareVSphere vsphere)";
        Logger logger = getLogger();

        Helper.checkNull(logger, signature, vsphere, "VMWare VSphere data");

        Helper.checkPositiveOrZero(logger, signature, vsphere.getBillableHoursForTesting(), 2, false,
                "# of billable hours for additional testing to be done by an IS");

        if (vsphere.getIncludeUpgrades() != null && vsphere.getIncludeUpgrades()) {
            Helper.checkPositiveOrZero(logger, signature, vsphere.getVcenterInstancesNum(), false,
                    "# of VMware vCenter 2.x Instances to Upgrade to vCenter 4.x");
            Helper.checkPositiveOrZero(logger, signature, vsphere.getEsxServersNum(), false,
                    "# of VMware ESX 3.x Servers to Upgrade to ESX 4.x Server");
        }

        if (vsphere.getIncludeJumpStartWorkshops() != null && vsphere.getIncludeJumpStartWorkshops()) {
            Helper.checkPositiveOrZero(logger, signature, vsphere.getJumpStartWorkshopsNum(), false,
                    "# of VMware vSphere \"JumpStart\" workshops to Deliver");
        }
    }

    /**
     * Validates the VMWare request data.
     *
     * @param vmwareRequestData
     *         the VMWare request data
     * @throws IllegalArgumentException
     *         if VMWare request data is invalid
     * @since SRT Phase 3-1 - Implement VMWare Tab Assembly
     */
    private void validateVMWare(VMwareRequestData vmwareRequestData) {
        final String signature = CLASSNAME + "#validateVMWare(VMWareRequestData vmwareRequestData)";
        Logger logger = getLogger();

        Helper.checkNull(logger, signature, vmwareRequestData, "VMWare Request Data");
        Helper.checkNull(logger, signature, vmwareRequestData.getServicesScope(), "VMWare Request Data services scope");

        if (vmwareRequestData.getServicesScope().isAssessment()) {
            validateVMWareAssessment(vmwareRequestData.getAssessment());
        }
        if (vmwareRequestData.getServicesScope().isBackupRecovery()) {
            validateVMWareBackupRecovery(vmwareRequestData.getBackupRecovery());
        }
        if (vmwareRequestData.getServicesScope().isHealthChecks()) {
            validateVMWareHealthChecks(vmwareRequestData.getHealthChecks());
        }
        if (vmwareRequestData.getServicesScope().isTcoAssessment()) {
            validateVMWareTCOAssessment(vmwareRequestData.getTcoAssessment());
        }
        if (vmwareRequestData.getServicesScope().isReplication()) {
            validateVMWareReplication(vmwareRequestData.getReplication());
        }
        if (vmwareRequestData.getServicesScope().isVceVblock()) {
            validateVMWareVblock(vmwareRequestData.getVceVblock());
        }
        if (vmwareRequestData.getServicesScope().isConverter()) {
            validateVMWareConverter(vmwareRequestData.getConverter());
        }
        if (vmwareRequestData.getServicesScope().isSvMotion()) {
            validateVMWareSvMotion(vmwareRequestData.getSvMotion());
        }
        if (vmwareRequestData.getServicesScope().isView()) {
            validateVMWareView(vmwareRequestData.getView());
        }
        if (vmwareRequestData.getServicesScope().isVirtualInfrastructure()) {
            validateVMWareVirtualInfra(vmwareRequestData.getVirtualInfrastructure());
        }
        if (vmwareRequestData.getServicesScope().isVsphere()) {
            validateVMWareVSphere(vmwareRequestData.getVsphere());
        }
    }

    /**
     * Validates the Avamar request data.
     *
     * @param avamar
     *         the Avamar request data
     * @throws IllegalArgumentException
     *         if Avamar request data is invalid
     * @since SRT Phase 3-5 - BRS Tabs Part 1 Assembly
     */
    private void validateAvamar(Avamar avamar) {
        final String signature = CLASSNAME + "#validateAvamar(Avamar avamar)";
        Logger logger = getLogger();
        Helper.checkNull(logger, signature, avamar, "Avamar");

        Helper.checkPositiveOrZero(logger, signature, avamar.getKnowledgeTransferHours(), 2, false,
                "# of Hours of Knowledge Transfer (Avamar)");

        String serverType = avamar.getServerType() == null ? "" : avamar.getServerType().getName();

        boolean notCapacityExpansion = "Avamar Single Node".equals(serverType)
                || "Avamar Multi-Node".equals(serverType)
                || "Avamar Virtual Edition".equals(serverType);

        // Avamar Design
        if (avamar.isDesignImplService() && avamar.isDesignDeliverOption()) {
            AvamarDesign design = avamar.getDesign();
            Helper.checkNull(logger, signature, design, "Avamar Design");

            Helper.checkPositiveOrZero(logger, signature, design.getServersNum(), false,
                    "# of Avamar Servers(Count one per AVE,Single Node and/or Grid)");

            if (notCapacityExpansion) {
                AvamarPlugins plugins = design.getPlugins();
                Helper.checkNull(logger, signature, plugins, "Avamar Design plugins");

                if (plugins.isExchange()) {
                    Helper.checkPositiveOrZero(logger, signature, plugins.getExchangePluginsNum(), false,
                            "# of Avamar Application Plug-ins for Microsoft Exchange");
                }
                if (plugins.isSqlServer()) {
                    Helper.checkPositiveOrZero(logger, signature, plugins.getSqlServerPluginsNum(), false,
                            "# of Avamar Application Plug-ins for Microsoft SQL Server");
                }
                if (plugins.isOracle()) {
                    Helper.checkPositiveOrZero(logger, signature, plugins.getOraclePluginsNum(), false,
                            "# of Avamar Application Plug-ins for Oracle");
                }
                if (plugins.isDb2()) {
                    Helper.checkPositiveOrZero(logger, signature, plugins.getDb2PluginsNum(), false,
                            "# of Avamar Application Plug-ins for DB2");
                }
                if (plugins.isSharepoint()) {
                    Helper.checkPositiveOrZero(logger, signature, plugins.getSharepointPluginsNum(), false,
                            "# of Avamar Application Plug-ins for Microsoft Sharepoint");
                }
                if (plugins.isLotusDomino()) {
                    Helper.checkPositiveOrZero(logger, signature, plugins.getLotusDominoPluginsNum(), false,
                            "# of Avamar Application Plug-ins for Lotus Domino");
                }

                AvamarOptions avaOpts = design.getOptions();
                Helper.checkNull(logger, signature, avaOpts, "Avamar Design options");

                if (avaOpts.isConfigureClients()) {
                    Helper.checkPositiveOrZero(logger, signature, design.getClientsNum(), false,
                            "# of Avamar clients in design");
                }
                if (avaOpts.isConfigureNDMP()) {
                    Helper.checkPositiveOrZero(logger, signature, design.getNdmpNodesNum(), false,
                            "# of Avamar NDMP Accelerator Nodes");
                    Helper.checkPositiveOrZero(logger, signature, design.getNdmpTargetsNum(), false,
                            "# of NDMP Targets for Backup");
                }
                if (avaOpts.isVmwareIntegeration()) {
                    Helper.checkPositiveOrZero(logger, signature, design.getEsxServersNum(), false,
                            "# of ESX Servers for Avamar Integration");
                    Helper.checkPositiveOrZero(logger, signature, design.getImageLevelBackupsNum(), false,
                            "# of Avamar Image Level Backups to Configure");
                }
            }

            if ("Avamar Capacity Expansion".equals(serverType)) {
                Helper.checkPositiveOrZero(logger, signature, design.getExpansionNodesNum(), false,
                        "# of Avamar Datastore Expansion Nodes");
            }
        }

        // Avamar Implementation
        if (avamar.isDesignImplService() && avamar.isImplementationDeliverOption()) {
            AvamarImplementation impl = avamar.getImplementation();
            Helper.checkNull(logger, signature, impl, "Avamar Implementation");

            Helper.checkPositiveOrZero(logger, signature, impl.getBillableHours(), 2, false,
                    "# of billable hours for additional testing to be done by an Implementation Specialist");
            Helper.checkPositiveOrZero(logger, signature, impl.getServersNum(), false,
                    "# of Avamar Servers(Count one per AVE,Single Node and/or Grid)");
            Helper.checkPositiveOrZero(logger, signature, impl.getDataNodesNum(), false,
                    "# of Avamar Data Nodes(Data Store)");
            Helper.checkPositiveOrZero(logger, signature, impl.getDataSetCreationHours(), 2, false,
                    "Estimate # of hours for DataSet creation (4 hours avg)");

            if (notCapacityExpansion) {
                AvamarOptions avaOpts = impl.getOptions();
                Helper.checkNull(logger, signature, avaOpts, "Avamar Implementation options");
                if (avaOpts.isConfigureClients()) {
                    Helper.checkPositiveOrZero(logger, signature, impl.getClientsNum(), false,
                            "# of Avamar clients in design");
                    Helper.checkPositiveOrZero(logger, signature, impl.getClientsPercent(), 2, false,
                            "% of Avamar Clients to implement");

                    AvamarPlugins plugins = impl.getPlugins();
                    Helper.checkNull(logger, signature, plugins, "Avamar Implementation plugins");

                    if (plugins.isExchange()) {
                        Helper.checkPositiveOrZero(logger, signature, plugins.getExchangePluginsNum(), false,
                                "# of Avamar Application Plug-ins for Microsoft Exchange");
                    }
                    if (plugins.isSqlServer()) {
                        Helper.checkPositiveOrZero(logger, signature, plugins.getSqlServerPluginsNum(), false,
                                "# of Avamar Application Plug-ins for Microsoft SQL Server");
                    }
                    if (plugins.isOracle()) {
                        Helper.checkPositiveOrZero(logger, signature, plugins.getOraclePluginsNum(), false,
                                "# of Avamar Application Plug-ins for Oracle");
                    }
                    if (plugins.isDb2()) {
                        Helper.checkPositiveOrZero(logger, signature, plugins.getDb2PluginsNum(), false,
                                "# of Avamar Application Plug-ins for DB2");
                    }
                    if (plugins.isSharepoint()) {
                        Helper.checkPositiveOrZero(logger, signature, plugins.getSharepointPluginsNum(), false,
                                "# of Avamar Application Plug-ins for Microsoft Sharepoint");
                    }
                    if (plugins.isLotusDomino()) {
                        Helper.checkPositiveOrZero(logger, signature, plugins.getLotusDominoPluginsNum(), false,
                                "# of Avamar Application Plug-ins for Lotus Domino");
                    }
                }

                if (avaOpts.isConfigureNDMP()) {
                    AvamarNDMP ndmp = impl.getNdmp();
                    Helper.checkNull(logger, signature, ndmp, "Avamar Implementation NDMP");

                    Helper.checkPositiveOrZero(logger, signature, ndmp.getNdmpNodesNum(), false,
                            "# of Avamar NDMP Accelerator Nodes");

                    if (ndmp.getIncludeMultistreamSupport() != null
                            && ndmp.getIncludeMultistreamSupport()) {
                        Helper.checkPositiveOrZero(logger, signature, ndmp.getStreamsPerNodeNum(), false,
                                "# of Streams per NDMP Node");
                    }

                    if (ndmp.isEmcCelerra()) {
                        Helper.checkPositiveOrZero(logger, signature, ndmp.getCelerraTargetsNum(), false,
                                "# of Celerra NDMP Targets for NDMP");
                    }
                    if (ndmp.isNetworkAppliance()) {
                        Helper.checkPositiveOrZero(logger, signature, ndmp.getNetAppFilerTargetsNum(), false,
                                "# of NetApp Filer NDMP Targets");
                    }
                    if (ndmp.isEmcIsilon()) {
                        Helper.checkPositiveOrZero(logger, signature, ndmp.getIsilonTargetsNum(), false,
                                "# of Isilon NDMP targets");
                    }
                    if (ndmp.isEmcVnx()) {
                        Helper.checkPositiveOrZero(logger, signature, ndmp.getVnxTargetsNum(), false,
                                "# of VNX/VNXe NDMP targets");
                    }

                    Helper.checkPositiveOrZero(logger, signature, ndmp.getDataSetCreationHours(), 2, false,
                            "# of hours for NDMP Data Set and Policy Creation(Default 4 Hrs)");
                }

                if (avaOpts.isConfigureReplication()) {
                    Helper.checkPositiveOrZero(logger, signature, impl.getReplicationSetsNum(), false,
                            "# of Avamar Replication Sets");
                }

                if (avaOpts.isVmwareIntegeration()) {
                    Helper.checkPositiveOrZero(logger, signature, impl.getEsxServersNum(), false,
                            "# of ESX Servers for Avamar Integration");
                    Helper.checkPositiveOrZero(logger, signature, impl.getProxiesNum(), false,
                            "# of Avamar VMware Proxies");
                    Helper.checkPositiveOrZero(logger, signature, impl.getImageLevelBackupsNum(), false,
                            "# of Avamar Image Level Backups to Configure");
                }

                if (avaOpts.isDataDomainIntegration()) {
                    Helper.checkPositiveOrZero(logger, signature, impl.getDataDomainServersNum(), false,
                            "# of Avamar Servers to configure for Data Domain");
                    Helper.checkPositiveOrZero(logger, signature, impl.getDdBoostPluginsNum(), false,
                            "# of Avamar Plug-ins configured with DDBoost");
                }
            }
        }

        // Avamar Design - Tape Out
        if (avamar.isTapeOutDesignImplService() && avamar.isDesignDeliverOption()) {
            AvamarTapeOutDesign design = avamar.getTapeOutDesign();
            Helper.checkNull(logger, signature, design, "Avamar Design - Tape Out");

            Helper.checkPositiveOrZero(logger, signature, design.getAdtControllersNum(), false,
                    "# of ADT Controllers");
            Helper.checkPositiveOrZero(logger, signature, design.getAdtDomainsNum(), false,
                    "# of Avamar Domains Needing Tuning and Reconfiguring for ADT Implementation");
            Helper.checkPositiveOrZero(logger, signature, design.getAdtClientsNum(), false,
                    "# of ADT Clients");
        }

        // Avamar Implementation - Tape Out
        if (avamar.isTapeOutDesignImplService() && avamar.isImplementationDeliverOption()) {
            AvamarTapeOutImplementation impl = avamar.getTapeOutImplementation();
            Helper.checkNull(logger, signature, impl, "Avamar Implementation - Tape Out");

            Helper.checkPositiveOrZero(logger, signature, impl.getGridsNum(), false,
                    "# of Avamar Grids");
            Helper.checkPositiveOrZero(logger, signature, impl.getArchiveServersNum(), false,
                    "# of Archive Servers");
            Helper.checkPositiveOrZero(logger, signature, impl.getEsxServersNum(), false,
                    "# of Existing ESX/ESXi Servers");
            Helper.checkPositiveOrZero(logger, signature, impl.getReplicationConnectionsNum(), false,
                    "# of Avamar Replication Connections");
            Helper.checkPositiveOrZero(logger, signature, impl.getAdtTransportNodesNum(), false,
                    "# of ADT Transport Nodes Needed to Support ADT Processing Requirements");
            Helper.checkPositiveOrZero(logger, signature, impl.getAdtControllersNum(), false,
                    "# of ADT Controllers");
        }

        // Operational Assurance
        if (avamar.isOperationalAssuranceService()) {
            AvamarOperationalAssurance assurance = avamar.getOperationalAssurance();
            Helper.checkNull(logger, signature, assurance, "Avamar Operational Assurance");

            Helper.checkPositiveOrZero(logger, signature, assurance.getGridsNum(), false,
                    "# of Avamar Grids");
            Helper.checkPositiveOrZero(logger, signature, assurance.getReplicationSitesNum(), false,
                    "# of Archive Replication Sites");
        }

        // Health Check
        if (avamar.isHealthCheckService()) {
            AvamarHealthCheck healthCheck = avamar.getHealthCheck();
            Helper.checkNull(logger, signature, healthCheck, "Avamar Health Check");

            Helper.checkPositiveOrZero(logger, signature, healthCheck.getGridsNum(), false,
                    "# of Avamar Grids");
            Helper.checkPositiveOrZero(logger, signature, healthCheck.getAssessmentInterviewsNum(), false,
                    "# of assessment interviews");
        }

        // Migration
        if (avamar.isMigrationService()) {
            AvamarMigration migration = avamar.getMigration();
            Helper.checkNull(logger, signature, migration, "Avamar Migration");

            Helper.checkPositiveOrZero(logger, signature, migration.getSourceSysNodesNum(), false,
                    "# of Source System Nodes");
            Helper.checkPositiveOrZero(logger, signature, migration.getTargetSysNodesNum(), false,
                    "# of Target System Nodes");
            Helper.checkPositiveOrZero(logger, signature, migration.getReplicationMonitoringEventsNum(), false,
                    "# of Replication Monitoring Events(1 Hour Per)");
            Helper.checkPositiveOrZero(logger, signature, migration.getReconfigureClientsNum(), false,
                    "# of Avamar Clients to Reconfigure");
        }

        // Avamar Integration Desktop Laptop Pilot and Workshop
        if (avamar.isIntegrationService()) {
            AvamarIntegration integration = avamar.getIntegration();
            Helper.checkNull(logger, signature, integration, "Avamar Integration Desktop Laptop Pilot and Workshop");

            Helper.checkPositiveOrZero(logger, signature, integration.getClientsNum(), false,
                    "# of Avamar Desktop / Laptop Clients");

            if (integration.getPilot() != null && integration.getPilot()) {
                Helper.checkPositiveOrZero(logger, signature, integration.getConfiguredClientsNum(), false,
                        "# of Clients to be Configured as part of the Avamar Desktop/Laptop Pilot Rollout");
            }

            Helper.checkPositiveOrZero(logger, signature, integration.getGridsNum(), false,
                    "# of Avamar Grids");
        }
    }

    /**
     * Validates the EDL request data.
     *
     * @param edl
     *         the EDL request data
     * @throws IllegalArgumentException
     *         if EDL request data is invalid
     * @since SRT Phase 3-5 - BRS Tabs Part 1 Assembly
     */
    private void validateEDL(EDL edl) {
        final String signature = CLASSNAME + "#validateEDL(EDL edl)";
        Logger logger = getLogger();
        Helper.checkNull(logger, signature, edl, "EDL");

        Helper.checkPositiveOrZero(logger, signature, edl.getKnowledgeTransferHours(), 2, false,
                "# of Hours of Knowledge Transfer (EDL)");

        if (edl.isDesign() || edl.isImplementation()) {
            EDLDesignImpl designImpl = edl.getDesignImpl();
            Helper.checkNull(logger, signature, designImpl, "EDL Design and Implementation");

            Helper.checkPositiveOrZero(logger, signature, designImpl.getBackendStorageArraysNum(), false,
                    "# of EMC Disk Library Backend Storage Arrays");
            Helper.checkPositiveOrZero(logger, signature, designImpl.getBackupServersNum(), false,
                    "# of Backup Servers (includes storage nodes / media servers)");
            Helper.checkPositiveOrZero(logger, signature, designImpl.getPhysicalTapeLibUnitsNum(), false,
                    "# of Physical Tape Library Units to Which EMC Disk Library Writes");
            Helper.checkPositiveOrZero(logger, signature, designImpl.getVirtualTapeLibrariesNum(), false,
                    "# of EMC Disk Library Virtual Tape Libraries (VTL)");
            Helper.checkPositiveOrZero(logger, signature, designImpl.getVirtualTapesNum(), false,
                    "# of EMC Disk Library Virtual Tapes");
            Helper.checkPositiveOrZero(logger, signature, designImpl.getVirtualTapeDrivesNum(), false,
                    "# of Virtual Tape Drives");

            if (designImpl.isReplication()) {
                Helper.checkPositiveOrZero(logger, signature, designImpl.getReplicationsCreatedNum(), false,
                        "# of EMC Disk Library Replications to Be Created");
            }
        }
    }

    /**
     * Validates the Vplex request data.
     *
     * @param vplex
     *         the Vplex request data
     * @throws IllegalArgumentException
     *         if Vplex request data is invalid
     * @since SRT Phase 3-5 - BRS Tabs Part 1 Assembly
     */
    private void validateVplex(Vplex vplex) {
        final String signature = CLASSNAME + "#validateVplex(Vplex vplex)";
        Logger logger = getLogger();
        Helper.checkNull(logger, signature, vplex, "Vplex");

        Helper.checkPositiveOrZero(logger, signature, vplex.getKnowledgeTransferHours(), 2, false,
                "# of Hours of Knowledge Transfer (Vplex)");
        Helper.checkPositiveOrZero(logger, signature, vplex.getSitesNumber(), false,
                "# of sites to install VPlex");
        Helper.checkPositiveOrZero(logger, signature, vplex.getEngineNumber(), false,
                "# of VPlex engines to install (total)");
        Helper.checkPositiveOrZero(logger, signature, vplex.getDirectorsNumber(), false,
                "# of VPlex directors to install (total)");
        Helper.checkPositiveOrZero(logger, signature, vplex.getExistingC4UpgradedNumber(), false,
                "# of existing CX4 arrays to be upgraded");
        Helper.checkPositiveOrZero(logger, signature, vplex.getVirtualVolumesNumber(), false,
                "# of VPlex Virtual Volumes");
        Helper.checkPositiveOrZero(logger, signature, vplex.getMirrorsNumber(), false,
                "# of VPlex Mirrors");
        Helper.checkPositiveOrZero(logger, signature, vplex.getMetroClustersNumber(), false,
                "# of VPlex MetroClusters to configure");
        Helper.checkPositiveOrZero(logger, signature, vplex.getGeoClustersNumber(), false,
                "# of VPlex GeoClusters to configure");
        Helper.checkPositiveOrZero(logger, signature, vplex.getHostsNumber(), false,
                "# of hosts using VPlex");
        Helper.checkPositiveOrZero(logger, signature, vplex.getArraysNumber(), false,
                "# of arrays attached to VPlex");
        Helper.checkPositiveOrZero(logger, signature, vplex.getStoragePortsNumber(), false,
                "# of storage ports dedicated to VPlex");
        Helper.checkPositiveOrZero(logger, signature, vplex.getStorageVolumesNumber(), false,
                "# of storage volumes imported into VPlex");
        Helper.checkPositiveOrZero(logger, signature, vplex.getWitnessServerNumber(), false,
                "# of VPlex Witness Servers");
        Helper.checkPositiveOrZero(logger, signature, vplex.getDataMobilityJobsNumber(), false,
                "# of data mobility jobs");
        Helper.checkPositiveOrZero(logger, signature, vplex.getEncapsulatedHostsNumber(), false,
                "# of hosts to have data encapsulated");
    }

    /**
     * Validates the RecoverPoint request data.
     *
     * @param rp
     *         the RecoverPoint request data
     * @throws IllegalArgumentException
     *         if RecoverPoint request data is invalid
     * @since SRT Phase 3-5 - BRS Tabs Part 1 Assembly
     */
    private void validateRecoverPoint(RecoverPoint rp) {
        final String signature = CLASSNAME + "#validateRecoverPoint(RecoverPoint rp)";
        Logger logger = getLogger();
        Helper.checkNull(logger, signature, rp, "Recover Point");
        
        if (rp.getInstallAndImplement()) {
            RecoverPointInstallationAndImplementation installImpl = rp.getInstallationAndImplementation();

            if (getBooleanValue(installImpl.getDeliveryOptionDesign()) ||
                getBooleanValue(installImpl.getDeliveryOptionImplementation())) {
                Helper.checkPositiveOrZero(logger, signature, installImpl.getNumberOfExistingPhysicalHosts(), false,
                    "# of Existing Physical Hosts?");
                Helper.checkPositiveOrZero(logger, signature, installImpl.getNumberOfExistingESXServers(), false,
                    "# of Existing ESX Servers (Not Virtual Machines)?");
                Helper.checkPositiveOrZero(logger, signature, installImpl.getNumberOfRPEnvironmentClientsServers(),
                    false, "# of client / servers / ESX servers in RP Environment?");
                Helper.checkPositiveOrZero(logger, signature, installImpl.getNumberOfRPAppliances(), false,
                    "# of RecoverPoint Appliances (Count each RPA Separately)?");
                Helper.checkPositiveOrZero(logger, signature, installImpl.getNumberOfStorageSystemsRequiringSplitter(),
                    false, "# of Storage Systems Requiring Splitter?");
            }

            if (installImpl.getNonEMCor3rdPartyStorageInvolved()) {
                Helper.checkPositiveOrZero(logger, signature, installImpl.getNumberOfNonEMCStorageArrays(), false,
                    "# of Non-EMC Storage Arrays?");
            }
            
            if (getBooleanValue(installImpl.getIncludeClusterEnabler())) {
                Helper.checkPositiveOrZero(logger, signature, installImpl.getNumberOfMicrosoftFailoverClusters(), false,
                    "# of Microsoft Clusters /Failover Cluster to be managed by CE?");
                Helper.checkPositiveOrZero(logger, signature, installImpl.getNumberOfRPCEClusterNodes(), false,
                    "# of RecoverPoint/CE Cluster Nodes?");
                Helper.checkPositiveOrZero(logger, signature, installImpl.getNumberOfRPConsistencyGroups(), false,
                    "# of RecoverPoint Consistency Groups to be Converted to CE Cluster Groups?");
            }
        }
        
        if (rp.getUpgradeRPAHardware()) {
            RPAHardwareUpgrade rpaHardwareUpgrade = rp.getRpaHardwareUpgrade();
            Helper.checkPositiveOrZero(logger, signature, rpaHardwareUpgrade.getNumberOfRPAsToUpgrade(), false,
                "# of RPAs to be Upgraded?");
        }
        
        if (rp.getMigrateIntelligentFabricSplitter()) {
            IntelligentFabricSplitterMigration migration = rp.getIntelligentFabricSplitterMigration();
            IntelligentFabricMigrationMethod intelligentFabricMigrationMethod 
                = migration.getIntelligentFabricMigrationMethod();

            if (intelligentFabricMigrationMethod != null) {
                if (intelligentFabricMigrationMethod.getId() == 1 || intelligentFabricMigrationMethod.getId() == 2) {
                    Helper.checkPositiveOrZero(logger, signature, migration.getNumberOfRPAClustersToMigrate(), false,
                        "# of RPA Clusters to be Migrated Off of IF splitters?");
                    Helper.checkPositiveOrZero(logger, signature, migration.getNumberOfRPAVolumesHostsToMigrate(),
                        false, "# of Hosts Using RPA Volumes to be Migrated Off of IF Splitters?");
                } else if (intelligentFabricMigrationMethod.getId() >= 3 
                    && intelligentFabricMigrationMethod.getId() <= 6) {
                    Helper.checkPositiveOrZero(logger, signature, migration.getNumberOfVPLEXClusters(), false,
                        "# of VPLEX Clusters?");
                    Helper.checkPositiveOrZero(logger, signature, migration.getNumberOfEncapsulatedVolumes(), false,
                        "# of Volumes to Encapsulate?");
                    Helper.checkPositiveOrZero(logger, signature,
                        migration.getNumberOfEncapsulationEventsPerEMCResource(), false,
                        "# of Encapsulation Events by a Single EMC Resource?");
                    
                    if (intelligentFabricMigrationMethod.getId() <= 4) {
                        Helper.checkPositiveOrZero(logger, signature, migration.getNumberOfHostVPLEXEncapsulations(),
                            false, "# of Hosts to be Encapsulated into VPLEX?");
                    }

                    Helper.checkPositiveOrZero(logger, signature, migration.getMaintenanceWindowsHours(), 2, false,
                        "# of Hours in Maintenance Windows?");
                    
                    Helper.checkPositiveOrZero(logger, signature, migration.getNumberOfRPEnvironmentClientsServers(),
                        false, "# of client / servers / ESX servers in RP Environment?");
                }
            }
        }
    }


    /**
     * Validates the DPA request data.
     *
     * @param dpa
     *         the DPA request data
     * @throws IllegalArgumentException
     *         if DPA request data is invalid
     * @since SRT Phase 3-5 - BRS Tabs Part 2 Assembly
     */
    private void validateDPA(DPA dpa) {
        final String signature = CLASSNAME + "#validateDPA(DPA dpa)";
        Logger logger = getLogger();
        Helper.checkNull(logger, signature, dpa, "DPA");

        Helper.checkPositiveOrZero(logger, signature, dpa.getKnowledgeTransferHours(), 2, false,
                "# of Hours of Knowledge Transfer (DPA)");

        if (dpa.isImplementService()) {
            if (dpa.isDesignActivity()) {
                DPADesign design = dpa.getDesign();
                Helper.checkNull(logger, signature, design, "DPA Design");

                Helper.checkPositiveOrZero(logger, signature, design.getCollectionNodesNum(), false,
                        "# of Data Protection Advisor Collection Nodes");
                Helper.checkPositiveOrZero(logger, signature, design.getCollectorNodesNum(), false,
                        "# of Data Protection Collector Nodes to Configure");
            }

            if (dpa.isImplementationActivity()) {
                DPAImplementation impl = dpa.getImplementation();
                Helper.checkNull(logger, signature, impl, "DPA Implementation");

                if (isBooleanTrue(impl.getUpgradeFromV5Environment())) {
                    validateDPAImplementationData(impl.getUpgradeData(), logger, signature);
                }

                if (isBooleanTrue(impl.getIncludeCustomReportDevelopment())) {
                    validateDPAImplementationData(impl.getCustomReportDevelopmentData(), logger, signature);
                }

                if (isBooleanTrue(impl.getIncludeInterfaceCustomization())) {
                    validateDPAImplementationData(impl.getInterfaceCustomizationData(), logger, signature);
                }

                if (isBooleanTrue(impl.getIncludeRecoverabilityAnalysis())) {
                    validateDPAImplementationData(impl.getRecoverabilityAnalysisData(), logger, signature);

                    if (isBooleanTrue(impl.getRecoverabilityAnalysisData().getIncludeEDLMonitoring())) {
                        Helper.checkPositiveOrZero(logger, signature, impl.getRecoverabilityAgentsNum(), false,
                                "# of Recoverability Agents");
                    }
                }

                if (isBooleanTrue(impl.getIncludeAnalysisJobs())) {
                    validateDPAImplementationData(impl.getAnalysisJobsData(), logger, signature);

                    if (isBooleanTrue(impl.getAnalysisJobsData().getIncludeEDLMonitoring())) {
                        Helper.checkPositiveOrZero(logger, signature, impl.getAnalysisJobsNum(), false,
                                "# of Data Protection Advisor Analysis Jobs (Estimated)");
                    }
                }
            }
        }

        if (dpa.isOperationalAssuranceService()) {
            DPAOperationalAssurance operAssurance = dpa.getOperationalAssurance();
            Helper.checkNull(logger, signature, operAssurance, "DPA Operational Assurance");

            Helper.checkPositiveOrZero(logger, signature, operAssurance.getAnalysisSiteImplementationsNum(),
                    false, "# of Data Protection Advisor Analysis Site Implementations");
        }

        if (dpa.isCustomizationService()) {
            DPACustomization customization = dpa.getCustomization();
            Helper.checkNull(logger, signature, customization, "DPA Customization");

            if (isBooleanTrue(customization.getIncludeThirdPartyIntegrationDevelopment())) {
                validateDPACustomizationData(customization.getThirdPartyIntegrationDevelopmentData(), logger,
                        signature);
            }

            if (isBooleanTrue(customization.getIncludeAnalysisJobs())) {
                validateDPACustomizationData(customization.getAnalysisJobsData(), logger, signature);
                Helper.checkPositiveOrZero(logger, signature, customization.getAnalysisJobsNum(), false,
                        "# of Data Protection Advisor Analysis Jobs (Estimated)");
            }

            if (isBooleanTrue(customization.getIncludeInterfaceCustomization())) {
                validateDPACustomizationData(customization.getInterfaceCustomizationData(), logger, signature);
            }

            if (isBooleanTrue(customization.getIncludeCustomReportDevelopment())) {
                validateDPACustomizationData(customization.getCustomReportDevelopmentData(), logger, signature);
            }
        }

        if (dpa.isUpgradeMigrationService()) {
            DPAUpgradeMigration upgradeMigration = dpa.getUpgradeMigration();
            Helper.checkNull(logger, signature, upgradeMigration, "DPA Upgrade And Migration");

            Helper.checkPositiveOrZero(logger, signature, upgradeMigration.getEstimatedMigrationVolumes(), false,
                    "Estimated Data Protection Advisor Migration Volumes in GB");
            Helper.checkPositiveOrZero(logger, signature, upgradeMigration.getReconfigureAgentsNum(), false,
                    "# of Data Protection Advisor Agents to Reconfigure");
        }

        if (dpa.isHealthCheckService()) {
            DPAHealthCheck healthCheck = dpa.getHealthCheck();
            Helper.checkNull(logger, signature, healthCheck, "DPA Health Check");

            Helper.checkPositiveOrZero(logger, signature, healthCheck.getSiteImplementationsNum(), false,
                    "# of Data Protection Advisor Site Implementations");
        }
    }

    /**
     * Validates the DPA implementation data.
     *
     * @param data
     *         the DPA implementation data
     * @param logger
     *         the logger
     * @param signature
     *         the signature
     * @throws IllegalArgumentException
     *         if DPA implementation data is invalid
     * @since SRT Phase 3-5 - BRS Tabs Part 2 Assembly
     */
    private void validateDPAImplementationData(DPAImplementationData data, Logger logger, String signature) {

        Helper.checkNull(logger, signature, data, "DPA implementation data");

        Helper.checkPositiveOrZero(logger, signature, data.getCollectionNodesNum(), false,
                "# of Data Protection Advisor Collection Nodes");
        Helper.checkPositiveOrZero(logger, signature, data.getCollectorNodesNum(), false,
            "# of Data Protection Collector Nodes to Configure");

        if (isBooleanTrue(data.getIncludeEDLMonitoring())) {
            Helper.checkPositiveOrZero(logger, signature, data.getEmcDiskLibrariesNum(), false,
                    "# of EMC Disk Libraries");
        }
    }

    /**
     * Validates the DPA customization data.
     *
     * @param data
     *         the DPA customization data
     * @param logger
     *         the logger
     * @param signature
     *         the signature
     * @throws IllegalArgumentException
     *         if DPA customization data is invalid
     * @since SRT Phase 3-5 - BRS Tabs Part 2 Assembly
     */
    private void validateDPACustomizationData(DPACustomizationData data, Logger logger, String signature) {

        Helper.checkNull(logger, signature, data, "DPA customization data");

        Helper.checkPositiveOrZero(logger, signature, data.getCollectionNodesNum(), false,
                "# of Data Protection Advisor Collection Nodes");
        Helper.checkPositiveOrZero(logger, signature, data.getCollectorNodesNum(), false,
                "# of Data Protection Collector Nodes to Configure");
    }

    /**
     * Validates the DataDomain request data.
     *
     * @param dataDomain
     *         the DataDomain request data
     * @throws IllegalArgumentException
     *         if DataDomain request data is invalid
     * @since SRT Phase 3-5 - BRS Tabs Part 2 Assembly
     */
    private void validateDataDomain(DataDomain dataDomain) {
        final String signature = CLASSNAME + "#validateDataDomain(DataDomain dataDomain)";
        Logger logger = getLogger();
        Helper.checkNull(logger, signature, dataDomain, "DataDomain");

        Helper.checkPositiveOrZero(logger, signature, dataDomain.getKnowledgeTransferHours(), 2, false,
                "# of Hours of Knowledge Transfer (DataDomain)");

        if (dataDomain.isImplementService()) {

            if (dataDomain.isDesignActivity()) {
                DataDomainDesign design = dataDomain.getDesign();
                Helper.checkNull(logger, signature, design, "Data Domain Design");

                if (design.getApplianceModels() != null) {
                    for (DataDomainDesignApplianceModel model : design.getApplianceModels().values()) {
                        Helper.checkPositiveOrZero(logger, signature, model.getAppliancesNum(), false,
                                model.getModelName() + " # of Appliances");
                    }
                }

                if (dataDomain.isImplementationActivity() && !dataDomain.getDesignImplementationIdentical()) {
                    validateDataDomainImplBase(signature, logger, design);
                }

            }

            if (dataDomain.isImplementationActivity()) {
                DataDomainImplementation impl = dataDomain.getImplementation();
                Helper.checkNull(logger, signature, impl, "Data Domain Implementation");

                if (impl.getApplianceModels() != null) {
                    for (DataDomainImplApplianceModel model : impl.getApplianceModels().values()) {
                        Helper.checkPositiveOrZero(logger, signature, model.getAppliancesNum(), false,
                                model.getModelName() + " # of Appliances");
                        Helper.checkPositiveOrZero(logger, signature, model.getExpansionShelvesNum(), false,
                                model.getModelName() + " # of Expansion Shelves");
                        String deviceType = lookupEntity2String(model.getDeviceType());
                        if ("Virtual Tape Library".equals(deviceType)) {
                            Helper.checkPositiveOrZero(logger, signature, model.getEdlVirtualTapeLibrariesNum(),
                                    false, model.getModelName() + " # of EDL Virtual Tape Libraries");
                        }
                        if ("DB Boost".equals(deviceType)) {
                            Helper.checkPositiveOrZero(logger, signature, model.getDdBoostServersNum(), false,
                                    model.getModelName() + " # of DD Boost Servers");
                        }
                    }
                }

                if (dataDomain.isDesignActivity() && !dataDomain.getDesignImplementationIdentical()) {
                    validateDataDomainImplBase(signature, logger, impl);
                }
            }
            
            if (dataDomain.isDesignActivity() && dataDomain.isImplementationActivity() 
                && dataDomain.getDesignImplementationIdentical()) {
                validateDataDomainImplBase(signature, logger, dataDomain.getDesignImplContent());
            }
        }

        if (dataDomain.isUpgradeService()) {
            DataDomainUpgrade upgrade = dataDomain.getUpgrade();
            Helper.checkNull(logger, signature, upgrade, "Data Domain Upgrade");

            String upgradeType = lookupEntity2String(upgrade.getUpgradeType());

            if ("Code Upgrade for DD".equals(upgradeType)) {
                Helper.checkPositiveOrZero(logger, signature, upgrade.getAppliancesNum(), false,
                        "# of Data Domain Appliances to Perform DD OS Upgrade");
            }

            if (upgrade.isDd890()) {
                Helper.checkPositiveOrZero(logger, signature, upgrade.getDd890AppliancesNum(), false,
                        "DD690,860,880 to DD890, # of Appliances");
            }
            if (upgrade.isDd990()) {
                Helper.checkPositiveOrZero(logger, signature, upgrade.getDd990AppliancesNum(), false,
                        "DD690,860,880,890 to DD990, # of Appliances");
            }
            if (upgrade.isDd4200()) {
                Helper.checkPositiveOrZero(logger, signature, upgrade.getDd4200AppliancesNum(), false,
                        "DD690,860,880,890 to DD4200, # of Appliances");
            }
            if (upgrade.isDd4500()) {
                Helper.checkPositiveOrZero(logger, signature, upgrade.getDd4500AppliancesNum(), false,
                        "DD690,860,880,890 to DD4500, # of Appliances");
            }
            if (upgrade.isDd7200()) {
                Helper.checkPositiveOrZero(logger, signature, upgrade.getDd7200AppliancesNum(), false,
                        "DD690,860,880,890 to DD7200, # of Appliances");
            }

            Helper.checkPositiveOrZero(logger, signature, upgrade.getStorageExpansionShelvesNum(), false,
                    "# of Data Domain Storage Expansion Shelves");
            Helper.checkPositiveOrZero(logger, signature, upgrade.getSystemControllerUpgradesNum(), false,
                    "# of Data Domain System Controller Upgrades");
        }

        if (dataDomain.isImplementVTLService()) {
            DataDomainVTL vtl = dataDomain.getVtl();
            Helper.checkNull(logger, signature, vtl, "Data Domain Implementation For Virtual Tape Library");

            if (isBooleanTrue(vtl.getIncludeIBMiseriesBRMS())) {
                Helper.checkPositiveOrZero(logger, signature, vtl.getIbmPARsNum(), false,
                        "# of IBM i PARs for Backup Configuration");
            }

            Helper.checkPositiveOrZero(logger, signature, vtl.getVtlAppliancesNum(), false,
                    "# of Data Domain Appliances for VTL");
            Helper.checkPositiveOrZero(logger, signature, vtl.getInstallFibreCardsNum(), false,
                    "# of Data Domain Fibre Cards to install");
            Helper.checkPositiveOrZero(logger, signature, vtl.getCreateVTLsNum(), false,
                    "# of Data Domain Emulated VTLs to Create");
        }

        if (dataDomain.isExpansionShelfService()) {
            DataDomainExpansionShelf expansionShelf = dataDomain.getExpansionShelf();
            Helper.checkNull(logger, signature, expansionShelf, "Data Domain Installation For Expansion Shelf");
            Helper.checkPositiveOrZero(logger, signature, expansionShelf.getStorageExpansionShelvesNum(), false,
                    "# of Data Domain Storage Expansion Shelves");
        }

        if (dataDomain.isDataStagingService()) {
            DataDomainDataStaging dataStaging = dataDomain.getDataStaging();
            Helper.checkNull(logger, signature, dataStaging, "Data Domain Data Staging And Relocation");
        }

        if (dataDomain.isIntegrationService()) {
            DataDomainIntegration integration = dataDomain.getIntegration();
            Helper.checkNull(logger, signature, integration, "Data Domain Integration");

            String integrationType = lookupEntity2String(integration.getIntegrationType());

            if ("DD Integration Workshop".equals(integrationType)) {
                Helper.checkPositiveOrZero(logger, signature, integration.getConductedInterviewsNum(), false,
                        "# of Interviews to be conducted");

                if (integration.isIbmTivoliStorageManager()) {
                    Helper.checkPositiveOrZero(logger, signature, integration.getIbmTSMInstancesNum(), false,
                            "# of IBM TSM Instances");
                }
                if (integration.isNetworker()) {
                    Helper.checkPositiveOrZero(logger, signature, integration.getNetworkerDataZonesNum(), false,
                            "# of Networker DataZones");
                }
                if (integration.isNetBackup()) {
                    Helper.checkPositiveOrZero(logger, signature, integration.getSymantecNetBackupDomainsNum(), false,
                            "# of Symantec NetBackup Domains");
                }
                if (integration.isRman()) {
                    Helper.checkPositiveOrZero(logger, signature, integration.getOracleDataServersNum(), false,
                            "# of Oracle Data Servers for RMAN");
                }
            } else if ("DD Integration with RMAN Scripting".equals(integrationType)) {
                Helper.checkPositiveOrZero(logger, signature, integration.getAppliancesForDDBoostNum(), false,
                        "# of Data Domain Appliances for DD Boost Implementation");
                Helper.checkPositiveOrZero(logger, signature, integration.getServersForDDBoostNum(), false,
                        "# of Servers for DD Boost Device Installation and Configuration");
                Helper.checkPositiveOrZero(logger, signature, integration.getOracleRMANBackupServersNum(), false,
                        "# of Oracle Database Servers for RMAN Backup");
                Helper.checkPositiveOrZero(logger, signature, integration.getOracleBackupConfigServersNum(), false,
                        "# of Oracle Databases for Backup Configuration");
            } else if ("DD Integration with SAP Hana Studio".equals(integrationType)) {
                Helper.checkPositiveOrZero(logger, signature, integration.getSapHanaDatabasesNum(), false,
                        "# of SAP Hana Databases Targeted for Backup");
            }
        }

        if (dataDomain.isHealthCheckService()) {
            DataDomainHealthCheck healthCheck = dataDomain.getHealthCheck();
            Helper.checkNull(logger, signature, healthCheck, "Data Domain Health Check");

            Helper.checkPositiveOrZero(logger, signature, healthCheck.getDataDomainAppliancesNum(), false,
                    "# of Data Domain Appliances");
            Helper.checkPositiveOrZero(logger, signature, healthCheck.getAssessmentInterviewsNum(), false,
                    "# of assessment interviews");
        }

        if (dataDomain.isMigrationService()) {
            DataDomainMigration migration = dataDomain.getMigration();
            Helper.checkNull(logger, signature, migration, "Data Domain Migration");

            String migrationType = lookupEntity2String(migration.getMigrationType());

            if ("Data Domain to Data Domain".equals(migrationType)
                    || "Centera to Data Domain using DixkXtender".equals(migrationType)) {

                Helper.checkPositiveOrZero(logger, signature, migration.getCentera2ddMigrationsNum(), false,
                        "# of Centera to Data Domain Migrations");

                if ("Data Domain to Data Domain".equals(migrationType)) {
                    Helper.checkPositiveOrZero(logger, signature, migration.getDd2ddMigrationsNum(), false,
                            "# of DD to DD Migrations");
                }

                Helper.checkPositiveOrZero(logger, signature, migration.getMonitoringEventsNum(), false,
                        "# of Data Migration Monitoring Events(1 hr.each)");
            }
        }

        if (dataDomain.isPreRackedService()) {
            DataDomainPreRack preRack = dataDomain.getPreRack();
            Helper.checkNull(logger, signature, preRack, "Data Domain Pre-Rack");

            DataDomainBoostBackupServer backupServer = preRack.getBoostBackupServer();

            Helper.checkPositiveOrZero(logger, signature, preRack.getPreRackedSystemRacksNum(), false,
                    "# of Pre-Racked System Racks");
            Helper.checkPositiveOrZero(logger, signature, preRack.getBackupServersNum(), false,
                    "# of backup servers (includes storage nodes / media servers)");
            Helper.checkPositiveOrZero(logger, signature, preRack.getOracleRMANBackupServersNum(), false,
                    "# of Oracle Database Servers for RMAN Backup");
            Helper.checkPositiveOrZero(logger, signature, preRack.getOracleBackupConfigServersNum(), false,
                    "# of Oracle Database Servers for Backup Configuration");

            if (isBooleanTrue(preRack.getIntegrateSapHana())) {
                Helper.checkPositiveOrZero(logger, signature, preRack.getSapHanaDatabasesNum(), false,
                        "# of SAP Hana Databases Targeted for Backup");
            }
            if (isBooleanTrue(preRack.getPlanDesignImplementVTL())) {
                Helper.checkPositiveOrZero(logger, signature, preRack.getEdlVirtualTapeLibrariesNum(), false,
                        "# of EDL Virtual Tape Libraries(VTL)");
            }

            Helper.checkPositiveOrZero(logger, signature, preRack.getServersForDDBoostNum(), false,
                    "# of Servers for DD Boost Device Installation and Config");

            if (backupServer != null && backupServer.isNbu()) {
                Helper.checkPositiveOrZero(logger, signature, preRack.getAppliancesForDDBoostNum(), false,
                        "# of Data Domain Appliances for DD Boost Implementation");
            }
            if (isBooleanTrue(preRack.getPlanDesignImplementVTL())) {
                Helper.checkPositiveOrZero(logger, signature, preRack.getVtlAppliancesNum(), false,
                        "# of Data Domain Appliances");
                Helper.checkPositiveOrZero(logger, signature, preRack.getInstallFibreCardsNum(), false,
                        "# of Data Domain Fibre Cards to Install");
                Helper.checkPositiveOrZero(logger, signature, preRack.getCreateVTLsNum(), false,
                        "# of Data Domain VTLs to Create");
            }
            if (isBooleanTrue(preRack.getIncludeIBMiseriesBRMS())) {
                Helper.checkPositiveOrZero(logger, signature, preRack.getIbmPARsNum(), false,
                        "# of IBM i LPARS for Backup Configuration");
            }
        }

        if (dataDomain.isBoostService()) {
            DataDomainBoost boost = dataDomain.getBoost();
            Helper.checkNull(logger, signature, boost, "Data Domain Boost");

            String boostType = lookupEntity2String(boost.getBoostType());

            if ("DD Boost with NBU".equals(boostType) || "DD Boost with RMAN".equals(boostType)) {
                Helper.checkPositiveOrZero(logger, signature, boost.getAppliancesForDDBoostNum(), false,
                        "# of Data Domain Appliances for DD Boost Implementation");
                Helper.checkPositiveOrZero(logger, signature, boost.getServersForDDBoostNum(), false,
                        "# of servers for DD Boost device installation and configure");
            }

            if ("DD Boost with RMAN".equals(boostType)) {
                Helper.checkPositiveOrZero(logger, signature, boost.getOracleRMANBackupServersNum(), false,
                        "# of Oracle Database Servers for RMAN Backup");
                Helper.checkPositiveOrZero(logger, signature, boost.getOracleBackupConfigServersNum(), false,
                        "# of Oracle databases for Backup Configuration");
            }
        }

        if (dataDomain.isExtendedRetentionConversionService()) {
            DataDomainExtendedRetentionConversion conversion = dataDomain.getExtendedRetentionConversion();
            Helper.checkNull(logger, signature, conversion, "Data Domain Extended Retention Conversion");
            Helper.checkPositiveOrZero(logger, signature, conversion.getApplicancesToConvertNum(), false,
                    "# of Data Domain Appliances to convert to Extended Retention");
        }

        if (dataDomain.isManagementCenterConfigService()) {
            DataDomainManagementCenterConfig config = dataDomain.getManagementCenterConfig();
            Helper.checkNull(logger, signature, config, "Data Domain Management Center Config");
        }

        if (dataDomain.isSapHanaService()) {
            DataDomainSapHana sapHana = dataDomain.getSapHana();
            Helper.checkNull(logger, signature, sapHana, "Data Domain Management SAP Hana Studio Integration");
            Helper.checkPositiveOrZero(logger, signature, sapHana.getSapHanaDatabasesNum(), false,
                    "# of SAP Hana Databases Targeted for Backup");
        }
    }

    private void validateDataDomainImplBase(String signature, Logger logger, DataDomainImplBase data) {
        DataDomainBoostBackupServer backupServer = data.getBoostBackupServer();

        if (isBooleanTrue(data.getPlanDesignImplementVTL())) {
            Helper.checkPositiveOrZero(logger, signature, data.getVtlAppliancesNum(), false,
                "# of Data Domain Appliances for VTL");
            Helper.checkPositiveOrZero(logger, signature, data.getInstallFibreCardsNum(), false,
                "# of Data Domain Fibre Cards to install");
            Helper.checkPositiveOrZero(logger, signature, data.getCreateVTLsNum(), false,
                "# of Data Domain Emulated VTLs to Create");
            if (isBooleanTrue(data.getIncludeIBMiseriesBRMS())) {
                Helper.checkPositiveOrZero(logger, signature, data.getIbmPARsNum(), false,
                    "# of IBM i PARs for Backup Configuration");
            }
        }

        if (backupServer != null && backupServer.isNbu()) {
            Helper.checkPositiveOrZero(logger, signature, data.getBackupServersNum(), false,
                "# of backup servers(includes storage nodes/media servers)");
            Helper.checkPositiveOrZero(logger, signature, data.getAppliancesForDDBoostNum(), false,
                "# of DD Appliances for DD Boost Implementation");
        }

        if (backupServer != null && backupServer.isRman()) {
            Helper.checkPositiveOrZero(logger, signature, data.getOracleRMANBackupServersNum(), false,
                "# of Oracle Database Servers for RMAN Backup");
            Helper.checkPositiveOrZero(logger, signature, data.getOracleBackupConfigServersNum(), false,
                "# of Oracle Database Servers for Backup Configuration");
        }

        if (isBooleanTrue(data.getIntegrateSapHana())) {
            Helper.checkPositiveOrZero(logger, signature, data.getSapHanaDatabasesNum(), false,
                "# of SAP Hana Database Targeted for Backup");
        }
    }

    /**
     * Validates the NetworkerStorageNodes request data.
     *
     * @param storageNodes
     *         the NetworkerStorageNodes request data
     * @throws IllegalArgumentException
     *         if NetworkerStorageNodes request data is invalid
     * @since SRT Phase 3-5 - BRS Tabs Part 3 Assembly
     */
    private void validateNetworkerStorageNodes(NetworkerStorageNodes storageNodes) {
        final String signature = CLASSNAME + "#validateNetworkerStorageNodes(NetworkerStorageNodes storageNodes)";
        Logger logger = getLogger();
        Helper.checkNull(logger, signature, storageNodes, "NetworkerStorageNodes");
        if (storageNodes.isStorageNode()) {
            Helper.checkPositiveOrZero(logger, signature, storageNodes.getStorageNodesNum(), false,
                    "# of Networker Storage Nodes");
        }
        if (storageNodes.isDedicatedStorageNode()) {
            Helper.checkPositiveOrZero(logger, signature, storageNodes.getDedicatedStorageNodesNum(), false,
                    "# of Networker Dedicated Storage Nodes");
        }
        if (storageNodes.isDeDuplicationNode()) {
            Helper.checkPositiveOrZero(logger, signature, storageNodes.getDeDuplicationNodesNum(), false,
                    "# of Networker De-Duplication Nodes");
        }
    }

    /**
     * Validates the NetworkerMediaDevices request data.
     *
     * @param mediaDevices
     *         the NetworkerMediaDevices request data
     * @throws IllegalArgumentException
     *         if NetworkerMediaDevices request data is invalid
     * @since SRT Phase 3-5 - BRS Tabs Part 3 Assembly
     */
    private void validateNetworkerMediaDevices(NetworkerMediaDevices mediaDevices) {
        final String signature = CLASSNAME + "#validateNetworkerMediaDevices(NetworkerMediaDevices mediaDevices)";
        Logger logger = getLogger();
        Helper.checkNull(logger, signature, mediaDevices, "NetworkerMediaDevices");
        if (mediaDevices.isAutoChanger()) {
            Helper.checkPositiveOrZero(logger, signature, mediaDevices.getAutoChangersNum(), false,
                    "# of Networker Auto Changers");
        }
        if (mediaDevices.isTapeDevice()) {
            Helper.checkPositiveOrZero(logger, signature, mediaDevices.getTapeDevicesNum(), false,
                    "# of Networker Tape Devices");
        }
        if (mediaDevices.isAdvancedFileTypeDevice()) {
            Helper.checkPositiveOrZero(logger, signature, mediaDevices.getAdvancedFileTypeDevicesNum(), false,
                    "# of Networker Advanced File Type Devices");
        }
        if (mediaDevices.isDdBoost()) {
            Helper.checkPositiveOrZero(logger, signature, mediaDevices.getDdBoostDevicesNum(), false,
                    "# of Networker DD Boost Devices");
        }
        if (mediaDevices.isAtmos()) {
            Helper.checkPositiveOrZero(logger, signature, mediaDevices.getAtmosDevicesNum(), false,
                    "# of Networker ATMOS Devices");
        }
    }

    /**
     * Validates the Networker request data.
     *
     * @param networker
     *         the Networker request data
     * @throws IllegalArgumentException
     *         if Networker request data is invalid
     * @since SRT Phase 3-5 - BRS Tabs Part 3 Assembly
     */
    private void validateNetworker(Networker networker) {
        final String signature = CLASSNAME + "#validateNetworker(Networker networker)";
        Logger logger = getLogger();
        Helper.checkNull(logger, signature, networker, "Networker");

        Helper.checkPositiveOrZero(logger, signature, networker.getKnowledgeTransferHours(), 2, false,
                "# of Hours of Knowledge Transfer (Networker)");

        if (networker.isImplementationService() || networker.isUpgradePlanningService()) {

            if (networker.isDesignActivity()) {
                NetworkerDesign design = networker.getDesign();
                Helper.checkNull(logger, signature, design, "NetworkerDesign");
                NetworkerComponents components = design.getComponents();
                Helper.checkNull(logger, signature, components, "NetworkerComponents");

                if (components.isServer() || components.isStorageNodes()) {
                    NetworkerServerDesign server = design.getServer();
                    Helper.checkNull(logger, signature, server, "NetworkerServerDesign");

                    Helper.checkPositiveOrZero(logger, signature, server.getServersNum(), false,
                            "# of Networker Servers");
                }

                if (components.isStorageNodes()) {
                    validateNetworkerStorageNodes(design.getStorageNodes());
                }

                if (components.isMediaDevices()) {
                    validateNetworkerMediaDevices(design.getMediaDevices());
                }

                if (components.isAdvancedBackupTech()) {
                    NetworkerAdvancedBackupTechDesign advancedBackup = design.getAdvancedBackupTech();
                    Helper.checkNull(logger, signature, advancedBackup, "NetworkerAdvancedBackupTechDesign");

                    if (advancedBackup.isVmware()) {
                        Boolean includeVmwareProtectionBackups = advancedBackup.getIncludeVmwareProtectionBackups();

                        if (isBooleanFalse(includeVmwareProtectionBackups)) {
                            Helper.checkPositiveOrZero(logger, signature,
                                    advancedBackup.getVmwareVsphereHostsNum(), false, "# of VMWare vSphere Hosts");
                        }
                        if (isBooleanTrue(includeVmwareProtectionBackups)) {
                            Helper.checkPositiveOrZero(logger, signature,
                                    advancedBackup.getVmwareBackupAppliancesNum(), false,
                                    "# of VMWare Backup Appliances");
                        }
                    }

                    if (advancedBackup.isSnapshotManagement()) {
                        Helper.checkPositiveOrZero(logger, signature,
                                advancedBackup.getSnapshotManagementAppHostsNum(), false,
                                "# of Networker Snapshot Management Application Hosts");
                        Helper.checkPositiveOrZero(logger, signature,
                                advancedBackup.getSnapshotManagementMountHostsNum(), false,
                                "# of Networker Snapshot Management Mount Hosts");
                    }

                    if (advancedBackup.isNas()) {
                        Helper.checkPositiveOrZero(logger, signature,
                                advancedBackup.getNasDataMoversNum(), false,
                                "# of NAS DataMovers to be Backed Up via NDMP");
                    }
                }

                if (components.isFileSystemClientBackups()) {
                    NetworkerFileSystemClientBackupsDesign fileSystemClientBackups = design
                            .getFileSystemClientBackups();
                    Helper.checkNull(logger, signature, fileSystemClientBackups,
                            "NetworkerFileSystemClientBackupsDesign");

                    Helper.checkPositiveOrZero(logger, signature,
                            fileSystemClientBackups.getClientsNum(), false,
                            "# of Networker Clients (Windows / Unix / Linux)");
                    Helper.checkPositiveOrZero(logger, signature,
                            fileSystemClientBackups.getClusterClientConnectionsNum(), false,
                            "# of Networker Cluster Client Connections");
                }

                if (components.isApplicationBackups()) {
                    NetworkerApplicationBackupsDesign applicationBackup = design.getApplicationBackups();
                    Helper.checkNull(logger, signature, applicationBackup,
                            "NetworkerApplicationBackupsDesign");

                    if (applicationBackup.isMsSql()) {
                        Helper.checkPositiveOrZero(logger, signature,
                                applicationBackup.getMsSqlServersNum(), false,
                                "# of Microsoft SQL Servers");
                        Helper.checkPositiveOrZero(logger, signature,
                                applicationBackup.getMsSqlDatabasesNum(), false,
                                "# of SQL Databases");
                    }

                    if (applicationBackup.isExchange()) {
                        Helper.checkPositiveOrZero(logger, signature,
                                applicationBackup.getExchangeMailboxServersNum(), false,
                                "# of Microsoft Exchange Mailbox Servers");
                        Helper.checkPositiveOrZero(logger, signature,
                                applicationBackup.getExchangeDatabaseStoresNum(), false,
                                "# of Microsoft Exchange Database Stores");
                    }

                    if (applicationBackup.isSharePoint()) {
                        Helper.checkPositiveOrZero(logger, signature,
                                applicationBackup.getSharePointMSSqlServersNum(), false,
                                "# of Microsoft SQL Servers");
                        Helper.checkPositiveOrZero(logger, signature,
                                applicationBackup.getSharePointSqlDatabasesNum(), false,
                                "# of SQL Databases");
                        Helper.checkPositiveOrZero(logger, signature,
                                applicationBackup.getSharePointFarmsNum(), false,
                                "# of SharePoint Farms");
                        Helper.checkPositiveOrZero(logger, signature,
                                applicationBackup.getSharePointWebAppsNum(), false,
                                "# of SharePoint Web Applications");
                        Helper.checkPositiveOrZero(logger, signature,
                                applicationBackup.getSharePointSitesNum(), false,
                                "# of SharePoint Sites");
                        Helper.checkPositiveOrZero(logger, signature,
                                applicationBackup.getSharePointSubSitesNum(), false,
                                "# of SharePoint Sub-Sites");
                    }

                    if (applicationBackup.isHyperv()) {
                        Helper.checkPositiveOrZero(logger, signature,
                                applicationBackup.getHypervServersNum(), false,
                                "# of Microsoft Hyper-V Servers to be Backed Up with NMM");
                    }

                    if (applicationBackup.isOracle()) {
                        Helper.checkPositiveOrZero(logger, signature,
                                applicationBackup.getOracleRMANBackupServersNum(), false,
                                "# of Oracle Database Servers for RMAN Backup");
                        Helper.checkPositiveOrZero(logger, signature,
                                applicationBackup.getOracleBackupConfigDatabasesNum(), false,
                                "# of Oracle Databases for Backup Configuration");
                    }

                    if (applicationBackup.isMySql()) {
                        Helper.checkPositiveOrZero(logger, signature,
                                applicationBackup.getMySqlServersNum(), false,
                                "# of MySQL Servers");
                    }

                    if (applicationBackup.isLotusNotes()) {
                        Helper.checkPositiveOrZero(logger, signature,
                                applicationBackup.getLotusDominoInstancesNum(), false,
                                "# of IBM Lotus Domino Instances");
                    }

                    if (applicationBackup.isSap()) {
                        Helper.checkPositiveOrZero(logger, signature,
                                applicationBackup.getSapAppServersNum(), false,
                                "# of SAP Applicaiton Servers");
                    }

                    if (applicationBackup.isMeditech()) {
                        Helper.checkPositiveOrZero(logger, signature, applicationBackup.getNumberOfMeditechHosts(),
                            false, "# of Meditech Hosts?");
                        Helper.checkPositiveOrZero(logger, signature,
                            applicationBackup.getNumberOfMeditechStorageArrays(), false,
                            "# of Storage Arrays in the Meditech Environment?");
                    }
                }
            }

            if (networker.isImplementationActivity()) {
                NetworkerImplementation impl = networker.getImplementation();
                Helper.checkNull(logger, signature, impl, "NetworkerImplementation");
                if (impl.getSelectDataZoneSize() != null && impl.getSelectDataZoneSize()) {
                    Helper.checkNull(logger, signature, impl.getDataZoneSize(), "Networker DataZone Size");
                }
            }
        }

        if (networker.isUpgradeService()) {
            NetworkerUpgrade upgrade = networker.getUpgrade();
            Helper.checkNull(logger, signature, upgrade, "NetworkerUpgrade");
            if (upgrade.isServer()) {
                Helper.checkPositiveOrZero(logger, signature,
                        upgrade.getServersNum(), false,
                        "# of Networker Servers to Be Upgraded");
            }

            if (upgrade.isStorageNodes()) {
                Helper.checkPositiveOrZero(logger, signature,
                        upgrade.getStorageNodesNum(), false,
                        "# of Networker Storage Nodes to Be Upgraded");
            }

            if (upgrade.isClients()) {
                Helper.checkPositiveOrZero(logger, signature,
                        upgrade.getClientsNum(), false,
                        "# of Networker Clients to Be Upgraded");
            }

            if (upgrade.isManagementConsole()) {
                Helper.checkPositiveOrZero(logger, signature,
                        upgrade.getManagementConsolesNum(), false,
                        "# of Networker Management Consoles to Be Upgraded");
            }
        }
        
        if (networker.isHealthCheckService()) {
            NetworkerHealthcheck healthcheck = networker.getHealthcheck();
            Helper.checkNull(logger, signature, healthcheck, "NetworkerHealthcheck");

            Helper.checkPositiveOrZero(logger, signature, healthcheck.getNumberOfNetworkerDatazones(), false,
                "# of Networker Datazones?");
            Helper.checkPositiveOrZero(logger, signature, healthcheck.getNumberOfAssessmentInterviews(), false,
                "# of Assessment Interviews?");

        }
    }

    /**
     * Validates the DPAD request data.
     *
     * @param dpadRequestData
     *         the DPAD request data
     * @throws IllegalArgumentException
     *         if DPAD request data is invalid
     * @since SRT Phase 3-5 - BRS Tabs Part 1 Assembly
     */
    private void validateDPAD(DPADRequestData dpadRequestData) {
        final String signature = CLASSNAME + "#validateDPAD(DPADRequestData dpadRequestData)";
        Logger logger = getLogger();
        Helper.checkNull(logger, signature, dpadRequestData, "DPAD Request Data");

        Helper.checkSitesInvolved(logger, signature, dpadRequestData.getSitesInvolved(), false, "# of sites involved?");

        DPADServicesScope servicesScope = dpadRequestData.getServicesScope();
        Helper.checkNull(logger, signature, servicesScope, "DPAD services scope");

        if (servicesScope.isAvamar()) {
            validateAvamar(dpadRequestData.getAvamar());
        }

        if (servicesScope.isDataDomain()) {
            validateDataDomain(dpadRequestData.getDataDomain());
        }

        if (servicesScope.isEdl()) {
            validateEDL(dpadRequestData.getEdl());
        }

        if (servicesScope.isDpa()) {
            validateDPA(dpadRequestData.getDpa());
        }

        if (servicesScope.isNetworker()) {
            validateNetworker(dpadRequestData.getNetworker());
        }

        if (servicesScope.isRecoverPoint()) {
            validateRecoverPoint(dpadRequestData.getRecoverPoint());
        }

        if (servicesScope.isMozy()) {
            validateMozy(dpadRequestData.getMozy());
        }
    }

    /**
     * <p>Validates the Mozy request data.</p>
     *
     * @param mozy
     *         a <code>Mozy</code> object providing the data to be validated.
     * @since 3.2
     */
    private void validateMozy(Mozy mozy) {
        final String signature = CLASSNAME + "#validateMozy(Mozy mozy)";
        Logger logger = getLogger();
        Helper.checkNull(logger, signature, mozy, "Mozy Reuqest Data");

        if (mozy.getMozyCustom()) {
            MozyCustom custom = mozy.getCustom();
            Helper.checkNull(logger, signature, custom, "MozyCustom");
            if (custom.getAccountSetupAndStructureConfiguration() || custom.getBranding() || custom.getApiWorkshop()
                    || custom.getFederatedIDConfiguration()) {
                Helper.checkPositiveOrZero(logger, signature, custom.getHoursForAPIWorkshopPlanning(), 2, false,
                        "# of hours for API Workshop Planning");
            }
            if (custom.getDevelopBetaPlanAndAssistWithRollout()) {
                Helper.checkPositiveOrZero(logger, signature, custom.getHoursForAPIWorkshopPlanning(), 2, false,
                        "# of Hours to assist with Pilot Roll-Out");
            }
            if (custom.getAdministrationTraining()) {
                Helper.checkPositiveOrZero(logger, signature, custom.getHoursForAPIWorkshopPlanning(), 2, false,
                        "# of Hours for Mozy Administration Training");
            }
            if (custom.getBranding()) {
                Helper.checkPositiveOrZero(logger, signature, custom.getHoursForAPIWorkshopPlanning(), 2, false,
                        "# of hours for Client Branding");
                Helper.checkPositiveOrZero(logger, signature, custom.getHoursForAPIWorkshopPlanning(), 2, false,
                        "# of hours for Branding Admin Console");
                Helper.checkPositiveOrZero(logger, signature, custom.getHoursForAPIWorkshopPlanning(), 2, false,
                        "# of Hours for Web Access Branding");
            }
            if (custom.getApiWorkshop()) {
                Helper.checkPositiveOrZero(logger, signature, custom.getHoursForAPIWorkshopPlanning(), 2, false,
                        "# of Hours for Mozy API Workshop");
            }
            if (custom.getL1SupportTraining()) {
                Helper.checkPositiveOrZero(logger, signature, custom.getHoursForAPIWorkshopPlanning(), 2, false,
                        "# of L1 Support Training Hours");
            }
        }

        if (mozy.getMozyOEMBranding()) {
            MozyOEMBranding oemBranding = mozy.getOemBranding();
            Helper.checkNull(logger, signature, oemBranding, "MozyOEMBranding");
            Helper.checkPositiveOrZero(logger, signature, oemBranding.getHoursForClientBranding(), 2, false,
                    "# of hours for Client Branding");
            Helper.checkPositiveOrZero(logger, signature, oemBranding.getHoursForBrandingAdminConsole(), 2, false,
                    "# of Hours for Branding Admin Console");
            Helper.checkPositiveOrZero(logger, signature, oemBranding.getHoursForWebAccessBranding(), 2, false,
                "# of Hours for Web Access Branding");
        }

        if (mozy.getMozyOutTasking()) {
            MozyOutTasking outTasking = mozy.getOutTasking();
            Helper.checkNull(logger, signature, outTasking, "MozyOutTasking");
            Helper.checkPositiveOrZero(logger, signature, outTasking.getHoursForMozyOutTasking(), 2, false,
                "# of Hours for Mozy Out-Tasking");
        }
    }

    /**
     * <p>Validates the Xtreme request data.</p>
     *
     * @param xtreme
     *         a <code>XtremeRequestData</code> object providing the data to be validated.
     * @since 3.2
     */
    private void validateXtreme(XtremeRequestData xtreme) {
        final String signature = CLASSNAME + "#validateXtreme(XtremeRequestData xtreme)";
        Logger logger = getLogger();
        Helper.checkNull(logger, signature, xtreme, "Xtreme Request Data");

        if (xtreme.getXtremeServices().getCache()) {
            XtremeCache xtremeCache = xtreme.getXtremeCache();
            Helper.checkNull(logger, signature, xtremeCache, "XtremeCache");
            Helper.checkPositiveOrZero(logger, signature,
                    xtremeCache.getNumberOfXtremSFFlashCardsToInstallAndConfigure(), false,
                    "# of XtremSF flash cards to install and configure?");
            Helper.checkPositiveOrZero(logger, signature, xtremeCache.getNumberOfHostsForXtremeCacheInstallation(),
                    false, "Number of hosts for XtremCache installation?");
        }

        if (xtreme.getXtremeServices().getSf()) {
            XtremeSF xtremeSF = xtreme.getXtremeSF();
            Helper.checkNull(logger, signature, xtremeSF, "XtremeSF");
            Helper.checkPositiveOrZero(logger, signature, xtremeSF.getNumberOfXtremSFFlashCardsToInstallAndConfigure(),
                    false, "# of XtremSF flash cards to install and configure?");
            Helper.checkPositiveOrZero(logger, signature, xtremeSF.getNumberOfHostsForXtremSFCardInstalls(),
                    false, "# of hosts for the XtremSF card installs?");
            Helper.checkPositiveOrZero(logger, signature, xtremeSF.getNumberOfHostsForXtremeCacheInstallation(),
                    false, "Number of hosts for XtremCache installation?");
        }

        if (xtreme.getXtremeServices().getOracleLocalReplication()) {
            XtremeIOOracleLocalReplication xtremeIOOracleLocalReplication = xtreme.getXtremeIOOracleLocalReplication();
            Helper.checkNull(logger, signature, xtremeIOOracleLocalReplication, "XtremeIOOracleLocalReplication");
            Helper
                .checkDecimal(logger, signature,
                    decimal2String(xtremeIOOracleLocalReplication.getFunctionalOverviewHours(), 2), 2,
                    "# of Hours of Functional Overview Delivered by Solutions Architect?");
        }
    }

    /**
     * Validates the Atmos request data.
     *
     * @param atmosRequestData
     *         the Atmos request data
     * @throws IllegalArgumentException
     *         if Atmos request data is invalid
     * @since SRT Phase 3-1 - Atmos Centera and Vblock Tabs Assembly
     */
    private void validateAtmos(AtmosCenteraRequestData atmosRequestData) {
        final String signature = CLASSNAME + "#validateAtmos(AtmosCenteraRequestData atmosRequestData)";
        Logger logger = getLogger();
        Helper.checkNull(logger, signature, atmosRequestData, "Atmos Request Data");

        Helper.checkPositiveOrZero(logger, signature, atmosRequestData.getDaysOfKnowledgeTransfer(), 2, false,
                "# days of knowledge transfer");

        AtmosCenteraServicesScope servicesScope = atmosRequestData.getServicesScope();
        Helper.checkNull(logger, signature, servicesScope, "Atmos services scope");

        if (servicesScope.isCenteraDesignImpl()) {
            CenteraDesignImpl cdi = atmosRequestData.getCenteraDesignImpl();
            Helper.checkNull(logger, signature, cdi, "Centera Design & Implementation");

            if (cdi.getCenterasExist() != null && cdi.getCenterasExist()) {
                List<ExistingCenteraCluster> existingClusters = cdi.getExistingClusters();
                if (existingClusters != null) {
                    for (ExistingCenteraCluster existingCluster : existingClusters) {
                        Helper.checkNull(logger, signature, existingCluster, "Existing centera cluster");
                        if (existingCluster.getLocation() != null) {

                            Helper.checkStringLength(logger, signature, existingCluster.getSerialNumber(), 9, 16,
                                    false, "Existing Centera serial number (mandatory)");
                            Helper.checkStringLength(logger, signature, existingCluster.getModemNumber(), 4, 14,
                                    false, "Existing Centera modem number or ESRS");
                        }
                    }
                }
            }

            List<NewCenteraCluster> newClusters = cdi.getNewClusters();
            if (newClusters != null) {
                for (NewCenteraCluster newCluster : newClusters) {
                    Helper.checkNull(logger, signature, newCluster, "Existing new cluster");
                    if (newCluster.getLocation() != null) {
                        Helper.checkIntegerInterval(logger, signature, newCluster.getNodesNum(),
                                4, Integer.MAX_VALUE, false, "How many nodes will each new Centera have?");
                    }
                }
            }
        }

        if (servicesScope.isAtmosDesignImpl()) {
            AtmosDesignImpl adi = atmosRequestData.getAtmosDesignImpl();
            Helper.checkNull(logger, signature, adi, "ATMOS Design & Implementation");

            Helper.checkPositiveOrZero(logger, signature, adi.getRmgsNum(), false,
                    "# of RMGs for base Hardware and Software of Atmos");
            Helper.checkPositiveOrZero(logger, signature, adi.getRmgsVENum(), false,
                    "# of RMGs for base software for Atmos VE");
            Helper.checkPositiveOrZero(logger, signature, adi.getInstallationSegmentsNum(), false,
                    "# of Atmos Installation Segments (IS)");
            Helper.checkPositiveOrZero(logger, signature, adi.getHardwareServersNum(), false,
                    "# of Atmos Hardware Servers to Install");
            Helper.checkPositiveOrZero(logger, signature, adi.getCifsServersNum(), false,
                    "# of CIFS servers to configure within Atmos");
            Helper.checkPositiveOrZero(logger, signature, adi.getNfsServersNum(), false,
                    "# of NFS servers to configure within Atmos");
            Helper.checkPositiveOrZero(logger, signature, adi.getIfsServersNum(), false,
                    "# of IFS servers to configure within Atmos");
            Helper.checkPositiveOrZero(logger, signature, adi.getWsServersNum(), false,
                    "# of WS servers to configure within Atmos");
            Helper.checkPositiveOrZero(logger, signature, adi.getTenantsNum(), false,
                    "# of tenants to be created");
            Helper.checkPositiveOrZero(logger, signature, adi.getSubTenantsNum(), false,
                    "# of subtenants to be created");
            Helper.checkPositiveOrZero(logger, signature, adi.getPoliciesNum(), false,
                    "# of policies to be created");
        }

        if (servicesScope.isCenteraToAtmosMig()) {
            CenteraToAtmosMigration mig = atmosRequestData.getCenteraToAtmosMigration();
            Helper.checkNull(logger, signature, mig, "Centera to ATMOS Data Migration");

            Helper.checkPositiveOrZero(logger, signature, mig.getApplicationsNum(), false,
                    "# of applications to be migrated to Atmos");
            Helper.checkPositiveOrZero(logger, signature, mig.getDataAmount(), false,
                    "Amount of data (in TB) to be migrated to Atmos");
        }

        if (servicesScope.isCua()) {
            CenteraUniversalAccess cua = atmosRequestData.getCenteraUniversalAccess();
            Helper.checkNull(logger, signature, cua, "Centera Universal Access");

            Helper.checkPositiveOrZero(logger, signature, cua.getDataPoolsNum(), false,
                    "# of data pools required on this CUA");

            Helper.checkIntegerInterval(logger, signature, cua.getActiveCUAsNum(), 0, 6, false,
                    "# of active CUAs to add to this Centera at this location");
            Helper.checkIntegerInterval(logger, signature, cua.getStandbyCUAsNum(), 0, 6, false,
                    "# of standby CUAs to add to this Centera at this location");
            Helper.checkIntegerInterval(logger, signature, cua.getRelocatedCUAsNum(), 0, 6, false,
                    "# of active or standby CUAs to be relocated");
        }

        if (servicesScope.isCicm()) {
            CenteraIntraClusterMigration cicm = atmosRequestData.getCenteraIntraClusterMigration();
            Helper.checkNull(logger, signature, cicm, "Centera Intra Cluster Migration CICM");

            Helper.checkPositiveOrZero(logger, signature, cicm.getSourceCubesNum(), false,
                    "# of Centera source cubes");
            Helper.checkPositiveOrZero(logger, signature, cicm.getTargetCubesNum(), false, "# of Centera target cubes");
            Helper.checkPositiveOrZero(logger, signature, cicm.getNewNodesNum(), false,
                    "# of new nodes to be added to this Centera for CICM?");
            Helper.checkPositiveOrZero(logger, signature, cicm.getRemovedNodesNum(), false,
                    "# of nodes to be removed from this Centera by CICM?");
        }

        if (servicesScope.isCenteraFileErasure()) {
            CenteraFileErasure cfe = atmosRequestData.getCenteraFileErasure();
            Helper.checkNull(logger, signature, cfe, "Centera File Erasure");

            Helper.checkIntegerInterval(logger, signature, cfe.getClipsToDeleteNum(), 0, 25, false,
                "# of Centera Clips to be deleted (in millions) - MAX: 25 million");
        }

        if (servicesScope.isExpansionNodeOnly()) {
            ExpansionNodeOnly en = atmosRequestData.getExpansionNodeOnly();
            Helper.checkNull(logger, signature, en, "Expansion Node");

            Helper.checkPositiveOrZero(logger, signature, en.getFlexKitsNum(), false,
                "Number of Atmos FLEX kits to be installed");
        }
    }

    /**
     * Validates the Vblock request data.
     *
     * @param vblockRequestData
     *         the Vblock request data
     * @throws IllegalArgumentException
     *         if Vblock request data is invalid
     * @since SRT Phase 3-1 - Atmos Centera and Vblock Tabs Assembly
     */
    private void validateVblock(VblockRequestData vblockRequestData) {
        final String signature = CLASSNAME + "#validateVblock(VblockRequestData vblockRequestData)";
        Logger logger = getLogger();
        Helper.checkNull(logger, signature, vblockRequestData, "Vblock Request Data");

        VblockServices services = vblockRequestData.getServices();
        Helper.checkNull(logger, signature, services, "Vblock services");

        if (services.isDesignImpl()) {
            VblockDesignImpl designImpl = vblockRequestData.getDesignImpl();
            Helper.checkNull(logger, signature, designImpl, "Vblock Design and Implementation");

            if (designImpl.isVnxType()) {
                Helper.checkPositiveOrZero(logger, signature, designImpl.getVnxLunsNum(), false,
                        "# of VBlock Type 1 Luns required (estimate)");
            }
            if (designImpl.isSymmetrixType()) {
                Helper.checkPositiveOrZero(logger, signature, designImpl.getSymmetrixLunsNum(), false,
                        "# of VBlock Type 2 Luns required (estimate)");
            }
            Helper.checkPositiveOrZero(logger, signature, designImpl.getType1VsphereServersNum(), false,
                    "# of type 1 Vsphere servers?");
            Helper.checkPositiveOrZero(logger, signature, designImpl.getType2VsphereServersNum(), false,
                    "# of type 2 Vsphere servers?");
            Helper.checkPositiveOrZero(logger, signature, designImpl.getCiscoPartnerHours(), 2, false,
                    "# of hours for Vblock Cisco partner?");
            Helper.checkPositiveOrZero(logger, signature, designImpl.getVmwarePartnerHours(), 2, false,
                    "# of hours for Vblock VmWare partner?");
            Helper.checkPositiveOrZero(logger, signature, designImpl.getNumberOfType1LUNs(), false,
                "# of Type 1 LUNs (estimate)?");
            Helper.checkPositiveOrZero(logger, signature, designImpl.getNumberOfType2LUNs(), false,
                "# of Type 2 LUNs (estimate)?");
            Helper.checkPositiveOrZero(logger, signature, designImpl.getNumberOfUnifiedFileType1(), false,
                "# of Unified File Type 1 (VG2)?");
            Helper.checkPositiveOrZero(logger, signature, designImpl.getNumberOfUnifiedFileType2(), false,
                "# of Unified File Type 2 (VG8)?");
        }

        if (services.isInfrastructure()) {
            VblockInfrastructure infra = vblockRequestData.getInfrastructure();
            Helper.checkNull(logger, signature, infra, "Implementation for Vblock Infrastructure");
            Helper.checkPositiveOrZero(logger, signature, infra.getVblockSeries300Num(), false,
                    "# of Vblock 300 Series to be installed?");
            Helper.checkPositiveOrZero(logger, signature, infra.getVblockSeries700Num(), false,
                "# of Vblock 700 Series to be installed?");
        }

        if (services.isTechAssessment()) {
            VblockTechAssessment techAssessment = vblockRequestData.getTechAssessment();
            Helper.checkNull(logger, signature, techAssessment, "Technical Assessment for Vblock Infrastructure");
            Helper.checkPositiveOrZero(logger, signature, techAssessment.getAssessedSites(), false,
                    "# of sites to be assessed");
            Helper.checkPositiveOrZero(logger, signature, techAssessment.getVmwareIdentifiedServersNum(), false,
                    "# of servers identified for VMWare consolidation");
        }
    }

    /**
     * Validates the Isilon request data.
     *
     * @param isilonRequestData
     *         the Isilon request data
     * @throws IllegalArgumentException
     *         if Isilon request data is invalid
     * @since SRT Phase 3-3 - Implement Isilon and ViPR Tabs Assembly
     */
    private void validateIsilon(IsilonRequestData isilonRequestData) {
        final String signature = CLASSNAME + "#validateIsilon(IsilonRequestData isilonRequestData)";
        Logger logger = getLogger();
        Helper.checkNull(logger, signature, isilonRequestData, "Isilon Request Data");
        Helper.checkNull(logger, signature, isilonRequestData.getServicesScope(),
                "Isilon Request Data services scope");

        Helper.checkPositiveOrZero(logger, signature, isilonRequestData.getKnowledgeTransferHours(), 2, false,
            "# of Hours of Knowledge Transfer");

        if (isilonRequestData.getServicesScope().isClusterRelocation()) {
            IsilonClusterRelocation cr = isilonRequestData.getClusterRelocation();
            Helper.checkNull(logger, signature, cr, "Isilon Cluster Relocation");

            Helper.checkPositiveOrZero(logger, signature, cr.getIsilon12UServersNum(), false,
                    "# of 1-2U Isilon Servers to Install");
            Helper.checkPositiveOrZero(logger, signature, cr.getIsilon4UServersNum(), false,
                    "# of Isilon 4U Servers to Install");
            Helper.checkPositiveOrZero(logger, signature, cr.getInfinibandSwitchesNum(), false,
                    "# of 1U Infiniband Switches to Install");
            Helper.checkPositiveOrZero(logger, signature, cr.getInfinibandChassisNum(), false,
                    "# of Isilon Infiniband Chassis to install(Non-1U Switches)");
        }

        if (isilonRequestData.getServicesScope().isHardwareUpgrade()) {
            IsilonHardwareUpgrade hu = isilonRequestData.getHardwareUpgrade();
            Helper.checkNull(logger, signature, hu, "Isilon Hardware Upgrade");

            if (hu.getPerformConfig() != null && hu.getPerformConfig()) {
                Helper.checkPositiveOrZero(logger, signature, hu.getNodesNum(), false, "nodesNum");
            }
        }

        if (isilonRequestData.getServicesScope().isDesignAndImpl()) {
            IsilonDesignAndImpl di = isilonRequestData.getDesignAndImpl();
            Helper.checkNull(logger, signature, di, "Isilon Design and Implementation");

            if (di.getNewCluster() != null && di.getNewCluster()) {
                Helper.checkPositiveOrZero(logger, signature, di.getSubnetsNum(), false,
                        "# of Isilon subnets to configure");
                Helper.checkPositiveOrZero(logger, signature, di.getSmartConnectZonesNum(), false,
                        "# of Isilon Smart Connect Zones to Configure");
                Helper.checkPositiveOrZero(logger, signature, di.getAuthMethodsNum(), false,
                        "# of Authentication Methods to Configure");
                Helper.checkPositiveOrZero(logger, signature, di.getSharesExportsNum(), false,
                        "# of Isilon Shares / Exports to Configure");
                Helper.checkPositiveOrZero(logger, signature, di.getSmartQuotasNum(), false,
                        "# of Isilon Smart Quotas to Configure");
                Helper.checkPositiveOrZero(logger, signature, di.getSnapshotsIQEntriesNum(), false,
                        "# of Snapshots IQ Entries to Configure");
            }
        }

        if (isilonRequestData.getServicesScope().isMigration()) {
            IsilonMigration mig = isilonRequestData.getMigration();
            Helper.checkNull(logger, signature, mig, "Isilon Migration");

            if (mig.isNetApp3rdPartyMigration() || mig.isCelerraUnifiedFile() || mig.isSyncIQ()) {

                if (mig.isCifs()) {
                    Helper.checkPositiveOrZero(logger, signature, mig.getCifsDataAmount(), false,
                            "Amount of CIFS data in TB to be migrated");
                }
                if (mig.isNfs()) {
                    Helper.checkPositiveOrZero(logger, signature, mig.getNfsDataAmount(), false,
                            "Amount of NFS Data in TB to be Migrated");
                }
                if (mig.isCifs()) {
                    Helper.checkPositiveOrZero(logger, signature, mig.getMultiProtocolDataAmount(), false,
                            "Amount of Multi-Protocol Data in TB to be Migrated");
                }
                Helper.checkPositiveOrZero(logger, signature, mig.getAverageDuration(), 2, false,
                        "Average duration of data migration event");
            }

            if (mig.isNetApp3rdPartyMigration() || mig.isCelerraUnifiedFile()) {
                Helper.checkPositiveOrZero(logger, signature, mig.getDataMigEventsNum(), false,
                        "# of data migration events");
            }

            if (mig.isSyncIQ()) {
                Helper.checkPositiveOrZero(logger, signature, mig.getMonitorWeeksNum(), false,
                        "# of weeks to monitor data movement");
                Helper.checkPositiveOrZero(logger, signature, mig.getCutoverEventsNum(), false,
                        "# of cutover events for synch IQ migration");
            }

            if (mig.isTechRefresh()) {
                Helper.checkPositiveOrZero(logger, signature, mig.getRemoveNodesNum(), false,
                        "Total # of Isilon nodes to be removed on the cluster after refresh");
                Helper.checkPositiveOrZero(logger, signature, mig.getRequiredEventsNum(), false,
                        "# of events required to move all node data");
                Helper.checkPositiveOrZero(logger, signature, mig.getTechRefreshMovedData(), false,
                        "Total TB of data to be moved as part of tech refresh");
            }
        }
    }

    /**
     * Validates the ViPR request data.
     *
     * @param viprRequestData
     *         the ViPR request data
     * @throws IllegalArgumentException
     *         if ViPR request data is invalid
     * @since SRT Phase 3-3 - Implement Isilon and ViPR Tabs Assembly
     */
    private void validateVipr(ViprRequestData viprRequestData) {
        final String signature = CLASSNAME + "#validateVipr(ViprRequestData viprRequestData)";
        Logger logger = getLogger();
        Helper.checkNull(logger, signature, viprRequestData, "ViPR Request Data");

        Helper.checkPositiveOrZero(logger, signature, viprRequestData.getKnowledgeTransferHours(), 2, false,
            "# of Hours of Knowledge Transfer");

        if (viprRequestData.getPlanningDesignImplementation()) {
            ViprImplementation impl = viprRequestData.getImpl();
            Helper.checkNull(logger, signature, impl, "ViPR Implementation");

            if (impl.getNewImplType() != null && impl.getNewImplType()) {
                Helper.checkPositiveOrZero(logger, signature, impl.getUnixHostsNum(), false,
                        "# of physical Unix hosts discovered");
                Helper.checkPositiveOrZero(logger, signature, impl.getWindowsHostsNum(), false,
                        "# of physical Windows hosts discovered");
                Helper.checkPositiveOrZero(logger, signature, impl.getvCenterHostsNum(), false,
                        "# of VMware vCenter hosts discovered");
                Helper.checkPositiveOrZero(logger, signature, impl.getFileOnlyArraysNum(), false,
                        "# of File-only arrays discovered(VNX,NetApp,Isilon)");
                Helper.checkPositiveOrZero(logger, signature, impl.getBlockArraysNum(), false,
                        "# of EMC Block arrays discovered(VMAX / VNX)");
                Helper.checkPositiveOrZero(logger, signature, impl.getVplexArraysNum(), false,
                        "# of EMC VPLEX arrays discovered");
                Helper.checkPositiveOrZero(logger, signature, impl.getRecoverPointSystemsNum(), false,
                        "# of EMC RecoverPoint systems discovered");
                Helper.checkPositiveOrZero(logger, signature, impl.getCiscoSwitchFabricsNum(), false,
                        "# of Cisco switch fabrics");
                Helper.checkPositiveOrZero(logger, signature, impl.getBrocadeSwitchFabricsNum(), false,
                        "# of Brocade switch fabrics");
                Helper.checkPositiveOrZero(logger, signature, impl.getVirtualArraysNum(), false,
                        "# of Virtual Arrays");
                Helper.checkPositiveOrZero(logger, signature, impl.getCatalogServicesNum(), false,
                        "# of Catalog Services to Customize");
                Helper.checkPositiveOrZero(logger, signature, impl.getUserRolesNum(), false, "# of User Roles defined");
    
                if (impl.getIncludeDataServices() != null && impl.getIncludeDataServices()) {
                    Helper.checkPositiveOrZero(logger, signature, impl.getDsBucketsNum(), false,
                            "# of Data Services Buckets");
                    Helper.checkPositiveOrZero(logger, signature, impl.getDsPoolsNum(), false,
                            "# of Data Services Virtual Pools");
                    Helper.checkPositiveOrZero(logger, signature, impl.getDataStoresNum(), false,
                            "# of Data Stores");
                    Helper.checkPositiveOrZero(logger, signature, impl.getDsIngestionsNum(), false,
                            "# of DS File Ingestions perfomed");
                    Helper.checkPositiveOrZero(logger, signature, impl.getHadoopClustersNum(), false,
                            "# of Hadoop Clusters");
                    Helper.checkPositiveOrZero(logger, signature, impl.getHadoopNodesNum(), false,
                            "Total # of Hadoop Cluster Nodes(Where ViPR HDFS Clients are to be deployed)");
                }
            }

            Helper.checkPositiveOrZero(logger, signature, impl.getSaKnowledgeTransferHours(), 2, false,
                    "# of hours for additional knowledge transfer(SA effort)");
        }
    }

    /**
     * Validates the HealthCheck request data.
     *
     * @param healthCheckRequestData
     *         the HealthCheck request data
     */
    private void validateHealthCheck(HealthCheckRequestData healthCheckRequestData) {
        final String signature = CLASSNAME + "#validateHealthCheck(HealthCheckRequestData healthCheckRequestData)";
        Logger logger = getLogger();
        Helper.checkNull(logger, signature, healthCheckRequestData, "HealthCheck Request Data");
        Helper.checkNull(logger, signature, healthCheckRequestData.getServicesScope(),
                "HealthCheck Request Data services scope");

        if (healthCheckRequestData.getServicesScope().isAvamar()) {
            HealthCheckAvamar avamar = healthCheckRequestData.getAvamar();
            Helper.checkNull(logger, signature, avamar, "Avamar HealthCheck");

            Helper.checkPositiveOrZero(logger, signature, avamar.getAvamarGridsNum(), false,
                    "# of Avamar Grids?");
            Helper.checkPositiveOrZero(logger, signature, avamar.getAssessmentInterviewsNum(), false,
                    "# of Assessment interviews?");
        }

        if (healthCheckRequestData.getServicesScope().isDataDomain()) {
            HealthCheckDataDomain dataDomain = healthCheckRequestData.getDataDomain();
            Helper.checkNull(logger, signature, dataDomain, "Data Domain HealthCheck");

            Helper.checkPositiveOrZero(logger, signature, dataDomain.getAppliancesNum(), false,
                    "# of Data Domain appliances?");
            Helper.checkPositiveOrZero(logger, signature, dataDomain.getAssessmentInterviewsNum(), false,
                    "# of Assessment interviews?");
        }

        if (healthCheckRequestData.getServicesScope().isDpa()) {
            HealthCheckDPA dpa = healthCheckRequestData.getDpa();
            Helper.checkNull(logger, signature, dpa, "Data Protection Advisor HealthCheck");

            Helper.checkPositiveOrZero(logger, signature, dpa.getSiteImplementationsNum(), false,
                    "# of DPA site implementations?");
        }

        if (healthCheckRequestData.getServicesScope().isDlm()) {
            HealthCheckDLM dlm = healthCheckRequestData.getDlm();
            Helper.checkNull(logger, signature, dlm, "DLM HealthCheck");

            Helper.checkPositiveOrZero(logger, signature, dlm.getDlmSubsystemNum(), false,
                    "# of Dish Library for Mainframe (DLm) subsystem to be evaluated?");
            Helper.checkPositiveOrZero(logger, signature, dlm.getStorageAmount(), false,
                    "Amount of storage, in whole TeraBytes (TB), on the DLm subsystem(s) to be evaluated?");
        }

        if (healthCheckRequestData.getServicesScope().isGreenPlum()) {
            HealthCheckGreenPlum greenplum = healthCheckRequestData.getGreenPlum();
            Helper.checkNull(logger, signature, greenplum, "Greenplum HealthCheck");

            Helper.checkPositiveOrZero(logger, signature, greenplum.getMasterHostServersNum(), false,
                    "# of Greenplum primary master host servers targeted for health check analysis?");
        }

        if (healthCheckRequestData.getServicesScope().isIonix()) {
            HealthCheckIonix ionix = healthCheckRequestData.getIonix();
            Helper.checkNull(logger, signature, ionix, "Ionix HealthCheck");
        }

        if (healthCheckRequestData.getServicesScope().isNetWorker()) {
            HealthCheckNetWorker netWorker = healthCheckRequestData.getNetWorker();
            Helper.checkNull(logger, signature, netWorker, "NetWorker HealthCheck");

            Helper.checkPositiveOrZero(logger, signature, netWorker.getDataZonesNum(), false,
                    "# of NetWorker datazones?");
            Helper.checkPositiveOrZero(logger, signature, netWorker.getAssessmentInterviewsNum(), false,
                    "# of Assessment interviews?");
        }

        if (healthCheckRequestData.getServicesScope().isSanSecurity()) {
            HealthCheckSanSecurity sanSecurity = healthCheckRequestData.getSanSecurity();
            Helper.checkNull(logger, signature, sanSecurity, "San Security HealthCheck");

            Helper.checkPositiveOrZero(logger, signature, sanSecurity.getAssessmentInterviewsNum(), false,
                    "# of Assessment interviews?");
            Helper.checkPositiveOrZero(logger, signature, sanSecurity.getAssessedSitesNum(), false,
                    "# of sites to be assessed?");
            Helper.checkPositiveOrZero(logger, signature, sanSecurity.getEmcStorageArraysNum(), false,
                    "# of EMC storage arrays to review?");
            Helper.checkPositiveOrZero(logger, signature, sanSecurity.getSanAttachedHostsNum(), false,
                    "# of SAN attached Hosts?");
            Helper.checkPositiveOrZero(logger, signature, sanSecurity.getStorageManagementStationsNum(), false,
                    "# of storage management stations?");
        }

        if (healthCheckRequestData.getServicesScope().isSap()) {
            HealthCheckSAP sap = healthCheckRequestData.getSap();
            Helper.checkNull(logger, signature, sap, "SAP HealthCheck");

            Helper.checkPositiveOrZero(logger, signature, sap.getDlmSubsystemNum(), false,
                    "# of Disk Library for Mainframe (DLm) subsystems to be evaluated?");
            Helper.checkPositiveOrZero(logger, signature, sap.getStorageAmount(), false,
                    "Amount of stroage, in whole TeraBytes (TB), on the DLm subsystem(s) to be evaluated");
        }

        if (healthCheckRequestData.getServicesScope().isSourceOne()) {
            HealthCheckSourceOne sourceOne = healthCheckRequestData.getSourceOne();
            Helper.checkNull(logger, signature, sourceOne, "SourceOne HealthCheck");

            Helper.checkPositiveOrZero(logger, signature, sourceOne.getServersNum(), false,
                    "# of SourceOne servers?");
            Helper.checkPositiveOrZero(logger, signature, sourceOne.getAssessmentInterviewsNum(), false,
                    "# of Assessment interviews?");
        }

        if (healthCheckRequestData.getServicesScope().isSymmetrixVmax()) {
            HealthCheckSymmetrixVmax symmVmax = healthCheckRequestData.getSymmetrixVmax();
            Helper.checkNull(logger, signature, symmVmax, "Symmetrix/Vmax HealthCheck");

            Helper.checkPositiveOrZero(logger, signature, symmVmax.getEventsSoldNum(), false,
                    "# of Health Checks Events sold to customer?");
            Helper.checkPositiveOrZero(logger, signature, symmVmax.getDmxVmaxArraysNum(), false,
                    "# of Symmetrix DMX and/or VMAX arrays?");
        }

        if (healthCheckRequestData.getServicesScope().isSymmetrixVmaxStorageReplication()) {
            HealthCheckSymmetrixVmaxStorageReplication symmVmaxSR = healthCheckRequestData
                    .getSymmetrixVmaxStorageReplication();
            Helper.checkNull(logger, signature, symmVmaxSR, "Symmetrix/Vmax Storage Replication HealthCheck");

            Helper.checkPositiveOrZero(logger, signature, symmVmaxSR.getAssessmentInterviewsNum(), false,
                    "# of Assessment interviews?");
            Helper.checkPositiveOrZero(logger, signature, symmVmaxSR.getConsistencyGroupsNum(), false,
                    "# of Consistency Groups for Symmetrix Health Check?");
            Helper.checkPositiveOrZero(logger, signature, symmVmaxSR.getSymmetrixArraysNum(), false,
                    "# of Symmetrix arrays for Symmetrix Health Check?");
            Helper.checkPositiveOrZero(logger, signature, symmVmaxSR.getOpenSystemsHostsNum(), false,
                    "# of Open Systems Hosts for Symmetrix Health Check?");
            Helper.checkPositiveOrZero(logger, signature, symmVmaxSR.getLogicalDevicesNum(), false,
                    "# of Symmetrix Logical Devices for Symmetrix Health Check?");
        }

        if (healthCheckRequestData.getServicesScope().isUnified()) {
            HealthCheckUnified unified = healthCheckRequestData.getUnified();
            Helper.checkNull(logger, signature, unified, "Unified HealthCheck");

            Helper.checkPositiveOrZero(logger, signature, unified.getEventsSoldNum(), false,
                    "# of Health Checks Events sold to customer");
            if (unified.getHealthCheckType() != null) {
                if ("File".equals(unified.getHealthCheckType().getName())) {
                    Helper.checkPositiveOrZero(logger, signature, unified.getFileArraysNum(), false,
                            "# of Celerra or VNX Unified File Based Arrays");
                }

                if ("Block".equals(unified.getHealthCheckType().getName())) {
                    Helper.checkPositiveOrZero(logger, signature, unified.getBlockArraysNum(), false,
                            "# of Clariion or VNX Unified Unified Block Arrays");
                }
            }
        }

        if (healthCheckRequestData.getServicesScope().isVblock()) {
            HealthCheckVblock vblock = healthCheckRequestData.getVblock();
            Helper.checkNull(logger, signature, vblock, "Vblock HealthCheck");

            Helper.checkPositiveOrZero(logger, signature, vblock.getBlockArraysNum(), false,
                    "# of existing VNX Block arrays for Health Check");
            Helper.checkPositiveOrZero(logger, signature, vblock.getSanSwitchesNum(), false,
                    "# of existing SAN switches for Health Check");
            Helper.checkPositiveOrZero(logger, signature, vblock.getSanHostsNum(), false,
                    "# of existing SAN hosts for health check");
        }

        if (healthCheckRequestData.getServicesScope().isVmwareVirtualInfrastructure()) {
            HealthCheckVmwareVirtualInfrastructure vmware = healthCheckRequestData.getVmwareVirtualInfrastructure();
            Helper.checkNull(logger, signature, vmware, "Vmware Virtual Infrastructure HealthCheck");

            Helper.checkPositiveOrZero(logger, signature, vmware.getAssessmentInterviewsNum(), false,
                    "# of Assessment interviews?");
            Helper.checkPositiveOrZero(logger, signature, vmware.getEsxServersNum(), false,
                    "# of existing ESX/ESXi Servers?");
            Helper.checkPositiveOrZero(logger, signature, vmware.getVirtualHostsNum(), false,
                    "# of existing VMware virtual hosts?");
        }

        if (healthCheckRequestData.getServicesScope().isVplex()) {
            HealthCheckVplex vplex = healthCheckRequestData.getVplex();
            Helper.checkNull(logger, signature, vplex, "Vplex HealthCheck");

            Helper.checkPositiveOrZero(logger, signature, vplex.getClustersReviewedNum(), false,
                    "# of VPLEX Clusters reviewed in each Health Check event?");
            Helper.checkPositiveOrZero(logger, signature, vplex.getEventsSoldNum(), false,
                    "# of Health Checks Events sold to customer");
        }
    }

    /**
     * Validates the ASD request data.
     *
     * @param asdRequestData
     *         the ASD request data
     */
    private void validateASD(ASDRequestData asdRequestData) {
        final String signature = CLASSNAME + "#validateASD(ASDRequestData asdRequestData)";
        Logger logger = getLogger();
        Helper.checkNull(logger, signature, asdRequestData, "ASD Request Data");
        Helper.checkNull(logger, signature, asdRequestData.getServicesScope(),
                "ASD Request Data services scope");

        if (asdRequestData.getServicesScope().isAppSync()) {
            ASDAppSync appSync = asdRequestData.getAppSync();
            Helper.checkNull(logger, signature, appSync, "ASD Request Data AppSync");

            Helper.checkPositiveOrZero(logger, signature, appSync.getAppSyncInstancesNum(), false,
                    "# of AppSync Instances Installed?");
            Helper.checkPositiveOrZero(logger, signature, appSync.getvCenterServersNum(), false,
                    "# of vCenter Servers Discovered?");
            Helper.checkPositiveOrZero(logger, signature, appSync.getApplicationProductionHostsNum(), false,
                    "# of Application Production Hosts Discovered?");
            Helper.checkPositiveOrZero(logger, signature, appSync.getVnxArraysNum(), false,
                    "# of VNX Arrays Discovered?");
            Helper.checkPositiveOrZero(logger, signature, appSync.getApplicationMountHostsNum(), false,
                    "# of Application Mount Hosts Discovered?");
            Helper.checkPositiveOrZero(logger, signature, appSync.getRecoverPointAppliancesNum(), false,
                    "# of RecoverPoint Appliances Discovered?");

            Helper.checkPositiveOrZero(logger, signature, appSync.getKnowledgeTransferHours(), 2, false,
                    "# of hours for additional knowledge transfer (IS effort)?");
        }

        if (asdRequestData.getServicesScope().isUim()) {
            ASDUIM uim = asdRequestData.getUim();
            Helper.checkNull(logger, signature, uim, "ASD Request Data UIM");

            if (uim.getIncludeRemoteInstallAgent() != null
                    && uim.getIncludeRemoteInstallAgent()) {
                Helper.checkPositiveOrZero(logger, signature, uim.getRemoteInstallAgentsNum(), false,
                        "# of Remote Install Agents?");
            }

            if (uim.getInstallType() != null && (
                    "UIM/P".equals(uim.getInstallType().getName())
                            || "Both".equals(uim.getInstallType().getName()))) {
                Helper.checkPositiveOrZero(logger, signature, uim.getUimProvisioningVAppsNum(), false,
                        "# of UIM / Provisioning vApps to Install");
                Helper.checkPositiveOrZero(logger, signature, uim.getIsolationZonesNum(), false,
                        "# of Isolation Zones to Add");
                if (uim.getIncludeVCO() != null && uim.getIncludeVCO()) {
                    Helper.checkPositiveOrZero(logger, signature, uim.getVcenterInstancesNum(), false,
                            "Total # of vCenter Instances to Add");
                }
            }

            if (uim.getUpgradeType() != null && (
                    "UIM/P".equals(uim.getUpgradeType().getName())
                            || "Both".equals(uim.getUpgradeType().getName()))) {
                Helper.checkPositiveOrZero(logger, signature, uim.getUimProvisioningServersNum(), false,
                        "# of UIM / Provisioning version 3.x Servers to Upgrade");
            }

            Helper.checkPositiveOrZero(logger, signature, uim.getVcloudDirectorInstancesNum(), false,
                    "# of vCloud Director Instances to Add");
            Helper.checkPositiveOrZero(logger, signature, uim.getConvergedHardwareSystemsNum(), false,
                    "# of Converged Hardware Systems to Discover by UIM / Provisioning");
            Helper.checkPositiveOrZero(logger, signature, uim.getBladeStorageGradesNum(), false,
                    "# of Blade and Storage Grades to Add and Assign to Pools");
            Helper.checkPositiveOrZero(logger, signature, uim.getIdentityPoolsNum(), false,
                    "# of Identity (UUID, MAC, IP, WWNN, WWPN) Pools to Add");
            Helper.checkPositiveOrZero(logger, signature, uim.getNetworkProfilesNum(), false,
                    "# of Network Profiles to Set");
            Helper.checkPositiveOrZero(logger, signature, uim.getUimOperationsVAppsNum(), false,
                    "# of UIM / Operations vApps to Install");
            Helper.checkPositiveOrZero(logger, signature, uim.getServiceOfferingsToCreateNum(), false,
                    "# of Service Offerings to Create");
            Helper.checkPositiveOrZero(logger, signature, uim.getServicesToCreateNum(), false,
                    "# of Services to Create");
            Helper.checkPositiveOrZero(logger, signature, uim.getBladesToProvisionNum(), false,
                    "# of Blades to Provision");
            Helper.checkPositiveOrZero(logger, signature, uim.getLunsToProvisionNum(), false,
                    "# of LUNs (block/RDM/File) to Provision");
            Helper.checkPositiveOrZero(logger, signature, uim.getServicesToProvisionNum(), false,
                    "# of Services to Provision with OS Install");

            if (uim.getInstallType() != null && (
                    "UIM/O".equals(uim.getInstallType().getName())
                            || "Both".equals(uim.getInstallType().getName()))) {
                Helper.checkPositiveOrZero(logger, signature, uim.getDataSourcesNum(), false,
                        "# of Data Sources added to UIM / Operations");
                Helper.checkPositiveOrZero(logger, signature, uim.getSnmpAlertsNum(), false,
                        "# of SNMP Alerts and/or Syslogs Forwarding Setup to External Management Systems");
            }

            if (uim.getUpgradeType() != null && (
                    "UIM/O".equals(uim.getUpgradeType().getName())
                            || "Both".equals(uim.getUpgradeType().getName()))) {
                Helper.checkPositiveOrZero(logger, signature, uim.getUimOperationsServersNum(), false,
                        "# of UIM Operations Servers to Upgrade from 3.x");
                Helper.checkPositiveOrZero(logger, signature, uim.getUimOperationsUsersNum(), false,
                        "# of UIM / Operations Users to Create");
            }

            if (uim.getPerformElasticProvisioning() != null && uim.getPerformElasticProvisioning()) {
                Helper.checkPositiveOrZero(logger, signature, uim.getServicesRequiringElasticOperationsNum(),
                        false, "# of Services Requiring Elastic Operations");
                Helper.checkPositiveOrZero(logger, signature, uim.getBladesImpactedNum(), false,
                        "# of Blades Impacted by vNIC Elastic Operations");
            }

            if (uim.getMigrateServices() != null && uim.getMigrateServices()) {
                Helper.checkPositiveOrZero(logger, signature, uim.getNonUIMConvergedHardwareSystemsNum(), false,
                        "# of non-UIM Converged Hardware Systems adopted/migrated to UIM");
                Helper.checkPositiveOrZero(logger, signature, uim.getServicesAdoptedMigratedNum(), false,
                        "# of Services From non-UIM Converged Hardware Systems Adopted/Migrated to UIM");
                Helper.checkPositiveOrZero(logger, signature, uim.getBladesAdoptedMigratedNum(), false,
                        "# of Blades Adopted/Migrated");
            }

            if (uim.getCustomerKnown() != null && uim.getCustomerKnown()) {
                Helper.checkPositiveOrZero(logger, signature, uim.getRemediateHours(), 2, false,
                        "# of Hours to remediate UIM pre-install issues");
            }

            Helper.checkPositiveOrZero(logger, signature, uim.getSaKnowledgeTransferHours(), 2, false,
                    "# of Hours for Additional Knowledge Transfer (SA effort)?");
            Helper.checkPositiveOrZero(logger, signature, uim.getIsKnowledgeTransferHours(), 2, false,
                    "# of hours for additional knowledge transfer (IS effort)?");
        }
    }

    /**
     * Validates the SourceOne request data.
     *
     * @param sourceOneRequestData
     *         the SourceOne request data
     */
    private void validateSourceOne(SourceOneRequestData sourceOneRequestData) {
        final String signature = CLASSNAME + "#validateSourceOne(SourceOneRequestData sourceOneRequestData)";
        Logger logger = getLogger();
        Helper.checkNull(logger, signature, sourceOneRequestData, "SourceOne Request Data");
        Helper.checkNull(logger, signature, sourceOneRequestData.getServicesScope(),
                "SourceOne Request Data services scope");

        Helper.checkPositiveOrZero(logger, signature, sourceOneRequestData.getSitesInvolvedNum(), false,
                "# of sites involved");

        if (sourceOneRequestData.getServicesScope().isUpgrade()) {
            SourceOneUpgrade upgrade = sourceOneRequestData.getUpgrade();
            Helper.checkNull(logger, signature, upgrade, "SourceOne Request Data Upgrade");

            Helper.checkPositiveOrZero(logger, signature, upgrade.getKnowledgeTransferHours(), 2, false,
                    "# of hours of knowledge transfer");

            Helper.checkPositiveOrZero(logger, signature, upgrade.getMasterServersNum(), false,
                    "Number of Master Servers?");
            Helper.checkPositiveOrZero(logger, signature, upgrade.getWorkerServersNum(), false,
                    "Number of Worker Servers?");
            Helper.checkPositiveOrZero(logger, signature, upgrade.getBillableHoursNum(), false,
                    "Number of billable hours for additional testing to be done by IS?");
        }

        if (sourceOneRequestData.getServicesScope().isMigration()) {
            SourceOneMigration migration = sourceOneRequestData.getMigration();
            Helper.checkNull(logger, signature, migration, "SourceOne Request Data In-Place Migration");

            Helper.checkPositiveOrZero(logger, signature, migration.getKnowledgeTransferHours(), 2, false,
                    "# of hours of knowledge transfer");

            Helper.checkPositiveOrZero(logger, signature, migration.getEmailXtenderServersNum(), false,
                    "Number of EmailXtender Servers?");
            Helper.checkPositiveOrZero(logger, signature, migration.getMigratedSize(), false,
                    "Total Size (TB) of the EmailXtender Archive to be migrated?");
            Helper.checkPositiveOrZero(logger, signature, migration.getBillableHoursNum(), false,
                    "Number of billable hours for additional testing to be done by IS?");
        }

        if (sourceOneRequestData.getServicesScope().isHealthCheck()) {
            SourceOneHealthCheck healthCheck = sourceOneRequestData.getHealthCheck();
            Helper.checkNull(logger, signature, healthCheck, "SourceOne Request Data Health Check");

            Helper.checkPositiveOrZero(logger, signature, healthCheck.getKnowledgeTransferHours(), 2, false,
                    "# of hours of knowledge transfer");

            Helper.checkPositiveOrZero(logger, signature, healthCheck.getServersNum(), false,
                    "Number of servers?");
            Helper.checkPositiveOrZero(logger, signature, healthCheck.getAssessmentInterviewsNum(), false,
                    "Number of assesment interviews?");
            Helper.checkPositiveOrZero(logger, signature, healthCheck.getMasterServersNum(), false,
                    "Number of Master Servers?");
            Helper.checkPositiveOrZero(logger, signature, healthCheck.getWorkerServersNum(), false,
                    "Number of Worker Servers?");
        }

        if (sourceOneRequestData.getServicesScope().isDesignAndImpl()) {
            SourceOneDesignImpl designImpl = sourceOneRequestData.getDesignImpl();
            Helper.checkNull(logger, signature, designImpl, "SourceOne Request Data Design & Implement");

            Helper.checkPositiveOrZero(logger, signature, designImpl.getKnowledgeTransferHours(), 2, false,
                    "# of hours of knowledge transfer");

            Helper.checkPositiveOrZero(logger, signature, designImpl.getMailboxesNum(), false,
                    "How many mailboxes?");

            SourceOneFeatures features = designImpl.getFeatures();
            if (features != null && features.isEmailSupervisor()) {
                Helper.checkPositiveOrZero(logger, signature, designImpl.getSupervisedUsersNum(), false,
                        "Number of users to be supervised with Supervisor?");
            }
            Helper.checkPositiveOrZero(logger, signature, designImpl.getMasterServersNum(), false,
                    "Number of Master Servers?");
            if (features != null && features.isEmailArchiving()) {
                Helper.checkPositiveOrZero(logger, signature, designImpl.getEmailMgmtServersNum(), false,
                        "Number of Worker Servers to perform Email Management?");
            }
            if (features != null && features.isSharePointArchiving()) {
                Helper.checkPositiveOrZero(logger, signature, designImpl.getSharePointArchivingServersNum(),
                        false, "Number of Worker Servers to be used for SharePoint Archiving?");
            }
            if (features != null && features.isFileArchiving()) {
                Helper.checkPositiveOrZero(logger, signature, designImpl.getFileArchivingServersNum(), false,
                        "Number of Worker Servers to be used for File Archiving?");
            }
            Helper.checkPositiveOrZero(logger, signature, designImpl.getMgmtConsolesNum(), false,
                    "Number of Management Console(s)?");
            if (features != null && features.isEmailArchiving()) {
                Helper.checkPositiveOrZero(logger, signature, designImpl.getMappedFoldersNum(), false,
                        "Number of Mapped Folders to Configure and Map these to the particular archive folder?");
                Helper.checkPositiveOrZero(logger, signature, designImpl.getEmailArchivePoliciesNum(), false,
                        "Number of Organization Policies for Email Archive?");
            }
            if (features != null && features.isFileArchiving()) {
                Helper.checkPositiveOrZero(logger, signature, designImpl.getFileArchivePoliciesNum(), false,
                        "Number of Organization Policies for File Archive?");
            }
            if (features != null && features.isDiscoveryManager()) {
                Helper.checkPositiveOrZero(logger, signature, designImpl.getDisManagerAdminConsoleNum(), false,
                        "Number of Discovery Manager Admin Console?");
                Helper.checkPositiveOrZero(logger, signature, designImpl.getDisManagerClientNum(), false,
                        "Number of Discovery Manager Client?");
                Helper.checkPositiveOrZero(logger, signature, designImpl.getHoldFoldersNum(), false,
                        "Number of Hold Folders?");
                Helper.checkPositiveOrZero(logger, signature, designImpl.getSampleMatterNum(), false,
                        "Number of Sample Matter?");
                Helper.checkPositiveOrZero(logger, signature, designImpl.getLegalHoldFoldersNum(), false,
                        "Number of Legal Hold Folders to Configure?");
            }
            if (features != null && features.isSharePointArchiving()) {
                Helper.checkPositiveOrZero(logger, signature, designImpl.getArchiveSharePointFarmsNum(), false,
                        "Number of SharePoint Farms? (SP Archive)");
            }
            if (features != null && features.isSharePointStorageManagment()) {
                Helper.checkPositiveOrZero(logger, signature, designImpl.getStorageMgmtSharePointFarmsNum(),
                        false, "Number of SharePoint Farms? (SP Storage Mangment)");
            }
            if (features != null && features.isFileArchiving()) {
                Helper.checkPositiveOrZero(logger, signature, designImpl.getFileArchiveMappedFoldersNum(), false,
                        "Number of File Archive Mapped Folders?");
                Helper.checkPositiveOrZero(logger, signature, designImpl.getFileArchivePolicesToBeConfiguredNum(),
                        false, "Number of Organization Policies to be configured for File Archive?");
            }
            if (features != null && features.isCloudTieringAppMgmt()) {
                Helper.checkPositiveOrZero(logger, signature, designImpl.getCloudTieringAppliancesNum(), false,
                        "Number of Cloud Tiering Appliances?");
            }
            if (features != null && features.isEmailSupervisor()) {
                Helper.checkPositiveOrZero(logger, signature, designImpl.getReviewerClientsNum(), false,
                        "Number of reviewer clients?");
            }
        }
    }

    /**
     * Validates the Residency request data. Currently only validate integer/decimal data is greater than or equal 0 (if
     * they are present).
     *
     * @param residencyRequestData
     *         the Residency request data
     */
    private void validateResidency(ResidencyRequestData residencyRequestData) {
        final String signature = CLASSNAME + "#validateResidency(ResidencyRequestData residencyRequestData)";
        Logger logger = getLogger();
        Helper.checkNull(logger, signature, residencyRequestData, "Residency Request Data");
        Helper.checkStrictPositive(logger, signature, residencyRequestData.getWorkHoursNum(), 2, false,
            "# of work hours in a month");

        ResidencyRoleSkillLevels rsls = residencyRequestData.getRoleSkillLevels();
        if (rsls != null) {
            Map<String, RoleSkillLevel> backup = rsls.getBackup();
            if (backup != null) {
                for (RoleSkillLevel rsl : backup.values()) {
                    Helper.checkPositiveOrZero(logger, signature, rsl.getQuantity(), 2, false,
                            rsl.getRollSkillName() + " Quantity");
                }
            }

            Map<String, RoleSkillLevel> pm = rsls.getProjectManagement();
            if (pm != null) {
                for (RoleSkillLevel rsl : pm.values()) {
                    Helper.checkPositiveOrZero(logger, signature, rsl.getQuantity(), 2, false,
                            rsl.getRollSkillName() + " Quantity");
                }
            }

            Map<String, RoleSkillLevel> sysAdm = rsls.getSystemAdmin();
            if (sysAdm != null) {
                for (RoleSkillLevel rsl : sysAdm.values()) {
                    Helper.checkPositiveOrZero(logger, signature, rsl.getQuantity(), 2, false,
                            rsl.getRollSkillName() + " Quantity");
                }
            }

            Map<String, RoleSkillLevel> storage = rsls.getStorage();
            if (storage != null) {
                for (RoleSkillLevel rsl : storage.values()) {
                    Helper.checkPositiveOrZero(logger, signature, rsl.getQuantity(), 2, false,
                            rsl.getRollSkillName() + " Quantity");
                }
            }

            Map<String, RoleSkillLevel> support = rsls.getSupport();
            if (support != null) {
                for (RoleSkillLevel rsl : support.values()) {
                    Helper.checkPositiveOrZero(logger, signature, rsl.getQuantity(), 2, false,
                            rsl.getRollSkillName() + " Quantity");
                }
            }

            Map<String, RoleSkillLevel> vmware = rsls.getVmware();
            if (vmware != null) {
                for (RoleSkillLevel rsl : vmware.values()) {
                    Helper.checkPositiveOrZero(logger, signature, rsl.getQuantity(), 2, false,
                            rsl.getRollSkillName() + " Quantity");
                }
            }

            if (rsls.getArchive() != null) {
                for (RoleSkillLevel level : rsls.getArchive()) {
                    Helper.checkStrNullEmpty(logger, signature, level.getRollSkillName(), "Archive role/skill name");
                    Helper.checkPositiveOrZero(logger, signature, level.getQuantity(), 2, false,
                        "Archive role/skill level Quantity");
                }
            }

            if (rsls.getCloud() != null) {
                for (RoleSkillLevel level : rsls.getCloud()) {
                    Helper.checkStrNullEmpty(logger, signature, level.getRollSkillName(), "Cloud role/skill name");
                    Helper.checkPositiveOrZero(logger, signature, level.getQuantity(), 2, false,
                        "Cloud role/skill level Quantity");
                }
            }

            if (rsls.getDataWareHouse() != null) {
                for (RoleSkillLevel level : rsls.getDataWareHouse()) {
                    Helper.checkStrNullEmpty(logger, signature, level.getRollSkillName(),
                        "Data Warehouse role/skill name");
                    Helper.checkPositiveOrZero(logger, signature, level.getQuantity(), 2, false,
                        "Data Warehouse role/skill level Quantity");
                }
            }

            if (rsls.getIsilon() != null) {
                for (RoleSkillLevel level : rsls.getIsilon()) {
                    Helper.checkStrNullEmpty(logger, signature, level.getRollSkillName(), "Isilon role/skill name");
                    Helper.checkPositiveOrZero(logger, signature, level.getQuantity(), 2, false,
                        "Isilon role/skill level Quantity");
                }
            }

            if (rsls.getStorageManagement() != null) {
                for (RoleSkillLevel level : rsls.getStorageManagement()) {
                    Helper.checkStrNullEmpty(logger, signature, level.getRollSkillName(),
                        "Storage Management role/skill name");
                    Helper.checkPositiveOrZero(logger, signature, level.getQuantity(), 2, false,
                        "Storage Management role/skill level Quantity");
                }
            }

            if (rsls.getVblock() != null) {
                for (RoleSkillLevel level : rsls.getVblock()) {
                    Helper.checkStrNullEmpty(logger, signature, level.getRollSkillName(), "Vblock role/skill name");
                    Helper.checkPositiveOrZero(logger, signature, level.getQuantity(), 2, false,
                        "Vblock role/skill level Quantity");
                }
            }

            if (rsls.getVirtualizationXtremeIO() != null) {
                for (RoleSkillLevel level : rsls.getVirtualizationXtremeIO()) {
                    Helper.checkStrNullEmpty(logger, signature, level.getRollSkillName(),
                        "Virtualization & XtremeIO role/skill name");
                    Helper.checkPositiveOrZero(logger, signature, level.getQuantity(), 2, false,
                        "Virtualization & XtremeIO role/skill level Quantity");
                }
            }
        }
    }

    /**
     * Validates the CTA request data. Currently only validate integer/decimal data is greater than or equal 0 (if they
     * are present).
     *
     * @param ctaRequestData
     *         the CTA request data
     */
    private void validateCTA(CTARequestData ctaRequestData) {
        final String signature = CLASSNAME + "#validateCTA(CTARequestData ctaRequestData)";
        Logger logger = getLogger();
        Helper.checkNull(logger, signature, ctaRequestData, "CTA Request Data");
        Helper.checkNull(logger, signature, ctaRequestData.getServicesScope(), "CTA Request Data services scope");

        Helper.checkPositiveOrZero(logger, signature, ctaRequestData.getDaysOfknowledgeTransfer(), 2, false,
                "# days of knowledge transfer");

        if (ctaRequestData.getServicesScope().isCtaDesignAndImplementation()
                || ctaRequestData.getServicesScope().isCtaImplementation()) {
            CTAImplementation impl = ctaRequestData.getImplementation();
            Helper.checkNull(logger, signature, impl, "CTA Request Data implementation info");
            if (impl.getArray() != null) {
                for (CTAImplementationArray array : impl.getArray()) {
                    Helper.checkStringLength(logger, signature, array.getLocation(), 1, 40, false,
                            "Location (City, State)");
                    Helper.checkPositiveOrZero(logger, signature, array.getClustersNum(), false,
                            "# of clusters");
                    Helper.checkPositiveOrZero(logger, signature, array.getSourceExportsSharesNum(), false,
                            "# of source exports/shares");
                    Helper.checkPositiveOrZero(logger, signature, array.getMultiTierSitesNum(), false,
                            "# of Multi-tier sites");
                    Helper.checkPositiveOrZero(logger, signature, array.getArchivePoliciesNum(), false,
                            "# of archive policies");
                    Helper.checkPositiveOrZero(logger, signature, array.getMigrationPoliciesNum(), false,
                            "# Number of migration policies");
                }
            }
        }

        if (ctaRequestData.getServicesScope().isCtaConversion()) {
            CTAConversion conversion = ctaRequestData.getConversion();
            Helper.checkNull(logger, signature, conversion, "CTA Request Data conversion info");
            Helper.checkPositiveOrZero(logger, signature, conversion.getCloudTieringApplianceNum(), false,
                    "# of Cloud Tiering Appliance or Cloud Tiering Appliance/VEs for conversion");
            Helper.checkPositiveOrZero(logger, signature, conversion.getFileServersNum(), false,
                    "# of file servers for the conversion");
            Helper.checkPositiveOrZero(logger, signature, conversion.getManagementSitesNum(), false,
                    "# of sites for Rainfinity File Management Appliance conversion");
            Helper.checkPositiveOrZero(logger, signature, conversion.getFilesConvertedNum(), false,
                    "# of Files on all the File Systems to be Converted (in millions)");
            Helper.checkPositiveOrZero(logger, signature, conversion.getFileArchiversNum(), false,
                    "# of Centera File Archivers in conversion environment");
            Helper.checkPositiveOrZero(logger, signature, conversion.getCfaRecordsNum(), false,
                    "# of CFA database records to be converted to Cloud Tiering Appliance (in millions)");
        }

        if (ctaRequestData.getServicesScope().isRainfinityDesignAndImplementation()) {
            CTARaininfinity rain = ctaRequestData.getRaininfinity();
            Helper.checkNull(logger, signature, rain, "CTA Request Data Raininfinity info");
            Helper.checkPositiveOrZero(logger, signature, rain.getBillableHoursNum(), 2, false,
                    "# of billable hours for Solutions Architect to complete Solutions Qualifiers");
            Helper.checkPositiveOrZero(logger, signature, rain.getAppliancesDeployedNum(), false,
                    "# of File Virtualization Appliances to be deployed");
            Helper.checkPositiveOrZero(logger, signature, rain.getFileServersNum(), false,
                    "# of file servers in the File Virtualization Appliance environment");
            Helper.checkPositiveOrZero(logger, signature, rain.getFileSystemsNum(), false,
                    "# of file systems in the File Virtualization Appliance environment");
            Helper.checkPositiveOrZero(logger, signature, rain.getLocalUserObjectsNum(), false,
                    "# of local user and group objects");
            Helper.checkPositiveOrZero(logger, signature, rain.getRainfinityAppliancesNum(), false,
                    "# of Rainfinity Global File Virtualization appliances");
            Helper.checkPositiveOrZero(logger, signature, rain.getRainfinityVLANsNum(), false,
                    "# of Rainfinity FVA VLANs for the MSTP configuration");
            Helper.checkPositiveOrZero(logger, signature, rain.getDomainsNum(), false,
                    "# of Domains for File Virtualization Appliance (FVA) cross-functional migration implementation");
            Helper.checkPositiveOrZero(logger, signature, rain.getMigrateDataAmount(), false,
                    "Amount of data in GB to be migrated by the Rainfinity File Virtualization Appliance");
        }
    }

    /**
     * Validates the MSS request data.
     *
     * @param mssRequestData
     *         the MSS request data
     */
    private void validateMSS(MSSRequestData mssRequestData) {
        final String signature = CLASSNAME + "#validateMSS(MSSRequestData mssRequestData)";
        Logger logger = getLogger();
        Helper.checkNull(logger, signature, mssRequestData, "MSS Request Data");
        if (mssRequestData.getMssArray() != null) {
            for (MSSArray array : mssRequestData.getMssArray()) {
                MSSDataDomain mdd = array.getDataDomain();
                if (mdd != null) {
                    Helper.checkPositiveOrZero(logger, signature, mdd.getNumRetentionDrives(), false,
                            "Number of drives for retention");
                }
            }
        }
    }

    /**
     * Validates the BC request data.
     *
     * @param bcRequestData
     *         the BC request data
     * @param unifiedRequestData
     *         the Unified request data
     */
    private void validateBC(BcRequestData bcRequestData, UnifiedRequestData unifiedRequestData) {
        final String signature = CLASSNAME + "#validateBC()";
        Logger logger = getLogger();
        Helper.checkNull(logger, signature, bcRequestData, "BC Request Data");

        BCServicesScope bcServicesScope = bcRequestData.getServicesScope();
        if (bcServicesScope.isMirrowView()) {
            MirrorViewInformation mirrorViewInformation = bcRequestData.getMirrorViewInformation();
            Helper.checkNull(logger, signature, mirrorViewInformation, "MirrorView Srdf Information");
            Helper.checkDecimal(logger, signature, mirrorViewInformation.getKnowledgeTransferHours(), 1,
                    "# hours of knowledge transfer (MirrorView Srdf Information)");
            Helper.checkNull(logger, signature, mirrorViewInformation.getNetworkLinkStatus(),
                    "MirrorView network link status");

            Map<String, Integer> hosts = mirrorViewInformation.getHostNumbers();
            if (hosts != null && !hosts.isEmpty()) {
                for (Entry<String, Integer> host : hosts.entrySet()) {
                    Helper.checkPositiveOrZero(logger, signature, host.getValue(), true,
                            "# of Hosts (MirrorView Source Host Information)");
                }
            }

            List<MirrorViewSourceArrayInformation> sourceArrayInformations = mirrorViewInformation
                    .getSourceArrayInformation();
            if (sourceArrayInformations != null && sourceArrayInformations.size() > 0) {
                for (MirrorViewSourceArrayInformation sourceArrayInformation : sourceArrayInformations) {
                    Helper.checkNull(logger, signature, sourceArrayInformation.getArrayModel(), "Array Model");
                    Helper.checkNull(logger, signature, sourceArrayInformation.getExistingOptionEnabled(),
                        "Existing or New");
                    Helper.checkPositiveOrZero(logger, signature, sourceArrayInformation.getReplicateSize(), true,
                            "# TB to Replicate");
                    Helper.checkNull(logger, signature, sourceArrayInformation.getMirrowViewInstalledStatus(),
                            "Current MV Status");
                    Helper.checkNull(logger, signature, sourceArrayInformation.getUniOptionEnabled(),
                            "Uni or Bi Directional");
                    Helper.checkNull(logger, signature, sourceArrayInformation.getMvConnectionType(),
                            "MV Connection");
                }
            }
            List<MirrorViewTargetArrayInformation> targetArrayInformations = mirrorViewInformation
                    .getTargetArrayInformation();
            if (targetArrayInformations != null && targetArrayInformations.size() > 0) {
                for (MirrorViewTargetArrayInformation targetArrayInformation : targetArrayInformations) {
                    Helper.checkNull(logger, signature, targetArrayInformation.getArrayModel(), "Array Model");
                    Helper.checkNull(logger, signature, targetArrayInformation.getExistingOptionEnabled(),
                            "Existing or New");
                    Helper.checkNull(logger, signature, targetArrayInformation.getMirrowViewInstalledStatus(),
                            "Current MV Status");
                }
            }
            Helper.checkNull(logger, signature, mirrorViewInformation.getMirrowViewScriptingLevel(),
                    "MirrorView process scripting requirements");
        }
        if (bcServicesScope.isSnapView()) {
            SnapViewInformation snapViewInformation = bcRequestData.getSnapViewInformation();
            Helper.checkNull(logger, signature, snapViewInformation, "SnapView Information");
            Helper.checkDecimal(logger, signature, snapViewInformation.getKnowledgeTransferHours(), 1,
                    "# hours of knowledge transfer (SnapView Information)");
            Map<String, Integer> hosts = snapViewInformation.getHostNumbers();
            if (hosts != null && !hosts.isEmpty()) {
                for (Entry<String, Integer> host : hosts.entrySet()) {
                    Helper.checkPositiveOrZero(logger, signature, host.getValue(), true,
                            "# of Hosts (SnapView Host Information)");
                }
            }

            Helper.checkPositiveOrZero(logger, signature, snapViewInformation.getReplicatedStorageSize(), true,
                    "TB of storage to be replicated");
            Helper.checkNull(logger, signature, snapViewInformation.getScriptingLevel(),
                    "Snapview Scripting Requirements");
            Helper.checkPositiveOrZero(logger, signature, snapViewInformation.getNumberOfSnapViewConsistentSessions(), 
                false, "# of Consistent Sessions for SnapView?");
            Helper.checkPositiveOrZero(logger, signature, snapViewInformation.getNumberOfSnapViewPersistentSessions(),
                false, "# of Persistent Sessions for SnapView?");
        }
        if (bcServicesScope.isSrdf()) {
            SrdfInformation srdfInformation = bcRequestData.getSrdfInformation();
            Helper.checkNull(logger, signature, srdfInformation, "SRDF Information");
            Helper.checkDecimal(logger, signature, srdfInformation.getKnowledgeTransferHours(), 1,
                    "# hours of knowledge transfer (SRDF Information)");
            Helper.checkNull(logger, signature, srdfInformation.getNetworkLinkStatus(), "SRDF network link status");
            Map<String, Integer> hosts = srdfInformation.getHostNumbers();
            if (hosts != null && !hosts.isEmpty()) {
                for (Entry<String, Integer> host : hosts.entrySet()) {
                    Helper.checkPositiveOrZero(logger, signature, host.getValue(), true,
                            "# of Hosts (SRDF Source Host Information)");
                }
            }
            List<SrdfSourceArrayInformation> srdfSourceArrayInformations = srdfInformation
                    .getSourceArrayInformation();
            if (srdfSourceArrayInformations != null && srdfSourceArrayInformations.size() > 0) {
                for (SrdfSourceArrayInformation srdfSourceArrayInformation : srdfSourceArrayInformations) {
                    Helper.checkNull(logger, signature, srdfSourceArrayInformation.getSymmetrixModel(),
                            "Symmetrix Model");
                    Helper.checkPositiveOrZero(logger, signature, srdfSourceArrayInformation.getReplicateSize(), true,
                        "# TB to Replicate");
                    Helper.checkPositiveOrZero(logger, signature,
                        srdfSourceArrayInformation.getNumOfSymmetrixRDFSourceDevices(), true,
                        "# of Symmetrix RDF Source Devices");
                    Helper.checkPositiveOrZero(logger, signature,
                        srdfSourceArrayInformation.getNumOfSymmetrixDevicesNeededAtRDFRemoteSites(), true,
                        "# of Symmetrix Devices Needed at SRDF Remote Sites");
                    Helper.checkNull(logger, signature, srdfSourceArrayInformation.getSrdfInstalledStatus(),
                            "Current SRDF Status");
                    Helper.checkNull(logger, signature, srdfSourceArrayInformation.getUniOptionEnabled(),
                            "Uni or Bi Directional");
                    Helper.checkNull(logger, signature, srdfSourceArrayInformation.getSrdfConnectionType(),
                            "SRDF Connection");
                }
            }
            List<SrdfTargetArrayInformation> srdfTargetArrayInformations = srdfInformation
                    .getTargetArrayInformation();
            if (srdfTargetArrayInformations != null && srdfTargetArrayInformations.size() > 0) {
                for (SrdfTargetArrayInformation srdfTargetArrayInformation : srdfTargetArrayInformations) {
                    Helper.checkNull(logger, signature, srdfTargetArrayInformation.getSymmetrixModel(),
                            "Symmetrix Model");
                    Helper.checkNull(logger, signature, srdfTargetArrayInformation.getSrdfInstalledStatus(),
                            "Current SRDF Status");
                }
            }
            Helper.checkNull(logger, signature, srdfInformation.getBcPractiveScriptingLevel2(),
                    "SRDF Process Scripting Requirements");
        }
        if (bcServicesScope.isTimeFinder()) {
            TimeFinderInformation timeFinderInformation = bcRequestData.getTimeFinderInformation();
            Helper.checkNull(logger, signature, timeFinderInformation, "TimeFinder Information");
            Helper.checkDecimal(logger, signature, timeFinderInformation.getKnowledgeTransferHours(), 1,
                    "# hours of knowledge transfer (TimeFinder Information)");
            Map<String, Integer> hosts = timeFinderInformation.getHostNumbers();
            if (hosts != null && !hosts.isEmpty()) {
                for (Entry<String, Integer> host : hosts.entrySet()) {
                    Helper.checkPositiveOrZero(logger, signature, host.getValue(), true,
                            "# of Hosts (TimeFinder Host Information)");
                }
            }
            Helper.checkNull(logger, signature, timeFinderInformation.getConfigChangeType(),
                    "Do target devices need to be created via config change?");
            Helper.checkPositive(logger, signature, timeFinderInformation.getReplicatedStorageSize(),
                    "TB of storage to be replicated");
            Helper.checkNull(logger, signature, timeFinderInformation.getScriptingLevel(),
                    "TimeFinder process scripting requirements");
        }
        if (bcServicesScope.isReplicationServices()) {
            ReplicationManagerInformation replicationManagerInformation = bcRequestData
                    .getReplicationManagerInformation();
            Helper.checkNull(logger, signature, replicationManagerInformation, "Replication Manager Information");
            Helper.checkDecimal(logger, signature, replicationManagerInformation.getKnowledgeTransferHours(), 1,
                    "# hours of knowledge transfer (Replication Manager Information)");
            Helper.checkNull(logger, signature,
                    replicationManagerInformation.getReplicationManagerImplementation(),
                    "Type of replication manager implementation");
            Helper.checkPositiveOrZero(logger, signature,
                    replicationManagerInformation.getReplicatedStorageSize(), true,
                    "TB of storage to be replicated");
            Helper.checkNull(logger, signature, replicationManagerInformation.getConfigChangeType(),
                    "Do target devices need to be created via config change?");
            Helper.checkPositive(logger, signature, replicationManagerInformation.getManagerServersNumber(),
                    "# of replication manager servers (Windows only)");
            Helper.checkNull(logger, signature, replicationManagerInformation.isClusteredRmServerOption(),
                    "Will the RM server(s) be clustered?");

            Map<String, Integer> sourceHosts = replicationManagerInformation.getSourceHostNumber();
            if (sourceHosts != null && !sourceHosts.isEmpty()) {
                for (Entry<String, Integer> sourceHost : sourceHosts.entrySet()) {
                    Helper.checkPositiveOrZero(logger, signature, sourceHost.getValue(), true,
                            "# of Hosts (Replication Manager Source Hosts Information)");
                }
            }
            Map<String, Integer> targetHosts = replicationManagerInformation.getTargetHostNumber();
            if (targetHosts != null && !targetHosts.isEmpty()) {
                for (Entry<String, Integer> targetHost : targetHosts.entrySet()) {
                    Helper.checkPositiveOrZero(logger, signature, targetHost.getValue(), true,
                            "# of Hosts (Replication Manager Mount Host Information)");
                }
            }
            Helper.checkNull(logger, signature, replicationManagerInformation.isCustomScriptingRequired(),
                    "Is custom scripting required?");
            Helper.checkNull(logger, signature, replicationManagerInformation.isClusteredRmServerOption(),
                    "Will the RM server(s) be clustered?");
        }
        if (unifiedRequestData != null) {
            UnifiedServicesScope unifiedServicesScope = unifiedRequestData.getServicesScope();
            if (unifiedServicesScope.isNasIpReplication()) {
                Helper.checkDecimal(logger, signature, bcRequestData.getNasIpReplicationKnowledgeTransferHours(),
                        1, "# hours of knowledge transfer (IP Replication)");
                List<NasIpReplicationInformation> nasIpReplicationInformations = bcRequestData
                        .getNasIpReplicationInformation();
                if (nasIpReplicationInformations != null && nasIpReplicationInformations.size() > 0) {
                    for (NasIpReplicationInformation nasIpReplicationInformation : nasIpReplicationInformations) {
                        Helper.checkNull(logger, signature, nasIpReplicationInformation.getCelerraDeviceType(),
                                "Source / Target");
                        Helper.checkPositive(logger, signature,
                                nasIpReplicationInformation.getNewFileSystemReplicationNumber(),
                                "# of Filesystems to be newly replicated from Source");
                    }
                }
            }
        }
    }

    /**
     * Validates the mainframe request data.
     *
     * @param mainframeRequestData
     *         the mainframe request data
     */
    private void validateMainframe(MainframeRequestData mainframeRequestData) {
        final String signature = CLASSNAME + "#validateMainframe()";
        Logger logger = getLogger();
        Helper.checkNull(logger, signature, mainframeRequestData, "Mainframe Request Data");
        MainframeServicesScope servicesScope = mainframeRequestData.getServicesScope();
        Map<String, ServiceData> serviceDataMap = new HashMap<String, ServiceData>();
        List<BooleanServiceData> booleanServiceData = mainframeRequestData.getBooleanServiceData();
        for (BooleanServiceData bsd : booleanServiceData) {
            serviceDataMap.put(bsd.getServiceName(), bsd);
        }
        List<StringServiceData> stringServiceData = mainframeRequestData.getStringServiceData();
        for (StringServiceData ssd : stringServiceData) {
            serviceDataMap.put(ssd.getServiceName(), ssd);
        }
        if (servicesScope.isDataAnalyticsHealthcheck()) {
            validateMainframeServiceField(logger, signature, serviceDataMap.get("DAS-01 Flash analysis"),
                    "Flash analysis");
            validateMainframeServiceField(logger, signature,
                    serviceDataMap.get("DAS-10 TimeFinder snap sizing analysis"),
                    "TimeFinder snap sizing analysis");
        }
        if (servicesScope.isEzsmEccInfoMover()) {
            validateMainframeServiceField(logger, signature,
                    serviceDataMap.get("MSS-01 EzSM install and knowledge sharing"),
                    "EzSM install and knowledge sharing");
            validateMainframeServiceField(logger, signature,
                    serviceDataMap.get("MSS-02 ECC install and knowledge sharing"),
                    "ECC install and knowledge sharing");
            validateMainframeServiceField(logger, signature,
                    serviceDataMap.get("MSS-03 InfoMover Implementation"), "InfoMover Implementation");
        }
        if (servicesScope.isDmxVmaxDataMigration()) {
            validateMainframeServiceField(logger, signature,
                    serviceDataMap.get("DSM-01 zMigrator Volume Migration"), "zMigrator Volume Migration");
            validateMainframeServiceField(logger, signature,
                    serviceDataMap.get("DSM-03 zMigrator DataSet Migration"), "zMigrator DataSet Migration");
            validateMainframeServiceField(logger, signature, serviceDataMap.get("DSM-05 SRDF Migration"),
                    "SRDF Migration");
            validateMainframeServiceField(logger, signature, serviceDataMap.get("DSM-09 Maintain replication"),
                    "Maintain replication");
            validateMainframeServiceField(logger, signature, serviceDataMap.get("DSM-11 iSeries Host Migration"),
                    "iSeries Host Migration");
        }
        if (servicesScope.isDmxVmaxHardwareImplementation()) {
            validateMainframeServiceField(logger, signature,
                    serviceDataMap.get("DSH-01 Virtual Provisioning Design"), "Virtual Provisioning Design");
            validateMainframeServiceField(logger, signature, serviceDataMap.get("DSH-04 Implement VP"),
                    "Implement VP");
            validateMainframeServiceField(logger, signature, serviceDataMap.get("DSH-07 Implement Fast VP"),
                    "Implement Fast VP");
            validateMainframeServiceField(logger, signature,
                    serviceDataMap.get("DSH-10 Non-Replicated Hardware Design"), "Non-Replicated Hardware Design");
            validateMainframeServiceField(logger, signature,
                    serviceDataMap.get("DSH-13 FICON Director Implementation"), "FICON Director Implementation");
            validateMainframeServiceField(logger, signature, serviceDataMap.get("DSH-14 Vendor"), "Vendor");
            validateMainframeServiceField(logger, signature,
                    serviceDataMap.get("DSH-17 Replication (SRDF/IBM) Hardware Design"),
                    "Replication (SRDF/IBM) Hardware Design");
        }
        if (servicesScope.isDmxVmaxSrdf()) {
            validateMainframeServiceField(logger, signature,
                    serviceDataMap.get("DSS-01 SRDF - A New Implementation"), "SRDF - A New Implementation");
            validateMainframeServiceField(logger, signature,
                    serviceDataMap.get("DSS-05 SRDF - A New Implementation"), "SRDF - A Refresh/Upgrade");
            validateMainframeServiceField(logger, signature, serviceDataMap.get("DSS-09 SRDF - A MSC Option"),
                    "SRDF - A MSC Option");
            validateMainframeServiceField(logger, signature,
                    serviceDataMap.get("DSS-11 SRDF - A Auto Recovery Option"), "SRDF - A Auto Recovery Option");
            validateMainframeServiceField(logger, signature,
                    serviceDataMap.get("DSS-12 SRDF - A 75 Code Enhancements"), "SRDF - A 75 Code Enhancements");
            validateMainframeServiceField(logger, signature,
                    serviceDataMap.get("DSS-13 SRDF - S New Implementation"), "SRDF - S New Implementation");
            validateMainframeServiceField(logger, signature,
                    serviceDataMap.get("DSS-17 SRDF - S Consistency Group Option"),
                    "SRDF - S Consistency Group Option");
            validateMainframeServiceField(logger, signature,
                    serviceDataMap.get("DSS-18 SRDF - AR New Implementation"), "SRDF - AR New Implementation");
            validateMainframeServiceField(logger, signature,
                    serviceDataMap.get("DSS-22 SRDF - AR Refresh/Upgrade"), "SRDF - AR Refresh/Upgrade");
            validateMainframeServiceField(logger, signature,
                    serviceDataMap.get("DSS-27 SRDF Conversion Static -> Dynamic"),
                    "SRDF Conversion Static -> Dynamic");
        }
        if (servicesScope.isDmxVmaxTimeFinder()) {
            validateMainframeServiceField(logger, signature,
                    serviceDataMap.get("DST-01 TimeFinder Hardware Design"), "TimeFinder Hardware Design");
            validateMainframeServiceField(logger, signature,
                    serviceDataMap.get("DST-04 TimeFinder Clone New Implementation"),
                    "TimeFinder Clone New Implementation");
            validateMainframeServiceField(logger, signature,
                    serviceDataMap.get("DST-07 TimeFinder Clone Refresh/Upgrade"),
                    "TimeFinder Clone Refresh/Upgrade");
            validateMainframeServiceField(logger, signature,
                    serviceDataMap.get("DST-10 TimeFinder Volume Snap New Implementation"),
                    "TimeFinder Volume Snap New Implementation");
            validateMainframeServiceField(logger, signature,
                    serviceDataMap.get("DST-13 TimeFinder Volume Snap Refresh/ Upgrade"),
                    "TimeFinder Volume Snap Refresh/ Upgrade");
            validateMainframeServiceField(logger, signature,
                    serviceDataMap.get("DST-16 TimeFinder Dataset Snap New Implementation"),
                    "TimeFinder Dataset Snap New Implementation");
            validateMainframeServiceField(logger, signature,
                    serviceDataMap.get("DST-19 TimeFinder Dataset Snap Refresh/Upgrade"),
                    "TimeFinder Dataset Snap Refresh/Upgrade");
            validateMainframeServiceField(logger, signature,
                    serviceDataMap.get("DST-24 TimeFinder convert from BCV to Clone"),
                    "TimeFinder convert from BCV to Clone");
        }
        if (servicesScope.isDmxVmaxAutoswapGddr()) {
            validateMainframeServiceField(logger, signature, serviceDataMap.get("RA-01 GDDR Implementation"),
                    "GDDR Implementation");
            validateMainframeServiceField(logger, signature, serviceDataMap.get("RA-05 Autoswap"), "Autoswap");
        }
        if (servicesScope.isDlmDataMigration()) {
            validateMainframeServiceField(logger, signature, serviceDataMap.get("DM-01 Normal Tape Migration"),
                    "Normal Tape Migration");
            validateMainframeServiceField(logger, signature,
                    serviceDataMap.get("DM-04 Block Level Tape Migration"), "Block Level Tape Migration");
            validateMainframeServiceField(logger, signature,
                    serviceDataMap.get("DM-05 Average Throughput Estimate (TBs/Day)"),
                    "Average Throughput Estimate (TBs/Day)");
            validateMainframeServiceField(logger, signature,
                    serviceDataMap.get("DM-07 DLm IP Replicator Based Migration"),
                    "DLm IP Replicator Based Migration");
        }
        if (servicesScope.isDlmImplementUpgrade()) {
            validateMainframeServiceField(logger, signature,
                    serviceDataMap.get("D2SH-01 DLm new NS/VNX hardware impl. (DLm 2000/6000, 120/960)"),
                    "DLm new NS/VNX hardware impl. (DLm 2000/6000, 120/960)");
            validateMainframeServiceField(logger, signature,
                    serviceDataMap.get("D2SH-05 DLm 2000 POC hardware implementation"),
                    "DLm 2000 POC hardware implementation");
            validateMainframeServiceField(logger, signature,
                    serviceDataMap.get("D2SH-09 DLm new DD hardware implementation"),
                    "DLm new DD hardware implementation");
            validateMainframeServiceField(logger, signature,
                    serviceDataMap.get("D1SH-05 DD Capacity Add Service"), "DD Capacity Add Service");
            validateMainframeServiceField(logger, signature,
                    serviceDataMap.get("D2SH-17 Expand current filesystems"), "Expand current filesystems");
            validateMainframeServiceField(logger, signature,
                    serviceDataMap.get("D2SH-18 DLm capacity add service (4020/4080 and DLm 120/960)"),
                    "DLm capacity add service (4020/4080 and DLm 120/960)");
            validateMainframeServiceField(logger, signature,
                    serviceDataMap.get("D2SH-21 Expand current filesystems"), "Expand current filesystems");
            validateMainframeServiceField(logger, signature, serviceDataMap.get("D2SH-22 Add new filesystems"),
                    "Add new filesystems");
            validateMainframeServiceField(logger, signature,
                    serviceDataMap.get("D2SH-23 DLm capacity add service (DLm 2000/6000)"),
                    "DLm capacity add service (DLm 2000/6000)");
            validateMainframeServiceField(logger, signature,
                    serviceDataMap.get("D2SH-26 DLm storage controller add (DLm 2000/6000)"),
                    "DLm storage controller add (DLm 2000/6000)");
            validateMainframeServiceField(logger, signature,
                    serviceDataMap.get("D2SSD-01 DLm new implementation"), "DLm new implementation");
            validateMainframeServiceField(logger, signature, serviceDataMap.get("D2SSD-02 DLm 960/120"),
                    "DLm 960/120");
            validateMainframeServiceField(logger, signature, serviceDataMap.get("D2SSD-03 DLm 6000"), "DLm 6000");
            validateMainframeServiceField(logger, signature, serviceDataMap.get("D2SSD-04 DLm 2000"), "DLm 2000");
            validateMainframeServiceField(logger, signature, serviceDataMap.get("D2SSD-08 DLm 2000 POC"),
                    "DLm 2000 POC");
            validateMainframeServiceField(logger, signature,
                    serviceDataMap.get("D2SSD-11 DLm 2000/6000 Upgrade/Tech Refresh"),
                    "DLm 2000/6000 Upgrade/Tech Refresh");
        }
        if (servicesScope.isDlmReconfigureAddMove()) {
            validateMainframeServiceField(logger, signature,
                    serviceDataMap.get("DSRAM-02 DLm storage redesign (DLm 4020/4080,120/960)"),
                    "DLm storage redesign (DLm 4020/4080,120/960)");
            validateMainframeServiceField(logger, signature,
                    serviceDataMap.get("DSRAM-07 DLm storage redesign service (DLm 2000/6000)"),
                    "DLm storage redesign service (DLm 2000/6000)");
            validateMainframeServiceField(logger, signature, serviceDataMap.get("DSRAM-13 DLm Snap"), "DLm Snap");
            validateMainframeServiceField(logger, signature,
                    serviceDataMap.get("DSRAM-16 DLm Virtuent 6 to 7 Upgrade"), "DLm Virtuent 6 to 7 Upgrade");
            validateMainframeServiceField(logger, signature,
                    serviceDataMap.get("DSRAM-20 DLm Add Replication Site"), "DLm Add Replication Site");
            validateMainframeServiceField(logger, signature, serviceDataMap.get("DSRAM-23 DLm Relocate"),
                    "DLm Relocate");
            validateMainframeServiceField(logger, signature, serviceDataMap.get("DSRAM-26 DLm Removal"),
                    "DLm Removal");
            validateMainframeServiceField(logger, signature,
                    serviceDataMap.get("DSRAM-29 DLm Unisys Lead - EMC DLm Install Services"),
                    "DLm Unisys Lead - EMC DLm Install Services");
        }
        if (servicesScope.isDlmScripting()) {
            validateMainframeServiceField(logger, signature,
                    serviceDataMap.get("D2S-01 DLm snapshot DR testing scripts (1 site, 1 DLM, and 1 snap)"),
                    "DLm snapshot DR testing scripts (1 site, 1 DLM, and 1 snap)");
        }
        if (servicesScope.isDlmServices()) {
            validateMainframeServiceField(logger, signature,
                    serviceDataMap.get("D1SH-01 DD Hardware Implementation"), "DD Hardware Implementation");
            validateMainframeServiceField(logger, signature,
                    serviceDataMap.get("D1SH-05 DD Capacity Add Service"), "DD Capacity Add Service");
            validateMainframeServiceField(logger, signature,
                    serviceDataMap.get("D1SH-09 Expand current filesystems"), "Expand current filesystems");
            validateMainframeServiceField(logger, signature, serviceDataMap.get("D1SH-10 Add new filesystems"),
                    "Add new filesystems");
            validateMainframeServiceField(logger, signature,
                    serviceDataMap.get("D1SS-01 DLm 1010/1020 new implementation"),
                    "DLm 1010/1020 new implementation");
            validateMainframeServiceField(logger, signature,
                    serviceDataMap.get("D1SS-05 DLm 1010/1020 tech refresh"), "DLm 1010/1020 tech refresh");
            validateMainframeServiceField(logger, signature, serviceDataMap.get("D1SS-12 DLm 1010/1020 snap"),
                    "DLm 1010/1020 snap");
            validateMainframeServiceField(logger, signature,
                    serviceDataMap.get("D1SS-15 DLm 1010/1020 add replication site"),
                    "DLm 1010/1020 add replication site");
            validateMainframeServiceField(logger, signature, serviceDataMap.get("D1SS-20 DLm 1010/1020 relocate"),
                    "DLm 1010/1020 relocate");
        }
        if (servicesScope.isDlmImplementation()) {
            validateMainframeServiceField(logger, signature,
                    serviceDataMap.get("D8SH-01 Replication Hardware Design"), "Replication Hardware Design");
            validateMainframeServiceField(logger, signature, serviceDataMap.get("D8SH-09 VTE Implementation"),
                    "VTE Implementation");
            validateMainframeServiceField(logger, signature,
                    serviceDataMap.get("D8SH-13 SRDF-S New Implementation"), "SRDF-S New Implementation");
            validateMainframeServiceField(logger, signature,
                    serviceDataMap.get("D8SH-17 SRDF-A New Implementation"), "SRDF-A New Implementation");
            validateMainframeServiceField(logger, signature,
                    serviceDataMap.get("D8SH-23 TimeFinder Clone New Implementation"),
                    "TimeFinder Clone New Implementation");
            validateMainframeServiceField(logger, signature,
                    serviceDataMap.get("D8SH-31 DLm 2 Site Standard Scripted Replication Solution"),
                    "DLm 2 Site Standard Scripted Replication Solution");
        }
    }

    /**
     * Validates a mainframe service field
     *
     * @param logger
     *         the logger object
     * @param signature
     *         the signature of the method to be logged.
     * @param serviceData
     *         the service field
     * @param label
     *         the field label
     */
    private void validateMainframeServiceField(Logger logger, String signature, ServiceData serviceData,
                                               String label) {
        Helper.checkNull(logger, signature, serviceData, label);
        if (serviceData instanceof BooleanServiceData) {
            Helper.checkNull(logger, signature, ((BooleanServiceData) serviceData).getEnabled(), label);
        } else if (serviceData instanceof StringServiceData) {
            Helper.checkNull(logger, signature, ((StringServiceData) serviceData).getValue(), label);
            Helper.checkNull(logger, signature, ((StringServiceData) serviceData).getDescription(), label);
        }
    }

    /**
     * Validates the Unified request data.
     *
     * @param unifiedRequestData
     *         the Unified request data
     * @param infrastructureRequestData
     *         the Infrastructure request data
     */
    private void validateUnified(UnifiedRequestData unifiedRequestData,
                                 InfrastructureRequestData infrastructureRequestData) {
        final String signature = CLASSNAME + "#validateUnified()";
        Logger logger = getLogger();
        Helper.checkNull(logger, signature, unifiedRequestData, "Unified Request Data");

        UnifiedServicesScope servicesScope = unifiedRequestData.getServicesScope();
        List<CelerraDetailInformation> celerraDetailInformations = unifiedRequestData
                .getCelerraDetailInformation();

        if (celerraDetailInformations != null && !celerraDetailInformations.isEmpty()) {
            Helper.checkDecimal(logger, signature, unifiedRequestData.getCelerraDetailKnowledgeTransferHours(), 1,
                    "# hours of knowledge transfer (Celerra)");
            VnxClariionInformation vci = infrastructureRequestData.getVnxClariionInformation();
            if (vci != null) {
                VnxInstallProtocolType vnxInstallProtocolType = vci.getVnxInstallProtocolType();

                boolean vnxFileAll = vnxInstallProtocolType != null
                        && "File Only (CIFS/NFS)".equals(vnxInstallProtocolType.getName());
                boolean vnxFileStandardComplex = vnxInstallProtocolType != null
                        && ("File Only (CIFS/NFS)".equals(vnxInstallProtocolType.getName()));
                boolean vnxFileCifsStandardComplex = vnxFileStandardComplex;
                boolean vnxFileNfsStandardComplex = vnxFileStandardComplex;
                boolean vnxAllStandardComplex = true;
                boolean celerraImplementation = servicesScope.isCelerraImplementation();
                for (CelerraDetailInformation detailInformation : celerraDetailInformations) {
                    if (celerraImplementation && vnxFileAll) {
                        Helper.checkNull(logger, signature, detailInformation.getCelerraModel(),
                                "Select the model for each Celerra");
                    }
                    if (celerraImplementation) {
                        Helper.checkStrNullEmpty(logger, signature, detailInformation.getCelerraLocation(),
                                "VNX Location (City, State)");
                    }
                    if (celerraImplementation && vnxFileAll) {
                        Helper.checkNull(logger, signature, detailInformation.getNewCelerraOption(),
                                "New or Existing Celerra?");
                    }
                    Helper.checkNull(logger, signature, detailInformation.getRackAndStackOption(),
                            "Include \"rack and stack\" as part of custom quote?");
                    Helper.checkNull(logger, signature, detailInformation.getGatewayStorageType(),
                            "Storage hardware for the Gateway");
                    Helper.checkNull(logger, signature, detailInformation.getNewSymmetrixStorageOption(),
                            "New or existing Symmetrix storage for the Gateway?");
                    if (vnxFileAll) {
                        Helper.checkNull(logger, signature, detailInformation.getDualControlStationsUsed(),
                                "Dual Control Stations to be used?");
                        Helper.checkPositiveOrZero(logger, signature, detailInformation.getDatamoversNumber(),
                                true, "# of New Datamovers - per Celerra");
                        Helper.checkPositive(logger, signature, detailInformation.getUsableStorageSize(),
                                "Usable Storage to be allocated to NAS (TB) - per NAS array");
                        Helper.checkPositive(logger, signature, detailInformation.getFileSystemNumber(),
                                "# of Filesystems to be created for NAS (TB) per NAS array");
                        Helper.checkNull(logger, signature, detailInformation.getNfsConfigured(),
                                "Configure NFS? - per NAS array");
                        Helper.checkNull(logger, signature, detailInformation.getCifsConfigured(),
                                "Configure CIFS? - per NAS array");
                        Helper.checkNull(logger, signature, detailInformation.getMultiprotocolCelerraConfigured(),
                                "Configure Celerra/VNX as MultiProtocol? - per NAS array");
                    }
                    Helper.checkNull(logger, signature, detailInformation.getFileFastVpConfigured(),
                            "Configure FAST VP for File?");

                    if (vnxFileStandardComplex) {
                        Helper.checkNull(logger, signature, detailInformation.getNasFeatures(),
                                "NAS Features Required");
                    }
                    if (vnxFileCifsStandardComplex) {
                        Helper.checkNull(logger, signature, detailInformation.getCifsFeaturesIncluded(),
                                "Include CIFS Advanced Features?");
                    }
                    if (vnxFileStandardComplex) {
                        Helper.checkNull(logger, signature, detailInformation.getLdapRequired(),
                                "LDAP Integration Required? - per NAS array");
                    }
                    if (vnxFileNfsStandardComplex) {
                        Helper.checkNull(logger, signature, detailInformation.getNfsv4Configured(),
                                "NFSv4 Required? - per Celerra");
                        Helper.checkNull(logger, signature, detailInformation.getIncludeNfsOverFc(),
                                "Include pNFS over FC?");
                        Helper.checkNull(logger, signature, detailInformation.getIncludeNfsOverIScsi(),
                                "Include pNFS over iSCSI?");
                    }
                    if (vnxAllStandardComplex) {
                        Helper.checkNull(logger, signature, detailInformation.getIpReplicationConfigured(),
                                "Is IP Replication currently configured on this Celerra?");
                        Helper.checkNull(logger, signature, detailInformation.getDeinstallCelera(),
                                "Deinstall this Celerra?");
                    }
                    if (vnxFileStandardComplex) {
                        Integer cavaServerNumber = detailInformation.getCavaServerNumber();
                        Helper.checkPositiveOrZero(logger, signature, cavaServerNumber, true,
                                "# of CAVA servers to be configured - Total");
                        if (cavaServerNumber > 200) {
                            throw new IllegalArgumentException(
                                    "'# of CAVA servers to be configured - Total' must be less or equal with 200.");
                        }
                    }
                    if (servicesScope.isMpfs()) {
                        Helper.checkNull(logger, signature, detailInformation.getMpfsRequired(),
                                "MPFS hosts to be configured? - per Celerra");
                        Helper.checkPositive(logger, signature, detailInformation.getMpfsHostQuantity(),
                                "MPFS host quantity - per Celerra");
                        Helper.checkPositive(logger, signature, detailInformation.getMpfsFileSystemsQuantity(),
                                "MPFS file systems - per Celerra");
                        Helper.checkNull(logger, signature, detailInformation.getMpfsiRequired(),
                                "MPFSi hosts to be configured? - per Celerra");
                        Helper.checkPositive(logger, signature, detailInformation.getMpfsiHostQuantity(),
                                "MPFSi host quantity - per Celerra");
                        Helper.checkPositive(logger, signature, detailInformation.getMpfsiFileSystemsQuantity(),
                                "MPFSi file systems - per Celerra");
                    }
                }
            }
        }
        if (servicesScope.isFileNasMigration()) {
            Helper.checkDecimal(logger, signature, unifiedRequestData.getNasMigrationKnowledgeTransferHours(), 1,
                "# hours of knowledge transfer (Nas Migration)");
            List<NasMigrationInformation> migrationInformations = unifiedRequestData.getNasMigrationInformation();
            if (migrationInformations != null && migrationInformations.size() > 0) {
                for (NasMigrationInformation migrationInformation : migrationInformations) {
                    Helper.checkNull(logger, signature, migrationInformation.getCelerraVnxModel(),
                            "Select the model for each Celerra/VNX");
                    Helper.checkNull(logger, signature, migrationInformation.getLocation(),
                            "Location (City, State)");
                    Helper.checkNull(logger, signature, migrationInformation.getTargetCelerra(),
                            "Target Celerra - per source type");
                    Helper.checkNull(logger, signature, migrationInformation.getAverageFileSize(),
                            "What is the average file size? - per source");
                    Helper.checkPositiveOrZero(logger, signature, migrationInformation.getCifsDataSize(), true,
                            "# of TB of CIFS data - per Celerra, NetApp or Windows source");
                    Helper.checkPositiveOrZero(logger, signature, migrationInformation.getCifsFilesystemNumber(),
                            true, "# of CIFS Filesystems");
                    Helper.checkNull(logger, signature, migrationInformation.getCifsLocalGroupOption(),
                            "Local groups used within CIFS Filesystems? - per source");
                    Helper.checkPositiveOrZero(logger, signature, migrationInformation.getNfsDataSizeNumber(),
                            true, "# of TB of NFS data - per Celerra, NetApp or UNIX source");
                    Helper.checkPositiveOrZero(logger, signature, migrationInformation.getNfsFilesystemNumber(),
                            true, "# of NFS Filesystems");
                    Helper.checkPositiveOrZero(logger, signature, migrationInformation.getBimodalDataSizeNumber(),
                            true, "# of TB of Bimodal data - per Celerra or NetApp source");
                    Helper.checkPositiveOrZero(logger, signature,
                            migrationInformation.getBimodalFilesystemNumber(), true, "# of Bimodal Filesystems");
                    Helper.checkNull(logger, signature, migrationInformation.getCertifiedDataMigrationOption(),
                            "Do you require a backend Certified Data Erasure after migration?");
                    Integer migrationWindowLength = migrationInformation.getMigrationWindowLength();
                    Helper.checkPositive(logger, signature, migrationWindowLength,
                            "Migration window length (hours)");
                    if (migrationWindowLength > 72) {
                        throw new IllegalArgumentException(
                                "'Migration window length (hours)' must be less or equal with 72.");
                    }
                    Integer migrationWindowsCustomerNumber = migrationInformation
                            .getMigrationWindowsCustomerNumber();
                    Helper.checkPositive(logger, signature, migrationWindowsCustomerNumber,
                            "# of migration windows customer expects");
                    if (migrationWindowLength > 100) {
                        throw new IllegalArgumentException(
                                "'# of migration windows customer expects' must be less or equal with 100.");
                    }
                }
            }
        }
    }

    /**
     * Validates the infrastructure request data.
     *
     * @param infrastructureRequestData
     *         the infrastructure request data
     */
    private void validateInfrastructure(InfrastructureRequestData infrastructureRequestData) {
        final String signature = CLASSNAME + "#validateInfrastructure()";
        Logger logger = getLogger();
        Helper.checkNull(logger, signature, infrastructureRequestData, "Infrastucture Request Data");

        EnvironmentDetailsInformation environmentDetailsInformation = infrastructureRequestData
                .getEnvironmentDetailsInformation();
        Helper.checkNull(logger, signature, environmentDetailsInformation, "Environment Details Information");
        EnvironmentGatherer environmentGatherer = environmentDetailsInformation.getEnvironmentGatherer();
        Helper.checkNull(logger, signature, environmentGatherer,
                "Who will be gathering current environment information?");
        if ("ECA".equals(environmentGatherer.getName())) {
            Helper.checkPositiveOrZero(logger, signature, environmentDetailsInformation.getDcaAppliancesNumber1(),
                    true, "# of ECA appliances to install and use to collect host data");
        }
        Helper.checkNull(logger, signature, environmentDetailsInformation.getHostSoftwareInstaller(),
                "Who installs host software?");

        Helper.checkNull(logger, signature, environmentDetailsInformation.getSanImplementator(),
                "environmentDetailsInformation.getEnvironmentGatherer()");

        List<EnvironmentArrayType> existingArrayTypes = environmentDetailsInformation.getExistingArrayTypes();
        if (existingArrayTypes != null && !existingArrayTypes.isEmpty()) {
            for (EnvironmentArrayType environmentArrayType : existingArrayTypes) {
                Helper.checkStrNullEmpty(logger, signature, environmentArrayType.getName(),
                        "Existing Array Type (Current Storage Array Information (In Scope Components Only))");
            }
        }

        List<Double> usableCapacities = environmentDetailsInformation.getUsableCapacities();
        if (usableCapacities != null && !usableCapacities.isEmpty()) {
            for (Double usableCapacity : usableCapacities) {
                Helper.checkPositive(logger, signature, usableCapacity,
                        "Usable Capacity (TB) (Current Storage Array Information (In Scope Components Only))");
            }
        }

        List<Integer> numberOfAttachedHosts = environmentDetailsInformation.getNumberOfAttachedHosts();
        if (numberOfAttachedHosts != null && !numberOfAttachedHosts.isEmpty()) {
            for (Integer numberOfAttachedHost : numberOfAttachedHosts) {
                Helper.checkPositive(logger, signature, numberOfAttachedHost,
                        "# of Attached Hosts (Current Storage Array Information (In Scope Components Only))");
            }
        }

        List<EnvironmentDeviceType> environmentDeviceTypes = environmentDetailsInformation
                .getEnvironmentDeviceTypes();
        if (environmentDeviceTypes != null && !environmentDeviceTypes.isEmpty()) {
            for (EnvironmentDeviceType environmentDeviceType : environmentDeviceTypes) {
                Helper.checkStrNullEmpty(logger, signature, environmentDeviceType.getName(),
                        "Device Type (Current SAN Information (In Scope Components Only))");
            }
        }

        List<Double> deviceQuantities = environmentDetailsInformation.getDeviceQuantities();
        if (deviceQuantities != null && !deviceQuantities.isEmpty()) {
            for (Double deviceQuantitie : deviceQuantities) {
                Helper.checkPositive(logger, signature, deviceQuantitie,
                        "Device Quantity (Current SAN Information (In Scope Components Only))");
            }
        }

        List<EnvironmentDetailsHostInfo> environmentHosts = environmentDetailsInformation.getHostInformation();
        if (environmentHosts != null && !environmentHosts.isEmpty()) {
            for (EnvironmentDetailsHostInfo environmentHost : environmentHosts) {
                Helper.checkPositiveOrZero(logger, signature, environmentHost.getHostNumber(), true,
                    "# of Hosts (Host Information (In Scope Components Only))");
                Helper.checkPositiveOrZero(logger, signature, environmentHost.getNumberOfClusters(), true,
                    "# of Clusters (Host Information (In Scope Components Only))");
            }
        }

        Helper.checkPositiveOrZero(logger, signature, environmentDetailsInformation.getExistingSanFabricsNumber(),
                true, "# of existing SAN fabrics");

        validateSymmetrix(infrastructureRequestData.getSymmetrixMF(),
            infrastructureRequestData.getSymmetrixMFServiceEnabled());
        validateSymmetrix(infrastructureRequestData.getSymmetrixOS(),
            infrastructureRequestData.getSymmetrixOSServiceEnabled());
        
        if (infrastructureRequestData.isDataMigrationServiceEnabled()) {
            DataMigrationInformation dataMigrationInformation = infrastructureRequestData
                    .getDataMigrationInformation();
            Helper.checkNull(logger, signature, dataMigrationInformation, "Data Migration Information");
            Helper.checkDecimal(logger, signature, dataMigrationInformation.getKnowledgeTransferHours(), 1,
                    "# hours of knowledge transfer (Block Data Migration)");
        }

        VnxClariionInformation vnxClariionInformation = infrastructureRequestData.getVnxClariionInformation();
        boolean vnxClariionServiceEnabled = infrastructureRequestData.isVnxClariionServiceEnabled();
        boolean cxReplicationServiceEnabled = infrastructureRequestData.isCxReplicationServiceEnabled();
        if (vnxClariionServiceEnabled || cxReplicationServiceEnabled) {
            Helper.checkNull(logger, signature, vnxClariionInformation, "VNX Block Information");
            Helper.checkDecimal(logger, signature, vnxClariionInformation.getKnowledgeTransferHours(), 1,
                    "# hours of knowledge transfer (VNX Block)");
            Helper.checkPositiveOrZero(logger, signature, vnxClariionInformation.getVnxArraysNumber(), true,
                    "# of new VNX arrays to be installed");
        }
        if (vnxClariionServiceEnabled) {
            Helper.checkPositiveOrZero(logger, signature, vnxClariionInformation.getUnisphereDomainsNumber(),
                    true, "# of UniSphere domains to configure");
            Helper.checkPositiveOrZero(logger, signature, vnxClariionInformation.getFastCacheSetupNumber(), true,
                    "# of arrays to implement FAST Cache setup");
            Helper.checkPositiveOrZero(logger, signature,
                    vnxClariionInformation.getVirtualProvisioningArraysNumber(), true,
                    "# of arrays to implement Virtual Provisioning");
            Helper.checkPositiveOrZero(logger, signature,
                    vnxClariionInformation.getCertifiedDiskErasureArraysNumber(), true,
                    "# of CX/NS arrays to execute Certified Disk Erasure");
            Helper.checkPositiveOrZero(logger, signature, vnxClariionInformation.getDeinstallCxNsVnxNumber(),
                    true, "# of CX/NS/VNX arrays to be deinstalled for a move");
        }

        if (infrastructureRequestData.getVplexServiceEnabled()) {
            validateVplex(infrastructureRequestData.getVplex());
        }


    }

    private void validateSymmetrix(SymmetrixInformationBase symmetrixInformation, boolean symmetrixServiceEnabled) {
        final String signature = CLASSNAME + "#validateSymmetrix()";
        Logger logger = getLogger();

        if (symmetrixServiceEnabled) {
            Helper.checkNull(logger, signature, symmetrixInformation, "Symmetrix Information");
            Helper.checkDecimal(logger, signature, symmetrixInformation.getKnowledgeTransferHours(), 1,
                    "# hours of knowledge transfer (Symmetrix)");

            Helper.checkPositiveOrZero(logger, signature,
                    symmetrixInformation.getVirtualProvisioningArraysNumber(), true,
                    "# of arrays to implement Virtual Provisioning");
            Helper.checkPositiveOrZero(logger, signature, symmetrixInformation.getThinDevicesHostNumber(), true,
                    "# of hosts to use thin devices for first time, across multiple tiers");
            Helper.checkPositiveOrZero(logger, signature, symmetrixInformation.getLunToDmxHostNumber(), true,
                    "# of hosts requiring mapping/LUN masking to DMX");
            Helper.checkPositiveOrZero(logger, signature,
                    symmetrixInformation.getAutoProvisioingToDmxHostNumber(), true,
                    "# of hosts requiring AutoProvisioning to VMAX");
            Helper.checkPositiveOrZero(logger, signature, symmetrixInformation.getAdvancedFastArraysNumber(),
                    true, "# of Arrays to Implement FAST");
            Helper.checkPositiveOrZero(logger, signature,
                    symmetrixInformation.getDeinstallOpenSystemsVmaxNumber(), true,
                    "# of Open Systems VMAX arrays to be de-installed");
        }

        if (symmetrixServiceEnabled) {
            Helper.checkPositiveOrZero(logger, signature, symmetrixInformation.getVmaxArraysNumber(), true,
                    "# of new Open Systems VMAX arrays to be installed");
            Helper.checkPositiveOrZero(logger, signature, symmetrixInformation.getVmaxArraysNumber(), true,
                    "# of new Open Systems DMX arrays to be installed");
            Helper.checkPositiveOrZero(logger, signature, symmetrixInformation.getVmaxArraysNumber(), true,
                    "# of existing Open Systems VMAX arrays to be upgraded");
            Helper.checkPositiveOrZero(logger, signature, symmetrixInformation.getVmaxArraysNumber(), true,
                    "# of existing Open Systems VMAX arrays to be upgraded");
        }
        Helper.checkPositiveOrZero(logger, signature, symmetrixInformation.getSrdfArraysNumber(), true,
                "# of source and target arrays to configure SRDF");
        Helper.checkPositiveOrZero(logger, signature, symmetrixInformation.getSrdfAArraysNumber(), true,
                "# of source and target arrays to configure SRDF/A");
    }

    /**
     * Validates the Service Request Info.
     *
     * @param requestType
     *         the request type
     * @param customer
     *         the request customer
     * @param startRequestData
     *         the start request data
     */
    private void validateServiceRequestInfo(RequestType requestType, Customer customer,
                                            StartRequestData startRequestData) {
        final String signature = CLASSNAME + "#validateServiceRequestInfo()";
        Logger logger = getLogger();
        Helper.checkNull(logger, signature, requestType, "Request Type");
        Helper.checkNull(logger, signature, startRequestData.isPhoneCallRequest(), "Phone call to discuss request");
        Helper.checkStrNullEmpty(logger, signature, startRequestData.getServiceRequestScope(),
                "Service Request Scope and Customer Objectives");
        validateAttachments(startRequestData.getAttachments());

        Helper.checkNull(logger, signature, customer, "Customer Worker Sites");
        Helper.checkNull(logger, signature, customer.getCustomerWorkSites(), "Customer Worker Sites");
        if (customer.getCustomerWorkSites().size() == 0) {
            throw new IllegalArgumentException("At least one work site is required");
        }

        if (requestType.getId() == 2 || requestType.getId() == 3) {
            RequestContractData requestContractData = startRequestData.getRequestContractData();
            Helper.checkNull(logger, signature, requestContractData, "Request Contract Data");
            Helper.checkNull(logger, signature, requestContractData.isCustomerFormatRequired(),
                    "Customer SOW Format Required");
            Helper.checkStrNullEmpty(logger, signature, customer.getFormalName(), "Customer Name");
            Helper.checkStrNullEmpty(logger, signature, customer.getAddress1(), "Customer Address Line 1");
            Helper.checkStrNullEmpty(logger, signature, customer.getCity(), "Customer City");
            Helper.checkNull(logger, signature, customer.getRegion(), "Customer State");
            Helper.checkZipPostalCode(logger, signature, customer.getZip(), "Customer Zip");
            Helper.checkStrNullEmpty(logger, signature, customer.getContactName(), "Customer Contact Name");
            Helper.checkPhone(logger, signature, customer.getOfficePhone(), "Customer Contact Office Phone");
            Helper.checkStrNullEmpty(logger, signature, customer.getEmail(), "Customer Contact Email");
        }
    }

    /**
     * Validates attachments exist.
     *
     * @param attachments
     *         the attachments to validate
     */
    private void validateAttachments(List<Attachment> attachments) {
        if (attachments != null) {
            StringBuilder lostAttachments = new StringBuilder();
            for (Attachment attachment : attachments) {
                File file = new File(attachmentUploadFolder, attachment.getAttachmentFilepath());
                if (!file.exists()) {
                    lostAttachments.append(attachment.getAttachmentFilename()).append(", ");
                }
            }
            if (lostAttachments.length() > 0) {
                lostAttachments = lostAttachments.deleteCharAt(lostAttachments.length() - 1);
                throw new IllegalArgumentException("The following attachments don't exist on disk anymore: "
                        + lostAttachments);
            }
        }
    }

    /**
     * Validates the Service Request Info.
     *
     * @param request the request data.
     * @return the given start request data
     */
    private StartRequestData validateProjectInfo(Request request) throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#validateProjectInfo()";
        Logger logger = getLogger();

        EngagementTypeData engagementTypeData = request.getEngagementTypeData();
        SRTPath path = validateEngagementType(engagementTypeData);
        boolean isSRT3 = path == SRTPath.SRT3;
        boolean isSRT4 = path == SRTPath.SRT4;
        boolean isHybrid = path == SRTPath.SRT_HYBRID;
        
        boolean isRSAChecked = engagementTypeData.isRsa();
        boolean isApproverForPendingRequest = isApprovingPendingRequest(request);

        StartRequestData startRequestData = request.getStartRequestData();

        Helper.checkStrNullEmpty(logger, signature, request.getProjectName(), "Project Name");
        Helper.checkNull(logger, signature, request.getProjectType(), "Project Type");
        Helper.checkNull(logger, signature, request.getProjectRegulatoryType(), "Project Regulatory Type");
        Helper.checkNull(logger, signature, request.getProjectStartDate(), "Estimated Start Date");
        Helper.checkNull(logger, signature, request.getProjectEndDate(), "Expected End Date");
        if (request.getProjectStartDate().after(request.getProjectEndDate())) {
            throw new IllegalArgumentException("Estimated start date must be earlier than expected end date");
        }

        Helper.checkNull(logger, signature, startRequestData, "Project Info");
        
        Division selectedDivision = startRequestData.getSelectedDivision();
        Helper.checkNull(logger, signature, selectedDivision, "Sales Division");
        boolean isMidMarket = selectedDivision != null && "Mid-Market".equals(selectedDivision.getDivisionName());
        if (isMidMarket) {
            throw new IllegalArgumentException(
                    "You must provide a geography and a state if the sales division is Mid-Market");
        }
        List<SalesDistrict> districtsForDivision =
            this.startRequestDataService.getDistrictsForDivision(selectedDivision.getId());
        if (districtsForDivision != null && !districtsForDivision.isEmpty()) {
            Helper.checkNull(logger, signature, startRequestData.getSelectedDistrict(), "Sales District");
            Helper.checkStrNullEmpty(logger, signature, startRequestData.getSelectedDistrict().getAreaName(),
                "Sales Area");
        }

        Helper.checkStrNullEmpty(logger, signature, startRequestData.getCustomerName(), "Customer Name");
        Helper.checkStrNullEmpty(logger, signature, startRequestData.getWorkCity(), "Primary Work Cities");
        Helper.checkStrNullEmpty(logger, signature, startRequestData.getPdmName(), "Program Delivery Manager Name");
        if (!isMidMarket) {
            Helper.checkStrNullEmpty(logger, signature, startRequestData.getPmName(), "Program Manager Name");
        }

        if (isSRT3 || isHybrid) {
            Helper.checkStrNullEmpty(logger, signature, startRequestData.getSeCsdName(), "SE/CSD Name");
            Helper.checkPhone(logger, signature, startRequestData.getSeCsdPhone(), "SE/CSD Phone");
            Helper.checkStrNullEmpty(logger, signature, startRequestData.getSeManagerName(), "SE Manager Name");
        }

        String dxQuoteNumber = startRequestData.getDxQuoteNumber();
        if (!isRSAChecked || isApproverForPendingRequest) {
            Helper.checkNumeric(logger, signature, dxQuoteNumber, "Quote Number");
            int dxQuoteNumberParsed = Integer.parseInt(dxQuoteNumber);
            if (dxQuoteNumberParsed < 1001000000 || dxQuoteNumberParsed > 1009000000) {
                throw new IllegalArgumentException(
                        "'Quote Number' must be a number between 1001000000 and 1009000000.");
            }
        }
        if (!engagementTypeData.isProductLead() && engagementTypeData.isServiceLead()) {
            Helper.checkStrNullEmpty(logger, signature, startRequestData.getSfdcNumber(), "Opportunity Number");
            if (!isRSAChecked || isApproverForPendingRequest) {
                Helper.checkNull(logger, signature, startRequestData.getOraclePartyID(), "Oracle Party ID");
            }
        }

        if (isHybrid || isSRT4) {
            EstimatesData estimatesData = request.getEstimatesData();
            Helper.checkNull(logger, signature, estimatesData, "Estimates data");
        }
        
        if (isSRT3 || isHybrid) {
            Helper.checkNull(logger, signature, startRequestData.getMeetingStatus(), "Status Meetings");
            Helper.checkNull(logger, signature, startRequestData.getRiskLevel(), "Presales Risk Factor");
            Helper.checkNull(logger, signature, startRequestData.getSowLanguage(), "SOW Language");
        }

        Helper.checkNull(logger, signature, startRequestData.getExpenseType(), "Expense Type");

        if (isSRT3 || isHybrid) {
            Helper.checkNull(logger, signature, startRequestData.isResellerSold(), "Sold Through Reseller");
            Helper.checkNull(logger, signature, startRequestData.getRequestedReturnDate(), "Requested Return Date");
            Helper.checkNull(logger, signature, startRequestData.isReturnEquipment(), "Equipment Returning to EMC?");
            Helper.checkNull(logger, signature, startRequestData.isRemoteAccess(), "Will Customer Allow Remote Access?");
            Helper.checkStrNullEmpty(logger, signature, startRequestData.getTravelRequirements(),
                "Special Travel Requirements");
        }
        
        Helper.checkStrNullEmpty(logger, signature, request.getProjectDescription(), "Project Description");


        return startRequestData;
    }

    /**
     * Submits a list of requests.
     *
     * @param requestIds
     *         the request ids
     * @param httpRequest
     *         the HTTP Servlet request
     * @return the submit result
     * @throws IllegalArgumentException
     *         if requestIds is null or empty.
     * @throws ExportServiceException
     *         if there is any problem when exporting the request.
     * @throws ServiceRequestToolException
     *         if there is any problem updating the request.
     */
    @RequestMapping(value = "submitRequests", method = RequestMethod.POST)
    @ResponseBody
    @Transactional
    public SubmitResult submitRequests(@RequestParam String requestIds, HttpServletRequest httpRequest)
            throws ServiceRequestToolException, ExportServiceException {
        final String signature = CLASSNAME + "#submitRequests(String requestIds)";
        Logger logger = getLogger();

        // Log entry
        Helper.logEntrance(logger, signature, new String[]{"requestIds"}, new Object[]{requestIds});
        Helper.checkStrNullEmpty(logger, signature, requestIds, "requestIds");

        SubmitResult submitResult = new SubmitResult("SubmitID-" + UUID.randomUUID().toString());
        submitResult.setValidationMessages(new ArrayList<String>());
        List<Request> validatedRequests = new ArrayList<Request>();

        String[] ids = requestIds.split(",");
        Request request;
        long requestId;
        for (String id : ids) {
            // Parse request id
            try {
                requestId = Long.parseLong(id);
            } catch (NumberFormatException ex) {
                submitResult.getValidationMessages().add("Invalid request id: " + id);
                continue;
            }

            try {
                // Get request
                // make a copy so that it is a detached entity.
                request = Helper.deepCloneEntity(requestService.get(requestId));

                if (request == null) {
                    submitResult.getValidationMessages().add("Request " + requestId + ": Request does not exist");
                    continue;
                }

                // Validate request
                validateRequest(request);
            } catch (IllegalArgumentException ex) {
                submitResult.getValidationMessages().add("Request " + requestId + ": " + ex.getMessage());
                continue;
            }
            validatedRequests.add(request);
        }

        if (submitResult.getValidationMessages().isEmpty()) {

            // Put to session
            httpRequest.getSession(true).setAttribute(submitResult.getSubmitId(), submitResult);

            // Do submit request
            doSubmitRequest(submitResult, validatedRequests);
        }

        // Log exit
        Helper.logExit(logger, signature, new Object[]{submitResult});
        return submitResult;
    }
    
    /**
     * Submits a list of requests.
     *
     * @param requestIds
     *            the request ids
     * @param httpRequest
     *            the HTTP Servlet request
     * @return the submit result
     * @throws IllegalArgumentException
     *             if requestIds is null or empty.
     * @throws ExportServiceException
     *             if there is any problem when exporting the request.
     * @throws ServiceRequestToolException
     *             if there is any problem updating the request.
     */
    @RequestMapping(value = "submitPendingRequest/{id}", method = RequestMethod.POST)
    @ResponseBody
    public SubmitResult submitPendingRequest(@PathVariable long id, @RequestBody EstimatesData estimatesData,
            HttpServletRequest httpRequest) throws ServiceRequestToolException, ExportServiceException {
        final String signature = CLASSNAME + "#submitPendingRequest(String requestId, EstimatesData estimatesData)";
        Logger logger = getLogger();
 
        // Log entry
        Helper.logEntrance(logger, signature, new String[] { "id", "estimatesData" },
                new Object[] { id, estimatesData });
        Helper.checkPositive(logger, signature, id, "id");
        Helper.checkNull(logger, signature, estimatesData, "estimatesData");
 
        SubmitResult submitResult = new SubmitResult("SubmitID-" + UUID.randomUUID().toString());
        submitResult.setValidationMessages(new ArrayList<String>());
        List<Request> validatedRequests = new ArrayList<Request>();
        Request request = null;
        try {
            // Get request
            // make a copy so that it is a detached entity.
            request = Helper.deepCloneEntity(requestService.get(id));
            if (request == null) {
                submitResult.getValidationMessages().add("Request " + id + ": Request does not exist");
            } else {
                request.setEstimatesData(estimatesData);
                // Validate request
                validateRequest(request);
                validatedRequests.add(request);
            }
        } catch (IllegalArgumentException ex) {
            submitResult.getValidationMessages().add("Request " + id + ": " + ex.getMessage());
        }
 
        if (submitResult.getValidationMessages().isEmpty()) {
 
            // Put to session
            httpRequest.getSession(true).setAttribute(submitResult.getSubmitId(), submitResult);
 
            // Do submit request
            doSubmitRequest(submitResult, validatedRequests);
        }
 
        // Log exit
        Helper.logExit(logger, signature, new Object[] { submitResult });
        return submitResult;
    }
    
    
    /**
     * Get the getRequest for id.
     *
     * @param requestId
     *         the request id.
     * @return the serialized request data.
     * @throws IllegalArgumentException
     *         if id is not positive.
     * @throws com.emc.gs.tools.srf.services.ServiceRequestToolException
     *         if there is any problem executing the request.
     * @since 3.23
     */
    @RequestMapping(value = "getRequest/{requestId}", method = RequestMethod.GET)
    @ResponseBody
    public Request get(@PathVariable long requestId) throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#getRequest(long requestId)";
        Logger logger = getLogger();

        // Log entry
        Helper.logEntrance(logger, signature, new String[]{"requestId"}, new Object[]{requestId});

        Request result = requestService.get(requestId);

        // Log exit
        Helper.logExit(logger, signature, new Object[]{result});

        return result;
    }
    
    /**
     * Get the request for id.
     *
     * @param id
     *         the request id
     * @return the view name for single request
     * @throws IllegalArgumentException
     *         if id is not positive
     * @throws com.emc.gs.tools.srf.services.ServiceRequestToolException
     *         if there is any problem executing the request.
     * @since 3.23
     */
    @RequestMapping(value = "request/estimate/{id}", method = RequestMethod.GET)
    @ResponseBody
    public EstimatedResult getEstimatedResult(@PathVariable long id) throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#getEstimatedResult(long id))";
        Logger logger = getLogger();

        // Log entry
        Helper.logEntrance(logger, signature, new String[]{"id"}, new Object[]{id});

        Request request = requestService.get(id);
        EstimatedResult result = estimateRequest(request);

        // Log exit
        Helper.logExit(logger, signature, new Object[]{result});

        return result;
    }
    

    /**
     * Get the StartRequestData for id.
     *
     * @param requestId
     *         the request id.
     * @return the serialized request data.
     * @throws IllegalArgumentException
     *         if id is not positive.
     * @throws ServiceRequestToolException
     *         if there is any problem executing the request.
     */
    @RequestMapping(value = "request/{id}/startRequestData", method = RequestMethod.GET)
    @ResponseBody
    public StartRequestData getStartRequestData(@PathVariable long requestId) throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#getStartRequestData(long requestId)";
        Logger logger = getLogger();

        // Log entry
        Helper.logEntrance(logger, signature, new String[]{"requestId"}, new Object[]{requestId});

        StartRequestData result = requestService.getStartRequestData(requestId);

        // Log exit
        Helper.logExit(logger, signature, new Object[]{result});

        return result;
    }

    /**
     * Get the BcRequestData for id.
     *
     * @param requestId
     *         the request id.
     * @return the serialized request data.
     * @throws IllegalArgumentException
     *         if id is not positive.
     * @throws ServiceRequestToolException
     *         if there is any problem executing the request.
     */
    @RequestMapping(value = "request/{id}/bcRequestData", method = RequestMethod.GET)
    @ResponseBody
    public BcRequestData getBcRequestData(@PathVariable long requestId) throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#getBcRequestData(long requestId)";
        Logger logger = getLogger();

        // Log entry
        Helper.logEntrance(logger, signature, new String[]{"requestId"}, new Object[]{requestId});

        BcRequestData result = requestService.getBcRequestData(requestId);

        // Log exit
        Helper.logExit(logger, signature, new Object[]{result});

        return result;
    }

    /**
     * Get the MainframeRequestData for id.
     *
     * @param requestId
     *         the request id.
     * @return the serialized request data.
     * @throws IllegalArgumentException
     *         if id is not positive.
     * @throws ServiceRequestToolException
     *         if there is any problem executing the request.
     */
    @RequestMapping(value = "request/{id}/mainframeRequestData", method = RequestMethod.GET)
    @ResponseBody
    public MainframeRequestData getMainframeRequestData(@PathVariable long requestId)
            throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#getMainframeRequestData(long requestId)";
        Logger logger = getLogger();

        // Log entry
        Helper.logEntrance(logger, signature, new String[]{"requestId"}, new Object[]{requestId});

        MainframeRequestData result = requestService.getMainframeRequestData(requestId);

        // Log exit
        Helper.logExit(logger, signature, new Object[]{result});

        return result;
    }

    /**
     * Get the UnifiedRequestData for id.
     *
     * @param requestId
     *         the request id.
     * @return the serialized request data.
     * @throws IllegalArgumentException
     *         if id is not positive.
     * @throws ServiceRequestToolException
     *         if there is any problem executing the request.
     */
    @RequestMapping(value = "request/{id}/unifiedRequestData", method = RequestMethod.GET)
    @ResponseBody
    public UnifiedRequestData getUnifiedRequestData(@PathVariable long requestId)
            throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#getUnifiedRequestData(long requestId)";
        Logger logger = getLogger();

        // Log entry
        Helper.logEntrance(logger, signature, new String[]{"requestId"}, new Object[]{requestId});

        UnifiedRequestData result = requestService.getUnifiedRequestData(requestId);

        // Log exit
        Helper.logExit(logger, signature, new Object[]{result});

        return result;
    }

    /**
     * Get the InfrastructureRequestData for id.
     *
     * @param requestId
     *         the request id.
     * @return the serialized request data.
     * @throws IllegalArgumentException
     *         if id is not positive.
     * @throws ServiceRequestToolException
     *         if there is any problem executing the request.
     */
    @RequestMapping(value = "request/{id}/infrastructureRequestData", method = RequestMethod.GET)
    @ResponseBody
    public InfrastructureRequestData getInfrastructureRequestData(@PathVariable long requestId)
            throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#getInfrastructureRequestData(long requestId)";
        Logger logger = getLogger();

        // Log entry
        Helper.logEntrance(logger, signature, new String[]{"requestId"}, new Object[]{requestId});

        InfrastructureRequestData result = requestService.getInfrastructureRequestData(requestId);

        // Log exit
        Helper.logExit(logger, signature, new Object[]{result});

        return result;
    }

    /**
     * This method checks whether the instance of the class was initialized properly.
     *
     * @throws com.emc.gs.tools.srf.ServiceRequestToolConfigurationException
     *         if requestService/exportService/startRequestDataService/profileService
     *         /lookupService/submitTaskExecutor/enabledTabs/estimatesService/ratesService is null,
     *         or if attachmentUploadFolder is null or empty
     */
    @PostConstruct
    protected void checkInit() {
        Helper.checkState(requestService == null, "'requestService' can't be null.");
        Helper.checkState(exportService == null, "'exportService' can't be null.");
        Helper.checkState(startRequestDataService == null, "'startRequestDataService' can't be null.");
        Helper.checkState(profileService == null, "'profileService' can't be null.");
        Helper.checkState(lookupService == null, "'lookupService' can't be null.");
        Helper.checkState(estimatesService == null, "'estimatesService' can't be null.");
        Helper.checkState(ratesService == null, "'ratesService' can't be null.");
        Helper.checkState(submitTaskExecutor == null, "'submitTaskExecutor' can't be null.");
        Helper.checkState(enabledTabs == null, "'enabledTabs' can't be null.");
        Helper.checkState(StringUtils.isBlank(attachmentUploadFolder),
                "'attachmentUploadFolder' can't be null/empty.");

        File folder = new File(attachmentUploadFolder);
        getLogger().info("AttachmentUploadFolder is: " + folder.getAbsolutePath());

        if (!folder.exists()) {
            Helper.checkState(!folder.mkdirs(), "Unable to create 'attachmentUploadFolder'");
        }

        try {
            // Initialize lookup entities
            getLogger().info("Start initialize lookup data...");
            addLookupEntities(new ExtendedModelMap());
            getLogger().info("End initialize lookup data.");
        } catch (ServiceRequestToolException e) {
            getLogger().error("Failed to initialize lookup entities", e);
        }
    }

    /**
     * <p>
     * Sets the value to lookupService field.
     * </p>
     *
     * @param lookupService
     *         the value of lookupService to set
     */
    public void setLookupService(LookupService lookupService) {
        this.lookupService = lookupService;
    }

    /**
     * <p>
     * Sets the value to requestService field.
     * </p>
     *
     * @param requestService
     *         the value of requestService to set
     */
    public void setRequestService(RequestService requestService) {
        this.requestService = requestService;
    }

    /**
     * <p>
     * Sets the value to exportService field.
     * </p>
     *
     * @param exportService
     *         the value of exportService to set
     */
    public void setExportService(ExportService exportService) {
        this.exportService = exportService;
    }

    /**
     * <p>
     * Sets the value to startRequestDataService field.
     * </p>
     *
     * @param startRequestDataService
     *         the value of startRequestDataService to set
     */
    public void setStartRequestDataService(StartRequestDataService startRequestDataService) {
        this.startRequestDataService = startRequestDataService;
    }

    /**
     * <p>
     * Sets the value to profileService field.
     * </p>
     *
     * @param profileService
     *         the value of profileService to set
     */
    public void setProfileService(ProfileService profileService) {
        this.profileService = profileService;
    }

    /**
     * <p>
     * Sets the value to estimatesService field.
     * </p>
     *
     * @param estimatesService
     *         the value of estimatesService to set
     */
    public void setEstimatesService(EstimatesService estimatesService) {
        this.estimatesService = estimatesService;
    }

    /**
     * <p>
     * Sets the value to ratesService field.
     * </p>
     *
     * @param ratesService
     *         the value of ratesService to set
     */
    public void setRatesService(RatesService ratesService) {
        this.ratesService = ratesService;
    }

    /**
     * Setter method for property <tt>submitTaskExecutor</tt>.
     *
     * @param submitTaskExecutor
     *         value to be assigned to property submitTaskExecutor
     * @since SRT Phase 2 Release Assembly
     */
    public void setSubmitTaskExecutor(TaskExecutor submitTaskExecutor) {
        this.submitTaskExecutor = submitTaskExecutor;
    }

    /**
     * Setter method for property <tt>attachmentUploadFolder</tt>.
     *
     * @param attachmentUploadFolder
     *         value to be assigned to property attachmentUploadFolder
     */
    public void setAttachmentUploadFolder(String attachmentUploadFolder) {
        this.attachmentUploadFolder = attachmentUploadFolder;
    }

    /**
     * Setter method for property <tt>enabledTabs</tt>.
     *
     * @param enabledTabs
     *         value to be assigned to property enabledTabs
     */
    public void setEnabledTabs(EnabledTabs enabledTabs) {
        this.enabledTabs = enabledTabs;
    }

    /**
     * <p>Gets the value of specified Boolean object. If object is null then false is returned.</p>
     *
     * @param b boolean object.
     * @return boolean value.
     * @since 2.10
     */
    private static boolean getBooleanValue(Boolean b) {
        if (b == null) {
            return false;
        } else {
            return b.booleanValue();
        }
    }
    
    /**
     * <p>Checks if current user is set as approver for specified request and that specified request is of PENDING
     * status.</p>
     * 
     * @param request a <code>Request</code> providing details for request. 
     * @return <code>true</code> if current user is set as approver for specified request and is in process of approving
     *         this request; <code>false</code> otherwise.
     * @throws ServiceRequestToolException if an unexpected error occurs.
     */
    private boolean isApprovingPendingRequest(Request request) throws ServiceRequestToolException {
        if (request.getRequestStatus() == RequestStatus.PENDING) {
            Profile defaultProfile = profileService.getDefaultProfile();
            Profile approver = request.getApprover();
            if (approver != null && approver.getId() == defaultProfile.getId()) {
                return true;
            }
        }
        return false;
    }
}

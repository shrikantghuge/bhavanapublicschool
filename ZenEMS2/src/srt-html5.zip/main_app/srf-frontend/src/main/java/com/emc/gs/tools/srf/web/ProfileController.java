/*
 * This code is copyright (c) 2013 - 2015 EMC Corporation.
 */
package com.emc.gs.tools.srf.web;

import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.servlet.http.HttpSession;

import com.emc.gs.tools.srf.model.ServiceContext;
import com.emc.gs.tools.srf.model.User;
import com.emc.gs.tools.srf.model.engagement.DeliveryCountry;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.emc.gs.tools.srf.AuthorizationException;
import com.emc.gs.tools.srf.ServiceRequestToolConfigurationException;
import com.emc.gs.tools.srf.model.Customer;
import com.emc.gs.tools.srf.model.Division;
import com.emc.gs.tools.srf.model.GeoState;
import com.emc.gs.tools.srf.model.Geography;
import com.emc.gs.tools.srf.model.PdmName;
import com.emc.gs.tools.srf.model.Profile;
import com.emc.gs.tools.srf.model.Region;
import com.emc.gs.tools.srf.model.SalesDistrict;
import com.emc.gs.tools.srf.model.SearchResult;
import com.emc.gs.tools.srf.model.ProfileSearchCriteria;
import com.emc.gs.tools.srf.services.ProfileService;
import com.emc.gs.tools.srf.services.ServiceRequestToolException;
import com.emc.gs.tools.srf.services.StartRequestDataService;
import com.emc.gs.tools.srf.services.SyncDown;
import com.emc.gs.tools.srf.services.SyncUp;
import com.emc.gs.tools.srf.services.impl.Helper;

/**
 * <p>
 * This class represents the controller to manage profile.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is effectively thread safe after configuration, the
 * configuration is done in a thread safe manner.
 * </p>
 *
 * <p>
 * <strong>Changes V1.1:</strong>
 * <strong>SRT Release Assembly - Base</strong>
 * <ul>
 * <li>Added new methods</li>
 * </ul>
 * </p>
 *
 * <p>
 * <strong>Changes V1.2:</strong>
 * <strong>SRT Release Assembly - Unified Tab</strong>
 * <ul>
 * <li>Handle the case that there is no default profile in view() method.</li>
 * <li>Add create() method to create profile.</li>
 * <li>Remove defaultProfileId configuration, use {@link ProfileService#getDefaultProfile()} instead.</li>
 * </ul>
 * </p>
 * 
 * <p>
 * <strong>Changes V1.3:</strong>
 * <strong>SRT Bug Fixes</strong>
 * <ul>
 * <li>Add getDefaultProfile() method.</li>
 * </ul>
 * </p>
 * 
 * <p>
 * <strong>Changes V1.4:</strong>
 * <strong>Commercial / Mid-Market Division Special Handling Logic</strong>
 * <ul>
 * <li>Added getAllGeographies() and getStatesForGeography() methods.</li>
 * </ul>
 * </p>
 *
 * <p>
 * <strong>Changes V1.5:</strong>
 * <strong>SRT 1.1 DEC 2014 Updates Assembly</strong>
 * <ul>
 * <li>Added getRegionsForGeography() method.</li>
 * </ul>
 * </p>
 *
 * <p>
 * Version 1.6 Change notes:
 *   <ol>
 *     <li>Added {@link #deliveryCountriesMapping} property.</li>
 *     <li>Updated {@link #create(Profile)} and {@link #update(long, Profile)} methods to secure profile in order to
 *     prevent malicious attempts to alter readonly profile properties.</li>
 *   </ol>
 * </p>
 *
 * <p>
 * Version 1.7 Change notes:
 *   <ol>
 *     <li>Updated methods to handle approvers/non-submitters.</li>
 *     <li>Added updateRole method.</li>
 *     <li>Added searchProfiles method.</li>
 *   </ol>
 * </p>
 *
 * <p>
 * Version 1.8 Change notes:
 *   <ol>
 *     <li>Added support for managing <code>Template Folder Editor</code> permissions.</li>
 *   </ol>
 * </p>
 *
 * <p>
 * Version 1.9 Change notes:
 *   <ol>
 *     <li>Updated {@link #searchProfiles(ProfileSearchCriteria)} method to limit the search scope by division for the
 *     current user's profile.</li>
 *     <li>Removed <code>submitter</code> property from <code>Profile</code> and <code>User</code> entities.</li>
 *     <li>Removed functionalities related for viewing and managing the users with <code>Submitter</code> role.</li>
 *     <li>Updated {@link #getStatesForGeography(long)} to sort the resulting list be name.</li>
 *   </ol>
 * </p>
 * 
 * <p>
 * <strong>Changes V1.10:</strong>
 * <strong>SRT HTML5 ET Production Fixes Part 1 Assembly 1.0</strong>
 * <ul>
 * <li>add hasUserManagementPermission method for the html5 app to check user permission</li>
 * <li>add getProfileById method</li>
 * </ul>
 * </p>
 * 
 * <p>
 * <strong>Changes V1.11:</strong>
 * <strong>SRT HTML5 ET Production Fixes Part 2 Assembly 1.0</strong>
 * <ul>
 * <li>updateRole method is updated with templatePermission set for the current user</li>
 * </ul>
 * </p>
 * @author faeton, stevenfrog, isv, MonicaMuranyi, TCSASSEMBLER
 * @version 1.11
 */
@Controller
public class ProfileController extends BaseController {
    /**
     * <p>
     * Represents the class name.
     * </p>
     */
    private static final String CLASSNAME = ProfileController.class.getName();

    /**
     * Represents the ProfileService instance for managing data. It is modified by setter. It is injected by
     * Spring. It can not be null after injected.
     */
    private ProfileService profileService;

    /**
     * Represents the StartRequestDataService instance for managing additional data for requests. It is
     * modified by setter. It is injected by Spring. It can not be null after injected.
     */
    private StartRequestDataService startRequestDataService;

    /**
     * <p>A <code>List</code> providing the value for deliveryCountries property.</p>
     * 
     * @since 1.6
     */
    private Map<String, DeliveryCountry> deliveryCountriesMapping = new HashMap<String, DeliveryCountry>();

    /**
     * Creates instance of the class.
     */
    public ProfileController() {
        // Empty
    }

    /**
     * Shows user profile.
     *
     * @param model
     *            Spring MVC model to put data
     * @param session
     *            the http session
     * @return the view name
     * @throws ServiceRequestToolException
     *             if there is any problem executing the request.
     */
    @SyncDown(entityType = "Profile")
    @RequestMapping(value = "profile", method = RequestMethod.GET)
    public String view(Model model, HttpSession session) throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#view(Model model)";
        Logger logger = getLogger();

        // Log entry
        Helper.logEntrance(logger, signature, new String[] {"model"}, new Object[] {model});

        Profile profile = profileService.getDefaultProfile();
        model.addAttribute("profile", profile);

        if (profile != null) {
            session.setAttribute("profileFirstname", profile.getFirstName());
            session.setAttribute("profileLastname", profile.getLastName());
        }

        String result = "viewProfile";

        // Log exit
        Helper.logExit(logger, signature, new Object[] {result});

        return result;
    }
    
    /**
     * Returns the default profile.
     *
     * @return The default profile
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     */
    @RequestMapping(value = "defaultProfile", method = RequestMethod.GET)
    @ResponseBody
    public Profile getDefaultProfile() throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#getDefaultProfile()";
        Logger logger = getLogger();

        // Log entry
        Helper.logEntrance(logger, signature, null, null);

        Profile profile = profileService.getDefaultProfile();

        // Log exit
        Helper.logExit(logger, signature, new Object[] {profile});

        return profile;
    }
    
    /**
     * Returns the profile by id.
     *
     * @return The profile with given id
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     *             
     * @since 1.10
     */
    @RequestMapping(value = "profileById/{id}", method = RequestMethod.GET)
    @ResponseBody
    public Profile getProfileById(@PathVariable long id) throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#getProfileById()";
        Logger logger = getLogger();

        // Log entry
        Helper.logEntrance(logger, signature, null, null);

        Profile profile = profileService.get(id);

        // Log exit
        Helper.logExit(logger, signature, new Object[] {profile});

        return profile;
    }

    /**
     * Returns all divisions.
     *
     * @return Whole list of lookup values, may be empty
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     */
    @RequestMapping(value = "profile/divisions", method = RequestMethod.GET)
    @ResponseBody
    public List<Division> getAllDivisions() throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#getAllDivisions()";
        Logger logger = getLogger();

        // Log entry
        Helper.logEntrance(logger, signature, null, null);

        List<Division> result = startRequestDataService.getAllDivisions();

        // Log exit
        Helper.logExit(logger, signature, new Object[] {result});

        return result;
    }
    
    /**
     * Returns all geographies.
     *
     * @return Whole list of lookup values, may be empty
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     */
    @RequestMapping(value = "profile/geographies", method = RequestMethod.GET)
    @ResponseBody
    public List<Geography> getAllGeographies() throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#getAllGeographies()";
        Logger logger = getLogger();

        // Log entry
        Helper.logEntrance(logger, signature, null, null);

        List<Geography> result = startRequestDataService.getAllGeographies();

        // Log exit
        Helper.logExit(logger, signature, new Object[] {result});

        return result;
    }
    
    /**
     * Returns all states associated with the given geography.
     *
     * @param geographyId
     *            the geography id
     * @return Whole list of lookup values, may be empty
     * @throws IllegalArgumentException
     *             if divisionId is not positive
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     */
    @RequestMapping(value = "profile/states/{geographyId}", method = RequestMethod.GET)
    @ResponseBody
    public List<GeoState> getStatesForGeography(@PathVariable long geographyId) throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#getStatesForGeography()";
        Logger logger = getLogger();

        // Log entry
        Helper.logEntrance(logger, signature, null, null);
        Helper.checkPositive(logger, signature, geographyId, "geographyId");

        List<GeoState> result = startRequestDataService.getStatesByGeography(geographyId);
        Collections.sort(result, new Comparator<GeoState>() {
            @Override
            public int compare(GeoState o1, GeoState o2) {
                if (o1 == null) {
                    if (o2 == null) {
                        return 0;
                    } else {
                        return -1;
                    }
                } else if (o2 == null) {
                    return 1;
                } else {
                    return o1.getName().compareTo(o2.getName());
                }
            }
        });
        // Log exit
        Helper.logExit(logger, signature, new Object[] {result});

        return result;
    }
    
    /**
     * Returns all states/regions associated with the given geography.
     *
     * @param countryId
     *            the country id
     * @return Whole list of lookup values, may be empty
     * @throws IllegalArgumentException
     *             if divisionId is not positive
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     */
    @RequestMapping(value = "profile/regions/{countryId}", method = RequestMethod.GET)
    @ResponseBody
    public List<Region> getRegionsForGeography(@PathVariable long countryId) throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#getRegionsForGeography()";
        Logger logger = getLogger();

        // Log entry
        Helper.logEntrance(logger, signature, null, null);
        Helper.checkPositive(logger, signature, countryId, "countryId");

        List<Region> result = startRequestDataService.getRegionsByCountry(countryId);

        // Log exit
        Helper.logExit(logger, signature, new Object[] {result});

        return result;
    }

    /**
     * Returns the sales districts by division id.
     *
     * @param divisionId
     *            the division id
     * @return Whole list of lookup values, may be empty
     * @throws IllegalArgumentException
     *             if divisionId is not positive
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     */
    @RequestMapping(value = "profile/salesDistricts/{divisionId}", method = RequestMethod.GET)
    @ResponseBody
    public List<SalesDistrict> getSalesDistrictsByDivision(@PathVariable long divisionId)
        throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#getSalesDistrictsByDivision(long divisionId)";
        Logger logger = getLogger();

        // Log entry
        Helper.logEntrance(logger, signature, new String[] {"divisionId"}, new Object[] {divisionId});

        Helper.checkPositive(logger, signature, divisionId, "divisionId");

        List<SalesDistrict> result = startRequestDataService.getDistrictsForDivision(divisionId);

        // Log exit
        Helper.logExit(logger, signature, new Object[] {result});

        return result;
    }
    
    /**
     * Returns the sales districts by division id.
     *
     * @param divisionId
     *            the division id
     * @return Whole list of lookup values, may be empty
     * @throws IllegalArgumentException
     *             if divisionId is not positive
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     * @since 1.1
     */
    @RequestMapping(value = "profile/pdmNames/{divisionId}", method = RequestMethod.GET)
    @ResponseBody
    public List<PdmName> getPDMNamesByDivision(@PathVariable long divisionId)
        throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#getPDMNamesByDivision(long divisionId)";
        Logger logger = getLogger();

        // Log entry
        Helper.logEntrance(logger, signature, new String[] {"divisionId"}, new Object[] {divisionId});

        Helper.checkPositive(logger, signature, divisionId, "divisionId");

        List<PdmName> result = startRequestDataService.getPdmNamesForDivision(divisionId);

        // Log exit
        Helper.logExit(logger, signature, new Object[] {result});

        return result;
    }

    /**
     * Creates the profile.
     *
     * @param profile
     *            the profile to create
     * @return The created profile.
     * @throws IllegalArgumentException
     *             if profile is null
     * @throws ServiceRequestToolException
     *             if there is any problem executing the request.
     * @since SRT Release Assembly - Unified Tab
     */
    @SyncUp(entityType = "Profile")
    @RequestMapping(value = "profile", method = RequestMethod.POST)
    @ResponseBody
    public Profile create(@RequestBody Profile profile) throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#create(Profile profile)";
        Logger logger = getLogger();

        // Log entry
        Helper.logEntrance(logger, signature, new String[] {"profile"}, new Object[] {profile});

        Helper.checkNull(logger, signature, profile, "profile");

        secureProfile(profile);
        if(StringUtils.isBlank(profile.getUserIdentifier())){
            profile.setUserIdentifier(ServiceContext.getCurrentUser().getUserIdentifier());
        }
        profile = profileService.create(profile);

        // Log exit
        Helper.logExit(logger, signature, new Object[]{profile});

        return profile;
    }

    /**
     * Updates the profile.
     *
     * @param id
     *            the id of profile to update
     * @param profile
     *            the profile to update
     * @throws IllegalArgumentException
     *             if profile is null, id is not positive or is not the id of profile
     * @throws ServiceRequestToolException
     *             if there is any problem executing the request.
     */
    @SyncUp(entityType = "Profile")
    @RequestMapping(value = "profile/{id}", method = RequestMethod.PUT)
    @ResponseBody
    public void update(@PathVariable long id, @RequestBody Profile profile) throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#update(long id, Profile profile)";
        Logger logger = getLogger();

        // Log entry
        Helper.logEntrance(logger, signature, new String[] {"id", "profile"}, new Object[] {id, profile});
        
        Helper.checkPositive(logger, signature, id, "id");
        Helper.checkNull(logger, signature, profile, "profile");

        if (id != profile.getId()) {
            throw Helper.logException(logger, signature, new IllegalArgumentException(
                "The update id is not same as profile id"));
        }

        if (StringUtils.isBlank(profile.getUserIdentifier())) {
            profile.setUserIdentifier(ServiceContext.getCurrentUser().getUserIdentifier());
        }
        secureProfile(profile);
        profileService.update(profile);

        // Log exit
        Helper.logExit(logger, signature, null);
    }
    
    
    /**
     * Updates the approver or submitter fields on a profile.
     *
     * @param id
     *            the id of profile to update
     * @param profile
     *            the profile to update
     * @throws IllegalArgumentException
     *             if profile is null, id is not positive or is not the id of profile
     * @throws ServiceRequestToolException
     *             if there is any problem executing the request.
     * @since 1.7
     */
    @SyncDown(entityType = "Profile")
    @RequestMapping(value = "profileRole/{id}", method = RequestMethod.PUT)
    @ResponseBody
    public void updateRole(@PathVariable long id, @RequestBody Profile profile) throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#updateRole(long id, Profile profile)";
        User currentUser = ServiceContext.getCurrentUser();

        Logger logger = getLogger();

        if(!currentUser.isUserManagementPermission()){
            throw Helper.logException(logger, signature,
                    new AuthorizationException("Insufficient permissions to update user role."));
        }
        
        // Log entry
        Helper.logEntrance(logger, signature, new String[] {"id", "profile"}, new Object[] {id, profile});
        
        Helper.checkPositive(logger, signature, id, "id");
        Helper.checkNull(logger, signature, profile, "profile");

        if (id != profile.getId()) {
            throw Helper.logException(logger, signature, new IllegalArgumentException(
                "The update id is not same as profile id"));
        }
        
        Profile actualProfile = profileService.get(id);
        actualProfile.setApprover(profile.isApprover());
        actualProfile.setTemplatePermission(profile.isTemplatePermission());
        
        
        profileService.update(actualProfile);
        // Update the current user's roles
        if(currentUser.getUserIdentifier().equals(actualProfile.getUserIdentifier())){
            currentUser.setApprover(actualProfile.isApprover());
            currentUser.setTemplatePermission(actualProfile.isTemplatePermission());
        }

        // Log exit
        Helper.logExit(logger, signature, null);
    }
    
    /**
     * Check if user has the management permission.
     * 
     * @return true if user has the management persmission, false otherwise.
     * @throws ServiceRequestToolException if any error occurs.
     * @since 1.10
     */
    @RequestMapping(value = "hasUserManagementPermission", method = RequestMethod.GET)
    @ResponseBody
    public boolean hasUserManagementPermission() throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#hasUserManagementPermission()";
        User currentUser = ServiceContext.getCurrentUser();
        Logger logger = getLogger();
        // Log entry
        Helper.logEntrance(logger, signature, null, null);


        // Log exit
        Helper.logExit(logger, signature, new Object[]{currentUser.isUserManagementPermission()});

        return currentUser.isUserManagementPermission();
    }
    
    /**
     * Views the approvers page.
     *
     * @return the view name.
     * @throws ServiceRequestToolException 
     */
    @RequestMapping(value = "approvers", method = RequestMethod.GET)
    public String viewApprovers() throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#viewApprovers()";
        User currentUser = ServiceContext.getCurrentUser();

        Logger logger = getLogger();

        if(!currentUser.isUserManagementPermission()){
            throw Helper.logException(logger, signature,
                    new AuthorizationException("Insufficient permissions to view Approvers."));
        }

        // Log entry
        Helper.logEntrance(logger, signature, null, null);

        String result = "viewApprovers";

        // Log exit
        Helper.logExit(logger, signature, new Object[]{result});

        return result;
    }

    /**
     * Views the template folder editors page.
     *
     * @return the view name.
     * @throws ServiceRequestToolException
     * @since 1.8
     */
    @RequestMapping(value = "templateFolderEditors", method = RequestMethod.GET)
    public String viewTemplateFolderEditors() throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#viewTemplateFolderEditors()";
        User currentUser = ServiceContext.getCurrentUser();

        Logger logger = getLogger();

        if (!currentUser.isUserManagementPermission()) {
            throw Helper.logException(logger, signature,
                new AuthorizationException("Insufficient permissions to view Template Folder Editors."));
        }

        // Log entry
        Helper.logEntrance(logger, signature, null, null);

        String result = "viewTemplateFolderEditors";

        // Log exit
        Helper.logExit(logger, signature, new Object[]{result});

        return result;
    }

    /**
     * Retrieves the customer information by the name.
     *
     * @param name
     *            the name of the customer to retrieve
     * @return the matched customer, or null if not found
     * @throws ServiceRequestToolException
     *             if there is any problem executing the request.
     * @throws IllegalArgumentException
     *             if the name is null.
     * @since 1.1
     */
    @RequestMapping(value = "profile/customer", method = RequestMethod.GET)
    @ResponseBody
    public List<Customer> getCustomerByName(@RequestParam String name) throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#getCustomerByName(String name)";
        Logger logger = getLogger();

        // Log entry
        Helper.logEntrance(logger, signature, new String[] {"name"}, new Object[] {name});

        List<Customer> result = startRequestDataService.getCustomerByName(name);
        // Log exit
        Helper.logExit(logger, signature, new Object[] {result});
        return result;
    }
    
    /**
     * Searches the profiles based on the criteria.
     *
     * @param criteria
     *            the search criteria
     * @return the serialized SearchResult in JSON format
     * @throws IllegalArgumentException
     *             if criteria is null, or if criteria.pageNumber is positive,
     *             criteria.pageSize is not positive
     * @throws com.emc.gs.tools.srf.services.ServiceRequestToolException
     *             if there is any problem executing the request.
     * @since 1.7
     */
    @RequestMapping(value = "profiles/search", method = RequestMethod.POST)
    @ResponseBody
    public SearchResult<Profile> searchProfiles(@RequestBody ProfileSearchCriteria criteria)
        throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#searchProfiles(ProfileSearchCriteria criteria)";

        Logger logger = getLogger();

        // Log entry
        Helper.logEntrance(logger, signature, new String[]{"criteria"}, new Object[]{criteria});

        Profile profile = profileService.getDefaultProfile();
        if (profile != null) {
            Division division = profile.getDivision();
            if (division != null) {
                if (division.getStrictProfileSearch()) {
                    criteria.setDivisionId(division.getId());
                }
            }
        }
        
        SearchResult<Profile> result = profileService.search(criteria);
        
        // Log exit
        Helper.logExit(logger, signature, new Object[]{result});

        return result;
    }
    
    /**
     * This method checks whether the instance of the class was initialized properly.
     *
     * @throws ServiceRequestToolConfigurationException
     *             if profileService/startRequestDataService is null
     */
    @PostConstruct
    protected void checkInit() {
        Helper.checkState(profileService == null, "'profileService' can't be null.");
        Helper.checkState(startRequestDataService == null, "'startRequestDataService' can't be null.");
    }

    /**
     * <p>
     * Sets the value to profileService field.
     * </p>
     *
     * @param profileService
     *            the value of profileService to set
     */
    public void setProfileService(ProfileService profileService) {
        this.profileService = profileService;
    }

    /**
     * <p>
     * Sets the value to startRequestDataService field.
     * </p>
     *
     * @param startRequestDataService
     *            the value of startRequestDataService to set
     */
    public void setStartRequestDataService(StartRequestDataService startRequestDataService) {
        this.startRequestDataService = startRequestDataService;
    }

    /**
     * <p>Sets the deliveryCountries property.</p>
     *
     * @param deliveryCountries a <code>List</code> providing the value for deliveryCountries property.
     * @since 1.6
     */
    public void setDeliveryCountries(List<DeliveryCountry> deliveryCountries) {
        deliveryCountriesMapping.clear();
        for (DeliveryCountry country : deliveryCountries) {
            deliveryCountriesMapping.put(country.getCode(), country);
        }
    }

    /**
     * <p>Sets the read-only properties (first name, last name, email, job title, country) for specified profile with
     * respective values from the {@link User} object bound to current session context.</p>
     * 
     * <p>This method must be used before calling the profile service in order to prevent the malicious attempts to 
     * change the readonly profile properties which are expected to match the SSO HTTP request headers.</p>
     * 
     * @param profile a <code>Profile</code> to be secured.
     * @since 1.6
     */
    private void secureProfile(Profile profile) {
        User user = ServiceContext.getCurrentUser();
        if(user.getUserIdentifier().equals(profile.getUserIdentifier())){
            profile.setFirstName(user.getFirstName());
            profile.setLastName(user.getLastName());
            profile.setEmail(user.getEmail());
            profile.setJobTitle(user.getJobTitle());
            if (deliveryCountriesMapping.containsKey(user.getCountry())) {
                profile.setCountryCode(deliveryCountriesMapping.get(user.getCountry()).getCallingCode());
            } else {
                profile.setCountryCode("");
            }
        }
    }

}

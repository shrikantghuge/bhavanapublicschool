/*
 * This code is copyright (c) 2014 - 2015 EMC Corporation.
 */
package com.emc.gs.tools.srf.web;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.emc.gs.tools.srf.model.Profile;
import com.emc.gs.tools.srf.model.ServiceContext;
import com.emc.gs.tools.srf.model.engagement.DeliveryCountry;
import com.emc.gs.tools.srf.services.ProfileService;

import org.apache.log4j.Logger;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import com.emc.gs.tools.srf.ServiceRequestToolConfigurationException;
import com.emc.gs.tools.srf.model.User;
import com.emc.gs.tools.srf.services.ServiceRequestToolException;
import com.emc.gs.tools.srf.services.UserAdminService;
import com.emc.gs.tools.srf.services.UserService;
import com.emc.gs.tools.srf.services.impl.Helper;

/**
 * <p>
 * The interceptor to check and handle authentication data. It intercepts all existing controllers.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is effectively thread safe after configuration, the configuration is done
 * in a thread safe manner.
 * </p>
 *
 * <p>
 * Version 1.1 Change notes:
 *   <ol>
 *     <li>Supporting new Job Title and Country properties for User entity.</li>
 *   </ol>
 * </p>
 *
 * <p>
 * Changes in version 1.2 (SRT 1.1 FEB 2015 Updates - Template Folder Assembly):
 * <ul>
 * <li>Sets templatePermission to User entity from Profile entity.</li>
 * </ul>
 * <p>
 *
 * <p>
 * Changes in version 1.3 (SRT 1.1 Approval Process Assembly):
 * <ul>
 * <li>Added userAdminService field.</li>
 * <li>Modified preHandle method to set the user roles.</li>
 * </ul>
 * <p>
 *
 * <p>
 * Version 1.4 Change notes:
 *   <ol>
 *     <li>Setting current user's profile ID to session attribute.</li>
 *   </ol>
 * </p>
 *
 * <p>
 * Version 1.5 Change notes:
 *   <ol>
 *     <li>Responding with HTTP 401 status for recognized AJAX requests in case the user is not authenticated or session
 *     expired.</li>
 *     <li>Removed <code>submitter</code> property from <code>Profile</code> and <code>User</code> entities.</li>
 *   </ol>
 * </p>
 *
 * @author zsudraco, isv, duxiaoyang, MonicaMuranyi
 * @version 1.5
 */
public class AuthenticationInterceptor extends HandlerInterceptorAdapter {

    /**
     * <p>
     * Represents the class name.
     * </p>
     */
    private static final String CLASSNAME = AuthenticationInterceptor.class.getName();

    /**
     * Represents the UserService instance for retrieving, creating and updating the logged in user. It is modified by
     * setter. It is injected by Spring. It can not be null after injected.
     */
    private UserService userService;

    /**
     * <p>A <code>ProfileService</code> providing the value for profileService property.</p>
     *
     * @since 1.1
     */
    private ProfileService profileService;
    
    /**
     * <p>A <code>UserAdminService</code> providing the value for userAdminService property.</p>
     *
     * @since 1.1
     */
    private UserAdminService userAdminService;

    /**
     * Represents the userSessionAttributeName. It is modified by
     * setter. It is injected by Spring. It can not be null after injected.
     */
    private String userSessionAttributeName = "user";

    /**
     * Represents the loginPage. It is modified by
     * setter. It is injected by Spring. It can not be null after injected.
     */
    private String loginPage;

    /**
     * Represents the userIdentifierHeaderName. It is modified by
     * setter. It is injected by Spring. It can not be null after injected.
     */
    private String userIdentifierHeaderName;

    /**
     * Represents the firstNameHeaderName. It is modified by
     * setter. It is injected by Spring. It can not be null after injected.
     */
    private String firstNameHeaderName;

    /**
     * Represents the lastNameHeaderName. It is modified by
     * setter. It is injected by Spring. It can not be null after injected.
     */
    private String lastNameHeaderName;

    /**
     * Represents the emailHeaderName. It is modified by
     * setter. It is injected by Spring. It can not be null after injected.
     */
    private String emailHeaderName;

    /**
     * <p>A <code>String</code> providing the value for jobTitleHeaderName property.</p>
     * 
     * @since 1.1
     */
    private String jobTitleHeaderName;

    /**
     * <p>A <code>String</code> providing the value for countryHeaderName property.</p>
     * 
     * @since 1.1
     */
    private String countryHeaderName;
    
    /**
     * This is the logger used for logging. It is initialized in constructor and never changed afterwards. It can not be
     * null.
     */
    private final Logger logger;

    /**
     * <p>A <code>List</code> providing the value for deliveryCountries property.</p>
     *
     * @since 1.1
     */
    private Map<String, DeliveryCountry> deliveryCountriesMapping = new HashMap<String, DeliveryCountry>();

    /**
     * Default constructor.
     */
    public AuthenticationInterceptor() {
        this.logger = Logger.getLogger(this.getClass());
    }

    /**
     * This method checks whether the instance of the class was initialized properly.
     * 
     * @throws ServiceRequestToolConfigurationException
     *             if userService is null
     *             or userSessionAttributeName is null or empty
     *             or loginPage is null or empty
     *             or userIdentifierHeaderName is null or empty
     *             or firstNameHeaderName is null or empty
     *             or lastNameHeaderName is null or empty
     *             or emailHeaderName is null or empty
     */
    @PostConstruct
    protected void checkInit() {
        Helper.checkState(userService == null, "'userService' can't be null.");
        Helper.checkState(profileService == null, "'userService' can't be null.");
        Helper.checkState(userAdminService == null, "'userAdminService' can't be null.");
        Helper.checkState(Helper.isStringNullOrEmpty(userSessionAttributeName),
                "'userSessionAttributeName' can't be null/empty.");
        Helper.checkState(Helper.isStringNullOrEmpty(loginPage), "'loginPage' can't be null/empty.");
        Helper.checkState(Helper.isStringNullOrEmpty(userIdentifierHeaderName),
                "'userIdentifierHeaderName' can't be null/empty.");
        Helper.checkState(Helper.isStringNullOrEmpty(firstNameHeaderName), "'firstNameHeaderName' can't be null/empty.");
        Helper.checkState(Helper.isStringNullOrEmpty(lastNameHeaderName), "'lastNameHeaderName' can't be null/empty.");
        Helper.checkState(Helper.isStringNullOrEmpty(emailHeaderName), "'emailHeaderName' can't be null/empty.");
        Helper.checkState(Helper.isStringNullOrEmpty(jobTitleHeaderName), "'jobTitleHeaderName' can't be null/empty.");
        Helper.checkState(Helper.isStringNullOrEmpty(countryHeaderName), "'countryHeaderName' can't be null/empty.");
    }

    /**
     * Check if user is already logged in, if not get user details from configured headers an log user in.
     * 
     * @param request
     *            the {@link javax.servlet.http.HttpServletRequest} instance
     * @param response
     *            the {@link javax.servlet.http.HttpServletResponse} instance
     * @param handler
     *            the handler
     * @return true if user is logged in; otherwise redirect to login page
     * @throws com.emc.gs.tools.srf.services.ServiceRequestToolException
     *             If any error occurs.
     */
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
            throws ServiceRequestToolException {
        final String signature = CLASSNAME
                + "#preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)";

        // Log entry
        Helper.logEntrance(logger, signature, new String[]{"request", "response", "handler"},
            new Object[]{request, response, handler});

        try {
            User user = (User) request.getSession().getAttribute(userSessionAttributeName);

            boolean result;

            if (user == null) {
                // Get user data from request header
                String userIdentifier = request.getHeader(userIdentifierHeaderName);
                String firstName = request.getHeader(firstNameHeaderName);
                String lastName = request.getHeader(lastNameHeaderName);
                String email = request.getHeader(emailHeaderName);
                String jobTitle = request.getHeader(jobTitleHeaderName);
                String country = request.getHeader(countryHeaderName);

                // User identifier must be present
                if (!Helper.isStringNullOrEmpty(userIdentifier)) {
                    // The user entity
                    user = new User();
                    user.setUserIdentifier(userIdentifier);
                    user.setFirstName(firstName);
                    user.setLastName(lastName);
                    user.setEmail(email);
                    user.setJobTitle(jobTitle);
                    user.setCountry(country);

                    // Authenticate user
                    user = userService.authenticate(user);

                    // Once user successfully logs into application update the profile properties with data from 
                    // SSO HTTP headers
                    if (user != null) {
                        ServiceContext.setCurrentUser(user); // Need to set-up service context temporarily
                        Profile profile = profileService.getDefaultProfile();
                        if (profile != null) {
                            profile.setFirstName(user.getFirstName());
                            profile.setLastName(user.getLastName());
                            profile.setEmail(user.getEmail());
                            profile.setJobTitle(user.getJobTitle());
                            if (deliveryCountriesMapping.containsKey(user.getCountry())) {
                                profile.setCountryCode(deliveryCountriesMapping.get(user.getCountry()).getCallingCode());
                            } else {
                                profile.setCountryCode("");
                            }
                            profileService.update(profile);
                            // save template permission into user entity
                            user.setTemplatePermission(profile.isTemplatePermission());
                            // save approver permission into user entity
                            user.setApprover(profile.isApprover());
                        }
                        // save user management permission into user entity
                        user.setUserManagementPermission(userAdminService.hasUserManagementPermission(user.getUserIdentifier()));
                        ServiceContext.clear();
                    }

                }
            }

            if (user == null) {
                String requestedWith = request.getHeader("X-Requested-With");
                if ("XMLHttpRequest".equalsIgnoreCase(requestedWith)) {
                    // For AJAX requests respond with HTTP 401
                    response.sendError(HttpServletResponse.SC_UNAUTHORIZED);
                } else {
                    // Failed, redirect to login page
                    response.sendRedirect(loginPage);
                }
                result = false;
            } else {
                // Put user to session attribute
                request.getSession().setAttribute(userSessionAttributeName, user);
                
                ServiceContext.setCurrentUser(user); // Need to set-up service context temporarily
                Profile defaultProfile = this.profileService.getDefaultProfile();
                if (defaultProfile != null) {
                    request.getSession().setAttribute("currentUserProfileId", defaultProfile.getId());
                }
                ServiceContext.clear();
                
                result = true;
            }

            // Log exit
            Helper.logExit(logger, signature, new Object[] {result});

            return result;
        } catch (IOException e) {
            // Log exception
            throw Helper.logException(logger, signature, new ServiceRequestToolException(
                    "An error has occurred while trying to redirect.", e));
        }
    }

    /**
     * <p>
     * Sets the value to userService field.
     * </p>
     * 
     * @param userService
     *            the userService to set
     */
    public void setUserService(UserService userService) {
        this.userService = userService;
    }

    /**
     * <p>
     * Sets the value to userSessionAttributeName field.
     * </p>
     * 
     * @param userSessionAttributeName
     *            the userSessionAttributeName to set
     */
    public void setUserSessionAttributeName(String userSessionAttributeName) {
        this.userSessionAttributeName = userSessionAttributeName;
    }

    /**
     * <p>
     * Sets the value to loginPage field.
     * </p>
     * 
     * @param loginPage
     *            the loginPage to set
     */
    public void setLoginPage(String loginPage) {
        this.loginPage = loginPage;
    }

    /**
     * <p>
     * Sets the value to userIdentifierHeaderName field.
     * </p>
     * 
     * @param userIdentifierHeaderName
     *            the userIdentifierHeaderName to set
     */
    public void setUserIdentifierHeaderName(String userIdentifierHeaderName) {
        this.userIdentifierHeaderName = userIdentifierHeaderName;
    }

    /**
     * <p>
     * Sets the value to firstNameHeaderName field.
     * </p>
     * 
     * @param firstNameHeaderName
     *            the firstNameHeaderName to set
     */
    public void setFirstNameHeaderName(String firstNameHeaderName) {
        this.firstNameHeaderName = firstNameHeaderName;
    }

    /**
     * <p>
     * Sets the value to lastNameHeaderName field.
     * </p>
     * 
     * @param lastNameHeaderName
     *            the lastNameHeaderName to set
     */
    public void setLastNameHeaderName(String lastNameHeaderName) {
        this.lastNameHeaderName = lastNameHeaderName;
    }

    /**
     * <p>
     * Sets the value to emailHeaderName field.
     * </p>
     * 
     * @param emailHeaderName
     *            the emailHeaderName to set
     */
    public void setEmailHeaderName(String emailHeaderName) {
        this.emailHeaderName = emailHeaderName;
    }

    /**
     * <p>Sets the countryHeaderName property.</p>
     *
     * @param countryHeaderName a <code>String</code> providing the value for countryHeaderName property.
     * @since 1.1
     */
    public void setCountryHeaderName(String countryHeaderName) {
        this.countryHeaderName = countryHeaderName;
    }

    /**
     * <p>Sets the jobTitleHeaderName property.</p>
     *
     * @param jobTitleHeaderName a <code>String</code> providing the value for jobTitleHeaderName property.
     * @since 1.1
     */
    public void setJobTitleHeaderName(String jobTitleHeaderName) {
        this.jobTitleHeaderName = jobTitleHeaderName;
    }

    /**
     * <p>Sets the profileService property.</p>
     *
     * @param profileService a <code>ProfileService</code> providing the value for profileService property.
     * @since 1.1
     */
    public void setProfileService(ProfileService profileService) {
        this.profileService = profileService;
    }
    
    /**
     * <p>Sets the userAdminService property.</p>
     *
     * @param userAdminService a <code>UserAdminService</code> providing the value for userAdminService property.
     * @since 1.1
     */
    public void setUserAdminService(UserAdminService userAdminService) {
        this.userAdminService = userAdminService;
    }
    
    /**
     * <p>Sets the deliveryCountries property.</p>
     *
     * @param deliveryCountries a <code>List</code> providing the value for deliveryCountries property.
     * @since 1.1
     */
    public void setDeliveryCountries(List<DeliveryCountry> deliveryCountries) {
        deliveryCountriesMapping.clear();
        for (DeliveryCountry country : deliveryCountries) {
            deliveryCountriesMapping.put(country.getCode(), country);
        }
    }
}

INSERT INTO pdmname VALUES(24, 'Geographic PDM', '', '', '', '', '', '', '', '', '', '', 5)/
INSERT INTO pdmname VALUES(28, 'Dawn Paul', 'Program Delivery Manager', '10400 Viking Drive', 'Suite 400', 'Eden Prairie', 'Minnesota', '55344', '(952) 562-7374', '(952) 828-9509', '(612) 860-8154', 'dawn.paul@emc.com', 6)/
INSERT INTO pdmname VALUES(56, 'Geographic PDM', '', '', '', '', '', '', '', '', '', '', 7)/
INSERT INTO pdmname VALUES(25, 'Akin Desai', 'Program Delivery Manager', '2201 Dupont Drive', '', 'Irvine', 'California', '92612', '(909) 859-9518', '(949) 833-0690', '(909) 859-9518', 'akin.desai@emc.com', 6)/
INSERT INTO pdmname VALUES(42, 'Shiju Vadakot', 'Program Delivery Manager', '300 Four Falls Corporate Center', 'Suite 700', 'Conshohocken', 'Pennsylvania', '19428', '(610) 234-2578', '(215) 754-4277', '(215) 570-6881', 'shiju.vadakot@emc.com', 7)/
INSERT INTO pdmname VALUES(35, 'Shiju Vadakot', 'Program Delivery Manager', '300 Four Falls Corporate Center', 'Suite 700', 'Conshohocken', 'Pennsylvania', '19428', '(610) 234-2578', '(215) 754-4277', '(215) 570-6881', 'shiju.vadakot@emc.com', 6)/

INSERT INTO GeoState VALUES(1, 1, 6, 28, 'Alabama')/
INSERT INTO GeoState VALUES(51, 1, 7, 56, 'Alberta')/
INSERT INTO GeoState VALUES(3, 1, 6, 25, 'Arkansas')/
INSERT INTO GeoState VALUES(52, 1, 7, 56, 'British Columbia')/
INSERT INTO GeoState VALUES(7, 1, 7, 42, 'Connecticut')/
INSERT INTO GeoState VALUES(8, 1, 6, 35, 'Delaware')/
INSERT INTO GeoState VALUES(90, 1, 6, 35, 'District of Columbia')/
INSERT INTO GeoState VALUES(9, 1, 6, 28, 'Florida')/
INSERT INTO GeoState VALUES(10, 1, 6, 28, 'Georgia')/
INSERT INTO GeoState VALUES(18, 1, 6, 28, 'Louisiana')/
INSERT INTO GeoState VALUES(19, 1, 7, 42, 'Maine')/
INSERT INTO GeoState VALUES(53, 1, 7, 56, 'Manitoba')/
INSERT INTO GeoState VALUES(20, 1, 6, 35, 'Maryland')/
INSERT INTO GeoState VALUES(21, 1, 7, 42, 'Massachusetts')/
INSERT INTO GeoState VALUES(22, 1, 2, 7, 'Michigan')/
INSERT INTO GeoState VALUES(24, 1, 6, 28, 'Mississippi')/
INSERT INTO GeoState VALUES(29, 1, 7, 42, 'New Hampshire')/
INSERT INTO GeoState VALUES(31, 1, 6, 35, 'North Carolina')/
INSERT INTO GeoState VALUES(36, 1, 6, 25, 'Oklahoma')/
INSERT INTO GeoState VALUES(38, 1, 6, 35, 'Pennsylvania (East)')/
INSERT INTO GeoState VALUES(39, 1, 6, 35, 'Rhode Island')/
INSERT INTO GeoState VALUES(40, 1, 6, 35, 'South Carolina')/
INSERT INTO GeoState VALUES(42, 1, 6, 28, 'Tennessee')/
INSERT INTO GeoState VALUES(43, 1, 6, 25, 'Texas')/
INSERT INTO GeoState VALUES(45, 1, 7, 42, 'Vermont')/
INSERT INTO GeoState VALUES(46, 1, 6, 35, 'Virginia')/
INSERT INTO GeoState VALUES(54, 1, 7, 56, 'New Brunswick')/
INSERT INTO GeoState VALUES(55, 1, 7, 56, 'Newfoundland and Labrador')/
INSERT INTO GeoState VALUES(56, 1, 7, 56, 'Northwest Territories')/
INSERT INTO GeoState VALUES(57, 1, 7, 56, 'Nova Scotia')/
INSERT INTO GeoState VALUES(58, 1, 7, 56, 'Nunavut')/
INSERT INTO GeoState VALUES(59, 1, 7, 56, 'Ontario')/
INSERT INTO GeoState VALUES(60, 1, 7, 56, 'Prince Edward Island')/
INSERT INTO GeoState VALUES(61, 1, 7, 56, 'Quebec')/
INSERT INTO GeoState VALUES(62, 1, 7, 56, 'Saskatchewan')/
INSERT INTO GeoState VALUES(63, 1, 7, 56, 'Yukon Territory')/
INSERT INTO GeoState VALUES(94, 1, 5, 24, 'Puerto Rico')/
INSERT INTO GeoState VALUES(95, 1, 5, 24, 'Virgin Islands')/

INSERT INTO GeoState VALUES(65, 2, 5, 24, 'Bermuda')/
INSERT INTO GeoState VALUES(69, 2, 5, 24, 'Colombia')/
INSERT INTO GeoState VALUES(70, 2, 5, 24, 'Costa Rica')/
INSERT INTO GeoState VALUES(71, 2, 5, 24, 'Cuba')/
INSERT INTO GeoState VALUES(72, 2, 5, 24, 'Dominican Republic')/
INSERT INTO GeoState VALUES(73, 2, 5, 24, 'Ecuador')/
INSERT INTO GeoState VALUES(74, 2, 5, 24, 'El Salvador')/
INSERT INTO GeoState VALUES(75, 2, 5, 24, 'French Guiana')/
INSERT INTO GeoState VALUES(76, 2, 5, 24, 'Guatemala')/
INSERT INTO GeoState VALUES(77, 2, 5, 24, 'Guyana')/
INSERT INTO GeoState VALUES(78, 2, 5, 24, 'Honduras')/
INSERT INTO GeoState VALUES(79, 2, 5, 24, 'Jamaica')/
INSERT INTO GeoState VALUES(80, 2, 5, 24, 'Mexico')/
INSERT INTO GeoState VALUES(81, 2, 5, 24, 'Nicaragua')/
INSERT INTO GeoState VALUES(82, 2, 5, 24, 'Panama')/
INSERT INTO GeoState VALUES(85, 2, 5, 24, 'Puerto Rico')/
INSERT INTO GeoState VALUES(86, 2, 5, 24, 'Suriname')/
INSERT INTO GeoState VALUES(88, 2, 5, 24, 'Venezuela')/

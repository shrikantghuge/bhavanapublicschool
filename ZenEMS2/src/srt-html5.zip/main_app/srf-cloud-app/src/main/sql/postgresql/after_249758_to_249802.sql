UPDATE ProjectType SET name = 'Concession Delivery' WHERE id = 2;


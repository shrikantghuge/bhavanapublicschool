INSERT INTO MaterialCode VALUES (140, 'PS-CUS-IIGSOL', 'PS-CUS-IIGSOL', 'PS-CUS-EXPIIG', 2, 2);

INSERT INTO MaterialCode_Competency (material_id, competency_id) VALUES(140, 205);
INSERT INTO MaterialCode_Competency (material_id, competency_id) VALUES(140, 211);
INSERT INTO MaterialCode_Competency (material_id, competency_id) VALUES(140, 212);
INSERT INTO MaterialCode_Competency (material_id, competency_id) VALUES(140, 213);
INSERT INTO MaterialCode_Competency (material_id, competency_id) VALUES(140, 214);
INSERT INTO MaterialCode_Competency (material_id, competency_id) VALUES(140, 226);
INSERT INTO MaterialCode_Competency (material_id, competency_id) VALUES(140, 228);

ALTER TABLE StartRequestData ADD (foo CLOB)/
UPDATE StartRequestData SET foo = service_request_scope/
ALTER TABLE StartRequestData DROP COLUMN service_request_scope/
ALTER TABLE StartRequestData RENAME COLUMN foo TO service_request_scope/
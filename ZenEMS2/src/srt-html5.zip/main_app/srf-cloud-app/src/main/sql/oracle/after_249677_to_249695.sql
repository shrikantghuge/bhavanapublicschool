INSERT INTO Division values(18, 'ANZ', '', 'ANZ')/
INSERT INTO Division values(19, 'China', '', 'China')/
INSERT INTO Division values(20, 'India', '', 'India')/
INSERT INTO Division values(21, 'Japan', '', 'Japan')/
INSERT INTO Division values(22, 'Korea', '', 'Korea')/
INSERT INTO Division values(23, 'South East Asia', '', 'South East Asia')/
INSERT INTO Division values(24, 'RSA', '', 'RSA')/
INSERT INTO Division values(25, 'ECD', '', 'ECD')/
INSERT INTO Division values(26, 'MS', '', 'MS')/

INSERT INTO pdmname VALUES(132, 'TBD', 'TBD', 'TBD', 'TBD', 'TBD', 'TBD', '', 'TBD', '', 'TBD', 'MS@emc.com', 26)/
INSERT INTO pdmname VALUES(133, 'TBD', 'TBD', 'TBD', 'TBD', 'TBD', 'TBD', '', 'TBD', '', 'TBD', 'TBD@emc.com', 23)/
INSERT INTO pdmname VALUES(134, 'TBD', 'TBD', 'TBD', 'TBD', 'TBD', 'TBD', '', 'TBD', '', 'TBD', 'TBD@emc.com', 21)/
INSERT INTO pdmname VALUES(135, 'TBD', 'TBD', 'TBD', 'TBD', 'TBD', 'TBD', '', 'TBD', '', 'TBD', 'TBD@emc.com', 22)/
INSERT INTO pdmname VALUES(136, 'TBD', 'TBD', 'TBD', 'TBD', 'TBD', 'TBD', '', 'TBD', '', 'TBD', 'TBD@emc.com', 20)/
INSERT INTO pdmname VALUES(137, 'RSA', 'RSA', 'RSA', 'RSA', 'RSA', 'RSA', '', 'RSA', '', 'RSA', 'RSA@emc.com', 24)/
INSERT INTO pdmname VALUES(138, 'TBD', 'TBD', 'TBD', 'TBD', 'TBD', 'TBD', '', 'TBD', '', 'TBD', 'TBD@emc.com', 19)/
INSERT INTO pdmname VALUES(139, 'TBD', 'TBD', 'TBD', 'TBD', 'TBD', 'TBD', '', 'TBD', '', 'TBD', 'TBD@emc.com', 18)/
INSERT INTO pdmname VALUES(140, 'ECD', 'ECD', 'ECD', 'ECD', 'ECD', 'ECD', '', 'ECD', '', 'ECD', 'ECD@emc.com', 25)/
UPDATE pdmname SET pdm_name='Eduardo Morales', title='Program Delivery Manager', address1='Av Rio Negro, 161', address2='8 Andar', city='Barueri', state='Sao Paulo', postalcode='06455-020', officenumber='55-11-2078-1522', faxnumber='55-11-2078-1699', mobilenumber='55-11-99901-4398', emailaddress='eduardo.morales@emc.com' WHERE id = 1/
UPDATE pdmname SET pdm_name='Geographic PDM', title='', address1='', address2='', city='', state='', postalcode='', officenumber='', faxnumber='', mobilenumber='', emailaddress='' WHERE id = 2/
UPDATE pdmname SET pdm_name='Akin Desai', title='Program Delivery Manager', address1='2201 Dupont Drive', address2='', city='Irvine', state='California', postalcode='92612', officenumber='(909) 859-9518', faxnumber='(949) 833-0690', mobilenumber='(909) 859-9518', emailaddress='akin.desai@emc.com' WHERE id = 3/
UPDATE pdmname SET pdm_name='Jason Cronister', title='Program Delivery Manager', address1='10400 Viking Drive', address2='Suite 400', city='Eden Prairie', state='Minnesota', postalcode='55344', officenumber='(952) 562-7354', faxnumber='(952) 828-9509', mobilenumber='(612) 308-1578', emailaddress='jason.cronister@emc.com' WHERE id = 4/
UPDATE pdmname SET pdm_name='Chris O''Neal', title='Program Delivery Manager', address1='600 Emerson Road', address2='Suite 400', city='Creve Coeur', state='Missouri', postalcode='63141', officenumber='(314) 989-3803', faxnumber='(314) 469-6169', mobilenumber='(636) 288-2550', emailaddress='christopher.oneal@emc.com' WHERE id = 5/
UPDATE pdmname SET pdm_name='Dawn Paul', title='Program Delivery Manager', address1='10400 Viking Drive', address2='Suite 400', city='Eden Prairie', state='Minnesota', postalcode='55344', officenumber='(952) 562-7374', faxnumber='(952) 828-9509', mobilenumber='(612) 860-8154', emailaddress='dawn.paul@emc.com' WHERE id = 7/
UPDATE pdmname SET pdm_name='Edie Mikalauskas', title='Program Delivery Manager', address1='36555 Corporate Drive', address2='2nd Floor', city='Farmington Hills', state='Michigan', postalcode='48331', officenumber='(248) 957-5834', faxnumber='None', mobilenumber='None', emailaddress='edie.mikalauskas@emc.com' WHERE id = 8/
UPDATE pdmname SET pdm_name='Ron Tremmel', title='Program Delivery Manager', address1='4225 Naperville Road', address2='Suite 500', city='Lisle', state='Illinois', postalcode='60532', officenumber='(414) 319-7637', faxnumber='(414) 319-7690', mobilenumber='(414) 704-7620', emailaddress='ron.tremmel@emc.com' WHERE id = 12/
UPDATE pdmname SET pdm_name='Shiju Vadakot', title='Program Delivery Manager', address1='300 Four Falls Corporate Center', address2='Suite 700', city='Conshohocken', state='Pennsylvania', postalcode='19428', officenumber='(610) 234-2578', faxnumber='(215) 754-4277', mobilenumber='(215) 570-6881', emailaddress='shiju.vadakot@emc.com' WHERE id = 14/
UPDATE pdmname SET pdm_name='Creighton Anderson', title='Program Delivery Manager', address1='8444 West Park Drive', address2='Suite 800', city='McLean', state='Virginia', postalcode='20136', officenumber='703 970 5202', faxnumber='', mobilenumber='703 517 3034', emailaddress='creighton.anderson@emc.com' WHERE id = 18/
UPDATE pdmname SET pdm_name='Dwight Davison', title='Program Delivery Manager', address1='8444 West Park Drive', address2='Suite 800', city='McLean', state='Virginia', postalcode='20136', officenumber='703 970 5349', faxnumber='703 842 8248', mobilenumber='703 282 0335', emailaddress='dwight.davison@emc.com' WHERE id = 21/
UPDATE pdmname SET pdm_name='Luis Alvarez Cuesta', title='Program Delivery Manager', address1='Torre Mayor, Paseo de la Reforma # 505', address2='Piso 39 - Col. Cuauhtemoc', city='Mexico City', state='Distrito Federal', postalcode='6500', officenumber='52-55-5080-3700', faxnumber='52-55-5080-3841', mobilenumber='52-55-3888-1316', emailaddress='Luis.AlvarezCuesta@emc.com' WHERE id = 23/
UPDATE pdmname SET pdm_name='Dan Elliott', title='Program Delivery Manager', address1='7900 Triad Center Drive', address2='', city='Greensboro', state='North Carolina', postalcode='27409', officenumber='None', faxnumber='None', mobilenumber='(336) 210-0691', emailaddress='dan.elliott@emc.com' WHERE id = 26/
UPDATE pdmname SET pdm_name='David Kopca', title='Program Delivery Manager', address1='14786 Preston Road', address2='', city='Dallas', state='Texas', postalcode='75255', officenumber='None', faxnumber='None', mobilenumber='(972) 892-7835', emailaddress='david.kopca@emc.com' WHERE id = 27/
UPDATE pdmname SET pdm_name='Dena Bowman', title='Program Delivery Manager', address1='14785 Preston Road', address2='', city='Dallas', state='Texas', postalcode='75254', officenumber='None', faxnumber='None', mobilenumber='(972) 759-6943', emailaddress='dena.bowman@emc.com' WHERE id = 29/
UPDATE pdmname SET pdm_name='Jason Hargrove', title='Program Delivery Manager', address1='8295 Tournament Drive', address2='Suite 350', city='Memphis', state='Tennessee', postalcode='38125', officenumber='None', faxnumber='None', mobilenumber='(901) 748-7331', emailaddress='jason.hargrove@emc.com' WHERE id = 31/
UPDATE pdmname SET pdm_name='Jeff Brinkman', title='Program Delivery Manager', address1='2850 Premiere Parkway', address2='', city='Duluth', state='Georgia', postalcode='30097', officenumber='None', faxnumber='None', mobilenumber='(770) 814-3290', emailaddress='jeff.brinkman@emc.com' WHERE id = 32/
UPDATE pdmname SET pdm_name='Pete Zipay', title='Program Delivery Manager', address1='485 N. Keller Road', address2='Suite 501', city='Maitland', state='Florida', postalcode='32751', officenumber='None', faxnumber='None', mobilenumber='(407) 838-2832', emailaddress='peter.zipay@emc.com' WHERE id = 33/
UPDATE pdmname SET pdm_name='Tony Ferguson', title='Program Delivery Manager', address1='8820 Columbia 100 Parkway', address2='', city='Columbia', state='Maryland', postalcode='21045', officenumber='None', faxnumber='None', mobilenumber='(443) 367-5322', emailaddress='tony.ferguson@emc.com' WHERE id = 37/
UPDATE pdmname SET pdm_name='John Root', title='Program Delivery Manager', address1='9 Townsend West', address2='', city='Nashua', state='New Hampshire', postalcode='03063', officenumber='(716) 200-2570', faxnumber='', mobilenumber='', emailaddress='john.root@emc.com' WHERE id = 38/
UPDATE pdmname SET pdm_name='Dennis Scheil', title='Program Delivery Manager', address1='184 Liberty Corner Rd', address2='4th Flr', city='Warren', state='New Jersey', postalcode='07059', officenumber='(908) 286-7691', faxnumber='None', mobilenumber='(917) 209-9850', emailaddress='dennis.scheil@emc.com' WHERE id = 43/
UPDATE pdmname SET pdm_name='Jeff Kells', title='Program Delivery Manager', address1='184 Liberty Corner Rd', address2='4th Flr', city='Warren', state='New Jersey', postalcode='07059', officenumber='(908) 286-7761', faxnumber='None', mobilenumber='(732) 299-6982', emailaddress='jeffrey.kells@emc.com' WHERE id = 45/
UPDATE pdmname SET pdm_name='Rick Weigand', title='Program Delivery Manager', address1='One Huntington', address2='Quadrangle', city='Melville', state='New York', postalcode='11747', officenumber='(716) 835-3755', faxnumber='None', mobilenumber='(516) 428-1735', emailaddress='rick.weigand@emc.com' WHERE id = 46/
UPDATE pdmname SET pdm_name='Akin Desai', title='Program Delivery Manager', address1='2201 Dupont Drive', address2='', city='Irvine', state='California', postalcode='92612', officenumber='(909) 859-9518', faxnumber='(949) 833-0690', mobilenumber='(909) 859-9518', emailaddress='akin.desai@emc.com' WHERE id = 48/
UPDATE pdmname SET pdm_name='Brandon Smith', title='Program Delivery Manager', address1='2201 Dupont Drive', address2='Suite 500', city='Irvine', state='California', postalcode='92612', officenumber='(949) 797-3304', faxnumber='(949) 833-0690', mobilenumber='(949) 202-7052', emailaddress='brandon.smith@emc.com' WHERE id = 49/
UPDATE pdmname SET pdm_name='Justin Holtzinger', title='Program Delivery Manager', address1='6801 Koll Center Parkway', address2='', city='Pleasanton', state='California', postalcode='94566', officenumber='', faxnumber='(925) 407-8279', mobilenumber='(925) 831-2000', emailaddress='justin.holtzinger@emc.com' WHERE id = 53/
UPDATE pdmname SET pdm_name='Nathan Mondragon', title='Program Delivery Manager', address1='8000 South Chester St', address2='Suite 600', city='Englewood', state='Colorado', postalcode='80112', officenumber='(303) 390-7016', faxnumber='(303) 200-8133', mobilenumber='(720) 413-9267', emailaddress='nathan.mondragon@emc.com' WHERE id = 54/
UPDATE pdmname SET pdm_name='Tony Thomas', title='Program Delivery Manager', address1='6801 Koll Center Parkway', address2='', city='Pleasanton', state='California', postalcode='94566', officenumber='(925) 600-5615', faxnumber='(925) 304-7437', mobilenumber='(925) 207-5202', emailaddress='tony.thomas@emc.com' WHERE id = 55/
UPDATE pdmname SET pdm_name='Mohamed El-Zomor', title='Program Delivery Manager', address1='11351 King Fahd Road', address2='EMC computer systems', city='Riyadh', state='Saudi Arabia', postalcode='', officenumber='+96(0)6112794515', faxnumber='', mobilenumber='+96(0)6540212375', emailaddress='mohamed.elzomor@emc.com' WHERE id = 59/
UPDATE pdmname SET pdm_name='Mahmood Shaker', title='Program Delivery Manager', address1='5th Floor-Internet City', address2='Alpha Building', city='Dubai', state='United Arab Emirates', postalcode='', officenumber='+97(0)144240462', faxnumber='', mobilenumber='+97(0)1526408821', emailaddress='Mahmood.Shaker@emc.com' WHERE id = 60/
UPDATE pdmname SET pdm_name='Suzanne Seif', title='Program Delivery Manager', address1='5th Floor-Internet City', address2='Alpha Building', city='Dubai', state='United Arab Emirates', postalcode='', officenumber='+97(0)144240457', faxnumber='', mobilenumber='+97(0)1501457342', emailaddress='suzanne.seif@emc.com' WHERE id = 67/
UPDATE pdmname SET pdm_name='Shakeel Shaik', title='Program Delivery Manager', address1='3021 William Nicol Drive', address2='Bryanston', city='Johannesburg,', state='South Africa', postalcode='', officenumber='+27(0)115810117', faxnumber='', mobilenumber='+27829034587', emailaddress='Shakeel.Shaik@emc.com' WHERE id = 71/
UPDATE pdmname SET pdm_name='Wendy Burns', title='Program Delivery Manager', address1='1st Floor The Royals', address2='353 Altrincham Road', city='Manchester', state='UK', postalcode='', officenumber='+44(0)1619465932', faxnumber='', mobilenumber='+44(0)7802241300', emailaddress='wendy.burns@emc.com' WHERE id = 73/
UPDATE pdmname SET pdm_name='Michael Hutchinson', title='Program Delivery Manager', address1='EMC Tower', address2='Great West Road', city='Brentford', state='UK', postalcode='', officenumber='+44(0)7730052623', faxnumber='', mobilenumber='+44(0)7730052623', emailaddress='michael.hutchinson@emc.com' WHERE id = 74/
UPDATE pdmname SET pdm_name='Jean Philippe Bianic', title='Sr Mgr, Professional Services', address1='River Ouest', address2='80 Quai Voltaire', city='Bezons', state='FR', postalcode='', officenumber='+33(0) 1 39969058', faxnumber='', mobilenumber='+33(0) 6 17221974', emailaddress='jean-philippe.bianic@emc.com' WHERE id = 76/
UPDATE pdmname SET pdm_name='Eric Avril', title='Mgr, Professional Services', address1='River Ouest', address2='80 Quai Voltaire', city='Bezons', state='FR', postalcode='', officenumber='+33(0)139969026', faxnumber='', mobilenumber='+33 (0)6 21 20 48 44', emailaddress='eric.avril@emc.com' WHERE id = 79/
UPDATE pdmname SET pdm_name='Manfred Oberpaul', title='Program Delivery Manager', address1='Osterfeldstrasse 84', address2='', city='Munich', state='Germany', postalcode='', officenumber='+49(0)8993091243', faxnumber='', mobilenumber='+49(0)1608818056', emailaddress='manfred.oberpaul@emc.com' WHERE id = 82/
UPDATE pdmname SET pdm_name='Raphael Mela', title='Program Delivery Manager', address1='Am Kronberger Hang 2a', address2='', city='Schwalbach', state='Germany', postalcode='', officenumber='+49(0)61964728374', faxnumber='', mobilenumber='+49(0)1734453428', emailaddress='raphael.mela@emc.com' WHERE id = 83/
UPDATE pdmname SET pdm_name='Chaled Rashwan', title='Program Delivery Manager', address1='Osterbeekstr. 90B', address2='', city='Hamburg', state='Germany', postalcode='', officenumber='+49(0)4027131626', faxnumber='', mobilenumber='+4915164962843', emailaddress='Chaled.Rashwan@emc.com' WHERE id = 84/
UPDATE pdmname SET pdm_name='Patrick Arn', title='GPSd Lead Switzerland / Manager Professional Services', address1='Hardturmstrasse 181', address2='', city='CH8005 Zürich', state='Switzerland', postalcode='', officenumber='+41(0)434446749', faxnumber='', mobilenumber='+41(0)792405046', emailaddress='patrick.arn@emc.com' WHERE id = 86/
UPDATE pdmname SET pdm_name='Koen Segers', title='Global Professional Services Delivery Lead BeLux', address1='Imperiastraat 18', address2='B1930', city='Zaventem', state='Belgium', postalcode='', officenumber='+32(0)27230100', faxnumber='', mobilenumber='+32(0)479682361', emailaddress='koen.segers@emc.com' WHERE id = 87/
UPDATE pdmname SET pdm_name='Ole Wulff', title='Sr Mgr, Professional Services', address1='Linde Allé 9', address2='', city='Nærum', state='Denmark', postalcode='', officenumber='+45(0)45560316', faxnumber='', mobilenumber='+45(0)24248160', emailaddress='ole.wulff@emc.com' WHERE id = 89/
UPDATE pdmname SET pdm_name='Teemu Silvennoinen', title='Team Lead, Prof Services', address1='Lauttasaarenmaki 4', address2='', city='Helsinki', state='Finland', postalcode='', officenumber='+35(0)8201202200', faxnumber='', mobilenumber='+35(0)8407700913', emailaddress='teemu.silvennoinen@emc.com' WHERE id = 90/
UPDATE pdmname SET pdm_name='Eirik Storeng', title='Team Lead, Prof Services', address1='Grenseveien 107', address2='', city='Oslo', state='Norway', postalcode='', officenumber='+47(0)23207727', faxnumber='', mobilenumber='+47(0)40004555', emailaddress='Eirik.Storeng@emc.com' WHERE id = 91/
UPDATE pdmname SET pdm_name='Robert Forsberg', title='Sr Mgr, Professional Services', address1='Telegrafgatan 4', address2='', city='Solna', state='Sweden', postalcode='', officenumber='+46(0)855512011', faxnumber='', mobilenumber='+46(0)761009330', emailaddress='robert.forsberg@emc.com' WHERE id = 92/
UPDATE pdmname SET pdm_name='Hans Kolff', title='Sr Mgr, Professional Services', address1='Edisonbaan 14B', address2='', city='Nieuwegein', state='Netherlands', postalcode='', officenumber='+31(0)306305060', faxnumber='', mobilenumber='+31(0)627033006', emailaddress='hans.kolff@emc.com' WHERE id = 93/
UPDATE pdmname SET pdm_name='Carmen Garcia', title='Sr Mgr, Professional Services', address1='Ribera del Loira 8', address2='', city='Madrid', state='Spain', postalcode='', officenumber='+34(0)914103898', faxnumber='', mobilenumber='+34(0)616952188', emailaddress='carmen.garcia@emc.com' WHERE id = 94/
UPDATE pdmname SET pdm_name='Sofia Lima', title='Sr Mgr, Professional Services', address1='Rua Doutor Antonio Loureiro Borges 5', address2='', city='Alges', state='Portugal', postalcode='', officenumber='+35(0)21214129624', faxnumber='', mobilenumber='+35(0)1935546585', emailaddress='sofia.lima@emc.com' WHERE id = 95/
UPDATE pdmname SET pdm_name='Andrea Franchi', title='Program Delivery Manager', address1='Via Spadolini, 5', address2='Edificio A', city='Milano', state='Italy', postalcode='', officenumber='+39(0)240908059', faxnumber='', mobilenumber='+39(0)3486430570', emailaddress='andrea.franchi@emc.com' WHERE id = 96/
UPDATE pdmname SET pdm_name='Vaibhav Sabharwal', title='Program Delivery Manager', address1='300 Conshohocken State Rd', address2='Suite 700', city='Conshohocken', state='PA', postalcode='19428', officenumber='', faxnumber='', mobilenumber='(704) 780 4089', emailaddress='Vaibhav.Sabharwal@emc.com' WHERE id = 97/
UPDATE pdmname SET pdm_name='Bob Martin', title='Program Delivery Manager', address1='14755 Preston Road', address2='Suite 200', city='Dallas', state='Texas', postalcode='75154', officenumber='None', faxnumber='None', mobilenumber='(972) 439-2633', emailaddress='robert.martin@emc.com' WHERE id = 98/
UPDATE pdmname SET pdm_name='Robin Aurilio', title='Sr Mgr, Professional Services', address1='300 Conshohocken State Road', address2='Suite 700', city='Conshohocken', state='Pennsylvania', postalcode='19428', officenumber='(610)276-3031', faxnumber='None', mobilenumber='(917)539-6099', emailaddress='robin.aurilio@emc.com' WHERE id = 99/
UPDATE pdmname SET pdm_name='Diego Faria', title='Delivery Manager', address1='Av Rio Negro, 161', address2='8 Andar', city='Barueri', state='Sao Paulo', postalcode='06455-020', officenumber='55-11-2078-1563', faxnumber='55-11-2078-1699', mobilenumber='55-11-97661-7605', emailaddress='diego.faria@emc.com' WHERE id = 100/
UPDATE pdmname SET pdm_name='Ben Elliott', title='Program Delivery Manager', address1='36555 Corporate Drive', address2='2nd Floor', city='Farmington Hills', state='Michigan', postalcode='48331', officenumber='(248) 957-5834', faxnumber='None', mobilenumber='(734)-904-2828', emailaddress='ben.elliott@emc.com' WHERE id = 101/
UPDATE pdmname SET pdm_name='Brandon Smith', title='Program Delivery Manager', address1='2201 Dupont Drive', address2='Suite 500', city='Irvine', state='California', postalcode='92612', officenumber='(949) 797-3304', faxnumber='(949) 833-0690', mobilenumber='(949) 202-7052', emailaddress='brandon.smith@emc.com' WHERE id = 102/
UPDATE pdmname SET pdm_name='Calvin Williams', title='Program Delivery Manager', address1='4225 Naperville Road', address2='Suite 500', city='Lisle', state='Illinois', postalcode='60532', officenumber='', faxnumber='(866) 569-2727', mobilenumber='(262) 496-0716', emailaddress='calvin.williams@emc.com' WHERE id = 103/
UPDATE pdmname SET pdm_name='Christina Stichweh', title='Program Delivery Manager', address1='9200 Worthington Rd.', address2='Suite 200', city='Columbus', state='OH', postalcode='43085', officenumber='(614) 797-5673', faxnumber='', mobilenumber='(614) 572-7145', emailaddress='christina.stichweh@emc.com' WHERE id = 104/
UPDATE pdmname SET pdm_name='Nathan Mondragon', title='Program Delivery Manager', address1='8000 South Chester St', address2='Suite 600', city='Englewood', state='Colorado', postalcode='80112', officenumber='(303) 390-7016', faxnumber='(303) 200-8133', mobilenumber='(720) 413-9267', emailaddress='nathan.mondragon@emc.com' WHERE id = 105/
UPDATE pdmname SET pdm_name='Geoff Wise', title='Program Delivery Manager', address1='8888 Keystone Crossing', address2='Suite 700', city='Indianapolis', state='Indiana', postalcode='46240', officenumber='(317) 690-2617', faxnumber='', mobilenumber='', emailaddress='geoff.wise@emc.com' WHERE id = 106/
UPDATE pdmname SET pdm_name='Pramod Kumar C K', title='Program Delivery Manager', address1='Bagmane Developers Pvt ltd', address2='SEZ, , Marathahalli Ring Road, Dodanekundi Vilage', city='Bangalore', state='Karnataka', postalcode='560037', officenumber='1.800-782-4362 Extn-785 4124', faxnumber='1-949-258-5502', mobilenumber='91-9611984499', emailaddress='pramod.kumar2@emc.com' WHERE id = 107/
UPDATE pdmname SET pdm_name='Mike O''Neill', title='Program Delivery Manager', address1='120 Adelaide Street West', address2='', city='Toronto', state='Ontario (Canada)', postalcode='M5H 1T1', officenumber='(902) 222-1402', faxnumber='', mobilenumber='', emailaddress='mike.oneill@emc.com' WHERE id = 108/
UPDATE pdmname SET pdm_name='Rosie Robinson', title='Program Delivery Manager', address1='555 Burrard Street', address2='', city='Vancouver', state='British Columbia (Canada)', postalcode='V7X 1B1', officenumber='(416) 434-2247', faxnumber='', mobilenumber='', emailaddress='rosie.robinson@emc.com' WHERE id = 109/
UPDATE pdmname SET pdm_name='Mark Harrington', title='Program Delivery Manager', address1='95 Wells Ave', address2='', city='Newton', state='Massachusetts', postalcode='02459', officenumber='(508) 864-7474', faxnumber='', mobilenumber='', emailaddress='mark.harrington@emc.com' WHERE id = 110/
UPDATE pdmname SET pdm_name='Glenn Steinhandler', title='Program Delivery Manager', address1='184 Liberty Corner Rd', address2='4th Flr', city='Warren', state='New Jersey', postalcode='07059', officenumber='(908) 286-7676', faxnumber='None', mobilenumber='(732) 453-4055', emailaddress='gabriel.dupas@emc.com' WHERE id = 111/
UPDATE pdmname SET pdm_name='Joe Farrugia', title='Program Delivery Manager', address1='184 Liberty Corner Rd', address2='4th Flr', city='Warren', state='New Jersey', postalcode='07059', officenumber='(908) 286-3896', faxnumber='None', mobilenumber='(973)868-7372', emailaddress='joseph.farrugia@emc.com' WHERE id = 112/
UPDATE pdmname SET pdm_name='Robert Zutterman', title='Program Delivery Manager', address1='184 Liberty Corner Rd', address2='4th Flr', city='Warren', state='New Jersey', postalcode='07059', officenumber='', faxnumber='', mobilenumber='', emailaddress='' WHERE id = 113/
UPDATE pdmname SET pdm_name='Sabareesan Balasubramaniam', title='Program Delivery Manager', address1='Bagmane Tech Park', address2='', city='Bangalore', state='India', postalcode='', officenumber='1-800-782-4362 x7854274', faxnumber='', mobilenumber='303-954-4343', emailaddress='Sabareesan.balasubramaniam@emc.com' WHERE id = 114/
UPDATE pdmname SET pdm_name='Dave Hunt', title='Program Delivery Manager', address1='250 Montgomery Street', address2='Suite 400', city='San Francisco', state='California', postalcode='94104', officenumber='(916) 221-2268', faxnumber='', mobilenumber='', emailaddress='dave.hunt@emc.com' WHERE id = 115/
UPDATE pdmname SET pdm_name='Mark Hutchings', title='Program Delivery Manager', address1='15500 SE 30th Place', address2='Suite 200', city='Bellevue', state='Washington', postalcode='98007', officenumber='(425) 748-3220', faxnumber='', mobilenumber='(206) 437-3085', emailaddress='mark.hutchings@emc.com' WHERE id = 116/
UPDATE pdmname SET pdm_name='Jossh Gladness', title='Program Delivery Manager', address1='2201 Dupont Drive', address2='Suite 500', city='Irvine', state='California', postalcode='92612', officenumber='(949) 797-2295', faxnumber='(949) 833-0690', mobilenumber='(949) 373-6464', emailaddress='josh.norige@emc.com' WHERE id = 117/
UPDATE pdmname SET pdm_name='Kathy Dugas', title='Program Delivery Manager', address1='4250 N. Drinkwater Blvd', address2='Suite 200', city='Scottsdale', state='Arizona', postalcode='85260', officenumber='(480) 874-7946', faxnumber='(480) 425-1247', mobilenumber='(480) 299-6485', emailaddress='kathy.dugas@emc.com' WHERE id = 118/
UPDATE pdmname SET pdm_name='Amber Parnell', title='Program Delivery Manager', address1='8444 West Park Drive', address2='Suite 800', city='McLean', state='Virginia', postalcode='20136', officenumber='703 970 5586', faxnumber='', mobilenumber='703 624 9205', emailaddress='amber.parnell@emc.com' WHERE id = 119/
UPDATE pdmname SET pdm_name='Figini Juan', title='Program Delivery Manager', address1='Av. Providencia 1760, Piso 15', address2='', city='Santiago de Chile', state='Santiago', postalcode='1001', officenumber='56 2 23733104', faxnumber='', mobilenumber='56 9 61708752', emailaddress='juan.figini@emc.com' WHERE id = 120/
UPDATE pdmname SET pdm_name='Marisol Sanchez - Colombia', title='Program Delivery Manager', address1='Calle 116 # 7-15 Int. 2, Of: 402.', address2='', city='Bogotá', state='Colombia.', postalcode='110111', officenumber='(212)206-6939', faxnumber='', mobilenumber='(416)637-3409', emailaddress='Marisol.SanchezFont@emc.com' WHERE id = 121/
UPDATE pdmname SET pdm_name='Marisol Sanchez - Venezuela', title='Program Delivery Manager', address1='Av, principal la castellana, torre la castellana piso 12 ofic 12-a', address2='', city='Caracas-Venezuela.', state='Altamira-miranda', postalcode='', officenumber='(212)206-6939', faxnumber='', mobilenumber='(416)637-3409', emailaddress='Marisol.SanchezFont@emc.com' WHERE id = 122/
UPDATE pdmname SET pdm_name='Marisol Sanchez - Puerto Rico', title='Program Delivery Manager', address1='Santander Tower 11th Floor B7 Tabonuco St. Guaynabo, PR', address2='', city='San Juan', state='Puerto Rico', postalcode='968', officenumber='(212)206-6939', faxnumber='', mobilenumber='(416)637-3409', emailaddress='Marisol.SanchezFont@emc.com' WHERE id = 123/
UPDATE pdmname SET pdm_name='Ioannis Diamantis', title='GPSd Lead Greece, Cyprus, Malta', address1='44 Zalokosta & Kifisias Avenue', address2='15233, Chalandri', city='Athens', state='Greece', postalcode='', officenumber='+30(0)2106146926', faxnumber='', mobilenumber='+30(0)6974262319', emailaddress='ioannis.diamantis@emc.com' WHERE id = 124/
UPDATE pdmname SET pdm_name='Itzhak Hanan', title='GPSd Lead Israel', address1='94 Em Hamoshavot', address2='1st & 2nd Floor, Park Azorim', city='Tel Aviv', state='Israel', postalcode='', officenumber='+972(0)37685404', faxnumber='', mobilenumber='+972(0)546757173', emailaddress='itzhak.hanan@emc.com' WHERE id = 125/
UPDATE pdmname SET pdm_name='Wojciech Pliszka', title='Mgr Prof. Services', address1='Choldna Street 512', address2='6th FloorWarsaw trade Tower', city='Warsaw', state='Poland', postalcode='', officenumber='+48224553002', faxnumber='', mobilenumber='+48 605 324704', emailaddress='wojciech.pliszka@emc.com' WHERE id = 126/
UPDATE pdmname SET pdm_name='Andrei Korinets', title='Mgr Prof. Services', address1='3 Begovaya StreetFloor 30, Bldg 1', address2='', city='Moscow', state='Russian Federation', postalcode='', officenumber='+7 495 78 56622', faxnumber='', mobilenumber='+7 9175662103', emailaddress='andrei.korinets@emc.com' WHERE id = 127/
UPDATE pdmname SET pdm_name='Umut Kurtdede', title='Program Delivery Manager', address1='5th Floor', address2='34330 Is Kuleleri Kule-2', city='Istanbul', state='Turkey', postalcode='', officenumber='+90(0)2123174464', faxnumber='', mobilenumber='+905309619344', emailaddress='Umut.Kurtdede@emc.com' WHERE id = 130/
UPDATE pdmname SET pdm_name='Bharath Cadambi', title='', address1='', address2='', city='', state='', postalcode='', officenumber='', faxnumber='', mobilenumber='', emailaddress='' WHERE id = 131/
UPDATE pdmname SET pdm_name='TBD', title='TBD', address1='TBD', address2='TBD', city='TBD', state='TBD', postalcode='', officenumber='TBD', faxnumber='', mobilenumber='TBD', emailaddress='MS@emc.com' WHERE id = 132/
UPDATE pdmname SET pdm_name='TBD', title='TBD', address1='TBD', address2='TBD', city='TBD', state='TBD', postalcode='', officenumber='TBD', faxnumber='', mobilenumber='TBD', emailaddress='TBD@emc.com' WHERE id = 133/
UPDATE pdmname SET pdm_name='TBD', title='TBD', address1='TBD', address2='TBD', city='TBD', state='TBD', postalcode='', officenumber='TBD', faxnumber='', mobilenumber='TBD', emailaddress='TBD@emc.com' WHERE id = 134/
UPDATE pdmname SET pdm_name='TBD', title='TBD', address1='TBD', address2='TBD', city='TBD', state='TBD', postalcode='', officenumber='TBD', faxnumber='', mobilenumber='TBD', emailaddress='TBD@emc.com' WHERE id = 135/
UPDATE pdmname SET pdm_name='TBD', title='TBD', address1='TBD', address2='TBD', city='TBD', state='TBD', postalcode='', officenumber='TBD', faxnumber='', mobilenumber='TBD', emailaddress='TBD@emc.com' WHERE id = 136/
UPDATE pdmname SET pdm_name='RSA', title='RSA', address1='RSA', address2='RSA', city='RSA', state='RSA', postalcode='', officenumber='RSA', faxnumber='', mobilenumber='RSA', emailaddress='RSA@emc.com' WHERE id = 137/
UPDATE pdmname SET pdm_name='TBD', title='TBD', address1='TBD', address2='TBD', city='TBD', state='TBD', postalcode='', officenumber='TBD', faxnumber='', mobilenumber='TBD', emailaddress='TBD@emc.com' WHERE id = 138/
UPDATE pdmname SET pdm_name='TBD', title='TBD', address1='TBD', address2='TBD', city='TBD', state='TBD', postalcode='', officenumber='TBD', faxnumber='', mobilenumber='TBD', emailaddress='TBD@emc.com' WHERE id = 139/
UPDATE pdmname SET pdm_name='ECD', title='ECD', address1='ECD', address2='ECD', city='ECD', state='ECD', postalcode='', officenumber='ECD', faxnumber='', mobilenumber='ECD', emailaddress='ECD@emc.com' WHERE id = 140/
INSERT INTO SalesDistrict VALUES(324, 'MS', 'MS', 'MS', 26, 132)/
INSERT INTO SalesDistrict VALUES(325, 'TBD', 'NotListed', '', 22, 135)/
INSERT INTO SalesDistrict VALUES(326, 'TBD', 'NotListed', '', 19, 138)/
INSERT INTO SalesDistrict VALUES(327, 'AUS', 'ANZ', '', 18, 139)/
INSERT INTO SalesDistrict VALUES(328, 'Greater China', 'Greater China', '', 19, 138)/
INSERT INTO SalesDistrict VALUES(329, 'India', 'India', '', 20, 136)/
INSERT INTO SalesDistrict VALUES(330, 'TBD', 'NotListed', '', 18, 139)/
INSERT INTO SalesDistrict VALUES(331, 'ECD', 'ECD', 'ECD', 25, 140)/
INSERT INTO SalesDistrict VALUES(332, 'Korea', 'Korea', '', 22, 135)/
INSERT INTO SalesDistrict VALUES(333, 'TBD', 'NotListed', '', 21, 134)/
INSERT INTO SalesDistrict VALUES(334, 'NZL', 'ANZ', '', 18, 139)/
INSERT INTO SalesDistrict VALUES(335, 'Japan', 'Japan', '', 21, 134)/
INSERT INTO SalesDistrict VALUES(336, 'Singapore', 'Singapore', '', 23, 133)/
INSERT INTO SalesDistrict VALUES(337, 'TBD', 'NotListed', '', 23, 133)/
INSERT INTO SalesDistrict VALUES(338, 'Malaysia', 'Malaysia', '', 23, 133)/
INSERT INTO SalesDistrict VALUES(339, 'TBD', 'NotListed', '', 20, 136)/
INSERT INTO SalesDistrict VALUES(340, 'Hong Kong', 'Hong Kong', '', 19, 138)/
INSERT INTO SalesDistrict VALUES(341, 'RSA', 'RSA', 'RSA', 24, 137)/
UPDATE SalesDistrict SET district_name='TME', area_name='Enterprise', market_name='Enterprise', division_id=1, default_pdm_id=1 WHERE id = 1/
UPDATE SalesDistrict SET district_name='Finance', area_name='Enterprise', market_name='Enterprise', division_id=1, default_pdm_id=1 WHERE id = 2/
UPDATE SalesDistrict SET district_name='Commercial South', area_name='Geo South', market_name='MidMarket/SMB', division_id=1, default_pdm_id=1 WHERE id = 5/
UPDATE SalesDistrict SET district_name='Commercial North', area_name='Geo North', market_name='MidMarket/SMB', division_id=1, default_pdm_id=1 WHERE id = 6/
UPDATE SalesDistrict SET district_name='Enterprise - Chicago 1', area_name='Chicago', market_name='Enterprise', division_id=2, default_pdm_id=103 WHERE id = 8/
UPDATE SalesDistrict SET district_name='Enterprise - Chicago 2', area_name='Chicago', market_name='Enterprise', division_id=2, default_pdm_id=12 WHERE id = 9/
UPDATE SalesDistrict SET district_name='Enterprise - Chicago 4', area_name='Chicago', market_name='Enterprise', division_id=2, default_pdm_id=12 WHERE id = 10/
UPDATE SalesDistrict SET district_name='Enterprise - Cincinnati 1', area_name='Ohio', market_name='Enterprise', division_id=2, default_pdm_id=106 WHERE id = 11/
UPDATE SalesDistrict SET district_name='Enterprise - Cleveland', area_name='Ohio', market_name='Enterprise', division_id=2, default_pdm_id=104 WHERE id = 12/
UPDATE SalesDistrict SET district_name='Enterprise - Detroit 3', area_name='IN/MI', market_name='Enterprise', division_id=2, default_pdm_id=101 WHERE id = 13/
UPDATE SalesDistrict SET district_name='Enterprise - GM', area_name='IN/MI', market_name='Enterprise', division_id=2, default_pdm_id=101 WHERE id = 14/
UPDATE SalesDistrict SET district_name='Enterprise - GM SMS', area_name='IN/MI', market_name='Enterprise', division_id=2, default_pdm_id=8 WHERE id = 15/
UPDATE SalesDistrict SET district_name='Enterprise - Indianapolis', area_name='IN/MI', market_name='Enterprise', division_id=2, default_pdm_id=106 WHERE id = 16/
UPDATE SalesDistrict SET district_name='Enterprise - Iowa', area_name='MO/MN', market_name='Enterprise', division_id=2, default_pdm_id=5 WHERE id = 17/
UPDATE SalesDistrict SET district_name='Enterprise - Minneapolis 2', area_name='MO/MN', market_name='Enterprise', division_id=2, default_pdm_id=4 WHERE id = 18/
UPDATE SalesDistrict SET district_name='Enterprise - Minneapolis 3', area_name='MO/MN', market_name='Enterprise', division_id=2, default_pdm_id=4 WHERE id = 19/
UPDATE SalesDistrict SET district_name='Enterprise - Pittsburgh', area_name='Ohio', market_name='Enterprise', division_id=2, default_pdm_id=104 WHERE id = 20/
UPDATE SalesDistrict SET district_name='Enterprise - Sprint', area_name='MO/MN', market_name='Enterprise', division_id=2, default_pdm_id=5 WHERE id = 21/
UPDATE SalesDistrict SET district_name='Enterprise - St Louis', area_name='MO/MN', market_name='Enterprise', division_id=2, default_pdm_id=5 WHERE id = 22/
UPDATE SalesDistrict SET district_name='Enterprise - Wisconsin 2', area_name='Chicago', market_name='Enterprise', division_id=2, default_pdm_id=12 WHERE id = 23/
UPDATE SalesDistrict SET district_name='MidMarket - Chicago 1', area_name='Midwest', market_name='MidMarket', division_id=2, default_pdm_id=103 WHERE id = 24/
UPDATE SalesDistrict SET district_name='MidMarket - Chicago 2', area_name='Midwest', market_name='MidMarket', division_id=2, default_pdm_id=103 WHERE id = 25/
UPDATE SalesDistrict SET district_name='MidMarket - Chicago 3', area_name='Midwest', market_name='MidMarket', division_id=2, default_pdm_id=103 WHERE id = 26/
UPDATE SalesDistrict SET district_name='MidMarket - Cincinnati', area_name='Ohio Valley', market_name='MidMarket', division_id=2, default_pdm_id=106 WHERE id = 27/
UPDATE SalesDistrict SET district_name='MidMarket - Denver', area_name='Mountain Plains', market_name='MidMarket', division_id=2, default_pdm_id=105 WHERE id = 28/
UPDATE SalesDistrict SET district_name='MidMarket - Michigan', area_name='Ohio Valley', market_name='MidMarket', division_id=2, default_pdm_id=101 WHERE id = 29/
UPDATE SalesDistrict SET district_name='MidMarket - Minnesota', area_name='Midwest', market_name='MidMarket', division_id=2, default_pdm_id=4 WHERE id = 30/
UPDATE SalesDistrict SET district_name='MidMarket - Mountain Plains 1', area_name='Mountain Plains', market_name='MidMarket', division_id=2, default_pdm_id=4 WHERE id = 31/
UPDATE SalesDistrict SET district_name='MidMarket - Mountain Plains 2', area_name='Mountain Plains', market_name='MidMarket', division_id=2, default_pdm_id=4 WHERE id = 32/
UPDATE SalesDistrict SET district_name='MidMarket - Ohio Valley Health Care', area_name='Ohio Valley', market_name='MidMarket', division_id=2, default_pdm_id=106 WHERE id = 33/
UPDATE SalesDistrict SET district_name='MidMarket - Oklahoma', area_name='Mountain Plains', market_name='MidMarket', division_id=2, default_pdm_id=4 WHERE id = 34/
UPDATE SalesDistrict SET district_name='MidMarket - Pittsburgh', area_name='Ohio Valley', market_name='MidMarket', division_id=2, default_pdm_id=104 WHERE id = 35/
UPDATE SalesDistrict SET district_name='MidMarket - St. Louis', area_name='Ohio Valley', market_name='MidMarket', division_id=2, default_pdm_id=5 WHERE id = 36/
UPDATE SalesDistrict SET district_name='MidMarket - Wisconsin', area_name='Midwest', market_name='MidMarket', division_id=2, default_pdm_id=12 WHERE id = 37/
UPDATE SalesDistrict SET district_name='SMB - MI - Ohio Valley District 1', area_name='Ohio Valley', market_name='SMB', division_id=2, default_pdm_id=101 WHERE id = 38/
UPDATE SalesDistrict SET district_name='SMB - MI - Ohio Valley District 2', area_name='Ohio Valley', market_name='SMB', division_id=2, default_pdm_id=101 WHERE id = 39/
UPDATE SalesDistrict SET district_name='SMB - Midwest District 1', area_name='Midwest', market_name='SMB', division_id=2, default_pdm_id=103 WHERE id = 40/
UPDATE SalesDistrict SET district_name='SMB - Midwest District 2', area_name='Midwest', market_name='SMB', division_id=2, default_pdm_id=103 WHERE id = 41/
UPDATE SalesDistrict SET district_name='SMB - Midwest District 3', area_name='Midwest', market_name='SMB', division_id=2, default_pdm_id=103 WHERE id = 42/
UPDATE SalesDistrict SET district_name='SMB - Midwest District 4', area_name='Midwest', market_name='SMB', division_id=2, default_pdm_id=12 WHERE id = 43/
UPDATE SalesDistrict SET district_name='SMB - Midwest District 5', area_name='Midwest', market_name='SMB', division_id=2, default_pdm_id=12 WHERE id = 44/
UPDATE SalesDistrict SET district_name='SMB - OH - Ohio Valley District 4', area_name='Ohio Valley', market_name='SMB', division_id=2, default_pdm_id=104 WHERE id = 45/
UPDATE SalesDistrict SET district_name='SMB - Ohio Valley District 5', area_name='Ohio Valley', market_name='SMB', division_id=2, default_pdm_id=104 WHERE id = 46/
UPDATE SalesDistrict SET district_name='SMB - Ohio Valley District 6', area_name='Ohio Valley', market_name='SMB', division_id=2, default_pdm_id=106 WHERE id = 47/
UPDATE SalesDistrict SET district_name='SMB - Ohio Valley District 7', area_name='Ohio Valley', market_name='SMB', division_id=2, default_pdm_id=106 WHERE id = 48/
UPDATE SalesDistrict SET district_name='SMB - South District 4', area_name='Mountain Plains', market_name='SMB', division_id=2, default_pdm_id=14 WHERE id = 49/
UPDATE SalesDistrict SET district_name='SMB - South District 5', area_name='Mountain Plains', market_name='SMB', division_id=2, default_pdm_id=14 WHERE id = 50/
UPDATE SalesDistrict SET district_name='SMB - South District 6', area_name='Mountain Plains', market_name='SMB', division_id=2, default_pdm_id=14 WHERE id = 51/
UPDATE SalesDistrict SET district_name='SMB - South District 7', area_name='Mountain Plains', market_name='SMB', division_id=2, default_pdm_id=14 WHERE id = 52/
UPDATE SalesDistrict SET district_name='SMB - Southern Cal District 6', area_name='Mountain Plains', market_name='SMB', division_id=2, default_pdm_id=102 WHERE id = 53/
UPDATE SalesDistrict SET district_name='GEO MidMarket/SMB', area_name='GEO', market_name='GEO', division_id=2, default_pdm_id=null WHERE id = 54/
UPDATE SalesDistrict SET district_name='Airforce', area_name='DOD', market_name='Enterprise', division_id=4, default_pdm_id=21 WHERE id = 55/
UPDATE SalesDistrict SET district_name='Navy', area_name='DOD', market_name='Enterprise', division_id=4, default_pdm_id=21 WHERE id = 56/
UPDATE SalesDistrict SET district_name='Army', area_name='DOD', market_name='Enterprise', division_id=4, default_pdm_id=21 WHERE id = 57/
UPDATE SalesDistrict SET district_name='Civilian 2', area_name='Civilian', market_name='Enterprise', division_id=4, default_pdm_id=119 WHERE id = 59/
UPDATE SalesDistrict SET district_name='Civilian 3', area_name='Civilian', market_name='Enterprise', division_id=4, default_pdm_id=119 WHERE id = 60/
UPDATE SalesDistrict SET district_name='COCOM', area_name='DOD', market_name='Enterprise', division_id=4, default_pdm_id=21 WHERE id = 63/
UPDATE SalesDistrict SET district_name='Intel', area_name='DOD', market_name='Enterprise', division_id=4, default_pdm_id=21 WHERE id = 65/
UPDATE SalesDistrict SET district_name='TME', area_name='Enterprise', market_name='Enterprise', division_id=5, default_pdm_id=23 WHERE id = 68/
UPDATE SalesDistrict SET district_name='Finance', area_name='Enterprise', market_name='Enterprise', division_id=5, default_pdm_id=23 WHERE id = 69/
UPDATE SalesDistrict SET district_name='Government', area_name='Enterprise', market_name='Enterprise', division_id=5, default_pdm_id=23 WHERE id = 70/
UPDATE SalesDistrict SET district_name='Enterprise - AT&T', area_name='AT&T', market_name='Enterprise', division_id=6, default_pdm_id=32 WHERE id = 75/
UPDATE SalesDistrict SET district_name='Enterprise - Atlanta 7', area_name='Southeast', market_name='Enterprise', division_id=6, default_pdm_id=32 WHERE id = 76/
UPDATE SalesDistrict SET district_name='Enterprise - Austin', area_name='TOLA', market_name='Enterprise', division_id=6, default_pdm_id=98 WHERE id = 77/
UPDATE SalesDistrict SET district_name='Enterprise - Baltimore', area_name='MidAtlantic', market_name='Enterprise', division_id=6, default_pdm_id=37 WHERE id = 78/
UPDATE SalesDistrict SET district_name='Enterprise - Blue Bell', area_name='MidAtlantic', market_name='Enterprise', division_id=6, default_pdm_id=99 WHERE id = 80/
UPDATE SalesDistrict SET district_name='Enterprise - Dallas 1', area_name='TOLA', market_name='Enterprise', division_id=6, default_pdm_id=29 WHERE id = 81/
UPDATE SalesDistrict SET district_name='Enterprise - Dallas 2', area_name='TOLA', market_name='Enterprise', division_id=6, default_pdm_id=29 WHERE id = 82/
UPDATE SalesDistrict SET district_name='Enterprise - Florida Enterprise Sales', area_name='Southeast', market_name='Enterprise', division_id=6, default_pdm_id=33 WHERE id = 83/
UPDATE SalesDistrict SET district_name='Enterprise - Georgia/Alabama', area_name='Southeast', market_name='Enterprise', division_id=6, default_pdm_id=32 WHERE id = 84/
UPDATE SalesDistrict SET district_name='Enterprise - HealthCare District', area_name='MidAtlantic', market_name='Enterprise', division_id=6, default_pdm_id=26 WHERE id = 85/
UPDATE SalesDistrict SET district_name='Enterprise - Houston', area_name='TOLA', market_name='Enterprise', division_id=6, default_pdm_id=98 WHERE id = 86/
UPDATE SalesDistrict SET district_name='Enterprise - Memphis District', area_name='Southeast', market_name='Enterprise', division_id=6, default_pdm_id=31 WHERE id = 87/
UPDATE SalesDistrict SET district_name='Enterprise - North Carolina 2', area_name='Southeast', market_name='Enterprise', division_id=6, default_pdm_id=26 WHERE id = 88/
UPDATE SalesDistrict SET district_name='Enterprise - Philly 2', area_name='MidAtlantic', market_name='Enterprise', division_id=6, default_pdm_id=99 WHERE id = 89/
UPDATE SalesDistrict SET district_name='Enterprise - Richmond 1/Raleigh', area_name='MidAtlantic', market_name='Enterprise', division_id=6, default_pdm_id=26 WHERE id = 90/
UPDATE SalesDistrict SET district_name='Enterprise - Tampa', area_name='Southeast', market_name='Enterprise', division_id=6, default_pdm_id=33 WHERE id = 91/
UPDATE SalesDistrict SET district_name='Enterprise - Tennessee/Carolina (includes Alabama)', area_name='Southeast', market_name='Enterprise', division_id=6, default_pdm_id=31 WHERE id = 92/
UPDATE SalesDistrict SET district_name='Enterprise - TOLA District #5', area_name='TOLA', market_name='Enterprise', division_id=6, default_pdm_id=27 WHERE id = 93/
UPDATE SalesDistrict SET district_name='Enterprise - Vienna 7', area_name='MidAtlantic', market_name='Enterprise', division_id=6, default_pdm_id=37 WHERE id = 94/
UPDATE SalesDistrict SET district_name='GEO MidMarket/SMB', area_name='GEO', market_name='GEO', division_id=6, default_pdm_id=97 WHERE id = 95/
UPDATE SalesDistrict SET district_name='Boston 1', area_name='Boston', market_name='Enterprise', division_id=7, default_pdm_id=110 WHERE id = 96/
UPDATE SalesDistrict SET district_name='Boston 2', area_name='Boston', market_name='Enterprise', division_id=7, default_pdm_id=110 WHERE id = 97/
UPDATE SalesDistrict SET district_name='Boston 3', area_name='Boston', market_name='Enterprise', division_id=7, default_pdm_id=110 WHERE id = 98/
UPDATE SalesDistrict SET district_name='Boston 4', area_name='Boston', market_name='Enterprise', division_id=7, default_pdm_id=110 WHERE id = 99/
UPDATE SalesDistrict SET district_name='Buffalo Comm', area_name='Commercial East', market_name='Commercial', division_id=7, default_pdm_id=38 WHERE id = 102/
UPDATE SalesDistrict SET district_name='Calgary', area_name='Canada', market_name='Enterprise', division_id=7, default_pdm_id=109 WHERE id = 103/
UPDATE SalesDistrict SET district_name='Comm Boston District', area_name='Commercial East', market_name='Commercial', division_id=7, default_pdm_id=110 WHERE id = 104/
UPDATE SalesDistrict SET district_name='Comm Connecticut District', area_name='Commercial East', market_name='Commercial', division_id=7, default_pdm_id=38 WHERE id = 105/
UPDATE SalesDistrict SET district_name='Comm East', area_name='Commercial East', market_name='Commercial', division_id=7, default_pdm_id=110 WHERE id = 106/
UPDATE SalesDistrict SET district_name='Comm New England District', area_name='Commercial East', market_name='Commercial', division_id=7, default_pdm_id=110 WHERE id = 107/
UPDATE SalesDistrict SET district_name='Comm Newton District', area_name='Commercial East', market_name='Commercial', division_id=7, default_pdm_id=110 WHERE id = 108/
UPDATE SalesDistrict SET district_name='Comm Upstate NY District', area_name='Commercial East', market_name='Commercial', division_id=7, default_pdm_id=38 WHERE id = 109/
UPDATE SalesDistrict SET district_name='Commercial East - House', area_name='Commercial East', market_name='Commercial', division_id=7, default_pdm_id=110 WHERE id = 110/
UPDATE SalesDistrict SET district_name='GE', area_name='Global Account', market_name='Global', division_id=7, default_pdm_id=38 WHERE id = 111/
UPDATE SalesDistrict SET district_name='Montreal', area_name='Canada', market_name='Enterprise', division_id=7, default_pdm_id=108 WHERE id = 112/
UPDATE SalesDistrict SET district_name='Ottawa', area_name='Canada', market_name='Enterprise', division_id=7, default_pdm_id=108 WHERE id = 113/
UPDATE SalesDistrict SET district_name='Rochester 1', area_name='CT/Upstate NY', market_name='Enterprise', division_id=7, default_pdm_id=38 WHERE id = 114/
UPDATE SalesDistrict SET district_name='Rocky Hill 1', area_name='CT/Upstate NY', market_name='Enterprise', division_id=7, default_pdm_id=38 WHERE id = 115/
UPDATE SalesDistrict SET district_name='Rocky Hill 2', area_name='CT/Upstate NY', market_name='Enterprise', division_id=7, default_pdm_id=38 WHERE id = 116/
UPDATE SalesDistrict SET district_name='Toronto 4', area_name='Canada', market_name='Enterprise', division_id=7, default_pdm_id=109 WHERE id = 128/
UPDATE SalesDistrict SET district_name='Toronto Commercial', area_name='Canada', market_name='Commercial', division_id=7, default_pdm_id=108 WHERE id = 129/
UPDATE SalesDistrict SET district_name='Vancouver', area_name='Canada', market_name='Enterprise', division_id=7, default_pdm_id=109 WHERE id = 130/
UPDATE SalesDistrict SET district_name='Enterprise - Bourke', area_name='Scotto', market_name='Enterprise', division_id=8, default_pdm_id=46 WHERE id = 132/
UPDATE SalesDistrict SET district_name='Enterprise - Citibank', area_name='McLaughlin', market_name='Enterprise', division_id=8, default_pdm_id=111 WHERE id = 133/
UPDATE SalesDistrict SET district_name='Enterprise - JPMC', area_name='Giordano', market_name='Enterprise', division_id=8, default_pdm_id=111 WHERE id = 134/
UPDATE SalesDistrict SET district_name='Enterprise - Lubrano Districts', area_name='Lubrano', market_name='Enterprise', division_id=8, default_pdm_id=43 WHERE id = 136/
UPDATE SalesDistrict SET district_name='Enterprise - Modica', area_name='Scotto', market_name='Enterprise', division_id=8, default_pdm_id=46 WHERE id = 137/
UPDATE SalesDistrict SET district_name='Enterprise - Verizon', area_name='Global', market_name='Enterprise', division_id=8, default_pdm_id=111 WHERE id = 140/
UPDATE SalesDistrict SET district_name='GEO MidMarket/SMB', area_name='Trizzino', market_name='GEO', division_id=8, default_pdm_id=112 WHERE id = 141/
UPDATE SalesDistrict SET district_name='Enterprise - AMEX West', area_name='Mountain', market_name='Enterprise', division_id=9, default_pdm_id=118 WHERE id = 142/
UPDATE SalesDistrict SET district_name='Enterprise - Cisco_Vertical_Globals', area_name='Nor Cal', market_name='Enterprise', division_id=9, default_pdm_id=48 WHERE id = 143/
UPDATE SalesDistrict SET district_name='Enterprise - Denver 3', area_name='Mountain', market_name='Enterprise', division_id=9, default_pdm_id=54 WHERE id = 144/
UPDATE SalesDistrict SET district_name='Enterprise - El Segundo', area_name='So Cal', market_name='Enterprise', division_id=9, default_pdm_id=117 WHERE id = 145/
UPDATE SalesDistrict SET district_name='Enterprise - El Segundo 2', area_name='So Cal', market_name='Enterprise', division_id=9, default_pdm_id=49 WHERE id = 146/
UPDATE SalesDistrict SET district_name='Enterprise - Irvine 1', area_name='So Cal', market_name='Enterprise', division_id=9, default_pdm_id=117 WHERE id = 147/
UPDATE SalesDistrict SET district_name='Enterprise - Phoenix', area_name='Mountain', market_name='Enterprise', division_id=9, default_pdm_id=118 WHERE id = 148/
UPDATE SalesDistrict SET district_name='Enterprise - Sacramento 1', area_name='Nor Cal', market_name='Enterprise', division_id=9, default_pdm_id=115 WHERE id = 149/
UPDATE SalesDistrict SET district_name='Enterprise - San Francisco 4', area_name='Nor Cal', market_name='Enterprise', division_id=9, default_pdm_id=48 WHERE id = 150/
UPDATE SalesDistrict SET district_name='Enterprise - San Francisco 6', area_name='Nor Cal', market_name='Enterprise', division_id=9, default_pdm_id=48 WHERE id = 151/
UPDATE SalesDistrict SET district_name='Enterprise - Seattle 2', area_name='Mountain', market_name='Enterprise', division_id=9, default_pdm_id=116 WHERE id = 152/
UPDATE SalesDistrict SET district_name='Enterprise - Seattle 3', area_name='Mountain', market_name='Enterprise', division_id=9, default_pdm_id=116 WHERE id = 153/
UPDATE SalesDistrict SET district_name='Enterprise - TME_SLG-SLED RM', area_name='Mountain', market_name='Enterprise', division_id=9, default_pdm_id=54 WHERE id = 154/
UPDATE SalesDistrict SET district_name='Enterprise - Wachovia', area_name='Nor Cal', market_name='Enterprise', division_id=9, default_pdm_id=115 WHERE id = 155/
UPDATE SalesDistrict SET district_name='MidMarket - Dublin', area_name='NW Comm', market_name='MidMarket', division_id=9, default_pdm_id=115 WHERE id = 157/
UPDATE SalesDistrict SET district_name='MidMarket - El Segundo', area_name='SW Comm', market_name='MidMarket', division_id=9, default_pdm_id=49 WHERE id = 158/
UPDATE SalesDistrict SET district_name='MidMarket - Orange County', area_name='SW Comm', market_name='MidMarket', division_id=9, default_pdm_id=49 WHERE id = 159/
UPDATE SalesDistrict SET district_name='MidMarket - San Diego / Hawaii', area_name='SW Comm', market_name='MidMarket', division_id=9, default_pdm_id=49 WHERE id = 160/
UPDATE SalesDistrict SET district_name='MidMarket - San Francisco', area_name='NW Comm', market_name='MidMarket', division_id=9, default_pdm_id=115 WHERE id = 161/
UPDATE SalesDistrict SET district_name='MidMarket - Seattle', area_name='NW Comm', market_name='MidMarket', division_id=9, default_pdm_id=115 WHERE id = 162/
UPDATE SalesDistrict SET district_name='MidMarket - South San Fran', area_name='NW Comm', market_name='MidMarket', division_id=9, default_pdm_id=115 WHERE id = 163/
UPDATE SalesDistrict SET district_name='SMB - Northern Cal', area_name='Geo West', market_name='SMB', division_id=9, default_pdm_id=115 WHERE id = 164/
UPDATE SalesDistrict SET district_name='SMB - Other', area_name='Geo West', market_name='SMB', division_id=9, default_pdm_id=null WHERE id = 165/
UPDATE SalesDistrict SET district_name='SMB - South', area_name='Geo West', market_name='SMB', division_id=9, default_pdm_id=118 WHERE id = 166/
UPDATE SalesDistrict SET district_name='SMB - Southern Cal', area_name='Geo West', market_name='SMB', division_id=9, default_pdm_id=49 WHERE id = 167/
UPDATE SalesDistrict SET district_name='SMB - Southern Cal / South / Northern Cal', area_name='Geo West', market_name='SMB', division_id=9, default_pdm_id=49 WHERE id = 168/
UPDATE SalesDistrict SET district_name='GEO MidMarket/SMB', area_name='GEO', market_name='GEO', division_id=9, default_pdm_id=114 WHERE id = 169/
UPDATE SalesDistrict SET district_name='East Enterprise', area_name='Enterprise', market_name='Enterprise', division_id=10, default_pdm_id=120 WHERE id = 170/
UPDATE SalesDistrict SET district_name='East Government', area_name='Government', market_name='Government', division_id=10, default_pdm_id=120 WHERE id = 171/
UPDATE SalesDistrict SET district_name='East Mid Tier', area_name='Mid Tier / Mid Market', market_name='Mid Tier / Mid Market', division_id=10, default_pdm_id=120 WHERE id = 172/
UPDATE SalesDistrict SET district_name='East Low Commercial', area_name='Low Commercial', market_name='Low Commercial', division_id=10, default_pdm_id=120 WHERE id = 173/
UPDATE SalesDistrict SET district_name='Central Enterprise', area_name='Enterprise', market_name='Enterprise', division_id=10, default_pdm_id=120 WHERE id = 174/
UPDATE SalesDistrict SET district_name='Central Government', area_name='Government', market_name='Government', division_id=10, default_pdm_id=120 WHERE id = 175/
UPDATE SalesDistrict SET district_name='Central Mid Tier', area_name='Mid Tier / Mid Market', market_name='Mid Tier / Mid Market', division_id=10, default_pdm_id=120 WHERE id = 176/
UPDATE SalesDistrict SET district_name='Central Low Commercial', area_name='Low Commercial', market_name='Low Commercial', division_id=10, default_pdm_id=120 WHERE id = 177/
UPDATE SalesDistrict SET district_name='West Enterprise', area_name='Enterprise', market_name='Enterprise', division_id=10, default_pdm_id=120 WHERE id = 178/
UPDATE SalesDistrict SET district_name='West Government', area_name='Government', market_name='Government', division_id=10, default_pdm_id=120 WHERE id = 179/
UPDATE SalesDistrict SET district_name='West Mid Tier', area_name='Mid Tier / Mid Market', market_name='Mid Tier / Mid Market', division_id=10, default_pdm_id=120 WHERE id = 180/
UPDATE SalesDistrict SET district_name='West Low Commercial', area_name='Low Commercial', market_name='Low Commercial', division_id=10, default_pdm_id=120 WHERE id = 181/
UPDATE SalesDistrict SET district_name='Colombia-Ecuador', area_name='Colombia', market_name='', division_id=11, default_pdm_id=121 WHERE id = 182/
UPDATE SalesDistrict SET district_name='Venezuela', area_name='Venezuela', market_name='', division_id=11, default_pdm_id=122 WHERE id = 183/
UPDATE SalesDistrict SET district_name='CCA', area_name='Puerto Rico', market_name='', division_id=11, default_pdm_id=123 WHERE id = 184/
UPDATE SalesDistrict SET district_name='Saudi Arabia', area_name='SEL', market_name='', division_id=12, default_pdm_id=59 WHERE id = 185/
UPDATE SalesDistrict SET district_name='Egypt', area_name='SEL', market_name='', division_id=12, default_pdm_id=59 WHERE id = 186/
UPDATE SalesDistrict SET district_name='Libya', area_name='SEL', market_name='', division_id=12, default_pdm_id=59 WHERE id = 187/
UPDATE SalesDistrict SET district_name='Bahrain', area_name='GULF', market_name='', division_id=12, default_pdm_id=60 WHERE id = 188/
UPDATE SalesDistrict SET district_name='Kuwait', area_name='GULF', market_name='', division_id=12, default_pdm_id=60 WHERE id = 189/
UPDATE SalesDistrict SET district_name='Oman', area_name='GULF', market_name='', division_id=12, default_pdm_id=60 WHERE id = 190/
UPDATE SalesDistrict SET district_name='Pakistan', area_name='GULF', market_name='', division_id=12, default_pdm_id=60 WHERE id = 191/
UPDATE SalesDistrict SET district_name='Qatar', area_name='GULF', market_name='', division_id=12, default_pdm_id=60 WHERE id = 192/
UPDATE SalesDistrict SET district_name='UAE', area_name='GULF', market_name='', division_id=12, default_pdm_id=60 WHERE id = 193/
UPDATE SalesDistrict SET district_name='Yemen', area_name='GULF', market_name='', division_id=12, default_pdm_id=60 WHERE id = 194/
UPDATE SalesDistrict SET district_name='Iraq', area_name='LEMA', market_name='', division_id=12, default_pdm_id=67 WHERE id = 195/
UPDATE SalesDistrict SET district_name='Jordan', area_name='LEMA', market_name='', division_id=12, default_pdm_id=67 WHERE id = 196/
UPDATE SalesDistrict SET district_name='Lebanon', area_name='LEMA', market_name='', division_id=12, default_pdm_id=67 WHERE id = 197/
UPDATE SalesDistrict SET district_name='Palestine', area_name='LEMA', market_name='', division_id=12, default_pdm_id=67 WHERE id = 198/
UPDATE SalesDistrict SET district_name='South Africa', area_name='South Africa', market_name='', division_id=12, default_pdm_id=71 WHERE id = 199/
UPDATE SalesDistrict SET district_name='NWCA', area_name='NWCA', market_name='', division_id=12, default_pdm_id=67 WHERE id = 200/
UPDATE SalesDistrict SET district_name='Enterprise South', area_name='United Kingdom', market_name='', division_id=13, default_pdm_id=73 WHERE id = 202/
UPDATE SalesDistrict SET district_name='Enterprise North', area_name='United Kingdom', market_name='', division_id=13, default_pdm_id=73 WHERE id = 203/
UPDATE SalesDistrict SET district_name='Mid Markets', area_name='United Kingdom', market_name='', division_id=13, default_pdm_id=73 WHERE id = 204/
UPDATE SalesDistrict SET district_name='Global Alliances', area_name='United Kingdom', market_name='', division_id=13, default_pdm_id=73 WHERE id = 205/
UPDATE SalesDistrict SET district_name='Public Sector', area_name='United Kingdom', market_name='', division_id=13, default_pdm_id=74 WHERE id = 206/
UPDATE SalesDistrict SET district_name='Service Provider', area_name='United Kingdom', market_name='', division_id=13, default_pdm_id=74 WHERE id = 207/
UPDATE SalesDistrict SET district_name='Enterprise', area_name='Ireland', market_name='', division_id=13, default_pdm_id=74 WHERE id = 208/
UPDATE SalesDistrict SET district_name='Mid Market', area_name='Ireland', market_name='', division_id=13, default_pdm_id=74 WHERE id = 209/
UPDATE SalesDistrict SET district_name='France', area_name='France', market_name='', division_id=14, default_pdm_id=76 WHERE id = 210/
UPDATE SalesDistrict SET district_name='South', area_name='Germany', market_name='', division_id=15, default_pdm_id=82 WHERE id = 211/
UPDATE SalesDistrict SET district_name='Central', area_name='Germany', market_name='', division_id=15, default_pdm_id=83 WHERE id = 212/
UPDATE SalesDistrict SET district_name='North', area_name='Germany', market_name='', division_id=15, default_pdm_id=84 WHERE id = 213/
UPDATE SalesDistrict SET district_name='Switzerland', area_name='West', market_name='', division_id=17, default_pdm_id=86 WHERE id = 215/
UPDATE SalesDistrict SET district_name='Belgium', area_name='West', market_name='', division_id=17, default_pdm_id=87 WHERE id = 216/
UPDATE SalesDistrict SET district_name='Luxembourg', area_name='West', market_name='', division_id=17, default_pdm_id=87 WHERE id = 217/
UPDATE SalesDistrict SET district_name='Denmark', area_name='West', market_name='', division_id=17, default_pdm_id=89 WHERE id = 218/
UPDATE SalesDistrict SET district_name='Finland', area_name='West', market_name='', division_id=17, default_pdm_id=90 WHERE id = 219/
UPDATE SalesDistrict SET district_name='Norway', area_name='West', market_name='', division_id=17, default_pdm_id=91 WHERE id = 220/
UPDATE SalesDistrict SET district_name='Sweden', area_name='West', market_name='', division_id=17, default_pdm_id=92 WHERE id = 221/
UPDATE SalesDistrict SET district_name='The Netherlands', area_name='West', market_name='', division_id=17, default_pdm_id=93 WHERE id = 222/
UPDATE SalesDistrict SET district_name='Spain', area_name='West', market_name='', division_id=17, default_pdm_id=94 WHERE id = 223/
UPDATE SalesDistrict SET district_name='Portugal', area_name='West', market_name='', division_id=17, default_pdm_id=95 WHERE id = 224/
UPDATE SalesDistrict SET district_name='Italy', area_name='West', market_name='', division_id=17, default_pdm_id=96 WHERE id = 225/
UPDATE SalesDistrict SET district_name='Greece', area_name='West', market_name='', division_id=17, default_pdm_id=124 WHERE id = 226/
UPDATE SalesDistrict SET district_name='Israel', area_name='West', market_name='', division_id=17, default_pdm_id=125 WHERE id = 227/
UPDATE SalesDistrict SET district_name='Poland', area_name='East', market_name='', division_id=16, default_pdm_id=126 WHERE id = 228/
UPDATE SalesDistrict SET district_name='Russia', area_name='East', market_name='', division_id=16, default_pdm_id=127 WHERE id = 229/
UPDATE SalesDistrict SET district_name='Austria', area_name='East', market_name='', division_id=16, default_pdm_id=126 WHERE id = 230/
UPDATE SalesDistrict SET district_name='RoEE', area_name='East', market_name='', division_id=16, default_pdm_id=126 WHERE id = 231/
UPDATE SalesDistrict SET district_name='Turkey', area_name='East', market_name='', division_id=16, default_pdm_id=130 WHERE id = 232/
UPDATE SalesDistrict SET district_name='MIDMARKET SELECT HOUSTON DISTRICT', area_name='South', market_name='MidMarket', division_id=6, default_pdm_id=98 WHERE id = 233/
UPDATE SalesDistrict SET district_name='MIDMARKET SELECT CHARLOTTE DISTRICT', area_name='Carolinas', market_name='MidMarket', division_id=6, default_pdm_id=26 WHERE id = 234/
UPDATE SalesDistrict SET district_name='MIDMARKET SELECT GREENSBORO DISTRICT', area_name='Carolinas', market_name='MidMarket', division_id=6, default_pdm_id=26 WHERE id = 235/
UPDATE SalesDistrict SET district_name='MIDMARKET SELECT RICHMOND DISTRICT', area_name='Carolinas', market_name='MidMarket', division_id=6, default_pdm_id=26 WHERE id = 236/
UPDATE SalesDistrict SET district_name='MIDMARKET SELECT DALLAS DISTRICT', area_name='South', market_name='MidMarket', division_id=6, default_pdm_id=27 WHERE id = 237/
UPDATE SalesDistrict SET district_name='MIDMARKET SELECT HEALTHCARE SOUTH DISTRICT', area_name='South', market_name='MidMarket', division_id=6, default_pdm_id=27 WHERE id = 238/
UPDATE SalesDistrict SET district_name='MIDMARKET SELECT LAM DISTRICT', area_name='South Central', market_name='MidMarket', division_id=6, default_pdm_id=27 WHERE id = 239/
UPDATE SalesDistrict SET district_name='MIDMARKET SELECT LAM HEALTHCARE DISTRICT', area_name='South Central', market_name='MidMarket', division_id=6, default_pdm_id=27 WHERE id = 240/
UPDATE SalesDistrict SET district_name='MIDMARKET SELECT TN-KY DISTRICT', area_name='South Central', market_name='MidMarket', division_id=6, default_pdm_id=27 WHERE id = 241/
UPDATE SalesDistrict SET district_name='MIDMARKET SELECT TN-KY HEALTHCARE DISTRICT', area_name='South Central', market_name='MidMarket', division_id=6, default_pdm_id=27 WHERE id = 242/
UPDATE SalesDistrict SET district_name='MIDMARKET SELECT AUSTIN DISTRICT', area_name='South', market_name='MidMarket', division_id=6, default_pdm_id=29 WHERE id = 243/
UPDATE SalesDistrict SET district_name='MIDMARKET SELECT METRO ATLANTA DISTRICT', area_name='Southeast', market_name='MidMarket', division_id=6, default_pdm_id=32 WHERE id = 244/
UPDATE SalesDistrict SET district_name='MIDMARKET SELECT ATLANTA HEALTH DISTRICT', area_name='Southeast', market_name='MidMarket', division_id=6, default_pdm_id=33 WHERE id = 245/
UPDATE SalesDistrict SET district_name='MIDMARKET SELECT FLORIDA 1 DISTRICT', area_name='Southeast', market_name='MidMarket', division_id=6, default_pdm_id=33 WHERE id = 246/
UPDATE SalesDistrict SET district_name='MIDMARKET SELECT FLORIDA 2 DISTRICT', area_name='Southeast', market_name='MidMarket', division_id=6, default_pdm_id=33 WHERE id = 247/
UPDATE SalesDistrict SET district_name='MIDMARKET SELECT PHILADELPHIA EAST DISTRICT', area_name='Mid-Atlantic', market_name='MidMarket', division_id=6, default_pdm_id=99 WHERE id = 248/
UPDATE SalesDistrict SET district_name='MIDMARKET SELECT PHILADELPHIA WEST DISTRICT', area_name='Mid-Atlantic', market_name='MidMarket', division_id=6, default_pdm_id=99 WHERE id = 249/
UPDATE SalesDistrict SET district_name='MIDMARKET SELECT BALTIMORE DISTRICT', area_name='Mid-Atlantic', market_name='MidMarket', division_id=6, default_pdm_id=37 WHERE id = 250/
UPDATE SalesDistrict SET district_name='MIDMARKET SELECT MCLEAN DISTRICT', area_name='Carolinas', market_name='MidMarket', division_id=6, default_pdm_id=37 WHERE id = 251/
UPDATE SalesDistrict SET district_name='Federal', area_name='Enterprise', market_name='Enterprise', division_id=1, default_pdm_id=1 WHERE id = 252/
UPDATE SalesDistrict SET district_name='Oil & Gas', area_name='Enterprise', market_name='Enterprise', division_id=1, default_pdm_id=1 WHERE id = 253/
UPDATE SalesDistrict SET district_name='Enterprise', area_name='Enterprise', market_name='Enterprise', division_id=1, default_pdm_id=1 WHERE id = 254/
UPDATE SalesDistrict SET district_name='Commercial', area_name='Geo SP', market_name='MidMarket/SMB', division_id=1, default_pdm_id=1 WHERE id = 255/
UPDATE SalesDistrict SET district_name='MidMarket - Arkansas', area_name='Arkansas', market_name='MidMarket', division_id=2, default_pdm_id=4 WHERE id = 256/
UPDATE SalesDistrict SET district_name='High Growth & Educational', area_name='Mexico City', market_name='MidMarket', division_id=5, default_pdm_id=23 WHERE id = 257/
UPDATE SalesDistrict SET district_name='Monterrey', area_name='Geo North', market_name='MidMarket', division_id=5, default_pdm_id=23 WHERE id = 258/
UPDATE SalesDistrict SET district_name='MM-E Large ACCT NE District', area_name='Commercial East', market_name='MM', division_id=7, default_pdm_id=110 WHERE id = 260/
UPDATE SalesDistrict SET district_name='MM-E Territory NE North District', area_name='Commercial East', market_name='MM', division_id=7, default_pdm_id=131 WHERE id = 261/
UPDATE SalesDistrict SET district_name='MM-E Territory NE South District', area_name='Commercial East', market_name='MM', division_id=7, default_pdm_id=131 WHERE id = 262/
UPDATE SalesDistrict SET district_name='Toronto Financial', area_name='Canada', market_name='Enterprise', division_id=7, default_pdm_id=108 WHERE id = 263/
UPDATE SalesDistrict SET district_name='MIDMARKET SELECT BOSTON DISTRICT', area_name='Northeast', market_name='MidMarket', division_id=7, default_pdm_id=110 WHERE id = 264/
UPDATE SalesDistrict SET district_name='MIDMARKET SELECT NEW ENGLAND DISTRICT', area_name='Northeast', market_name='MidMarket', division_id=7, default_pdm_id=110 WHERE id = 265/
UPDATE SalesDistrict SET district_name='MIDMARKET SELECT NEWTON DISTRICT', area_name='Northeast', market_name='MidMarket', division_id=7, default_pdm_id=110 WHERE id = 266/
UPDATE SalesDistrict SET district_name='MIDMARKET SELECT CONNECTICUT DISTRICT', area_name='Northeast', market_name='MidMarket', division_id=7, default_pdm_id=38 WHERE id = 267/
UPDATE SalesDistrict SET district_name='MIDMARKET SELECT UPSTATE NY DISTRICT', area_name='Northeast', market_name='MidMarket', division_id=7, default_pdm_id=38 WHERE id = 268/
UPDATE SalesDistrict SET district_name='Enterprise - Bank of America', area_name='BOA', market_name='Enterprise', division_id=8, default_pdm_id=113 WHERE id = 269/
UPDATE SalesDistrict SET district_name='Enterprise - Hillock', area_name='Scotto', market_name='Enterprise', division_id=8, default_pdm_id=46 WHERE id = 273/
UPDATE SalesDistrict SET district_name='Enterprise - Polaski - Burgess District', area_name='Polaski', market_name='Enterprise', division_id=8, default_pdm_id=113 WHERE id = 275/
UPDATE SalesDistrict SET district_name='Enterprise - Polaski - Other Districts', area_name='Polaski', market_name='Enterprise', division_id=8, default_pdm_id=45 WHERE id = 276/
UPDATE SalesDistrict SET district_name='Enterprise - Lilienfeld', area_name='Scotto', market_name='Enterprise', division_id=8, default_pdm_id=111 WHERE id = 277/
UPDATE SalesDistrict SET district_name='MIDMARKET SELECT NJ 1 DISTRICT', area_name='Trizzino', market_name='GEO', division_id=8, default_pdm_id=112 WHERE id = 279/
UPDATE SalesDistrict SET district_name='MIDMARKET SELECT NJ 2 DISTRICT', area_name='Trizzino', market_name='GEO', division_id=8, default_pdm_id=112 WHERE id = 280/
UPDATE SalesDistrict SET district_name='MIDMARKET SELECT NYC 1 DISTRICT', area_name='Trizzino', market_name='GEO', division_id=8, default_pdm_id=112 WHERE id = 281/
UPDATE SalesDistrict SET district_name='MIDMARKET SELECT NYC 2 DISTRICT', area_name='Trizzino', market_name='GEO', division_id=8, default_pdm_id=112 WHERE id = 282/
UPDATE SalesDistrict SET district_name='NJ HEALTHCARE/LEGAL DISTRICT', area_name='Scotto', market_name='Enterprise', division_id=8, default_pdm_id=112 WHERE id = 283/
UPDATE SalesDistrict SET district_name='Enterprise - Las Vegas', area_name='Mountain', market_name='Enterprise', division_id=9, default_pdm_id=118 WHERE id = 284/
UPDATE SalesDistrict SET district_name='Enterprise - New Mexico', area_name='Mountain', market_name='Enterprise', division_id=9, default_pdm_id=54 WHERE id = 285/
UPDATE SalesDistrict SET district_name='Enterprise - Santa Clara 1', area_name='Nor Cal', market_name='Enterprise', division_id=9, default_pdm_id=48 WHERE id = 286/
UPDATE SalesDistrict SET district_name='MidMarket - AZ', area_name='SW Comm', market_name='MidMarket', division_id=9, default_pdm_id=118 WHERE id = 287/
UPDATE SalesDistrict SET district_name='MidMarket - NM', area_name='SW Comm', market_name='MidMarket', division_id=9, default_pdm_id=54 WHERE id = 288/
UPDATE SalesDistrict SET district_name='MidMarket - N. NV', area_name='SW Comm', market_name='MidMarket', division_id=9, default_pdm_id=115 WHERE id = 289/
UPDATE SalesDistrict SET district_name='MidMarket - S. NV', area_name='SW Comm', market_name='MidMarket', division_id=9, default_pdm_id=118 WHERE id = 290/
UPDATE SalesDistrict SET district_name='Strategic Programs', area_name='Civilian', market_name='Enterprise', division_id=4, default_pdm_id=18 WHERE id = 318/
UPDATE SalesDistrict SET district_name='DHS / State Dept', area_name='Civilian', market_name='Enterprise', division_id=4, default_pdm_id=119 WHERE id = 319/
UPDATE SalesDistrict SET district_name='BRS - South', area_name='Germany', market_name='', division_id=15, default_pdm_id=82 WHERE id = 320/
UPDATE SalesDistrict SET district_name='BRS - Central', area_name='Germany', market_name='', division_id=15, default_pdm_id=83 WHERE id = 321/
UPDATE SalesDistrict SET district_name='BRS - North', area_name='Germany', market_name='', division_id=15, default_pdm_id=84 WHERE id = 322/
UPDATE SalesDistrict SET district_name='France - BRS', area_name='France', market_name='', division_id=14, default_pdm_id=79 WHERE id = 323/
UPDATE SalesDistrict SET district_name='MS', area_name='MS', market_name='MS', division_id=26, default_pdm_id=132 WHERE id = 324/
UPDATE SalesDistrict SET district_name='TBD', area_name='NotListed', market_name='', division_id=22, default_pdm_id=135 WHERE id = 325/
UPDATE SalesDistrict SET district_name='TBD', area_name='NotListed', market_name='', division_id=19, default_pdm_id=138 WHERE id = 326/
UPDATE SalesDistrict SET district_name='AUS', area_name='ANZ', market_name='', division_id=18, default_pdm_id=139 WHERE id = 327/
UPDATE SalesDistrict SET district_name='Greater China', area_name='Greater China', market_name='', division_id=19, default_pdm_id=138 WHERE id = 328/
UPDATE SalesDistrict SET district_name='India', area_name='India', market_name='', division_id=20, default_pdm_id=136 WHERE id = 329/
UPDATE SalesDistrict SET district_name='TBD', area_name='NotListed', market_name='', division_id=18, default_pdm_id=139 WHERE id = 330/
UPDATE SalesDistrict SET district_name='ECD', area_name='ECD', market_name='ECD', division_id=25, default_pdm_id=140 WHERE id = 331/
UPDATE SalesDistrict SET district_name='Korea', area_name='Korea', market_name='', division_id=22, default_pdm_id=135 WHERE id = 332/
UPDATE SalesDistrict SET district_name='TBD', area_name='NotListed', market_name='', division_id=21, default_pdm_id=134 WHERE id = 333/
UPDATE SalesDistrict SET district_name='NZL', area_name='ANZ', market_name='', division_id=18, default_pdm_id=139 WHERE id = 334/
UPDATE SalesDistrict SET district_name='Japan', area_name='Japan', market_name='', division_id=21, default_pdm_id=134 WHERE id = 335/
UPDATE SalesDistrict SET district_name='Singapore', area_name='Singapore', market_name='', division_id=23, default_pdm_id=133 WHERE id = 336/
UPDATE SalesDistrict SET district_name='TBD', area_name='NotListed', market_name='', division_id=23, default_pdm_id=133 WHERE id = 337/
UPDATE SalesDistrict SET district_name='Malaysia', area_name='Malaysia', market_name='', division_id=23, default_pdm_id=133 WHERE id = 338/
UPDATE SalesDistrict SET district_name='TBD', area_name='NotListed', market_name='', division_id=20, default_pdm_id=136 WHERE id = 339/
UPDATE SalesDistrict SET district_name='Hong Kong', area_name='Hong Kong', market_name='', division_id=19, default_pdm_id=138 WHERE id = 340/
UPDATE SalesDistrict SET district_name='RSA', area_name='RSA', market_name='RSA', division_id=24, default_pdm_id=137 WHERE id = 341/
DELETE FROM pdmname WHERE id = 77/
DELETE FROM pdmname WHERE id = 78/
DELETE FROM pdmname WHERE id = 80/
DELETE FROM pdmname WHERE id = 81/

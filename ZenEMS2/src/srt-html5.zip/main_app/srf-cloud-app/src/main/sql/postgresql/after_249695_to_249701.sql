ALTER TABLE Division ADD COLUMN strict_profile_search BOOLEAN DEFAULT false;

UPDATE Division SET strict_profile_search = TRUE WHERE id = 24;
UPDATE Division SET strict_profile_search = TRUE WHERE id = 25;
UPDATE Division SET strict_profile_search = TRUE WHERE id = 26;

ALTER TABLE IPEDUData DROP COLUMN hosts_number;

INSERT INTO replicationmanagerinformation VALUES(1, 3, true, true, true, true, true, true, true, true, 1, 1, 1, 1, 1, 1, 1, 1, true, true, true);
INSERT INTO replicationmanagerinformation VALUES(2, 5, false, false, false, false, false, false, false, false, 2, 2, 2, 2, 2, 2, 2, 2, false, false, false);
INSERT INTO replicationmanagerinformation VALUES(3, 5, true, true, true, true, true, true, true, true, 3, 3, 3, 3, 2, 2, 2, 3, true, true, true);

INSERT INTO RepManagerInformation_SHN VALUES(1, 'Windows', 1);
INSERT INTO RepManagerInformation_SHN VALUES(1, 'Solaris', 1);
INSERT INTO RepManagerInformation_SHN VALUES(1, 'AIX', 0);
INSERT INTO RepManagerInformation_SHN VALUES(1, 'HP-UX', 2);
INSERT INTO RepManagerInformation_SHN VALUES(1, 'Linux', 1);
INSERT INTO RepManagerInformation_SHN VALUES(1, 'VMWare ESX', 0);
INSERT INTO RepManagerInformation_SHN VALUES(1, 'NetWare', 0);
INSERT INTO RepManagerInformation_SHN VALUES(1, 'HP VMS', 0);
INSERT INTO RepManagerInformation_SHN VALUES(1, 'Other', 1);

INSERT INTO RepManagerInformation_THN VALUES(1, 'Windows', 1);
INSERT INTO RepManagerInformation_THN VALUES(1, 'Solaris', 0);
INSERT INTO RepManagerInformation_THN VALUES(1, 'AIX', 0);
INSERT INTO RepManagerInformation_THN VALUES(1, 'HP-UX', 2);
INSERT INTO RepManagerInformation_THN VALUES(1, 'Linux', 0);
INSERT INTO RepManagerInformation_THN VALUES(1, 'VMWare ESX', 0);
INSERT INTO RepManagerInformation_THN VALUES(1, 'NetWare', 1);
INSERT INTO RepManagerInformation_THN VALUES(1, 'HP VMS', 0);
INSERT INTO RepManagerInformation_THN VALUES(1, 'Other', 1);

INSERT INTO timefinderinformation VALUES(1, 5, true, true, true, true, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1);
INSERT INTO timefinderinformation VALUES(2, 7, false, false, false, false, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2);

INSERT INTO TimeFinderInformation_HN VALUES(1, 'Windows', 1);
INSERT INTO TimeFinderInformation_HN VALUES(1, 'VMWare ESX', 3);
INSERT INTO TimeFinderInformation_HN VALUES(1, 'NetWare', 4);
INSERT INTO TimeFinderInformation_HN VALUES(1, 'HP VMS', 5);
INSERT INTO TimeFinderInformation_HN VALUES(1, 'Other', 7);
INSERT INTO TimeFinderInformation_HN VALUES(2, 'Windows', 1);
INSERT INTO TimeFinderInformation_HN VALUES(2, 'VMWare ESX', 3);
INSERT INTO TimeFinderInformation_HN VALUES(2, 'NetWare', 4);
INSERT INTO TimeFinderInformation_HN VALUES(2, 'HP VMS', 5);
INSERT INTO TimeFinderInformation_HN VALUES(2, 'Other', 7);

INSERT INTO snapviewinformation VALUES(1, 3.5, 1, true, true, 1, 1, 1, 1, 1, 2);
INSERT INTO snapviewinformation VALUES(2, 6.5, 2, false, true, 2, 2, 2, 2, 3, 4);

INSERT INTO SnapViewInformation_HN VALUES(1, 'Windows', 1);
INSERT INTO SnapViewInformation_HN VALUES(1, 'VMWare ESX', 3);
INSERT INTO SnapViewInformation_HN VALUES(1, 'NetWare', 4);
INSERT INTO SnapViewInformation_HN VALUES(1, 'HP VMS', 5);
INSERT INTO SnapViewInformation_HN VALUES(1, 'Other', 7);
INSERT INTO SnapViewInformation_HN VALUES(2, 'Windows', 1);
INSERT INTO SnapViewInformation_HN VALUES(2, 'VMWare ESX', 3);
INSERT INTO SnapViewInformation_HN VALUES(2, 'NetWare', 4);
INSERT INTO SnapViewInformation_HN VALUES(2, 'HP VMS', 5);
INSERT INTO SnapViewInformation_HN VALUES(2, 'Other', 7);

INSERT INTO bcservicesscope VALUES(1, true, true, true, true, true);
INSERT INTO bcservicesscope VALUES(2, false, false, false, false, false);
INSERT INTO bcservicesscope VALUES(3, true, true, true, true, true);

INSERT INTO openreplicator VALUES(1, 3.5, 1);
INSERT INTO openreplicator VALUES(2, 8, 2);

INSERT INTO srdfinformation VALUES(1, 2, true, true, true, true, true, 1, 1, 1, true, true, 0, 0, 0);
INSERT INTO srdfinformation VALUES(2, 3, false, false, false, false, false, 2, 2, 2, false, false, 0, 0, 0);

INSERT INTO srdfinformation_hostnumbers VALUES(1, 'Windows', 0);
INSERT INTO srdfinformation_hostnumbers VALUES(1, 'Solaris', 1);
INSERT INTO srdfinformation_hostnumbers VALUES(1, 'AIX', 0);
INSERT INTO srdfinformation_hostnumbers VALUES(1, 'HP-UX', 0);
INSERT INTO srdfinformation_hostnumbers VALUES(1, 'Linux', 1);
INSERT INTO srdfinformation_hostnumbers VALUES(1, 'VMWare ESX', 0);
INSERT INTO srdfinformation_hostnumbers VALUES(1, 'NetWare', 0);
INSERT INTO srdfinformation_hostnumbers VALUES(1, 'HP VMS', 0);
INSERT INTO srdfinformation_hostnumbers VALUES(1, 'Other', 1);

INSERT INTO SRDFINFORMATION_SOURCEARRAY VALUES (1, 1, true, 33, 10, 20, false, 1, 1, 4);
INSERT INTO SRDFINFORMATION_SOURCEARRAY VALUES (1, 2, true, 44, 12, 22, true, 2, 2, 2);

INSERT INTO SRDFINFORMATION_TARGETARRAY VALUES (1, 1, true, 33, 55, false, 'Source 1', false, false, 2, 3);
INSERT INTO SRDFINFORMATION_TARGETARRAY VALUES (1, 2, false, 66, 77, true, 'Source 2', true, true, 2, 3);

INSERT INTO mirrorviewinformation VALUES(1, 4.5, true, false, false, 1, 1, 'custom_scripting_details1', 1, 1, 2);
INSERT INTO mirrorviewinformation VALUES(2, 2.3, false, true, true, 2, 2, 'custom_scripting_details2', 3, 4, 5);

INSERT INTO MIRRORVIEWINFORMATION_HN VALUES (1, 'Windows', 21);
INSERT INTO MIRRORVIEWINFORMATION_HN VALUES (1, 'AIX', 33);
INSERT INTO MIRRORVIEWINFORMATION_HN VALUES (1, 'Solaris', 12);

INSERT INTO MIRRORVIEWINFORMATION_SA VALUES (1, 1, true, true, 12, true, 1);
INSERT INTO MIRRORVIEWINFORMATION_SA VALUES (1, 2, false, false, 12, false, 2);

INSERT INTO MIRRORVIEWINFORMATION_TA VALUES (1, 1, null, true, true);
INSERT INTO MIRRORVIEWINFORMATION_TA VALUES (1, 2, null, false, false);

INSERT INTO bcrequestdata VALUES(1, 'general comment', 1, 1, 1, 1, 1, 1, 1, 1.2);
INSERT INTO bcrequestdata VALUES(2, 'general comment', 0, 2, 2, 2, 2, 2, 2, 4.2);

INSERT INTO nasfeature VALUES(1, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true);
INSERT INTO nasfeature VALUES(2, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false);
INSERT INTO nasfeature VALUES(3, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true);

INSERT INTO NASMIGRATIONINFORMATION VALUES (1, 'NewYork', 23, 5, 7, false, 43, 3, 3, 5, true, 6, 7, 3, 1, 1);
INSERT INTO NASMIGRATIONINFORMATION VALUES (2, 'Chicago', 44, 5, 6, true, 44, 1, 2, 62, true, 8, 9, 6, 2, 2);

INSERT INTO CELERRADETAILINFORMATION VALUES (1, 3, 1, 'Chicago', false, false, 2, 1, true, true, 0, true, 12, 66, true, true, true, 1, null, null, null, null, null, null, null, null, true, 23, 44, true, 22, 22, 1, 1, 1, 1, 1, 1, 2);
INSERT INTO CELERRADETAILINFORMATION VALUES (2, 3, 2, 'NewYork', false, true, 1, 2, false, true, 0, true, 33, 55, true, true, true, 2, null, null, null, null, null, null, null, null, true, 56, 88, false, 11, 33, 1, 1, 1, 1, 1, 1, 3);

INSERT INTO unifiedservicesscope VALUES(1, true, true, true, true, true, true, false);
INSERT INTO unifiedservicesscope VALUES(2, false, false, false, false, false, false, false);
INSERT INTO unifiedservicesscope VALUES(3, true, true, true, true, true, true, true);

INSERT INTO unifiedrequestdata VALUES(1, 'general comment', 4, 5, 1, 3, true, true, 1);
INSERT INTO unifiedrequestdata VALUES(2, 'general comment', 4, 5, 2, 3, true, false, 2);
INSERT INTO unifiedrequestdata VALUES(3, 'general comment', 4, 5, 3, 5, false, true, 3);

INSERT INTO UNIFIEDREQUESTDATA_CELERRADI VALUES (1, 1);
INSERT INTO UNIFIEDREQUESTDATA_CELERRADI VALUES (1, 2);

INSERT INTO UNIFIEDREQUESTDATA_NASMI VALUES (1, 1);
INSERT INTO UNIFIEDREQUESTDATA_NASMI VALUES (1, 2);

INSERT INTO santaninformation VALUES(1, 2, true, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1);
INSERT INTO santaninformation VALUES(2, 1, false, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2);
INSERT INTO santaninformation VALUES(3, 4, true, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3);

INSERT INTO datamigrationinformation VALUES(1, 2.3, 1, true, true, 1, 1, 1, 1, 1, 1, 1, true, 1, true, true, true, 'Open Replicator');
INSERT INTO datamigrationinformation VALUES(2, 4.6, 2, false, false, 2, 2, 2, 2, 2, 2, 2, true, 2, false, false, false, 'SRDF');

INSERT INTO DataMigInformationn_array VALUES(1, 1, 'location1', 1, 1, 1, true, 'Source', 2.34);
INSERT INTO DataMigInformationn_array VALUES(2, 2, 'location2', 2, 2, 2, false, 'Target', 100);

INSERT INTO environmentdetailsinformation VALUES(1, 1, 1, 1, 1, 1);
INSERT INTO environmentdetailsinformation VALUES(2, 2, 2, 2, 2, 2);

INSERT INTO envdetailsinformation_exat VALUES(1, 1, 1);
INSERT INTO envdetailsinformation_exat VALUES(2, 2, 2);

INSERT INTO EnvDetailsInformation_exSL VALUES(1, 1, 'Chicago');
INSERT INTO EnvDetailsInformation_exSL VALUES(2, 2, 'Chicago');

INSERT INTO EnvDetailsInformation_UC VALUES(1, 1, 1);
INSERT INTO EnvDetailsInformation_UC VALUES(2, 2, 2);

INSERT INTO EnvDetailsInformation_NAH VALUES(1, 1, 1);
INSERT INTO EnvDetailsInformation_NAH VALUES(2, 2, 2);

INSERT INTO EnvDetailsInformation_EDT VALUES(1, 1, 1);
INSERT INTO EnvDetailsInformation_EDT VALUES(2, 2, 2);

INSERT INTO EnvDetailsInformation_exSanLo VALUES(1, 1, 'Chicago');
INSERT INTO EnvDetailsInformation_exSanLo VALUES(2, 2, 'Chicago');

INSERT INTO EnvDetailsInformation_man VALUES(1, 1, 'value1');
INSERT INTO EnvDetailsInformation_man VALUES(2, 2, 'value2');

INSERT INTO EnvDetailsInformation_devQ VALUES(1, 1, 1);
INSERT INTO EnvDetailsInformation_devQ VALUES(2, 2, 2);

INSERT INTO EnvDetailsInformation_hostIn VALUES(1, 1, 'Windows', 0, 1, 1, 1, 'CX-Chicago');
INSERT INTO EnvDetailsInformation_hostIn VALUES(2, 1, 'Solaris', 0, 1, 1, 1, 'CX-Chicago');
INSERT INTO EnvDetailsInformation_hostIn VALUES(3, 1, 'AIX', 1, 1, 1, 1, 'CX-Chicago');
INSERT INTO EnvDetailsInformation_hostIn VALUES(4, 1, 'HP-UX', 0, 1, 1, 1, 'CX-Chicago');
INSERT INTO EnvDetailsInformation_hostIn VALUES(5, 1, 'Linux', 0, 1, 1, 1, 'CX-Chicago');
INSERT INTO EnvDetailsInformation_hostIn VALUES(6, 1, 'VMWare ESX', 0, 1, 1, 1, 'CX-Chicago');
INSERT INTO EnvDetailsInformation_hostIn VALUES(7, 1, 'NetWare', 0, 1, 1, 1, 'CX-Chicago');
INSERT INTO EnvDetailsInformation_hostIn VALUES(8, 1, 'HP VMS', 0, 1, 1, 1, 'CX-Chicago');
INSERT INTO EnvDetailsInformation_hostIn VALUES(9, 1, 'Other', 0, 1, 1, 1, 'CX-Chicago');
INSERT INTO EnvDetailsInformation_hostIn VALUES(10, 2, 'Windows', 0, 1, 1, 1, 'CX-Chicago');
INSERT INTO EnvDetailsInformation_hostIn VALUES(11, 2, 'Solaris', 0, 1, 1, 1, 'CX-Chicago');
INSERT INTO EnvDetailsInformation_hostIn VALUES(12, 2, 'AIX', 0, 1, 1, 1, 'CX-Chicago');
INSERT INTO EnvDetailsInformation_hostIn VALUES(13, 2, 'HP-UX', 0, 1, 1, 1, 'CX-Chicago');
INSERT INTO EnvDetailsInformation_hostIn VALUES(14, 2, 'Linux', 0, 1, 1, 1, 'CX-Chicago');
INSERT INTO EnvDetailsInformation_hostIn VALUES(15, 2, 'VMWare ESX', 0, 1, 1, 1, 'CX-Chicago');
INSERT INTO EnvDetailsInformation_hostIn VALUES(16, 2, 'NetWare', 0, 1, 1, 1, 'CX-Chicago');
INSERT INTO EnvDetailsInformation_hostIn VALUES(17, 2, 'HP VMS', 0, 1, 1, 1, 'CX-Chicago');
INSERT INTO EnvDetailsInformation_hostIn VALUES(18, 2, 'Other', 0, 1, 1, 1, 'CX-Chicago');

INSERT INTO vnxclariioninformation VALUES(1, 3, 1, 1, 1, 1, 1, 1, 1, true, 1, true, true, 1, 1, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, 1, 1, 1, 1, 1, 1, '< 1TB', 1, 1, 1, true, true, 3, 4, 5);
INSERT INTO vnxclariioninformation VALUES(2, 4, 2, 2, 2, 2, 2, 2, 2, false, 2, false, false, 2, 2, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, 2, 2, 2, 2, 2, 2, '< 1TB', 2, 2, 2, false, null, null, null, null);
INSERT INTO vnxclariioninformation VALUES(3, 5, 3, 3, 3, 3, 3, 3, 3, true, 3, true, true, 3, 3,  true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, 3, 3, 3, 3, 3, 3, '< 1TB', 3, 3, 3, true, true, 3, 4, 5);


INSERT INTO Vplex VALUES(1, 4, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, true, true);
INSERT INTO Vplex VALUES(2, 4.6, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, false, false);

INSERT INTO infrastructurerequestdata VALUES(1, 'general comment', false, false, true, true, true, true, true, true, true, 1, 1, 1, 1, null, null, 1);
INSERT INTO infrastructurerequestdata VALUES(2, 'general comment', false, false, false, false, false, false, false, false, true, 2, 2, 2, 2, null, null, 2);

INSERT INTO stringservicedata VALUES(1, 'service_name1', 'description1', 'value1');
INSERT INTO stringservicedata VALUES(2, 'service_name2', 'description2', 'value2');
INSERT INTO stringservicedata VALUES(3, 'service_name3', 'description3', 'value3');

INSERT INTO booleanservicedata VALUES(1, 'service_name1', 'description1', true);
INSERT INTO booleanservicedata VALUES(2, 'service_name2', 'description2', false);
INSERT INTO booleanservicedata VALUES(3, 'service_name3', 'description3', true);

INSERT INTO mainframeservicesscope VALUES(1, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true);
INSERT INTO mainframeservicesscope VALUES(2, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false);
INSERT INTO mainframeservicesscope VALUES(3, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true);

INSERT INTO mainframerequestdata VALUES(1, 'general comment', 1);
INSERT INTO mainframerequestdata VALUES(2, 'general comment', 2);
INSERT INTO mainframerequestdata VALUES(3, 'general comment', 3);

INSERT INTO MainframeReqData_booleanSD VALUES(1, 1);
INSERT INTO MainframeReqData_booleanSD VALUES(1, 2);
INSERT INTO MainframeReqData_booleanSD VALUES(3, 3);

INSERT INTO MainframeReqData_stringSD VALUES(1, 1);
INSERT INTO MainframeReqData_stringSD VALUES(2, 2);
INSERT INTO MainframeReqData_stringSD VALUES(1, 3);

INSERT INTO MSSFcAtaDrives VALUES(1, '73GB', '146GB', '300GB', '400GB', '450GB', '500GB', '600GB', '750GB', '1TB', '2TB', '3TB', 'Other');
INSERT INTO MSSFlashDrives VALUES(1, '73GB', '100GB', '146GB', '200GB', '400GB', 'Other');
INSERT INTO MSSVnxSasDrives VALUES(1, '300GB', '2.5" 300GB', '600GB', '2.5" 600GB', '2.5" 900GB', '3.5" 900GB', '1TB', '2TB', '3TB', '100GB', '200GB', 'Other');
INSERT INTO MSSClariionAx4Drives VALUES(1, '500GB', '750GB', '1000GB', '146GB', '300GB', '400GB', '450GB', '600GB', 'Other');
INSERT INTO MSSCenteraNodes VALUES(1, 'Gen-1 640GB', 'Gen-2 1TB', 'Gen-3 1.28TB', 'Gen-4 750GB', 'Gen-4 1.28TB', 'Gen-4 2TB', 'Gen-4LP 1TB', 'Gen-4LP 2TB', 'Other');
INSERT INTO MSSAvamarNodes VALUES(1, '1TB', '2TB', '3.3TB', 'Utility 1', 'Utility 2/3', 'Utility 4', 'Accelerator', 'Small 2', 'Large 2', 'Accelerator 3&4', '1.3TB', '2.6TB', '3.9TB', '7.8TB', 'Other');
INSERT INTO MSSDataDomain VALUES(1, 'model', 'serial', 10);
INSERT INTO MSSAtmos VALUES(1, '2.5" 250GB', '1TB', '2TB','3TB', 'Other');
INSERT INTO MSSGreenplum VALUES(1, '2.5" 600GB', '3.5" 600GB', '3.5" 2TB');

INSERT INTO MSSArray VALUES(1, 'New York', 1, 1, 1, 1, null, null, null, null, null, null, null);
INSERT INTO MSSArray VALUES(2, 'Chicago', 2, 2, null, null, 1, null, null, null, null, null, null);
INSERT INTO MSSArray VALUES(3, 'Washington', 3, 5, null, null, null, 1, null, null, null, null, null);
INSERT INTO MSSArray VALUES(4, 'Los Angeles', 1, 6, null, null, null, null, 1, null, null, null, null);
INSERT INTO MSSArray VALUES(5, 'Columbus', 2, 8, null, null, null, null, null, 1, null, null, null);
INSERT INTO MSSArray VALUES(6, 'Austin', 3, 7, null, null, null, null, null, null, 1, null, null);
INSERT INTO MSSArray VALUES(7, 'San Diego', 1, 9, null, null, null, null, null, null, null, 1, null);
INSERT INTO MSSArray VALUES(8, 'Houston', 2, 10, null, null, null, null, null, null, null, null, 1);

INSERT INTO MSSRequestData VALUES (1, 'desc1', 'general comment', 1);
INSERT INTO MSSRequestData VALUES (2, 'desc2', 'general comment', 2);
INSERT INTO MSSRequestData VALUES (3, 'desc3', 'general comment', 3);

INSERT INTO MSS_array VALUES(1, 1);
INSERT INTO MSS_array VALUES(1, 2);
INSERT INTO MSS_array VALUES(1, 3);
INSERT INTO MSS_array VALUES(1, 4);
INSERT INTO MSS_array VALUES(1, 5);
INSERT INTO MSS_array VALUES(1, 6);
INSERT INTO MSS_array VALUES(1, 7);
INSERT INTO MSS_array VALUES(1, 8);

INSERT INTO NASDestination VALUES(1, true, true, true, true, true, true, true, true);

INSERT INTO CTAImplementationArray VALUES(1, 'New York', 1, true, 10, 1, 10, true, 10, true, null, 10, 10, null);
INSERT INTO CTAImplementationArray VALUES(2, 'Chicago', 2, false, null, 2, 20, false, 20, false, null, 20, 20, null);
INSERT INTO CTAImplementationArray VALUES(3, 'Washington', 3, true, 30, 3, 30, true, 30, true, 1, 30, 30, true);

INSERT INTO CTAImplementation VALUES(1, 'explanation of customer expectations');
INSERT INTO CTAImplementation VALUES(2, 'explanation of customer expectations');
INSERT INTO CTAImplementation VALUES(3, 'explanation of customer expectations');

INSERT INTO CTAImplementation_array VALUES(1, 1);
INSERT INTO CTAImplementation_array VALUES(1, 2);
INSERT INTO CTAImplementation_array VALUES(1, 3);

INSERT INTO CTAConversion VALUES(1, 0, 10, 10, 10, 10, 10, 10, 0);
INSERT INTO CTAConversion VALUES(2, 1, 20, 20, 20, 20, 20, 20, 1);
INSERT INTO CTAConversion VALUES(3, 0, 30, 30, 30, 30, 30, 30, 0);

INSERT INTO CTARaininfinity VALUES(1, true, true, true, false, 10, 10, 10, 10, true, 10, true, true, 10, 10, 10, true, true, 10);
INSERT INTO CTARaininfinity VALUES(2, false, false, true, false, 20, 20, 20, 20, false, 20, false, false, 20, 20, 20, false, false, 20);
INSERT INTO CTARaininfinity VALUES(3, true, true, true, false, 30, 30, 30, 30, true, 30, true, true, 30, 30, 30, true, true, 30);

INSERT INTO CTAServicesScope VALUES(1, true, true, true, true);
INSERT INTO CTAServicesScope VALUES(2, true, true, true, true);
INSERT INTO CTAServicesScope VALUES(3, true, true, true, true);

INSERT INTO CTARequestData VALUES(1, 1, 1, 1, 1, 1, 1.5, 'general comment');
INSERT INTO CTARequestData VALUES(2, 2, 2, 2, 2, 2, 2.5, 'general comment');
INSERT INTO CTARequestData VALUES(3, 3, 3, 3, 3, 3, 3.5, 'general comment');

INSERT INTO RoleSkillLevel VALUES(1, 'Backup Administrator', 'Days', '10', 'info1');
INSERT INTO RoleSkillLevel VALUES(2, 'Backup Architect', 'Months', '20', 'info2');
INSERT INTO RoleSkillLevel VALUES(3, 'Senior Backup Administrator', 'Years', '30', 'info3');
INSERT INTO RoleSkillLevel VALUES(4, 'Project Manager', 'Days', '40', 'info4');
INSERT INTO RoleSkillLevel VALUES(5, 'Senior Project Manager', 'Months', '50', 'info5');
INSERT INTO RoleSkillLevel VALUES(6, 'Associate Systems Administrator', 'Days', '60', 'info6');
INSERT INTO RoleSkillLevel VALUES(7, 'Senior Systems Administrator', 'Months', '70', 'info7');
INSERT INTO RoleSkillLevel VALUES(8, 'Systems Administrator', 'Years', '80', 'info8');
INSERT INTO RoleSkillLevel VALUES(9, 'Assoc Storage Oper Specialist', 'Days', '90', 'info9');
INSERT INTO RoleSkillLevel VALUES(10, 'SAN-Storage Administrator', 'Months', '100', 'info10');
INSERT INTO RoleSkillLevel VALUES(11, 'Sr Storage Operations Specialist', 'Years', '110', 'info11');
INSERT INTO RoleSkillLevel VALUES(12, 'Senior Solutions Architect', 'Days', '120', 'info12');
INSERT INTO RoleSkillLevel VALUES(13, 'Solutions Architect', 'Months', '130', 'info13');
INSERT INTO RoleSkillLevel VALUES(14, 'Storage Operations Specialist', 'Years', '140', 'info14');
INSERT INTO RoleSkillLevel VALUES(15, 'Customer Support Engineer', 'Days', '150', 'info15');
INSERT INTO RoleSkillLevel VALUES(16, 'Strategic Account Manager (SAM)', 'Months', '160', 'info16');
INSERT INTO RoleSkillLevel VALUES(17, 'Senior VMWare Administrator', 'Days', '170', 'info17');
INSERT INTO RoleSkillLevel VALUES(18, 'Vmware Administrator', 'Months', '180', 'info18');
INSERT INTO RoleSkillLevel VALUES(19, 'Vmware Solutions Architect', 'Years', '190', 'info19');

INSERT INTO ResidencyRoleSkillLevels VALUES(1, 'instructions');

INSERT INTO ResRoleSkillLevels_backupL VALUES(1, 1);
INSERT INTO ResRoleSkillLevels_backupL VALUES(1, 2);
INSERT INTO ResRoleSkillLevels_backupL VALUES(1, 3);

INSERT INTO ResRoleSkillLevels_projectL VALUES(1, 4);
INSERT INTO ResRoleSkillLevels_projectL VALUES(1, 5);

INSERT INTO ResRoleSkillLevels_adminL VALUES(1, 6);
INSERT INTO ResRoleSkillLevels_adminL VALUES(1, 7);
INSERT INTO ResRoleSkillLevels_adminL VALUES(1, 8);

INSERT INTO ResRoleSkillLevels_storageL VALUES(1, 9);
INSERT INTO ResRoleSkillLevels_storageL VALUES(1, 10);
INSERT INTO ResRoleSkillLevels_storageL VALUES(1, 11);
INSERT INTO ResRoleSkillLevels_storageL VALUES(1, 12);
INSERT INTO ResRoleSkillLevels_storageL VALUES(1, 13);
INSERT INTO ResRoleSkillLevels_storageL VALUES(1, 14);

INSERT INTO  ResRoleSkillLevels_supportL VALUES(1, 15);
INSERT INTO  ResRoleSkillLevels_supportL VALUES(1, 16);

INSERT INTO ResRoleSkillLevels_vmwareL VALUES(1, 17);
INSERT INTO ResRoleSkillLevels_vmwareL VALUES(1, 18);
INSERT INTO ResRoleSkillLevels_vmwareL VALUES(1, 19);

INSERT INTO ResidencyRequestData VALUES(1, 1, 'New York', 'conditions', 1, 1, TO_DATE('2014-05-14','YYYY-MM-DD'), 10, 'general comment', 1);
INSERT INTO ResidencyRequestData VALUES(2, 2, 'Chicago', 'conditions', 2, 2, TO_DATE('2014-05-14','YYYY-MM-DD'), 20, 'general comment', null);
INSERT INTO ResidencyRequestData VALUES(3, 3, 'Washington', 'conditions', 3, 3, TO_DATE('2014-05-14','YYYY-MM-DD'), 30, 'general comment', null);

INSERT INTO SourceOneFeatures VALUES(1, true, true, true, true, true, true, true);
INSERT INTO SourceOneFeatures VALUES(2, false, false, false, false, false, false, false);
INSERT INTO SourceOneFeatures VALUES(3, true, true, true, true, true, true, true);

INSERT INTO SourceOneDROptions VALUES(1, true, true, true);
INSERT INTO SourceOneDROptions VALUES(2, false, false, false);
INSERT INTO SourceOneDROptions VALUES(3, true, true, true);

INSERT INTO SourceOneDesignImpl VALUES(1, 1.11, 10, true, true, 1, 1, true, true, true, true, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100, 110, 120, 130, 140, 150, 160, 170, 180, 190, 200);
INSERT INTO SourceOneDesignImpl VALUES(2, 2.22, 10, true, true, 2, 2, true, true, true, true, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100, 110, 120, 130, 140, 150, 160, 170, 180, 190, 200);
INSERT INTO SourceOneDesignImpl VALUES(3, 3.33, 10, true, true, 3, 3, true, true, true, true, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100, 110, 120, 130, 140, 150, 160, 170, 180, 190, 200);

INSERT INTO SourceOneUpgrade VALUES(1, 1.11, '6.5', '6.82', 10, 20, 30);
INSERT INTO SourceOneUpgrade VALUES(2, 2.22, '6.5', '6.82', 10, 20, 30);
INSERT INTO SourceOneUpgrade VALUES(3, 3.33, '6.5', '6.82', 10, 20, 30);

INSERT INTO SourceOneMigration VALUES(1, 1.11, 10, 20, 30);
INSERT INTO SourceOneMigration VALUES(2, 2.22, 10, 20, 30);
INSERT INTO SourceOneMigration VALUES(3, 3.33, 10, 20, 30);

INSERT INTO SourceOneHealthCheck VALUES(1, 1.11, 10, 20, 30, 40);
INSERT INTO SourceOneHealthCheck VALUES(2, 2.22, 10, 20, 30, 40);
INSERT INTO SourceOneHealthCheck VALUES(3, 3.33, 10, 20, 30, 40);

INSERT INTO SourceOneServicesScope VALUES(1, true, true, true, true);
INSERT INTO SourceOneServicesScope VALUES(2, false, false, false, false);
INSERT INTO SourceOneServicesScope VALUES(3, true, true, true, true);

INSERT INTO SourceOneRequestData VALUES(1, 1, 1, 1, 1, 1, 10, 'general comment');
INSERT INTO SourceOneRequestData VALUES(2, 2, 2, 2, 2, 2, 20, 'general comment');
INSERT INTO SourceOneRequestData VALUES(3, 3, 3, 3, 3, 3, 30, 'general comment');

INSERT INTO ASDAppSync VALUES(1, true, 10, 10, 10, 10, 10, 10, 10.10);
INSERT INTO ASDAppSync VALUES(2, true, 20, 20, 20, 20, 20, 20, 20.20);
INSERT INTO ASDAppSync VALUES(3, true, 30, 30, 30, 30, 30, 30, 30.30);

INSERT INTO ASDUIM VALUES(1, 3, 3, true, 10, 10, 10, true, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, true, 10, 10, true, 10, 10, 10, true, 10.10, 10.10, 10.10);
INSERT INTO ASDUIM VALUES(2, 2, 2, true, 20, 20, 20, true, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, true, 20, 20, true, 20, 20, 20, true, 20.20, 20.20, 20.20);
INSERT INTO ASDUIM VALUES(3, 1, 1, true, 30, 30, 30, true, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, true, 30, 30, true, 30, 30, 30, true, 30.30, 30.30, 30.30);

INSERT INTO ASDServicesScope VALUES(1, true, true, true);
INSERT INTO ASDServicesScope VALUES(2, true, true, true);
INSERT INTO ASDServicesScope VALUES(3, true, true, true);

INSERT INTO ASDRequestData VALUES(1, 1, 1, 1, 'general comment');
INSERT INTO ASDRequestData VALUES(2, 2, 2, 2, 'general comment');
INSERT INTO ASDRequestData VALUES(3, 3, 3, 3, 'general comment');

INSERT INTO HealthCheckAvamar VALUES(1, 10, 10);
INSERT INTO HealthCheckAvamar VALUES(2, 20, 20);
INSERT INTO HealthCheckAvamar VALUES(3, 30, 30);

INSERT INTO HealthCheckDataDomain VALUES(1, 10, 10);
INSERT INTO HealthCheckDataDomain VALUES(2, 20, 20);
INSERT INTO HealthCheckDataDomain VALUES(3, 30, 30);

INSERT INTO HealthCheckDPA VALUES(1, 10);
INSERT INTO HealthCheckDPA VALUES(2, 20);
INSERT INTO HealthCheckDPA VALUES(3, 30);

INSERT INTO HealthCheckDLM VALUES(1, 10, 10);
INSERT INTO HealthCheckDLM VALUES(2, 20, 20);
INSERT INTO HealthCheckDLM VALUES(3, 30, 30);

INSERT INTO HealthCheckGreenPlum VALUES(1, 10);
INSERT INTO HealthCheckGreenPlum VALUES(2, 20);
INSERT INTO HealthCheckGreenPlum VALUES(3, 30);

INSERT INTO HealthCheckIonix VALUES(1, true, 0);
INSERT INTO HealthCheckIonix VALUES(2, true, 1);
INSERT INTO HealthCheckIonix VALUES(3, true, 2);

INSERT INTO HealthCheckNetWorker VALUES(1, true, 10, 10);
INSERT INTO HealthCheckNetWorker VALUES(2, true, 20, 20);
INSERT INTO HealthCheckNetWorker VALUES(3, true, 30, 30);

INSERT INTO HealthCheckSanSecurity VALUES(1, 10, 10, 10, 10, 10);
INSERT INTO HealthCheckSanSecurity VALUES(2, 20, 20, 20, 20, 20);
INSERT INTO HealthCheckSanSecurity VALUES(3, 30, 30, 30, 30, 30);

INSERT INTO HealthCheckSAP VALUES(1, 10, 10);
INSERT INTO HealthCheckSAP VALUES(2, 20, 20);
INSERT INTO HealthCheckSAP VALUES(3, 30, 30);

INSERT INTO HealthCheckSourceOne VALUES(1, 10, 10);
INSERT INTO HealthCheckSourceOne VALUES(2, 20, 20);
INSERT INTO HealthCheckSourceOne VALUES(3, 30, 30);

INSERT INTO HealthCheckSymmetrixVmax VALUES(1, 10, 10);
INSERT INTO HealthCheckSymmetrixVmax VALUES(2, 20, 20);
INSERT INTO HealthCheckSymmetrixVmax VALUES(3, 30, 30);

INSERT INTO HealthCheckSymVmaxStorageRep VALUES(1, true, true, 10, 10, 10, 10, 10);
INSERT INTO HealthCheckSymVmaxStorageRep VALUES(2, true, true, 20, 20, 20, 20, 20);
INSERT INTO HealthCheckSymVmaxStorageRep VALUES(3, true, true, 30, 30, 30, 30, 30);

INSERT INTO HealthCheckUnified VALUES(1, 1, 10, 10, 10);
INSERT INTO HealthCheckUnified VALUES(2, 2, 20, 20, 20);
INSERT INTO HealthCheckUnified VALUES(3, 1, 30, 30, 30);

INSERT INTO HealthCheckVblock VALUES(1, true, true, true, true, 10, 10, 10);
INSERT INTO HealthCheckVblock VALUES(2, true, true, true, true, 20, 20, 20);
INSERT INTO HealthCheckVblock VALUES(3, true, true, true, true, 30, 30, 30);

INSERT INTO HealthCheckVmwareVirtualInf VALUES(1, true, 10, 10, 10);
INSERT INTO HealthCheckVmwareVirtualInf VALUES(2, true, 20, 20, 20);
INSERT INTO HealthCheckVmwareVirtualInf VALUES(3, true, 30, 30, 30);

INSERT INTO HealthCheckVplex VALUES(1, 10, 10);
INSERT INTO HealthCheckVplex VALUES(2, 20, 20);
INSERT INTO HealthCheckVplex VALUES(3, 30, 30);

INSERT INTO HealthCheckServicesScope VALUES(1, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true);
INSERT INTO HealthCheckServicesScope VALUES(2, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true);
INSERT INTO HealthCheckServicesScope VALUES(3, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true);

INSERT INTO HealthCheckRequestData VALUES(1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 'general comment');
INSERT INTO HealthCheckRequestData VALUES(2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 'general comment');
INSERT INTO HealthCheckRequestData VALUES(3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 'general comment');

INSERT INTO ViprImplementation VALUES(1, true, 10, true, true, true, true, true, true, true, true, true, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, true, true, 12.34, null, null, null, null, null, null, null, null);
INSERT INTO ViprImplementation VALUES(2, true, 10, true, true, true, true, true, true, true, true, true, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, true, true, 12.34, null, null, null, null, null, null, null, null);

INSERT INTO ViprRequestData VALUES(1, 12.34, 'general comment', false, false, false, false, 1, null, null, null);
INSERT INTO ViprRequestData VALUES(2, 12.34, 'general comment', false, false, false, false, 2, null, null, null);

INSERT INTO IsilonClusterRelocation VALUES(1, 10, 10, 10, 10);
INSERT INTO IsilonClusterRelocation VALUES(2, 10, 10, 10, 10);

INSERT INTO IsilonDesignAndImpl VALUES(1, true, true, true, 10, 10, 10, 10, 10, 10, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true);
INSERT INTO IsilonDesignAndImpl VALUES(2, true, true, true, 10, 10, 10, 10, 10, 10, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true);

INSERT INTO IsilonHardwareUpgrade VALUES(1, true, 10);
INSERT INTO IsilonHardwareUpgrade VALUES(2, true, 10);

INSERT INTO IsilonMigration VALUES(1, true, true, true, true, true, true, true, true, true, true, true, true, true, 10, true, 10, 10, 12.34, 10, 10, 10, true, 10, 10, 10);
INSERT INTO IsilonMigration VALUES(2, true, true, true, true, true, true, true, true, true, true, true, true, true, 10, true, 10, 10, 12.34, 10, 10, 10, true, 10, 10, 10);

INSERT INTO IsilonServicesScope VALUES(1, true, true, true, true, true);
INSERT INTO IsilonServicesScope VALUES(2, true, true, true, true, true);

INSERT INTO IsilonRequestData VALUES(1, 12.34, 'general comment', 1, 1, 1, 1, 1);
INSERT INTO IsilonRequestData VALUES(2, 12.34, 'general comment', 2, 2, 2, 2, 2);

INSERT INTO VblockProject VALUES(1, 'description');
INSERT INTO VblockProject VALUES(2, 'description');

INSERT INTO VblockTechAssessment VALUES(1, 10, 10);
INSERT INTO VblockTechAssessment VALUES(2, 10, 10);

INSERT INTO VblockInfrastructure VALUES(1, 10, 10);
INSERT INTO VblockInfrastructure VALUES(2, 10, 10);

INSERT INTO VblockDesignImpl VALUES(1, true, true, 10, 10, true, true, 10, 10, 12.34, 12.34, 1, 2, 3, 4);
INSERT INTO VblockDesignImpl VALUES(2, true, true, 10, 10, true, true, 10, 10, 12.34, 12.34, 10, 20, 30, 30);

INSERT INTO VblockServices VALUES(1, true, true, true);
INSERT INTO VblockServices VALUES(2, true, true, true);

INSERT INTO VblockRequestData VALUES(1, 'describe options', 'general comment', 1, 1, 1, 1, 1);
INSERT INTO VblockRequestData VALUES(2, 'describe options', 'general comment', 2, 2, 2, 2, 2);

INSERT INTO AtmosDesignImpl VALUES(1, true, 10, 10, 10, true, 10, 10, 10, 10, 10, 10, 10, 10, true);
INSERT INTO AtmosDesignImpl VALUES(2, true, 10, 10, 10, true, 10, 10, 10, 10, 10, 10, 10, 10, true);

INSERT INTO CenteraToAtmosMigration VALUES(1, 10, 0, 10);
INSERT INTO CenteraToAtmosMigration VALUES(2, 10, 0, 10);

INSERT INTO CenteraFileErasure VALUES(1, 10);
INSERT INTO CenteraFileErasure VALUES(2, 10);

INSERT INTO CenteraUniversalAccess VALUES(1, 6, 10, 6, 1, 6);
INSERT INTO CenteraUniversalAccess VALUES(2, 6, 10, 6, 1, 6);

INSERT INTO CenteraIntraClusterMigration VALUES(1, 10, 10, 10, 10, true);
INSERT INTO CenteraIntraClusterMigration VALUES(2, 10, 10, 10, 10, true);

INSERT INTO ExpansionNodeOnly VALUES(1, 10);
INSERT INTO ExpansionNodeOnly VALUES(2, 10);

INSERT INTO ExistingCenteraCluster VALUES(1, 'location', 'serial number', 'modem number', 1, 1, 1, 'New 1', 'Existing 2', 'New 2', true, 'applications writting', 2, true, true, true);
INSERT INTO ExistingCenteraCluster VALUES(2, 'location', 'serial number', 'modem number', 1, 1, 1, 'New 2', 'Existing 1', 'New 1', true, 'applications writting', 3, true, true, true);

INSERT INTO NewCenteraCluster VALUES(1, 'location', 1, 1, 1, 10, 'New 2', 'Existing 1', true, true, 'applications writting');
INSERT INTO NewCenteraCluster VALUES(2, 'location', 1, 1, 1, 10, 'New 1', 'Existing 2', true, true, 'applications writting');

INSERT INTO CenteraDesignImpl VALUES(1, true, true, 'existing centeras review detail', 'hardware repurposing detail', 'array relocation detail', 2, true, 'develop code detail', true, 'custom scripting detail', 'expected timeline', 1, true);
INSERT INTO CenteraDesignImpl VALUES(2, true, true, 'existing centeras review detail', 'hardware repurposing detail', 'array relocation detail', 2, true, 'develop code detail', true, 'custom scripting detail', 'expected timeline', 1, true);

INSERT INTO CenteraDesignImpl_exClusters VALUES(1, 1);
INSERT INTO CenteraDesignImpl_exClusters VALUES(1, 2);

INSERT INTO CenteraDesignImpl_newClusters VALUES(1, 1);
INSERT INTO CenteraDesignImpl_newClusters VALUES(1, 2);

INSERT INTO AtmosCenteraServicesScope VALUES(1, true, true, true, true, true, true, true, true, true);
INSERT INTO AtmosCenteraServicesScope VALUES(2, true, true, true, true, true, true, true, true, true);

INSERT INTO AtmosCenteraRequestData VALUES(1, true, 1, 12.34, true, 'general comment', 1, 1, 1, 1, 1, 1, 1, 1);
INSERT INTO AtmosCenteraRequestData VALUES(2, true, 1, 12.34, true, 'general comment', 2, 2, 2, 2, 2, 2, 2, 2);

INSERT INTO VMwareAssessment VALUES(1, 0, true, true, true, 10, 10, 10, 10, 10);
INSERT INTO VMwareAssessment VALUES(2, 0, true, true, true, 10, 10, 10, 10, 10);

INSERT INTO VMwareBackupRecovery VALUES(1, 10, 10, 10, 10);
INSERT INTO VMwareBackupRecovery VALUES(2, 10, 10, 10, 10);

INSERT INTO VMwareHealthChecks VALUES(1, true, 10, 10, 10);
INSERT INTO VMwareHealthChecks VALUES(2, true, 10, 10, 10);

INSERT INTO VMwareReplication VALUES(1, true, true, 10, 10, true, true, true, true, 10, 10, 10, 10, 10, 10, 10, 10);
INSERT INTO VMwareReplication VALUES(2, true, true, 10, 10, true, true, true, true, 10, 10, 10, 10, 10, 10, 10, 10);

INSERT INTO VMwareTCOAssessment VALUES(1, 0, 10, 10);
INSERT INTO VMwareTCOAssessment VALUES(2, 0, 10, 10);

INSERT INTO VMwareVblockDesignImpl VALUES(1, true, true, true, 12.34, 12.34, true, true, true, true, 10, 10, 10, 10, 10, 10, 10, 10);
INSERT INTO VMwareVblockDesignImpl VALUES(2, true, true, true, 12.34, 12.34, true, true, true, true, 10, 10, 10, 10, 10, 10, 10, 10);

INSERT INTO VMwareVblockInfraImpl VALUES(1, 10, 10);
INSERT INTO VMwareVblockInfraImpl VALUES(2, 10, 10);

INSERT INTO VMwareVblockInfraTechAss VALUES(1, 10, 10);
INSERT INTO VMwareVblockInfraTechAss VALUES(2, 10, 10);

INSERT INTO VMwareVblock VALUES(1, true, true, true, 1, 1, 1);
INSERT INTO VMwareVblock VALUES(2, true, true, true, 2, 2, 2);

INSERT INTO VMwareConverter VALUES(1, true, true, 10, 10, 12.34, 12.34, 12.34);
INSERT INTO VMwareConverter VALUES(2, true, true, 10, 10, 12.34, 12.34, 12.34);

INSERT INTO VMwareSvMotion VALUES(1, true, 10, 12.34);
INSERT INTO VMwareSvMotion VALUES(2, true, 10, 12.34);

INSERT INTO VMwareViewDesign VALUES(1, true, true, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10);
INSERT INTO VMwareViewDesign VALUES(2, true, true, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10);

INSERT INTO VMwareViewImpl VALUES(1, true, true, 10, 10, 10, 10, 10, 10, 10, 10, 10, 12.34);
INSERT INTO VMwareViewImpl VALUES(2, true, true, 10, 10, 10, 10, 10, 10, 10, 10, 10, 12.34);

INSERT INTO VMwareView VALUES(1, true, true, 1, 1);
INSERT INTO VMwareView VALUES(2, true, true, 2, 2);

INSERT INTO VMwareVirtualInfra VALUES(1, true, true, true, true, true, 10, 10, 10, true, 10, 10, 10, 10, 10, 10, 12.34, 10, 10, 10);
INSERT INTO VMwareVirtualInfra VALUES(2, true, true, true, true, true, 10, 10, 10, true, 10, 10, 10, 10, 10, 10, 12.34, 10, 10, 10);

INSERT INTO VMwareVSphere VALUES(1, true, true, 12.34, 10, 10, 10);
INSERT INTO VMwareVSphere VALUES(2, true, true, 12.34, 10, 10, 10);

INSERT INTO VMwareServicesScope VALUES(1, true, true, true, true, true, true, true, true, true, true, true);
INSERT INTO VMwareServicesScope VALUES(2, true, true, true, true, true, true, true, true, true, true, true);

INSERT INTO VMwareRequestData VALUES(1, 'general comments', 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1);
INSERT INTO VMwareRequestData VALUES(2, 'general comments', 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2);

INSERT INTO RecoverPoint VALUES(1, false, false, false, null, null, null);
INSERT INTO RecoverPoint VALUES(2, false, false, false, null, null, null);

INSERT INTO EDLDesignImpl VALUES(1, true, true, true, true, 10, 10, 10, 10, 10, 10, 10);
INSERT INTO EDLDesignImpl VALUES(2, true, true, true, true, 10, 10, 10, 10, 10, 10, 10);

INSERT INTO EDL VALUES(1, 12.34, true, true, 1);
INSERT INTO EDL VALUES(2, 12.34, true, true, 2);

INSERT INTO AvamarOptions VALUES(1, true, true, true, true, true, true, true, true, true);
INSERT INTO AvamarOptions VALUES(2, true, true, true, true, true, true, true, true, true);
INSERT INTO AvamarOptions VALUES(3, true, true, true, true, true, true, true, true, true);
INSERT INTO AvamarOptions VALUES(4, true, true, true, true, true, true, true, true, true);

INSERT INTO AvamarPlugins VALUES(1, true, true, true, true, true, true, 10, 10, 10, 10, 10, 10);
INSERT INTO AvamarPlugins VALUES(2, true, true, true, true, true, true, 10, 10, 10, 10, 10, 10);
INSERT INTO AvamarPlugins VALUES(3, true, true, true, true, true, true, 10, 10, 10, 10, 10, 10);
INSERT INTO AvamarPlugins VALUES(4, true, true, true, true, true, true, 10, 10, 10, 10, 10, 10);

INSERT INTO AvamarNDMP VALUES(1, true, true, true, true, 10, true, 10, 10, 10, 10, 10, 12.34);
INSERT INTO AvamarNDMP VALUES(2, true, true, true, true, 10, true, 10, 10, 10, 10, 10, 12.34);

INSERT INTO AvamarDesign VALUES(1, 1, 1, 10, 10, 10, 10, 10, 10, 10);
INSERT INTO AvamarDesign VALUES(2, 2, 2, 10, 10, 10, 10, 10, 10, 10);

INSERT INTO AvamarImplementation VALUES(1, 3, 3, 10, 10, 10, 10, 12.34, true, true, 10, 12.34, 0, 0, 12.34, 1, 10, 10, 10, 10);
INSERT INTO AvamarImplementation VALUES(2, 4, 4, 10, 10, 10, 10, 12.34, true, true, 10, 12.34, 0, 0, 12.34, 2, 10, 10, 10, 10);

INSERT INTO AvamarTapeOutDesign VALUES(1, true, 10, 10, 10);
INSERT INTO AvamarTapeOutDesign VALUES(2, true, 10, 10, 10);

INSERT INTO AvamarTapeOutImplementation VALUES(1, 0, 10, 10, 10, 10, 10, 10);
INSERT INTO AvamarTapeOutImplementation VALUES(2, 0, 10, 10, 10, 10, 10, 10);

INSERT INTO AvamarOperationalAssurance VALUES(1, true, true, true, 10, 10);
INSERT INTO AvamarOperationalAssurance VALUES(2, true, true, true, 10, 10);

INSERT INTO AvamarHealthCheck VALUES(1, 10, 10);
INSERT INTO AvamarHealthCheck VALUES(2, 10, 10);

INSERT INTO AvamarMigration VALUES(1, 0, true, true, 10, 10, 10, 10);
INSERT INTO AvamarMigration VALUES(2, 0, true, true, 10, 10, 10, 10);

INSERT INTO AvamarIntegration VALUES(1, true, true, 10, 10, true, 10);
INSERT INTO AvamarIntegration VALUES(2, true, true, 10, 10, true, 10);

INSERT INTO Avamar VALUES(1, 12.34, true, true, true, true, true, true, true, 1, true, true, 1, 1, 1, 1, 1, 1, 1, 1);
INSERT INTO Avamar VALUES(2, 12.34, true, true, true, true, true, true, true, 2, true, true, 2, 2, 2, 2, 2, 2, 2, 2);

INSERT INTO DataDomainDesign (id) VALUES(1);
INSERT INTO DataDomainDesign (id) VALUES(2);

INSERT INTO DataDomainDesignAppModel VALUES(1, 'DD160', 10);
INSERT INTO DataDomainDesignAppModel VALUES(2, 'DD620', 10);

INSERT INTO DataDomainDesign_appModels VALUES(1, 1);
INSERT INTO DataDomainDesign_appModels VALUES(1, 2);

INSERT INTO DataDomainBoostBackupServer VALUES(1, true, true);
INSERT INTO DataDomainBoostBackupServer VALUES(2, true, true);
INSERT INTO DataDomainBoostBackupServer VALUES(3, true, true);
INSERT INTO DataDomainBoostBackupServer VALUES(4, true, true);

INSERT INTO DataDomainImplementation VALUES(1, 1, true, true, true, 10, 10, 10, 10, 10, 10, 10, 10, 10);
INSERT INTO DataDomainImplementation VALUES(2, 2, true, true, true, 10, 10, 10, 10, 10, 10, 10, 10, 10);

INSERT INTO DataDomainImplApplianceModel VALUES(1, 'DD160', 10, 10, true, 3, true, true, 10, 10);
INSERT INTO DataDomainImplApplianceModel VALUES(2, 'DD620', 10, 10, true, 4, true, true, 10, 10);

INSERT INTO DataDomainImpl_appModels VALUES(1, 1);
INSERT INTO DataDomainImpl_appModels VALUES(1, 2);

INSERT INTO DataDomainUpgrade VALUES(1, 1, 10, true, 10, true, 10, true, 10, true, 10, true, 10, 10, 10);
INSERT INTO DataDomainUpgrade VALUES(2, 2, 10, true, 10, true, 10, true, 10, true, 10, true, 10, 10, 10);

INSERT INTO DataDomainVTL VALUES(1, true, 10, 10, 10, 10);
INSERT INTO DataDomainVTL VALUES(2, true, 10, 10, 10, 10);

INSERT INTO DataDomainExpansionShelf VALUES(1, 10);
INSERT INTO DataDomainExpansionShelf VALUES(2, 10);

INSERT INTO DataDomainDataStaging VALUES(1, 1);
INSERT INTO DataDomainDataStaging VALUES(2, 2);

INSERT INTO DataDomainIntegration VALUES(1, true, 1, 10, 10, 10, 10, 1, true, true, true, true, 10, 10, 10, 10, 10, 10);
INSERT INTO DataDomainIntegration VALUES(2, true, 2, 10, 10, 10, 10, 2, true, true, true, true, 10, 10, 10, 10, 10, 10);

INSERT INTO DataDomainHealthCheck VALUES(1, 10, 10);
INSERT INTO DataDomainHealthCheck VALUES(2, 10, 10);

INSERT INTO DataDomainMigration VALUES(1, 1, 10, 10, 10);
INSERT INTO DataDomainMigration VALUES(2, 2, 10, 10, 10);

INSERT INTO DataDomainPreRack VALUES(1, 3, true, true, true, 10, 10, 10, 10, 10, 10, 10, 10, 10, 1, 10, 10, 10);
INSERT INTO DataDomainPreRack VALUES(2, 4, true, true, true, 10, 10, 10, 10, 10, 10, 10, 10, 10, 2, 10, 10, 10);

INSERT INTO DataDomainBoost VALUES(1, true, 1, 10, 10, 10, 10, 1);
INSERT INTO DataDomainBoost VALUES(2, true, 2, 10, 10, 10, 10, 2);

INSERT INTO DataDomainExtRetentionConv VALUES(1, 10);
INSERT INTO DataDomainExtRetentionConv VALUES(2, 10);

INSERT INTO DataDomainManCenterConf VALUES(1, 0);
INSERT INTO DataDomainManCenterConf VALUES(2, 1);

INSERT INTO DataDomainSapHana VALUES(1, 10);
INSERT INTO DataDomainSapHana VALUES(2, 10);

INSERT INTO DataDomain VALUES(1, 12.34, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, false, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, null);
INSERT INTO DataDomain VALUES(2, 12.34, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, false, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, null);

INSERT INTO DPADesign VALUES(1, true, true, true, true, true, true, 10, 10);
INSERT INTO DPADesign VALUES(2, true, true, true, true, true, true, 10, 10);

INSERT INTO DPAImplementation VALUES(1, true, true, true, true, true, true, true, 10, 10, 10, true, true, 10, 10, 10, true, true, 10, 10, 10, true, true, 10, 10, 10, 10, true, true, 10, 10, 10, 10);
INSERT INTO DPAImplementation VALUES(2, true, true, true, true, true, true, true, 10, 10, 10, true, true, 10, 10, 10, true, true, 10, 10, 10, true, true, 10, 10, 10, 10, true, true, 10, 10, 10, 10);

INSERT INTO DPAOperationalAssurance VALUES(1, true, 10);
INSERT INTO DPAOperationalAssurance VALUES(2, true, 10);

INSERT INTO DPACustomization VALUES(1, true, true, true, true, true, true, 10, 10, true, true, 10, 10, 10, true, true, 10, 10, true, true, 10, 10);
INSERT INTO DPACustomization VALUES(2, true, true, true, true, true, true, 10, 10, true, true, 10, 10, 10, true, true, 10, 10, true, true, 10, 10);

INSERT INTO DPAUpgradeMigration VALUES(1, 0, true, true, 10, 10);
INSERT INTO DPAUpgradeMigration VALUES(2, 0, true, true, 10, 10);

INSERT INTO DPAHealthCheck VALUES(1, 10);
INSERT INTO DPAHealthCheck VALUES(2, 10);

INSERT INTO DPA VALUES(1, 12.34, true, true, true, true, true, true, true, 1, 1, 1, 1, 1, 1);
INSERT INTO DPA VALUES(2, 12.34, true, true, true, true, true, true, true, 2, 2, 2, 2, 2, 2);

INSERT INTO NetworkerComponents VALUES(1, true, true, true, true, true, true, true);
INSERT INTO NetworkerComponents VALUES(2, true, true, true, true, true, true, true);
INSERT INTO NetworkerComponents VALUES(3, true, true, true, true, true, true, true);
INSERT INTO NetworkerComponents VALUES(4, true, true, true, true, true, true, true);

INSERT INTO NetworkerStorageNodes VALUES(1, true, true, true, 10, 10, 10);
INSERT INTO NetworkerStorageNodes VALUES(2, true, true, true, 10, 10, 10);
INSERT INTO NetworkerStorageNodes VALUES(3, true, true, true, 10, 10, 10);
INSERT INTO NetworkerStorageNodes VALUES(4, true, true, true, 10, 10, 10);

INSERT INTO NetworkerMediaDevices VALUES(1, true, true, true, true, true, 10, 10, 10, 10, 10);
INSERT INTO NetworkerMediaDevices VALUES(2, true, true, true, true, true, 10, 10, 10, 10, 10);
INSERT INTO NetworkerMediaDevices VALUES(3, true, true, true, true, true, 10, 10, 10, 10, 10);
INSERT INTO NetworkerMediaDevices VALUES(4, true, true, true, true, true, 10, 10, 10, 10, 10);

INSERT INTO NetworkerServerDesign VALUES(1, 0, 10);
INSERT INTO NetworkerServerDesign VALUES(2, 0, 10);

INSERT INTO NetAdvancedBackupTechDesign VALUES(1, true, true, true, true, true, 10, 10, 10, 10, 10);
INSERT INTO NetAdvancedBackupTechDesign VALUES(2, true, true, true, true, true, 10, 10, 10, 10, 10);

INSERT INTO NetFileSystemClientBackDesign VALUES(1, 10, 10);
INSERT INTO NetFileSystemClientBackDesign VALUES(2, 10, 10);

INSERT INTO NetApplicationBackDesign VALUES(1, true, true, true, true, true, true, true, true, true, true, 10, true, true, 10, 10, true, true, true, 10, 10, 10, 10, 10, true, 10, true, 10, 10, true, 10, true, 10, true, 10, 10, true, 10, true, true, 1, 1, 2);
INSERT INTO NetApplicationBackDesign VALUES(2, true, true, true, true, true, true, true, true, true, true, 10, true, true, 10, 10, true, true, true, 10, 10, 10, 10, 10, true, 10, true, 10, 10, true, 10, true, 10, true, 10, 10, true, 10, true, true, 2, 2, 2);

INSERT INTO NetworkerDesign VALUES(1, 1, 1, 1, 1, 1, 1, 1);
INSERT INTO NetworkerDesign VALUES(2, 2, 2, 2, 2, 2, 2, 2);

INSERT INTO NetworkerServerImpl VALUES(1, 0, 10, 10);
INSERT INTO NetworkerServerImpl VALUES(2, 0, 10, 10);

INSERT INTO NetAdvancedBackupTechImpl VALUES(1, true, true, true, true, true, 10, 10, 10, 10, 10, 10, 10, 10);
INSERT INTO NetAdvancedBackupTechImpl VALUES(2, true, true, true, true, true, 10, 10, 10, 10, 10, 10, 10, 10);

INSERT INTO NetFileSystemClientBackImpl VALUES(1, 10, 10, true);
INSERT INTO NetFileSystemClientBackImpl VALUES(2, 10, 10, true);

INSERT INTO NetApplicationBackImpl VALUES(1, true, true, true, true, true, true, true, true, true, 10, true, true, 10, 10, true, true, true, 10, 10, 10, 10, 10, true, 10, true, 10, 10, true, 10, true, 10, true, 10, true, 10, 10, true, 10, 10, 10, 10, true, 10, 10, 10, true, 10, true, 10, 10, 10, 10, 10, 10);
INSERT INTO NetApplicationBackImpl VALUES(2, true, true, true, true, true, true, true, true, true, 10, true, true, 10, 10, true, true, true, 10, 10, 10, 10, 10, true, 10, true, 10, 10, true, 10, true, 10, true, 10, true, 10, 10, true, 10, 10, 10, 10, true, 10, 10, 10, true, 10, true, 10, 10, 10, 10, 10, 10);

INSERT INTO NetworkerImplementation VALUES(1, true, 1);
INSERT INTO NetworkerImplementation VALUES(2, false, null);

INSERT INTO NetworkerUpgrade VALUES(1, true, true, true, true, 0, 0, true, 10, 10, 10, 10);
INSERT INTO NetworkerUpgrade VALUES(2, true, true, true, true, 0, 0, true, 10, 10, 10, 10);

INSERT INTO NetworkerHealthcheck VALUES(1, true, 3, 5);
INSERT INTO NetworkerHealthcheck VALUES(2, false, 0, 10);

INSERT INTO Networker VALUES(1, 12.34, true, true, true, true, true, true, 1, 1, 1, 1);
INSERT INTO Networker VALUES(2, 12.34, true, true, true, true, true, true, 2, 2, 2, 2);

INSERT INTO DPADServicesScope VALUES(1, true, true, true, true, true, true, true, false);
INSERT INTO DPADServicesScope VALUES(2, true, true, true, true, true, true, true, false);

INSERT INTO DPADRequestData VALUES(1, 'More Than 4', 'general comments', 1, 1, 1, 1, 1, 1, 1, null);
INSERT INTO DPADRequestData VALUES(2, 'More Than 4', 'general comments', 2, 2, 2, 2, 2, 2, 2, null);

INSERT INTO coreoptions VALUES(1, true, true, true, true, true, true, true, true, true, true, true, true);
INSERT INTO coreoptions VALUES(2, false, false, false, false, false, false, false, false, false, false, false, false);
INSERT INTO coreoptions VALUES(3, true, false, true, false, true, true, true, true, true, true, true, true);

INSERT INTO affinityoptions VALUES(1, true, false, false, true, true);
INSERT INTO affinityoptions VALUES(2, false, true, false, false, false);
INSERT INTO affinityoptions VALUES(3, true, false, true, false, true);

INSERT INTO ConsultingOptions VALUES(1, true, false, false, true, true);
INSERT INTO ConsultingOptions VALUES(2, false, true, false, false, false);
INSERT INTO ConsultingOptions VALUES(3, true, false, true, false, true);

INSERT INTO otherrequestoptions VALUES(1, true, false, true, true, true, false);
INSERT INTO otherrequestoptions VALUES(2, false, true, false, false, false, false);
INSERT INTO otherrequestoptions VALUES(3, true, false, true, false, true, false);

INSERT INTO dpadoptions VALUES(1, true, true, true, true, true, true, true, true, true);
INSERT INTO dpadoptions VALUES(2, false, true, true, false, true, true, true, true, true);
INSERT INTO dpadoptions VALUES(3, true, true, false, true, true, true, true, true, true);

INSERT INTO asdoptions VALUES(1, true, true, true, true, true, true, true, true);
INSERT INTO asdoptions VALUES(2, false, false, true, false, true, false, false, false);
INSERT INTO asdoptions VALUES(3, true, true, false, true, true, true, true, false);

INSERT INTO attachment VALUES(1, 'attachment_filename1', 'test.txt', 1002);
INSERT INTO attachment VALUES(2, 'attachment_filename2', 'test.txt', 300);
INSERT INTO attachment VALUES(3, 'attachment_filename3', 'test.txt', 4035);

INSERT INTO requestcontractdata VALUES(1, 1, true, 3, TO_DATE('2013-09-09 12:30:21','YYYY-MM-DD HH24:MI:SS'), 'partner_information1');
INSERT INTO requestcontractdata VALUES(2, 2, false, 3, TO_DATE('2013-09-09 12:30:21','YYYY-MM-DD HH24:MI:SS'), 'partner_information2');
INSERT INTO requestcontractdata VALUES(3, 2, true, 4, TO_DATE('2013-09-09 12:30:21','YYYY-MM-DD HH24:MI:SS'), 'partner_information3');

INSERT INTO EngagementTypeData VALUES(1, true, true, true, true, true, true, 53);
INSERT INTO EngagementTypeData VALUES(2, true, true, true, true, true, true, 53);

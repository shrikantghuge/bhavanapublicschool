/*
 * This code is copyright (c) 2014 EMC Corporation.
 */
package com.emc.gs.tools.srf.web;

import java.io.IOException;

import javax.annotation.PostConstruct;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import com.emc.gs.tools.srf.ServiceRequestToolConfigurationException;
import com.emc.gs.tools.srf.services.ProfileService;
import com.emc.gs.tools.srf.services.ServiceRequestToolException;
import com.emc.gs.tools.srf.services.impl.Helper;

/**
 * <p>
 * Interceptor used to check whether profile exists. If not redirect to profile page.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is effectively thread safe after configuration, the configuration is done
 * in a thread safe manner.
 * </p>
 * @author TCSASSEMBLER
 * @version 1.0
 * @since SRT Release Assembly - Unified Tab
 */
public class ProfileInterceptor extends HandlerInterceptorAdapter {

    /**
     * <p>
     * Represents the class name.
     * </p>
     */
    private static final String CLASSNAME = ProfileInterceptor.class.getName();

    /**
     * This is the logger used for logging. It is initialized in constructor and never changed afterwards. It can not be
     * null.
     */
    private final Logger logger;

    /**
     * Represents the ProfileService instance for retrieving email options of currently logged user. It is modified by
     * setter. It is injected by Spring. It can not be null after injected.
     */
    private ProfileService profileService;

    /**
     * Default constructor.
     */
    public ProfileInterceptor() {
        this.logger = Logger.getLogger(this.getClass());
    }

    /**
     * This method checks whether the instance of the class was initialized properly.
     *
     * @throws ServiceRequestToolConfigurationException
     *             if profileService is null
     */
    @PostConstruct
    protected void checkInit() {
        Helper.checkState(profileService == null, "'profileService' can't be null.");
    }

    /**
     * Check user profile exists.
     * @param request
     *            the {@link HttpServletRequest} instance
     * @param response
     *            the {@link HttpServletResponse} instance
     * @param handler
     *            the handler
     * @return true if user profile exists; otherwise redirect to profile page
     * @throws ServiceRequestToolException
     *             If any error occurs.
     */
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
            throws ServiceRequestToolException {
        final String signature = CLASSNAME
                + "#preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)";

        // Log entry
        Helper.logEntrance(logger, signature, new String[] {"request", "response", "handler"},
                new Object[] {request, response, handler});

        boolean result = false;

        if (profileService.getDefaultProfile() == null) {
            try {
                // Redirect to profile page
                response.sendRedirect(request.getContextPath() + "/profile");
            } catch (IOException e) {
                throw Helper.logException(logger, signature, new ServiceRequestToolException(
                        "Failed to redirect to create profile page", e));
            }
        } else {
            result = true;
        }

        // Log exit
        Helper.logExit(logger, signature, new Object[]{result});

        return result;
    }

    /**
     * Setter method for property <tt>profileService</tt>.
     * @param profileService
     *            value to be assigned to property profileService
     */
    public void setProfileService(ProfileService profileService) {
        this.profileService = profileService;
    }
}

/*
 * This code is copyright (c) 2013 - 2014 EMC Corporation.
 */
package com.emc.gs.tools.srf.web;

import java.io.IOException;

import javax.annotation.PostConstruct;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.handler.SimpleMappingExceptionResolver;

import com.emc.gs.tools.srf.AuthorizationException;
import com.emc.gs.tools.srf.ServiceRequestToolConfigurationException;
import com.emc.gs.tools.srf.services.AlreadySynchronizedException;
import com.emc.gs.tools.srf.services.EntityNotFoundException;
import com.emc.gs.tools.srf.services.impl.Helper;

/**
 * <p>
 * This class resolves exceptions thrown from AJAX requests and sets proper HTTP codes.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is immutable and thread safe.
 * </p>
 *
 * <p>
 * <strong>Changes V1.1:</strong>
 * <strong>SRT Phase 4 - ET Assembly 2</strong>
 * <ul>
 * <li>Add syncOpLogHeaderName field.</li>
 * <li>Change resolveException() method to be return different status code for
 * different exception type.</li>
 * </ul>
 * </p>
 *
 * <p>
 * <strong>Changes V1.2:</strong>
 * <strong>SRT Phase 4 - ET Assembly 3</strong>
 * <ul>
 * <li>Added ENTITY_NOT_FOUND_PREFIX to the error message for EntityNotFoundException.
 * This is used to differentiate it with the general 404 page not found error.
 * We need to do this, otherwise, it is quite likely the delete entities will not be synchronized up
 * when the cloud app just starts (during this period, it will return 404 for all the requests)</li>
 * </ul>
 * </p>
 *
 * @author faeton, TCSASSEMBLER
 * @version 1.2
 */
public class AJAXExceptionResolver extends SimpleMappingExceptionResolver {
    /**
     * <p>
     * Represents the class name.
     * </p>
     */
    private static final String CLASSNAME = AJAXExceptionResolver.class.getName();

    /**
     * This is the logger used for logging.
     *
     * It is initialized in constructor and never changed afterwards.
     *
     * It can not be null.
     */
    private final Logger logger;

    /**
     * This is HTTP header name of synchronizing operation log.
     * Not null, not empty.
     * @since SRT Phase 4 - ET Assembly 2
     */
    private String syncOpLogHeaderName;

    /**
     * This is the constructor of this class.
     */
    public AJAXExceptionResolver() {
        this.logger = Logger.getLogger(this.getClass());
    }

    /**
     * This methods resolves the exception and sets necessary HTTP code.
     *
     * @param response
     *            the http servlet response
     * @param exception
     *            the thrown exception
     * @param request
     *            the http servlet request
     * @param handler
     *            the handler object
     * @return The resulting ModelAndView object
     */
    @Override
    public ModelAndView resolveException(HttpServletRequest request, HttpServletResponse response, Object handler,
        Exception exception) {
        final String signature = CLASSNAME + "#resolveException(HttpServletRequest request,"
            + " HttpServletResponse response, Object handler, Exception exception)";

        // Log entry
        Helper.logEntrance(logger, signature, new String[] {"request", "response", "handler", "exception"},
            new Object[] {request, response, handler, exception});

        // Check whether this was an AJAX response.
        String requestWithHeader = request.getHeader("X-Requested-With");
        ModelAndView result = null;
        if (requestWithHeader != null && requestWithHeader.equals("XMLHttpRequest")) {
            try {
                if (exception instanceof IllegalArgumentException) {
                    response.sendError(HttpServletResponse.SC_BAD_REQUEST, exception.getMessage());
                } else if (exception instanceof AuthorizationException) {
                    response.sendError(HttpServletResponse.SC_FORBIDDEN, exception.getMessage());
                } else if (exception instanceof EntityNotFoundException) {
                    response.sendError(HttpServletResponse.SC_NOT_FOUND,
                            EntityNotFoundException.ENTITY_NOT_FOUND_PREFIX + exception.getMessage());
                } else if (exception instanceof AlreadySynchronizedException) {
                    response.setHeader(syncOpLogHeaderName, Helper.OBJECT_MAPPER
                            .writeValueAsString(((AlreadySynchronizedException) exception).getSynchronizedLog()));
                    response.sendError(HttpServletResponse.SC_CONFLICT, exception.getMessage());
                } else if (exception instanceof IOException) {
                    // Ignore and log
                    Helper.logException(logger, signature, exception);
                } else {
                    response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, exception.getMessage());
                }
            } catch (IOException e) {
                // Ignore
            }
            result = new ModelAndView();

        } else {
            result = super.resolveException(request, response, handler, exception);
        }

        // Log exit
        Helper.logExit(logger, signature, new Object[] {result});

        return result;
    }

    /**
     * Check if all required fields are initialized properly.
     *
     * @throws ServiceRequestToolConfigurationException
     *             if syncOpLogHeaderName is null or empty.
     * @since SRT Phase 4 - ET Assembly 2
     */
    @PostConstruct
    protected void checkInit() {
        Helper.checkState(Helper.isStringNullOrEmpty(syncOpLogHeaderName),
                "'syncOpLogHeaderName' can't be null/empty.");
    }

    /**
     * <p>
     * Sets the value to syncOpLogHeaderName field.
     * </p>
     *
     * @param syncOpLogHeaderName the syncOpLogHeaderName to set
     * @since SRT Phase 4 - ET Assembly 2
     */
    public void setSyncOpLogHeaderName(String syncOpLogHeaderName) {
        this.syncOpLogHeaderName = syncOpLogHeaderName;
    }
}

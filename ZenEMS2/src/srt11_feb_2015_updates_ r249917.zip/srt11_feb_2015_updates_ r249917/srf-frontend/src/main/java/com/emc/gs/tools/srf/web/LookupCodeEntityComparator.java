/*
 * This code is copyright (c) 2014 EMC Corporation.
 */
package com.emc.gs.tools.srf.web;

import com.emc.gs.tools.srf.model.LookupCodeEntity;

import java.util.Comparator;

/**
 * <p>This is LookupCodeEntityComparator class to be used for sorting the collections of {@link LookupCodeEntity}
 * objects.</p>
 *
 * <p><strong>Thread safety</strong>: This class is thread safe.</p>
 *
 * @author isv
 */
public class LookupCodeEntityComparator implements Comparator<LookupCodeEntity> {

    /**
     * <p>A <code>LookupCodeEntityComparator</code> to be used for comparing entities by IDs.</p>
     */
    public static final LookupCodeEntityComparator BY_ID = new LookupCodeEntityComparator(TYPE.ID);

    /**
     * <p>A <code>LookupCodeEntityComparator</code> to be used for comparing entities by names.</p>
     */
    public static final LookupCodeEntityComparator BY_NAME = new LookupCodeEntityComparator(TYPE.NAME);

    /**
     * <p>A <code>LookupCodeEntityComparator</code> to be used for comparing entities by codes.</p>
     */
    public static final LookupCodeEntityComparator BY_CODE = new LookupCodeEntityComparator(TYPE.CODE);
    
    /**
     * <p>An enumeration over possible types of comparison of entities.</p>
     */
    private enum TYPE {
        ID,
        
        NAME,
        
        CODE
    }

    /**
     * <p>A <code>TYPE</code> specifying the type of comparison.</p>
     */
    private TYPE comparisonType;

    /**
     * <p>Constructs new <code>LookupCodeEntityComparator</code> instance.</p>
     * 
     * @param comparisonType a <code>TYPE</code> specifying the type of comparison.
     */
    private LookupCodeEntityComparator(TYPE comparisonType) {
        this.comparisonType = comparisonType;
    }

    /**
     * <p>Compares the specified entities.</p>
     * 
     * @param o1 a first <code>LookupCodeEntity</code> to compare. 
     * @param o2 a second <code>LookupCodeEntity</code> to compare.
     * @return an <code>int</code> specifying the result of comparison.
     */
    @Override
    public int compare(LookupCodeEntity o1, LookupCodeEntity o2) {
        if (o1 == null) {
            if (o2 == null) {
                return 0;
            } else {
                return -1;
            }
        } else if (o2 == null) {
            return 1;
        } else {
            switch (this.comparisonType) {
                case ID: {
                    if (o1.getId() == o2.getId()) {
                        return 0;
                    } else if (o1.getId() < o2.getId()) {
                        return -1;
                    } else {
                        return 1;
                    }
                }
                case NAME: {
                    return o1.getName().compareTo(o2.getName());
                }
                case CODE: {
                    return o1.getCode().compareTo(o2.getCode());
                }
                default: {
                    return 0;
                }
            }
        }
    }
}

ALTER TABLE EngagementTypeData RENAME COLUMN iig TO ecd;
ALTER TABLE AffinityOptions RENAME COLUMN iig TO ecd;
UPDATE lob SET name = 'ECD' WHERE id = 2;

ALTER TABLE OtherRequestOptions ADD COLUMN not_listed BOOLEAN DEFAULT false;

INSERT INTO Division VALUES (12, 'TEAM', '', 'TEAM');
INSERT INTO Division VALUES (13, 'UKI', '', 'UKI');
INSERT INTO Division VALUES (14, 'France', '', 'France');
INSERT INTO Division VALUES (15, 'Germany', '', 'Germany');
INSERT INTO Division VALUES (16, 'East', '', 'East');

-- TEAM
INSERT INTO pdmname VALUES (59, 'Mohamed El-Zomor', 'Program Delivery Manager', '11351 King Fahd Road', 'EMC computer systems', 'Riyadh', 'Saudi Arabia', '', '+96(0)6112794515', '', '+96(0)6540212375', 'mohamed.elzomor@emc.com', 12);
INSERT INTO pdmname VALUES (60, 'Mahmood Shaker', 'Program Delivery Manager', '5th Floor-Internet City', 'Alpha Building', 'Dubai', 'United Arab Emirates', '', '+97(0)144240462', '', '+97(0)1526408821', 'Mahmood.Shaker@emc.com', 12);
INSERT INTO pdmname VALUES (61, 'Mahmood Shaker', 'Program Delivery Manager', '5th Floor-Internet City', 'Alpha Building', 'Dubai', 'United Arab Emirates', '', '+97(0)144240463', '', '+97(0)1526408822', 'Mahmood.Shaker@emc.com', 12);
INSERT INTO pdmname VALUES (62, 'Mahmood Shaker', 'Program Delivery Manager', '5th Floor-Internet City', 'Alpha Building', 'Dubai', 'United Arab Emirates', '', '+97(0)144240464', '', '+97(0)1526408823', 'Mahmood.Shaker@emc.com', 12);
INSERT INTO pdmname VALUES (63, 'Mahmood Shaker', 'Program Delivery Manager', '5th Floor-Internet City', 'Alpha Building', 'Dubai', 'United Arab Emirates', '', '+97(0)144240465', '', '+97(0)1526408824', 'Mahmood.Shaker@emc.com', 12);
INSERT INTO pdmname VALUES (64, 'Mahmood Shaker', 'Program Delivery Manager', '5th Floor-Internet City', 'Alpha Building', 'Dubai', 'United Arab Emirates', '', '+97(0)144240466', '', '+97(0)1526408825', 'Mahmood.Shaker@emc.com', 12);
INSERT INTO pdmname VALUES (65, 'Mahmood Shaker', 'Program Delivery Manager', '5th Floor-Internet City', 'Alpha Building', 'Dubai', 'United Arab Emirates', '', '+97(0)144240467', '', '+97(0)1526408826', 'Mahmood.Shaker@emc.com', 12);
INSERT INTO pdmname VALUES (66, 'Mahmood Shaker', 'Program Delivery Manager', '5th Floor-Internet City', 'Alpha Building', 'Dubai', 'United Arab Emirates', '', '+97(0)144240468', '', '+97(0)1526408827', 'Mahmood.Shaker@emc.com', 12);
INSERT INTO pdmname VALUES (67, 'Suzanne Seif', 'Program Delivery Manager', '5th Floor-Internet City', 'Alpha Building', 'Dubai', 'United Arab Emirates', '', '+97(0)144240457', '', '+97(0)1501457342', 'suzanne.seif@emc.com', 12);
INSERT INTO pdmname VALUES (68, 'Suzanne Seif', 'Program Delivery Manager', '5th Floor-Internet City', 'Alpha Building', 'Dubai', 'United Arab Emirates', '', '+97(0)144240458', '', '+97(0)1501457343', 'suzanne.seif@emc.com', 12);
INSERT INTO pdmname VALUES (69, 'Suzanne Seif', 'Program Delivery Manager', '5th Floor-Internet City', 'Alpha Building', 'Dubai', 'United Arab Emirates', '', '+97(0)144240459', '', '+97(0)1501457344', 'suzanne.seif@emc.com', 12);
INSERT INTO pdmname VALUES (70, 'Suzanne Seif', 'Program Delivery Manager', '5th Floor-Internet City', 'Alpha Building', 'Dubai', 'United Arab Emirates', '', '+97(0)144240460', '', '+97(0)1501457345', 'suzanne.seif@emc.com', 12);
INSERT INTO pdmname VALUES (71, 'Shakeel Shaik', 'Program Delivery Manager', '3021 William Nicol Drive', 'Bryanston', 'Johannesburg', 'South Africa', '', '+27(0)115810117', '', '+27829034587', 'Shakeel.Shaik@emc.com', 12);
INSERT INTO pdmname VALUES (72, 'Umut Kurtdede', 'Program Delivery Manager', '5th Floor', '34330 Is Kuleleri Kule-2', 'Istanbul', 'Turkey', '', '+90(0)2123174464', '', '+905309619344', 'Umut.Kurtdede@emc.com', 12);

INSERT INTO SalesDistrict VALUES (185, 'Saudi Arabia', 'SEL', 'SEL', 12, 59);
INSERT INTO SalesDistrict VALUES (186, 'Egypt', 'SEL', 'SEL', 12, 59);
INSERT INTO SalesDistrict VALUES (187, 'Libya', 'SEL', 'SEL', 12, 59);
INSERT INTO SalesDistrict VALUES (188, 'Bahrain', 'GULF', 'GULF', 12, 60);
INSERT INTO SalesDistrict VALUES (189, 'Kuwait', 'GULF', 'GULF', 12, 61);
INSERT INTO SalesDistrict VALUES (190, 'Oman', 'GULF', 'GULF', 12, 62);
INSERT INTO SalesDistrict VALUES (191, 'Pakistan', 'GULF', 'GULF', 12, 63);
INSERT INTO SalesDistrict VALUES (192, 'Qatar', 'GULF', 'GULF', 12, 64);
INSERT INTO SalesDistrict VALUES (193, 'UAE', 'GULF', 'GULF', 12, 65);
INSERT INTO SalesDistrict VALUES (194, 'Yemen', 'GULF', 'GULF', 12, 66);
INSERT INTO SalesDistrict VALUES (195, 'Iraq', 'LEMA', 'LEMA', 12, 67);
INSERT INTO SalesDistrict VALUES (196, 'Jordan', 'LEMA', 'LEMA', 12, 68);
INSERT INTO SalesDistrict VALUES (197, 'Lebanon', 'LEMA', 'LEMA', 12, 69);
INSERT INTO SalesDistrict VALUES (198, 'Palestine', 'LEMA', 'LEMA', 12, 70);
INSERT INTO SalesDistrict VALUES (199, 'South Africa', 'South Africa', 'South Africa', 12, 71);
INSERT INTO SalesDistrict VALUES (200, 'NWCA', 'NWCA', 'NWCA', 12, 67);
INSERT INTO SalesDistrict VALUES (201, 'Turkey', 'Turkey', 'Turkey', 12, 72);

-- UKI
INSERT INTO pdmname VALUES (73, 'Wendy Burns', 'Program Delivery Manager', '1st Floor The Royals', '353 Altrincham Road', 'Manchester', 'UK', '', '+44(0)1619465932', '', '+44(0)7802241300', 'wendy.burns@emc.com', 13);
INSERT INTO pdmname VALUES (74, 'Michael Hutchinson', 'Program Delivery Manager', 'EMC Tower', 'Great West Road', 'Brentford', 'UK', '', '+44(0)7730052623', '', '+44(0)7730052623', 'michael.hutchinson@emc.com', 13);
INSERT INTO pdmname VALUES (75, 'Michael Hutchinson', 'Program Delivery Manager', 'EMC Tower', 'Great West Road', 'Brentford', 'Ireland', '', '+44(0)7730052623', '', '+44(0)7730052623', 'michael.hutchinson@emc.com', 13);

INSERT INTO SalesDistrict VALUES (202, 'Enterprise South', 'United Kingdom', 'United Kingdom', 13, 73);
INSERT INTO SalesDistrict VALUES (203, 'Enterprise North', 'United Kingdom', 'United Kingdom', 13, 73);
INSERT INTO SalesDistrict VALUES (204, 'Mid Markets', 'United Kingdom', 'United Kingdom', 13, 73);
INSERT INTO SalesDistrict VALUES (205, 'Global Alliances', 'United Kingdom', 'United Kingdom', 13, 73);
INSERT INTO SalesDistrict VALUES (206, 'Public Sector', 'United Kingdom', 'United Kingdom', 13, 74);
INSERT INTO SalesDistrict VALUES (207, 'Service Provider', 'United Kingdom', 'United Kingdom', 13, 74);
INSERT INTO SalesDistrict VALUES (208, 'Enterprise', 'Ireland', 'Ireland', 13, 75);
INSERT INTO SalesDistrict VALUES (209, 'Mid Market', 'Ireland', 'Ireland', 13, 75);

-- France
INSERT INTO pdmname VALUES (76, 'Jean Philippe Bianic', 'Sr Mgr, Professional Services', 'River Ouest', '80 Quai Voltaire', 'Bezons', 'FR', '', '+33(0) 1 39969058', '', '+33(0) 6 17221974', 'jean-philippe.bianic@emc.com', 14);
INSERT INTO pdmname VALUES (77, 'Charles Dropsy', 'Sr Mgr, Professional Services', 'River Ouest', '80 Quai Voltaire', 'Bezons', 'FR', '', '+33(0) 13 9969202', '', '+33(0)60 1168110', 'charles.dropsy@emc.com', 14);
INSERT INTO pdmname VALUES (78, 'Christophe Laclef', 'Mgr, Professional Services', 'River Ouest', '80 Quai Voltaire', 'Bezons', 'FR', '', '+33(0) 13 9969343', '', '+33(0) 60 3769082', 'christophe.laclef@emc.com', 14);
INSERT INTO pdmname VALUES (79, 'Eric Avril', 'Mgr, Professional Services', 'River Ouest', '80 Quai Voltaire', 'Bezons', 'FR', '', '+33(0)139969026', '', '+33 (0)6 21 20 48 44', 'eric.avril@emc.com', 14);
INSERT INTO pdmname VALUES (80, 'Frédéric Jean', 'Mgr, Professional Services', 'River Ouest', '80 Quai Voltaire', 'Bezons', 'FR', '', '+33(0) 13 9969326', '', '+33(0) 61 5127113', 'frederic.jean@emc.com', 14);
INSERT INTO pdmname VALUES (81, 'Christophe Soustelle', 'Mgr, Professional Services', 'River Ouest', '80 Quai Voltaire', 'Bezons', 'FR', '', '+33(0) 13 9969571', '', '+33(0) 62 7512842', 'christophe.soustelle@emc.com', 14);

INSERT INTO SalesDistrict VALUES (210, 'All BRS', 'France', 'France', 14, 81);

-- Germany
INSERT INTO pdmname VALUES (82, 'Manfred Oberpaul', 'Program Delivery Manager', 'Osterfeldstrasse 84', '', 'Munich', 'Germany', '', '+49(0)8993091243', '', '+49(0)1608818056', 'manfred.oberpaul@emc.com', 15);
INSERT INTO pdmname VALUES (83, 'Raphael Mela', 'Program Delivery Manager', 'Am Kronberger Hang 2a', '', 'Schwalbach', 'Germany', '', '+49(0)61964728374', '', '+49(0)1734453428', 'raphael.mela@emc.com', 15);
INSERT INTO pdmname VALUES (84, 'Chaled Rashwan', 'Program Delivery Manager', 'Osterbeekstr. 90B', '', 'Hamburg', 'Germany', '', '+49(0)4027131626 ', '', '+4915164962843', 'Chaled.Rashwan@emc.com', 15);
INSERT INTO pdmname VALUES (85, 'Stefan Henke', 'Program Delivery Manager', 'Am Südwestpark 53', '', 'Nuremburg', 'Germany', '', '+49(0)911688698128', '', '+49(0)1726655733', 'stefan.henke@emc.com', 15);

INSERT INTO SalesDistrict VALUES (211, 'South', 'Germany', 'Germany', 15, 82);
INSERT INTO SalesDistrict VALUES (212, 'Central', 'Germany', 'Germany', 15, 83);
INSERT INTO SalesDistrict VALUES (213, 'North', 'Germany', 'Germany', 15, 84);
INSERT INTO SalesDistrict VALUES (214, 'All BRS', 'Germany', 'Germany', 15, 85);

-- West
INSERT INTO pdmname VALUES (86, 'Patrick Arn', 'GPSd Lead Switzerland / Manager Professional Services', 'Hardturmstrasse 181', '', 'CH8005 Zürich', 'Switzerland', '', '+41(0)434446749', '', '+41(0)792405046', 'patrick.arn@emc.com', 9);
INSERT INTO pdmname VALUES (87, 'Koen Segers', 'Global Professional Services Delivery Lead BeLux', 'Imperiastraat 18', 'B1930', 'Zaventem', 'Belgium', '', '+32(0)27230100', '', '+32(0)479682361', 'koen.segers@emc.com', 9);
INSERT INTO pdmname VALUES (88, 'Koen Segers', 'Global Professional Services Delivery Lead BeLux', 'Imperiastraat 19', 'B1931', 'Zaventem', 'Belgium', '', '+32(0)27230101', '', '+32(0)479682362', 'koen.segers@emc.com', 9);
INSERT INTO pdmname VALUES (89, 'Ole Wulff', 'Sr Mgr, Professional Services', 'Linde Allé 9', '', 'Nærum', 'Denmark', '', '+45(0)45560316', '', '+45(0)24248160', 'ole.wulff@emc.com', 9);
INSERT INTO pdmname VALUES (90, 'Teemu Silvennoinen', 'Team Lead, Prof Services', 'Lauttasaarenmaki 4', '', 'Helsinki', 'Finland', '', '+35(0)8201202200', '', '+35(0)8407700913', 'teemu.silvennoinen@emc.com', 9);
INSERT INTO pdmname VALUES (91, 'Eirik Storeng', 'Team Lead, Prof Services', 'Grenseveien 107', '', 'Oslo', 'Norway', '', '+47(0)23207727', '', '+47(0)40004555', 'Eirik.Storeng@emc.com', 9);
INSERT INTO pdmname VALUES (92, 'Robert Forsberg', 'Sr Mgr, Professional Services', 'Telegrafgatan 4', '', 'Solna', 'Sweden', '', '+46(0)855512011', '', '+46(0)761009330', 'robert.forsberg@emc.com', 9);
INSERT INTO pdmname VALUES (93, 'Hans Kolff', 'Sr Mgr, Professional Services', 'Edisonbaan 14B', '', 'Nieuwegein', 'Netherlands', '', '+31(0)306305060', '', '+31(0)627033006', 'hans.kolff@emc.com', 9);
INSERT INTO pdmname VALUES (94, 'Carmen Garcia', 'Sr Mgr, Professional Services', 'Ribera del Loira 8', '', 'Madrid', 'Spain', '', '+34(0)914103898', '', '+34(0)616952188', 'carmen.garcia@emc.com', 9);
INSERT INTO pdmname VALUES (95, 'Sofia Lima', 'Sr Mgr, Professional Services', 'Rua Doutor Antonio Loureiro Borges 5', '', 'Alges', 'Portugal', '', '+35(0)21214129624', '', '+35(0)1935546585', 'sofia.lima@emc.com', 9);
INSERT INTO pdmname VALUES (96, 'Andrea Franchi', 'Program Delivery Manager', 'Via Spadolini, 5', 'Edificio A', 'Milano', 'Italy', '', '+39(0)240908059', '', '+39(0)3486430570', 'andrea.franchi@emc.com', 9);

INSERT INTO SalesDistrict VALUES (215, 'Switzerland', 'Switzerland', 'Switzerland', 9, 86);
INSERT INTO SalesDistrict VALUES (216, 'Belgium', 'Belgium', 'Belgium', 9, 87);
INSERT INTO SalesDistrict VALUES (217, 'Luxembourg', 'Luxembourg', 'Luxembourg', 9, 88);
INSERT INTO SalesDistrict VALUES (218, 'Denmark', 'Denmark', 'Denmark', 9, 89);
INSERT INTO SalesDistrict VALUES (219, 'Finland', 'Finland', 'Finland', 9, 90);
INSERT INTO SalesDistrict VALUES (220, 'Norway', 'Norway', 'Norway', 9, 91);
INSERT INTO SalesDistrict VALUES (221, 'Sweden', 'Sweden', 'Sweden', 9, 92);
INSERT INTO SalesDistrict VALUES (222, 'The Netherlands', 'The Netherlands', 'The Netherlands', 9, 93);
INSERT INTO SalesDistrict VALUES (223, 'Spain', 'Spain', 'Spain', 9, 94);
INSERT INTO SalesDistrict VALUES (224, 'Portugal', 'Portugal', 'Portugal', 9, 95);
INSERT INTO SalesDistrict VALUES (225, 'Italy', 'Italy', 'Italy', 9, 96);
INSERT INTO SalesDistrict VALUES (226, 'Greece', 'Greece', 'Greece', 9, NULL);
INSERT INTO SalesDistrict VALUES (227, 'Israel', 'Israel', 'Israel', 9, NULL);

-- East
INSERT INTO SalesDistrict VALUES (228, 'Poland', 'Poland', 'Poland', 16, NULL);
INSERT INTO SalesDistrict VALUES (229, 'Russia', 'Russia', 'Russia', 16, NULL);
INSERT INTO SalesDistrict VALUES (230, 'Austria', 'Austria', 'Austria', 16, NULL);
INSERT INTO SalesDistrict VALUES (231, 'RoEE', 'RoEE', 'RoEE', 16, NULL);
INSERT INTO SalesDistrict VALUES (232, 'Turkey', 'Turkey', 'Turkey', 16, NULL);

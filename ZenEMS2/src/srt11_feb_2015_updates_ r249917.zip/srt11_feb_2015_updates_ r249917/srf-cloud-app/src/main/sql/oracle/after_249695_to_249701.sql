ALTER TABLE Division ADD strict_profile_search NUMBER(1) DEFAULT 0/

UPDATE Division SET strict_profile_search = 1 WHERE id = 24/
UPDATE Division SET strict_profile_search = 1 WHERE id = 25/
UPDATE Division SET strict_profile_search = 1 WHERE id = 26/

ALTER TABLE IPEDUData DROP COLUMN hosts_number/

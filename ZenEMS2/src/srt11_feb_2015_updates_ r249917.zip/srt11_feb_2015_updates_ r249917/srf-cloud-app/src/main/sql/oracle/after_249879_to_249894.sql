insert into Geography values(5, 'RSA')/
insert into Geography values(6, 'ECD')/

ALTER TABLE Division ADD geography_id NUMBER/
ALTER TABLE Division ADD FOREIGN KEY (geography_id) REFERENCES Geography (id)/

UPDATE Division SET geography_id = 2 WHERE id = 1/
UPDATE Division SET geography_id = 1, division_name = 'NA - Central' WHERE id = 2/
UPDATE Division SET geography_id = 1, division_name = 'NA - Mid-Market' WHERE id = 3/
UPDATE Division SET geography_id = 1, division_name = 'NA - Federal' WHERE id = 4/
UPDATE Division SET geography_id = 2 WHERE id = 5/
UPDATE Division SET geography_id = 1, division_name = 'NA - MASE' WHERE id = 6/
UPDATE Division SET geography_id = 1, division_name = 'NA - NE/Canada' WHERE id = 7/
UPDATE Division SET geography_id = 1, division_name = 'NA - NY NJ' WHERE id = 8/
UPDATE Division SET geography_id = 1, division_name = 'NA - West' WHERE id = 9/
UPDATE Division SET geography_id = 2 WHERE id = 10/
UPDATE Division SET geography_id = 2 WHERE id = 11/
UPDATE Division SET geography_id = 3, division_name = 'EMEA - TEAM' WHERE id = 12/
UPDATE Division SET geography_id = 3, division_name = 'EMEA - UKI' WHERE id = 13/
UPDATE Division SET geography_id = 3, division_name = 'EMEA - France' WHERE id = 14/
UPDATE Division SET geography_id = 3, division_name = 'EMEA - Germany' WHERE id = 15/
UPDATE Division SET geography_id = 3, division_name = 'EMEA - East' WHERE id = 16/
UPDATE Division SET geography_id = 3, division_name = 'EMEA - West' WHERE id = 17/
UPDATE Division SET geography_id = 3, division_name = 'EMEA - ANZ' WHERE id = 18/
UPDATE Division SET geography_id = 4, division_name = 'APJ - China' WHERE id = 19/
UPDATE Division SET geography_id = 4, division_name = 'APJ - India' WHERE id = 20/
UPDATE Division SET geography_id = 4, division_name = 'APJ - Japan' WHERE id = 21/
UPDATE Division SET geography_id = 4, division_name = 'APJ - Korea' WHERE id = 22/
UPDATE Division SET geography_id = 4, division_name = 'APJ -SE Asia ' WHERE id = 23/
UPDATE Division SET geography_id = 5 WHERE id = 24/
UPDATE Division SET geography_id = 6 WHERE id = 25/
UPDATE Division SET geography_id = 5 WHERE id = 26/


ALTER TABLE SalesDistrict ADD email_address VARCHAR2(256)/

UPDATE Division SET email_address = 'SQCUK@emc.com' WHERE id = 13/
UPDATE Division SET email_address = 'SQCGermany@emc.com' WHERE id = 15/
UPDATE Division SET email_address = 'SQCFrance@emc.com' WHERE id = 14/
UPDATE Division SET email_address = 'SQCEAST@emc.com' WHERE id = 16/
UPDATE Division SET email_address = 'SQCTEAM@emc.com' WHERE id = 12/

UPDATE SalesDistrict SET email_address = 'SQCIreland@emc.com' WHERE id = 208/
UPDATE SalesDistrict SET email_address = 'SQCIreland@emc.com' WHERE id = 209/
UPDATE SalesDistrict SET email_address = 'SQCIBERIA@emc.com' WHERE id = 223/
UPDATE SalesDistrict SET email_address = 'SQCIBERIA@emc.com' WHERE id = 224/
UPDATE SalesDistrict SET email_address = 'SQCItaly@emc.com' WHERE id = 225/
UPDATE SalesDistrict SET email_address = 'SQCSwitzerland@emc.com' WHERE id = 215/
UPDATE SalesDistrict SET email_address = 'SQCBeLux@emc.com' WHERE id = 216/
UPDATE SalesDistrict SET email_address = 'SQCNetherlands@emc.com' WHERE id = 222/
UPDATE SalesDistrict SET email_address = 'SQCIsrael@emc.com' WHERE id = 227/
UPDATE SalesDistrict SET email_address = 'SQCGreece@emc.com' WHERE id = 226/
UPDATE SalesDistrict SET email_address = 'SQCNordics@emc.com' WHERE id = 217/
UPDATE SalesDistrict SET email_address = 'SQCNordics@emc.com' WHERE id = 218/
UPDATE SalesDistrict SET email_address = 'SQCNordics@emc.com' WHERE id = 219/
UPDATE SalesDistrict SET email_address = 'SQCNordics@emc.com' WHERE id = 220/
UPDATE SalesDistrict SET email_address = 'SQCNordics@emc.com' WHERE id = 221/


ALTER TABLE StartRequestData ALTER COLUMN service_request_scope SET DATA TYPE TEXT;

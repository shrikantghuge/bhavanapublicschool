ALTER TABLE Profile DROP COLUMN submitter;

INSERT INTO MaterialCode_Competency (material_id, competency_id) VALUES (47, 58);
INSERT INTO MaterialCode_Competency (material_id, competency_id) VALUES (47, 59);
INSERT INTO MaterialCode_Competency (material_id, competency_id) VALUES (52, 126);
INSERT INTO MaterialCode_Competency (material_id, competency_id) VALUES (51, 118);
INSERT INTO MaterialCode_Competency (material_id, competency_id) VALUES (51, 143);
INSERT INTO MaterialCode_Competency (material_id, competency_id) VALUES (32, 105);
INSERT INTO MaterialCode_Competency (material_id, competency_id) VALUES (50, 160);
INSERT INTO MaterialCode_Competency (material_id, competency_id) VALUES (19, 137);
INSERT INTO MaterialCode_Competency (material_id, competency_id) VALUES (23, 105);
INSERT INTO MaterialCode_Competency (material_id, competency_id) VALUES (66, 3);
INSERT INTO MaterialCode_Competency (material_id, competency_id) VALUES (3, 105);
INSERT INTO MaterialCode_Competency (material_id, competency_id) VALUES (56, 139);
INSERT INTO MaterialCode_Competency (material_id, competency_id) VALUES (56, 140);
INSERT INTO MaterialCode_Competency (material_id, competency_id) VALUES (119, 254);


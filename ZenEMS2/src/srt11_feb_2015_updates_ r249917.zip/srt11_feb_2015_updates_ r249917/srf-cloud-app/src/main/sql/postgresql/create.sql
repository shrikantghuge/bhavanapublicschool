CREATE SEQUENCE SContractStructure INCREMENT BY 1 START WITH 1000;

CREATE TABLE ContractStructure (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SContractStructure'),
    name VARCHAR(256) NOT NULL);

CREATE SEQUENCE SDealQuestionSection INCREMENT BY 1 START WITH 1000;

CREATE TABLE DealQuestionSection (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SDealQuestionSection'),
    name VARCHAR(256) NOT NULL);

CREATE SEQUENCE SDealQuestion INCREMENT BY 1 START WITH 1000;

CREATE TABLE DealQuestion (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SDealQuestion'),
    name VARCHAR(256) NOT NULL,
    comment_condition BOOLEAN NOT NULL,
    comment_place_holder VARCHAR(256) NOT NULL,
    section_id BIGINT NOT NULL,
    FOREIGN KEY (section_id) REFERENCES DealQuestionSection (id));

CREATE SEQUENCE SDealGovernanceData INCREMENT BY 1 START WITH 1000;

CREATE TABLE DealGovernanceData (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SDealGovernanceData'),
    opportunity_name VARCHAR(140),
    primary_delivery_org VARCHAR(140),
    other_practices VARCHAR(140),
    estimated_start_date DATE,
    brief_description VARCHAR(140),
    contract_structure_id BIGINT,
    approver_notes VARCHAR(140),
    FOREIGN KEY (contract_structure_id) REFERENCES ContractStructure (id));

CREATE TABLE DealGovernanceData_answers (
    deal_governance_data_id BIGINT,
    question_id BIGINT,
    yes_no BOOLEAN,
    answer_comment VARCHAR(140),
    FOREIGN KEY (deal_governance_data_id) REFERENCES DealGovernanceData (id),
    FOREIGN KEY (question_id) REFERENCES DealQuestion (id));

CREATE SEQUENCE SGeography INCREMENT BY 1 START WITH 1000;

CREATE TABLE Geography (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SGeography'),
    name VARCHAR(256));

CREATE SEQUENCE SDeliveryGeography INCREMENT BY 1 START WITH 1000;

CREATE TABLE DeliveryGeography (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SDeliveryGeography'),
    name VARCHAR(256),
    code VARCHAR(10) NOT NULL);

CREATE SEQUENCE SDealCurrency INCREMENT BY 1 START WITH 1000;

CREATE TABLE DealCurrency (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SDealCurrency'),
    name VARCHAR(3),
    exchange_rate DECIMAL(20,10) NOT NULL);

CREATE SEQUENCE SDeliveryCountry INCREMENT BY 1 START WITH 1000;

CREATE TABLE DeliveryCountry (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SDeliveryCountry'),
    code VARCHAR(2) NOT NULL,
    name VARCHAR(256) NOT NULL,
    delivery_geography_id BIGINT,
    delivery_currency_id BIGINT,
    calling_code VARCHAR(256),
    FOREIGN KEY (delivery_geography_id) REFERENCES DeliveryGeography (id),
    FOREIGN KEY (delivery_currency_id) REFERENCES DealCurrency (id));

CREATE SEQUENCE SRegion INCREMENT BY 1 START WITH 1000;

CREATE TABLE Region (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SRegion'),
    code VARCHAR(256) NOT NULL,
    name VARCHAR(256),
    region_country_id BIGINT,
    FOREIGN KEY (region_country_id) REFERENCES DeliveryCountry (id));

CREATE SEQUENCE SScreenerInterviewer INCREMENT BY 1 START WITH 1000;

CREATE TABLE ScreenerInterviewer (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SScreenerInterviewer'),
    name VARCHAR(256) NOT NULL);

CREATE SEQUENCE SResourceType INCREMENT BY 1 START WITH 1000;

CREATE TABLE ResourceType (
  id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SResourceType'),
  name VARCHAR(256) NOT NULL,
  code VARCHAR(2) NOT NULL
);

CREATE SEQUENCE SBillingType INCREMENT BY 1 START WITH 1000;

CREATE TABLE BillingType (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SBillingType'),
    name VARCHAR(256) NOT NULL,
    code VARCHAR(10) NOT NULL);

CREATE SEQUENCE SLOB INCREMENT BY 1 START WITH 1000;

CREATE TABLE LOB (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SLOB'),
    name VARCHAR(256) NOT NULL,
    code VARCHAR(10) NOT NULL);

CREATE SEQUENCE SBOERole INCREMENT BY 1 START WITH 1000;

CREATE TABLE BOERole (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SBOERole'),
    code VARCHAR(256) NOT NULL,
    name VARCHAR(256) NOT NULL);

CREATE SEQUENCE SDiscountFloorType INCREMENT BY 1 START WITH 1000;

CREATE TABLE DiscountFloorType (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SDiscountFloorType'),
    name VARCHAR(256) NOT NULL,
    code VARCHAR(256) NOT NULL
);

CREATE SEQUENCE SDiscountFloorGroup INCREMENT BY 1 START WITH 1000;

CREATE TABLE DiscountFloorGroup (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SDiscountFloorGroup'),
    name VARCHAR(256) NOT NULL
);

CREATE SEQUENCE SDiscountFloor INCREMENT BY 1 START WITH 2000;

CREATE TABLE DiscountFloor (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SDiscountFloor'),
    group_id BIGINT,
    type_id BIGINT,
    threshold DECIMAL(10,2),
    FOREIGN KEY (group_id) REFERENCES DiscountFloorGroup (id),
    FOREIGN KEY (type_id) REFERENCES DiscountFloorType (id)
);

CREATE SEQUENCE SMaterialCode INCREMENT BY 1 START WITH 1000;

CREATE TABLE MaterialCode (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SMaterialCode'),
    code VARCHAR(256) NOT NULL,
    name VARCHAR(256) NOT NULL,
    expense_model VARCHAR(256) NOT NULL,
    lob_id BIGINT NOT NULL,
    discount_group_id BIGINT NOT NULL,
    FOREIGN KEY (lob_id) REFERENCES LOB (id),
    FOREIGN KEY (discount_group_id) REFERENCES DiscountFloorGroup (id)
);

CREATE SEQUENCE SCompetency INCREMENT BY 1 START WITH 1000;

CREATE TABLE Competency (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SCompetency'),
    code VARCHAR(256) NOT NULL,
    name VARCHAR(256) NOT NULL,
    lob_id BIGINT NOT NULL,
    FOREIGN KEY (lob_id) REFERENCES LOB (id));

CREATE TABLE MaterialCode_Competency (
    material_id BIGINT NOT NULL,
    competency_id BIGINT NOT NULL,
    PRIMARY KEY (material_id, competency_id),
    FOREIGN KEY (material_id) REFERENCES MaterialCode (id),
    FOREIGN KEY (competency_id) REFERENCES Competency (id));

CREATE TABLE Competency_BOERole (
    competency_id BIGINT NOT NULL,
    role_id BIGINT NOT NULL,
    PRIMARY KEY (competency_id, role_id),
    FOREIGN KEY (role_id) REFERENCES BOERole (id),
    FOREIGN KEY (competency_id) REFERENCES Competency (id));

CREATE SEQUENCE SLOBCountry INCREMENT BY 1 START WITH 1000;

CREATE TABLE LOBCountry (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SLOBCountry'),
    lob_id BIGINT NOT NULL,
    country_code VARCHAR(2),
    company_code VARCHAR(256) NOT NULL,
    cost_center_code VARCHAR(256) NOT NULL,
    FOREIGN KEY (lob_id) REFERENCES LOB (id));

CREATE SEQUENCE SHourlyStdCostRate INCREMENT BY 1 START WITH 1000;

CREATE TABLE HourlyStdCostRate (
    lookup_key VARCHAR(100) NOT NULL PRIMARY KEY DEFAULT nextval('SHourlyStdCostRate'),
    rate DECIMAL(20,2));

CREATE SEQUENCE SStandardBillRate INCREMENT BY 1 START WITH 1000;

CREATE TABLE StandardBillRate (
    lookup_key VARCHAR(100) NOT NULL PRIMARY KEY DEFAULT nextval('SStandardBillRate'),
    rate DECIMAL(20,2));

CREATE SEQUENCE SDeliverAction INCREMENT BY 1 START WITH 1000;

CREATE TABLE DeliverAction (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SDeliverAction'),
    name VARCHAR(256) NOT NULL,
    code VARCHAR(10) NOT NULL,
    description VARCHAR(1024) NOT NULL);

CREATE SEQUENCE SLOBResource INCREMENT BY 1 START WITH 1000;

CREATE TABLE LOBResource (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SLOBResource'),
    competency_id BIGINT,
    role_id BIGINT,
    start_date DATE,
    weeks INT,
    end_date DATE,
    contingency_percent DECIMAL(20),
    bill_rate_override DECIMAL(20),
    long_role_description VARCHAR(256),
    skills VARCHAR(140),
    additional_comments VARCHAR(140),
    potential_candidate VARCHAR(140),
    tech_screeners VARCHAR(140),
    utilization_target DECIMAL(20,2),
    resource_type_id BIGINT,
    citizenship_required BOOLEAN,
    security_clearance_required BOOLEAN,
    remote_work_allowed BOOLEAN,
    work_location VARCHAR(140),
    days_week_on_site INT,
    screener_interviewer_id BIGINT,
    project_pdm VARCHAR(140),
    project_pm VARCHAR(140),
    project_rm VARCHAR(140),
    notes VARCHAR(140),
    FOREIGN KEY (role_id) REFERENCES BOERole (id),
    FOREIGN KEY (competency_id) REFERENCES Competency (id),
    FOREIGN KEY (screener_interviewer_id) REFERENCES ScreenerInterviewer (id),
    FOREIGN KEY (resource_type_id) REFERENCES ResourceType (id));

CREATE TABLE LOBResource_monthHours (
    lob_resource_id BIGINT,
    month INT,
    hours INT,
    FOREIGN KEY (lob_resource_id) REFERENCES LOBResource (id));

CREATE SEQUENCE SLOBResources INCREMENT BY 1 START WITH 1000;

CREATE TABLE LOBResources (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SLOBResources'),
    lob_id BIGINT,
    material_id BIGINT,
    competency_id BIGINT,
    billing_type_id BIGINT,
    months_num INT,
    expense_amount DECIMAL(20),
    discount_percent DECIMAL(20),
    discount_amount DECIMAL(20),
    wbs_number VARCHAR(140),
    sales_order_item_number VARCHAR(140),
    expense_wbs_number VARCHAR(140),
    expense_sales_order_number VARCHAR(140),
    FOREIGN KEY (lob_id) REFERENCES LOB (id),
    FOREIGN KEY (material_id) REFERENCES MaterialCode (id),
    FOREIGN KEY (competency_id) REFERENCES Competency (id),
    FOREIGN KEY (billing_type_id) REFERENCES BillingType (id));

CREATE TABLE LOB_resources (
    lob_resources_id BIGINT NOT NULL,
    lob_resource_id BIGINT NOT NULL,
    FOREIGN KEY (lob_resources_id) REFERENCES LOBResources (id),
    FOREIGN KEY (lob_resource_id) REFERENCES LOBResource (id));

CREATE SEQUENCE SEstimatesData INCREMENT BY 1 START WITH 1000;

CREATE TABLE EstimatesData (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SEstimatesData'),
    deal_currency_id BIGINT,
    estimated_percent DECIMAL(20),
    expense_amount DECIMAL(20),
    capped_percent DECIMAL(20),
    client_pricing_override DECIMAL(20),
    deliver_description VARCHAR(512),
    deliver_action_id BIGINT,
    contingency_percent DECIMAL(20),
    sow_number VARCHAR(256),
    contract_number VARCHAR(256),
    FOREIGN KEY (deal_currency_id) REFERENCES DealCurrency (id),
    FOREIGN KEY (deliver_action_id) REFERENCES DeliverAction (id));

CREATE SEQUENCE SIPEDUData INCREMENT BY 1 START WITH 1000;
CREATE TABLE IPEDUData (
  id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SIPEDUData'),
  estimates_data_id  BIGINT,
  data_type   VARCHAR(3),
  material_id BIGINT,
  competency_id BIGINT,
  amount DECIMAL(20, 2),
  FOREIGN KEY (estimates_data_id) REFERENCES EstimatesData (id),
  FOREIGN KEY (material_id) REFERENCES MaterialCode (id),
  FOREIGN KEY (competency_id) REFERENCES Competency (id)
);
    

CREATE TABLE EstimatesData_resources (
    estimates_data_id BIGINT NOT NULL,
    lob_resources_id BIGINT NOT NULL,
    FOREIGN KEY (estimates_data_id) REFERENCES EstimatesData (id),
    FOREIGN KEY (lob_resources_id) REFERENCES LOBResources (id));

CREATE SEQUENCE SEngagementTypeData INCREMENT BY 1 START WITH 1000;

CREATE TABLE EngagementTypeData (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SEngagementTypeData'),
    product_lead BOOLEAN,
    service_lead BOOLEAN,
    emc BOOLEAN,
    ecd BOOLEAN,
    rsa BOOLEAN,
    ms BOOLEAN,
    delivery_country_id BIGINT,
    FOREIGN KEY (delivery_country_id) REFERENCES DeliveryCountry (id));

CREATE SEQUENCE SDataDomainDeviceType INCREMENT BY 1 START WITH 1000;

CREATE TABLE DataDomainDeviceType (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SDataDomainDeviceType'),
    name VARCHAR(256));

CREATE SEQUENCE SDataDomainUpgradeType INCREMENT BY 1 START WITH 1000;

CREATE TABLE DataDomainUpgradeType (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SDataDomainUpgradeType'),
    name VARCHAR(256));

CREATE SEQUENCE SDataDomainDataStagingType INCREMENT BY 1 START WITH 1000;

CREATE TABLE DataDomainDataStagingType (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SDataDomainDataStagingType'),
    name VARCHAR(256));

CREATE SEQUENCE SDataDomainIntegrationType INCREMENT BY 1 START WITH 1000;

CREATE TABLE DataDomainIntegrationType (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SDataDomainIntegrationType'),
    name VARCHAR(256));

CREATE SEQUENCE SDataDomainMigrationType INCREMENT BY 1 START WITH 1000;

CREATE TABLE DataDomainMigrationType (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SDataDomainMigrationType'),
    name VARCHAR(256));

CREATE SEQUENCE SDataDomainPreRackType INCREMENT BY 1 START WITH 1000;

CREATE TABLE DataDomainPreRackType (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SDataDomainPreRackType'),
    name VARCHAR(256));

CREATE SEQUENCE SDataDomainBoostType INCREMENT BY 1 START WITH 1000;

CREATE TABLE DataDomainBoostType (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SDataDomainBoostType'),
    name VARCHAR(256));

CREATE SEQUENCE SDataDomainMaxBackupWindowTime INCREMENT BY 1 START WITH 1000;

CREATE TABLE DataDomainMaxBackupWindowTime (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SDataDomainMaxBackupWindowTime'),
    name VARCHAR(256));

CREATE SEQUENCE SAvamarServerType INCREMENT BY 1 START WITH 1000;

CREATE TABLE AvamarServerType (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SAvamarServerType'),
    name VARCHAR(256) NOT NULL);

CREATE SEQUENCE SVplexDataMobilityType INCREMENT BY 1 START WITH 1000;

CREATE TABLE VplexDataMobilityType (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SVplexDataMobilityType'),
    name VARCHAR(256) NOT NULL);

CREATE SEQUENCE SRecoverPointSplitterType INCREMENT BY 1 START WITH 1000;

CREATE TABLE RecoverPointSplitterType (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SRecoverPointSplitterType'),
    name VARCHAR(256));

CREATE SEQUENCE SIntelligentFabricMigrationMet INCREMENT BY 1 START WITH 1000;

CREATE TABLE IntelligentFabricMigrationMet (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SIntelligentFabricMigrationMet'),
    name VARCHAR(256) NOT NULL);

CREATE SEQUENCE SRecoverPointOption INCREMENT BY 1 START WITH 1000;

CREATE TABLE RecoverPointOption (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SRecoverPointOption'),
    name VARCHAR(256) NOT NULL);

CREATE SEQUENCE SCenteraArrayActionType INCREMENT BY 1 START WITH 1000;

CREATE TABLE CenteraArrayActionType (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SCenteraArrayActionType'),
    name VARCHAR(256));

CREATE SEQUENCE SCenteraEditionType INCREMENT BY 1 START WITH 1000;

CREATE TABLE CenteraEditionType (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SCenteraEditionType'),
    name VARCHAR(256));

CREATE SEQUENCE SCenteraGenerationType INCREMENT BY 1 START WITH 1000;

CREATE TABLE CenteraGenerationType (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SCenteraGenerationType'),
    name VARCHAR(256));

CREATE SEQUENCE SCenteraHealthCheckType INCREMENT BY 1 START WITH 1000;

CREATE TABLE CenteraHealthCheckType (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SCenteraHealthCheckType'),
    name VARCHAR(256));

CREATE SEQUENCE SCenteraReplicationType INCREMENT BY 1 START WITH 1000;

CREATE TABLE CenteraReplicationType (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SCenteraReplicationType'),
    name VARCHAR(256));

CREATE SEQUENCE SCenteraProtectionSchemeType INCREMENT BY 1 START WITH 1000;

CREATE TABLE CenteraProtectionSchemeType (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SCenteraProtectionSchemeType'),
    name VARCHAR(256));

CREATE SEQUENCE SCenteraShippingArranger INCREMENT BY 1 START WITH 1000;

CREATE TABLE CenteraShippingArranger (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SCenteraShippingArranger'),
    name VARCHAR(256));

CREATE SEQUENCE SCUAHardwareType INCREMENT BY 1 START WITH 1000;

CREATE TABLE CUAHardwareType (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SCUAHardwareType'),
    name VARCHAR(256));

CREATE SEQUENCE SUIMType INCREMENT BY 1 START WITH 1000;

CREATE TABLE UIMType (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SUIMType'),
    name VARCHAR(256));

CREATE SEQUENCE SUnifiedHealthCheckType INCREMENT BY 1 START WITH 1000;

CREATE TABLE UnifiedHealthCheckType (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SUnifiedHealthCheckType'),
    name VARCHAR(256));

CREATE SEQUENCE SWeekDay INCREMENT BY 1 START WITH 1000;

CREATE TABLE WeekDay (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SWeekDay'),
    name VARCHAR(256));

CREATE SEQUENCE SResidencyPaymentType INCREMENT BY 1 START WITH 1000;

CREATE TABLE ResidencyPaymentType (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SResidencyPaymentType'),
    name VARCHAR(256));

CREATE SEQUENCE SCTASourceFileServerType INCREMENT BY 1 START WITH 1000;

CREATE TABLE CTASourceFileServerType (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SCTASourceFileServerType'),
    name VARCHAR(256));

CREATE SEQUENCE SCTAApplianceType INCREMENT BY 1 START WITH 1000;

CREATE TABLE CTAApplianceType (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SCTAApplianceType'),
    name VARCHAR(256));

CREATE SEQUENCE SDurationMonths INCREMENT BY 1 START WITH 1000;

CREATE TABLE DurationMonths (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SDurationMonths'),
    name VARCHAR(256));

CREATE SEQUENCE SMSSService INCREMENT BY 1 START WITH 1000;

CREATE TABLE MSSService (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SMSSService'),
    name VARCHAR(256));

CREATE SEQUENCE SMSSPlatform INCREMENT BY 1 START WITH 1000;

CREATE TABLE MSSPlatform (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SMSSPlatform'),
    name VARCHAR(256));

CREATE SEQUENCE SSitesInvolved INCREMENT BY 1 START WITH 1000;

CREATE TABLE SitesInvolved (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SSitesInvolved'),
    name VARCHAR(256));

CREATE SEQUENCE SFlashStorageLayoutServices INCREMENT BY 1 START WITH 1000;

CREATE TABLE FlashStorageLayoutServices (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SFlashStorageLayoutServices'),
    name VARCHAR(256));

CREATE SEQUENCE SScriptingLevelOption INCREMENT BY 1 START WITH 1000;

CREATE TABLE ScriptingLevelOption (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SScriptingLevelOption'),
    name VARCHAR(256));

CREATE SEQUENCE SDivision INCREMENT BY 1 START WITH 1000;

CREATE TABLE Division (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SDivision'),
    division_name VARCHAR(256),
    email_address VARCHAR(256),
    short_name VARCHAR(256),
    strict_profile_search BOOLEAN,
    geography_id BIGINT,
    FOREIGN KEY (geography_id) REFERENCES Geography (id)
);

CREATE SEQUENCE SPdmName INCREMENT BY 1 START WITH 1000;

CREATE TABLE PdmName (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SPdmName'),
    pdm_name VARCHAR(256),
    title VARCHAR(256),
    address1 VARCHAR(256),
    address2 VARCHAR(256),
    city VARCHAR(256),
    state VARCHAR(256),
    postalcode VARCHAR(256),
    officenumber VARCHAR(256),
    faxnumber VARCHAR(256),
    mobilenumber VARCHAR(256),
    emailaddress VARCHAR(256),
    division_id BIGINT,
    FOREIGN KEY (division_id) REFERENCES Division (id));

CREATE SEQUENCE SGeoState INCREMENT BY 1 START WITH 1000;

CREATE TABLE GeoState (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SGeoState'),
    geography_id BIGINT,
    default_division_id BIGINT,
    default_pdm_name_id BIGINT,
    name VARCHAR(256),
    FOREIGN KEY (geography_id) REFERENCES Geography (id),
    FOREIGN KEY (default_division_id) REFERENCES Division (id),
    FOREIGN KEY (default_pdm_name_id) REFERENCES PdmName (id));

CREATE SEQUENCE SSalesDistrict INCREMENT BY 1 START WITH 1000;

CREATE TABLE SalesDistrict (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SSalesDistrict'),
    district_name VARCHAR(256),
    area_name VARCHAR(256),
    market_name VARCHAR(256),
    division_id BIGINT,
    default_pdm_id BIGINT,
    email_address VARCHAR(256),
    FOREIGN KEY (division_id) REFERENCES Division (id),
    FOREIGN KEY (default_pdm_id) REFERENCES PdmName (id));

CREATE SEQUENCE SProfile INCREMENT BY 1 START WITH 1000;

CREATE TABLE Profile (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SProfile'),
    first_name VARCHAR(256),
    last_name VARCHAR(256),
    job_title VARCHAR(256),
    country_code VARCHAR(256),
    office_phone_country_code VARCHAR(256),
    office_phone_number VARCHAR(256),
    mobile_phone_country_code VARCHAR(256),
    mobile_phone_number VARCHAR(256),
    fax_country_code VARCHAR(256),
    fax_number VARCHAR(256),
    email VARCHAR(256),
    division_id BIGINT,
    sales_district_id BIGINT,
    default_profile BOOLEAN,
    user_identifier VARCHAR(128) NOT NULL,
    correlated_id BIGINT,
    template_permission BOOLEAN NOT NULL DEFAULT FALSE,
    approver BOOLEAN NOT NULL DEFAULT FALSE,
    se_csd_name VARCHAR(256),
    se_csd_phone_country_code VARCHAR(256),
    se_csd_phone_number VARCHAR(256),
    se_manager_name VARCHAR(256),
    FOREIGN KEY (division_id) REFERENCES Division (id),
    FOREIGN KEY (sales_district_id) REFERENCES SalesDistrict (id)
);

CREATE SEQUENCE SServicesAgreementType INCREMENT BY 1 START WITH 1000;

CREATE TABLE ServicesAgreementType (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SServicesAgreementType'),
    name VARCHAR(256) NOT NULL);

CREATE SEQUENCE SSowType INCREMENT BY 1 START WITH 1000;

CREATE TABLE SowType (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SSowType'),
    name VARCHAR(256) NOT NULL);

CREATE SEQUENCE SCustomerWorkSite INCREMENT BY 1 START WITH 1000;

CREATE TABLE CustomerWorkSite (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SCustomerWorkSite'),
    site_name VARCHAR(256),
    delivery_city VARCHAR(256),
    cws_delivery_country_type_id BIGINT,
    cws_delivery_region_type_id BIGINT,
    FOREIGN KEY (cws_delivery_country_type_id) REFERENCES DeliveryCountry (id),
    FOREIGN KEY (cws_delivery_region_type_id) REFERENCES Region (id));

CREATE SEQUENCE SCustomer INCREMENT BY 1 START WITH 1000;

CREATE TABLE Customer (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SCustomer'),
    contact_name VARCHAR(256),
    formal_name VARCHAR(256),
    address1 VARCHAR(256),
    address2 VARCHAR(256),
    city VARCHAR(256),
    zip VARCHAR(256),
    title VARCHAR(256),
    office_phone_country_code VARCHAR(256),
    office_phone_number VARCHAR(256),
    mobile_phone_country_code VARCHAR(256),
    mobile_phone_number VARCHAR(256),
    fax_country_code VARCHAR(256),
    fax_number VARCHAR(256),
    email VARCHAR(256),
    services_agreement_number VARCHAR(256),
    services_agreement_date TIMESTAMP,
    partner_information VARCHAR(256),
    geo_state_id BIGINT,
    country_id BIGINT,
    services_agreement_type_id BIGINT,
    template BOOLEAN,
    user_identifier VARCHAR(128) NOT NULL,
    correlated_id BIGINT,
    FOREIGN KEY (geo_state_id) REFERENCES Region (id),
    FOREIGN KEY (country_id) REFERENCES DeliveryCountry (id),
    FOREIGN KEY (services_agreement_type_id) REFERENCES ServicesAgreementType (id));

CREATE SEQUENCE SCustomer_CustomerWorkSite INCREMENT BY 1 START WITH 1000;

CREATE TABLE Customer_CustomerWorkSite (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SCustomer_CustomerWorkSite'),
    customer_id BIGINT,
    customer_work_site_id BIGINT,
    FOREIGN KEY (customer_id) REFERENCES Customer (id),
    FOREIGN KEY (customer_work_site_id) REFERENCES CustomerWorkSite (id));
    
CREATE SEQUENCE SProjectType INCREMENT BY 1 START WITH 1000;

CREATE TABLE ProjectType (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SProjectType'),
    name VARCHAR(256) NOT NULL,
    code VARCHAR(10));

CREATE SEQUENCE SProjectRegulatoryType INCREMENT BY 1 START WITH 1000;

CREATE TABLE ProjectRegulatoryType (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SProjectRegulatoryType'),
    name VARCHAR(256) NOT NULL,
    code VARCHAR(10) NOT NULL);

CREATE SEQUENCE SExpenseType INCREMENT BY 1 START WITH 1000;

CREATE TABLE ExpenseType (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SExpenseType'),
    name VARCHAR(256) NOT NULL);

CREATE SEQUENCE SMeditechBackupType INCREMENT BY 1 START WITH 1000;

CREATE TABLE MeditechBackupType (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SMeditechBackupType'),
    name VARCHAR(256) NOT NULL);

CREATE SEQUENCE SNetworkerDatazoneSize INCREMENT BY 1 START WITH 1000;

CREATE TABLE NetworkerDatazoneSize (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SNetworkerDatazoneSize'),
    name VARCHAR(256) NOT NULL);

CREATE SEQUENCE SEnvironmentDeviceType INCREMENT BY 1 START WITH 1000;

CREATE TABLE EnvironmentDeviceType (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SEnvironmentDeviceType'),
    name VARCHAR(256) NOT NULL);

CREATE SEQUENCE SVnxClariionInstallType INCREMENT BY 1 START WITH 1000;

CREATE TABLE VnxClariionInstallType (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SVnxClariionInstallType'),
    name VARCHAR(256) NOT NULL);

CREATE SEQUENCE SSrdfConnectionType INCREMENT BY 1 START WITH 1000;

CREATE TABLE SrdfConnectionType (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SSrdfConnectionType'),
    name VARCHAR(256) NOT NULL);

CREATE SEQUENCE SPsaAgreementType INCREMENT BY 1 START WITH 1000;

CREATE TABLE PsaAgreementType (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SPsaAgreementType'),
    name VARCHAR(256) NOT NULL);

CREATE SEQUENCE SEnvironmentArrayType INCREMENT BY 1 START WITH 1000;

CREATE TABLE EnvironmentArrayType (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SEnvironmentArrayType'),
    name VARCHAR(256) NOT NULL);

CREATE SEQUENCE SSrdfStaticDynamicType INCREMENT BY 1 START WITH 1000;

CREATE TABLE SrdfStaticDynamicType (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SSrdfStaticDynamicType'),
    name VARCHAR(256) NOT NULL);

CREATE SEQUENCE SVnxInstallProtocolSubType INCREMENT BY 1 START WITH 1000;

CREATE TABLE VnxInstallProtocolSubType (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SVnxInstallProtocolSubType'),
    name VARCHAR(256) NOT NULL);

CREATE SEQUENCE SRequestType INCREMENT BY 1 START WITH 1000;

CREATE TABLE RequestType (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SRequestType'),
    name VARCHAR(256) NOT NULL);

CREATE SEQUENCE SSourceVnxType INCREMENT BY 1 START WITH 1000;

CREATE TABLE SourceVnxType (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SSourceVnxType'),
    name VARCHAR(256) NOT NULL);

CREATE SEQUENCE SAreaSizingType INCREMENT BY 1 START WITH 1000;

CREATE TABLE AreaSizingType (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SAreaSizingType'),
    name VARCHAR(256) NOT NULL);

CREATE SEQUENCE SCelerraSetupType INCREMENT BY 1 START WITH 1000;

CREATE TABLE CelerraSetupType (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SCelerraSetupType'),
    name VARCHAR(256) NOT NULL);

CREATE SEQUENCE SCelerraArrayType INCREMENT BY 1 START WITH 1000;

CREATE TABLE CelerraArrayType (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SCelerraArrayType'),
    name VARCHAR(256) NOT NULL);

CREATE SEQUENCE STargetCelerraType INCREMENT BY 1 START WITH 1000;

CREATE TABLE TargetCelerraType (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('STargetCelerraType'),
    name VARCHAR(256) NOT NULL);

CREATE SEQUENCE SConfigChangeType INCREMENT BY 1 START WITH 1000;

CREATE TABLE ConfigChangeType (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SConfigChangeType'),
    name VARCHAR(256) NOT NULL);

CREATE SEQUENCE SUnifiedConversionType INCREMENT BY 1 START WITH 1000;

CREATE TABLE UnifiedConversionType (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SUnifiedConversionType'),
    name VARCHAR(256) NOT NULL);

CREATE SEQUENCE SVnxInstallProtocolType INCREMENT BY 1 START WITH 1000;

CREATE TABLE VnxInstallProtocolType (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SVnxInstallProtocolType'),
    name VARCHAR(256) NOT NULL);

CREATE SEQUENCE STestAcceptancePlanType INCREMENT BY 1 START WITH 1000;

CREATE TABLE TestAcceptancePlanType (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('STestAcceptancePlanType'),
    name VARCHAR(256) NOT NULL);

CREATE SEQUENCE SMvConnectionType INCREMENT BY 1 START WITH 1000;

CREATE TABLE MvConnectionType (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SMvConnectionType'),
    name VARCHAR(256) NOT NULL);

CREATE SEQUENCE SGatewayStorageType INCREMENT BY 1 START WITH 1000;

CREATE TABLE GatewayStorageType (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SGatewayStorageType'),
    name VARCHAR(256) NOT NULL);

CREATE SEQUENCE SKnowledgeTransferLevel INCREMENT BY 1 START WITH 1000;

CREATE TABLE KnowledgeTransferLevel (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SKnowledgeTransferLevel'),
    name VARCHAR(256) NOT NULL);

CREATE SEQUENCE SDocumentationLevel INCREMENT BY 1 START WITH 1000;

CREATE TABLE DocumentationLevel (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SDocumentationLevel'),
    name VARCHAR(256) NOT NULL);

CREATE SEQUENCE SScriptingLevel INCREMENT BY 1 START WITH 1000;

CREATE TABLE ScriptingLevel (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SScriptingLevel'),
    name VARCHAR(256) NOT NULL);

CREATE SEQUENCE SClearanceLevel INCREMENT BY 1 START WITH 1000;

CREATE TABLE ClearanceLevel (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SClearanceLevel'),
    name VARCHAR(256) NOT NULL);

CREATE SEQUENCE SRiskLevel INCREMENT BY 1 START WITH 1000;

CREATE TABLE RiskLevel (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SRiskLevel'),
    name VARCHAR(256) NOT NULL,
    code VARCHAR(10) NOT NULL);

CREATE SEQUENCE SNetworkLinkStatus INCREMENT BY 1 START WITH 1000;

CREATE TABLE NetworkLinkStatus (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SNetworkLinkStatus'),
    name VARCHAR(256) NOT NULL);

CREATE SEQUENCE SMeetingStatus INCREMENT BY 1 START WITH 1000;

CREATE TABLE MeetingStatus (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SMeetingStatus'),
    name VARCHAR(256) NOT NULL);

CREATE SEQUENCE SPushPullOption INCREMENT BY 1 START WITH 1000;

CREATE TABLE PushPullOption (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SPushPullOption'),
    name VARCHAR(256) NOT NULL);

CREATE SEQUENCE SRackAndStackOption INCREMENT BY 1 START WITH 1000;

CREATE TABLE RackAndStackOption (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SRackAndStackOption'),
    name VARCHAR(256) NOT NULL);

CREATE SEQUENCE SBcvCloneOption INCREMENT BY 1 START WITH 1000;

CREATE TABLE BcvCloneOption (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SBcvCloneOption'),
    name VARCHAR(256) NOT NULL);

CREATE SEQUENCE SPostSalesCompletionQualifier INCREMENT BY 1 START WITH 1000;

CREATE TABLE PostSalesCompletionQualifier (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SPostSalesCompletionQualifier'),
    name VARCHAR(256) NOT NULL);

CREATE SEQUENCE SMvMode INCREMENT BY 1 START WITH 1000;

CREATE TABLE MvMode (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SMvMode'),
    name VARCHAR(256) NOT NULL);

CREATE SEQUENCE SArrayModel INCREMENT BY 1 START WITH 1000;

CREATE TABLE ArrayModel (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SArrayModel'),
    name VARCHAR(256) NOT NULL);

CREATE SEQUENCE SIOInterfaceModule INCREMENT BY 1 START WITH 1000;

CREATE TABLE IOInterfaceModule (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SIOInterfaceModule'),
    name VARCHAR(256) NOT NULL);

CREATE SEQUENCE SEmcMigrationInvolvement INCREMENT BY 1 START WITH 1000;

CREATE TABLE EmcMigrationInvolvement (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SEmcMigrationInvolvement'),
    name VARCHAR(256) NOT NULL);

CREATE SEQUENCE SSymmetrixModel INCREMENT BY 1 START WITH 1000;

CREATE TABLE SymmetrixModel (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SSymmetrixModel'),
    name VARCHAR(256) NOT NULL);

CREATE SEQUENCE SMigrationTestNumber INCREMENT BY 1 START WITH 1000;

CREATE TABLE MigrationTestNumber (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SMigrationTestNumber'),
    name VARCHAR(256) NOT NULL);

CREATE SEQUENCE SHostSoftwareInstaller INCREMENT BY 1 START WITH 1000;

CREATE TABLE HostSoftwareInstaller (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SHostSoftwareInstaller'),
    name VARCHAR(256) NOT NULL);

CREATE SEQUENCE SCelerraVnxModel INCREMENT BY 1 START WITH 1000;

CREATE TABLE CelerraVnxModel (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SCelerraVnxModel'),
    name VARCHAR(256) NOT NULL);

CREATE SEQUENCE SMigrationMethod INCREMENT BY 1 START WITH 1000;

CREATE TABLE MigrationMethod (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SMigrationMethod'),
    name VARCHAR(256) NOT NULL);

CREATE SEQUENCE SCelerraModel INCREMENT BY 1 START WITH 1000;

CREATE TABLE CelerraModel (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SCelerraModel'),
    name VARCHAR(256) NOT NULL);

CREATE SEQUENCE SVNXProtocol INCREMENT BY 1 START WITH 1000;

CREATE TABLE VNXProtocol (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SVNXProtocol'),
    name VARCHAR(256) NOT NULL);

CREATE SEQUENCE SEnvironmentGatherer INCREMENT BY 1 START WITH 1000;

CREATE TABLE EnvironmentGatherer (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SEnvironmentGatherer'),
    name VARCHAR(256) NOT NULL);

CREATE SEQUENCE SSrdfMode INCREMENT BY 1 START WITH 1000;

CREATE TABLE SrdfMode (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SSrdfMode'),
    name VARCHAR(256) NOT NULL);

CREATE SEQUENCE SMigrationWorker INCREMENT BY 1 START WITH 1000;

CREATE TABLE MigrationWorker (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SMigrationWorker'),
    name VARCHAR(256) NOT NULL);

CREATE SEQUENCE SSanImplementator INCREMENT BY 1 START WITH 1000;

CREATE TABLE SanImplementator (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SSanImplementator'),
    name VARCHAR(256) NOT NULL);

CREATE SEQUENCE SVolumeSizeChange INCREMENT BY 1 START WITH 1000;

CREATE TABLE VolumeSizeChange (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SVolumeSizeChange'),
    name VARCHAR(256) NOT NULL);

CREATE SEQUENCE SRepManagerImplementation INCREMENT BY 1 START WITH 1000;

CREATE TABLE RepManagerImplementation (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SRepManagerImplementation'),
    name VARCHAR(256) NOT NULL);

CREATE SEQUENCE SRepManagerProductSpecificPrep INCREMENT BY 1 START WITH 1000;

CREATE TABLE RepManagerProductSpecificPrep (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SRepManagerProductSpecificPrep'),
    name VARCHAR(256) NOT NULL);

CREATE SEQUENCE SSowLanguage INCREMENT BY 1 START WITH 1000;

CREATE TABLE SowLanguage (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SSowLanguage'),
    name VARCHAR(256) NOT NULL);

CREATE SEQUENCE STargetCelerra INCREMENT BY 1 START WITH 1000;

CREATE TABLE TargetCelerra (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('STargetCelerra'),
    name VARCHAR(256) NOT NULL);

CREATE SEQUENCE SSynchronousMode INCREMENT BY 1 START WITH 1000;

CREATE TABLE SynchronousMode (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SSynchronousMode'),
    name VARCHAR(256) NOT NULL);

CREATE SEQUENCE SReplicationFailoverLevel INCREMENT BY 1 START WITH 1000;

CREATE TABLE ReplicationFailoverLevel (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SReplicationFailoverLevel'),
    name VARCHAR(256) NOT NULL);

CREATE SEQUENCE SReplicationManagerInformation INCREMENT BY 1 START WITH 1000;

CREATE TABLE ReplicationManagerInformation (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SReplicationManagerInformation'),
    knowledge_transfer_hours VARCHAR(256),
    time_finder_managed BOOLEAN,
    open_replicator_managed BOOLEAN,
    snap_view_managed BOOLEAN,
    recover_point_managed BOOLEAN,
    san_copy_managed BOOLEAN,
    celerra_managed BOOLEAN,
    snap_sure_managed BOOLEAN,
    replication_installed BOOLEAN,
    rep_man_implementation_id BIGINT,
    rep_man_prod_specific_prep_id BIGINT,
    replicated_storage_size INT,
    nr_of_replicas INT,
    nr_of_replicated_apps INT,
    nr_of_replication_jobs INT,
    config_change_type_id BIGINT,
    manager_servers_number INT,
    clustered_rm_server_option BOOLEAN,
    include_app_integration BOOLEAN,
    custom_scripting_required BOOLEAN,
    FOREIGN KEY (rep_man_implementation_id) REFERENCES RepManagerImplementation (id),
    FOREIGN KEY (rep_man_prod_specific_prep_id) REFERENCES RepManagerProductSpecificPrep (id),
    FOREIGN KEY (config_change_type_id) REFERENCES ConfigChangeType (id));

CREATE TABLE RepManagerInformation_SHN (
    rep_man_information_int BIGINT,
    map_key VARCHAR(256),
    map_value INT,
    FOREIGN KEY (rep_man_information_int) REFERENCES ReplicationManagerInformation (id));

CREATE TABLE RepManagerInformation_THN (
    rep_man_information_int BIGINT,
    map_key VARCHAR(256),
    map_value INT,
    FOREIGN KEY (rep_man_information_int) REFERENCES ReplicationManagerInformation (id));

CREATE SEQUENCE STimeFinderInformation INCREMENT BY 1 START WITH 1000;

CREATE TABLE TimeFinderInformation (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('STimeFinderInformation'),
    knowledge_transfer_hours VARCHAR(256),
    bcv_to_implement BOOLEAN,
    clone_to_implement BOOLEAN,
    snap_to_implement BOOLEAN,
    vp_snap_to_implement BOOLEAN,
    config_change_type_id BIGINT,
    replicated_storage_size INT,
    nr_of_clone_copies INT,
    nr_of_bcv_copies INT,
    nr_of_snaps_copies INT,
    nr_of_vp_snaps_copies INT,
    nr_of_solution_enabler_hosts INT,
    nr_of_clone_pairs INT,
    scripting_level_id BIGINT,
    area_sizing_type_id BIGINT,
    FOREIGN KEY (config_change_type_id) REFERENCES ConfigChangeType (id),
    FOREIGN KEY (scripting_level_id) REFERENCES ScriptingLevel (id),
    FOREIGN KEY (area_sizing_type_id) REFERENCES AreaSizingType (id));

CREATE TABLE TimeFinderInformation_HN (
    time_finder_information_int BIGINT,
    map_key VARCHAR(256),
    map_value INT,
    FOREIGN KEY (time_finder_information_int) REFERENCES TimeFinderInformation (id));

CREATE SEQUENCE SSnapViewInformation INCREMENT BY 1 START WITH 1000;

CREATE TABLE SnapViewInformation (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SSnapViewInformation'),
    knowledge_transfer_hours VARCHAR(256),
    replicated_storage_size INT,
    snap_view_func_required BOOLEAN,
    snap_shot_view_func_required BOOLEAN,
    nr_of_vnx_arrays INT,
    nr_of_vnx_snapshots_copies INT,
    nr_of_snap_view_clones_copies INT,
    scripting_level_id BIGINT,
    nr_of_consistent_sessions INT,
    nr_of_persistent_sessions INT,
    FOREIGN KEY (scripting_level_id) REFERENCES ScriptingLevel (id));

CREATE TABLE SnapViewInformation_HN (
    snap_view_information_int BIGINT,
    map_key VARCHAR(256),
    map_value INT,
    FOREIGN KEY (snap_view_information_int) REFERENCES SnapViewInformation (id));

CREATE SEQUENCE SBCServicesScope INCREMENT BY 1 START WITH 1000;

CREATE TABLE BCServicesScope (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SBCServicesScope'),
    srdf BOOLEAN,
    time_finder BOOLEAN,
    mirrow_view BOOLEAN,
    snap_view BOOLEAN,
    replication_services BOOLEAN);

CREATE SEQUENCE SOpenReplicator INCREMENT BY 1 START WITH 1000;

CREATE TABLE OpenReplicator (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SOpenReplicator'),
    knowledge_transfer_hours VARCHAR(256),
    post_sales_compl_qualifier_id BIGINT,
    FOREIGN KEY (post_sales_compl_qualifier_id) REFERENCES PostSalesCompletionQualifier (id));

CREATE SEQUENCE SSrdfInformation INCREMENT BY 1 START WITH 1000;

CREATE TABLE SrdfInformation (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SSrdfInformation'),
    knowledge_transfer_hours VARCHAR(256),
    srdfs_functionality_required BOOLEAN,
    srdfa_functionality_required BOOLEAN,
    casc_srdf_func_required BOOLEAN,
    srdf_star_func_required BOOLEAN,
    concurrent_srdf_func_required BOOLEAN,
    network_link_status_id BIGINT,
    srdf_static_dynamic_type_id BIGINT,
    bc_practive_script_level2_id BIGINT,
    emc_map_points_option BOOLEAN,
    srdf_ce BOOLEAN,
    num_symm_directors_fa2ra_conv INT,
    num_symm_ra_directors_compres INT,
    num_symm_gigabit_ethernet_dir INT,
    FOREIGN KEY (network_link_status_id) REFERENCES NetworkLinkStatus (id),
    FOREIGN KEY (srdf_static_dynamic_type_id) REFERENCES SrdfStaticDynamicType (id),
    FOREIGN KEY (bc_practive_script_level2_id) REFERENCES ScriptingLevel (id));

CREATE TABLE SrdfInformation_sourceArray (
    srdf_information_id BIGINT NOT NULL,
    symmetrix_model_id BIGINT,
    srdf_installed_status BOOLEAN,
    replicate_size INT,
    nr_of_symm_rdf_devices INT,
    nr_of_symm_devices_rdf_sites INT,
    uni_option_enabled BOOLEAN,
    nr_of_rdf_pairs INT,
    nr_of_rdf_groups INT,
    srdf_connection_type_id BIGINT,
    FOREIGN KEY (symmetrix_model_id) REFERENCES SymmetrixModel (id),
    FOREIGN KEY (srdf_connection_type_id) REFERENCES SrdfConnectionType (id),
    FOREIGN KEY (srdf_information_id) REFERENCES SrdfInformation (id));

CREATE TABLE SrdfInformation_targetArray (
    srdf_information_id BIGINT NOT NULL,
    symmetrix_model_id BIGINT,
    srdf_installed_status BOOLEAN,
    time_finder INT,
    bcv_clones_number INT,
    tf_backup BOOLEAN,
    source_name VARCHAR(256),
    include_bandwidth_analysis BOOLEAN,
    include_network_assessement BOOLEAN,
    nr_of_hosts_needed INT,
    nr_of_device_composite_groups INT,
    FOREIGN KEY (symmetrix_model_id) REFERENCES SymmetrixModel (id),
    FOREIGN KEY (srdf_information_id) REFERENCES SrdfInformation (id));

CREATE TABLE SrdfInformation_hostNumbers (
    srdf_information_id BIGINT,
    map_key VARCHAR(256),
    map_value INT,
    FOREIGN KEY (srdf_information_id) REFERENCES SrdfInformation (id));

CREATE SEQUENCE SMirrorViewInformation INCREMENT BY 1 START WITH 1000;

CREATE TABLE MirrorViewInformation (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SMirrorViewInformation'),
    knowledge_transfer_hours VARCHAR(256),
    mirror_views_func_required BOOLEAN,
    mirror_viewa_func_required BOOLEAN,
    mirror_viewce_func_required BOOLEAN,
    network_link_status_id BIGINT,
    mirrow_view_script_level_id BIGINT,
    custom_scripting_details VARCHAR(256),
    nr_of_consistency_groups INT,
    nr_of_remote_mirrors INT,
    nr_of_secondary_images_created INT,
    FOREIGN KEY (network_link_status_id) REFERENCES NetworkLinkStatus (id),
    FOREIGN KEY (mirrow_view_script_level_id) REFERENCES ScriptingLevel (id));

CREATE TABLE MirrorViewInformation_SA (
    mirror_view_information_id BIGINT NOT NULL,
    array_model_id BIGINT,
    existing_option_enabled BOOLEAN,
    mirrow_view_installed_status BOOLEAN,
    replicate_size INT,
    uni_option_enabled BOOLEAN,
    mv_connection_type_id BIGINT,
    FOREIGN KEY (array_model_id) REFERENCES ArrayModel (id),
    FOREIGN KEY (mv_connection_type_id) REFERENCES MvConnectionType (id),
    FOREIGN KEY (mirror_view_information_id) REFERENCES MirrorViewInformation (id));

CREATE TABLE MirrorViewInformation_TA (
    mirror_view_information_id BIGINT NOT NULL,
    array_model_id BIGINT,
    new_mv_mode_id BIGINT,
    existing_option_enabled BOOLEAN,
    mirrow_view_installed_status BOOLEAN,
    FOREIGN KEY (array_model_id) REFERENCES ArrayModel (id),
    FOREIGN KEY (new_mv_mode_id) REFERENCES MvMode (id),
    FOREIGN KEY (mirror_view_information_id) REFERENCES MirrorViewInformation (id));

CREATE TABLE MirrorViewInformation_HN (
    mirror_view_information_id BIGINT,
    map_key VARCHAR(256),
    map_value INT,
    FOREIGN KEY (mirror_view_information_id) REFERENCES MirrorViewInformation (id));

CREATE SEQUENCE SBcRequestData INCREMENT BY 1 START WITH 1000;

CREATE TABLE BcRequestData (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SBcRequestData'),
    general_comment VARCHAR(256),
    knowledge_transfer_days VARCHAR(256),
    services_scope_id BIGINT,
    srdf_information_id BIGINT,
    time_finder_information_id BIGINT,
    mirror_view_information_id BIGINT,
    snap_view_information_id BIGINT,
    repl_manager_information_id BIGINT,
    nas_ip_repl_knowl_trans_days VARCHAR(256),
    FOREIGN KEY (services_scope_id) REFERENCES BCServicesScope (id),
    FOREIGN KEY (srdf_information_id) REFERENCES SrdfInformation (id),
    FOREIGN KEY (time_finder_information_id) REFERENCES TimeFinderInformation (id),
    FOREIGN KEY (mirror_view_information_id) REFERENCES MirrorViewInformation (id),
    FOREIGN KEY (snap_view_information_id) REFERENCES SnapViewInformation (id),
    FOREIGN KEY (repl_manager_information_id) REFERENCES ReplicationManagerInformation (id));

CREATE SEQUENCE SCifsFeature INCREMENT BY 1 START WITH 1000;

CREATE TABLE CifsFeature (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SCifsFeature'),
    gpo_required BOOLEAN,
    local_users_groups_required BOOLEAN,
    dfs_roots_servers_required BOOLEAN,
    wide_links_required BOOLEAN,
    file_extension_required BOOLEAN,
    ext_user_mappings_required BOOLEAN);

CREATE SEQUENCE SNasFeature INCREMENT BY 1 START WITH 1000;

CREATE TABLE NasFeature (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SNasFeature'),
    advanced_file_system_features BOOLEAN,
    advanced_networking_features BOOLEAN,
    advanced_storage_features BOOLEAN,
    backup BOOLEAN,
    vee BOOLEAN,
    vnx_file_mover BOOLEAN,
    ftp BOOLEAN,
    vnx_data_deduplication BOOLEAN,
    iscsi BOOLEAN,
    vnx_mpfs BOOLEAN,
    vnx_quotas BOOLEAN,
    vnx_replicator BOOLEAN,
    vnx_iscsi_replicator BOOLEAN,
    vnx_administrative_security BOOLEAN,
    vnx_snap_sure BOOLEAN);

CREATE SEQUENCE SUnifiedServicesScope INCREMENT BY 1 START WITH 1000;

CREATE TABLE UnifiedServicesScope (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SUnifiedServicesScope'),
    celerra_implementation BOOLEAN,
    nas_health_check BOOLEAN,
    file_nas_migration BOOLEAN,
    mpfs BOOLEAN,
    nas_srdf_replication BOOLEAN,
    mdl_dlm BOOLEAN,
    nas_ip_replication BOOLEAN);

CREATE SEQUENCE SNasMigrationInformation INCREMENT BY 1 START WITH 1000;

CREATE TABLE NasMigrationInformation (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SNasMigrationInformation'),
    location VARCHAR(256),
    average_file_size INT,
    cifs_data_size INT,
    cifs_file_system_number INT,
    cifs_local_group_option BOOLEAN,
    nfs_data_size_number INT,
    nfs_file_system_number INT,
    bimodal_data_size_number INT,
    bimodal_file_system_number INT,
    certified_data_migr_option BOOLEAN,
    migration_window_length INT,
    migr_windows_customer_number INT,
    celerra_vnx_model_id BIGINT,
    target_celerra_id BIGINT,
    migration_method_id BIGINT,
    FOREIGN KEY (celerra_vnx_model_id) REFERENCES CelerraVnxModel (id),
    FOREIGN KEY (target_celerra_id) REFERENCES TargetCelerra (id),
    FOREIGN KEY (migration_method_id) REFERENCES MigrationMethod (id));

CREATE SEQUENCE SCelerraDetailInformation INCREMENT BY 1 START WITH 1000;

CREATE TABLE CelerraDetailInformation (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SCelerraDetailInformation'),
    celerra_model_id BIGINT,
    vnx_protocol_id BIGINT,
    celerra_location VARCHAR(256),
    new_celerra_option BOOLEAN,
    disk_array_enclosures_incl BOOLEAN,
    rack_and_stack_option_id BIGINT,
    gateway_storage_type_id BIGINT,
    new_symmetrix_storage_option BOOLEAN,
    dual_control_stations_used BOOLEAN,
    datamovers_number INT,
    file_fast_vp_configured BOOLEAN,
    usable_storage_size INT,
    file_system_number INT,
    nfs_configured BOOLEAN,
    cifs_configured BOOLEAN,
    multi_protocol_celerra_conf BOOLEAN,
    nas_features_id BIGINT,
    cifs_features_included BOOLEAN,
    ldap_required BOOLEAN,
    nfsv4_configured BOOLEAN,
    include_nfs_over_fc BOOLEAN,
    include_nfs_over_iscsi BOOLEAN,
    ip_replication_configured BOOLEAN,
    deinstall_celera BOOLEAN,
    cava_server_number INT,
    mpfs_required BOOLEAN,
    mpfs_host_quantity INT,
    mpfs_file_systems_quantity INT,
    mpfsi_required BOOLEAN,
    mpfsi_host_quantity INT,
    mpfsi_file_systems_quantity INT,
    file_servers_number INT,
    file_systems_number INT,
    cifs_file_servers_number INT,
    cifs_file_shares_number INT,
    nfs_file_systems_conf_number INT,
    nfs_fs_export_number INT,
    io_interface_module_id BIGINT,
    FOREIGN KEY (celerra_model_id) REFERENCES CelerraModel (id),
    FOREIGN KEY (vnx_protocol_id) REFERENCES CelerraModel (id),
    FOREIGN KEY (rack_and_stack_option_id) REFERENCES RackAndStackOption (id),
    FOREIGN KEY (gateway_storage_type_id) REFERENCES GatewayStorageType (id),
    FOREIGN KEY (nas_features_id) REFERENCES NasFeature (id),
    FOREIGN KEY (io_interface_module_id) REFERENCES IOInterfaceModule (id));

CREATE SEQUENCE SNasIpReplicationInformation INCREMENT BY 1 START WITH 1000;

CREATE TABLE NasIpReplicationInformation (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SNasIpReplicationInformation'),
    new_file_system_repl_number INT,
    replicated_data_size INT,
    vnx_array VARCHAR(256),
    include_local_replication BOOLEAN,
    include_remote_replication BOOLEAN,
    nr_of_cifs_file_systems INT,
    tb_of_cifs_file_systems INT,
    nr_of_nfs_file_systems INT,
    tb_of_nfs_file_systems INT,
    celerra_device_type VARCHAR(256));

CREATE SEQUENCE SUnifiedRequestData INCREMENT BY 1 START WITH 1000;

CREATE TABLE UnifiedRequestData (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SUnifiedRequestData'),
    general_comment VARCHAR(256),
    cele_detail_know_trans_days VARCHAR(256),
    nas_migr_knowledge_trans_days VARCHAR(256),
    nas_srdf_repl_know_trans_days VARCHAR(256),
    mdl_dlm_knowl_trans_days VARCHAR(256),
    include_unified_home_dirs BOOLEAN,
    include_unified_virtual_dm BOOLEAN,
    services_scope_id BIGINT,
    FOREIGN KEY (services_scope_id) REFERENCES UnifiedServicesScope (id));

CREATE TABLE UnifiedRequestData_celerraDI (
    unified_request_data_id BIGINT NOT NULL,
    celerra_detail_information_id BIGINT NOT NULL,
    FOREIGN KEY (unified_request_data_id) REFERENCES UnifiedRequestData (id),
    FOREIGN KEY (celerra_detail_information_id) REFERENCES CelerraDetailInformation (id));

CREATE TABLE UnifiedRequestData_nasMI (
    unified_request_data_id BIGINT NOT NULL,
    nas_migration_information_id BIGINT NOT NULL,
    FOREIGN KEY (unified_request_data_id) REFERENCES UnifiedRequestData (id),
    FOREIGN KEY (nas_migration_information_id) REFERENCES NasMigrationInformation (id));

CREATE TABLE BcRequestData_nasIpRI (
    bc_request_data_id BIGINT NOT NULL,
    nas_ip_repl_information_id BIGINT NOT NULL,
    FOREIGN KEY (bc_request_data_id) REFERENCES BcRequestData (id),
    FOREIGN KEY (nas_ip_repl_information_id) REFERENCES NasIpReplicationInformation (id));

CREATE SEQUENCE SSanTanInformation INCREMENT BY 1 START WITH 1000;

CREATE TABLE SanTanInformation (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SSanTanInformation'),
    knowledge_transfer_hours VARCHAR(256),
    san_migration_in_scope_option BOOLEAN,
    total_ports_to_migrate INT,
    san_directors_number INT,
    san_switches_number INT,
    blades_number INT,
    fcoe_switches_number INT,
    fcoe_vlan_number INT,
    fcoe_channel_number INT,
    san_extension_devices_number INT,
    nas_to_cx_units_number INT,
    nas_to_symmetrix_units_number INT,
    nas_to_cx_hosts_number INT,
    nas_to_symmetrix_hosts_number INT,
    verify_major_outage_conn_hn INT,
    deinst_san_directors_number INT,
    deinst_san_switches_number INT,
    deinst_san_extension_dn INT);

CREATE SEQUENCE SDataMigrationInformation INCREMENT BY 1 START WITH 1000;

CREATE TABLE DataMigrationInformation (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SDataMigrationInformation'),
    knowledge_transfer_hours VARCHAR(256),
    migration_worker_id BIGINT,
    migr_luns_to_symmetrix_option BOOLEAN,
    migr_luns_to_clariion_option BOOLEAN,
    symm_volume_size_change_id BIGINT,
    clar_volume_size_change_id BIGINT,
    emc_migration_involvement_id BIGINT,
    weekend_maintenance_hours INT,
    migr_cutover_hosts_number INT,
    migr_cutover_tests_number INT,
    migr_cutover_events_number INT,
    script_adjustment_option BOOLEAN,
    weekend_migrations_number INT,
    include_eca BOOLEAN,
    include_storage_data_erasure BOOLEAN,
    remove_relocate_emc_storage BOOLEAN,
    proposed_migration_tools VARCHAR(256),
    FOREIGN KEY (migration_worker_id) REFERENCES MigrationWorker (id),
    FOREIGN KEY (symm_volume_size_change_id) REFERENCES VolumeSizeChange (id),
    FOREIGN KEY (clar_volume_size_change_id) REFERENCES VolumeSizeChange (id),
    FOREIGN KEY (emc_migration_involvement_id) REFERENCES EmcMigrationInvolvement (id));

CREATE TABLE DataMigInformationn_array (
    data_migration_information_id BIGINT,
    array_type_id BIGINT,
    location VARCHAR(256),
    number_non_esx_hosts INT,
    number_esx_hosts INT,
    number_virtual_machines INT,
    swing_box BOOLEAN,
    array_type VARCHAR(256),
    capacity DOUBLE PRECISION,
    FOREIGN KEY (array_type_id) REFERENCES EnvironmentArrayType (id),
    FOREIGN KEY (data_migration_information_id) REFERENCES DataMigrationInformation (id));

CREATE SEQUENCE SEnvironmentDetailsInformation INCREMENT BY 1 START WITH 1000;

CREATE TABLE EnvironmentDetailsInformation (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SEnvironmentDetailsInformation'),
    environment_gatherer_id BIGINT,
    dca_appliances_number1 INT,
    host_software_installer_id BIGINT,
    san_implementator_id BIGINT,
    existing_san_fabrics_number INT,
    FOREIGN KEY (environment_gatherer_id) REFERENCES EnvironmentGatherer (id),
    FOREIGN KEY (host_software_installer_id) REFERENCES HostSoftwareInstaller (id),
    FOREIGN KEY (san_implementator_id) REFERENCES SanImplementator (id));

CREATE SEQUENCE SEnvDetailsInformation_exAT INCREMENT BY 1 START WITH 1000;

CREATE TABLE EnvDetailsInformation_exAT (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SEnvDetailsInformation_exAT'),
    env_details_information_id BIGINT,
    environment_array_type_id BIGINT,
    FOREIGN KEY (env_details_information_id) REFERENCES EnvironmentDetailsInformation (id),
    FOREIGN KEY (environment_array_type_id) REFERENCES EnvironmentArrayType (id));

CREATE SEQUENCE SEnvDetailsInformation_exSL INCREMENT BY 1 START WITH 1000;

CREATE TABLE EnvDetailsInformation_exSL (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SEnvDetailsInformation_exSL'),
    env_details_information_id BIGINT,
    value VARCHAR(256),
    FOREIGN KEY (env_details_information_id) REFERENCES EnvironmentDetailsInformation (id));

CREATE SEQUENCE SEnvDetailsInformation_UC INCREMENT BY 1 START WITH 1000;

CREATE TABLE EnvDetailsInformation_UC (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SEnvDetailsInformation_UC'),
    env_details_information_id BIGINT,
    value DOUBLE PRECISION,
    FOREIGN KEY (env_details_information_id) REFERENCES EnvironmentDetailsInformation (id));

CREATE SEQUENCE SEnvDetailsInformation_NAH INCREMENT BY 1 START WITH 1000;

CREATE TABLE EnvDetailsInformation_NAH (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SEnvDetailsInformation_NAH'),
    env_details_information_id BIGINT,
    value INT,
    FOREIGN KEY (env_details_information_id) REFERENCES EnvironmentDetailsInformation (id));

CREATE SEQUENCE SEnvDetailsInformation_EDT INCREMENT BY 1 START WITH 1000;

CREATE TABLE EnvDetailsInformation_EDT (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SEnvDetailsInformation_EDT'),
    env_details_information_id BIGINT,
    environment_device_type_id BIGINT,
    FOREIGN KEY (env_details_information_id) REFERENCES EnvironmentDetailsInformation (id),
    FOREIGN KEY (environment_device_type_id) REFERENCES EnvironmentDeviceType (id));

CREATE SEQUENCE SEnvDetailsInformation_exSanLo INCREMENT BY 1 START WITH 1000;

CREATE TABLE EnvDetailsInformation_exSanLo (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SEnvDetailsInformation_exSanLo'),
    env_details_information_id BIGINT,
    value VARCHAR(256),
    FOREIGN KEY (env_details_information_id) REFERENCES EnvironmentDetailsInformation (id));

CREATE SEQUENCE SEnvDetailsInformation_man INCREMENT BY 1 START WITH 1000;

CREATE TABLE EnvDetailsInformation_man (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SEnvDetailsInformation_man'),
    env_details_information_id BIGINT,
    value VARCHAR(256),
    FOREIGN KEY (env_details_information_id) REFERENCES EnvironmentDetailsInformation (id));

CREATE SEQUENCE SEnvDetailsInformation_devQ INCREMENT BY 1 START WITH 1000;

CREATE TABLE EnvDetailsInformation_devQ (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SEnvDetailsInformation_devQ'),
    env_details_information_id BIGINT,
    value DOUBLE PRECISION,
    FOREIGN KEY (env_details_information_id) REFERENCES EnvironmentDetailsInformation (id));

CREATE SEQUENCE SEnvDetailsInformation_hostIn INCREMENT BY 1 START WITH 1000;
CREATE TABLE EnvDetailsInformation_hostIn (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SEnvDetailsInformation_hostIn'),
    env_details_information_id BIGINT,
    platform VARCHAR(256),
    host_number INT,
    new_host_number INT,
    number_of_clusters INT,
    number_boot_from_san INT,
    array_host_attached_to VARCHAR(256),
    FOREIGN KEY (env_details_information_id) REFERENCES EnvironmentDetailsInformation (id));

CREATE SEQUENCE SSymmetrixMF INCREMENT BY 1 START WITH 1000;
CREATE TABLE SymmetrixMF (
  id                           BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SSymmetrixMF'),
  knowledge_transfer_hours     VARCHAR(256),
  vmax_arrays_number           INT,
  dmx_arrays_number            INT,
  vmax_arrays_upgrade_number   INT,
  dmx_arrays_upgrade_number    INT,
  srdf_arrays_number           INT,
  srdfa_arrays_number          INT,
  virtual_prov_arrays_number   INT,
  thin_devices_host_number     INT,
  lun_to_dmx_host_number       INT,
  auto_prov_to_dmx_host_number INT,
  advanced_fast_arrays_number  INT,
  deinst_open_sys_vmax_number  INT,
  vmax_arrays_num              INT,
  vmax_groups_num              INT,
  vmax_combinations_num        INT,
  vmax_tiers_num               INT,
  vmax_policies_num            INT,
  vmax_performance_windows_num INT,
  vmax_dm_windows_num          INT,
  vmax_add_h_cr_dev_tests_num  INT,
  vmax_add_h_exe_dev_tests_num INT,
  vp_storage_groups_num        INT,
  vp_disk_combinations_num     INT,
  tdev_num                     INT,
  tdat_num                     INT,
  vp_thin_pools_num            INT,
  fast_vp_perf_time_windows_num INT,
  fast_vp_move_time_windows_num INT,
  fast_vp_tiers_num            INT,
  fast_vp_policies_num         INT,
  engagement_adding_fast_vp    BOOLEAN);

CREATE SEQUENCE SSymmetrixOS INCREMENT BY 1 START WITH 1000;
CREATE TABLE SymmetrixOS (
  id                           BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SSymmetrixOS'),
  knowledge_transfer_hours     VARCHAR(256),
  vmax_arrays_number           INT,
  dmx_arrays_number            INT,
  vmax_arrays_upgrade_number   INT,
  dmx_arrays_upgrade_number    INT,
  srdf_arrays_number           INT,
  srdfa_arrays_number          INT,
  virtual_prov_arrays_number   INT,
  thin_devices_host_number     INT,
  lun_to_dmx_host_number       INT,
  auto_prov_to_dmx_host_number INT,
  advanced_fast_arrays_number  INT,
  deinst_open_sys_vmax_number  INT,
  vmax_arrays_num              INT,
  vmax_groups_num              INT,
  vmax_combinations_num        INT,
  vmax_tiers_num               INT,
  vmax_policies_num            INT,
  vmax_performance_windows_num INT,
  vmax_dm_windows_num          INT,
  vmax_add_h_cr_dev_tests_num  INT,
  vmax_add_h_exe_dev_tests_num INT,
  vp_storage_groups_num        INT,
  vp_disk_combinations_num     INT,
  tdev_num                     INT,
  tdat_num                     INT,
  vp_thin_pools_num            INT,
  fast_vp_perf_time_windows_num INT,
  fast_vp_move_time_windows_num INT,
  fast_vp_tiers_num            INT,
  fast_vp_policies_num         INT,
  engagement_adding_fast_vp    BOOLEAN);

CREATE SEQUENCE SVnxClariionInformation INCREMENT BY 1 START WITH 1000;

CREATE TABLE VnxClariionInformation (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SVnxClariionInformation'),
    knowledge_transfer_hours VARCHAR(256),
    virtual_prov_arrays_number INT,
    vnx_arrays_number INT,
    unisphere_domains_number INT,
    fast_cache_setup_number INT,
    cert_disk_erasure_arrays_num INT,
    deinstall_cx_ns_vnx_number INT,
    vnx_clariion_install_type_id BIGINT,
    unified_conversions_required BOOLEAN,
    unified_conversion_type_id BIGINT,
    health_check_required BOOLEAN,
    sap_hana_required BOOLEAN,
    vnx_install_protocol_type_id BIGINT,
    vnx_install_prot_sub_type_id BIGINT,
    vnx_mon_reporting_required BOOLEAN,
    fc_storage_conn_required BOOLEAN,
    fcoe_storage_conn_required BOOLEAN,
    iscsi_san_ext_stor_conn_req BOOLEAN,
    vsan_lsan_stor_conn_required BOOLEAN,
    fc_routing_stor_conn_required BOOLEAN,
    virtual_infr_enable_included BOOLEAN,
    watch4_net_included BOOLEAN,
    unified_local_protection BOOLEAN,
    unified_remote_protection BOOLEAN,
    unified_app_protection BOOLEAN,
    unified_fast_deployment BOOLEAN,
    unified_security_compliance BOOLEAN,
    unified_management_suite BOOLEAN,
    data_protection_advisor BOOLEAN,
    fast_lun_migrator BOOLEAN,
    mirror_view BOOLEAN,
    qos_manager BOOLEAN,
    replication_manager BOOLEAN,
    recover_point BOOLEAN,
    san_copy BOOLEAN,
    snap_view_vnx_snap_shots BOOLEAN,
    virtual_provisioning BOOLEAN,
    unisphere_analyzer BOOLEAN,
    unisphere_remote BOOLEAN,
    storage_analytics BOOLEAN,
    unified_file_oe_required BOOLEAN,
    dial_home_activities BOOLEAN,
    flash_stor_layout_services_id BIGINT,
    vnx_file_servers_number INT,
    total_storage_amount DOUBLE PRECISION,
    active_data_movers_number INT,
    control_stations_number INT,
    file_systems_number INT,
    avg_file_system_size VARCHAR(256),
    storage_pools_number INT,
    storage_groups_number INT,
    thin_luns_number INT,
    iscsi BOOLEAN,
    iscsi_required BOOLEAN,
    iscsi_host_quantity INT,
    ivnx_scsi_host_quantity INT,
    idart_scsi_host_quantity INT,
    FOREIGN KEY (vnx_clariion_install_type_id) REFERENCES VnxClariionInstallType (id),
    FOREIGN KEY (unified_conversion_type_id) REFERENCES UnifiedConversionType (id),
    FOREIGN KEY (vnx_install_protocol_type_id) REFERENCES VnxInstallProtocolType (id),
    FOREIGN KEY (vnx_install_prot_sub_type_id) REFERENCES VnxInstallProtocolSubType (id),
    FOREIGN KEY (flash_stor_layout_services_id) REFERENCES FlashStorageLayoutServices (id));

CREATE SEQUENCE SVplex INCREMENT BY 1 START WITH 1000;

CREATE TABLE Vplex (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SVplex'),
    knowledge_transfer_hours DECIMAL(20),
    sites_number INT,
    engine_number INT,
    directors_number INT,
    existing_c4_upgraded_number INT,
    virtual_volumes_number INT,
    mirrors_number INT,
    metro_clusters_number INT,
    geo_clusters_number INT,
    hosts_number INT,
    arrays_number INT,
    storage_ports_number INT,
    storage_volumes_number INT,
    witness_server_number INT,
    data_mobility_type_id BIGINT,
    data_mobility_jobs_number INT,
    encapsulated_hosts_number INT,
    emc_installed_option BOOLEAN,
    recoverpoint_installed_option BOOLEAN,
    FOREIGN KEY (data_mobility_type_id) REFERENCES VplexDataMobilityType (id));

CREATE SEQUENCE SInfrastructureRequestData INCREMENT BY 1 START WITH 1000;

CREATE TABLE InfrastructureRequestData (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SInfrastructureRequestData'),
    general_comment VARCHAR(256),
    symmetrix_mf_service_enabled BOOLEAN,
    symmetrix_os_service_enabled BOOLEAN,
    data_migr_service_enabled BOOLEAN,
    vnx_clariion_service_enabled BOOLEAN,
    cx_repl_service_enabled BOOLEAN,
    san_ass_service_enabled BOOLEAN,
    array_health_check_service_en BOOLEAN,
    san_health_check_service_en BOOLEAN,
    vplex_service_enabled BOOLEAN,
    env_details_information_id BIGINT,
    vnx_clariion_information_id BIGINT,
    data_migration_information_id BIGINT,
    open_replicator_id BIGINT,
    symmetrix_mf_id BIGINT,
    symmetrix_os_id BIGINT,
    vplex_id BIGINT,
    FOREIGN KEY (env_details_information_id) REFERENCES EnvironmentDetailsInformation (id),
    FOREIGN KEY (vnx_clariion_information_id) REFERENCES VnxClariionInformation (id),
    FOREIGN KEY (data_migration_information_id) REFERENCES DataMigrationInformation (id),
    FOREIGN KEY (open_replicator_id) REFERENCES OpenReplicator (id),
    FOREIGN KEY (symmetrix_mf_id) REFERENCES SymmetrixMF (id),
    FOREIGN KEY (symmetrix_os_id) REFERENCES SymmetrixOS (id),
    FOREIGN KEY (vplex_id) REFERENCES Vplex (id)
);

CREATE SEQUENCE SStringServiceData INCREMENT BY 1 START WITH 1000;

CREATE TABLE StringServiceData (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SStringServiceData'),
    service_name VARCHAR(256),
    description VARCHAR(256),
    value VARCHAR(256));

CREATE SEQUENCE SBooleanServiceData INCREMENT BY 1 START WITH 1000;

CREATE TABLE BooleanServiceData (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SBooleanServiceData'),
    service_name VARCHAR(256),
    description VARCHAR(256),
    enabled BOOLEAN);

CREATE SEQUENCE SMainframeServicesScope INCREMENT BY 1 START WITH 1000;

CREATE TABLE MainframeServicesScope (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SMainframeServicesScope'),
    data_analytics_healthcheck BOOLEAN,
    ezsm_ecc_info_mover BOOLEAN,
    dmx_vmax_data_migration BOOLEAN,
    dmx_vmax_hardware_impl BOOLEAN,
    dmx_vmax_srdf BOOLEAN,
    dmx_vmax_time_finder BOOLEAN,
    dmx_vmax_autoswap_gddr BOOLEAN,
    dlm_data_migration BOOLEAN,
    dlm_healthcheck BOOLEAN,
    dlm_custom_requirements BOOLEAN,
    dlm_implement_upgrade BOOLEAN,
    dlm_reconfigure_add_move BOOLEAN,
    dlm_scripting BOOLEAN,
    dlm_services BOOLEAN,
    dlm_implementation BOOLEAN);

CREATE SEQUENCE SMainframeRequestData INCREMENT BY 1 START WITH 1000;

CREATE TABLE MainframeRequestData (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SMainframeRequestData'),
    general_comment VARCHAR(256),
    services_scope_id BIGINT,
    FOREIGN KEY (services_scope_id) REFERENCES MainframeServicesScope (id));

CREATE TABLE MainframeReqData_booleanSD (
    mainframe_request_data_id BIGINT,
    boolean_service_data_id BIGINT,
    FOREIGN KEY (mainframe_request_data_id) REFERENCES MainframeRequestData (id),
    FOREIGN KEY (boolean_service_data_id) REFERENCES BooleanServiceData (id));

CREATE TABLE MainframeReqData_stringSD (
    mainframe_request_data_id BIGINT,
    string_service_data_id BIGINT,
    FOREIGN KEY (mainframe_request_data_id) REFERENCES MainframeRequestData (id),
    FOREIGN KEY (string_service_data_id) REFERENCES StringServiceData (id));

CREATE SEQUENCE SMSSFcAtaDrives INCREMENT BY 1 START WITH 1000;

CREATE TABLE MSSFcAtaDrives (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SMSSFcAtaDrives'),
    fc_ata_73gb VARCHAR(256),
    fc_ata_146gb VARCHAR(256),
    fc_ata_300gb VARCHAR(256),
    fc_ata_400gb VARCHAR(256),
    fc_ata_450gb VARCHAR(256),
    fc_ata_500gb VARCHAR(256),
    fc_ata_600gb VARCHAR(256),
    fc_ata_750gb VARCHAR(256),
    fc_ata_1tb VARCHAR(256),
    fc_ata_2tb VARCHAR(256),
    fc_ata_3tb_4g VARCHAR(256),
    fc_ata_other VARCHAR(256));

CREATE SEQUENCE SMSSFlashDrives INCREMENT BY 1 START WITH 1000;

CREATE TABLE MSSFlashDrives (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SMSSFlashDrives'),
    flash_73gb VARCHAR(256),
    flash_100gb VARCHAR(256),
    flash_146gb VARCHAR(256),
    flash_200gb VARCHAR(256),
    flash_400gb VARCHAR(256),
    flash_other VARCHAR(256));

CREATE SEQUENCE SMSSVnxSasDrives INCREMENT BY 1 START WITH 1000;

CREATE TABLE MSSVnxSasDrives (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SMSSVnxSasDrives'),
    vnx_sas_300gb VARCHAR(256),
    vnx_sas_25_inch_300gb VARCHAR(256),
    vnx_sas_600gb VARCHAR(256),
    vnx_sas_25_inch_600gb VARCHAR(256),
    vnx_sas_25_inch_900gb VARCHAR(256),
    vnx_sas_35_inch_900gb VARCHAR(256),
    vnx_sas_1tb VARCHAR(256),
    vnx_sas_2tb VARCHAR(256),
    vnx_sas_3tb VARCHAR(256),
    vnx_sas_100gb_flash VARCHAR(256),
    vnx_sas_200gb_flash VARCHAR(256),
    vnx_sas_other VARCHAR(256));

CREATE SEQUENCE SMSSClariionAx4Drives INCREMENT BY 1 START WITH 1000;

CREATE TABLE MSSClariionAx4Drives (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SMSSClariionAx4Drives'),
    clariion_ax4_sataii_500gb VARCHAR(256),
    clariion_ax4_sataii_750gb VARCHAR(256),
    clariion_ax4_sataii_1000gb VARCHAR(256),
    clariion_ax4_sas_146gb_15k VARCHAR(256),
    clariion_ax4_sas_300gb_15k VARCHAR(256),
    clariion_ax4_sas_400gb_15k VARCHAR(256),
    clariion_ax4_sas_450gb_10k VARCHAR(256),
    clariion_ax4_sas_600gb_10k VARCHAR(256),
    clariion_ax4_other VARCHAR(256));

CREATE SEQUENCE SMSSCenteraNodes INCREMENT BY 1 START WITH 1000;

CREATE TABLE MSSCenteraNodes (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SMSSCenteraNodes'),
    gen1_nodes_640gb VARCHAR(256),
    gen2_nodes_1tb VARCHAR(256),
    gen3_nodes_128tb VARCHAR(256),
    gen4_nodes_750gb VARCHAR(256),
    gen4_nodes_128tb VARCHAR(256),
    gen4_nodes_2tb VARCHAR(256),
    gen4_lp_nodes_1tb VARCHAR(256),
    gen4_lp_nodes_2tb VARCHAR(256),
    centera_nodes_other VARCHAR(256));

CREATE SEQUENCE SMSSAvamarNodes INCREMENT BY 1 START WITH 1000;

CREATE TABLE MSSAvamarNodes (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SMSSAvamarNodes'),
    storage_nodes_1tb VARCHAR(256),
    storage_nodes_2tb VARCHAR(256),
    storage_nodes_33tb VARCHAR(256),
    utility_nodes_gen1 VARCHAR(256),
    utility_nodes_gen2_gen3 VARCHAR(256),
    utility_nodes_gen4 VARCHAR(256),
    accelerator_nodes_gen1 VARCHAR(256),
    small_accelerator_nodes_gen2 VARCHAR(256),
    large_accelerator_nodes_gen2 VARCHAR(256),
    accelerator_nodes_gen3_gen4 VARCHAR(256),
    storage_nodes_13tb_gen4 VARCHAR(256),
    storage_nodes_26tb_gen4 VARCHAR(256),
    storage_nodes_39tb_gen4 VARCHAR(256),
    storage_nodes_78tb_gen4 VARCHAR(256),
    avamar_nodes_other VARCHAR(256));

CREATE SEQUENCE SMSSDataDomain INCREMENT BY 1 START WITH 1000;

CREATE TABLE MSSDataDomain (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SMSSDataDomain'),
    model_type VARCHAR(256),
    serial_number VARCHAR(256),
    num_retention_drives INT);

CREATE SEQUENCE SMSSAtmos INCREMENT BY 1 START WITH 1000;

CREATE TABLE MSSAtmos (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SMSSAtmos'),
    atmos_25_inch_250gb VARCHAR(256),
    atmos_1tb VARCHAR(256),
    atmos_2tb VARCHAR(256),
    atmos_3tb VARCHAR(256),
    atmos_other VARCHAR(256));

CREATE SEQUENCE SMSSGreenplum INCREMENT BY 1 START WITH 1000;

CREATE TABLE MSSGreenplum (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SMSSGreenplum'),
    greenplum_25_inch_600gb_10k VARCHAR(256),
    greenplum_35_inch_600gb_15k VARCHAR(256),
    greenplum_35_inch_2tb VARCHAR(256));

CREATE SEQUENCE SMSSArray INCREMENT BY 1 START WITH 1000;

CREATE TABLE MSSArray (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SMSSArray'),
    location VARCHAR(256),
    service_id BIGINT,
    platform_id BIGINT,
    fc_ata_drives_id BIGINT,
    flash_drives_id BIGINT,
    vnx_sas_drives_id BIGINT,
    clariion_ax4_drives_id BIGINT,
    centera_nodes_id BIGINT,
    avamar_nodes_id BIGINT,
    data_domain_id BIGINT,
    atmos_id BIGINT,
    greenplum_id BIGINT,
    FOREIGN KEY (service_id) REFERENCES MSSService (id),
    FOREIGN KEY (platform_id) REFERENCES MSSPlatform (id),
    FOREIGN KEY (fc_ata_drives_id) REFERENCES MSSFcAtaDrives (id),
    FOREIGN KEY (flash_drives_id) REFERENCES MSSFlashDrives (id),
    FOREIGN KEY (vnx_sas_drives_id) REFERENCES MSSVnxSasDrives (id),
    FOREIGN KEY (clariion_ax4_drives_id) REFERENCES MSSClariionAx4Drives (id),
    FOREIGN KEY (centera_nodes_id) REFERENCES MSSCenteraNodes (id),
    FOREIGN KEY (avamar_nodes_id) REFERENCES MSSAvamarNodes (id),
    FOREIGN KEY (atmos_id) REFERENCES MSSAtmos (id),
    FOREIGN KEY (data_domain_id) REFERENCES MSSDataDomain (id),
    FOREIGN KEY (greenplum_id) REFERENCES MSSGreenplum (id));

CREATE SEQUENCE SMSSRequestData INCREMENT BY 1 START WITH 1000;

CREATE TABLE MSSRequestData (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SMSSRequestData'),
    service_scope_description VARCHAR(256),
    general_comment VARCHAR(256),
    duration_months_id BIGINT,
    FOREIGN KEY (duration_months_id) REFERENCES DurationMonths (id));

CREATE TABLE MSS_array (
    mss_request_data_id BIGINT NOT NULL,
    mss_array_id BIGINT NOT NULL,
    FOREIGN KEY (mss_request_data_id) REFERENCES MSSRequestData (id),
    FOREIGN KEY (mss_array_id) REFERENCES MSSArray (id));

CREATE SEQUENCE SNASDestination INCREMENT BY 1 START WITH 1000;

CREATE TABLE NASDestination (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SNASDestination'),
    celerra BOOLEAN,
    vnx BOOLEAN,
    vnxe BOOLEAN,
    network_appliance BOOLEAN,
    centera BOOLEAN,
    windows BOOLEAN,
    atmos BOOLEAN,
    data_domain BOOLEAN);

CREATE SEQUENCE SCTAImplementationArray INCREMENT BY 1 START WITH 1000;

CREATE TABLE CTAImplementationArray (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SCTAImplementationArray'),
    location VARCHAR(256),
    appliance_type_id BIGINT,
    clustered_appliance BOOLEAN,
    clusters_num INT,
    source_file_server_type_id BIGINT,
    source_exports_shares_num INT,
    multi_tier_archiving BOOLEAN,
    multi_tier_sites_num INT,
    security_hardening BOOLEAN,
    nas_destination_id BIGINT,
    archive_policies_num INT,
    migration_policies_num INT,
    capacity_management BOOLEAN,
    FOREIGN KEY (appliance_type_id) REFERENCES CTAApplianceType (id),
    FOREIGN KEY (source_file_server_type_id) REFERENCES CTASourceFileServerType (id),
    FOREIGN KEY (nas_destination_id) REFERENCES NASDestination (id));

CREATE SEQUENCE SCTAImplementation INCREMENT BY 1 START WITH 1000;

CREATE TABLE CTAImplementation (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SCTAImplementation'),
    customer_expectations VARCHAR(256));

CREATE TABLE CTAImplementation_array (
    cta_implementation_id BIGINT NOT NULL,
    cta_implementation_array_id BIGINT NOT NULL,
    FOREIGN KEY (cta_implementation_id) REFERENCES CTAImplementation (id),
    FOREIGN KEY (cta_implementation_array_id) REFERENCES CTAImplementationArray (id));

CREATE SEQUENCE SCTAConversion INCREMENT BY 1 START WITH 1000;

CREATE TABLE CTAConversion (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SCTAConversion'),
    conversation_type INT,
    cloud_tiering_appliance_num INT,
    file_servers_num INT,
    management_sites_num INT,
    files_converted_num INT,
    file_archivers_num INT,
    cfa_records_num INT,
    monitoring_method INT);

CREATE SEQUENCE SCTARaininfinity INCREMENT BY 1 START WITH 1000;

CREATE TABLE CTARaininfinity (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SCTARaininfinity'),
    include_clustered_deployment BOOLEAN,
    hardware_conversion BOOLEAN,
    mstp BOOLEAN,
    cross_functional_migration BOOLEAN,
    billable_hours_num DECIMAL(20),
    appliances_deployed_num INT,
    file_servers_num INT,
    file_systems_num INT,
    include_sid BOOLEAN,
    local_user_objects_num INT,
    include_windows_proxy BOOLEAN,
    include_remote_migration BOOLEAN,
    rainfinity_appliances_num INT,
    rainfinity_vlans_num INT,
    domains_num INT,
    switch_config_required BOOLEAN,
    include_local_migration BOOLEAN,
    migrate_data_amount INT);

CREATE SEQUENCE SCTAServicesScope INCREMENT BY 1 START WITH 1000;

CREATE TABLE CTAServicesScope (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SCTAServicesScope'),
    cta_design_and_implementation BOOLEAN,
    cta_implementation BOOLEAN,
    cta_conversion BOOLEAN,
    rainfinity_design_and_impl BOOLEAN);

CREATE SEQUENCE SCTARequestData INCREMENT BY 1 START WITH 1000;

CREATE TABLE CTARequestData (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SCTARequestData'),
    services_scope_id BIGINT,
    implementation_id BIGINT,
    conversion_id BIGINT,
    raininfinity_id BIGINT,
    sites_involved_id BIGINT,
    days_of_knowledge_transfer DECIMAL(20),
    general_comment VARCHAR(256),
    FOREIGN KEY (services_scope_id) REFERENCES CTAServicesScope (id),
    FOREIGN KEY (implementation_id) REFERENCES CTAImplementation (id),
    FOREIGN KEY (conversion_id) REFERENCES CTAConversion (id),
    FOREIGN KEY (raininfinity_id) REFERENCES CTARaininfinity (id),
    FOREIGN KEY (sites_involved_id) REFERENCES SitesInvolved (id));

CREATE SEQUENCE SRoleSkillLevel INCREMENT BY 1 START WITH 1000;

CREATE TABLE RoleSkillLevel (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SRoleSkillLevel'),
    roll_skill_name VARCHAR(256),
    time_period VARCHAR(256),
    quantity DECIMAL(20),
    additional_info VARCHAR(256));

CREATE SEQUENCE SResidencyRoleSkillLevels INCREMENT BY 1 START WITH 1000;

CREATE TABLE ResidencyRoleSkillLevels (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SResidencyRoleSkillLevels'),
    special_handling_instructions VARCHAR(256));

CREATE TABLE ResRoleSkillLevels_backupL (
    res_role_skill_levels_id BIGINT NOT NULL,
    role_skill_level_id BIGINT NOT NULL,
    FOREIGN KEY (res_role_skill_levels_id) REFERENCES ResidencyRoleSkillLevels (id),
    FOREIGN KEY (role_skill_level_id) REFERENCES RoleSkillLevel (id));

CREATE TABLE ResRoleSkillLevels_projectL (
    res_role_skill_levels_id BIGINT NOT NULL,
    role_skill_level_id BIGINT NOT NULL,
    FOREIGN KEY (res_role_skill_levels_id) REFERENCES ResidencyRoleSkillLevels (id),
    FOREIGN KEY (role_skill_level_id) REFERENCES RoleSkillLevel (id));

CREATE TABLE ResRoleSkillLevels_adminL (
    res_role_skill_levels_id BIGINT NOT NULL,
    role_skill_level_id BIGINT NOT NULL,
    FOREIGN KEY (res_role_skill_levels_id) REFERENCES ResidencyRoleSkillLevels (id),
    FOREIGN KEY (role_skill_level_id) REFERENCES RoleSkillLevel (id));

CREATE TABLE ResRoleSkillLevels_storageL (
    res_role_skill_levels_id BIGINT NOT NULL,
    role_skill_level_id BIGINT NOT NULL,
    FOREIGN KEY (res_role_skill_levels_id) REFERENCES ResidencyRoleSkillLevels (id),
    FOREIGN KEY (role_skill_level_id) REFERENCES RoleSkillLevel (id));

CREATE TABLE ResRoleSkillLevels_supportL (
    res_role_skill_levels_id BIGINT NOT NULL,
    role_skill_level_id BIGINT NOT NULL,
    FOREIGN KEY (res_role_skill_levels_id) REFERENCES ResidencyRoleSkillLevels (id),
    FOREIGN KEY (role_skill_level_id) REFERENCES RoleSkillLevel (id));

CREATE TABLE ResRoleSkillLevels_vmwareL (
    res_role_skill_levels_id BIGINT NOT NULL,
    role_skill_level_id BIGINT NOT NULL,
    FOREIGN KEY (res_role_skill_levels_id) REFERENCES ResidencyRoleSkillLevels (id),
    FOREIGN KEY (role_skill_level_id) REFERENCES RoleSkillLevel (id));

CREATE TABLE ResRoleSkillLevels_archive (
    res_role_skill_levels_id BIGINT NOT NULL,
    role_skill_level_id BIGINT NOT NULL,
    FOREIGN KEY (res_role_skill_levels_id) REFERENCES ResidencyRoleSkillLevels (id),
    FOREIGN KEY (role_skill_level_id) REFERENCES RoleSkillLevel (id));

CREATE TABLE ResRoleSkillLevels_cloud (
    res_role_skill_levels_id BIGINT NOT NULL,
    role_skill_level_id BIGINT NOT NULL,
    FOREIGN KEY (res_role_skill_levels_id) REFERENCES ResidencyRoleSkillLevels (id),
    FOREIGN KEY (role_skill_level_id) REFERENCES RoleSkillLevel (id));

CREATE TABLE ResRoleSkillLevels_dataWH (
    res_role_skill_levels_id BIGINT NOT NULL,
    role_skill_level_id BIGINT NOT NULL,
    FOREIGN KEY (res_role_skill_levels_id) REFERENCES ResidencyRoleSkillLevels (id),
    FOREIGN KEY (role_skill_level_id) REFERENCES RoleSkillLevel (id));

CREATE TABLE ResRoleSkillLevels_isilon (
    res_role_skill_levels_id BIGINT NOT NULL,
    role_skill_level_id BIGINT NOT NULL,
    FOREIGN KEY (res_role_skill_levels_id) REFERENCES ResidencyRoleSkillLevels (id),
    FOREIGN KEY (role_skill_level_id) REFERENCES RoleSkillLevel (id));

CREATE TABLE ResRoleSkillLevels_storageMgmt (
    res_role_skill_levels_id BIGINT NOT NULL,
    role_skill_level_id BIGINT NOT NULL,
    FOREIGN KEY (res_role_skill_levels_id) REFERENCES ResidencyRoleSkillLevels (id),
    FOREIGN KEY (role_skill_level_id) REFERENCES RoleSkillLevel (id));

CREATE TABLE ResRoleSkillLevels_vblock (
    res_role_skill_levels_id BIGINT NOT NULL,
    role_skill_level_id BIGINT NOT NULL,
    FOREIGN KEY (res_role_skill_levels_id) REFERENCES ResidencyRoleSkillLevels (id),
    FOREIGN KEY (role_skill_level_id) REFERENCES RoleSkillLevel (id));

CREATE TABLE ResRoleSkillLevels_virtXtreme (
    res_role_skill_levels_id BIGINT NOT NULL,
    role_skill_level_id BIGINT NOT NULL,
    FOREIGN KEY (res_role_skill_levels_id) REFERENCES ResidencyRoleSkillLevels (id),
    FOREIGN KEY (role_skill_level_id) REFERENCES RoleSkillLevel (id));

CREATE SEQUENCE SResidencyRequestData INCREMENT BY 1 START WITH 1000;

CREATE TABLE ResidencyRequestData (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SResidencyRequestData'),
    payment_type_id BIGINT,
    location VARCHAR(256),
    special_conditions VARCHAR(256),
    work_start_day_id BIGINT,
    work_end_day_id BIGINT,
    approximate_start_date DATE,
    work_hours_num DECIMAL(20),
    general_comment VARCHAR(256),
    role_skill_levels_id BIGINT,
    FOREIGN KEY (payment_type_id) REFERENCES ResidencyPaymentType (id),
    FOREIGN KEY (work_start_day_id) REFERENCES WeekDay (id),
    FOREIGN KEY (work_end_day_id) REFERENCES WeekDay (id),
    FOREIGN KEY (role_skill_levels_id) REFERENCES ResidencyRoleSkillLevels (id));

CREATE SEQUENCE SSourceOneFeatures INCREMENT BY 1 START WITH 1000;

CREATE TABLE SourceOneFeatures (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SSourceOneFeatures'),
    email_archiving BOOLEAN,
    discovery_manager BOOLEAN,
    share_point_archiving BOOLEAN,
    file_archiving BOOLEAN,
    email_supervisor BOOLEAN,
    share_point_storage_managment BOOLEAN,
    cloud_tiering_app_mgmt BOOLEAN);

CREATE SEQUENCE SSourceOneDROptions INCREMENT BY 1 START WITH 1000;

CREATE TABLE SourceOneDROptions (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SSourceOneDROptions'),
    full_dr BOOLEAN,
    dr_planning BOOLEAN,
    dr_testing BOOLEAN);

CREATE SEQUENCE SSourceOneDesignImpl INCREMENT BY 1 START WITH 1000;

CREATE TABLE SourceOneDesignImpl (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SSourceOneDesignImpl'),
    knowledge_transfer_hours DECIMAL(20),
    mailboxes_num INT,
    include_piolt BOOLEAN,
    include_meeting BOOLEAN,
    features_id BIGINT,
    dr_options_id BIGINT,
    include_validation_sizing BOOLEAN,
    include_shortcut_email BOOLEAN,
    include_shortcut_file_archive BOOLEAN,
    include_lexicon_query BOOLEAN,
    supervised_users_num INT,
    master_servers_num INT,
    email_mgmt_servers_num INT,
    sharepoint_arch_servers_num INT,
    file_archiving_servers_num INT,
    mgmt_consoles_num INT,
    mapped_folders_num INT,
    email_archive_policies_num INT,
    file_archive_policies_num INT,
    dis_manager_admin_console_num INT,
    dis_manager_client_num INT,
    hold_folders_num INT,
    sample_matter_num INT,
    legal_hold_folders_num INT,
    archive_sharepoint_farms_num INT,
    stor_mgmt_share_farms_num INT,
    file_arch_mapped_folders_num INT,
    file_arch_pol_to_be_conf_num INT,
    cloud_tiering_appliances_num INT,
    reviewer_clients_num INT,
    FOREIGN KEY (features_id) REFERENCES SourceOneFeatures (id),
    FOREIGN KEY (dr_options_id) REFERENCES SourceOneDROptions (id));

CREATE SEQUENCE SSourceOneUpgrade INCREMENT BY 1 START WITH 1000;

CREATE TABLE SourceOneUpgrade (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SSourceOneUpgrade'),
    knowledge_transfer_hours DECIMAL(20),
    current_version VARCHAR(256),
    upgrade_version VARCHAR(256),
    master_servers_num INT,
    worker_servers_num INT,
    billable_hours_num INT);

CREATE SEQUENCE SSourceOneMigration INCREMENT BY 1 START WITH 1000;

CREATE TABLE SourceOneMigration (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SSourceOneMigration'),
    knowledge_transfer_hours DECIMAL(20),
    email_xtender_servers_num INT,
    migrated_size INT,
    billable_hours_num INT);

CREATE SEQUENCE SSourceOneHealthCheck INCREMENT BY 1 START WITH 1000;

CREATE TABLE SourceOneHealthCheck (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SSourceOneHealthCheck'),
    knowledge_transfer_hours DECIMAL(20),
    servers_num INT,
    assessment_interviews_num INT,
    master_servers_num INT,
    worker_servers_num INT);

CREATE SEQUENCE SSourceOneServicesScope INCREMENT BY 1 START WITH 1000;

CREATE TABLE SourceOneServicesScope (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SSourceOneServicesScope'),
    design_and_impl BOOLEAN,
    upgrade BOOLEAN,
    migration BOOLEAN,
    health_check BOOLEAN);

CREATE SEQUENCE SSourceOneRequestData INCREMENT BY 1 START WITH 1000;

CREATE TABLE SourceOneRequestData (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SSourceOneRequestData'),
    services_scope_id BIGINT,
    design_impl_id BIGINT,
    upgrade_id BIGINT,
    migration_id BIGINT,
    health_check_id BIGINT,
    sites_involved_num INT,
    general_comment VARCHAR(256),
    FOREIGN KEY (services_scope_id) REFERENCES SourceOneServicesScope (id),
    FOREIGN KEY (design_impl_id) REFERENCES SourceOneDesignImpl (id),
    FOREIGN KEY (upgrade_id) REFERENCES SourceOneUpgrade (id),
    FOREIGN KEY (migration_id) REFERENCES SourceOneMigration (id),
    FOREIGN KEY (health_check_id) REFERENCES SourceOneHealthCheck (id));

CREATE SEQUENCE SASDAppSync INCREMENT BY 1 START WITH 1000;

CREATE TABLE ASDAppSync (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SASDAppSync'),
    install_vsi BOOLEAN,
    app_sync_instances_num INT,
    vcenter_servers_num INT,
    app_production_hosts_num INT,
    vnx_arrays_num INT,
    application_mount_hosts_num INT,
    recover_point_appliances_num INT,
    knowledge_transfer_hours DECIMAL(20,2));

CREATE SEQUENCE SASDUIM INCREMENT BY 1 START WITH 1000;

CREATE TABLE ASDUIM (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SASDUIM'),
    install_type_id BIGINT,
    upgrade_type_id BIGINT,
    include_remote_install_agent BOOLEAN,
    remote_install_agents_num INT,
    uim_provisioning_vapps_num INT,
    isolation_zones_num INT,
    include_vco BOOLEAN,
    vcenter_instances_num INT,
    uim_provisioning_servers_num INT,
    vcloud_director_instances_num INT,
    conv_hardware_systems_num INT,
    blade_storage_grades_num INT,
    identity_pools_num INT,
    network_profiles_num INT,
    uim_operations_vapps_num INT,
    service_offer_to_create_num INT,
    services_to_create_num INT,
    blades_to_provision_num INT,
    luns_to_provision_num INT,
    services_to_provision_num INT,
    data_sources_num INT,
    snmp_alerts_num INT,
    uim_operations_servers_num INT,
    uim_operations_users_num INT,
    perform_elastic_provisioning BOOLEAN,
    services_req_elastic_ops_num INT,
    blades_impacted_num INT,
    migrate_services BOOLEAN,
    non_uim_conv_hardware_sys_num INT,
    services_adopted_migrated_num INT,
    blades_adopted_migrated_num INT,
    customer_known BOOLEAN,
    remediate_hours DECIMAL(20,2),
    sa_knowledge_transfer_hours DECIMAL(20,2),
    is_knowledge_transfer_hours DECIMAL(20,2));

CREATE SEQUENCE SASDServicesScope INCREMENT BY 1 START WITH 1000;

CREATE TABLE ASDServicesScope (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SASDServicesScope'),
    ncm BOOLEAN,
    app_sync BOOLEAN,
    uim BOOLEAN);

CREATE SEQUENCE SASDRequestData INCREMENT BY 1 START WITH 1000;

CREATE TABLE ASDRequestData (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SASDRequestData'),
    services_scope_id BIGINT,
    app_sync_id BIGINT,
    uim_id BIGINT,
    general_comment VARCHAR(256),
    FOREIGN KEY (services_scope_id) REFERENCES ASDServicesScope (id),
    FOREIGN KEY (app_sync_id) REFERENCES ASDAppSync (id),
    FOREIGN KEY (uim_id) REFERENCES ASDUIM (id));

CREATE SEQUENCE SHealthCheckAvamar INCREMENT BY 1 START WITH 1000;

CREATE TABLE HealthCheckAvamar (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SHealthCheckAvamar'),
    avamar_grids_num INT,
    assessment_interviews_num INT);

CREATE SEQUENCE SHealthCheckDataDomain INCREMENT BY 1 START WITH 1000;

CREATE TABLE HealthCheckDataDomain (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SHealthCheckDataDomain'),
    appliances_num INT,
    assessment_interviews_num INT);

CREATE SEQUENCE SHealthCheckDPA INCREMENT BY 1 START WITH 1000;

CREATE TABLE HealthCheckDPA (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SHealthCheckDPA'),
    site_implementations_num INT);

CREATE SEQUENCE SHealthCheckDLM INCREMENT BY 1 START WITH 1000;

CREATE TABLE HealthCheckDLM (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SHealthCheckDLM'),
    dlm_subsystem_num INT,
    storage_amount INT);

CREATE SEQUENCE SHealthCheckGreenPlum INCREMENT BY 1 START WITH 1000;

CREATE TABLE HealthCheckGreenPlum (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SHealthCheckGreenPlum'),
    master_host_servers_num INT);

CREATE SEQUENCE SHealthCheckIonix INCREMENT BY 1 START WITH 1000;

CREATE TABLE HealthCheckIonix (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SHealthCheckIonix'),
    incl_exe_summary_presentation BOOLEAN,
    size_environment INT);

CREATE SEQUENCE SHealthCheckNetWorker INCREMENT BY 1 START WITH 1000;

CREATE TABLE HealthCheckNetWorker (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SHealthCheckNetWorker'),
    include_emc_assessment BOOLEAN,
    data_zones_num INT,
    assessment_interviews_num INT);

CREATE SEQUENCE SHealthCheckSanSecurity INCREMENT BY 1 START WITH 1000;

CREATE TABLE HealthCheckSanSecurity (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SHealthCheckSanSecurity'),
    assessment_interviews_num INT,
    assessed_sites_num INT,
    emc_storage_arrays_num INT,
    san_attached_hosts_num INT,
    storage_mgmt_stations_num INT);

CREATE SEQUENCE SHealthCheckSAP INCREMENT BY 1 START WITH 1000;

CREATE TABLE HealthCheckSAP (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SHealthCheckSAP'),
    dlm_subsystem_num INT,
    storage_amount INT);

CREATE SEQUENCE SHealthCheckSourceOne INCREMENT BY 1 START WITH 1000;

CREATE TABLE HealthCheckSourceOne (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SHealthCheckSourceOne'),
    servers_num INT,
    assessment_interviews_num INT);

CREATE SEQUENCE SHealthCheckSymmetrixVmax INCREMENT BY 1 START WITH 1000;

CREATE TABLE HealthCheckSymmetrixVmax (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SHealthCheckSymmetrixVmax'),
    events_sold_num INT,
    dmx_vmax_arrays_num INT);

CREATE SEQUENCE SHealthCheckSymVmaxStorageRep INCREMENT BY 1 START WITH 1000;

CREATE TABLE HealthCheckSymVmaxStorageRep (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SHealthCheckSymVmaxStorageRep'),
    include_final_report BOOLEAN,
    incl_exec_summ_review_pres BOOLEAN,
    assessment_interviews_num INT,
    consistency_groups_num INT,
    symmetrix_arrays_num INT,
    open_systems_hosts_num INT,
    logical_devices_num INT);

CREATE SEQUENCE SHealthCheckUnified INCREMENT BY 1 START WITH 1000;

CREATE TABLE HealthCheckUnified (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SHealthCheckUnified'),
    health_check_type_id BIGINT,
    events_sold_num INT,
    file_arrays_num INT,
    block_arrays_num INT,
    FOREIGN KEY (health_check_type_id) REFERENCES UnifiedHealthCheckType (id));

CREATE SEQUENCE SHealthCheckVblock INCREMENT BY 1 START WITH 1000;

CREATE TABLE HealthCheckVblock (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SHealthCheckVblock'),
    incl_interoperability_check BOOLEAN,
    include_performance_check BOOLEAN,
    include_capacity_analysis BOOLEAN,
    include_flare_software_update BOOLEAN,
    block_arrays_num INT,
    san_switches_num INT,
    san_hosts_num INT);

CREATE SEQUENCE SHealthCheckVmwareVirtualInf INCREMENT BY 1 START WITH 1000;

CREATE TABLE HealthCheckVmwareVirtualInf (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SHealthCheckVmwareVirtualInf'),
    incl_executive_summary_review BOOLEAN,
    assessment_interviews_num INT,
    esx_servers_num INT,
    virtual_hosts_num INT);

CREATE SEQUENCE SHealthCheckVplex INCREMENT BY 1 START WITH 1000;

CREATE TABLE HealthCheckVplex (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SHealthCheckVplex'),
    clusters_reviewed_num INT,
    events_sold_num INT);

CREATE SEQUENCE SHealthCheckServicesScope INCREMENT BY 1 START WITH 1000;

CREATE TABLE HealthCheckServicesScope (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SHealthCheckServicesScope'),
    avamar BOOLEAN,
    data_domain BOOLEAN,
    dpa BOOLEAN,
    dlm BOOLEAN,
    greenplum BOOLEAN,
    ionix BOOLEAN,
    net_worker BOOLEAN,
    san_security BOOLEAN,
    sap BOOLEAN,
    source_one BOOLEAN,
    symmetrix_vmax BOOLEAN,
    symmetrix_vmax_storage_repl BOOLEAN,
    unified BOOLEAN,
    vblock BOOLEAN,
    vmware_virtual_infrastructure BOOLEAN,
    vplex BOOLEAN);

CREATE SEQUENCE SHealthCheckRequestData INCREMENT BY 1 START WITH 1000;

CREATE TABLE HealthCheckRequestData (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SHealthCheckRequestData'),
    services_scope_id BIGINT,
    avamar_id BIGINT,
    data_domain_id BIGINT,
    dpa_id BIGINT,
    dlm_id BIGINT,
    greenplum_id BIGINT,
    ionix_id BIGINT,
    net_worker_id BIGINT,
    san_security_id BIGINT,
    sap_id BIGINT,
    source_one_id BIGINT,
    symmetrix_vmax_id BIGINT,
    symmetrix_vmax_stor_repl_id BIGINT,
    unified_id BIGINT,
    vblock_id BIGINT,
    vmware_virtual_infra_id BIGINT,
    vplex_id BIGINT,
    general_comment VARCHAR(256),
    FOREIGN KEY (services_scope_id) REFERENCES HealthCheckServicesScope (id),
    FOREIGN KEY (avamar_id) REFERENCES HealthCheckAvamar (id),
    FOREIGN KEY (data_domain_id) REFERENCES HealthCheckDataDomain (id),
    FOREIGN KEY (dpa_id) REFERENCES HealthCheckDPA (id),
    FOREIGN KEY (dlm_id) REFERENCES HealthCheckDLM (id),
    FOREIGN KEY (greenplum_id) REFERENCES HealthCheckGreenPlum (id),
    FOREIGN KEY (ionix_id) REFERENCES HealthCheckIonix (id),
    FOREIGN KEY (net_worker_id) REFERENCES HealthCheckNetWorker (id),
    FOREIGN KEY (san_security_id) REFERENCES HealthCheckSanSecurity (id),
    FOREIGN KEY (sap_id) REFERENCES HealthCheckSAP (id),
    FOREIGN KEY (source_one_id) REFERENCES HealthCheckSourceOne (id),
    FOREIGN KEY (symmetrix_vmax_id) REFERENCES HealthCheckSymmetrixVmax (id),
    FOREIGN KEY (symmetrix_vmax_stor_repl_id) REFERENCES HealthCheckSymVmaxStorageRep (id),
    FOREIGN KEY (unified_id) REFERENCES HealthCheckUnified (id),
    FOREIGN KEY (vblock_id) REFERENCES HealthCheckVblock (id),
    FOREIGN KEY (vmware_virtual_infra_id) REFERENCES HealthCheckVmwareVirtualInf (id),
    FOREIGN KEY (vplex_id) REFERENCES HealthCheckVplex (id));

CREATE SEQUENCE SIsilonClusterRelocation INCREMENT BY 1 START WITH 1000;

CREATE TABLE IsilonClusterRelocation (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SIsilonClusterRelocation'),
    isilon_12uservers_num INT,
    isilon_4uservers_num INT,
    infiniband_switches_num INT,
    infiniband_chassis_num INT);

CREATE SEQUENCE SIsilonDesignAndImpl INCREMENT BY 1 START WITH 1000;

CREATE TABLE IsilonDesignAndImpl (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SIsilonDesignAndImpl'),
    install_hardware BOOLEAN,
    include_tech_refresh BOOLEAN,
    new_cluster BOOLEAN,
    subnets_num INT,
    smart_connect_zones_num INT,
    auth_methods_num INT,
    shares_exports_num INT,
    smart_quotas_num INT,
    snapshots_iqentries_num INT,
    include_email BOOLEAN,
    include_subnet BOOLEAN,
    include_advice BOOLEAN,
    include_smart_connect BOOLEAN,
    include_auth BOOLEAN,
    include_file_system_shares BOOLEAN,
    install_insight_iq BOOLEAN,
    include_smart_quotas BOOLEAN,
    include_snapshots BOOLEAN,
    include_ndmp BOOLEAN,
    include_smart_lock BOOLEAN,
    include_1u_switch_install BOOLEAN,
    include_4u_chassis_install BOOLEAN,
    include_12u_node_install BOOLEAN,
    include_4u_node_install BOOLEAN);

CREATE SEQUENCE SIsilonMigration INCREMENT BY 1 START WITH 1000;

CREATE TABLE IsilonMigration (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SIsilonMigration'),
    net_app_3rd_party_migration BOOLEAN,
    celerra_unified_file BOOLEAN,
    sync_iq BOOLEAN,
    tech_refresh BOOLEAN,
    plan_and_design BOOLEAN,
    impl_and_migration BOOLEAN,
    additional_testing BOOLEAN,
    additional_monitoring BOOLEAN,
    scripting_work BOOLEAN,
    install_isilon_hardware BOOLEAN,
    cifs BOOLEAN,
    nfs BOOLEAN,
    multi_protocol BOOLEAN,
    cifs_data_amount INT,
    include_local_users_groups BOOLEAN,
    nfs_data_amount INT,
    multi_protocol_data_amount INT,
    average_duration DECIMAL(20,2),
    data_mig_events_num INT,
    monitor_weeks_num INT,
    cutover_events_num INT,
    smart_pools_enabled BOOLEAN,
    remove_nodes_num INT,
    required_events_num INT,
    tech_refresh_moved_data INT);

CREATE SEQUENCE SIsilonHardwareUpgrade INCREMENT BY 1 START WITH 1000;

CREATE TABLE IsilonHardwareUpgrade (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SIsilonHardwareUpgrade'),
    perform_config BOOLEAN,
    nodes_num INT);

CREATE SEQUENCE SIsilonServicesScope INCREMENT BY 1 START WITH 1000;

CREATE TABLE IsilonServicesScope (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SIsilonServicesScope'),
    cluster_relocation BOOLEAN,
    hardware_upgrade BOOLEAN,
    migration BOOLEAN,
    design_and_impl BOOLEAN,
    config_assurance BOOLEAN);

CREATE SEQUENCE SIsilonRequestData INCREMENT BY 1 START WITH 1000;

CREATE TABLE IsilonRequestData (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SIsilonRequestData'),
    knowledge_transfer_hours DECIMAL(20,2),
    general_comment VARCHAR(256),
    services_scope_id BIGINT,
    cluster_relocation_id BIGINT,
    hardware_upgrade_id BIGINT,
    migration_id BIGINT,
    design_and_impl_id BIGINT,
    FOREIGN KEY (services_scope_id) REFERENCES IsilonServicesScope (id),
    FOREIGN KEY (cluster_relocation_id) REFERENCES IsilonClusterRelocation (id),
    FOREIGN KEY (hardware_upgrade_id) REFERENCES IsilonHardwareUpgrade (id),
    FOREIGN KEY (migration_id) REFERENCES IsilonMigration (id),
    FOREIGN KEY (design_and_impl_id) REFERENCES IsilonDesignAndImpl (id));

CREATE SEQUENCE SViprImplementation INCREMENT BY 1 START WITH 1000;

CREATE TABLE ViprImplementation (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SViprImplementation'),
    new_impl_type BOOLEAN,
    controller_instances_num INT,
    include_data_services BOOLEAN,
    include_ldap BOOLEAN,
    watch_4net_exist BOOLEAN,
    include_block_services BOOLEAN,
    include_vcops BOOLEAN,
    include_vco BOOLEAN,
    include_vcac BOOLEAN,
    include_scvmm BOOLEAN,
    include_vsi BOOLEAN,
    unix_hosts_num INT,
    windows_hosts_num INT,
    v_center_hosts_num INT,
    file_only_arrays_num INT,
    block_arrays_num INT,
    vplex_arrays_num INT,
    recover_point_systems_num INT,
    cisco_switch_fabrics_num INT,
    brocade_switch_fabrics_num INT,
    virtual_arrays_num INT,
    catalog_services_num INT,
    user_roles_num INT,
    ds_buckets_num INT,
    ds_pools_num INT,
    data_stores_num INT,
    ds_ingestions_num INT,
    hadoop_clusters_num INT,
    hadoop_nodes_num INT,
    include_hdfs BOOLEAN,
    include_kerberos_auth BOOLEAN,
    sa_knowledge_transfer_hours DECIMAL(20,2),
    include_vipr_content_address BOOLEAN,
    include_vipr_sofwtare_install BOOLEAN,
    tenants_defined_num INT,
    openstack_cinder_arrays_num INT,
    scaleio_protection_domains_num INT,
    block_file_virtual_pools_num INT,
    projects_num INT,
    additional_hours DECIMAL(20,2));

CREATE SEQUENCE SHostBasedMigrationTool INCREMENT BY 1 START WITH 1000;

CREATE TABLE HostBasedMigrationTool (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SHostBasedMigrationTool'),
    name VARCHAR(256));

CREATE SEQUENCE SXtremeHostBasedMigrationTool INCREMENT BY 1 START WITH 1000;

CREATE TABLE XtremeHostBasedMigrationTool (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SXtremeHostBasedMigrationTool'),
    name VARCHAR(256));

CREATE SEQUENCE SECSApplianceDesignImpl INCREMENT BY 1 START WITH 1000;

CREATE TABLE ECSApplianceDesignImpl (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SECSApplianceDesignImpl'),
    include_data_services_for_hdfs BOOLEAN,
    include_integration_ad_ldap BOOLEAN,
    include_kerberos_auth_mode BOOLEAN,
    include_vipr_content_address BOOLEAN,
    watch4net_platform_exists BOOLEAN,
    ecs_systems_with_block_num INT,
    ecs_unstructured_systems_num INT,
    tenants_defined_num INT,
    hadoop_clusters_num INT,
    total_hadoop_cluster_nodes_num INT,
    virtual_arrays_num INT,
    block_virtual_pools_num INT,
    object_virtual_pools_num INT,
    projects_num INT,
    data_service_buckets_num INT,
    user_roles_defined_num INT,
    catalog_services_customize_num INT,
    cas_required_num INT);

CREATE SEQUENCE SViprDataServiceCommodity INCREMENT BY 1 START WITH 1000;

CREATE TABLE ViprDataServiceCommodity (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SViprDataServiceCommodity'),
    include_data_services_for_hdfs BOOLEAN,
    include_integration_ad_ldap BOOLEAN,
    include_kerberos_auth_mode BOOLEAN,
    include_vipr_content_address BOOLEAN,
    watch4net_platform_exists BOOLEAN,
    commodity_storage_systems_num INT,
    tenants_defined_num INT,
    hadoop_clusters_num INT,
    total_hadoop_cluster_nodes_num INT,
    virtual_arrays_num INT,
    object_virtual_pools_num INT,
    projects_num INT,
    user_roles_defined_num INT,
    catalog_services_customize_num INT,
    cas_required_num INT);

CREATE SEQUENCE SViprDataMigrationPPMEDesign INCREMENT BY 1 START WITH 1000;

CREATE TABLE ViprDataMigrationPPMEDesign (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SViprDataMigrationPPMEDesign'),
    total_source_target_sites_num INT,
    new_physical_hosts_num INT,
    new_esx_servers_num INT,
    new_enterprise_directors_num INT,
    new_department_switches_num INT,
    new_vnx_block_stor_arrays_num INT,
    data_migration_factor_percent DECIMAL(20,2),
    new_symmetrix_stor_arrays_num INT,
    vnx_blocks_to_upgrade_num INT,
    symmetrix_to_upgrade_num INT,
    xtreme_io_clusters_num INT,
    non_emc_storage_arrays_num INT);

CREATE SEQUENCE SViprDataMigrationPPMEImpl INCREMENT BY 1 START WITH 1000;

CREATE TABLE ViprDataMigrationPPMEImpl (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SViprDataMigrationPPMEImpl'),
    remove_existing_emc_storage BOOLEAN,
    relocate_existing_emc_storage BOOLEAN,
    include_storage_data_erasure BOOLEAN,
    include_add_bin_file_work BOOLEAN,
    bin_files_design_impl_num INT,
    hours_per_bin_file DECIMAL(20,2),
    include_xtreme_io_config BOOLEAN,
    tb_migrated_source_data_amount INT,
    data_migration_factor_percent DECIMAL(20,2),
    total_hosts_migrate_by_emc_num INT,
    new_design_included_hosts_num INT,
    new_esx_servers_num INT,
    customer_zonning_switches BOOLEAN,
    existing_san_fabrics_num INT,
    hosts_booted_from_san_num INT,
    customer_lun_device_allocation BOOLEAN,
    new_vnx_blocks_stor_arrays_num INT,
    vnx_blocks_upgrade_num INT,
    xtreme_io_clusters_num INT,
    xtreme_io_bricks_num INT,
    hosts_migrated_via_ppme_num INT,
    include_device_size_changes BOOLEAN,
    servers_lun_size_percent DECIMAL(20,2),
    vnx_arrays_to_erase_data_num INT,
    vnx_arrays_serial_numbers VARCHAR(256),
    sym_storage_to_erase_data_num INT,
    sym_storage_serial_numbers VARCHAR(256));

CREATE SEQUENCE SViprDataMigrationPPME INCREMENT BY 1 START WITH 1000;

CREATE TABLE ViprDataMigrationPPME (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SViprDataMigrationPPME'),
    planning_and_design BOOLEAN,
    implementation_and_migration BOOLEAN,
    customer_mig_work_themselves BOOLEAN,
    emc_onsite_support BOOLEAN,
    host_based_migration_tool_id BIGINT,
    include_esx_hosts_mig_vmotion BOOLEAN,
    include_sec_round_data_gather BOOLEAN,
    include_eca BOOLEAN,
    storage_array_vnx_clariion BOOLEAN,
    storage_array_vmax_dmax_symm BOOLEAN,
    storage_array_3rd_party_stor BOOLEAN,
    storage_array_no_source BOOLEAN,
    storage_array_xtreme_io_clus BOOLEAN,
    existing_physical_hosts_num INT,
    existing_esx_servers_num INT,
    swing_frame_required BOOLEAN,
    total_source_array_involved INT,
    total_target_array_involved INT,
    include_device_size_changes BOOLEAN,
    servers_lun_size_percent DECIMAL(20,2),
    tb_data_migration_amount INT,
    hosts_migrated_via_ppme_num INT,
    vmware_machines_num INT,
    ppme_planning_design_id BIGINT,
    ppme_impl_migration_id BIGINT,
    FOREIGN KEY (host_based_migration_tool_id) REFERENCES HostBasedMigrationTool (id),
    FOREIGN KEY (ppme_planning_design_id) REFERENCES ViprDataMigrationPPMEDesign (id),
    FOREIGN KEY (ppme_impl_migration_id) REFERENCES ViprDataMigrationPPMEImpl (id));

CREATE SEQUENCE SViprRequestData INCREMENT BY 1 START WITH 1000;

CREATE TABLE ViprRequestData (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SViprRequestData'),
    knowledge_transfer_hours DECIMAL(20,2),
    general_comment VARCHAR(256),
    planning_design_impl BOOLEAN,
    data_migration_with_ppme BOOLEAN,
    design_impl_for_commodity BOOLEAN,
    ecs_appliance_design_impl BOOLEAN,
    impl_id BIGINT,
    vipr_data_migration_ppme_id BIGINT,
    ecs_appliance_design_impl_id BIGINT,
    vipr_data_service_id BIGINT,
    FOREIGN KEY (impl_id) REFERENCES ViprImplementation (id),
    FOREIGN KEY (vipr_data_migration_ppme_id) REFERENCES ViprDataMigrationPPME (id),
    FOREIGN KEY (ecs_appliance_design_impl_id) REFERENCES ECSApplianceDesignImpl (id),
    FOREIGN KEY (vipr_data_service_id) REFERENCES ViprDataServiceCommodity (id));

CREATE SEQUENCE SVblockProject INCREMENT BY 1 START WITH 1000;

CREATE TABLE VblockProject (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SVblockProject'),
    custom_project_description VARCHAR(256));

CREATE SEQUENCE SVblockDesignImpl INCREMENT BY 1 START WITH 1000;

CREATE TABLE VblockDesignImpl (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SVblockDesignImpl'),
    vnx_type BOOLEAN,
    symmetrix_type BOOLEAN,
    vnx_luns_num INT,
    symmetrix_luns_num INT,
    include_unified_file BOOLEAN,
    include_ionix_uim BOOLEAN,
    type1_vsphere_servers_num INT,
    type2_vsphere_servers_num INT,
    cisco_partner_hours DECIMAL(20,2),
    vmware_partner_hours DECIMAL(20,2),
    type1_luns_num INT,
    type2_luns_num INT,
    uft_type1_num INT,
    uft_type2_num INT);

CREATE SEQUENCE SVblockInfrastructure INCREMENT BY 1 START WITH 1000;

CREATE TABLE VblockInfrastructure (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SVblockInfrastructure'),
    vblock_series300_num INT,
    vblock_series700_num INT);

CREATE SEQUENCE SVblockTechAssessment INCREMENT BY 1 START WITH 1000;

CREATE TABLE VblockTechAssessment (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SVblockTechAssessment'),
    assessed_sites INT,
    vmware_identified_servers_num INT);

CREATE SEQUENCE SVblockServices INCREMENT BY 1 START WITH 1000;

CREATE TABLE VblockServices (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SVblockServices'),
    design_impl BOOLEAN,
    infrastructure BOOLEAN,
    tech_assessment BOOLEAN);

CREATE SEQUENCE SVblockRequestData INCREMENT BY 1 START WITH 1000;

CREATE TABLE VblockRequestData (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SVblockRequestData'),
    describe_options VARCHAR(256),
    general_comment VARCHAR(256),
    services_id BIGINT,
    design_impl_id BIGINT,
    infrastructure_id BIGINT,
    tech_assessment_id BIGINT,
    project_id BIGINT,
    FOREIGN KEY (services_id) REFERENCES VblockServices (id),
    FOREIGN KEY (design_impl_id) REFERENCES VblockDesignImpl (id),
    FOREIGN KEY (infrastructure_id) REFERENCES VblockInfrastructure (id),
    FOREIGN KEY (tech_assessment_id) REFERENCES VblockTechAssessment (id),
    FOREIGN KEY (project_id) REFERENCES VblockProject (id));

CREATE SEQUENCE SCenteraToAtmosMigration INCREMENT BY 1 START WITH 1000;

CREATE TABLE CenteraToAtmosMigration (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SCenteraToAtmosMigration'),
    applications_num INT,
    protection_type INT,
    data_amount INT);

CREATE SEQUENCE SCenteraFileErasure INCREMENT BY 1 START WITH 1000;

CREATE TABLE CenteraFileErasure (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SCenteraFileErasure'),
    clips_to_delete_num INT);

CREATE SEQUENCE SCenteraUniversalAccess INCREMENT BY 1 START WITH 1000;

CREATE TABLE CenteraUniversalAccess (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SCenteraUniversalAccess'),
    active_cuas_num INT,
    data_pools_num INT,
    standby_cuas_num INT,
    cua_hardware_type_id BIGINT,
    relocated_cuas_num INT,
    FOREIGN KEY (cua_hardware_type_id) REFERENCES CUAHardwareType (id));

CREATE SEQUENCE SCenteraIntraClusterMigration INCREMENT BY 1 START WITH 1000;

CREATE TABLE CenteraIntraClusterMigration (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SCenteraIntraClusterMigration'),
    source_cubes_num INT,
    target_cubes_num INT,
    new_nodes_num INT,
    removed_nodes_num INT,
    existing_nodes_gen3 BOOLEAN);

CREATE SEQUENCE SExpansionNodeOnly INCREMENT BY 1 START WITH 1000;

CREATE TABLE ExpansionNodeOnly (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SExpansionNodeOnly'),
    flex_kits_num INT);

CREATE SEQUENCE SExistingCenteraCluster INCREMENT BY 1 START WITH 1000;

CREATE TABLE ExistingCenteraCluster (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SExistingCenteraCluster'),
    location VARCHAR(256),
    serial_number VARCHAR(256),
    modem_number VARCHAR(256),
    edition_id BIGINT,
    generation_id BIGINT,
    health_check_id BIGINT,
    replication_target VARCHAR(256),
    migration_source VARCHAR(256),
    migration_target VARCHAR(256),
    cicm BOOLEAN,
    applications_writting VARCHAR(256),
    array_action_id BIGINT,
    certified_data_erasure_req BOOLEAN,
    data_deletion_required BOOLEAN,
    customer_clip_list BOOLEAN,
    FOREIGN KEY (edition_id) REFERENCES CenteraEditionType (id),
    FOREIGN KEY (generation_id) REFERENCES CenteraGenerationType (id),
    FOREIGN KEY (health_check_id) REFERENCES CenteraHealthCheckType (id),
    FOREIGN KEY (array_action_id) REFERENCES CenteraArrayActionType (id));

CREATE SEQUENCE SNewCenteraCluster INCREMENT BY 1 START WITH 1000;

CREATE TABLE NewCenteraCluster (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SNewCenteraCluster'),
    location VARCHAR(256),
    edition_id BIGINT,
    generation_id BIGINT,
    protection_scheme_id BIGINT,
    nodes_num INT,
    replication_target VARCHAR(256),
    migration_source VARCHAR(256),
    located_at_target_site BOOLEAN,
    moved_from_target_site BOOLEAN,
    applications_writting VARCHAR(256),
    FOREIGN KEY (edition_id) REFERENCES CenteraEditionType (id),
    FOREIGN KEY (generation_id) REFERENCES CenteraGenerationType (id),
    FOREIGN KEY (protection_scheme_id) REFERENCES CenteraProtectionSchemeType (id));

CREATE SEQUENCE SCenteraDesignImpl INCREMENT BY 1 START WITH 1000;

CREATE TABLE CenteraDesignImpl (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SCenteraDesignImpl'),
    centeras_exist BOOLEAN,
    ex_centeras_require_review BOOLEAN,
    ex_centeras_review_detail VARCHAR(256),
    hardware_repurposing_detail VARCHAR(256),
    array_relocation_detail VARCHAR(256),
    shipping_arranger_id BIGINT,
    need_develop_code BOOLEAN,
    develop_code_detail VARCHAR(256),
    custom_scripting BOOLEAN,
    custom_scripting_detail VARCHAR(256),
    expected_timeline VARCHAR(256),
    replication_type_id BIGINT,
    implement_tape_backup BOOLEAN,
    FOREIGN KEY (shipping_arranger_id) REFERENCES CenteraShippingArranger (id),
    FOREIGN KEY (replication_type_id) REFERENCES CenteraReplicationType (id));

CREATE TABLE CenteraDesignImpl_exClusters (
    centera_design_impl_id BIGINT NOT NULL,
    existing_centera_cluster_id BIGINT NOT NULL,
    FOREIGN KEY (centera_design_impl_id) REFERENCES CenteraDesignImpl (id),
    FOREIGN KEY (existing_centera_cluster_id) REFERENCES ExistingCenteraCluster (id));

CREATE TABLE CenteraDesignImpl_newClusters (
    centera_design_impl_id BIGINT NOT NULL,
    new_centera_cluster_id BIGINT NOT NULL,
    FOREIGN KEY (centera_design_impl_id) REFERENCES CenteraDesignImpl (id),
    FOREIGN KEY (new_centera_cluster_id) REFERENCES NewCenteraCluster (id));

CREATE SEQUENCE SAtmosDesignImpl INCREMENT BY 1 START WITH 1000;

CREATE TABLE AtmosDesignImpl (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SAtmosDesignImpl'),
    include_acdp BOOLEAN,
    rmgs_num INT,
    rmgs_ve_num INT,
    installation_segments_num INT,
    cabinet_type_ws2 BOOLEAN,
    hardware_servers_num INT,
    cifs_servers_num INT,
    nfs_servers_num INT,
    ifs_servers_num INT,
    ws_servers_num INT,
    tenants_num INT,
    sub_tenants_num INT,
    policies_num INT,
    include_secondary_acdpsite BOOLEAN);

CREATE SEQUENCE SAtmosCenteraServicesScope INCREMENT BY 1 START WITH 1000;

CREATE TABLE AtmosCenteraServicesScope (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SAtmosCenteraServicesScope'),
    centera_design_impl BOOLEAN,
    atmos_design_impl BOOLEAN,
    centera_to_atmos_mig BOOLEAN,
    acdp BOOLEAN,
    cva BOOLEAN,
    cua BOOLEAN,
    cicm BOOLEAN,
    centera_file_erasure BOOLEAN,
    expansion_node_only BOOLEAN);

CREATE SEQUENCE SAtmosCenteraRequestData INCREMENT BY 1 START WITH 1000;

CREATE TABLE AtmosCenteraRequestData (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SAtmosCenteraRequestData'),
    have_high_level_design BOOLEAN,
    sites_involved_id BIGINT,
    days_of_knowledge_transfer DECIMAL(20,2),
    customer_has_centera BOOLEAN,
    general_comment VARCHAR(256),
    services_scope_id BIGINT,
    atmos_design_impl_id BIGINT,
    centera_design_impl_id BIGINT,
    centera_to_atmos_migration_id BIGINT,
    centera_file_erasure_id BIGINT,
    centera_universal_access_id BIGINT,
    centera_intra_cluster_migr_id BIGINT,
    expansion_node_only_id BIGINT,
    FOREIGN KEY (sites_involved_id) REFERENCES SitesInvolved (id),
    FOREIGN KEY (services_scope_id) REFERENCES AtmosCenteraServicesScope (id),
    FOREIGN KEY (atmos_design_impl_id) REFERENCES AtmosDesignImpl (id),
    FOREIGN KEY (centera_design_impl_id) REFERENCES CenteraDesignImpl (id),
    FOREIGN KEY (centera_to_atmos_migration_id) REFERENCES CenteraToAtmosMigration (id),
    FOREIGN KEY (centera_file_erasure_id) REFERENCES CenteraFileErasure (id),
    FOREIGN KEY (centera_universal_access_id) REFERENCES CenteraUniversalAccess (id),
    FOREIGN KEY (centera_intra_cluster_migr_id) REFERENCES CenteraIntraClusterMigration (id),
    FOREIGN KEY (expansion_node_only_id) REFERENCES ExpansionNodeOnly (id));

CREATE SEQUENCE SVMwareAssessment INCREMENT BY 1 START WITH 1000;

CREATE TABLE VMwareAssessment (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SVMwareAssessment'),
    assessment_type INT,
    include_single_config BOOLEAN,
    include_multiple_config BOOLEAN,
    present_emc_report BOOLEAN,
    capacity_planner_sites_num INT,
    cap_planner_collectors_num INT,
    days_to_capt_collection_data INT,
    additional_servers_num INT,
    vsphere_clusters_num INT);

CREATE SEQUENCE SVMwareBackupRecovery INCREMENT BY 1 START WITH 1000;

CREATE TABLE VMwareBackupRecovery (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SVMwareBackupRecovery'),
    virtual_center_install_num INT,
    esx_servers_num INT,
    virtual_hosts_num INT,
    assessment_interviews_num INT);

CREATE SEQUENCE SVMwareHealthChecks INCREMENT BY 1 START WITH 1000;

CREATE TABLE VMwareHealthChecks (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SVMwareHealthChecks'),
    incl_executive_summary_review BOOLEAN,
    assessment_interviews_num INT,
    esx_servers_num INT,
    virtual_hosts_num INT);

CREATE SEQUENCE SVMwareReplication INCREMENT BY 1 START WITH 1000;

CREATE TABLE VMwareReplication (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SVMwareReplication'),
    install_srm BOOLEAN,
    customer_require_srm_training BOOLEAN,
    srm_adopters_num INT,
    srm_plans_num INT,
    celerra_ip BOOLEAN,
    vnx_block BOOLEAN,
    recover_point BOOLEAN,
    symmetrix_srdf BOOLEAN,
    new_symmetrix_num INT,
    existing_symmetrix_num INT,
    new_vnx_block_num INT,
    existing_vnx_block_num INT,
    new_rec_point_clusters_num INT,
    ex_rec_point_clusters_num INT,
    new_unified_file_servers_num INT,
    ex_celerra_file_servers_num INT);

CREATE SEQUENCE SVMwareTCOAssessment INCREMENT BY 1 START WITH 1000;

CREATE TABLE VMwareTCOAssessment (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SVMwareTCOAssessment'),
    assessment_scenario INT,
    data_center_locations_num INT,
    conducted_interviews_num INT);

CREATE SEQUENCE SVMwareVblockDesignImpl INCREMENT BY 1 START WITH 1000;

CREATE TABLE VMwareVblockDesignImpl (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SVMwareVblockDesignImpl'),
    include_partner_loe BOOLEAN,
    cisco BOOLEAN,
    vmware BOOLEAN,
    cisco_partner_hours DECIMAL(20,2),
    vmware_partner_hours DECIMAL(20,2),
    include_unified_file_options BOOLEAN,
    include_ionix_uim BOOLEAN,
    type1 BOOLEAN,
    type2 BOOLEAN,
    type1_vblocks_num INT,
    type1_luns_num INT,
    type1_vsphere_servers_num INT,
    type2_vblocks_num INT,
    type2_luns_num INT,
    type2_vsphere_servers_num INT,
    unified_file_type_vg2_num INT,
    unified_file_type_vg8_num INT);

CREATE SEQUENCE SVMwareVblockInfraImpl INCREMENT BY 1 START WITH 1000;

CREATE TABLE VMwareVblockInfraImpl (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SVMwareVblockInfraImpl'),
    vblock_300series_num INT,
    vblock_700series_num INT);

CREATE SEQUENCE SVMwareVblockInfraTechAss INCREMENT BY 1 START WITH 1000;

CREATE TABLE VMwareVblockInfraTechAss (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SVMwareVblockInfraTechAss'),
    assessed_sites_num INT,
    identified_servers_num INT);

CREATE SEQUENCE SVMwareVblock INCREMENT BY 1 START WITH 1000;

CREATE TABLE VMwareVblock (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SVMwareVblock'),
    design_impl BOOLEAN,
    infra_tech_assessment BOOLEAN,
    infra_impl BOOLEAN,
    vblock_design_impl_id BIGINT,
    vblock_infra_impl_id BIGINT,
    vblock_infra_tech_ass_id BIGINT,
    FOREIGN KEY (vblock_design_impl_id) REFERENCES VMwareVblockDesignImpl (id),
    FOREIGN KEY (vblock_infra_impl_id) REFERENCES VMwareVblockInfraImpl (id),
    FOREIGN KEY (vblock_infra_tech_ass_id) REFERENCES VMwareVblockInfraTechAss (id));

CREATE SEQUENCE SVMwareConverter INCREMENT BY 1 START WITH 1000;

CREATE TABLE VMwareConverter (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SVMwareConverter'),
    migration_performed BOOLEAN,
    include_jump_start_workshops BOOLEAN,
    installs_num INT,
    servers_num INT,
    additional_hours DECIMAL(20,2),
    billable_hours_per_str DECIMAL(20,2),
    billable_hours_for_testing DECIMAL(20,2));

CREATE SEQUENCE SVMwareSvMotion INCREMENT BY 1 START WITH 1000;

CREATE TABLE VMwareSvMotion (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SVMwareSvMotion'),
    include_virtual_infra_35 BOOLEAN,
    virtual_machines_num INT,
    additional_hours DECIMAL(20,2));

CREATE SEQUENCE SVMwareViewDesign INCREMENT BY 1 START WITH 1000;

CREATE TABLE VMwareViewDesign (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SVMwareViewDesign'),
    include_mssql BOOLEAN,
    include_oracle BOOLEAN,
    esx_servers_num INT,
    virtual_center_install_num INT,
    automated_desktop_pools_num INT,
    manual_desktop_pools_num INT,
    manager_conn_servers_num INT,
    manager_replica_servers_num INT,
    composer_instances_num INT,
    sql_databases_num INT,
    oracle_databases_num INT,
    manager_pods_num INT,
    manager_partitions_num INT,
    desktop_profiles_num INT,
    application_profiles_num INT,
    virt_desk_per_esx_host_num INT);

CREATE SEQUENCE SVMwareViewImpl INCREMENT BY 1 START WITH 1000;

CREATE TABLE VMwareViewImpl (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SVMwareViewImpl'),
    include_mssql BOOLEAN,
    include_oracle BOOLEAN,
    esx_servers_num INT,
    virtual_center_install_num INT,
    automated_desktop_pools_num INT,
    manual_desktop_pools_num INT,
    manager_conn_servers_num INT,
    manager_replica_servers_num INT,
    composer_instances_num INT,
    sql_databases_num INT,
    oracle_databases_num INT,
    billable_hours_for_testing DECIMAL(20,2));

CREATE SEQUENCE SVMwareView INCREMENT BY 1 START WITH 1000;

CREATE TABLE VMwareView (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SVMwareView'),
    design BOOLEAN,
    impl BOOLEAN,
    view_design_id BIGINT,
    view_impl_id BIGINT,
    FOREIGN KEY (view_design_id) REFERENCES VMwareViewDesign (id),
    FOREIGN KEY (view_impl_id) REFERENCES VMwareViewImpl (id));

CREATE SEQUENCE SVMwareVirtualInfra INCREMENT BY 1 START WITH 1000;

CREATE TABLE VMwareVirtualInfra (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SVMwareVirtualInfra'),
    server_storage_design_service BOOLEAN,
    infra_impl_service BOOLEAN,
    des_impl_jump_start_service BOOLEAN,
    design_impl_service BOOLEAN,
    jump_start_only_service BOOLEAN,
    storage_config_varieties_num INT,
    esx_hosts_num INT,
    identified_servers_num INT,
    include_rdm BOOLEAN,
    impl_vcenter_servers_num INT,
    impl_esxi_servers_num INT,
    impl_esxi_clusters_num INT,
    dij_vcenter_servers_num INT,
    dij_esx_clusters_num INT,
    dij_esx_servers_num INT,
    dij_billable_hour_for_testing DECIMAL(20,2),
    des_impl_vcenter_servers_num INT,
    design_impl_esx_clusters_num INT,
    design_impl_esx_servers_num INT);

CREATE SEQUENCE SVMwareVSphere INCREMENT BY 1 START WITH 1000;

CREATE TABLE VMwareVSphere (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SVMwareVSphere'),
    include_upgrades BOOLEAN,
    include_jump_start_workshops BOOLEAN,
    billable_hours_for_testing DECIMAL(20,2),
    vcenter_instances_num INT,
    esx_servers_num INT,
    jump_start_workshops_num INT);

CREATE SEQUENCE SVMwareServicesScope INCREMENT BY 1 START WITH 1000;

CREATE TABLE VMwareServicesScope (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SVMwareServicesScope'),
    assessment BOOLEAN,
    backup_recovery BOOLEAN,
    health_checks BOOLEAN,
    replication BOOLEAN,
    tco_assessment BOOLEAN,
    vce_vblock BOOLEAN,
    converter BOOLEAN,
    sv_motion BOOLEAN,
    vm_view BOOLEAN,
    virtual_infrastructure BOOLEAN,
    vsphere BOOLEAN);

CREATE SEQUENCE SVMwareRequestData INCREMENT BY 1 START WITH 1000;

CREATE TABLE VMwareRequestData (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SVMwareRequestData'),
    general_comments VARCHAR(256),
    services_scope_id BIGINT,
    assessment_id BIGINT,
    backup_recovery_id BIGINT,
    health_checks_id BIGINT,
    replication_id BIGINT,
    tco_assessment_id BIGINT,
    vce_vblock_id BIGINT,
    converter_id BIGINT,
    sv_motion_id BIGINT,
    view_id BIGINT,
    virtual_infrastructure_id BIGINT,
    vsphere_id BIGINT,
    FOREIGN KEY (services_scope_id) REFERENCES VMwareServicesScope (id),
    FOREIGN KEY (assessment_id) REFERENCES VMwareAssessment (id),
    FOREIGN KEY (backup_recovery_id) REFERENCES VMwareBackupRecovery (id),
    FOREIGN KEY (health_checks_id) REFERENCES VMwareHealthChecks (id),
    FOREIGN KEY (replication_id) REFERENCES VMwareReplication (id),
    FOREIGN KEY (tco_assessment_id) REFERENCES VMwareTCOAssessment (id),
    FOREIGN KEY (vce_vblock_id) REFERENCES VMwareVblock (id),
    FOREIGN KEY (converter_id) REFERENCES VMwareConverter (id),
    FOREIGN KEY (sv_motion_id) REFERENCES VMwareSvMotion (id),
    FOREIGN KEY (view_id) REFERENCES VMwareView (id),
    FOREIGN KEY (virtual_infrastructure_id) REFERENCES VMwareVirtualInfra (id),
    FOREIGN KEY (vsphere_id) REFERENCES VMwareVSphere (id));


CREATE SEQUENCE SRecoverPointInstallationAndIm INCREMENT BY 1 START WITH 1000;

CREATE TABLE RecoverPointInstallationAndIm (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SRecoverPointInstallationAndIm'),
    delivery_option_design BOOLEAN,
    delivery_option_impl BOOLEAN,
    recover_point_option_id BIGINT,
    rp_replication_method_local BOOLEAN,
    rp_replication_method_remote BOOLEAN,
    include_cluster_enabler BOOLEAN,
    recover_point_splitter_type_id BIGINT,
    vnx_or_clariion_involved BOOLEAN,
    vmax_dmx_or_symm_involved BOOLEAN,
    non_emc_or_3rd_party_storage_i BOOLEAN,
    no_source_array_involved BOOLEAN,
    xtrem_io_cluster_involved BOOLEAN,
    existing_physical_hosts_num INT,
    existing_esx_servers_num INT,
    rp_env_clients_servers_num INT,
    rp_appliances_num INT,
    storage_systems_req_splitter_n INT,
    include_bandwidth_analysis BOOLEAN,
    dispatch_emc_team BOOLEAN,
    include_3rd_party_storage_arr BOOLEAN,
    include_3rd_party_storage_arri BOOLEAN,
    non_emc_storage_arrays_num INT,
    include_replication_manager_ei BOOLEAN,
    include_vmware_vcenter_site_i BOOLEAN,
    ms_failover_clusters_num INT,
    rp_ce_cluster_nodes_num INT,
    rp_consistency_groups_num INT,
    FOREIGN KEY (recover_point_splitter_type_id) REFERENCES RecoverPointSplitterType (id),
    FOREIGN KEY (recover_point_option_id) REFERENCES RecoverPointOption (id));

CREATE SEQUENCE SRPAHardwareUpgrade INCREMENT BY 1 START WITH 1000;

CREATE TABLE RPAHardwareUpgrade (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SRPAHardwareUpgrade'),
    use_gen1_rpa_hardware BOOLEAN,
    rpas_to_upgrade_num INT);

CREATE SEQUENCE SIntelligentFabricSplitterMig INCREMENT BY 1 START WITH 1000;

CREATE TABLE IntelligentFabricSplitterMig (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SIntelligentFabricSplitterMig'),
    intelligent_fabric_migration_m BIGINT,
    grid_analysis_required BIGINT,
    vnx_or_clariion_involved BIGINT,
    vmax_dmx_or_symm_involved BIGINT,
    non_emc_or_3rd_party_storage_i BIGINT,
    no_source_array_involved BIGINT,
    xtrem_io_cluster_involved BIGINT,
    rpa_clusters_to_migrate_num INT,
    rpa_volumes_hosts_to_migrate_n INT,
    include_bandwidth_analysis BIGINT,
    include_3rd_party_storage_arr BIGINT,
    recover_point_option_id BIGINT,
    vplex_clusters_num INT,
    volumes_to_encapsulate_num INT,
    encaps_events_per_emc_rn INT,
    host_encapsulations_to_vplex_n INT,
    maintenance_windows_hours FLOAT,
    rp_env_clients_servers_num INT,
    rp_replication_method_local BOOLEAN,
    rp_replication_method_remote BIGINT,
    FOREIGN KEY (intelligent_fabric_migration_m) REFERENCES IntelligentFabricMigrationMet (id),
    FOREIGN KEY (recover_point_option_id) REFERENCES RecoverPointOption (id));

CREATE SEQUENCE SRecoverPoint INCREMENT BY 1 START WITH 1000;

CREATE TABLE RecoverPoint (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SRecoverPoint'),
    install_and_implement BOOLEAN,
    migrate_intelligent_fabric_spl BOOLEAN,
    upgrade_rpa_hardware BOOLEAN,
    installation_implementation_id BIGINT,
    intelligent_fabric_splitter_mi BIGINT,
    rpa_hardware_upgrade_id BIGINT,
    FOREIGN KEY (installation_implementation_id) REFERENCES RecoverPointInstallationAndIm (id),
    FOREIGN KEY (intelligent_fabric_splitter_mi) REFERENCES IntelligentFabricSplitterMig (id),
    FOREIGN KEY (rpa_hardware_upgrade_id) REFERENCES RPAHardwareUpgrade (id));

CREATE SEQUENCE SEDLDesignImpl INCREMENT BY 1 START WITH 1000;

CREATE TABLE EDLDesignImpl (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SEDLDesignImpl'),
    replication BOOLEAN,
    acsls BOOLEAN,
    auto_engine_failover BOOLEAN,
    integrated_backup_application BOOLEAN,
    backend_storage_arrays_num INT,
    backup_servers_num INT,
    physical_tape_lib_units_num INT,
    virtual_tape_libraries_num INT,
    virtual_tapes_num INT,
    virtual_tape_drives_num INT,
    replications_created_num INT);

CREATE SEQUENCE SEDL INCREMENT BY 1 START WITH 1000;

CREATE TABLE EDL (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SEDL'),
    knowledge_transfer_hours DECIMAL(20,2),
    design BOOLEAN,
    implementation BOOLEAN,
    design_impl_id BIGINT,
    FOREIGN KEY (design_impl_id) REFERENCES EDLDesignImpl (id));

CREATE SEQUENCE SAvamarOptions INCREMENT BY 1 START WITH 1000;

CREATE TABLE AvamarOptions (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SAvamarOptions'),
    configure_clients BOOLEAN,
    configure_ndmp BOOLEAN,
    configure_avf BOOLEAN,
    configure_advanced_network BOOLEAN,
    configure_download_server BOOLEAN,
    configure_replication BOOLEAN,
    vmware_integeration BOOLEAN,
    data_domain_integration BOOLEAN,
    configure_vcloud_director BOOLEAN);

CREATE SEQUENCE SAvamarPlugins INCREMENT BY 1 START WITH 1000;

CREATE TABLE AvamarPlugins (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SAvamarPlugins'),
    exchange BOOLEAN,
    sql_server BOOLEAN,
    oracle BOOLEAN,
    db2 BOOLEAN,
    sharepoint BOOLEAN,
    lotus_domino BOOLEAN,
    exchange_plugins_num INT,
    sql_server_plugins_num INT,
    oracle_plugins_num INT,
    db2_plugins_num INT,
    sharepoint_plugins_num INT,
    lotus_domino_plugins_num INT);

CREATE SEQUENCE SAvamarNDMP INCREMENT BY 1 START WITH 1000;

CREATE TABLE AvamarNDMP (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SAvamarNDMP'),
    emc_celerra BOOLEAN,
    network_appliance BOOLEAN,
    emc_isilon BOOLEAN,
    emc_vnx BOOLEAN,
    ndmp_nodes_num INT,
    include_multistream_support BOOLEAN,
    streams_per_node_num INT,
    celerra_targets_num INT,
    net_app_filer_targets_num INT,
    isilon_targets_num INT,
    vnx_targets_num INT,
    data_set_creation_hours DECIMAL(20,2));

CREATE SEQUENCE SAvamarDesign INCREMENT BY 1 START WITH 1000;

CREATE TABLE AvamarDesign (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SAvamarDesign'),
    plugins_id BIGINT,
    options_id BIGINT,
    servers_num INT,
    clients_num INT,
    esx_servers_num INT,
    image_level_backups_num INT,
    ndmp_nodes_num INT,
    ndmp_targets_num INT,
    expansion_nodes_num INT,
    FOREIGN KEY (plugins_id) REFERENCES AvamarPlugins (id),
    FOREIGN KEY (options_id) REFERENCES AvamarOptions (id));

CREATE SEQUENCE SAvamarImplementation INCREMENT BY 1 START WITH 1000;

CREATE TABLE AvamarImplementation (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SAvamarImplementation'),
    plugins_id BIGINT,
    options_id BIGINT,
    servers_num INT,
    clients_num INT,
    esx_servers_num INT,
    image_level_backups_num INT,
    billable_hours DECIMAL(20,2),
    incl_backup_recovery_manager BOOLEAN,
    include_hardware_installation BOOLEAN,
    data_nodes_num INT,
    data_set_creation_hours DECIMAL(20,2),
    install_type INT,
    auth_method INT,
    clients_percent DECIMAL(20,2),
    ndmp_id BIGINT,
    proxies_num INT,
    replication_sets_num INT,
    data_domain_servers_num INT,
    dd_boost_plugins_num INT,
    FOREIGN KEY (plugins_id) REFERENCES AvamarPlugins (id),
    FOREIGN KEY (options_id) REFERENCES AvamarOptions (id),
    FOREIGN KEY (ndmp_id) REFERENCES AvamarNDMP (id));

CREATE SEQUENCE SAvamarTapeOutImplementation INCREMENT BY 1 START WITH 1000;

CREATE TABLE AvamarTapeOutImplementation (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SAvamarTapeOutImplementation'),
    adt_type INT,
    grids_num INT,
    archive_servers_num INT,
    esx_servers_num INT,
    replication_connections_num INT,
    adt_transport_nodes_num INT,
    adt_controllers_num INT);

CREATE SEQUENCE SAvamarTapeOutDesign INCREMENT BY 1 START WITH 1000;

CREATE TABLE AvamarTapeOutDesign (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SAvamarTapeOutDesign'),
    include_domain_reconfiguring BOOLEAN,
    adt_controllers_num INT,
    adt_domains_num INT,
    adt_clients_num INT);

CREATE SEQUENCE SAvamarOperationalAssurance INCREMENT BY 1 START WITH 1000;

CREATE TABLE AvamarOperationalAssurance (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SAvamarOperationalAssurance'),
    include_operations_guide BOOLEAN,
    include_troubleshooting_guide BOOLEAN,
    include_high_level_arch BOOLEAN,
    grids_num INT,
    replication_sites_num INT);

CREATE SEQUENCE SAvamarHealthCheck INCREMENT BY 1 START WITH 1000;

CREATE TABLE AvamarHealthCheck (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SAvamarHealthCheck'),
    grids_num INT,
    assessment_interviews_num INT);

CREATE SEQUENCE SAvamarMigration INCREMENT BY 1 START WITH 1000;

CREATE TABLE AvamarMigration (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SAvamarMigration'),
    migration_type INT,
    include_client_reconf BOOLEAN,
    include_source_data_wipe BOOLEAN,
    source_sys_nodes_num INT,
    target_sys_nodes_num INT,
    repl_monitoring_events_num INT,
    reconfigure_clients_num INT);

CREATE SEQUENCE SAvamarIntegration INCREMENT BY 1 START WITH 1000;

CREATE TABLE AvamarIntegration (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SAvamarIntegration'),
    workshop BOOLEAN,
    pilot BOOLEAN,
    clients_num INT,
    configured_clients_num INT,
    dtlt_clients_activated BOOLEAN,
    grids_num INT);

CREATE SEQUENCE SAvamar INCREMENT BY 1 START WITH 1000;

CREATE TABLE Avamar (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SAvamar'),
    knowledge_transfer_hours DECIMAL(20,2),
    design_impl_service BOOLEAN,
    tape_out_design_impl_service BOOLEAN,
    operational_assurance_service BOOLEAN,
    health_check_service BOOLEAN,
    migration_service BOOLEAN,
    integration_service BOOLEAN,
    vcloud_director_service BOOLEAN,
    server_type_id BIGINT,
    design_deliver_option BOOLEAN,
    implementation_deliver_option BOOLEAN,
    design_id BIGINT,
    implementation_id BIGINT,
    tape_out_design_id BIGINT,
    tape_out_implementation_id BIGINT,
    operational_assurance_id BIGINT,
    health_check_id BIGINT,
    migration_id BIGINT,
    integration_id BIGINT,
    FOREIGN KEY (server_type_id) REFERENCES AvamarServerType (id),
    FOREIGN KEY (design_id) REFERENCES AvamarDesign (id),
    FOREIGN KEY (implementation_id) REFERENCES AvamarImplementation (id),
    FOREIGN KEY (tape_out_design_id) REFERENCES AvamarTapeOutDesign (id),
    FOREIGN KEY (tape_out_implementation_id) REFERENCES AvamarTapeOutImplementation (id),
    FOREIGN KEY (operational_assurance_id) REFERENCES AvamarOperationalAssurance (id),
    FOREIGN KEY (health_check_id) REFERENCES AvamarHealthCheck (id),
    FOREIGN KEY (migration_id) REFERENCES AvamarMigration (id),
    FOREIGN KEY (integration_id) REFERENCES AvamarIntegration (id));

CREATE SEQUENCE SDataDomainBoostBackupServer INCREMENT BY 1 START WITH 1000;

CREATE TABLE DataDomainBoostBackupServer (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SDataDomainBoostBackupServer'),
    nbu BOOLEAN,
    rman BOOLEAN);

CREATE SEQUENCE SDataDomainDesignImplContent INCREMENT BY 1 START WITH 1000;

CREATE TABLE DataDomainDesignImplContent (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SDataDomainDesignImplContent'),
    boost_backup_server_id BIGINT,
    integrate_sap_hana BOOLEAN,
    plan_design_implement_vtl BOOLEAN,
    include_ibm_iseries_brms BOOLEAN,
    ibm_pars_num INT,
    vtl_appliances_num INT,
    install_fibre_cards_num INT,
    create_vtls_num INT,
    backup_servers_num INT,
    appliances_for_ddboost_num INT,
    ora_rman_backup_servers_num INT,
    ora_backup_config_servers_num INT,
    sap_hana_databases_num INT,
    FOREIGN KEY (boost_backup_server_id) REFERENCES DataDomainBoostBackupServer (id));

CREATE SEQUENCE SDataDomainDesign INCREMENT BY 1 START WITH 1000;

CREATE TABLE DataDomainDesign (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SDataDomainDesign'),
    boost_backup_server_id BIGINT,
    integrate_sap_hana BOOLEAN,
    plan_design_implement_vtl BOOLEAN,
    include_ibm_iseries_brms BOOLEAN,
    ibm_pars_num INT,
    vtl_appliances_num INT,
    install_fibre_cards_num INT,
    create_vtls_num INT,
    backup_servers_num INT,
    appliances_for_ddboost_num INT,
    ora_rman_backup_servers_num INT,
    ora_backup_config_servers_num INT,
    sap_hana_databases_num INT,
    FOREIGN KEY (boost_backup_server_id) REFERENCES DataDomainBoostBackupServer (id));

CREATE SEQUENCE SDataDomainDesignAppModel INCREMENT BY 1 START WITH 1000;

CREATE TABLE DataDomainDesignAppModel (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SDataDomainDesignAppModel'),
    model_name VARCHAR(256),
    appliances_num INT);

CREATE TABLE DataDomainDesign_appModels (
    data_domain_design_id BIGINT NOT NULL,
    data_dom_design_app_model_id BIGINT NOT NULL,
    FOREIGN KEY (data_domain_design_id) REFERENCES DataDomainDesign (id),
    FOREIGN KEY (data_dom_design_app_model_id) REFERENCES DataDomainDesignAppModel (id));

CREATE SEQUENCE SDataDomainImplementation INCREMENT BY 1 START WITH 1000;

CREATE TABLE DataDomainImplementation (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SDataDomainImplementation'),
    boost_backup_server_id BIGINT,
    integrate_sap_hana BOOLEAN,
    plan_design_implement_vtl BOOLEAN,
    include_ibm_iseries_brms BOOLEAN,
    ibm_pars_num INT,
    vtl_appliances_num INT,
    install_fibre_cards_num INT,
    create_vtls_num INT,
    backup_servers_num INT,
    appliances_for_ddboost_num INT,
    ora_rman_backup_servers_num INT,
    ora_backup_config_servers_num INT,
    sap_hana_databases_num INT,
    FOREIGN KEY (boost_backup_server_id) REFERENCES DataDomainBoostBackupServer (id));

CREATE SEQUENCE SDataDomainImplApplianceModel INCREMENT BY 1 START WITH 1000;

CREATE TABLE DataDomainImplApplianceModel (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SDataDomainImplApplianceModel'),
    model_name VARCHAR(256),
    appliances_num INT,
    expansion_shelves_num INT,
    include_ipreplication BOOLEAN,
    device_type_id BIGINT,
    virtual_tape_library_app BOOLEAN,
    db_boost BOOLEAN,
    edl_virtual_tape_libs_num INT,
    dd_boost_servers_num INT,
    FOREIGN KEY (device_type_id) REFERENCES DataDomainDeviceType (id));

CREATE TABLE DataDomainImpl_appModels (
    data_domain_impl_id BIGINT NOT NULL,
    data_domain_impl_app_model_id BIGINT NOT NULL,
    FOREIGN KEY (data_domain_impl_id) REFERENCES DataDomainImplementation (id),
    FOREIGN KEY (data_domain_impl_app_model_id) REFERENCES DataDomainImplApplianceModel (id));

CREATE SEQUENCE SDataDomainUpgrade INCREMENT BY 1 START WITH 1000;

CREATE TABLE DataDomainUpgrade (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SDataDomainUpgrade'),
    upgrade_type_id BIGINT,
    appliances_num INT,
    dd890 BOOLEAN,
    dd890_appliances_num INT,
    dd990 BOOLEAN,
    dd990_appliances_num INT,
    dd4200 BOOLEAN,
    dd4200_appliances_num INT,
    dd4500 BOOLEAN,
    dd4500_appliances_num INT,
    dd7200 BOOLEAN,
    dd7200_appliances_num INT,
    storage_expansion_shelves_num INT,
    system_ctrl_upgrades_num INT,
    FOREIGN KEY (upgrade_type_id) REFERENCES DataDomainUpgradeType (id));

CREATE SEQUENCE SDataDomainVTL INCREMENT BY 1 START WITH 1000;

CREATE TABLE DataDomainVTL (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SDataDomainVTL'),
    include_ibm_iseries_brms BOOLEAN,
    ibm_pars_num INT,
    vtl_appliances_num INT,
    install_fibre_cards_num INT,
    create_vtls_num INT);

CREATE SEQUENCE SDataDomainExpansionShelf INCREMENT BY 1 START WITH 1000;

CREATE TABLE DataDomainExpansionShelf (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SDataDomainExpansionShelf'),
    storage_expansion_shelves_num INT);

CREATE SEQUENCE SDataDomainDataStaging INCREMENT BY 1 START WITH 1000;

CREATE TABLE DataDomainDataStaging (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SDataDomainDataStaging'),
    data_staging_type_id BIGINT,
    FOREIGN KEY (data_staging_type_id) REFERENCES DataDomainDataStagingType (id));

CREATE SEQUENCE SDataDomainIntegration INCREMENT BY 1 START WITH 1000;

CREATE TABLE DataDomainIntegration (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SDataDomainIntegration'),
    include_rman_scripting BOOLEAN,
    max_backup_window_time_id BIGINT,
    appliances_for_ddboost_num INT,
    servers_for_ddboost_num INT,
    ora_rman_backup_servers_num INT,
    ora_backup_config_servers_num INT,
    integration_type_id BIGINT,
    ibm_tivoli_storage_manager BOOLEAN,
    networker BOOLEAN,
    net_backup BOOLEAN,
    rman BOOLEAN,
    conducted_interviews_num INT,
    ibm_tsm_instances_num INT,
    networker_data_zones_num INT,
    sym_net_backup_domains_num INT,
    oracle_data_servers_num INT,
    sap_hana_databases_num INT,
    FOREIGN KEY (max_backup_window_time_id) REFERENCES DataDomainMaxBackupWindowTime (id),
    FOREIGN KEY (integration_type_id) REFERENCES DataDomainIntegrationType (id));

CREATE SEQUENCE SDataDomainHealthCheck INCREMENT BY 1 START WITH 1000;

CREATE TABLE DataDomainHealthCheck (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SDataDomainHealthCheck'),
    data_domain_appliances_num INT,
    assessment_interviews_num INT);

CREATE SEQUENCE SDataDomainMigration INCREMENT BY 1 START WITH 1000;

CREATE TABLE DataDomainMigration (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SDataDomainMigration'),
    migration_type_id BIGINT,
    centera2dd_migrations_num INT,
    dd2dd_migrations_num INT,
    monitoring_events_num INT,
    FOREIGN KEY (migration_type_id) REFERENCES DataDomainMigrationType (id));

CREATE SEQUENCE SDataDomainPreRack INCREMENT BY 1 START WITH 1000;

CREATE TABLE DataDomainPreRack (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SDataDomainPreRack'),
    boost_backup_server_id BIGINT,
    integrate_sap_hana BOOLEAN,
    plan_design_implement_vtl BOOLEAN,
    include_ibm_iseries_brms BOOLEAN,
    ibm_pars_num INT,
    vtl_appliances_num INT,
    install_fibre_cards_num INT,
    create_vtls_num INT,
    backup_servers_num INT,
    appliances_for_ddboost_num INT,
    ora_rman_backup_servers_num INT,
    ora_backup_config_servers_num INT,
    sap_hana_databases_num INT,
    pre_rack_type_id BIGINT,
    pre_racked_system_racks_num INT,
    edl_virtual_tape_libs_num INT,
    servers_for_ddboost_num INT,
    FOREIGN KEY (pre_rack_type_id) REFERENCES DataDomainPreRackType (id),
    FOREIGN KEY (boost_backup_server_id) REFERENCES DataDomainBoostBackupServer (id));

CREATE SEQUENCE SDataDomainBoost INCREMENT BY 1 START WITH 1000;

CREATE TABLE DataDomainBoost (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SDataDomainBoost'),
    include_rman_scripting BOOLEAN,
    max_backup_window_time_id BIGINT,
    appliances_for_ddboost_num INT,
    servers_for_ddboost_num INT,
    ora_rman_backup_servers_num INT,
    ora_backup_config_servers_num INT,
    boost_type_id BIGINT,
    FOREIGN KEY (max_backup_window_time_id) REFERENCES DataDomainMaxBackupWindowTime (id),
    FOREIGN KEY (boost_type_id) REFERENCES DataDomainBoostType (id));

CREATE SEQUENCE SDataDomainExtRetentionConv INCREMENT BY 1 START WITH 1000;

CREATE TABLE DataDomainExtRetentionConv (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SDataDomainExtRetentionConv'),
    applicances_to_convert_num INT);

CREATE SEQUENCE SDataDomainManCenterConf INCREMENT BY 1 START WITH 1000;

CREATE TABLE DataDomainManCenterConf (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SDataDomainManCenterConf'),
    management_center_config_type INT);

CREATE SEQUENCE SDataDomainSapHana INCREMENT BY 1 START WITH 1000;

CREATE TABLE DataDomainSapHana (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SDataDomainSapHana'),
    sap_hana_databases_num INT);

CREATE SEQUENCE SDataDomain INCREMENT BY 1 START WITH 1000;

CREATE TABLE DataDomain (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SDataDomain'),
    knowledge_transfer_hours DECIMAL(20,2),
    implement_service BOOLEAN,
    upgrade_service BOOLEAN,
    implement_vtl_service BOOLEAN,
    data_staging_service BOOLEAN,
    expansion_shelf_service BOOLEAN,
    integration_service BOOLEAN,
    health_check_service BOOLEAN,
    migration_service BOOLEAN,
    pre_racked_service BOOLEAN,
    boost_service BOOLEAN,
    ext_retention_conv_service BOOLEAN,
    mgmt_center_config_service BOOLEAN,
    sap_hana_service BOOLEAN,
    design_activity BOOLEAN,
    implementation_activity BOOLEAN,
    design_impl_identical BOOLEAN,
    design_id BIGINT,
    implementation_id BIGINT,
    upgrade_id BIGINT,
    vtl_id BIGINT,
    expansion_shelf_id BIGINT,
    data_staging_id BIGINT,
    integration_id BIGINT,
    health_check_id BIGINT,
    migration_id BIGINT,
    pre_rack_id BIGINT,
    boost_id BIGINT,
    ext_retention_conversion_id BIGINT,
    management_center_config_id BIGINT,
    sap_hana_id BIGINT,
    design_impl_content_id BIGINT,
    FOREIGN KEY (design_impl_content_id) REFERENCES DataDomainDesignImplContent (id),
    FOREIGN KEY (design_id) REFERENCES DataDomainDesign (id),
    FOREIGN KEY (implementation_id) REFERENCES DataDomainImplementation (id),
    FOREIGN KEY (upgrade_id) REFERENCES DataDomainUpgrade (id),
    FOREIGN KEY (vtl_id) REFERENCES DataDomainVTL (id),
    FOREIGN KEY (expansion_shelf_id) REFERENCES DataDomainExpansionShelf (id),
    FOREIGN KEY (data_staging_id) REFERENCES DataDomainDataStaging (id),
    FOREIGN KEY (integration_id) REFERENCES DataDomainIntegration (id),
    FOREIGN KEY (health_check_id) REFERENCES DataDomainHealthCheck (id),
    FOREIGN KEY (migration_id) REFERENCES DataDomainMigration (id),
    FOREIGN KEY (pre_rack_id) REFERENCES DataDomainPreRack (id),
    FOREIGN KEY (boost_id) REFERENCES DataDomainBoost (id),
    FOREIGN KEY (ext_retention_conversion_id) REFERENCES DataDomainExtRetentionConv (id),
    FOREIGN KEY (management_center_config_id) REFERENCES DataDomainManCenterConf (id),
    FOREIGN KEY (sap_hana_id) REFERENCES DataDomainSapHana (id));

CREATE SEQUENCE SDPADesign INCREMENT BY 1 START WITH 1000;

CREATE TABLE DPADesign (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SDPADesign'),
    install_on_extended_database BOOLEAN,
    include_analysis_jobs BOOLEAN,
    incl_recoverability_analysis BOOLEAN,
    incl_custom_report_dev BOOLEAN,
    incl_interface_customization BOOLEAN,
    include_scale_plan BOOLEAN,
    collection_nodes_num INT,
    collector_nodes_num INT);

CREATE SEQUENCE SDPAImplementation INCREMENT BY 1 START WITH 1000;

CREATE TABLE DPAImplementation (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SDPAImplementation'),
    upgrade_from_v5_environment BOOLEAN,
    incl_custom_report_dev BOOLEAN,
    incl_interface_customization BOOLEAN,
    incl_recoverability_analysis BOOLEAN,
    include_analysis_jobs BOOLEAN,
    upgrade_install_on_ext_db BOOLEAN,
    upgrade_incl_edl_monitoring BOOLEAN,
    upgrade_collection_nodes_num INT,
    upgrade_collector_nodes_num INT,
    upgrade_emc_disk_libs_num INT,
    crd_install_on_ext_db BOOLEAN,
    crd_include_edl_monitoring BOOLEAN,
    crd_collection_nodes_num INT,
    crd_collector_nodes_num INT,
    crd_emc_disk_libraries_num INT,
    ic_install_on_ext_db BOOLEAN,
    ic_include_edl_monitoring BOOLEAN,
    ic_collection_nodes_num INT,
    ic_collector_nodes_num INT,
    ic_emc_disk_libraries_num INT,
    ra_install_on_ext_db BOOLEAN,
    ra_include_edl_monitoring BOOLEAN,
    ra_collection_nodes_num INT,
    ra_collector_nodes_num INT,
    ra_emc_disk_libraries_num INT,
    recoverability_agents_num INT,
    aj_install_on_ext_db BOOLEAN,
    aj_include_edl_monitoring BOOLEAN,
    aj_collection_nodes_num INT,
    aj_collector_nodes_num INT,
    aj_emc_disk_libraries_num INT,
    analysis_jobs_num INT);

CREATE SEQUENCE SDPACustomization INCREMENT BY 1 START WITH 1000;

CREATE TABLE DPACustomization (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SDPACustomization'),
    incl_third_party_integ_dev BOOLEAN,
    include_analysis_jobs BOOLEAN,
    incl_interface_customization BOOLEAN,
    incl_custom_report_dev BOOLEAN,
    tpid_include_req_workshop BOOLEAN,
    tpid_include_scale_plan BOOLEAN,
    tpid_collection_nodes_num INT,
    tpid_collector_nodes_num INT,
    aj_include_req_workshop BOOLEAN,
    aj_include_scale_plan BOOLEAN,
    aj_collection_nodes_num INT,
    aj_collector_nodes_num INT,
    analysis_jobs_num INT,
    ic_include_req_workshop BOOLEAN,
    ic_include_scale_plan BOOLEAN,
    ic_collection_nodes_num INT,
    ic_collector_nodes_num INT,
    crd_include_req_workshop BOOLEAN,
    crd_include_scale_plan BOOLEAN,
    crd_collection_nodes_num INT,
    crd_collector_nodes_num INT);

CREATE SEQUENCE SDPAOperationalAssurance INCREMENT BY 1 START WITH 1000;

CREATE TABLE DPAOperationalAssurance (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SDPAOperationalAssurance'),
    include_requirements_workshop BOOLEAN,
    analysis_site_impl_num INT);

CREATE SEQUENCE SDPAUpgradeMigration INCREMENT BY 1 START WITH 1000;

CREATE TABLE DPAUpgradeMigration (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SDPAUpgradeMigration'),
    upgrade_migration_version INT,
    manual_migrations BOOLEAN,
    customization_migration BOOLEAN,
    estimated_migration_volumes INT,
    reconfigure_agents_num INT);

CREATE SEQUENCE SDPAHealthCheck INCREMENT BY 1 START WITH 1000;

CREATE TABLE DPAHealthCheck (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SDPAHealthCheck'),
    site_implementations_num INT);

CREATE SEQUENCE SDPA INCREMENT BY 1 START WITH 1000;

CREATE TABLE DPA (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SDPA'),
    knowledge_transfer_hours DECIMAL(20,2),
    implement_service BOOLEAN,
    operational_assurance_service BOOLEAN,
    customization_service BOOLEAN,
    upgrade_migration_service BOOLEAN,
    health_check_service BOOLEAN,
    design_activity BOOLEAN,
    implementation_activity BOOLEAN,
    design_id BIGINT,
    implementation_id BIGINT,
    operational_assurance_id BIGINT,
    customization_id BIGINT,
    upgrade_migration_id BIGINT,
    health_check_id BIGINT,
    FOREIGN KEY (design_id) REFERENCES DPADesign (id),
    FOREIGN KEY (implementation_id) REFERENCES DPAImplementation (id),
    FOREIGN KEY (operational_assurance_id) REFERENCES DPAOperationalAssurance (id),
    FOREIGN KEY (customization_id) REFERENCES DPACustomization (id),
    FOREIGN KEY (upgrade_migration_id) REFERENCES DPAUpgradeMigration (id),
    FOREIGN KEY (health_check_id) REFERENCES DPAHealthCheck (id));

CREATE SEQUENCE SNetworkerComponents INCREMENT BY 1 START WITH 1000;

CREATE TABLE NetworkerComponents (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SNetworkerComponents'),
    server BOOLEAN,
    advanced_backup_tech BOOLEAN,
    storage_nodes BOOLEAN,
    file_system_client_backups BOOLEAN,
    media_devices BOOLEAN,
    application_backups BOOLEAN,
    emc_backup_recovery_manager BOOLEAN);

CREATE SEQUENCE SNetworkerStorageNodes INCREMENT BY 1 START WITH 1000;

CREATE TABLE NetworkerStorageNodes (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SNetworkerStorageNodes'),
    storage_node BOOLEAN,
    dedicated_storage_node BOOLEAN,
    de_duplication_node BOOLEAN,
    storage_nodes_num INT,
    dedicated_storage_nodes_num INT,
    de_duplication_nodes_num INT);

CREATE SEQUENCE SNetworkerMediaDevices INCREMENT BY 1 START WITH 1000;

CREATE TABLE NetworkerMediaDevices (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SNetworkerMediaDevices'),
    auto_changer BOOLEAN,
    dd_boost BOOLEAN,
    tape_device BOOLEAN,
    atmos BOOLEAN,
    advanced_file_type_device BOOLEAN,
    auto_changers_num INT,
    tape_devices_num INT,
    adv_file_type_devices_num INT,
    dd_boost_devices_num INT,
    atmos_devices_num INT);

CREATE SEQUENCE SNetworkerServerDesign INCREMENT BY 1 START WITH 1000;

CREATE TABLE NetworkerServerDesign (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SNetworkerServerDesign'),
    impl_env INT,
    servers_num INT);

CREATE SEQUENCE SNetAdvancedBackupTechDesign INCREMENT BY 1 START WITH 1000;

CREATE TABLE NetAdvancedBackupTechDesign (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SNetAdvancedBackupTechDesign'),
    snmp BOOLEAN,
    vmware BOOLEAN,
    snapshot_management BOOLEAN,
    nas BOOLEAN,
    incl_vmware_protect_backups BOOLEAN,
    vmware_backup_appliances_num INT,
    snapshot_mgmt_app_hosts_num INT,
    snapshot_mgmt_mount_hosts_num INT,
    nas_data_movers_num INT,
    vmware_vsphere_hosts_num INT);

CREATE SEQUENCE SNetFileSystemClientBackDesign INCREMENT BY 1 START WITH 1000;

CREATE TABLE NetFileSystemClientBackDesign (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SNetFileSystemClientBackDesign'),
    clients_num INT,
    cluster_client_conn_num INT);

CREATE SEQUENCE SNetApplicationBackDesign INCREMENT BY 1 START WITH 1000;

CREATE TABLE NetApplicationBackDesign (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SNetApplicationBackDesign'),
    ms_sql BOOLEAN,
    exchange BOOLEAN,
    share_point BOOLEAN,
    hyperv BOOLEAN,
    oracle BOOLEAN,
    my_sql BOOLEAN,
    lotus_notes BOOLEAN,
    sap BOOLEAN,
    meditech BOOLEAN,
    include_mssql_server_cluster BOOLEAN,
    ms_sql_servers_num INT,
    impl_exch_granular_backups BOOLEAN,
    incl_clustered_exch_servers BOOLEAN,
    exchange_mailbox_servers_num INT,
    exchange_database_stores_num INT,
    share_point_incl_mssql_sc BOOLEAN,
    incl_gran_share_point_backups BOOLEAN,
    incl_share_point_dist_env BOOLEAN,
    share_point_mssql_servers_num INT,
    share_point_farms_num INT,
    share_point_web_apps_num INT,
    share_point_sites_num INT,
    share_point_sub_sites_num INT,
    hyperv_env_clustered BOOLEAN,
    hyperv_servers_num INT,
    clustered_oracle_servers BOOLEAN,
    ora_rman_backup_servers_num INT,
    ora_backup_config_dbs_num INT,
    my_sql_env_clustered BOOLEAN,
    my_sql_servers_num INT,
    lotus_notes_apps_clustered BOOLEAN,
    lotus_domino_instances_num INT,
    sap_env_clustered BOOLEAN,
    sap_app_servers_num INT,
    ms_sql_databases_num INT,
    exchange_data_domain_boost BOOLEAN,
    share_point_sql_databases_num INT,
    share_point_data_domain_boost BOOLEAN,
    incl_extensive_rman_scripting BOOLEAN,
    meditech_backup_type_id BIGINT,
    num_of_meditech_hosts INT,
    num_of_meditech_storage_arr INT,
    FOREIGN KEY (meditech_backup_type_id) REFERENCES MeditechBackupType (id));

CREATE SEQUENCE SNetworkerDesign INCREMENT BY 1 START WITH 1000;

CREATE TABLE NetworkerDesign (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SNetworkerDesign'),
    components_id BIGINT,
    storage_nodes_id BIGINT,
    media_devices_id BIGINT,
    server_id BIGINT,
    advanced_backup_tech_id BIGINT,
    file_system_client_backups_id BIGINT,
    application_backups_id BIGINT,
    FOREIGN KEY (components_id) REFERENCES NetworkerComponents (id),
    FOREIGN KEY (storage_nodes_id) REFERENCES NetworkerStorageNodes (id),
    FOREIGN KEY (media_devices_id) REFERENCES NetworkerMediaDevices (id),
    FOREIGN KEY (server_id) REFERENCES NetworkerServerDesign (id),
    FOREIGN KEY (advanced_backup_tech_id) REFERENCES NetAdvancedBackupTechDesign (id),
    FOREIGN KEY (file_system_client_backups_id) REFERENCES NetFileSystemClientBackDesign (id),
    FOREIGN KEY (application_backups_id) REFERENCES NetApplicationBackDesign (id));

CREATE SEQUENCE SNetworkerServerImpl INCREMENT BY 1 START WITH 1000;

CREATE TABLE NetworkerServerImpl (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SNetworkerServerImpl'),
    impl_env INT,
    servers_num INT,
    management_consoles_num INT);

CREATE SEQUENCE SNetAdvancedBackupTechImpl INCREMENT BY 1 START WITH 1000;

CREATE TABLE NetAdvancedBackupTechImpl (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SNetAdvancedBackupTechImpl'),
    snmp BOOLEAN,
    vmware BOOLEAN,
    snapshot_management BOOLEAN,
    nas BOOLEAN,
    incl_vmware_protect_backups BOOLEAN,
    vmware_backup_appliances_num INT,
    snapshot_mgmt_app_hosts_num INT,
    snapshot_mgmt_mount_hosts_num INT,
    nas_data_movers_num INT,
    snmp_modules_num INT,
    ext_vmware_protect_app_num INT,
    virtual_machine_clients_num INT,
    emc_disk_arrays_num INT);

CREATE SEQUENCE SNetFileSystemClientBackImpl INCREMENT BY 1 START WITH 1000;

CREATE TABLE NetFileSystemClientBackImpl (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SNetFileSystemClientBackImpl'),
    clients_num INT,
    cluster_client_conn_num INT,
    firewall_support BOOLEAN);

CREATE SEQUENCE SNetApplicationBackImpl INCREMENT BY 1 START WITH 1000;

CREATE TABLE NetApplicationBackImpl (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SNetApplicationBackImpl'),
    ms_sql BOOLEAN,
    exchange BOOLEAN,
    share_point BOOLEAN,
    hyperv BOOLEAN,
    oracle BOOLEAN,
    my_sql BOOLEAN,
    lotus_notes BOOLEAN,
    sap BOOLEAN,
    include_mssql_server_cluster BOOLEAN,
    ms_sql_servers_num INT,
    impl_exch_granular_backups BOOLEAN,
    incl_clustered_exch_servers BOOLEAN,
    exchange_mailbox_servers_num INT,
    exchange_database_stores_num INT,
    share_point_incl_mssql_sc BOOLEAN,
    incl_gran_share_point_backups BOOLEAN,
    incl_share_point_dist_env BOOLEAN,
    share_point_mssql_servers_num INT,
    share_point_farms_num INT,
    share_point_web_apps_num INT,
    share_point_sites_num INT,
    share_point_sub_sites_num INT,
    hyperv_env_clustered BOOLEAN,
    hyperv_servers_num INT,
    clustered_oracle_servers BOOLEAN,
    ora_rman_backup_servers_num INT,
    ora_backup_config_dbs_num INT,
    my_sql_env_clustered BOOLEAN,
    my_sql_servers_num INT,
    lotus_notes_apps_clustered BOOLEAN,
    lotus_domino_instances_num INT,
    sap_env_clustered BOOLEAN,
    sap_app_servers_num INT,
    ms_sql_incl_hardware_provider BOOLEAN,
    ms_sql_proxy_nodes_num INT,
    ms_sql_sc_nodes_num INT,
    exchange_incl_hw_provider BOOLEAN,
    exchange_proxy_nodes_num INT,
    exchange_db_stores_av_size INT,
    exchange_cluster_nodes_num INT,
    ccr_clusters_num INT,
    share_point_incl_hw_provider BOOLEAN,
    share_point_proxy_nodes_num INT,
    share_point_mssql_sc_node_num INT,
    share_point_phys_servers_num INT,
    hyperv_incl_hardware_provider BOOLEAN,
    hyperv_proxy_nodes_num INT,
    hyperv_nmm_configured BOOLEAN,
    hyperv_physical_servers_num INT,
    hyperv_virtual_machines_num INT,
    oracle_physical_servers_num INT,
    my_sql_physical_servers_num INT,
    lotus_notes_phys_servers_num INT,
    sap_physical_servers_num INT);

CREATE SEQUENCE SNetworkerImplementation INCREMENT BY 1 START WITH 1000;

CREATE TABLE NetworkerImplementation (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SNetworkerImplementation'),
    select_datazone_size BOOLEAN,
    datazone_size_id BIGINT,
    FOREIGN KEY (datazone_size_id) REFERENCES NetworkerDatazoneSize (id));

CREATE SEQUENCE SNetworkerUpgrade INCREMENT BY 1 START WITH 1000;

CREATE TABLE NetworkerUpgrade (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SNetworkerUpgrade'),
    server BOOLEAN,
    storage_nodes BOOLEAN,
    clients BOOLEAN,
    management_console BOOLEAN,
    current_version INT,
    upgrade_version INT,
    upgrade_to_new_hardware BOOLEAN,
    servers_num INT,
    storage_nodes_num INT,
    clients_num INT,
    management_consoles_num INT);

CREATE SEQUENCE SNetWorkerHealthCheck INCREMENT BY 1 START WITH 1000;

CREATE TABLE NetWorkerHealthCheck (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SNetWorkerHealthCheck'),
    include_emc_assessment BOOLEAN,
    data_zones_num INT,
    assessment_interviews_num INT);

CREATE SEQUENCE SNetworker INCREMENT BY 1 START WITH 1000;

CREATE TABLE Networker (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SNetworker'),
    knowledge_transfer_hours DECIMAL(20,2),
    implementation_service BOOLEAN,
    upgrade_planning_service BOOLEAN,
    health_check_service BOOLEAN,
    upgrade_service BOOLEAN,
    design_activity BOOLEAN,
    implementation_activity BOOLEAN,
    design_id BIGINT,
    implementation_id BIGINT,
    upgrade_id BIGINT,
    healthcheck_id BIGINT,
    FOREIGN KEY (design_id) REFERENCES NetworkerDesign (id),
    FOREIGN KEY (implementation_id) REFERENCES NetworkerImplementation (id),
    FOREIGN KEY (upgrade_id) REFERENCES NetworkerUpgrade (id),
    FOREIGN KEY (healthcheck_id) REFERENCES NetWorkerHealthCheck (id));

CREATE SEQUENCE SDPADServicesScope INCREMENT BY 1 START WITH 1000;

CREATE TABLE DPADServicesScope (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SDPADServicesScope'),
    avamar BOOLEAN,
    data_domain BOOLEAN,
    dpa BOOLEAN,
    edl BOOLEAN,
    networker BOOLEAN,
    dlm BOOLEAN,
    recover_point BOOLEAN,
    mozy BOOLEAN);

CREATE SEQUENCE SMozyCustom INCREMENT BY 1 START WITH 1000;

CREATE TABLE MozyCustom (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SMozyCustom'),
    account_setup_structure_config BOOLEAN,
    solutions_assurance BOOLEAN,
    branding BOOLEAN,
    federated_id_config BOOLEAN,
    develop_beta_plan_assist_roll BOOLEAN,
    administration_training BOOLEAN,
    api_workshop BOOLEAN,
    l1_support_training BOOLEAN,
    api_workshop_planning_hours DECIMAL(20,2),
    assist_pilot_rollout_hours DECIMAL(20,2),
    administration_training_hours DECIMAL(20,2),
    client_branding_hours DECIMAL(20,2),
    admin_console_branding_hours DECIMAL(20,2),
    web_access_branding_hours DECIMAL(20,2),
    api_workshop_hours DECIMAL(20,2),
    l1_support_training_hours DECIMAL(20,2));

CREATE SEQUENCE SMozyOEMBranding INCREMENT BY 1 START WITH 1000;

CREATE TABLE MozyOEMBranding (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SMozyOEMBranding'),
    client_branding_hours DECIMAL(20,2),
    admin_console_hours DECIMAL(20,2),
    web_access_hours DECIMAL(20,2));

CREATE SEQUENCE SMozyOutTasking INCREMENT BY 1 START WITH 1000;

CREATE TABLE MozyOutTasking (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SMozyOutTasking'),
    start_date DATE,
    out_tasking_hours DECIMAL(20,2));

CREATE SEQUENCE SMozy INCREMENT BY 1 START WITH 1000;

CREATE TABLE Mozy (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SMozy'),
    custom BOOLEAN,
    oem_branding BOOLEAN,
    out_tasking BOOLEAN,
    custom_id BIGINT,
    oem_branding_id BIGINT,
    out_tasking_id BIGINT,
    FOREIGN KEY (custom_id) REFERENCES MozyCustom (id),
    FOREIGN KEY (oem_branding_id) REFERENCES MozyOEMBranding (id),
    FOREIGN KEY (out_tasking_id) REFERENCES MozyOutTasking (id));

CREATE SEQUENCE SDPADRequestData INCREMENT BY 1 START WITH 1000;

CREATE TABLE DPADRequestData (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SDPADRequestData'),
    sites_involved VARCHAR(256),
    general_comments VARCHAR(256),
    services_scope_id BIGINT,
    avamar_id BIGINT,
    edl_id BIGINT,
    recover_point_id BIGINT,
    data_domain_id BIGINT,
    dpa_id BIGINT,
    networker_id BIGINT,
    mozy_id BIGINT,
    FOREIGN KEY (services_scope_id) REFERENCES DPADServicesScope (id),
    FOREIGN KEY (recover_point_id) REFERENCES RecoverPoint (id),
    FOREIGN KEY (edl_id) REFERENCES EDL (id),
    FOREIGN KEY (avamar_id) REFERENCES Avamar (id),
    FOREIGN KEY (data_domain_id) REFERENCES DataDomain (id),
    FOREIGN KEY (dpa_id) REFERENCES DPA (id),
    FOREIGN KEY (networker_id) REFERENCES Networker (id),
    FOREIGN KEY (mozy_id) REFERENCES Mozy (id));

CREATE SEQUENCE SCoreOptions INCREMENT BY 1 START WITH 1000;

CREATE TABLE CoreOptions (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SCoreOptions'),
    symm_os BOOLEAN,
    symm_mf BOOLEAN,
    vblock BOOLEAN,
    unified BOOLEAN,
    replication BOOLEAN,
    san BOOLEAN,
    isilon BOOLEAN,
    xtremeio BOOLEAN,
    vplex BOOLEAN,
    cta BOOLEAN,
    mainframe BOOLEAN,
    change_request BOOLEAN);

CREATE SEQUENCE SOtherRequestOptions INCREMENT BY 1 START WITH 1000;

CREATE TABLE OtherRequestOptions (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SOtherRequestOptions'),
    residency BOOLEAN,
    i_series BOOLEAN,
    disk_retention BOOLEAN,
    move_request BOOLEAN,
    health_checks BOOLEAN,
    not_listed BOOLEAN
);

CREATE SEQUENCE SDPADOptions INCREMENT BY 1 START WITH 1000;

CREATE TABLE DPADOptions (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SDPADOptions'),
    avamar BOOLEAN,
    source_one BOOLEAN,
    data_domain BOOLEAN,
    networker BOOLEAN,
    edl BOOLEAN,
    mozy BOOLEAN,
    dlm BOOLEAN,
    dpa BOOLEAN,
    recover_point BOOLEAN);

CREATE SEQUENCE SASDOptions INCREMENT BY 1 START WITH 1000;

CREATE TABLE ASDOptions (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SASDOptions'),
    srm BOOLEAN,
    app_sync BOOLEAN,
    atmos BOOLEAN,
    w4n BOOLEAN,
    centera BOOLEAN,
    vipr BOOLEAN,
    uim BOOLEAN,
    ncm BOOLEAN);

CREATE SEQUENCE SAffinityOptions INCREMENT BY 1 START WITH 1000;

CREATE TABLE AffinityOptions (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SAffinityOptions'),
    vmware BOOLEAN,
    pivotal BOOLEAN,
    rsa BOOLEAN,
    vce BOOLEAN,
    ecd BOOLEAN);

CREATE SEQUENCE SConsultingOptions INCREMENT BY 1 START WITH 1000;

CREATE TABLE ConsultingOptions (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SConsultingOptions'),
    blue_printing BOOLEAN,
    dcm BOOLEAN,
    staff BOOLEAN,
    p2v BOOLEAN,
    vmware BOOLEAN);

CREATE SEQUENCE SAttachment INCREMENT BY 1 START WITH 1000;

CREATE TABLE Attachment (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SAttachment'),
    attachment_filename VARCHAR(256),
    attachment_filepath VARCHAR(256),
    attachment_size BIGINT);

CREATE SEQUENCE SRequestContractData INCREMENT BY 1 START WITH 1000;

CREATE TABLE RequestContractData (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SRequestContractData'),
    sow_type_id BIGINT,
    customer_format_required BOOLEAN,
    services_agreement_type_id BIGINT,
    services_agreement_date TIMESTAMP,
    partner_information VARCHAR(256),
    FOREIGN KEY (sow_type_id) REFERENCES SowType (id),
    FOREIGN KEY (services_agreement_type_id) REFERENCES ServicesAgreementType (id));

CREATE SEQUENCE SStartRequestData INCREMENT BY 1 START WITH 1000;

CREATE TABLE StartRequestData (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SStartRequestData'),
    core_options_id BIGINT,
    dpad_options_id BIGINT,
    asd_options_id BIGINT,
    affinity_options_id BIGINT,
    consulting_options_id BIGINT,
    other_request_options_id BIGINT,
    selected_division_id BIGINT,
    selected_geography_id BIGINT,
    selected_state_id BIGINT,
    selected_district_id BIGINT,
    selected_pdm_name_id BIGINT,
    customer_name VARCHAR(256),
    project_name VARCHAR(256),
    project_type_id BIGINT,
    work_city VARCHAR(256),
    dx_quote_number VARCHAR(256),
    se_csd_name VARCHAR(256),
    pdm_name VARCHAR(256),
    pm_name VARCHAR(256),
    sfdc_number VARCHAR(256),
    se_csd_phone_country_code VARCHAR(256),
    se_csd_phone_number VARCHAR(256),
    meeting_status_id BIGINT,
    se_manager_name VARCHAR(256),
    program_delivery_manager_name VARCHAR(256),
    risk_level_id BIGINT,
    sow_language_id BIGINT,
    phone_call_request BOOLEAN,
    reseller_sold BOOLEAN,
    requested_return_date TIMESTAMP,
    return_equipment BOOLEAN,
    remote_access BOOLEAN,
    clearance_level_id BIGINT,
    request_contract_data_id BIGINT,
    service_request_scope TEXT,
    travel_requirements VARCHAR(256),
    expense_type_id BIGINT,
    oracle_party_id BIGINT,
    FOREIGN KEY (core_options_id) REFERENCES CoreOptions (id),
    FOREIGN KEY (dpad_options_id) REFERENCES DPADOptions (id),
    FOREIGN KEY (asd_options_id) REFERENCES ASDOptions (id),
    FOREIGN KEY (affinity_options_id) REFERENCES AffinityOptions (id),
    FOREIGN KEY (consulting_options_id) REFERENCES ConsultingOptions (id),
    FOREIGN KEY (other_request_options_id) REFERENCES OtherRequestOptions (id),
    FOREIGN KEY (selected_division_id) REFERENCES Division (id),
    FOREIGN KEY (selected_geography_id) REFERENCES Geography (id),
    FOREIGN KEY (selected_state_id) REFERENCES GeoState (id),
    FOREIGN KEY (selected_district_id) REFERENCES SalesDistrict (id),
    FOREIGN KEY (selected_pdm_name_id) REFERENCES PdmName (id),
    FOREIGN KEY (project_type_id) REFERENCES ProjectType (id),
    FOREIGN KEY (meeting_status_id) REFERENCES MeetingStatus (id),
    FOREIGN KEY (risk_level_id) REFERENCES RiskLevel (id),
    FOREIGN KEY (sow_language_id) REFERENCES SowLanguage (id),
    FOREIGN KEY (clearance_level_id) REFERENCES ClearanceLevel (id),
    FOREIGN KEY (request_contract_data_id) REFERENCES RequestContractData (id),
    FOREIGN KEY (expense_type_id) REFERENCES ExpenseType (id));

CREATE SEQUENCE SStartRequestData_attachments INCREMENT BY 1 START WITH 1000;

CREATE TABLE StartRequestData_attachments (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SStartRequestData_attachments'),
    start_request_data_id BIGINT,
    attachment_id BIGINT,
    FOREIGN KEY (start_request_data_id) REFERENCES StartRequestData (id),
    FOREIGN KEY (attachment_id) REFERENCES Attachment (id));

CREATE SEQUENCE SSiteInformation INCREMENT BY 1 START WITH 1000;

CREATE TABLE SiteInformation (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SSiteInformation'),
    address VARCHAR(2048),
    trailer_access BOOLEAN,
    loading_docks BOOLEAN,
    second_floor BOOLEAN,
    lift_gate BOOLEAN,
    packing_date VARCHAR(2048),
    pickup_date VARCHAR(2048),
    delivery_date VARCHAR(2048));

CREATE SEQUENCE SMoveRequestData INCREMENT BY 1 START WITH 1000;

CREATE TABLE MoveRequestData (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SMoveRequestData'),
    general_comments VARCHAR(2048),
    description VARCHAR(2048),
    after_hours_mss BOOLEAN,
    project_timeline VARCHAR(2048),
    target_date VARCHAR(2048),
    emc_racks_cnt INT,
    non_emc_racks_cnt INT,
    no_rack VARCHAR(2048),
    equip_no_maint_contract BOOLEAN,
    emc_mv_svcs BOOLEAN,
    after_hours_pickup BOOLEAN,
    single_event BOOLEAN,
    cfg_reset BOOLEAN,
    emc_packing_needed BOOLEAN,
    total_value VARCHAR(2048),
    comments VARCHAR(2048),
    shipping_timeline VARCHAR(2048),
    equipment VARCHAR(2048),
    recertification_required BOOLEAN,
    scope_move_services BOOLEAN NOT NULL,
    scope_power_up_down BOOLEAN NOT NULL,
    scope_reinstall BOOLEAN NOT NULL,
    scope_configuration BOOLEAN NOT NULL,
    pu_equipment VARCHAR(2048),
    install_equipment VARCHAR(2048),
    ip_change_required BOOLEAN,
    cust_requirements VARCHAR(2048));

CREATE TABLE MoveRequestData_SI (
    move_request_data_id BIGINT NOT NULL,
    site_information_id BIGINT NOT NULL,
    FOREIGN KEY (move_request_data_id) REFERENCES MoveRequestData (id),
    FOREIGN KEY (site_information_id) REFERENCES SiteInformation (id));

CREATE SEQUENCE SChangeRequestData INCREMENT BY 1 START WITH 1000;

CREATE TABLE ChangeRequestData (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SChangeRequestData'),
    general_comments VARCHAR(2048),
    no_of_months INT);

CREATE SEQUENCE SChangeRequestData_HBM INCREMENT BY 1 START WITH 1000;

CREATE TABLE ChangeRequestData_HBM (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SChangeRequestData_HBM'),
    rows_id BIGINT,
    changerequestdata_id BIGINT,
    FOREIGN KEY (changerequestdata_id) REFERENCES ChangeRequestData (id));

CREATE SEQUENCE SHoursByMonth INCREMENT BY 1 START WITH 1000;

CREATE TABLE HoursByMonth (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SHoursByMonth'),
    sap_wbs_element_no VARCHAR(2048));

CREATE SEQUENCE SHoursByMonth_RoleHoursByMonth INCREMENT BY 1 START WITH 1000;

CREATE TABLE HoursByMonth_RoleHoursByMonth (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SHoursByMonth_RoleHoursByMonth'),
    rows_id BIGINT,
    hoursbymonth_id BIGINT,
    FOREIGN KEY (hoursbymonth_id) REFERENCES HoursByMonth (id));

CREATE SEQUENCE SRoleHoursByMonth INCREMENT BY 1 START WITH 1000;

CREATE TABLE RoleHoursByMonth (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SRoleHoursByMonth'),
    role VARCHAR(2048));

CREATE SEQUENCE SRoleHoursByMonth_Hours INCREMENT BY 1 START WITH 1000;

CREATE TABLE RoleHoursByMonth_Hours (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SRoleHoursByMonth_Hours'),
    month_num INT,
    hours VARCHAR(10),
    rolehoursbymonth_id BIGINT,
    FOREIGN KEY (rolehoursbymonth_id) REFERENCES RoleHoursByMonth (id));

CREATE SEQUENCE SCollector INCREMENT BY 1 START WITH 1000;

CREATE TABLE Collector (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SCollector'),
    name VARCHAR(256) NOT NULL);

CREATE SEQUENCE SDCSolutionPack INCREMENT BY 1 START WITH 1000;

CREATE TABLE DCSolutionPack (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SDCSolutionPack'),
    name VARCHAR(256) NOT NULL);

CREATE SEQUENCE SEMCSolutionPack INCREMENT BY 1 START WITH 1000;

CREATE TABLE EMCSolutionPack (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SEMCSolutionPack'),
    name VARCHAR(256) NOT NULL);

CREATE SEQUENCE SMobileSolutionPack INCREMENT BY 1 START WITH 1000;

CREATE TABLE MobileSolutionPack (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SMobileSolutionPack'),
    name VARCHAR(256) NOT NULL);

CREATE SEQUENCE SNetworkReportPack INCREMENT BY 1 START WITH 1000;

CREATE TABLE NetworkReportPack (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SNetworkReportPack'),
    name VARCHAR(256) NOT NULL);

CREATE SEQUENCE SServerReportPack INCREMENT BY 1 START WITH 1000;

CREATE TABLE ServerReportPack (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SServerReportPack'),
    name VARCHAR(256) NOT NULL);

CREATE SEQUENCE SSmartsDomainType INCREMENT BY 1 START WITH 1000;

CREATE TABLE SmartsDomainType (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SSmartsDomainType'),
    name VARCHAR(256) NOT NULL);

CREATE SEQUENCE SStorageReportPack INCREMENT BY 1 START WITH 1000;

CREATE TABLE StorageReportPack (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SStorageReportPack'),
    name VARCHAR(256) NOT NULL);

CREATE SEQUENCE SVOIPSolutionPack INCREMENT BY 1 START WITH 1000;

CREATE TABLE VOIPSolutionPack (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SVOIPSolutionPack'),
    name VARCHAR(256) NOT NULL);

CREATE SEQUENCE SVPNReportPack INCREMENT BY 1 START WITH 1000;

CREATE TABLE VPNReportPack (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SVPNReportPack'),
    name VARCHAR(256) NOT NULL);

CREATE SEQUENCE SWANAccelerator INCREMENT BY 1 START WITH 1000;

CREATE TABLE WANAccelerator (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SWANAccelerator'),
    name VARCHAR(256) NOT NULL);

CREATE SEQUENCE SWiFiReportPack INCREMENT BY 1 START WITH 1000;

CREATE TABLE WiFiReportPack (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SWiFiReportPack'),
    name VARCHAR(256) NOT NULL);

CREATE SEQUENCE SSRMRequestData INCREMENT BY 1 START WITH 1000;

CREATE TABLE SRMRequestData (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SSRMRequestData'),
    new_install BOOLEAN,
    migration BOOLEAN,
    v_app BOOLEAN,
    emc_control_center BOOLEAN,
    onsite_or_remote BOOLEAN,
    keyboard_access BOOLEAN,
    general_comments VARCHAR(2048),
    aix_vio INT,
    brocade INT,
    cisco_mds INT,
    cisco_ucs INT,
    converged_infra INT,
    data_centers INT,
    data_domain INT,
    emc_atmos INT,
    emc_avamar INT,
    emc_centera INT,
    emc_data_prot_adv INT,
    emc_isilon_nas INT,
    emc_recover_pt INT,
    emc_vipr INT,
    emc_vmax_symm INT,
    emc_vnx_block INT,
    emc_vnx_file_nas INT,
    emc_vplex INT,
    vmware_esx_servers INT,
    xtrem_io INT,
    hitachi_dev_mgr INT,
    hp_par_store INT,
    hp_eva INT,
    hp_storage_works INT,
    hyperv INT,
    ibm_ds_series INT,
    ibm_san_vol_contrlr INT,
    ibm_svc INT,
    ibm_xiv INT,
    net_app_filer_nas INT,
    oracle INT,
    physical_hosts INT,
    san_ports INT,
    vi_san_perf_probes INT);

CREATE SEQUENCE SW4NData INCREMENT BY 1 START WITH 1000;

CREATE TABLE W4NData (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SW4NData'),
    general_comments VARCHAR(2048),
    w4n_install BOOLEAN NOT NULL,
    w4n_upgrade BOOLEAN NOT NULL,
    existing_smarts_cust BOOLEAN NOT NULL,
    add_lab_install BOOLEAN NOT NULL,
    itpr_migration BOOLEAN NOT NULL,
    w4n_failover BOOLEAN,
    total_managed_devices INT,
    total_managed_pi INT,
    other_not_listed VARCHAR(1024),
    number_luns INT,
    number_disks INT,
    number_arrays INT,
    storage_soln_pack BOOLEAN,
    traffic_flows BOOLEAN,
    transactions BOOLEAN,
    enabled_flows_count INT);

CREATE SEQUENCE SW4NData_SmartsDomainType INCREMENT BY 1 START WITH 1000;

CREATE TABLE W4NData_SmartsDomainType (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SW4NData_SmartsDomainType'),
    w4n_data_id BIGINT,
    smarts_domain_type_id BIGINT,
    FOREIGN KEY (w4n_data_id) REFERENCES W4NData (id),
    FOREIGN KEY (smarts_domain_type_id) REFERENCES SmartsDomainType (id));

CREATE SEQUENCE SW4NData_EMCSolutionPack INCREMENT BY 1 START WITH 1000;

CREATE TABLE W4NData_EMCSolutionPack (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SW4NData_EMCSolutionPack'),
    w4n_data_id BIGINT,
    emcsolutionpack_id BIGINT,
    FOREIGN KEY (w4n_data_id) REFERENCES W4NData (id),
    FOREIGN KEY (emcsolutionpack_id) REFERENCES EMCSolutionPack (id));

CREATE SEQUENCE SW4NData_WiFiReportPack INCREMENT BY 1 START WITH 1000;

CREATE TABLE W4NData_WiFiReportPack (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SW4NData_WiFiReportPack'),
    w4n_data_id BIGINT,
    wifireportpack_id BIGINT,
    FOREIGN KEY (w4n_data_id) REFERENCES W4NData (id),
    FOREIGN KEY (wifireportpack_id) REFERENCES WiFiReportPack (id));

CREATE SEQUENCE SW4NData_DCSolutionPack INCREMENT BY 1 START WITH 1000;

CREATE TABLE W4NData_DCSolutionPack (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SW4NData_DCSolutionPack'),
    w4n_data_id BIGINT,
    dcsolutionpack_id BIGINT,
    FOREIGN KEY (w4n_data_id) REFERENCES W4NData (id),
    FOREIGN KEY (dcsolutionpack_id) REFERENCES DCSolutionPack (id));

CREATE SEQUENCE SW4NData_VOIPSolutionPack INCREMENT BY 1 START WITH 1000;

CREATE TABLE W4NData_VOIPSolutionPack (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SW4NData_VOIPSolutionPack'),
    w4n_data_id BIGINT,
    voipsolutionpack_id BIGINT,
    FOREIGN KEY (w4n_data_id) REFERENCES W4NData (id),
    FOREIGN KEY (voipsolutionpack_id) REFERENCES VOIPSolutionPack (id));

CREATE SEQUENCE SW4NData_MobileSolutionPack INCREMENT BY 1 START WITH 1000;

CREATE TABLE W4NData_MobileSolutionPack (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SW4NData_MobileSolutionPack'),
    w4n_data_id BIGINT,
    mobilesolutionpack_id BIGINT,
    FOREIGN KEY (w4n_data_id) REFERENCES W4NData (id),
    FOREIGN KEY (mobilesolutionpack_id) REFERENCES MobileSolutionPack (id));

CREATE SEQUENCE SW4NData_Collector INCREMENT BY 1 START WITH 1000;

CREATE TABLE W4NData_Collector (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SW4NData_Collector'),
    w4n_data_id BIGINT,
    collector_id BIGINT,
    FOREIGN KEY (w4n_data_id) REFERENCES W4NData (id),
    FOREIGN KEY (collector_id) REFERENCES Collector (id));

CREATE SEQUENCE SW4NData_NetworkReportPack INCREMENT BY 1 START WITH 1000;

CREATE TABLE W4NData_NetworkReportPack (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SW4NData_NetworkReportPack'),
    w4n_data_id BIGINT,
    networkreportpack_id BIGINT,
    FOREIGN KEY (w4n_data_id) REFERENCES W4NData (id),
    FOREIGN KEY (networkreportpack_id) REFERENCES NetworkReportPack (id));

CREATE SEQUENCE SW4NData_VPNReportPack INCREMENT BY 1 START WITH 1000;

CREATE TABLE W4NData_VPNReportPack (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SW4NData_VPNReportPack'),
    w4n_data_id BIGINT,
    vpnreportpack_id BIGINT,
    FOREIGN KEY (w4n_data_id) REFERENCES W4NData (id),
    FOREIGN KEY (vpnreportpack_id) REFERENCES VPNReportPack (id));

CREATE SEQUENCE SW4NData_WANAccelerator INCREMENT BY 1 START WITH 1000;

CREATE TABLE W4NData_WANAccelerator (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SW4NData_WANAccelerator'),
    w4n_data_id BIGINT,
    wanaccelerator_id BIGINT,
    FOREIGN KEY (w4n_data_id) REFERENCES W4NData (id),
    FOREIGN KEY (wanaccelerator_id) REFERENCES WANAccelerator (id));

CREATE SEQUENCE SW4NData_ServerReportPack INCREMENT BY 1 START WITH 1000;

CREATE TABLE W4NData_ServerReportPack (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SW4NData_ServerReportPack'),
    w4n_data_id BIGINT,
    serverreportpack_id BIGINT,
    FOREIGN KEY (w4n_data_id) REFERENCES W4NData (id),
    FOREIGN KEY (serverreportpack_id) REFERENCES ServerReportPack (id));

CREATE SEQUENCE SW4NData_StorageReportPack INCREMENT BY 1 START WITH 1000;

CREATE TABLE W4NData_StorageReportPack (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SW4NData_StorageReportPack'),
    w4n_data_id BIGINT,
    storagereportpack_id BIGINT,
    FOREIGN KEY (w4n_data_id) REFERENCES W4NData (id),
    FOREIGN KEY (storagereportpack_id) REFERENCES StorageReportPack (id));

CREATE SEQUENCE SUnfundedProjectData INCREMENT BY 1 START WITH 1000;

CREATE TABLE UnfundedProjectData (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SUnfundedProjectData'),
    general_comments VARCHAR(2048),
    summary VARCHAR(1024),
    roi VARCHAR(1024),
    environment_type VARCHAR(1024),
    est_book_value DECIMAL,
    purchase_decision_dt TIMESTAMP,
    special_req VARCHAR(1024),
    start_dt TIMESTAMP,
    end_dt TIMESTAMP);

CREATE SEQUENCE SXtremeDataMobilityType INCREMENT BY 1 START WITH 1000;

CREATE TABLE XtremeDataMobilityType (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SXtremeDataMobilityType'),
    name VARCHAR(256) NOT NULL);

CREATE SEQUENCE SXtremeServices INCREMENT BY 1 START WITH 1000;

CREATE TABLE XtremeServices (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SXtremeServices'),
    design_and_impl BOOLEAN,
    cluster_expansion BOOLEAN,
    cache BOOLEAN,
    sf BOOLEAN,
    oracle_local_replication BOOLEAN);

CREATE SEQUENCE SXtremeDataMigration INCREMENT BY 1 START WITH 1000;

CREATE TABLE XtremeDataMigration (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SXtremeDataMigration'),
    planning_and_design BOOLEAN,
    impl_and_migration BOOLEAN,
    xtreme_host_migration_tool_id BIGINT,
    hosts_migrated_by_migrator_num INT,
    hosts_migrated_by_ppme_num INT,
    include_esx_host_mig_vmotion BOOLEAN,
    rcli_installs_num INT,
    vmware_vm_vmotion_storage_num INT,
    storage_vmotion_addit_hours DECIMAL(20,2),
    implement_vplex_data_mobility BOOLEAN,
    xtreme_data_mobility_type_id BIGINT,
    use_encapsulation_under_vplex BOOLEAN,
    storage_volums_vplex_num INT,
    vplex_virtual_volumes_num INT,
    vplex_mirrors_num INT,
    vplex_data_mobility_jobs_num INT,
    implement_xtreme_io_snapshots BOOLEAN,
    swing_frame_box_required BOOLEAN,
    swing_box_hosts_emc_num INT,
    swing_box_hosts_migrator_num INT,
    swing_box_hosts_ppme_num INT,
    include_vmware_35_infra BOOLEAN,
    total_source_target_sites_num INT,
    new_physical_hosts_design_num INT,
    new_esx_servers_in_design_num INT,
    new_enterprise_directors_num INT,
    new_departmental_switches_num INT,
    new_vnx_block_stor_arrays_num INT,
    new_symmetrix_stor_arrays_num INT,
    vnx_blocks_to_upgrade_num INT,
    symmetrix_to_upgrade_num INT,
    total_source_arrays_num INT,
    total_target_arrays_num INT,
    device_size_changes_required BOOLEAN,
    source_data_amount_to_migrate INT,
    hosts_to_migrate_by_emc_num INT,
    total_hosts_to_migrate_num INT,
    customer_zonning_switches BOOLEAN,
    hosts_booted_from_san_num INT,
    customer_lun_device_allocation BOOLEAN,
    FOREIGN KEY (xtreme_host_migration_tool_id) REFERENCES XtremeHostBasedMigrationTool (id),
    FOREIGN KEY (xtreme_data_mobility_type_id) REFERENCES XtremeDataMobilityType (id));

CREATE SEQUENCE SXtremeDesignImpl INCREMENT BY 1 START WITH 1000;

CREATE TABLE XtremeDesignImpl (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SXtremeDesignImpl'),
    emc_customer_rack BOOLEAN,
    cluster_config_2_4_bricks BOOLEAN,
    additional_testing BOOLEAN,
    additional_monitoring BOOLEAN,
    scripting_work BOOLEAN,
    include_emc_equipment_removal BOOLEAN,
    include_xtreme_io_migration BOOLEAN,
    xtreme_io_clusters_num BIGINT,
    xtreme_io_bricks_num BIGINT,
    xtreme_io_hosts_num BIGINT,
    xtreme_snapshots_num BIGINT,
    xtreme_io_bricks_added_num BIGINT,
    deployed_infin_switches_num BIGINT,
    xtreme_data_migration_id BIGINT,
    FOREIGN KEY (xtreme_data_migration_id) REFERENCES XtremeDataMigration (id));

CREATE SEQUENCE SXtremeCache INCREMENT BY 1 START WITH 1000;

CREATE TABLE XtremeCache (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SXtremeCache'),
    is_assessment BOOLEAN,
    flash_cards_num BIGINT,
    include_cache_install_config BOOLEAN,
    cache_install_hosts_num BIGINT);

CREATE SEQUENCE SXtremeSF INCREMENT BY 1 START WITH 1000;

CREATE TABLE XtremeSF (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SXtremeSF'),
    flash_cards_num BIGINT,
    cards_install_hosts_num BIGINT,
    cache_install_hosts_num BIGINT);

CREATE SEQUENCE SXtremeOracleLocalReplication INCREMENT BY 1 START WITH 1000;

CREATE TABLE XtremeOracleLocalReplication (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SXtremeOracleLocalReplication'),
    perform_planning_design_shots BOOLEAN,
    functional_overview_hours DECIMAL(20,2));

CREATE SEQUENCE SXtremeRequestData INCREMENT BY 1 START WITH 1000;

CREATE TABLE XtremeRequestData (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SXtremeRequestData'),
    knowledge_transfer_hours DECIMAL(20,2),
    general_comments VARCHAR(2048),
    xtreme_design_impl_id BIGINT,
    xtreme_services_id BIGINT,
    xtreme_cache_id BIGINT,
    xtreme_sf_id BIGINT,
    xtreme_oracle_local_repl_id BIGINT,
    FOREIGN KEY (xtreme_design_impl_id) REFERENCES XtremeDesignImpl (id),
    FOREIGN KEY (xtreme_services_id) REFERENCES XtremeServices (id),
    FOREIGN KEY (xtreme_cache_id) REFERENCES XtremeCache (id),
    FOREIGN KEY (xtreme_sf_id) REFERENCES XtremeSF (id),
    FOREIGN KEY (xtreme_oracle_local_repl_id) REFERENCES XtremeOracleLocalReplication (id));

CREATE SEQUENCE SMultipleTheatersLangsInvOpt INCREMENT BY 1 START WITH 1000;

CREATE TABLE MultipleTheatersLangsInvOpt (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SMultipleTheatersLangsInvOpt'),
    name VARCHAR(256),
    risk INT);

CREATE SEQUENCE SMultipleWorkgroupsDiscOpt INCREMENT BY 1 START WITH 1000;

CREATE TABLE MultipleWorkgroupsDiscOpt (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SMultipleWorkgroupsDiscOpt'),
    name VARCHAR(256),
    risk INT);

CREATE SEQUENCE SEMCClientOption INCREMENT BY 1 START WITH 1000;

CREATE TABLE EMCClientOption (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SEMCClientOption'),
    name VARCHAR(256),
    risk INT);

CREATE SEQUENCE SEMCClientRelationshipOption INCREMENT BY 1 START WITH 1000;

CREATE TABLE EMCClientRelationshipOption (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SEMCClientRelationshipOption'),
    name VARCHAR(256),
    risk INT);

CREATE SEQUENCE SProcessStaffMaturityOption INCREMENT BY 1 START WITH 1000;

CREATE TABLE ProcessStaffMaturityOption (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SProcessStaffMaturityOption'),
    name VARCHAR(256),
    risk INT);

CREATE SEQUENCE SClientEnvDocumentationOption INCREMENT BY 1 START WITH 1000;

CREATE TABLE ClientEnvDocumentationOption (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SClientEnvDocumentationOption'),
    name VARCHAR(256),
    risk INT);

CREATE SEQUENCE SProjectScopeUnderstandOption INCREMENT BY 1 START WITH 1000;

CREATE TABLE ProjectScopeUnderstandOption (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SProjectScopeUnderstandOption'),
    name VARCHAR(256),
    risk INT);

CREATE SEQUENCE SProjectImpactOption INCREMENT BY 1 START WITH 1000;

CREATE TABLE ProjectImpactOption (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SProjectImpactOption'),
    name VARCHAR(256),
    risk INT);

CREATE SEQUENCE SProjectSponsorInvOption INCREMENT BY 1 START WITH 1000;

CREATE TABLE ProjectSponsorInvOption (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SProjectSponsorInvOption'),
    name VARCHAR(256),
    risk INT);

CREATE SEQUENCE SOfferingMaturityOption INCREMENT BY 1 START WITH 1000;

CREATE TABLE OfferingMaturityOption (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SOfferingMaturityOption'),
    name VARCHAR(256),
    risk INT);

CREATE SEQUENCE SProjectComplexityLevelOption INCREMENT BY 1 START WITH 1000;

CREATE TABLE ProjectComplexityLevelOption (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SProjectComplexityLevelOption'),
    name VARCHAR(256),
    risk INT);

CREATE SEQUENCE SExternalFactorsOption INCREMENT BY 1 START WITH 1000;

CREATE TABLE ExternalFactorsOption (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SExternalFactorsOption'),
    name VARCHAR(256),
    risk INT);

CREATE SEQUENCE SEMCStaffAvailabilityOption INCREMENT BY 1 START WITH 1000;

CREATE TABLE EMCStaffAvailabilityOption (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SEMCStaffAvailabilityOption'),
    name VARCHAR(256),
    risk INT);

CREATE SEQUENCE SPartnerStaffAvailOption INCREMENT BY 1 START WITH 1000;

CREATE TABLE PartnerStaffAvailOption (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SPartnerStaffAvailOption'),
    name VARCHAR(256),
    risk INT);

CREATE SEQUENCE SRiskLevelOption INCREMENT BY 1 START WITH 1000;

CREATE TABLE RiskLevelOption (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SRiskLevelOption'),
    name VARCHAR(256),
    risk INT);

CREATE SEQUENCE SEMCFederatedCompaniesInvOpt INCREMENT BY 1 START WITH 1000;

CREATE TABLE EMCFederatedCompaniesInvOpt (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SEMCFederatedCompaniesInvOpt'),
    name VARCHAR(256),
    risk INT);

CREATE SEQUENCE SThirdPartyInvolvementOption INCREMENT BY 1 START WITH 1000;

CREATE TABLE ThirdPartyInvolvementOption (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SThirdPartyInvolvementOption'),
    name VARCHAR(256),
    risk INT);

CREATE SEQUENCE STMBillingUsageOption INCREMENT BY 1 START WITH 1000;

CREATE TABLE TMBillingUsageOption (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('STMBillingUsageOption'),
    name VARCHAR(256),
    risk INT);

CREATE SEQUENCE SEMCAccountabilityOption INCREMENT BY 1 START WITH 1000;

CREATE TABLE EMCAccountabilityOption (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SEMCAccountabilityOption'),
    name VARCHAR(256),
    risk INT);

CREATE SEQUENCE SProgramMgmtUseCaseOption INCREMENT BY 1 START WITH 1000;

CREATE TABLE ProgramMgmtUseCaseOption (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SProgramMgmtUseCaseOption'),
    name VARCHAR(256));

CREATE SEQUENCE SRiskCalculationData INCREMENT BY 1 START WITH 1000;

CREATE TABLE RiskCalculationData (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SRiskCalculationData'),
    theater_id BIGINT,
    division_id BIGINT,
    multi_theatre_lang_inv_opt_id BIGINT,
    multi_workgroups_disc_opt_id BIGINT,
    emc_client_type_id BIGINT,
    emc_client_rel_type_id BIGINT,
    proc_staff_maturity_type_id BIGINT,
    client_env_doc_type_id BIGINT,
    project_scope_under_type_id BIGINT,
    project_impact_type_id BIGINT,
    project_sponsor_inv_type_id BIGINT,
    list_price INT,
    potential_value INT,
    offering_maturity_type_id BIGINT,
    project_complexity_type_id BIGINT,
    external_factors_type_id BIGINT,
    emc_staff_avail_type_id BIGINT,
    partner_staff_avail_type_id BIGINT,
    risk_level_type_id BIGINT,
    risk VARCHAR(256),
    rationale VARCHAR(256),
    adjustment INT,
    emc_fed_comps_inv_type_id BIGINT,
    third_party_inv_type_id BIGINT,
    tm_billing_usage_type_id BIGINT,
    emc_acc_type_id BIGINT,
    pg_mgmt_use_case_type_id BIGINT,
    FOREIGN KEY (theater_id) REFERENCES Geography (id),
    FOREIGN KEY (division_id) REFERENCES Division (id),
    FOREIGN KEY (multi_theatre_lang_inv_opt_id) REFERENCES MultipleTheatersLangsInvOpt (id),
    FOREIGN KEY (multi_workgroups_disc_opt_id) REFERENCES MultipleWorkgroupsDiscOpt (id),
    FOREIGN KEY (emc_client_type_id) REFERENCES EMCClientOption (id),
    FOREIGN KEY (emc_client_rel_type_id) REFERENCES EMCClientRelationshipOption (id),
    FOREIGN KEY (proc_staff_maturity_type_id) REFERENCES ProcessStaffMaturityOption (id),
    FOREIGN KEY (client_env_doc_type_id) REFERENCES ClientEnvDocumentationOption (id),
    FOREIGN KEY (project_scope_under_type_id) REFERENCES ProjectScopeUnderstandOption (id),
    FOREIGN KEY (project_impact_type_id) REFERENCES ProjectImpactOption (id),
    FOREIGN KEY (project_sponsor_inv_type_id) REFERENCES ProjectSponsorInvOption (id),
    FOREIGN KEY (offering_maturity_type_id) REFERENCES OfferingMaturityOption (id),
    FOREIGN KEY (project_complexity_type_id) REFERENCES ProjectComplexityLevelOption (id),
    FOREIGN KEY (external_factors_type_id) REFERENCES ExternalFactorsOption (id),
    FOREIGN KEY (emc_staff_avail_type_id) REFERENCES EMCStaffAvailabilityOption (id),
    FOREIGN KEY (partner_staff_avail_type_id) REFERENCES PartnerStaffAvailOption (id),
    FOREIGN KEY (risk_level_type_id) REFERENCES RiskLevelOption (id),
    FOREIGN KEY (emc_fed_comps_inv_type_id) REFERENCES EMCFederatedCompaniesInvOpt (id),
    FOREIGN KEY (third_party_inv_type_id) REFERENCES ThirdPartyInvolvementOption (id),
    FOREIGN KEY (tm_billing_usage_type_id) REFERENCES TMBillingUsageOption (id),
    FOREIGN KEY (emc_acc_type_id) REFERENCES EMCAccountabilityOption (id),
    FOREIGN KEY (pg_mgmt_use_case_type_id) REFERENCES ProgramMgmtUseCaseOption (id));

CREATE SEQUENCE SUsers INCREMENT BY 1 START WITH 1000;

CREATE TABLE Users (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SUsers'),
    user_identifier VARCHAR(128) NOT NULL,
    first_name VARCHAR(128),
    last_name VARCHAR(128),
    email VARCHAR(128),
    title VARCHAR(128),
    country VARCHAR(128),
    correlated_id BIGINT,
    CONSTRAINT unique_user_identifier UNIQUE (user_identifier));    
    
CREATE SEQUENCE SRequest INCREMENT BY 1 START WITH 1000;

CREATE TABLE Request (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SRequest'),
    customer_id BIGINT,
    request_status VARCHAR(256),
    request_type_id BIGINT,
    project_name VARCHAR(256),
    project_type_id BIGINT,
    project_regulatory_type_id BIGINT,
    start_request_data_id BIGINT,
    engagement_type_data_id BIGINT,
    mainframe_request_data_id BIGINT,
    infrastucture_request_data_id BIGINT,
    bc_request_data_id BIGINT,
    unified_request_data_id BIGINT,
    mss_request_data_id BIGINT,
    cta_request_data_id BIGINT,
    residency_request_data_id BIGINT,
    sourceone_request_data_id BIGINT,
    asd_request_data_id BIGINT,
    healthcheck_request_data_id BIGINT,
    isilon_request_data_id BIGINT,
    vipr_request_data_id BIGINT,
    atmos_request_data_id BIGINT,
    vblock_request_data_id BIGINT,
    dpad_request_data_id BIGINT,
    vmware_request_data_id BIGINT,
    change_request_data_id BIGINT,
    move_request_data_id BIGINT,
    srm_request_data_id BIGINT,
    w4n_data_id BIGINT,
    unfunded_proj_data_id BIGINT,
    xtreme_request_data_id BIGINT,
    deal_governance_data_id BIGINT,
    estimates_data_id BIGINT,
    user_identifier VARCHAR(128) NOT NULL,
    correlated_id BIGINT,
    project_start_date DATE,
    project_end_date DATE,
    risk_calculation_data_id BIGINT,
    project_description VARCHAR(150),
    san_tan_information_id BIGINT,
    approver_id BIGINT,
    FOREIGN KEY (customer_id) REFERENCES Customer (id),
    FOREIGN KEY (request_type_id) REFERENCES RequestType (id),
    FOREIGN KEY (project_type_id) REFERENCES ProjectType (id),
    FOREIGN KEY (project_regulatory_type_id) REFERENCES ProjectRegulatoryType (id),
    FOREIGN KEY (start_request_data_id) REFERENCES StartRequestData (id),
    FOREIGN KEY (mainframe_request_data_id) REFERENCES MainframeRequestData (id),
    FOREIGN KEY (infrastucture_request_data_id) REFERENCES InfrastructureRequestData (id),
    FOREIGN KEY (bc_request_data_id) REFERENCES BcRequestData (id),
    FOREIGN KEY (unified_request_data_id) REFERENCES UnifiedRequestData (id),
    FOREIGN KEY (change_request_data_id) REFERENCES ChangeRequestData (id),
    FOREIGN KEY (move_request_data_id) REFERENCES MoveRequestData (id),
    FOREIGN KEY (srm_request_data_id) REFERENCES SRMRequestData (id),
    FOREIGN KEY (w4n_data_id) REFERENCES W4NData (id),
    FOREIGN KEY (unfunded_proj_data_id) REFERENCES UnfundedProjectData (id),
    FOREIGN KEY (mss_request_data_id) REFERENCES MSSRequestData (id),
    FOREIGN KEY (cta_request_data_id) REFERENCES CTARequestData (id),
    FOREIGN KEY (residency_request_data_id) REFERENCES ResidencyRequestData (id),
    FOREIGN KEY (sourceone_request_data_id) REFERENCES SourceOneRequestData (id),
    FOREIGN KEY (asd_request_data_id) REFERENCES ASDRequestData (id),
    FOREIGN KEY (healthcheck_request_data_id) REFERENCES HealthCheckRequestData (id),
    FOREIGN KEY (isilon_request_data_id) REFERENCES IsilonRequestData (id),
    FOREIGN KEY (vipr_request_data_id) REFERENCES ViprRequestData (id),
    FOREIGN KEY (atmos_request_data_id) REFERENCES AtmosCenteraRequestData (id),
    FOREIGN KEY (vblock_request_data_id) REFERENCES VblockRequestData (id),
    FOREIGN KEY (dpad_request_data_id) REFERENCES DPADRequestData (id),
    FOREIGN KEY (vmware_request_data_id) REFERENCES VMwareRequestData (id),
    FOREIGN KEY (xtreme_request_data_id) REFERENCES XtremeRequestData (id),
    FOREIGN KEY (engagement_type_data_id) REFERENCES EngagementTypeData (id),
    FOREIGN KEY (deal_governance_data_id) REFERENCES DealGovernanceData (id),
    FOREIGN KEY (estimates_data_id) REFERENCES EstimatesData (id),
    FOREIGN KEY (risk_calculation_data_id) REFERENCES RiskCalculationData (id),
    FOREIGN KEY (san_tan_information_id) REFERENCES SanTanInformation (id),
    FOREIGN KEY (approver_id) REFERENCES Profile (id)
);

CREATE SEQUENCE SOperationLog INCREMENT BY 1 START WITH 1000;

CREATE TABLE OperationLog (
    log_id VARCHAR(256) NOT NULL PRIMARY KEY DEFAULT nextval('SOperationLog'),
    entity_id BIGINT NOT NULL,
    entity_type VARCHAR(128) NOT NULL,
    operation INT NOT NULL,
    timestamp BIGINT NOT NULL,
    user_identifier VARCHAR(128) NOT NULL,
    correlated_id BIGINT,
    seq BIGINT,
    CONSTRAINT unique_operation_log UNIQUE (entity_id, entity_type, user_identifier));

CREATE SEQUENCE SSynchronizedOperationLog INCREMENT BY 1 START WITH 1000;

CREATE TABLE SynchronizedOperationLog (
    log_id VARCHAR(256) NOT NULL PRIMARY KEY DEFAULT nextval('SSynchronizedOperationLog'),
    entity_id BIGINT NOT NULL,
    entity_type VARCHAR(128) NOT NULL,
    operation INT NOT NULL,
    timestamp BIGINT NOT NULL,
    user_identifier VARCHAR(128) NOT NULL,
    correlated_id BIGINT,
    seq BIGINT);

CREATE SEQUENCE SRequest_AdditionalRecipients INCREMENT BY 1 START WITH 1000;

CREATE TABLE Request_AdditionalRecipients (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SRequest_AdditionalRecipients'),
    request_id BIGINT,
    recipient_id BIGINT,
    FOREIGN KEY (request_id) REFERENCES Request (id),
    FOREIGN KEY (recipient_id) REFERENCES Profile (id));

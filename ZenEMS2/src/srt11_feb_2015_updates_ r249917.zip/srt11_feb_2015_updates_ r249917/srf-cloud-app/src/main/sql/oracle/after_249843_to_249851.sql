ALTER TABLE Profile ADD se_csd_name VARCHAR2(256)/
ALTER TABLE Profile ADD se_csd_phone_country_code VARCHAR2(256)/
ALTER TABLE Profile ADD se_csd_phone_number VARCHAR2(256)/
ALTER TABLE Profile ADD se_manager_name VARCHAR2(256)/

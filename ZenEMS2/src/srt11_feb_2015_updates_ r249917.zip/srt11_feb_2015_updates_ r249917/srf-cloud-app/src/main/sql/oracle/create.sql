CREATE SEQUENCE SContractStructure
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE
/
CREATE TABLE ContractStructure (
    id NUMBER NOT NULL PRIMARY KEY,
    name VARCHAR2(256) NOT NULL
)
/

CREATE SEQUENCE SDealQuestionSection
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE
/
CREATE TABLE DealQuestionSection (
    id NUMBER NOT NULL PRIMARY KEY,
    name VARCHAR2(256) NOT NULL
)
/

CREATE SEQUENCE SDealQuestion
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE DealQuestion (
    id NUMBER NOT NULL PRIMARY KEY,
    name VARCHAR2(256) NOT NULL,
    comment_condition NUMBER(1) NOT NULL,
    comment_place_holder VARCHAR2(256) NOT NULL,
    section_id NUMBER NOT NULL,
    FOREIGN KEY (section_id) REFERENCES DealQuestionSection (id)
)
/

CREATE SEQUENCE SDealGovernanceData
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE
/
CREATE TABLE DealGovernanceData (
    id NUMBER NOT NULL PRIMARY KEY,
    opportunity_name VARCHAR2(140),
    primary_delivery_org VARCHAR2(140),
    other_practices VARCHAR2(140),
    estimated_start_date DATE,
    brief_description VARCHAR2(140),
    contract_structure_id NUMBER,
    approver_notes VARCHAR2(140),
    FOREIGN KEY (contract_structure_id) REFERENCES ContractStructure (id)
)
/

CREATE TABLE DealGovernanceData_answers (
    deal_governance_data_id NUMBER,
    question_id NUMBER,
    yes_no NUMBER(1),
    answer_comment VARCHAR2(140),
    FOREIGN KEY (deal_governance_data_id) REFERENCES DealGovernanceData (id),
    FOREIGN KEY (question_id) REFERENCES DealQuestion (id)
)
/

CREATE SEQUENCE SGeography
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE Geography (
    id NUMBER NOT NULL PRIMARY KEY, 
    name VARCHAR2(256)
)
/

CREATE SEQUENCE SDeliveryGeography
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE DeliveryGeography (
    id NUMBER NOT NULL PRIMARY KEY, 
    name VARCHAR2(256), 
    code VARCHAR2(10) NOT NULL 
)
/

CREATE SEQUENCE SDealCurrency
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE
/

CREATE TABLE DealCurrency (
    id NUMBER NOT NULL PRIMARY KEY,
    name VARCHAR2(3),
    exchange_rate DECIMAL(20,10) NOT NULL
)
/

CREATE SEQUENCE SDeliveryCountry
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE
/
CREATE TABLE DeliveryCountry (
    id NUMBER NOT NULL PRIMARY KEY,
    code VARCHAR2(2) NOT NULL,
    name VARCHAR2(256) NOT NULL,
    delivery_geography_id NUMBER,
    delivery_currency_id NUMBER,
    calling_code VARCHAR2(256),
    FOREIGN KEY (delivery_geography_id) REFERENCES DeliveryGeography (id),
    FOREIGN KEY (delivery_currency_id) REFERENCES DealCurrency (id)
)
/

CREATE TRIGGER TDeliveryCountry
BEFORE INSERT ON DeliveryCountry
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SDeliveryCountry.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SRegion
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE
/

CREATE TABLE Region (
    id NUMBER NOT NULL PRIMARY KEY,
    code VARCHAR2(256) NOT NULL,
    name VARCHAR2(256),
    region_country_id NUMBER,
    FOREIGN KEY (region_country_id) REFERENCES DeliveryCountry (id)
)
/

CREATE SEQUENCE SScreenerInterviewer
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE
/

CREATE TABLE ScreenerInterviewer (
    id NUMBER NOT NULL PRIMARY KEY,
    name VARCHAR2(256) NOT NULL
)
/

CREATE SEQUENCE SResourceType
INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE
/
CREATE TABLE ResourceType (
  id NUMBER NOT NULL PRIMARY KEY,
  name VARCHAR2(256) NOT NULL,
  code VARCHAR2(2) NOT NULL
)
/

CREATE SEQUENCE SBillingType
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE
/
CREATE TABLE BillingType (
    id NUMBER NOT NULL PRIMARY KEY,
    name VARCHAR2(256) NOT NULL,
    code VARCHAR2(10) NOT NULL
)
/

CREATE SEQUENCE SLOB
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE
/
CREATE TABLE LOB (
    id NUMBER NOT NULL PRIMARY KEY,
    name VARCHAR2(256) NOT NULL,
    code VARCHAR2(10) NOT NULL
)
/

CREATE SEQUENCE SBOERole
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE
/
CREATE TABLE BOERole (
    id NUMBER NOT NULL PRIMARY KEY,
    code VARCHAR2(256) NOT NULL,
    name VARCHAR2(256) NOT NULL
)
/

CREATE SEQUENCE SDiscountFloorType
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE
/
CREATE TABLE DiscountFloorType (
    id NUMBER NOT NULL PRIMARY KEY,
    name VARCHAR2(256) NOT NULL,
    code VARCHAR2(256) NOT NULL
)
/
CREATE SEQUENCE SDiscountFloorGroup
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE
/
CREATE TABLE DiscountFloorGroup (
    id NUMBER NOT NULL PRIMARY KEY,
    name VARCHAR2(256) NOT NULL
)
/

CREATE SEQUENCE SDiscountFloor
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE
/
CREATE TABLE DiscountFloor (
    id NUMBER NOT NULL PRIMARY KEY,
    group_id NUMBER,
    type_id NUMBER,
    threshold DECIMAL(10,2),
    FOREIGN KEY (group_id) REFERENCES DiscountFloorGroup (id),
    FOREIGN KEY (type_id) REFERENCES DiscountFloorType (id)
)
/


CREATE SEQUENCE SMaterialCode
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE
/
CREATE TABLE MaterialCode (
    id NUMBER NOT NULL PRIMARY KEY,
    code VARCHAR2(256) NOT NULL,
    name VARCHAR2(256) NOT NULL,
    expense_model VARCHAR2(256) NOT NULL,
    lob_id NUMBER NOT NULL,
    discount_group_id NUMBER NOT NULL,
    FOREIGN KEY (lob_id) REFERENCES LOB (id),
    FOREIGN KEY (discount_group_id) REFERENCES DiscountFloorGroup (id)
)
/

CREATE SEQUENCE SCompetency
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE
/
CREATE TABLE Competency (
    id NUMBER NOT NULL PRIMARY KEY,
    code VARCHAR2(256) NOT NULL,
    name VARCHAR2(256) NOT NULL,
    lob_id NUMBER NOT NULL,
    FOREIGN KEY (lob_id) REFERENCES LOB (id)
)
/

CREATE TABLE MaterialCode_Competency (
    material_id NUMBER NOT NULL,
    competency_id NUMBER NOT NULL,
    PRIMARY KEY (material_id, competency_id),
    FOREIGN KEY (material_id) REFERENCES MaterialCode (id),
    FOREIGN KEY (competency_id) REFERENCES Competency (id)
)
/

CREATE TABLE Competency_BOERole (
    competency_id NUMBER NOT NULL,
    role_id NUMBER NOT NULL,
    PRIMARY KEY (competency_id, role_id),
    FOREIGN KEY (role_id) REFERENCES BOERole (id),
    FOREIGN KEY (competency_id) REFERENCES Competency (id)
)
/

CREATE SEQUENCE SLOBCountry
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE
/
CREATE TABLE LOBCountry (
    id NUMBER NOT NULL PRIMARY KEY,
    lob_id NUMBER NOT NULL,
    country_code VARCHAR2(2) NULL,
    company_code VARCHAR2(256) NOT NULL,
    cost_center_code VARCHAR2(256) NOT NULL,
    FOREIGN KEY (lob_id) REFERENCES LOB (id)
)
/

CREATE TABLE HourlyStdCostRate (
    lookup_key VARCHAR2(100) NOT NULL PRIMARY KEY,
    rate DECIMAL(20,2)
)
/

CREATE TABLE StandardBillRate (
    lookup_key VARCHAR2(100) NOT NULL PRIMARY KEY,
    rate DECIMAL(20,2)
)
/

CREATE SEQUENCE SDeliverAction
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE
/
CREATE TABLE DeliverAction (
    id NUMBER NOT NULL PRIMARY KEY,
    name VARCHAR2(256) NOT NULL,
    code VARCHAR2(10) NOT NULL,
    description VARCHAR2(1024) NOT NULL
)
/

CREATE SEQUENCE SLOBResource
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE
/
CREATE TABLE LOBResource (
    id NUMBER NOT NULL PRIMARY KEY,
    competency_id NUMBER,
    role_id NUMBER,
    start_date DATE,
    weeks INT,
    end_date DATE,
    contingency_percent DECIMAL(20, 2),
    bill_rate_override DECIMAL(20, 2),
    long_role_description VARCHAR2(256),
    skills VARCHAR2(140),
    additional_comments VARCHAR2(140),
    potential_candidate VARCHAR2(140),
    tech_screeners VARCHAR2(140),
    utilization_target DECIMAL(20,2),
    resource_type_id NUMBER,
    citizenship_required NUMBER(1),
    security_clearance_required NUMBER(1),
    remote_work_allowed NUMBER(1),
    work_location VARCHAR2(140),
    days_week_on_site INT,
    screener_interviewer_id NUMBER,
    project_pdm VARCHAR2(140),
    project_pm VARCHAR2(140),
    project_rm VARCHAR2(140),
    notes VARCHAR2(140),
    FOREIGN KEY (role_id) REFERENCES BOERole (id),
    FOREIGN KEY (competency_id) REFERENCES Competency (id),
    FOREIGN KEY (screener_interviewer_id) REFERENCES ScreenerInterviewer (id),
    FOREIGN KEY (resource_type_id) REFERENCES ResourceType (id)
)
/

CREATE TABLE LOBResource_monthHours (
    lob_resource_id NUMBER,
    month INT,
    hours INT,
    FOREIGN KEY (lob_resource_id) REFERENCES LOBResource (id)
)
/

CREATE SEQUENCE SLOBResources
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE
/
CREATE TABLE LOBResources (
    id NUMBER NOT NULL PRIMARY KEY,
    lob_id NUMBER,
    material_id NUMBER,
    competency_id NUMBER,
    billing_type_id NUMBER,
    months_num INT,
    expense_amount DECIMAL(20, 2),
    discount_percent DECIMAL(20, 2),
    discount_amount DECIMAL(20, 2),
    wbs_number VARCHAR2(140),
    sales_order_item_number VARCHAR2(140),
    expense_wbs_number VARCHAR2(140),
    expense_sales_order_number VARCHAR2(140),
    FOREIGN KEY (lob_id) REFERENCES LOB (id),
    FOREIGN KEY (material_id) REFERENCES MaterialCode (id),
    FOREIGN KEY (competency_id) REFERENCES Competency (id),
    FOREIGN KEY (billing_type_id) REFERENCES BillingType (id)
)
/

CREATE TABLE LOB_resources (
    lob_resources_id NUMBER NOT NULL,
    lob_resource_id NUMBER NOT NULL,
    FOREIGN KEY (lob_resources_id) REFERENCES LOBResources (id),
    FOREIGN KEY (lob_resource_id) REFERENCES LOBResource (id)
)
/

CREATE SEQUENCE SEstimatesData
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE
/
CREATE TABLE EstimatesData (
    id NUMBER NOT NULL PRIMARY KEY,
    deal_currency_id NUMBER,
    estimated_percent DECIMAL(20, 2),
    expense_amount DECIMAL(20, 2),
    capped_percent DECIMAL(20, 2),
    client_pricing_override DECIMAL(20, 2),
    deliver_description VARCHAR2(512),
    deliver_action_id NUMBER,
    contingency_percent DECIMAL(20, 2),
    sow_number VARCHAR2(256),
    contract_number VARCHAR2(256),
    FOREIGN KEY (deal_currency_id) REFERENCES DealCurrency (id),
    FOREIGN KEY (deliver_action_id) REFERENCES DeliverAction (id)
)
/

CREATE SEQUENCE SIPEDUData
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE
/
CREATE TABLE IPEDUData (
  id NUMBER NOT NULL PRIMARY KEY,
  estimates_data_id  NUMBER,
  data_type   VARCHAR2(3),
  material_id NUMBER,
  competency_id NUMBER,
  amount DECIMAL(20, 2),
  FOREIGN KEY (estimates_data_id) REFERENCES EstimatesData (id),
  FOREIGN KEY (material_id) REFERENCES MaterialCode (id),
  FOREIGN KEY (competency_id) REFERENCES Competency (id)
)/


CREATE TABLE EstimatesData_resources (
    estimates_data_id NUMBER NOT NULL,
    lob_resources_id NUMBER NOT NULL,
    FOREIGN KEY (estimates_data_id) REFERENCES EstimatesData (id),
    FOREIGN KEY (lob_resources_id) REFERENCES LOBResources (id)
)
/

CREATE SEQUENCE SEngagementTypeData
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE
/
CREATE TABLE EngagementTypeData (
    id NUMBER NOT NULL PRIMARY KEY,
    product_lead NUMBER(1),
    service_lead NUMBER(1),
    emc NUMBER(1),
    ecd NUMBER(1),
    rsa NUMBER(1),
    ms NUMBER(1),
    delivery_country_id NUMBER,
    FOREIGN KEY (delivery_country_id) REFERENCES DeliveryCountry (id)
)
/

CREATE SEQUENCE SDataDomainDeviceType
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE DataDomainDeviceType (
    id NUMBER NOT NULL PRIMARY KEY,
    name VARCHAR2(256)
)
/
CREATE TRIGGER TDataDomainDeviceType
BEFORE INSERT ON DataDomainDeviceType
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SDataDomainDeviceType.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/
CREATE SEQUENCE SDataDomainUpgradeType
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE DataDomainUpgradeType (
    id NUMBER NOT NULL PRIMARY KEY,
    name VARCHAR2(256)
)
/
CREATE TRIGGER TDataDomainUpgradeType
BEFORE INSERT ON DataDomainUpgradeType
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SDataDomainUpgradeType.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/
CREATE SEQUENCE SDataDomainDataStagingType
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE DataDomainDataStagingType (
    id NUMBER NOT NULL PRIMARY KEY,
    name VARCHAR2(256)
)
/
CREATE TRIGGER TDataDomainDataStagingType
BEFORE INSERT ON DataDomainDataStagingType
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SDataDomainDataStagingType.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/
CREATE SEQUENCE SDataDomainIntegrationType
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE DataDomainIntegrationType (
    id NUMBER NOT NULL PRIMARY KEY,
    name VARCHAR2(256)
)
/
CREATE TRIGGER TDataDomainIntegrationType
BEFORE INSERT ON DataDomainIntegrationType
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SDataDomainIntegrationType.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/
CREATE SEQUENCE SDataDomainMigrationType
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE DataDomainMigrationType (
    id NUMBER NOT NULL PRIMARY KEY,
    name VARCHAR2(256)
)
/
CREATE TRIGGER TDataDomainMigrationType
BEFORE INSERT ON DataDomainMigrationType
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SDataDomainMigrationType.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/
CREATE SEQUENCE SDataDomainPreRackType
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE DataDomainPreRackType (
    id NUMBER NOT NULL PRIMARY KEY,
    name VARCHAR2(256)
)
/
CREATE TRIGGER TDataDomainPreRackType
BEFORE INSERT ON DataDomainPreRackType
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SDataDomainPreRackType.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/
CREATE SEQUENCE SDataDomainBoostType
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE DataDomainBoostType (
    id NUMBER NOT NULL PRIMARY KEY,
    name VARCHAR2(256)
)
/
CREATE TRIGGER TDataDomainBoostType
BEFORE INSERT ON DataDomainBoostType
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SDataDomainBoostType.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/
CREATE SEQUENCE SDataDomainMaxBackupWindowTime
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE DataDomainMaxBackupWindowTime (
    id NUMBER NOT NULL PRIMARY KEY,
    name VARCHAR2(256)
)
/
CREATE TRIGGER TDataDomainMaxBackupWindowTime
BEFORE INSERT ON DataDomainMaxBackupWindowTime
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SDataDomainMaxBackupWindowTime.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SAvamarServerType
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE AvamarServerType (
    id NUMBER NOT NULL PRIMARY KEY, 
    name VARCHAR2(256) NOT NULL
)
/
CREATE TRIGGER TAvamarServerType
BEFORE INSERT ON AvamarServerType
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SAvamarServerType.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/
CREATE SEQUENCE SVplexDataMobilityType
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE VplexDataMobilityType (
    id NUMBER NOT NULL PRIMARY KEY, 
    name VARCHAR2(256) NOT NULL
)
/
CREATE TRIGGER TVplexDataMobilityType
BEFORE INSERT ON VplexDataMobilityType
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SVplexDataMobilityType.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/
CREATE SEQUENCE SRecoverPointSplitterType
INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE RecoverPointSplitterType (
  id NUMBER NOT NULL PRIMARY KEY,
  name VARCHAR2(256)
)
/
CREATE TRIGGER TRecoverPointSplitterType
BEFORE INSERT ON RecoverPointSplitterType
FOR EACH ROW
when (new.id = 0 or new.id is null)
  BEGIN
    SELECT
      SRecoverPointSplitterType.NEXTVAL
    INTO :new.id
    FROM dual;
  END;

/

CREATE SEQUENCE SIntelligentFabricMigrationMet
INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE
/
CREATE TABLE IntelligentFabricMigrationMet (
  id   NUMBER NOT NULL PRIMARY KEY,
  name VARCHAR(256)          NOT NULL
)/

CREATE SEQUENCE SRecoverPointOption
INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE
/
CREATE TABLE RecoverPointOption (
  id   NUMBER NOT NULL PRIMARY KEY,
  name VARCHAR(256)          NOT NULL
)/


CREATE SEQUENCE SCenteraArrayActionType
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE CenteraArrayActionType (
    id NUMBER NOT NULL PRIMARY KEY, 
    name VARCHAR2(256)
)
/
CREATE TRIGGER TCenteraArrayActionType
BEFORE INSERT ON CenteraArrayActionType
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SCenteraArrayActionType.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/
CREATE SEQUENCE SCenteraEditionType
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE CenteraEditionType (
    id NUMBER NOT NULL PRIMARY KEY, 
    name VARCHAR2(256)
)
/
CREATE TRIGGER TCenteraEditionType
BEFORE INSERT ON CenteraEditionType
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SCenteraEditionType.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/
CREATE SEQUENCE SCenteraGenerationType
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE CenteraGenerationType (
    id NUMBER NOT NULL PRIMARY KEY, 
    name VARCHAR2(256)
)
/
CREATE TRIGGER TCenteraGenerationType
BEFORE INSERT ON CenteraGenerationType
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SCenteraGenerationType.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/
CREATE SEQUENCE SCenteraHealthCheckType
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE CenteraHealthCheckType (
    id NUMBER NOT NULL PRIMARY KEY, 
    name VARCHAR2(256)
)
/
CREATE TRIGGER TCenteraHealthCheckType
BEFORE INSERT ON CenteraHealthCheckType
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SCenteraHealthCheckType.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/
CREATE SEQUENCE SCenteraReplicationType
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE CenteraReplicationType (
    id NUMBER NOT NULL PRIMARY KEY, 
    name VARCHAR2(256)
)
/
CREATE TRIGGER TCenteraReplicationType
BEFORE INSERT ON CenteraReplicationType
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SCenteraReplicationType.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/
CREATE SEQUENCE SCenteraProtectionSchemeType
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE CenteraProtectionSchemeType (
    id NUMBER NOT NULL PRIMARY KEY, 
    name VARCHAR2(256)
)
/
CREATE TRIGGER TCenteraProtectionSchemeType
BEFORE INSERT ON CenteraProtectionSchemeType
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SCenteraProtectionSchemeType.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/
CREATE SEQUENCE SCenteraShippingArranger
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE CenteraShippingArranger (
    id NUMBER NOT NULL PRIMARY KEY, 
    name VARCHAR2(256)
)
/
CREATE TRIGGER TCenteraShippingArranger
BEFORE INSERT ON CenteraShippingArranger
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SCenteraShippingArranger.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/
CREATE SEQUENCE SCUAHardwareType
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE CUAHardwareType (
    id NUMBER NOT NULL PRIMARY KEY, 
    name VARCHAR2(256)
)
/
CREATE TRIGGER TCUAHardwareType
BEFORE INSERT ON CUAHardwareType
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SCUAHardwareType.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SUIMType
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE UIMType (
    id NUMBER NOT NULL PRIMARY KEY, 
    name VARCHAR2(256)
)
/
CREATE TRIGGER TUIMType
BEFORE INSERT ON UIMType
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SUIMType.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/
CREATE SEQUENCE SUnifiedHealthCheckType
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE UnifiedHealthCheckType (
    id NUMBER NOT NULL PRIMARY KEY, 
    name VARCHAR2(256)
)
/
CREATE TRIGGER TUnifiedHealthCheckType
BEFORE INSERT ON UnifiedHealthCheckType
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SUnifiedHealthCheckType.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/
CREATE SEQUENCE SWeekDay
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE WeekDay (
    id NUMBER NOT NULL PRIMARY KEY, 
    name VARCHAR2(256)
)
/
CREATE TRIGGER TWeekDay
BEFORE INSERT ON WeekDay
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SWeekDay.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/
CREATE SEQUENCE SResidencyPaymentType
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE ResidencyPaymentType (
    id NUMBER NOT NULL PRIMARY KEY, 
    name VARCHAR2(256)
)
/
CREATE TRIGGER TResidencyPaymentType
BEFORE INSERT ON ResidencyPaymentType
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SResidencyPaymentType.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/
CREATE SEQUENCE SCTASourceFileServerType
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE CTASourceFileServerType (
    id NUMBER NOT NULL PRIMARY KEY, 
    name VARCHAR2(256)
)
/
CREATE TRIGGER TCTASourceFileServerType
BEFORE INSERT ON CTASourceFileServerType
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SCTASourceFileServerType.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/
CREATE SEQUENCE SCTAApplianceType
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE CTAApplianceType (
    id NUMBER NOT NULL PRIMARY KEY, 
    name VARCHAR2(256)
)
/
CREATE TRIGGER TCTAApplianceType
BEFORE INSERT ON CTAApplianceType
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SCTAApplianceType.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/
CREATE SEQUENCE SDurationMonths
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE DurationMonths (
    id NUMBER NOT NULL PRIMARY KEY, 
    name VARCHAR2(256)
)
/
CREATE TRIGGER TDurationMonths
BEFORE INSERT ON DurationMonths
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SDurationMonths.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/
CREATE SEQUENCE SMSSService
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE MSSService (
    id NUMBER NOT NULL PRIMARY KEY, 
    name VARCHAR2(256)
)
/
CREATE TRIGGER TMSSService
BEFORE INSERT ON MSSService
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SMSSService.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/
CREATE SEQUENCE SMSSPlatform
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE MSSPlatform (
    id NUMBER NOT NULL PRIMARY KEY, 
    name VARCHAR2(256)
)
/
CREATE TRIGGER TMSSPlatform
BEFORE INSERT ON MSSPlatform
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SMSSPlatform.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/
CREATE SEQUENCE SSitesInvolved
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE SitesInvolved (
    id NUMBER NOT NULL PRIMARY KEY, 
    name VARCHAR2(256)
)
/
CREATE TRIGGER TSitesInvolved
BEFORE INSERT ON SitesInvolved
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SSitesInvolved.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SFlashStorageLayoutServices
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE FlashStorageLayoutServices (
    id NUMBER NOT NULL PRIMARY KEY, 
    name VARCHAR2(256)
)
/
CREATE TRIGGER TFlashStorageLayoutServices
BEFORE INSERT ON FlashStorageLayoutServices
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SFlashStorageLayoutServices.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE TRIGGER TGeography
BEFORE INSERT ON Geography
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SGeography.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE TRIGGER TDeliveryGeography
BEFORE INSERT ON DeliveryGeography
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SDeliveryGeography.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SScriptingLevelOption
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE ScriptingLevelOption (
    id NUMBER NOT NULL PRIMARY KEY, 
    name VARCHAR2(256)
)
/
CREATE TRIGGER TScriptingLevelOption
BEFORE INSERT ON ScriptingLevelOption
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SScriptingLevelOption.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SDivision
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE Division (
    id NUMBER NOT NULL PRIMARY KEY, 
    division_name VARCHAR2(256),
    email_address VARCHAR2(256),
    short_name VARCHAR2(256),
    strict_profile_search NUMBER(1),
    geography_id NUMBER,
    FOREIGN KEY (geography_id) REFERENCES Geography (id)
)
/
CREATE TRIGGER TDivision
BEFORE INSERT ON Division
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SDivision.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SPdmName
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE PdmName (
    id NUMBER NOT NULL PRIMARY KEY, 
    pdm_name VARCHAR2(256),
    title VARCHAR2(256),
    address1 VARCHAR2(256),
    address2 VARCHAR2(256),
    city VARCHAR2(256),
    state VARCHAR2(256),
    postalCode VARCHAR2(256),
    officeNumber VARCHAR2(256),
    faxNumber VARCHAR2(256),
    mobileNumber VARCHAR2(256),
    emailAddress VARCHAR2(256),
    division_id NUMBER,
    FOREIGN KEY (division_id) REFERENCES Division (id)
)
/
CREATE TRIGGER TPdmName
BEFORE INSERT ON PdmName
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SPdmName.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SGeoState
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE GeoState (
    id NUMBER NOT NULL PRIMARY KEY,
    geography_id NUMBER,
    default_division_id NUMBER,
    default_pdm_name_id NUMBER,
    name VARCHAR2(256),
    FOREIGN KEY (geography_id) REFERENCES Geography (id),
    FOREIGN KEY (default_division_id) REFERENCES Division (id),
    FOREIGN KEY (default_pdm_name_id) REFERENCES PdmName (id)
)
/
CREATE TRIGGER TGeoState
BEFORE INSERT ON GeoState
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SGeoState.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SSalesDistrict
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE SalesDistrict (
    id NUMBER NOT NULL PRIMARY KEY, 
    district_name VARCHAR2(256),
    area_name VARCHAR2(256),
    market_name VARCHAR2(256),
    division_id NUMBER,
    default_pdm_id NUMBER,
    email_address VARCHAR2(256),
    FOREIGN KEY (division_id) REFERENCES Division (id),
    FOREIGN KEY (default_pdm_id) REFERENCES PdmName (id)
)
/
CREATE TRIGGER TSalesDistrict
BEFORE INSERT ON SalesDistrict
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SSalesDistrict.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SProfile
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE Profile (
    id NUMBER NOT NULL PRIMARY KEY, 
    first_name VARCHAR2(256),
    last_name VARCHAR2(256),
    job_title VARCHAR2(256),
    country_code VARCHAR2(256),
    office_phone_country_code VARCHAR2(256),
    office_phone_number VARCHAR2(256),
    mobile_phone_country_code VARCHAR2(256),
    mobile_phone_number VARCHAR2(256),
    fax_country_code VARCHAR2(256),
    fax_number VARCHAR2(256),
    email VARCHAR2(256),
    division_id NUMBER,
    sales_district_id NUMBER,
    default_profile NUMBER(1),
    user_identifier VARCHAR2(128) NOT NULL,
    correlated_id NUMBER,
    template_permission NUMBER(1) DEFAULT 0 NOT NULL,
    approver NUMBER(1) DEFAULT 0 NOT NULL,
    se_csd_name VARCHAR2(256),
    se_csd_phone_country_code VARCHAR2(256),
    se_csd_phone_number VARCHAR2(256),
    se_manager_name VARCHAR2(256),
    FOREIGN KEY (division_id) REFERENCES Division (id),
    FOREIGN KEY (sales_district_id) REFERENCES SalesDistrict (id)
)
/
CREATE TRIGGER TProfile
BEFORE INSERT ON Profile
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SProfile.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SServicesAgreementType
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE ServicesAgreementType (
    id NUMBER NOT NULL PRIMARY KEY, 
    name VARCHAR2(256) NOT NULL
)
/
CREATE TRIGGER TServicesAgreementType
BEFORE INSERT ON ServicesAgreementType
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SServicesAgreementType.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SSowType
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE SowType (
    id NUMBER NOT NULL PRIMARY KEY, 
    name VARCHAR2(256) NOT NULL
)
/
CREATE TRIGGER TSowType
BEFORE INSERT ON SowType
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SSowType.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SCustomerWorkSite
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE CustomerWorkSite (
    id NUMBER NOT NULL PRIMARY KEY, 
    site_name VARCHAR2(256),
    delivery_city VARCHAR2(256),
    cws_delivery_country_type_id NUMBER,
    cws_delivery_region_type_id NUMBER,
    FOREIGN KEY (cws_delivery_country_type_id) REFERENCES DeliveryCountry (id),
    FOREIGN KEY (cws_delivery_region_type_id) REFERENCES Region (id)
)
/
CREATE TRIGGER TCustomerWorkSite
BEFORE INSERT ON CustomerWorkSite
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SCustomerWorkSite.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SCustomer
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE Customer (
    id NUMBER NOT NULL PRIMARY KEY, 
    contact_name VARCHAR2(256),
    formal_name VARCHAR2(256),
    address1 VARCHAR2(256),
    address2 VARCHAR2(256),
    city VARCHAR2(256),
    zip VARCHAR2(256),
    title VARCHAR2(256),
    office_phone_country_code VARCHAR2(256),
    office_phone_number VARCHAR2(256),
    mobile_phone_country_code VARCHAR2(256),
    mobile_phone_number VARCHAR2(256),
    fax_country_code VARCHAR2(256),
    fax_number VARCHAR2(256),
    email VARCHAR2(256),
    services_agreement_number VARCHAR2(256),
    services_agreement_date TIMESTAMP,
    partner_information VARCHAR2(256),
    geo_state_id NUMBER,
	  country_id NUMBER,
    services_agreement_type_id NUMBER,
    template NUMBER(1),
    user_identifier VARCHAR2(128) NOT NULL,
    correlated_id NUMBER,
    FOREIGN KEY (geo_state_id) REFERENCES Region (id),
	FOREIGN KEY (country_id) REFERENCES DeliveryCountry (id),
    FOREIGN KEY (services_agreement_type_id) REFERENCES ServicesAgreementType (id)
)
/
CREATE TRIGGER TCustomer
BEFORE INSERT ON Customer
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SCustomer.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SCustomer_CustomerWorkSite
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE Customer_CustomerWorkSite (
    id NUMBER NOT NULL PRIMARY KEY, 
    customer_id NUMBER,
    customer_work_site_id NUMBER,
    FOREIGN KEY (customer_id) REFERENCES Customer (id),
    FOREIGN KEY (customer_work_site_id) REFERENCES CustomerWorkSite (id)
)
/
CREATE TRIGGER TCustomer_CustomerWorkSite
BEFORE INSERT ON Customer_CustomerWorkSite
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SCustomer_CustomerWorkSite.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SProjectType
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE ProjectType (
    id NUMBER NOT NULL PRIMARY KEY, 
    name VARCHAR2(256) NOT NULL, 
    code VARCHAR2(10)
)
/
CREATE TRIGGER TProjectType
BEFORE INSERT ON ProjectType
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SProjectType.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SProjectRegulatoryType
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE ProjectRegulatoryType (
    id NUMBER NOT NULL PRIMARY KEY, 
    name VARCHAR2(256) NOT NULL, 
    code VARCHAR2(10) NOT NULL 
)
/
CREATE TRIGGER TProjectRegulatoryType
BEFORE INSERT ON ProjectRegulatoryType
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SProjectRegulatoryType.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/


CREATE SEQUENCE SExpenseType
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE ExpenseType (
    id NUMBER NOT NULL PRIMARY KEY, 
    name VARCHAR2(256) NOT NULL 
)
/
CREATE TRIGGER TExpenseType
BEFORE INSERT ON ExpenseType
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SExpenseType.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SMeditechBackupType
INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE MeditechBackupType (
  id NUMBER NOT NULL PRIMARY KEY,
  name VARCHAR2(256) NOT NULL
)
/
CREATE TRIGGER TMeditechBackupType
BEFORE INSERT ON MeditechBackupType
FOR EACH ROW
WHEN (new.id = 0 OR new.id IS NULL)
  BEGIN
    SELECT
      SMeditechBackupType.NEXTVAL
    INTO :new.id
    FROM dual;
  END;
/

CREATE SEQUENCE SNetworkerDatazoneSize
INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE NetworkerDatazoneSize (
  id NUMBER NOT NULL PRIMARY KEY,
  name VARCHAR2(256) NOT NULL
)
/
CREATE TRIGGER TNetworkerDatazoneSize
BEFORE INSERT ON NetworkerDatazoneSize
FOR EACH ROW
WHEN (new.id = 0 OR new.id IS NULL)
  BEGIN
    SELECT
      SNetworkerDatazoneSize.NEXTVAL
    INTO :new.id
    FROM dual;
  END;
/

CREATE SEQUENCE SEnvironmentDeviceType
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE EnvironmentDeviceType (
    id NUMBER NOT NULL PRIMARY KEY, 
    name VARCHAR2(256) NOT NULL
)
/
CREATE TRIGGER TEnvironmentDeviceType
BEFORE INSERT ON EnvironmentDeviceType
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SEnvironmentDeviceType.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SVnxClariionInstallType
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE VnxClariionInstallType (
    id NUMBER NOT NULL PRIMARY KEY, 
    name VARCHAR2(256) NOT NULL
)
/
CREATE TRIGGER TVnxClariionInstallType
BEFORE INSERT ON VnxClariionInstallType
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SVnxClariionInstallType.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SSrdfConnectionType
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE SrdfConnectionType (
    id NUMBER NOT NULL PRIMARY KEY, 
    name VARCHAR2(256) NOT NULL
)
/
CREATE TRIGGER TSrdfConnectionType
BEFORE INSERT ON SrdfConnectionType
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SSrdfConnectionType.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SPsaAgreementType
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE PsaAgreementType (
    id NUMBER NOT NULL PRIMARY KEY, 
    name VARCHAR2(256) NOT NULL
)
/
CREATE TRIGGER TPsaAgreementType
BEFORE INSERT ON PsaAgreementType
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SPsaAgreementType.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SEnvironmentArrayType
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE EnvironmentArrayType (
    id NUMBER NOT NULL PRIMARY KEY, 
    name VARCHAR2(256) NOT NULL
)
/
CREATE TRIGGER TEnvironmentArrayType
BEFORE INSERT ON EnvironmentArrayType
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SEnvironmentArrayType.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SSrdfStaticDynamicType
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE SrdfStaticDynamicType (
    id NUMBER NOT NULL PRIMARY KEY, 
    name VARCHAR2(256) NOT NULL
)
/
CREATE TRIGGER TSrdfStaticDynamicType
BEFORE INSERT ON SrdfStaticDynamicType
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SSrdfStaticDynamicType.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SVnxInstallProtocolSubType
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE VnxInstallProtocolSubType (
    id NUMBER NOT NULL PRIMARY KEY, 
    name VARCHAR2(256) NOT NULL
)
/
CREATE TRIGGER TVnxInstallProtocolSubType
BEFORE INSERT ON VnxInstallProtocolSubType
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SVnxInstallProtocolSubType.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SRequestType
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE RequestType (
    id NUMBER NOT NULL PRIMARY KEY, 
    name VARCHAR2(256) NOT NULL
)
/
CREATE TRIGGER TRequestType
BEFORE INSERT ON RequestType
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SRequestType.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SSourceVnxType
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE SourceVnxType (
    id NUMBER NOT NULL PRIMARY KEY, 
    name VARCHAR2(256) NOT NULL
)
/
CREATE TRIGGER TSourceVnxType
BEFORE INSERT ON SourceVnxType
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SSourceVnxType.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SAreaSizingType
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE AreaSizingType (
    id NUMBER NOT NULL PRIMARY KEY, 
    name VARCHAR2(256) NOT NULL
)
/
CREATE TRIGGER TAreaSizingType
BEFORE INSERT ON AreaSizingType
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SAreaSizingType.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SCelerraSetupType
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE CelerraSetupType (
    id NUMBER NOT NULL PRIMARY KEY, 
    name VARCHAR2(256) NOT NULL
)
/
CREATE TRIGGER TCelerraSetupType
BEFORE INSERT ON CelerraSetupType
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SCelerraSetupType.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SCelerraArrayType
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE CelerraArrayType (
    id NUMBER NOT NULL PRIMARY KEY, 
    name VARCHAR2(256) NOT NULL
)
/
CREATE TRIGGER TCelerraArrayType
BEFORE INSERT ON CelerraArrayType
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SCelerraArrayType.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE STargetCelerraType
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE TargetCelerraType (
    id NUMBER NOT NULL PRIMARY KEY, 
    name VARCHAR2(256) NOT NULL
)
/
CREATE TRIGGER TTargetCelerraType
BEFORE INSERT ON TargetCelerraType
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT STargetCelerraType.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SConfigChangeType
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE ConfigChangeType (
    id NUMBER NOT NULL PRIMARY KEY, 
    name VARCHAR2(256) NOT NULL
)
/
CREATE TRIGGER TConfigChangeType
BEFORE INSERT ON ConfigChangeType
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SConfigChangeType.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SUnifiedConversionType
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE UnifiedConversionType (
    id NUMBER NOT NULL PRIMARY KEY, 
    name VARCHAR2(256) NOT NULL
)
/
CREATE TRIGGER TUnifiedConversionType
BEFORE INSERT ON UnifiedConversionType
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SUnifiedConversionType.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SVnxInstallProtocolType
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE VnxInstallProtocolType (
    id NUMBER NOT NULL PRIMARY KEY, 
    name VARCHAR2(256) NOT NULL
)
/
CREATE TRIGGER TVnxInstallProtocolType
BEFORE INSERT ON VnxInstallProtocolType
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SVnxInstallProtocolType.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE STestAcceptancePlanType
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE TestAcceptancePlanType (
    id NUMBER NOT NULL PRIMARY KEY, 
    name VARCHAR2(256) NOT NULL
)
/
CREATE TRIGGER TTestAcceptancePlanType
BEFORE INSERT ON TestAcceptancePlanType
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT STestAcceptancePlanType.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SMvConnectionType
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE MvConnectionType (
    id NUMBER NOT NULL PRIMARY KEY, 
    name VARCHAR2(256) NOT NULL
)
/
CREATE TRIGGER TMvConnectionType
BEFORE INSERT ON MvConnectionType
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SMvConnectionType.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SGatewayStorageType
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE GatewayStorageType (
    id NUMBER NOT NULL PRIMARY KEY, 
    name VARCHAR2(256) NOT NULL
)
/
CREATE TRIGGER TGatewayStorageType
BEFORE INSERT ON GatewayStorageType
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SGatewayStorageType.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SKnowledgeTransferLevel
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE KnowledgeTransferLevel (
    id NUMBER NOT NULL PRIMARY KEY, 
    name VARCHAR2(256) NOT NULL
)
/
CREATE TRIGGER TKnowledgeTransferLevel
BEFORE INSERT ON KnowledgeTransferLevel
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SKnowledgeTransferLevel.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/


CREATE SEQUENCE SDocumentationLevel
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE DocumentationLevel (
    id NUMBER NOT NULL PRIMARY KEY, 
    name VARCHAR2(256) NOT NULL
)
/
CREATE TRIGGER TDocumentationLevel
BEFORE INSERT ON DocumentationLevel
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SDocumentationLevel.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SScriptingLevel
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE ScriptingLevel (
    id NUMBER NOT NULL PRIMARY KEY, 
    name VARCHAR2(256) NOT NULL
)
/
CREATE TRIGGER TScriptingLevel
BEFORE INSERT ON ScriptingLevel
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SScriptingLevel.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SClearanceLevel
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE ClearanceLevel (
    id NUMBER NOT NULL PRIMARY KEY, 
    name VARCHAR2(256) NOT NULL
)
/
CREATE TRIGGER TClearanceLevel
BEFORE INSERT ON ClearanceLevel
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SClearanceLevel.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SRiskLevel
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE RiskLevel (
    id NUMBER NOT NULL PRIMARY KEY, 
    name VARCHAR2(256) NOT NULL, 
    code VARCHAR2(10) NOT NULL
)
/
CREATE TRIGGER TRiskLevel
BEFORE INSERT ON RiskLevel
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SRiskLevel.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SNetworkLinkStatus
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE NetworkLinkStatus (
    id NUMBER NOT NULL PRIMARY KEY, 
    name VARCHAR2(256) NOT NULL
)
/
CREATE TRIGGER TNetworkLinkStatus
BEFORE INSERT ON NetworkLinkStatus
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SNetworkLinkStatus.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SMeetingStatus
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE MeetingStatus (
    id NUMBER NOT NULL PRIMARY KEY, 
    name VARCHAR2(256) NOT NULL
)
/
CREATE TRIGGER TMeetingStatus
BEFORE INSERT ON MeetingStatus
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SMeetingStatus.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SPushPullOption
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE PushPullOption (
    id NUMBER NOT NULL PRIMARY KEY, 
    name VARCHAR2(256) NOT NULL
)
/
CREATE TRIGGER TPushPullOption
BEFORE INSERT ON PushPullOption
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SPushPullOption.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SRackAndStackOption
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE RackAndStackOption (
    id NUMBER NOT NULL PRIMARY KEY, 
    name VARCHAR2(256) NOT NULL
)
/
CREATE TRIGGER TRackAndStackOption
BEFORE INSERT ON RackAndStackOption
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SRackAndStackOption.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SBcvCloneOption
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE BcvCloneOption (
    id NUMBER NOT NULL PRIMARY KEY, 
    name VARCHAR2(256) NOT NULL
)
/
CREATE TRIGGER TBcvCloneOption
BEFORE INSERT ON BcvCloneOption
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SBcvCloneOption.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SPostSalesCompletionQualifier
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE PostSalesCompletionQualifier (
    id NUMBER NOT NULL PRIMARY KEY, 
    name VARCHAR2(256) NOT NULL
)
/
CREATE TRIGGER TPostSalesCompletionQualifier
BEFORE INSERT ON PostSalesCompletionQualifier
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SPostSalesCompletionQualifier.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SMvMode
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE MvMode (
    id NUMBER NOT NULL PRIMARY KEY, 
    name VARCHAR2(256) NOT NULL
)
/
CREATE TRIGGER TMvMode
BEFORE INSERT ON MvMode
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SMvMode.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SArrayModel
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE ArrayModel (
    id NUMBER NOT NULL PRIMARY KEY, 
    name VARCHAR2(256) NOT NULL
)
/
CREATE TRIGGER TArrayModel
BEFORE INSERT ON ArrayModel
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SArrayModel.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SIOInterfaceModule
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE IOInterfaceModule (
    id NUMBER NOT NULL PRIMARY KEY, 
    name VARCHAR2(256) NOT NULL
)
/
CREATE TRIGGER TIOInterfaceModule
BEFORE INSERT ON IOInterfaceModule
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SIOInterfaceModule.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SEmcMigrationInvolvement
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE EmcMigrationInvolvement (
    id NUMBER NOT NULL PRIMARY KEY, 
    name VARCHAR2(256) NOT NULL
)
/
CREATE TRIGGER TEmcMigrationInvolvement
BEFORE INSERT ON EmcMigrationInvolvement
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SEmcMigrationInvolvement.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SSymmetrixModel
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE SymmetrixModel (
    id NUMBER NOT NULL PRIMARY KEY, 
    name VARCHAR2(256) NOT NULL
)
/
CREATE TRIGGER TSymmetrixModel
BEFORE INSERT ON SymmetrixModel
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SSymmetrixModel.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SMigrationTestNumber
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE MigrationTestNumber (
    id NUMBER NOT NULL PRIMARY KEY, 
    name VARCHAR2(256) NOT NULL
)
/
CREATE TRIGGER TMigrationTestNumber
BEFORE INSERT ON MigrationTestNumber
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SMigrationTestNumber.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SHostSoftwareInstaller
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE HostSoftwareInstaller (
    id NUMBER NOT NULL PRIMARY KEY, 
    name VARCHAR2(256) NOT NULL
)
/
CREATE TRIGGER THostSoftwareInstaller
BEFORE INSERT ON HostSoftwareInstaller
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SHostSoftwareInstaller.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SCelerraVnxModel
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE CelerraVnxModel (
    id NUMBER NOT NULL PRIMARY KEY, 
    name VARCHAR2(256) NOT NULL
)
/
CREATE TRIGGER TCelerraVnxModel
BEFORE INSERT ON CelerraVnxModel
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SCelerraVnxModel.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SMigrationMethod
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE MigrationMethod (
    id NUMBER NOT NULL PRIMARY KEY, 
    name VARCHAR2(256) NOT NULL
)
/
CREATE TRIGGER TMigrationMethod
BEFORE INSERT ON MigrationMethod
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SMigrationMethod.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SCelerraModel
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE CelerraModel (
    id NUMBER NOT NULL PRIMARY KEY, 
    name VARCHAR2(256) NOT NULL
)
/
CREATE TRIGGER TCelerraModel
BEFORE INSERT ON CelerraModel
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SCelerraModel.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SVNXProtocol
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE VNXProtocol (
    id NUMBER NOT NULL PRIMARY KEY, 
    name VARCHAR2(256) NOT NULL
)
/
CREATE TRIGGER TVNXProtocol
BEFORE INSERT ON VNXProtocol
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SVNXProtocol.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SEnvironmentGatherer
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE EnvironmentGatherer (
    id NUMBER NOT NULL PRIMARY KEY, 
    name VARCHAR2(256) NOT NULL
)
/
CREATE TRIGGER TEnvironmentGatherer
BEFORE INSERT ON EnvironmentGatherer
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SEnvironmentGatherer.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SSrdfMode
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE SrdfMode (
    id NUMBER NOT NULL PRIMARY KEY, 
    name VARCHAR2(256) NOT NULL
)
/
CREATE TRIGGER TSrdfMode
BEFORE INSERT ON SrdfMode
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SSrdfMode.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SMigrationWorker
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE MigrationWorker (
    id NUMBER NOT NULL PRIMARY KEY, 
    name VARCHAR2(256) NOT NULL
)
/
CREATE TRIGGER TMigrationWorker
BEFORE INSERT ON MigrationWorker
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SMigrationWorker.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SSanImplementator
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE SanImplementator (
    id NUMBER NOT NULL PRIMARY KEY, 
    name VARCHAR2(256) NOT NULL
)
/
CREATE TRIGGER TSanImplementator
BEFORE INSERT ON SanImplementator
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SSanImplementator.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SVolumeSizeChange
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE VolumeSizeChange (
    id NUMBER NOT NULL PRIMARY KEY, 
    name VARCHAR2(256) NOT NULL
)
/
CREATE TRIGGER TVolumeSizeChange
BEFORE INSERT ON VolumeSizeChange
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SVolumeSizeChange.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SRepManagerImplementation
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE RepManagerImplementation (
    id NUMBER NOT NULL PRIMARY KEY, 
    name VARCHAR2(256) NOT NULL
)
/
CREATE TRIGGER TRepManagerImplementation
BEFORE INSERT ON RepManagerImplementation
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SRepManagerImplementation.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SRepManagerProductSpecificPrep
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE RepManagerProductSpecificPrep (
    id NUMBER NOT NULL PRIMARY KEY, 
    name VARCHAR2(256) NOT NULL
)
/
CREATE TRIGGER TRepManagerProductSpecificPrep
BEFORE INSERT ON RepManagerProductSpecificPrep
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SRepManagerProductSpecificPrep.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SSowLanguage
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE SowLanguage (
    id NUMBER NOT NULL PRIMARY KEY, 
    name VARCHAR2(256) NOT NULL
)
/
CREATE TRIGGER TSowLanguage
BEFORE INSERT ON SowLanguage
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SSowLanguage.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE STargetCelerra
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE TargetCelerra (
    id NUMBER NOT NULL PRIMARY KEY, 
    name VARCHAR2(256) NOT NULL
)
/
CREATE TRIGGER TTargetCelerra
BEFORE INSERT ON TargetCelerra
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT STargetCelerra.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SSynchronousMode
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE SynchronousMode (
    id NUMBER NOT NULL PRIMARY KEY, 
    name VARCHAR2(256) NOT NULL
)
/
CREATE TRIGGER TSynchronousMode
BEFORE INSERT ON SynchronousMode
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SSynchronousMode.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SReplicationFailoverLevel
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE ReplicationFailoverLevel (
    id NUMBER NOT NULL PRIMARY KEY, 
    name VARCHAR2(256) NOT NULL
)
/
CREATE TRIGGER TReplicationFailoverLevel
BEFORE INSERT ON ReplicationFailoverLevel
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SReplicationFailoverLevel.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SReplicationManagerInformation
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE ReplicationManagerInformation (
    id NUMBER NOT NULL PRIMARY KEY,
    knowledge_transfer_hours VARCHAR2(256),
    time_finder_managed NUMBER(1),
    open_replicator_managed NUMBER(1),
    snap_view_managed NUMBER(1),
    recover_point_managed NUMBER(1),
    san_copy_managed NUMBER(1),
    celerra_managed NUMBER(1),
    snap_sure_managed NUMBER(1),
    replication_installed NUMBER(1),
    rep_man_implementation_id NUMBER,
    rep_man_prod_specific_prep_id NUMBER,
    replicated_storage_size INT,
    nr_of_replicas INT,
    nr_of_replicated_apps INT,
    nr_of_replication_jobs INT,
    config_change_type_id NUMBER,
    manager_servers_number INT,
    clustered_rm_server_option NUMBER(1),
    include_app_integration NUMBER(1),
    custom_scripting_required NUMBER(1),
    FOREIGN KEY (rep_man_implementation_id) REFERENCES RepManagerImplementation (id),
    FOREIGN KEY (rep_man_prod_specific_prep_id) REFERENCES RepManagerProductSpecificPrep (id),
    FOREIGN KEY (config_change_type_id) REFERENCES ConfigChangeType (id)
)
/
CREATE TRIGGER TReplicationManagerInformation
BEFORE INSERT ON ReplicationManagerInformation
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SReplicationManagerInformation.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE TABLE RepManagerInformation_SHN (
    rep_man_information_int NUMBER,
    map_key VARCHAR2(256),
    map_value INT,
    FOREIGN KEY (rep_man_information_int) REFERENCES ReplicationManagerInformation (id)
)
/

CREATE TABLE RepManagerInformation_THN (
    rep_man_information_int NUMBER,
    map_key VARCHAR2(256),
    map_value INT,
    FOREIGN KEY (rep_man_information_int) REFERENCES ReplicationManagerInformation (id)
)
/

CREATE SEQUENCE STimeFinderInformation
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE TimeFinderInformation (
    id NUMBER NOT NULL PRIMARY KEY,
    knowledge_transfer_hours VARCHAR2(256),
    bcv_to_implement NUMBER(1),
    clone_to_implement NUMBER(1),
    snap_to_implement NUMBER(1),
    vp_snap_to_implement NUMBER(1),
    config_change_type_id NUMBER,
    replicated_storage_size INT,
    nr_of_clone_copies INT,
    nr_of_bcv_copies INT,
    nr_of_snaps_copies INT,
    nr_of_vp_snaps_copies INT,
    nr_of_solution_enabler_hosts INT,
    nr_of_clone_pairs INT,
    scripting_level_id NUMBER,
    area_sizing_type_id NUMBER,
    FOREIGN KEY (config_change_type_id) REFERENCES ConfigChangeType (id),
    FOREIGN KEY (scripting_level_id) REFERENCES ScriptingLevel (id),
    FOREIGN KEY (area_sizing_type_id) REFERENCES AreaSizingType (id)
)
/
CREATE TRIGGER TTimeFinderInformation
BEFORE INSERT ON TimeFinderInformation
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT STimeFinderInformation.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE TABLE TimeFinderInformation_HN (
    time_finder_information_int NUMBER,
    map_key VARCHAR2(256),
    map_value INT,
    FOREIGN KEY (time_finder_information_int) REFERENCES TimeFinderInformation (id)
)
/

CREATE SEQUENCE SSnapViewInformation
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE SnapViewInformation (
    id NUMBER NOT NULL PRIMARY KEY,
    knowledge_transfer_hours VARCHAR2(256),
    replicated_storage_size INT,
    snap_view_func_required NUMBER(1),
    snap_shot_view_func_required NUMBER(1),
    nr_of_vnx_arrays INT,
    nr_of_vnx_snapshots_copies INT,
    nr_of_snap_view_clones_copies INT,
    scripting_level_id NUMBER,
    nr_of_consistent_sessions INT,
    nr_of_persistent_sessions INT,
    FOREIGN KEY (scripting_level_id) REFERENCES ScriptingLevel (id)
)
/
CREATE TRIGGER TSnapViewInformation
BEFORE INSERT ON SnapViewInformation
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SSnapViewInformation.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE TABLE SnapViewInformation_HN (
    snap_view_information_int NUMBER,
    map_key VARCHAR2(256),
    map_value INT,
    FOREIGN KEY (snap_view_information_int) REFERENCES SnapViewInformation (id)
)
/

CREATE SEQUENCE SBCServicesScope
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE BCServicesScope (
    id NUMBER NOT NULL PRIMARY KEY, 
    srdf NUMBER(1),
    time_finder NUMBER(1),
    mirrow_view NUMBER(1),
    snap_view NUMBER(1),
    replication_services NUMBER(1)
)
/
CREATE TRIGGER TBCServicesScope
BEFORE INSERT ON BCServicesScope
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SBCServicesScope.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SOpenReplicator
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE OpenReplicator (
    id NUMBER NOT NULL PRIMARY KEY,
    knowledge_transfer_hours VARCHAR2(256),
    post_sales_compl_qualifier_id NUMBER,
    FOREIGN KEY (post_sales_compl_qualifier_id) REFERENCES PostSalesCompletionQualifier (id)
)
/
CREATE TRIGGER TOpenReplicator
BEFORE INSERT ON OpenReplicator
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SOpenReplicator.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SSrdfInformation
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE SrdfInformation (
    id NUMBER NOT NULL PRIMARY KEY,
    knowledge_transfer_hours VARCHAR2(256),
    srdfS_functionality_required NUMBER(1),
    srdfA_functionality_required NUMBER(1),
    casc_srdf_func_required NUMBER(1),
    srdf_star_func_required NUMBER(1),
    concurrent_srdf_func_required NUMBER(1),
    network_link_status_id NUMBER,
    srdf_static_dynamic_type_id NUMBER,
    bc_practive_script_level2_id NUMBER,
    emc_map_points_option NUMBER(1),
    srdf_ce NUMBER(1),
    num_symm_directors_fa2ra_conv INT,
    num_symm_ra_directors_compres INT,
    num_symm_gigabit_ethernet_dir INT,
    FOREIGN KEY (network_link_status_id) REFERENCES NetworkLinkStatus (id),
    FOREIGN KEY (srdf_static_dynamic_type_id) REFERENCES SrdfStaticDynamicType (id),
    FOREIGN KEY (bc_practive_script_level2_id) REFERENCES ScriptingLevel (id)
)
/
CREATE TRIGGER TSrdfInformation
BEFORE INSERT ON SrdfInformation
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SSrdfInformation.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE TABLE SrdfInformation_sourceArray (
    srdf_information_id NUMBER NOT NULL,
    symmetrix_model_id NUMBER,
    srdf_installed_status NUMBER(1),
    replicate_size INT,
    nr_of_symm_rdf_devices INT,
    nr_of_symm_devices_rdf_sites INT,
    uni_option_enabled NUMBER(1),
    nr_of_rdf_pairs INT,
    nr_of_rdf_groups INT,
    srdf_connection_type_id NUMBER,
    FOREIGN KEY (symmetrix_model_id) REFERENCES SymmetrixModel (id),
    FOREIGN KEY (srdf_connection_type_id) REFERENCES SrdfConnectionType (id),
    FOREIGN KEY (srdf_information_id) REFERENCES SrdfInformation (id)
)
/

CREATE TABLE SrdfInformation_targetArray (
    srdf_information_id NUMBER NOT NULL,
    symmetrix_model_id NUMBER,
    srdf_installed_status NUMBER(1),
    time_finder INT,
    bcv_clones_number INT,
    tf_backup NUMBER(1),
    source_name VARCHAR2(256),
    include_bandwidth_analysis NUMBER(1),
    include_network_assessement NUMBER(1),
    nr_of_hosts_needed INT,
    nr_of_device_composite_groups INT,
    FOREIGN KEY (symmetrix_model_id) REFERENCES SymmetrixModel (id),
    FOREIGN KEY (srdf_information_id) REFERENCES SrdfInformation (id)
)
/

CREATE TABLE SrdfInformation_hostNumbers (
    srdf_information_id NUMBER,
    map_key VARCHAR2(256),
    map_value INT,
    FOREIGN KEY (srdf_information_id) REFERENCES SrdfInformation (id)
)
/

CREATE SEQUENCE SMirrorViewInformation
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE MirrorViewInformation (
    id NUMBER NOT NULL PRIMARY KEY,
    knowledge_transfer_hours VARCHAR2(256), 
    mirror_viewS_func_required NUMBER(1),
    mirror_viewA_func_required NUMBER(1),
    mirror_viewCE_func_required NUMBER(1),
    network_link_status_id NUMBER,
    mirrow_view_script_level_id NUMBER,
    custom_scripting_details VARCHAR2(256),
    nr_of_consistency_groups INT,
    nr_of_remote_mirrors INT,
    nr_of_secondary_images_created INT,
    FOREIGN KEY (network_link_status_id) REFERENCES NetworkLinkStatus (id),
    FOREIGN KEY (mirrow_view_script_level_id) REFERENCES ScriptingLevel (id)
)
/
CREATE TRIGGER TMirrorViewInformation
BEFORE INSERT ON MirrorViewInformation
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SMirrorViewInformation.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE TABLE MirrorViewInformation_SA (
    mirror_view_information_id NUMBER NOT NULL,
    array_model_id NUMBER,
    existing_option_enabled NUMBER(1),
    mirrow_view_installed_status NUMBER(1),
    replicate_size INT,
    uni_option_enabled NUMBER(1),
    mv_connection_type_id NUMBER,
    FOREIGN KEY (array_model_id) REFERENCES ArrayModel (id),
    FOREIGN KEY (mv_connection_type_id) REFERENCES MvConnectionType (id),
    FOREIGN KEY (mirror_view_information_id) REFERENCES MirrorViewInformation (id)
)
/

CREATE TABLE MirrorViewInformation_TA (
    mirror_view_information_id NUMBER NOT NULL,
    array_model_id NUMBER,
    new_mv_mode_id NUMBER,
    existing_option_enabled NUMBER(1),
    mirrow_view_installed_status NUMBER(1),
    FOREIGN KEY (array_model_id) REFERENCES ArrayModel (id),
    FOREIGN KEY (new_mv_mode_id) REFERENCES MvMode (id),
    FOREIGN KEY (mirror_view_information_id) REFERENCES MirrorViewInformation (id)
)
/

CREATE TABLE MirrorViewInformation_HN (
    mirror_view_information_id NUMBER,
    map_key VARCHAR2(256),
    map_value INT,
    FOREIGN KEY (mirror_view_information_id) REFERENCES MirrorViewInformation (id)
)
/

CREATE SEQUENCE SBcRequestData
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE BcRequestData (
    id NUMBER NOT NULL PRIMARY KEY, 
    general_comment VARCHAR2(256),
    knowledge_transfer_days VARCHAR2(256),
    services_scope_id NUMBER,
    srdf_information_id NUMBER,
    time_finder_information_id NUMBER,
    mirror_view_information_id NUMBER,
    snap_view_information_id NUMBER,
    repl_manager_information_id NUMBER,
	  nas_ip_repl_knowl_trans_days VARCHAR2(256),
    FOREIGN KEY (services_scope_id) REFERENCES BCServicesScope (id),
    FOREIGN KEY (srdf_information_id) REFERENCES SrdfInformation (id),
    FOREIGN KEY (time_finder_information_id) REFERENCES TimeFinderInformation (id),
    FOREIGN KEY (mirror_view_information_id) REFERENCES MirrorViewInformation (id),
    FOREIGN KEY (snap_view_information_id) REFERENCES SnapViewInformation (id),
    FOREIGN KEY (repl_manager_information_id) REFERENCES ReplicationManagerInformation (id)
)
/
CREATE TRIGGER TBcRequestData
BEFORE INSERT ON BcRequestData
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SBcRequestData.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SCifsFeature
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE CifsFeature (
    id NUMBER NOT NULL PRIMARY KEY, 
    gpo_required NUMBER(1),
    local_users_groups_required NUMBER(1),
    dfs_roots_servers_required NUMBER(1),
    wide_links_required NUMBER(1),
    file_extension_required NUMBER(1),
    ext_user_mappings_required NUMBER(1)
)
/
CREATE TRIGGER TCifsFeature
BEFORE INSERT ON CifsFeature
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SCifsFeature.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SNasFeature
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE NasFeature (
    id NUMBER NOT NULL PRIMARY KEY, 
    advanced_file_system_features NUMBER(1),
    advanced_networking_features NUMBER(1),
    advanced_storage_features NUMBER(1),
    backup NUMBER(1),
    vee NUMBER(1),
    vnx_file_mover NUMBER(1),
    ftp NUMBER(1),
    vnx_data_deduplication NUMBER(1),
    iscsi NUMBER(1),
    vnx_mpfs NUMBER(1),
    vnx_quotas NUMBER(1),
    vnx_replicator NUMBER(1),
    vnx_iscsi_replicator NUMBER(1),
    vnx_administrative_security NUMBER(1),
    vnx_snap_sure NUMBER(1)
)
/
CREATE TRIGGER TNasFeature
BEFORE INSERT ON NasFeature
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SNasFeature.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SUnifiedServicesScope
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE UnifiedServicesScope (
    id NUMBER NOT NULL PRIMARY KEY, 
    celerra_implementation NUMBER(1),
    nas_health_check NUMBER(1),
    file_nas_migration NUMBER(1),
    mpfs NUMBER(1),
    nas_srdf_replication NUMBER(1),
    mdl_dlm NUMBER(1),
    nas_ip_replication NUMBER(1)
)
/
CREATE TRIGGER TUnifiedServicesScope
BEFORE INSERT ON UnifiedServicesScope
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SUnifiedServicesScope.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SNasMigrationInformation
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE NasMigrationInformation (
    id NUMBER NOT NULL PRIMARY KEY,
    location VARCHAR2(256),
	average_file_size INT,
	cifs_data_size INT,
	cifs_file_system_number INT,
	cifs_local_group_option NUMBER(1),
	nfs_data_size_number INT,
	nfs_file_system_number INT,
	bimodal_data_size_number INT,
	bimodal_file_system_number INT,
	certified_data_migr_option NUMBER(1),
	migration_window_length INT,
	migr_windows_customer_number INT,
	celerra_vnx_model_id NUMBER,
	target_celerra_id NUMBER,
	migration_method_id NUMBER,
    FOREIGN KEY (celerra_vnx_model_id) REFERENCES CelerraVnxModel (id),
    FOREIGN KEY (target_celerra_id) REFERENCES TargetCelerra (id),
    FOREIGN KEY (migration_method_id) REFERENCES MigrationMethod (id)
)
/
CREATE TRIGGER TNasMigrationInformation
BEFORE INSERT ON NasMigrationInformation
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SNasMigrationInformation.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SCelerraDetailInformation
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE CelerraDetailInformation (
    id NUMBER NOT NULL PRIMARY KEY, 
    celerra_model_id NUMBER,
    vnx_protocol_id NUMBER,
    celerra_location VARCHAR2(256),
    new_celerra_option NUMBER(1),
    disk_array_enclosures_incl NUMBER(1),
    rack_and_stack_option_id NUMBER,
    gateway_storage_type_id NUMBER,
    new_symmetrix_storage_option NUMBER(1),
    dual_control_stations_used NUMBER(1),
    datamovers_number INT,
    file_fast_vp_configured NUMBER(1),
    usable_storage_size INT,
    file_system_number INT,
    nfs_configured NUMBER(1),
    cifs_configured NUMBER(1),
    multi_protocol_celerra_conf NUMBER(1),
    nas_features_id NUMBER,
    cifs_features_included NUMBER(1),
    ldap_required NUMBER(1),
    nfsv4_configured NUMBER(1),
    include_nfs_over_fc NUMBER(1),
    include_nfs_over_iscsi NUMBER(1),
    ip_replication_configured NUMBER(1),
    deinstall_celera NUMBER(1),
    cava_server_number INT,
    mpfs_required NUMBER(1),
    mpfs_host_quantity INT,
    mpfs_file_systems_quantity INT,
    mpfsi_required NUMBER(1),
    mpfsi_host_quantity INT,
    mpfsi_file_systems_quantity INT,
    file_servers_number INT,
    file_systems_number INT,
    cifs_file_servers_number INT,
    cifs_file_shares_number INT,
    nfs_file_systems_conf_number INT,
    nfs_fs_export_number INT,
    io_interface_module_id NUMBER,
    FOREIGN KEY (celerra_model_id) REFERENCES CelerraModel (id),
    FOREIGN KEY (vnx_protocol_id) REFERENCES CelerraModel (id),
    FOREIGN KEY (rack_and_stack_option_id) REFERENCES RackAndStackOption (id),
    FOREIGN KEY (gateway_storage_type_id) REFERENCES GatewayStorageType (id),
    FOREIGN KEY (nas_features_id) REFERENCES NasFeature (id),
    FOREIGN KEY (io_interface_module_id) REFERENCES IOInterfaceModule (id)
)
/
CREATE TRIGGER TCelerraDetailInformation
BEFORE INSERT ON CelerraDetailInformation
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SCelerraDetailInformation.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SNasIpReplicationInformation
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE NasIpReplicationInformation (
    id NUMBER NOT NULL PRIMARY KEY,
    new_file_system_repl_number INT,
    replicated_data_size INT,
    vnx_array VARCHAR2(256),
    include_local_replication NUMBER(1),
    include_remote_replication NUMBER(1),
    nr_of_cifs_file_systems INT,
    tb_of_cifs_file_systems INT,
    nr_of_nfs_file_systems INT,
    tb_of_nfs_file_systems INT,
    celerra_device_type VARCHAR2(256)
)
/
CREATE TRIGGER TNasIpReplicationInformation
BEFORE INSERT ON NasIpReplicationInformation
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SNasIpReplicationInformation.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SUnifiedRequestData
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE UnifiedRequestData (
    id NUMBER NOT NULL PRIMARY KEY, 
    general_comment VARCHAR2(256),
    cele_detail_know_trans_days VARCHAR2(256),
    nas_migr_knowledge_trans_days VARCHAR2(256),
    nas_srdf_repl_know_trans_days VARCHAR2(256),
    mdl_dlm_knowl_trans_days VARCHAR2(256),
    include_unified_home_dirs NUMBER(1),
    include_unified_virtual_dm NUMBER(1),
    services_scope_id NUMBER,
    FOREIGN KEY (services_scope_id) REFERENCES UnifiedServicesScope (id)
)
/
CREATE TRIGGER TUnifiedRequestData
BEFORE INSERT ON UnifiedRequestData
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SUnifiedRequestData.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE TABLE UnifiedRequestData_celerraDI (
    unified_request_data_id NUMBER NOT NULL,
    celerra_detail_information_id NUMBER NOT NULL,
    FOREIGN KEY (unified_request_data_id) REFERENCES UnifiedRequestData (id),
    FOREIGN KEY (celerra_detail_information_id) REFERENCES CelerraDetailInformation (id)
)
/

CREATE TABLE UnifiedRequestData_nasMI (
    unified_request_data_id NUMBER NOT NULL,
    nas_migration_information_id NUMBER NOT NULL,
    FOREIGN KEY (unified_request_data_id) REFERENCES UnifiedRequestData (id),
    FOREIGN KEY (nas_migration_information_id) REFERENCES NasMigrationInformation (id)
)
/

CREATE TABLE BcRequestData_nasIpRI (
    bc_request_data_id NUMBER NOT NULL,
    nas_ip_repl_information_id NUMBER NOT NULL,
    FOREIGN KEY (bc_request_data_id) REFERENCES BcRequestData (id),
    FOREIGN KEY (nas_ip_repl_information_id) REFERENCES NasIpReplicationInformation (id)
)
/

CREATE SEQUENCE SSanTanInformation
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE SanTanInformation (
    id NUMBER NOT NULL PRIMARY KEY,
    knowledge_transfer_hours VARCHAR2(256), 
    san_migration_in_scope_option NUMBER(1),
    total_ports_to_migrate INT,
    san_directors_number INT,
    san_switches_number INT,
    blades_number INT,
    fcoe_switches_number INT,
    fcoe_vlan_number INT,
    fcoe_channel_number INT,
    san_extension_devices_number INT,
    nas_to_cx_units_number INT,
    nas_to_symmetrix_units_number INT,
    nas_to_cx_hosts_number INT,
    nas_to_symmetrix_hosts_number INT,
    verify_major_outage_conn_hn INT,
    deinst_san_directors_number INT,
    deinst_san_switches_number INT,
    deinst_san_extension_dn INT
)
/
CREATE TRIGGER TSanTanInformation
BEFORE INSERT ON SanTanInformation
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SSanTanInformation.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SDataMigrationInformation
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE DataMigrationInformation (
    id NUMBER NOT NULL PRIMARY KEY,
    knowledge_transfer_hours VARCHAR2(256),
    migration_worker_id NUMBER,
    migr_luns_to_symmetrix_option NUMBER(1),
    migr_luns_to_clariion_option NUMBER(1),
    symm_volume_size_change_id NUMBER,
    clar_volume_size_change_id NUMBER,
    emc_migration_involvement_id NUMBER,
    weekend_maintenance_hours INT,
    migr_cutover_hosts_number INT,
    migr_cutover_tests_number INT,
    migr_cutover_events_number INT,
    script_adjustment_option NUMBER(1),
    weekend_migrations_number INT,
    include_eca NUMBER(1),
    include_storage_data_erasure NUMBER(1),
    remove_relocate_emc_storage NUMBER(1),
    proposed_migration_tools VARCHAR2(256),
    FOREIGN KEY (migration_worker_id) REFERENCES MigrationWorker (id),
    FOREIGN KEY (symm_volume_size_change_id) REFERENCES VolumeSizeChange (id),
    FOREIGN KEY (clar_volume_size_change_id) REFERENCES VolumeSizeChange (id),
    FOREIGN KEY (emc_migration_involvement_id) REFERENCES EmcMigrationInvolvement (id)
)
/
CREATE TRIGGER TDataMigrationInformation
BEFORE INSERT ON DataMigrationInformation
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SDataMigrationInformation.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE TABLE DataMigInformationn_array (
    data_migration_information_id NUMBER,
    array_type_id NUMBER,
    location VARCHAR2(256),
    number_non_esx_hosts INT,
    number_esx_hosts INT,
    number_virtual_machines INT,
    swing_box NUMBER(1),
    array_type VARCHAR2(256),
    capacity DOUBLE PRECISION,
    FOREIGN KEY (array_type_id) REFERENCES EnvironmentArrayType (id),
    FOREIGN KEY (data_migration_information_id) REFERENCES DataMigrationInformation (id)
)
/

CREATE SEQUENCE SEnvironmentDetailsInformation
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE EnvironmentDetailsInformation (
    id NUMBER NOT NULL PRIMARY KEY, 
    environment_gatherer_id NUMBER,
    dca_appliances_number1 INT,
    host_software_installer_id NUMBER,
    san_implementator_id NUMBER,
    existing_san_fabrics_number INT,
    FOREIGN KEY (environment_gatherer_id) REFERENCES EnvironmentGatherer (id),
    FOREIGN KEY (host_software_installer_id) REFERENCES HostSoftwareInstaller (id),
    FOREIGN KEY (san_implementator_id) REFERENCES SanImplementator (id)
)
/
CREATE TRIGGER TEnvironmentDetailsInformation
BEFORE INSERT ON EnvironmentDetailsInformation
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SEnvironmentDetailsInformation.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SEnvDetailsInformation_exAT
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE EnvDetailsInformation_exAT (
    id NUMBER NOT NULL PRIMARY KEY, 
    env_details_information_id NUMBER,
    environment_array_type_id NUMBER,
    FOREIGN KEY (env_details_information_id) REFERENCES EnvironmentDetailsInformation (id),
    FOREIGN KEY (environment_array_type_id) REFERENCES EnvironmentArrayType (id)
)
/
CREATE TRIGGER TEnvDetailsInformation_exAT
BEFORE INSERT ON EnvDetailsInformation_exAT
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SEnvDetailsInformation_exAT.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SEnvDetailsInformation_exSL
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE EnvDetailsInformation_exSL (
    id NUMBER NOT NULL PRIMARY KEY, 
    env_details_information_id NUMBER,
    value VARCHAR2(256),
    FOREIGN KEY (env_details_information_id) REFERENCES EnvironmentDetailsInformation (id)
)
/
CREATE TRIGGER TEnvDetailsInformation_exSL
BEFORE INSERT ON EnvDetailsInformation_exSL
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SEnvDetailsInformation_exSL.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SEnvDetailsInformation_UC
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE EnvDetailsInformation_UC (
    id NUMBER NOT NULL PRIMARY KEY,
    env_details_information_id NUMBER,
    value DOUBLE PRECISION,
    FOREIGN KEY (env_details_information_id) REFERENCES EnvironmentDetailsInformation (id)
)
/
CREATE TRIGGER TEnvDetailsInformation_UC
BEFORE INSERT ON EnvDetailsInformation_UC
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SEnvDetailsInformation_UC.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SEnvDetailsInformation_NAH
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE EnvDetailsInformation_NAH (
    id NUMBER NOT NULL PRIMARY KEY,
    env_details_information_id NUMBER,
    value INT,
    FOREIGN KEY (env_details_information_id) REFERENCES EnvironmentDetailsInformation (id)
)
/
CREATE TRIGGER TEnvDetailsInformation_NAH
BEFORE INSERT ON EnvDetailsInformation_NAH
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SEnvDetailsInformation_NAH.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SEnvDetailsInformation_EDT
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE EnvDetailsInformation_EDT (
    id NUMBER NOT NULL PRIMARY KEY,
    env_details_information_id NUMBER,
    environment_device_type_id NUMBER,
    FOREIGN KEY (env_details_information_id) REFERENCES EnvironmentDetailsInformation (id),
    FOREIGN KEY (environment_device_type_id) REFERENCES EnvironmentDeviceType (id)
)
/
CREATE TRIGGER TEnvDetailsInformation_EDT
BEFORE INSERT ON EnvDetailsInformation_EDT
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SEnvDetailsInformation_EDT.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SEnvDetailsInformation_exSanLo
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE EnvDetailsInformation_exSanLo (
    id NUMBER NOT NULL PRIMARY KEY,
    env_details_information_id NUMBER,
    value VARCHAR2(256),
    FOREIGN KEY (env_details_information_id) REFERENCES EnvironmentDetailsInformation (id)
)
/
CREATE TRIGGER TEnvDetailsInformation_exSanLo
BEFORE INSERT ON EnvDetailsInformation_exSanLo
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SEnvDetailsInformation_exSanLo.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SEnvDetailsInformation_man
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE EnvDetailsInformation_man (
    id NUMBER NOT NULL PRIMARY KEY,
    env_details_information_id NUMBER,
    value VARCHAR2(256),
    FOREIGN KEY (env_details_information_id) REFERENCES EnvironmentDetailsInformation (id)
)
/
CREATE TRIGGER TEnvDetailsInformation_man
BEFORE INSERT ON EnvDetailsInformation_man
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SEnvDetailsInformation_man.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SEnvDetailsInformation_devQ
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE EnvDetailsInformation_devQ (
    id NUMBER NOT NULL PRIMARY KEY,
    env_details_information_id NUMBER,
    value DOUBLE PRECISION,
    FOREIGN KEY (env_details_information_id) REFERENCES EnvironmentDetailsInformation (id)
)
/
CREATE TRIGGER TEnvDetailsInformation_devQ
BEFORE INSERT ON EnvDetailsInformation_devQ
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SEnvDetailsInformation_devQ.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SEnvDetailsInformation_hostIn
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE
/
CREATE TABLE EnvDetailsInformation_hostIn (
    id NUMBER NOT NULL PRIMARY KEY,
    env_details_information_id NUMBER,
    platform VARCHAR2(256),
    host_number INT,
    new_host_number INT,
    number_of_clusters INT,
    number_boot_from_san INT,
    array_host_attached_to VARCHAR2(256),
    FOREIGN KEY (env_details_information_id) REFERENCES EnvironmentDetailsInformation (id)
)
/
CREATE TRIGGER TEnvDetailsInformation_hostIn
BEFORE INSERT ON EnvDetailsInformation_hostIn
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SEnvDetailsInformation_hostIn.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;
/



CREATE SEQUENCE SSymmetrixMF
INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE
/
CREATE TABLE SymmetrixMF (
  id                           NUMBER NOT NULL PRIMARY KEY,
  knowledge_transfer_hours     VARCHAR2(256),
  vmax_arrays_number           INT,
  dmx_arrays_number            INT,
  vmax_arrays_upgrade_number   INT,
  dmx_arrays_upgrade_number    INT,
  srdf_arrays_number           INT,
  srdfA_arrays_number          INT,
  virtual_prov_arrays_number   INT,
  thin_devices_host_number     INT,
  lun_to_dmx_host_number       INT,
  auto_prov_to_dmx_host_number INT,
  advanced_fast_arrays_number  INT,
  deinst_open_sys_vmax_number  INT,
  vmax_arrays_num              INT,
  vmax_groups_num              INT,
  vmax_combinations_num        INT,
  vmax_tiers_num               INT,
  vmax_policies_num            INT,
  vmax_performance_windows_num INT,
  vmax_dm_windows_num          INT,
  vmax_add_h_cr_dev_tests_num  INT,
  vmax_add_h_exe_dev_tests_num INT,
  vp_storage_groups_num        INT,
  vp_disk_combinations_num     INT,
  tdev_num                     INT,
  tdat_num                     INT,
  vp_thin_pools_num            INT,
  fast_vp_perf_time_windows_num INT,
  fast_vp_move_time_windows_num INT,
  fast_vp_tiers_num            INT,
  fast_vp_policies_num         INT,
  engagement_adding_fast_vp    NUMBER(1)
)
/
CREATE TRIGGER TSymmetrixMF
BEFORE INSERT ON SymmetrixMF
FOR EACH ROW
WHEN (new.id = 0 OR new.id IS NULL)
  BEGIN
    SELECT
      SSymmetrixMF.NEXTVAL
    INTO :new.id
    FROM dual;
  END;
/


CREATE SEQUENCE SSymmetrixOS
INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE
/
CREATE TABLE SymmetrixOS (
  id                           NUMBER NOT NULL PRIMARY KEY,
  knowledge_transfer_hours     VARCHAR2(256),
  vmax_arrays_number           INT,
  dmx_arrays_number            INT,
  vmax_arrays_upgrade_number   INT,
  dmx_arrays_upgrade_number    INT,
  srdf_arrays_number           INT,
  srdfA_arrays_number          INT,
  virtual_prov_arrays_number   INT,
  thin_devices_host_number     INT,
  lun_to_dmx_host_number       INT,
  auto_prov_to_dmx_host_number INT,
  advanced_fast_arrays_number  INT,
  deinst_open_sys_vmax_number  INT,
  vmax_arrays_num              INT,
  vmax_groups_num              INT,
  vmax_combinations_num        INT,
  vmax_tiers_num               INT,
  vmax_policies_num            INT,
  vmax_performance_windows_num INT,
  vmax_dm_windows_num          INT,
  vmax_add_h_cr_dev_tests_num  INT,
  vmax_add_h_exe_dev_tests_num INT,
  vp_storage_groups_num        INT,
  vp_disk_combinations_num     INT,
  tdev_num                     INT,
  tdat_num                     INT,
  vp_thin_pools_num            INT,
  fast_vp_perf_time_windows_num INT,
  fast_vp_move_time_windows_num INT,
  fast_vp_tiers_num            INT,
  fast_vp_policies_num         INT,
  engagement_adding_fast_vp    NUMBER(1)
)
/
CREATE TRIGGER TSymmetrixOS
BEFORE INSERT ON SymmetrixOS
FOR EACH ROW
WHEN (new.id = 0 OR new.id IS NULL)
  BEGIN
    SELECT
      SSymmetrixOS.NEXTVAL
    INTO :new.id
    FROM dual;
  END;
/

CREATE SEQUENCE SVnxClariionInformation
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE VnxClariionInformation (
    id NUMBER NOT NULL PRIMARY KEY,
    knowledge_transfer_hours VARCHAR2(256),
    virtual_prov_arrays_number INT,
	  vnx_arrays_number INT,
    unisphere_domains_number INT,
    fast_cache_setup_number INT,
    cert_disk_erasure_arrays_num INT,
    deinstall_cx_ns_vnx_number INT,
    vnx_clariion_install_type_id NUMBER,
    unified_conversions_required NUMBER(1),
    unified_conversion_type_id NUMBER,
    health_check_required NUMBER(1),
    sap_hana_required NUMBER(1),
    vnx_install_protocol_type_id NUMBER,
    vnx_install_prot_sub_type_id NUMBER,
    vnx_mon_reporting_required NUMBER(1),
    fc_storage_conn_required NUMBER(1),
    fcoe_storage_conn_required NUMBER(1),
    iscsi_san_ext_stor_conn_req NUMBER(1),
    vsan_lsan_stor_conn_required NUMBER(1),
    fc_routing_stor_conn_required NUMBER(1),
    virtual_infr_enable_included NUMBER(1),
    watch4_net_included NUMBER(1),
    unified_local_protection NUMBER(1),
    unified_remote_protection NUMBER(1),
    unified_app_protection NUMBER(1),
    unified_fast_deployment NUMBER(1),
    unified_security_compliance NUMBER(1),
    unified_management_suite NUMBER(1),
    data_protection_advisor NUMBER(1),
    fast_lun_migrator NUMBER(1),
    mirror_view NUMBER(1),
    qos_manager NUMBER(1),
    replication_manager NUMBER(1),
    recover_point NUMBER(1),
    san_copy NUMBER(1),
    snap_view_vnx_snap_shots NUMBER(1),
    virtual_provisioning NUMBER(1),
    unisphere_analyzer NUMBER(1),
    unisphere_remote NUMBER(1),
    storage_analytics NUMBER(1),
    unified_file_oe_required NUMBER(1),
    dial_home_activities NUMBER(1),
    flash_stor_layout_services_id NUMBER,
    vnx_file_servers_number INT,
    total_storage_amount DOUBLE PRECISION,
    active_data_movers_number INT,
    control_stations_number INT,
    file_systems_number INT,
    avg_file_system_size VARCHAR2(256),
    storage_pools_number INT,
    storage_groups_number INT,
    thin_luns_number INT,
    iscsi NUMBER(1),
    iscsi_required NUMBER(1),
    iscsi_host_quantity INT,
    ivnx_scsi_host_quantity INT,
    idart_scsi_host_quantity INT,
    FOREIGN KEY (vnx_clariion_install_type_id) REFERENCES VnxClariionInstallType (id),
    FOREIGN KEY (unified_conversion_type_id) REFERENCES UnifiedConversionType (id),
    FOREIGN KEY (vnx_install_protocol_type_id) REFERENCES VnxInstallProtocolType (id),
    FOREIGN KEY (vnx_install_prot_sub_type_id) REFERENCES VnxInstallProtocolSubType (id),
    FOREIGN KEY (flash_stor_layout_services_id) REFERENCES FlashStorageLayoutServices (id)
)
/
CREATE TRIGGER TVnxClariionInformation
BEFORE INSERT ON VnxClariionInformation
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SVnxClariionInformation.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/


CREATE SEQUENCE SVplex
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE Vplex (
    id NUMBER NOT NULL PRIMARY KEY,
    knowledge_transfer_hours DECIMAL(20, 2),
    sites_number INT,
    engine_number INT,
    directors_number INT,
    existing_c4_upgraded_number INT,
    virtual_volumes_number INT,
    mirrors_number INT,
    metro_clusters_number INT,
    geo_clusters_number INT,
    hosts_number INT,
    arrays_number INT,
    storage_ports_number INT,
    storage_volumes_number INT,
    witness_server_number INT,
    data_mobility_type_id NUMBER,
    data_mobility_jobs_number INT,
    encapsulated_hosts_number INT,
    emc_installed_option NUMBER(1),
    recoverpoint_installed_option NUMBER(1),
    FOREIGN KEY (data_mobility_type_id) REFERENCES VplexDataMobilityType (id)
)
/
CREATE TRIGGER TVplex
BEFORE INSERT ON Vplex
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SVplex.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SInfrastructureRequestData
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE InfrastructureRequestData (
    id NUMBER NOT NULL PRIMARY KEY,
    general_comment VARCHAR2(256),
    symmetrix_mf_service_enabled NUMBER(1),
    symmetrix_os_service_enabled NUMBER(1),
    data_migr_service_enabled NUMBER(1),
    vnx_clariion_service_enabled NUMBER(1),
    cx_repl_service_enabled NUMBER(1),
    san_ass_service_enabled NUMBER(1),
    array_health_check_service_en NUMBER(1),
    san_health_check_service_en NUMBER(1),
    vplex_service_enabled NUMBER(1),
    env_details_information_id NUMBER,
    vnx_clariion_information_id NUMBER,
    data_migration_information_id NUMBER,
    open_replicator_id NUMBER,
    symmetrix_mf_id NUMBER,
    symmetrix_os_id NUMBER,
    vplex_id NUMBER,
    FOREIGN KEY (env_details_information_id) REFERENCES EnvironmentDetailsInformation (id),
    FOREIGN KEY (vnx_clariion_information_id) REFERENCES VnxClariionInformation (id),
    FOREIGN KEY (data_migration_information_id) REFERENCES DataMigrationInformation (id),
    FOREIGN KEY (open_replicator_id) REFERENCES OpenReplicator (id),
    FOREIGN KEY (symmetrix_mf_id) REFERENCES SymmetrixMF (id),
    FOREIGN KEY (symmetrix_os_id) REFERENCES SymmetrixOS (id),
    FOREIGN KEY (vplex_id) REFERENCES Vplex (id)
)
/
CREATE TRIGGER TInfrastructureRequestData
BEFORE INSERT ON InfrastructureRequestData
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SInfrastructureRequestData.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SStringServiceData
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE StringServiceData (
    id NUMBER NOT NULL PRIMARY KEY, 
    service_name VARCHAR2(256),
    description VARCHAR2(256),
    value VARCHAR2(256)
)
/
CREATE TRIGGER TStringServiceData
BEFORE INSERT ON StringServiceData
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SStringServiceData.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SBooleanServiceData
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE BooleanServiceData (
    id NUMBER NOT NULL PRIMARY KEY, 
    service_name VARCHAR2(256),
    description VARCHAR2(256),
    enabled NUMBER(1)
)
/
CREATE TRIGGER TBooleanServiceData
BEFORE INSERT ON BooleanServiceData
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SBooleanServiceData.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SMainframeServicesScope
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE MainframeServicesScope (
    id NUMBER NOT NULL PRIMARY KEY, 
    data_analytics_healthcheck NUMBER(1),
    ezsm_ecc_info_mover NUMBER(1),
    dmx_vmax_data_migration NUMBER(1),
    dmx_vmax_hardware_impl NUMBER(1),
    dmx_vmax_srdf NUMBER(1),
    dmx_vmax_time_finder NUMBER(1),
    dmx_vmax_autoswap_gddr NUMBER(1),
    dlm_data_migration NUMBER(1),
    dlm_healthcheck NUMBER(1),
    dlm_custom_requirements NUMBER(1),
    dlm_implement_upgrade NUMBER(1),
    dlm_reconfigure_add_move NUMBER(1),
    dlm_scripting NUMBER(1),
    dlm_services NUMBER(1),
    dlm_implementation NUMBER(1)
)
/
CREATE TRIGGER TMainframeServicesScope
BEFORE INSERT ON MainframeServicesScope
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SMainframeServicesScope.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SMainframeRequestData
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE MainframeRequestData (
    id NUMBER NOT NULL PRIMARY KEY, 
    general_comment VARCHAR2(256),
    services_scope_id NUMBER,
    FOREIGN KEY (services_scope_id) REFERENCES MainframeServicesScope (id)
)
/
CREATE TRIGGER TMainframeRequestData
BEFORE INSERT ON MainframeRequestData
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SMainframeRequestData.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE TABLE MainframeReqData_booleanSD (
    mainframe_request_data_id NUMBER,
    boolean_service_data_id NUMBER,
    FOREIGN KEY (mainframe_request_data_id) REFERENCES MainframeRequestData (id),
    FOREIGN KEY (boolean_service_data_id) REFERENCES BooleanServiceData (id)
)
/

CREATE TABLE MainframeReqData_stringSD (
    mainframe_request_data_id NUMBER,
    string_service_data_id NUMBER,
    FOREIGN KEY (mainframe_request_data_id) REFERENCES MainframeRequestData (id),
    FOREIGN KEY (string_service_data_id) REFERENCES StringServiceData (id)
)
/

CREATE SEQUENCE SMSSFcAtaDrives
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE MSSFcAtaDrives (
    id NUMBER NOT NULL PRIMARY KEY,
    fc_ata_73gb VARCHAR2(256),
    fc_ata_146gb VARCHAR2(256),
    fc_ata_300gb VARCHAR2(256),
    fc_ata_400gb VARCHAR2(256),
    fc_ata_450gb VARCHAR2(256),
    fc_ata_500gb VARCHAR2(256),
    fc_ata_600gb VARCHAR2(256),
    fc_ata_750gb VARCHAR2(256),
    fc_ata_1tb VARCHAR2(256),
    fc_ata_2tb VARCHAR2(256),
    fc_ata_3tb_4g VARCHAR2(256),
    fc_ata_other VARCHAR2(256)
)
/
CREATE TRIGGER TMSSFcAtaDrives
BEFORE INSERT ON MSSFcAtaDrives
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SMSSFcAtaDrives.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SMSSFlashDrives
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE MSSFlashDrives (
    id NUMBER NOT NULL PRIMARY KEY,
    flash_73gb VARCHAR2(256),
    flash_100gb VARCHAR2(256),
    flash_146gb VARCHAR2(256),
    flash_200gb VARCHAR2(256),
    flash_400gb VARCHAR2(256),
    flash_other VARCHAR2(256)
)
/
CREATE TRIGGER TMSSFlashDrives
BEFORE INSERT ON MSSFlashDrives
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SMSSFlashDrives.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SMSSVnxSasDrives
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE MSSVnxSasDrives (
    id NUMBER NOT NULL PRIMARY KEY,
    vnx_sas_300gb VARCHAR2(256),
    vnx_sas_25_inch_300gb VARCHAR2(256),
    vnx_sas_600gb VARCHAR2(256),
    vnx_sas_25_inch_600gb VARCHAR2(256),
    vnx_sas_25_inch_900gb VARCHAR2(256),
    vnx_sas_35_inch_900gb VARCHAR2(256),
    vnx_sas_1tb VARCHAR2(256),
    vnx_sas_2tb VARCHAR2(256),
    vnx_sas_3tb VARCHAR2(256),
    vnx_sas_100gb_flash VARCHAR2(256),
    vnx_sas_200gb_flash VARCHAR2(256),
    vnx_sas_other VARCHAR2(256)
)
/
CREATE TRIGGER TMSSVnxSasDrives
BEFORE INSERT ON MSSVnxSasDrives
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SMSSVnxSasDrives.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SMSSClariionAx4Drives
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE MSSClariionAx4Drives (
    id NUMBER NOT NULL PRIMARY KEY,
    clariion_ax4_sataii_500gb VARCHAR2(256),
    clariion_ax4_sataii_750gb VARCHAR2(256),
    clariion_ax4_sataii_1000gb VARCHAR2(256),
    clariion_ax4_sas_146gb_15k VARCHAR2(256),
    clariion_ax4_sas_300gb_15k VARCHAR2(256),
    clariion_ax4_sas_400gb_15k VARCHAR2(256),
    clariion_ax4_sas_450gb_10k VARCHAR2(256),
    clariion_ax4_sas_600gb_10k VARCHAR2(256),
    clariion_ax4_other VARCHAR2(256)
)
/
CREATE TRIGGER TMSSClariionAx4Drives
BEFORE INSERT ON MSSClariionAx4Drives
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SMSSClariionAx4Drives.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SMSSCenteraNodes
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE MSSCenteraNodes (
    id NUMBER NOT NULL PRIMARY KEY,
    gen1_nodes_640gb VARCHAR2(256),
    gen2_nodes_1tb VARCHAR2(256),
    gen3_nodes_128tb VARCHAR2(256),
    gen4_nodes_750gb VARCHAR2(256),
    gen4_nodes_128tb VARCHAR2(256),
    gen4_nodes_2tb VARCHAR2(256),
    gen4_lp_nodes_1tb VARCHAR2(256),
    gen4_lp_nodes_2tb VARCHAR2(256),
    centera_nodes_other VARCHAR2(256)
)
/
CREATE TRIGGER TMSSCenteraNodes
BEFORE INSERT ON MSSCenteraNodes
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SMSSCenteraNodes.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SMSSAvamarNodes
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE MSSAvamarNodes (
    id NUMBER NOT NULL PRIMARY KEY,
    storage_nodes_1tb VARCHAR2(256),
    storage_nodes_2tb VARCHAR2(256),
    storage_nodes_33tb VARCHAR2(256),
    utility_nodes_gen1 VARCHAR2(256),
    utility_nodes_gen2_gen3 VARCHAR2(256),
    utility_nodes_gen4 VARCHAR2(256),
    accelerator_nodes_gen1 VARCHAR2(256),
    small_accelerator_nodes_gen2 VARCHAR2(256),
    large_accelerator_nodes_gen2 VARCHAR2(256),
    accelerator_nodes_gen3_gen4 VARCHAR2(256),
    storage_nodes_13tb_gen4 VARCHAR2(256),
    storage_nodes_26tb_gen4 VARCHAR2(256),
    storage_nodes_39tb_gen4 VARCHAR2(256),
    storage_nodes_78tb_gen4 VARCHAR2(256),
    avamar_nodes_other VARCHAR2(256)
)
/
CREATE TRIGGER TMSSAvamarNodes
BEFORE INSERT ON MSSAvamarNodes
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SMSSAvamarNodes.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SMSSDataDomain
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE MSSDataDomain (
    id NUMBER NOT NULL PRIMARY KEY,
    model_type VARCHAR2(256),
    serial_number VARCHAR2(256),
    num_retention_drives INT
)
/
CREATE TRIGGER TMSSDataDomain
BEFORE INSERT ON MSSDataDomain
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SMSSDataDomain.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SMSSAtmos
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE MSSAtmos (
    id NUMBER NOT NULL PRIMARY KEY,
    atmos_25_inch_250gb VARCHAR2(256),
    atmos_1tb VARCHAR2(256),
    atmos_2tb VARCHAR2(256),
    atmos_3tb VARCHAR2(256),
    atmos_other VARCHAR2(256)
)
/
CREATE TRIGGER TMSSAtmos
BEFORE INSERT ON MSSAtmos
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SMSSAtmos.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SMSSGreenplum
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE MSSGreenplum (
    id NUMBER NOT NULL PRIMARY KEY,
    greenplum_25_inch_600gb_10k VARCHAR2(256),
    greenplum_35_inch_600gb_15k VARCHAR2(256),
    greenplum_35_inch_2tb VARCHAR2(256)
)
/
CREATE TRIGGER TMSSGreenplum
BEFORE INSERT ON MSSGreenplum
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SMSSGreenplum.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SMSSArray
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE MSSArray (
    id NUMBER NOT NULL PRIMARY KEY,
    location VARCHAR2(256),
    service_id NUMBER,
    platform_id NUMBER,
    fc_ata_drives_id NUMBER,
    flash_drives_id NUMBER,
    vnx_sas_drives_id NUMBER,
    clariion_ax4_drives_id NUMBER,
    centera_nodes_id NUMBER,
    avamar_nodes_id NUMBER,
    data_domain_id NUMBER,
    atmos_id NUMBER,
    greenplum_id NUMBER,
    FOREIGN KEY (service_id) REFERENCES MSSService (id),
    FOREIGN KEY (platform_id) REFERENCES MSSPlatform (id),
    FOREIGN KEY (fc_ata_drives_id) REFERENCES MSSFcAtaDrives (id),
    FOREIGN KEY (flash_drives_id) REFERENCES MSSFlashDrives (id),
    FOREIGN KEY (vnx_sas_drives_id) REFERENCES MSSVnxSasDrives (id),
    FOREIGN KEY (clariion_ax4_drives_id) REFERENCES MSSClariionAx4Drives (id),
    FOREIGN KEY (centera_nodes_id) REFERENCES MSSCenteraNodes (id),
    FOREIGN KEY (avamar_nodes_id) REFERENCES MSSAvamarNodes (id),
    FOREIGN KEY (atmos_id) REFERENCES MSSAtmos (id),
    FOREIGN KEY (data_domain_id) REFERENCES MSSDataDomain (id),
    FOREIGN KEY (greenplum_id) REFERENCES MSSGreenplum (id)
)
/
CREATE TRIGGER TMSSArray
BEFORE INSERT ON MSSArray
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SMSSArray.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SMSSRequestData
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE MSSRequestData (
    id NUMBER NOT NULL PRIMARY KEY,
    service_scope_description VARCHAR2(256),
    general_comment VARCHAR2(256),
    duration_months_id NUMBER,
    FOREIGN KEY (duration_months_id) REFERENCES DurationMonths (id)
)
/
CREATE TRIGGER TMSSRequestData
BEFORE INSERT ON MSSRequestData
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SMSSRequestData.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE TABLE MSS_array (
    mss_request_data_id NUMBER NOT NULL,
    mss_array_id NUMBER NOT NULL,
    FOREIGN KEY (mss_request_data_id) REFERENCES MSSRequestData (id),
    FOREIGN KEY (mss_array_id) REFERENCES MSSArray (id)
)
/

CREATE SEQUENCE SNASDestination
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE NASDestination (
    id NUMBER NOT NULL PRIMARY KEY,
    celerra NUMBER(1),
    vnx NUMBER(1),
    vnxe NUMBER(1),
    network_appliance NUMBER(1),
    centera NUMBER(1),
    windows NUMBER(1),
    atmos NUMBER(1),
    data_domain NUMBER(1)
)
/
CREATE TRIGGER TNASDestination
BEFORE INSERT ON NASDestination
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SNASDestination.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SCTAImplementationArray
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE CTAImplementationArray (
    id NUMBER NOT NULL PRIMARY KEY,
    location VARCHAR2(256),
    appliance_type_id NUMBER,
    clustered_appliance NUMBER(1),
    clusters_num INT,
    source_file_server_type_id NUMBER,
    source_exports_shares_num INT,
    multi_tier_archiving NUMBER(1),
    multi_tier_sites_num INT,
    security_hardening NUMBER(1),
    nas_destination_id NUMBER,
    archive_policies_num INT,
    migration_policies_num INT,
    capacity_management NUMBER(1),
    FOREIGN KEY (appliance_type_id) REFERENCES CTAApplianceType (id),
    FOREIGN KEY (source_file_server_type_id) REFERENCES CTASourceFileServerType (id),
    FOREIGN KEY (nas_destination_id) REFERENCES NASDestination (id)
)
/
CREATE TRIGGER TCTAImplementationArray
BEFORE INSERT ON CTAImplementationArray
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SCTAImplementationArray.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SCTAImplementation
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE CTAImplementation (
    id NUMBER NOT NULL PRIMARY KEY,
    customer_expectations VARCHAR2(256)
)
/
CREATE TRIGGER TCTAImplementation
BEFORE INSERT ON CTAImplementation
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SCTAImplementation.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE TABLE CTAImplementation_array (
    cta_implementation_id NUMBER NOT NULL,
    cta_implementation_array_id NUMBER NOT NULL,
    FOREIGN KEY (cta_implementation_id) REFERENCES CTAImplementation (id),
    FOREIGN KEY (cta_implementation_array_id) REFERENCES CTAImplementationArray (id)
)
/

CREATE SEQUENCE SCTAConversion
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE CTAConversion (
    id NUMBER NOT NULL PRIMARY KEY,
    conversation_type INT,
    cloud_tiering_appliance_num INT,
    file_servers_num INT,
    management_sites_num INT,
    files_converted_num INT,
    file_archivers_num INT,
    cfa_records_num INT,
    monitoring_method INT
)
/
CREATE TRIGGER TCTAConversion
BEFORE INSERT ON CTAConversion
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SCTAConversion.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SCTARaininfinity
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE CTARaininfinity (
    id NUMBER NOT NULL PRIMARY KEY,
    include_clustered_deployment NUMBER(1),
    hardware_conversion NUMBER(1),
    mstp NUMBER(1),
    cross_functional_migration NUMBER(1),
    billable_hours_num DECIMAL(20, 2),
    appliances_deployed_num INT,
    file_servers_num INT,
    file_systems_num INT,
    include_sid NUMBER(1),
    local_user_objects_num INT,
    include_windows_proxy NUMBER(1),
    include_remote_migration NUMBER(1),
    rainfinity_appliances_num INT,
    rainfinity_vlans_num INT,
    domains_num INT,
    switch_config_required NUMBER(1),
    include_local_migration NUMBER(1),
    migrate_data_amount INT
)
/
CREATE TRIGGER TCTARaininfinity
BEFORE INSERT ON CTARaininfinity
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SCTARaininfinity.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SCTAServicesScope
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE CTAServicesScope (
    id NUMBER NOT NULL PRIMARY KEY, 
    cta_design_and_implementation NUMBER(1),
    cta_implementation NUMBER(1),
    cta_conversion NUMBER(1),
    rainfinity_design_and_impl NUMBER(1)
)
/
CREATE TRIGGER TCTAServicesScope
BEFORE INSERT ON CTAServicesScope
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SCTAServicesScope.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SCTARequestData
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE CTARequestData (
    id NUMBER NOT NULL PRIMARY KEY,
    services_scope_id NUMBER,
    implementation_id NUMBER,
    conversion_id NUMBER,
    raininfinity_id NUMBER,
    sites_involved_id NUMBER,
    days_of_knowledge_transfer DECIMAL(20, 2),
    general_comment VARCHAR2(256),
    FOREIGN KEY (services_scope_id) REFERENCES CTAServicesScope (id),
    FOREIGN KEY (implementation_id) REFERENCES CTAImplementation (id),
    FOREIGN KEY (conversion_id) REFERENCES CTAConversion (id),
    FOREIGN KEY (raininfinity_id) REFERENCES CTARaininfinity (id),
    FOREIGN KEY (sites_involved_id) REFERENCES SitesInvolved (id)
)
/
CREATE TRIGGER TCTARequestData
BEFORE INSERT ON CTARequestData
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SCTARequestData.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SRoleSkillLevel
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE RoleSkillLevel (
    id NUMBER NOT NULL PRIMARY KEY,
    roll_skill_name VARCHAR2(256),
    time_period VARCHAR2(256),
    quantity DECIMAL(20, 2),
    additional_info VARCHAR2(256)
)
/
CREATE TRIGGER TRoleSkillLevel
BEFORE INSERT ON RoleSkillLevel
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SRoleSkillLevel.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SResidencyRoleSkillLevels
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE ResidencyRoleSkillLevels (
    id NUMBER NOT NULL PRIMARY KEY,
    special_handling_instructions VARCHAR2(256)
)
/
CREATE TRIGGER TResidencyRoleSkillLevels
BEFORE INSERT ON ResidencyRoleSkillLevels
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SResidencyRoleSkillLevels.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE TABLE ResRoleSkillLevels_backupL (
    res_role_skill_levels_id NUMBER NOT NULL,
    role_skill_level_id NUMBER NOT NULL,
    FOREIGN KEY (res_role_skill_levels_id) REFERENCES ResidencyRoleSkillLevels (id),
    FOREIGN KEY (role_skill_level_id) REFERENCES RoleSkillLevel (id)
)
/

CREATE TABLE ResRoleSkillLevels_projectL (
    res_role_skill_levels_id NUMBER NOT NULL,
    role_skill_level_id NUMBER NOT NULL,
    FOREIGN KEY (res_role_skill_levels_id) REFERENCES ResidencyRoleSkillLevels (id),
    FOREIGN KEY (role_skill_level_id) REFERENCES RoleSkillLevel (id)
)
/

CREATE TABLE ResRoleSkillLevels_adminL (
    res_role_skill_levels_id NUMBER NOT NULL,
    role_skill_level_id NUMBER NOT NULL,
    FOREIGN KEY (res_role_skill_levels_id) REFERENCES ResidencyRoleSkillLevels (id),
    FOREIGN KEY (role_skill_level_id) REFERENCES RoleSkillLevel (id)
)
/

CREATE TABLE ResRoleSkillLevels_storageL (
    res_role_skill_levels_id NUMBER NOT NULL,
    role_skill_level_id NUMBER NOT NULL,
    FOREIGN KEY (res_role_skill_levels_id) REFERENCES ResidencyRoleSkillLevels (id),
    FOREIGN KEY (role_skill_level_id) REFERENCES RoleSkillLevel (id)
)
/

CREATE TABLE ResRoleSkillLevels_supportL (
    res_role_skill_levels_id NUMBER NOT NULL,
    role_skill_level_id NUMBER NOT NULL,
    FOREIGN KEY (res_role_skill_levels_id) REFERENCES ResidencyRoleSkillLevels (id),
    FOREIGN KEY (role_skill_level_id) REFERENCES RoleSkillLevel (id)
)
/

CREATE TABLE ResRoleSkillLevels_vmwareL (
    res_role_skill_levels_id NUMBER NOT NULL,
    role_skill_level_id NUMBER NOT NULL,
    FOREIGN KEY (res_role_skill_levels_id) REFERENCES ResidencyRoleSkillLevels (id),
    FOREIGN KEY (role_skill_level_id) REFERENCES RoleSkillLevel (id)
)
/

CREATE TABLE ResRoleSkillLevels_archive (
  res_role_skill_levels_id NUMBER NOT NULL,
  role_skill_level_id NUMBER NOT NULL,
  FOREIGN KEY (res_role_skill_levels_id) REFERENCES ResidencyRoleSkillLevels (id),
  FOREIGN KEY (role_skill_level_id) REFERENCES RoleSkillLevel (id)
)
/
CREATE TABLE ResRoleSkillLevels_cloud (
  res_role_skill_levels_id NUMBER NOT NULL,
  role_skill_level_id NUMBER NOT NULL,
  FOREIGN KEY (res_role_skill_levels_id) REFERENCES ResidencyRoleSkillLevels (id),
  FOREIGN KEY (role_skill_level_id) REFERENCES RoleSkillLevel (id)
)
/
CREATE TABLE ResRoleSkillLevels_dataWH (
  res_role_skill_levels_id NUMBER NOT NULL,
  role_skill_level_id NUMBER NOT NULL,
  FOREIGN KEY (res_role_skill_levels_id) REFERENCES ResidencyRoleSkillLevels (id),
  FOREIGN KEY (role_skill_level_id) REFERENCES RoleSkillLevel (id)
)
/
CREATE TABLE ResRoleSkillLevels_isilon (
  res_role_skill_levels_id NUMBER NOT NULL,
  role_skill_level_id NUMBER NOT NULL,
  FOREIGN KEY (res_role_skill_levels_id) REFERENCES ResidencyRoleSkillLevels (id),
  FOREIGN KEY (role_skill_level_id) REFERENCES RoleSkillLevel (id)
)
/
CREATE TABLE ResRoleSkillLevels_storageMgmt (
  res_role_skill_levels_id NUMBER NOT NULL,
  role_skill_level_id NUMBER NOT NULL,
  FOREIGN KEY (res_role_skill_levels_id) REFERENCES ResidencyRoleSkillLevels (id),
  FOREIGN KEY (role_skill_level_id) REFERENCES RoleSkillLevel (id)
)
/
CREATE TABLE ResRoleSkillLevels_vblock (
  res_role_skill_levels_id NUMBER NOT NULL,
  role_skill_level_id NUMBER NOT NULL,
  FOREIGN KEY (res_role_skill_levels_id) REFERENCES ResidencyRoleSkillLevels (id),
  FOREIGN KEY (role_skill_level_id) REFERENCES RoleSkillLevel (id)
)
/
CREATE TABLE ResRoleSkillLevels_virtXtreme (
  res_role_skill_levels_id NUMBER NOT NULL,
  role_skill_level_id NUMBER NOT NULL,
  FOREIGN KEY (res_role_skill_levels_id) REFERENCES ResidencyRoleSkillLevels (id),
  FOREIGN KEY (role_skill_level_id) REFERENCES RoleSkillLevel (id)
)
/

CREATE SEQUENCE SResidencyRequestData
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE ResidencyRequestData (
    id NUMBER NOT NULL PRIMARY KEY,
    payment_type_id NUMBER,
    location VARCHAR2(256),
    special_conditions VARCHAR2(256),
    work_start_day_id NUMBER,
    work_end_day_id NUMBER,
    approximate_start_date DATE,
    work_hours_num DECIMAL(20, 2),
    general_comment VARCHAR2(256),
    role_skill_levels_id NUMBER,
    FOREIGN KEY (payment_type_id) REFERENCES ResidencyPaymentType (id),
    FOREIGN KEY (work_start_day_id) REFERENCES WeekDay (id),
    FOREIGN KEY (work_end_day_id) REFERENCES WeekDay (id),
    FOREIGN KEY (role_skill_levels_id) REFERENCES ResidencyRoleSkillLevels (id)
)
/
CREATE TRIGGER TResidencyRequestData
BEFORE INSERT ON ResidencyRequestData
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SResidencyRequestData.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SSourceOneFeatures
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE SourceOneFeatures (
    id NUMBER NOT NULL PRIMARY KEY,
    email_archiving NUMBER(1),
    discovery_manager NUMBER(1),
    share_point_archiving NUMBER(1),
    file_archiving NUMBER(1),
    email_supervisor NUMBER(1),
    share_point_storage_managment NUMBER(1),
    cloud_tiering_app_mgmt NUMBER(1)
)
/
CREATE TRIGGER TSourceOneFeatures
BEFORE INSERT ON SourceOneFeatures
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SSourceOneFeatures.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SSourceOneDROptions
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE SourceOneDROptions (
    id NUMBER NOT NULL PRIMARY KEY,
    full_dr NUMBER(1),
    dr_planning NUMBER(1),
    dr_testing NUMBER(1)
)
/
CREATE TRIGGER TSourceOneDROptions
BEFORE INSERT ON SourceOneDROptions
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SSourceOneDROptions.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SSourceOneDesignImpl
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE SourceOneDesignImpl (
    id NUMBER NOT NULL PRIMARY KEY,
    knowledge_transfer_hours DECIMAL(20, 2),
    mailboxes_num INT,
    include_piolt NUMBER(1),
    include_meeting NUMBER(1),
    features_id NUMBER,
    dr_options_id NUMBER,
    include_validation_sizing NUMBER(1),
    include_shortcut_email NUMBER(1),
    include_shortcut_file_archive NUMBER(1),
    include_lexicon_query NUMBER(1),
    supervised_users_num INT,
    master_servers_num INT,
    email_mgmt_servers_num INT,
    sharepoint_arch_servers_num INT,
    file_archiving_servers_num INT,
    mgmt_consoles_num INT,
    mapped_folders_num INT,
    email_archive_policies_num INT,
    file_archive_policies_num INT,
    dis_manager_admin_console_num INT,
    dis_manager_client_num INT,
    hold_folders_num INT,
    sample_matter_num INT,
    legal_hold_folders_num INT,
    archive_sharepoint_farms_num INT,
    stor_mgmt_share_farms_num INT,
    file_arch_mapped_folders_num INT,
    file_arch_pol_to_be_conf_num INT,
    cloud_tiering_appliances_num INT,
    reviewer_clients_num INT,
    FOREIGN KEY (features_id) REFERENCES SourceOneFeatures (id),
    FOREIGN KEY (dr_options_id) REFERENCES SourceOneDROptions (id)
)
/
CREATE TRIGGER TSourceOneDesignImpl
BEFORE INSERT ON SourceOneDesignImpl
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SSourceOneDesignImpl.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SSourceOneUpgrade
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE SourceOneUpgrade (
    id NUMBER NOT NULL PRIMARY KEY,
    knowledge_transfer_hours DECIMAL(20, 2),
    current_version VARCHAR2(256),
    upgrade_version VARCHAR2(256),
    master_servers_num INT,
    worker_servers_num INT,
    billable_hours_num INT
)
/
CREATE TRIGGER TSourceOneUpgrade
BEFORE INSERT ON SourceOneUpgrade
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SSourceOneUpgrade.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SSourceOneMigration
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE SourceOneMigration (
    id NUMBER NOT NULL PRIMARY KEY,
    knowledge_transfer_hours DECIMAL(20, 2),
    email_xtender_servers_num INT,
    migrated_size INT,
    billable_hours_num INT
)
/
CREATE TRIGGER TSourceOneMigration
BEFORE INSERT ON SourceOneMigration
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SSourceOneMigration.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SSourceOneHealthCheck
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE SourceOneHealthCheck (
    id NUMBER NOT NULL PRIMARY KEY,
    knowledge_transfer_hours DECIMAL(20, 2),
    servers_num INT,
    assessment_interviews_num INT,
    master_servers_num INT,
    worker_servers_num INT
)
/
CREATE TRIGGER TSourceOneHealthCheck
BEFORE INSERT ON SourceOneHealthCheck
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SSourceOneHealthCheck.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SSourceOneServicesScope
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE SourceOneServicesScope (
    id NUMBER NOT NULL PRIMARY KEY,
    design_and_impl NUMBER(1),
    upgrade NUMBER(1),
    migration NUMBER(1),
    health_check NUMBER(1)
)
/
CREATE TRIGGER TSourceOneServicesScope
BEFORE INSERT ON SourceOneServicesScope
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SSourceOneServicesScope.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SSourceOneRequestData
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE SourceOneRequestData (
    id NUMBER NOT NULL PRIMARY KEY,
    services_scope_id NUMBER,
    design_impl_id NUMBER,
    upgrade_id NUMBER,
    migration_id NUMBER,
    health_check_id NUMBER,
    sites_involved_num INT,
    general_comment VARCHAR2(256),
    FOREIGN KEY (services_scope_id) REFERENCES SourceOneServicesScope (id),
    FOREIGN KEY (design_impl_id) REFERENCES SourceOneDesignImpl (id),
    FOREIGN KEY (upgrade_id) REFERENCES SourceOneUpgrade (id),
    FOREIGN KEY (migration_id) REFERENCES SourceOneMigration (id),
    FOREIGN KEY (health_check_id) REFERENCES SourceOneHealthCheck (id)
)
/
CREATE TRIGGER TSourceOneRequestData
BEFORE INSERT ON SourceOneRequestData
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SSourceOneRequestData.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SASDAppSync
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE ASDAppSync (
    id NUMBER NOT NULL PRIMARY KEY,
    install_vsi NUMBER(1),
    app_sync_instances_num INT,
    vcenter_servers_num INT,
    app_production_hosts_num INT,
    vnx_arrays_num INT,
    application_mount_hosts_num INT,
    recover_point_appliances_num INT,
    knowledge_transfer_hours DECIMAL(20,2)
)
/
CREATE TRIGGER TASDAppSync
BEFORE INSERT ON ASDAppSync
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SASDAppSync.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SASDUIM
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE ASDUIM (
    id NUMBER NOT NULL PRIMARY KEY,
    install_type_id NUMBER,
    upgrade_type_id NUMBER,
    include_remote_install_agent NUMBER(1),
    remote_install_agents_num INT,
    uim_provisioning_vapps_num INT,
    isolation_zones_num INT,
    include_vco NUMBER(1),
    vcenter_instances_num INT,
    uim_provisioning_servers_num INT,
    vcloud_director_instances_num INT,
    conv_hardware_systems_num INT,
    blade_storage_grades_num INT,
    identity_pools_num INT,
    network_profiles_num INT,
    uim_operations_vapps_num INT,
    service_offer_to_create_num INT,
    services_to_create_num INT,
    blades_to_provision_num INT,
    luns_to_provision_num INT,
    services_to_provision_num INT,
    data_sources_num INT,
    snmp_alerts_num INT,
    uim_operations_servers_num INT,
    uim_operations_users_num INT,
    perform_elastic_provisioning NUMBER(1),
    services_req_elastic_ops_num INT,
    blades_impacted_num INT,
    migrate_services NUMBER(1),
    non_uim_conv_hardware_sys_num INT,
    services_adopted_migrated_num INT,
    blades_adopted_migrated_num INT,
    customer_known NUMBER(1),
    remediate_hours DECIMAL(20,2),
    sa_knowledge_transfer_hours DECIMAL(20,2),
    is_knowledge_transfer_hours DECIMAL(20,2)
)
/
CREATE TRIGGER TASDUIM
BEFORE INSERT ON ASDUIM
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SASDUIM.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SASDServicesScope
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE ASDServicesScope (
    id NUMBER NOT NULL PRIMARY KEY,
    ncm NUMBER(1),
    app_sync NUMBER(1),
    uim NUMBER(1)
)
/
CREATE TRIGGER TASDServicesScope
BEFORE INSERT ON ASDServicesScope
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SASDServicesScope.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SASDRequestData
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE ASDRequestData (
    id NUMBER NOT NULL PRIMARY KEY,
    services_scope_id NUMBER,
    app_sync_id NUMBER,
    uim_id NUMBER,
    general_comment VARCHAR2(256),
    FOREIGN KEY (services_scope_id) REFERENCES ASDServicesScope (id),
    FOREIGN KEY (app_sync_id) REFERENCES ASDAppSync (id),
    FOREIGN KEY (uim_id) REFERENCES ASDUIM (id)
)
/
CREATE TRIGGER TASDRequestData
BEFORE INSERT ON ASDRequestData
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SASDRequestData.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SHealthCheckAvamar
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE HealthCheckAvamar (
    id NUMBER NOT NULL PRIMARY KEY,
    avamar_grids_num INT,
    assessment_interviews_num INT
)
/
CREATE TRIGGER THealthCheckAvamar
BEFORE INSERT ON HealthCheckAvamar
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SHealthCheckAvamar.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SHealthCheckDataDomain
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE HealthCheckDataDomain (
    id NUMBER NOT NULL PRIMARY KEY,
    appliances_num INT,
    assessment_interviews_num INT
)
/
CREATE TRIGGER THealthCheckDataDomain
BEFORE INSERT ON HealthCheckDataDomain
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SHealthCheckDataDomain.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SHealthCheckDPA
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE HealthCheckDPA (
    id NUMBER NOT NULL PRIMARY KEY,
    site_implementations_num INT
)
/
CREATE TRIGGER THealthCheckDPA
BEFORE INSERT ON HealthCheckDPA
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SHealthCheckDPA.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SHealthCheckDLM
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE HealthCheckDLM (
    id NUMBER NOT NULL PRIMARY KEY,
    dlm_subsystem_num INT,
    storage_amount INT
)
/
CREATE TRIGGER THealthCheckDLM
BEFORE INSERT ON HealthCheckDLM
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SHealthCheckDLM.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SHealthCheckGreenPlum
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE HealthCheckGreenPlum (
    id NUMBER NOT NULL PRIMARY KEY,
    master_host_servers_num INT
)
/
CREATE TRIGGER THealthCheckGreenPlum
BEFORE INSERT ON HealthCheckGreenPlum
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SHealthCheckGreenPlum.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SHealthCheckIonix
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE HealthCheckIonix (
    id NUMBER NOT NULL PRIMARY KEY,
    incl_exe_summary_presentation NUMBER(1),
    size_environment INT
)
/
CREATE TRIGGER THealthCheckIonix
BEFORE INSERT ON HealthCheckIonix
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SHealthCheckIonix.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SHealthCheckNetWorker
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE HealthCheckNetWorker (
    id NUMBER NOT NULL PRIMARY KEY,
    include_emc_assessment NUMBER(1),
    data_zones_num INT,
    assessment_interviews_num INT
)
/
CREATE TRIGGER THealthCheckNetWorker
BEFORE INSERT ON HealthCheckNetWorker
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SHealthCheckNetWorker.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SHealthCheckSanSecurity
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE HealthCheckSanSecurity (
    id NUMBER NOT NULL PRIMARY KEY,
    assessment_interviews_num INT,
    assessed_sites_num INT,
    emc_storage_arrays_num INT,
    san_attached_hosts_num INT,
    storage_mgmt_stations_num INT
)
/
CREATE TRIGGER THealthCheckSanSecurity
BEFORE INSERT ON HealthCheckSanSecurity
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SHealthCheckSanSecurity.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SHealthCheckSAP
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE HealthCheckSAP (
    id NUMBER NOT NULL PRIMARY KEY,
    dlm_subsystem_num INT,
    storage_amount INT
)
/
CREATE TRIGGER THealthCheckSAP
BEFORE INSERT ON HealthCheckSAP
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SHealthCheckSAP.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SHealthCheckSourceOne
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE HealthCheckSourceOne (
    id NUMBER NOT NULL PRIMARY KEY,
    servers_num INT,
    assessment_interviews_num INT
)
/
CREATE TRIGGER THealthCheckSourceOne
BEFORE INSERT ON HealthCheckSourceOne
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SHealthCheckSourceOne.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SHealthCheckSymmetrixVmax
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE HealthCheckSymmetrixVmax (
    id NUMBER NOT NULL PRIMARY KEY,
    events_sold_num INT,
    dmx_vmax_arrays_num INT
)
/
CREATE TRIGGER THealthCheckSymmetrixVmax
BEFORE INSERT ON HealthCheckSymmetrixVmax
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SHealthCheckSymmetrixVmax.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SHealthCheckSymVmaxStorageRep
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE HealthCheckSymVmaxStorageRep (
    id NUMBER NOT NULL PRIMARY KEY,
    include_final_report NUMBER(1),
    incl_exec_summ_review_pres NUMBER(1),
    assessment_interviews_num INT,
    consistency_groups_num INT,
    symmetrix_arrays_num INT,
    open_systems_hosts_num INT,
    logical_devices_num INT
)
/
CREATE TRIGGER THealthCheckSymVmaxStorageRep
BEFORE INSERT ON HealthCheckSymVmaxStorageRep
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SHealthCheckSymVmaxStorageRep.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SHealthCheckUnified
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE HealthCheckUnified (
    id NUMBER NOT NULL PRIMARY KEY,
    health_check_type_id NUMBER,
    events_sold_num INT,
    file_arrays_num INT,
    block_arrays_num INT,
    FOREIGN KEY (health_check_type_id) REFERENCES UnifiedHealthCheckType (id)
)
/
CREATE TRIGGER THealthCheckUnified
BEFORE INSERT ON HealthCheckUnified
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SHealthCheckUnified.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SHealthCheckVblock
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE HealthCheckVblock (
    id NUMBER NOT NULL PRIMARY KEY,
    incl_interoperability_check NUMBER(1),
    include_performance_check NUMBER(1),
    include_capacity_analysis NUMBER(1),
    include_flare_software_update NUMBER(1),
    block_arrays_num INT,
    san_switches_num INT,
    san_hosts_num INT
)
/
CREATE TRIGGER THealthCheckVblock
BEFORE INSERT ON HealthCheckVblock
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SHealthCheckVblock.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SHealthCheckVmwareVirtualInf
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE HealthCheckVmwareVirtualInf (
    id NUMBER NOT NULL PRIMARY KEY,
    incl_executive_summary_review NUMBER(1),
    assessment_interviews_num INT,
    esx_servers_num INT,
    virtual_hosts_num INT
)
/
CREATE TRIGGER THealthCheckVmwareVirtualInf
BEFORE INSERT ON HealthCheckVmwareVirtualInf
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SHealthCheckVmwareVirtualInf.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SHealthCheckVplex
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE HealthCheckVplex (
    id NUMBER NOT NULL PRIMARY KEY,
    clusters_reviewed_num INT,
    events_sold_num INT
)
/
CREATE TRIGGER THealthCheckVplex
BEFORE INSERT ON HealthCheckVplex
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SHealthCheckVplex.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SHealthCheckServicesScope
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE HealthCheckServicesScope (
    id NUMBER NOT NULL PRIMARY KEY,
    avamar NUMBER(1),
    data_domain NUMBER(1),
    dpa NUMBER(1),
    dlm NUMBER(1),
    greenplum NUMBER(1),
    ionix NUMBER(1),
    net_worker NUMBER(1),
    san_security NUMBER(1),
    sap NUMBER(1),
    source_one NUMBER(1),
    symmetrix_vmax NUMBER(1),
    symmetrix_vmax_storage_repl NUMBER(1),
    unified NUMBER(1),
    vblock NUMBER(1),
    vmware_virtual_infrastructure NUMBER(1),
    vplex NUMBER(1)
)
/
CREATE TRIGGER THealthCheckServicesScope
BEFORE INSERT ON HealthCheckServicesScope
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SHealthCheckServicesScope.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SHealthCheckRequestData
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE HealthCheckRequestData (
    id NUMBER NOT NULL PRIMARY KEY,
    services_scope_id NUMBER,
    avamar_id NUMBER,
    data_domain_id NUMBER,
    dpa_id NUMBER,
    dlm_id NUMBER,
    greenplum_id NUMBER,
    ionix_id NUMBER,
    net_worker_id NUMBER,
    san_security_id NUMBER,
    sap_id NUMBER,
    source_one_id NUMBER,
    symmetrix_vmax_id NUMBER,
    symmetrix_vmax_stor_repl_id NUMBER,
    unified_id NUMBER,
    vblock_id NUMBER,
    vmware_virtual_infra_id NUMBER,
    vplex_id NUMBER,
    general_comment VARCHAR2(256),
    FOREIGN KEY (services_scope_id) REFERENCES HealthCheckServicesScope (id),
    FOREIGN KEY (avamar_id) REFERENCES HealthCheckAvamar (id),
    FOREIGN KEY (data_domain_id) REFERENCES HealthCheckDataDomain (id),
    FOREIGN KEY (dpa_id) REFERENCES HealthCheckDPA (id),
    FOREIGN KEY (dlm_id) REFERENCES HealthCheckDLM (id),
    FOREIGN KEY (greenplum_id) REFERENCES HealthCheckGreenPlum (id),
    FOREIGN KEY (ionix_id) REFERENCES HealthCheckIonix (id),
    FOREIGN KEY (net_worker_id) REFERENCES HealthCheckNetWorker (id),
    FOREIGN KEY (san_security_id) REFERENCES HealthCheckSanSecurity (id),
    FOREIGN KEY (sap_id) REFERENCES HealthCheckSAP (id),
    FOREIGN KEY (source_one_id) REFERENCES HealthCheckSourceOne (id),
    FOREIGN KEY (symmetrix_vmax_id) REFERENCES HealthCheckSymmetrixVmax (id),
    FOREIGN KEY (symmetrix_vmax_stor_repl_id) REFERENCES HealthCheckSymVmaxStorageRep (id),
    FOREIGN KEY (unified_id) REFERENCES HealthCheckUnified (id),
    FOREIGN KEY (vblock_id) REFERENCES HealthCheckVblock (id),
    FOREIGN KEY (vmware_virtual_infra_id) REFERENCES HealthCheckVmwareVirtualInf (id),
    FOREIGN KEY (vplex_id) REFERENCES HealthCheckVplex (id)
)
/
CREATE TRIGGER THealthCheckRequestData
BEFORE INSERT ON HealthCheckRequestData
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SHealthCheckRequestData.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SIsilonClusterRelocation
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE IsilonClusterRelocation (
    id NUMBER NOT NULL PRIMARY KEY,
    isilon_12uservers_num INT,
    isilon_4uservers_num INT,
    infiniband_switches_num INT,
    infiniband_chassis_num INT
)
/
CREATE TRIGGER TIsilonClusterRelocation
BEFORE INSERT ON IsilonClusterRelocation
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SIsilonClusterRelocation.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SIsilonDesignAndImpl
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE IsilonDesignAndImpl (
    id NUMBER NOT NULL PRIMARY KEY,
    install_hardware NUMBER(1),
    include_tech_refresh NUMBER(1),
    new_cluster NUMBER(1),
    subnets_num INT,
    smart_connect_zones_num INT,
    auth_methods_num INT,
    shares_exports_num INT,
    smart_quotas_num INT,
    snapshots_iqentries_num INT,
    include_email NUMBER(1),
    include_subnet NUMBER(1),
    include_advice NUMBER(1),
    include_smart_connect NUMBER(1),
    include_auth NUMBER(1),
    include_file_system_shares NUMBER(1),
    install_insight_iq NUMBER(1),
    include_smart_quotas NUMBER(1),
    include_snapshots NUMBER(1),
    include_ndmp NUMBER(1),
    include_smart_lock NUMBER(1),
    include_1u_switch_install NUMBER(1),
    include_4u_chassis_install NUMBER(1),
    include_12u_node_install NUMBER(1),
    include_4u_node_install NUMBER(1)
)
/
CREATE TRIGGER TIsilonDesignAndImpl
BEFORE INSERT ON IsilonDesignAndImpl
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SIsilonDesignAndImpl.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SIsilonMigration
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE IsilonMigration (
    id NUMBER NOT NULL PRIMARY KEY,
    net_app_3rd_party_migration NUMBER(1),
    celerra_unified_file NUMBER(1),
    sync_iq NUMBER(1),
    tech_refresh NUMBER(1),
    plan_and_design NUMBER(1),
    impl_and_migration NUMBER(1),
    additional_testing NUMBER(1),
    additional_monitoring NUMBER(1),
    scripting_work NUMBER(1),
    install_isilon_hardware NUMBER(1),
    cifs NUMBER(1),
    nfs NUMBER(1),
    multi_protocol NUMBER(1),
    cifs_data_amount INT,
    include_local_users_groups NUMBER(1),
    nfs_data_amount INT,
    multi_protocol_data_amount INT,
    average_duration DECIMAL(20,2),
    data_mig_events_num INT,
    monitor_weeks_num INT,
    cutover_events_num INT,
    smart_pools_enabled NUMBER(1),
    remove_nodes_num INT,
    required_events_num INT,
    tech_refresh_moved_data INT
)
/
CREATE TRIGGER TIsilonMigration
BEFORE INSERT ON IsilonMigration
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SIsilonMigration.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SIsilonHardwareUpgrade
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE IsilonHardwareUpgrade (
    id NUMBER NOT NULL PRIMARY KEY,
    perform_config NUMBER(1),
    nodes_num INT
)
/
CREATE TRIGGER TIsilonHardwareUpgrade
BEFORE INSERT ON IsilonHardwareUpgrade
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SIsilonHardwareUpgrade.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SIsilonServicesScope
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE IsilonServicesScope (
    id NUMBER NOT NULL PRIMARY KEY,
    cluster_relocation NUMBER(1),
    hardware_upgrade NUMBER(1),
    migration NUMBER(1),
    design_and_impl NUMBER(1),
    config_assurance NUMBER(1)
)
/
CREATE TRIGGER TIsilonServicesScope
BEFORE INSERT ON IsilonServicesScope
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SIsilonServicesScope.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SIsilonRequestData
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE IsilonRequestData (
    id NUMBER NOT NULL PRIMARY KEY,
    knowledge_transfer_hours DECIMAL(20,2),
    general_comment VARCHAR2(256),
    services_scope_id NUMBER,
    cluster_relocation_id NUMBER,
    hardware_upgrade_id NUMBER,
    migration_id NUMBER,
    design_and_impl_id NUMBER,
    FOREIGN KEY (services_scope_id) REFERENCES IsilonServicesScope (id),
    FOREIGN KEY (cluster_relocation_id) REFERENCES IsilonClusterRelocation (id),
    FOREIGN KEY (hardware_upgrade_id) REFERENCES IsilonHardwareUpgrade (id),
    FOREIGN KEY (migration_id) REFERENCES IsilonMigration (id),
    FOREIGN KEY (design_and_impl_id) REFERENCES IsilonDesignAndImpl (id)
)
/
CREATE TRIGGER TIsilonRequestData
BEFORE INSERT ON IsilonRequestData
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SIsilonRequestData.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SViprImplementation
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE ViprImplementation (
    id NUMBER NOT NULL PRIMARY KEY,
    new_impl_type NUMBER(1),
    controller_instances_num INT,
    include_data_services NUMBER(1),
    include_ldap NUMBER(1),
    watch_4net_exist NUMBER(1),
    include_block_services NUMBER(1),
    include_vcops NUMBER(1),
    include_vco NUMBER(1),
    include_vcac NUMBER(1),
    include_scvmm NUMBER(1),
    include_vsi NUMBER(1),
    unix_hosts_num INT,
    windows_hosts_num INT,
    v_center_hosts_num INT,
    file_only_arrays_num INT,
    block_arrays_num INT,
    vplex_arrays_num INT,
    recover_point_systems_num INT,
    cisco_switch_fabrics_num INT,
    brocade_switch_fabrics_num INT,
    virtual_arrays_num INT,
    catalog_services_num INT,
    user_roles_num INT,
    ds_buckets_num INT,
    ds_pools_num INT,
    data_stores_num INT,
    ds_ingestions_num INT,
    hadoop_clusters_num INT,
    hadoop_nodes_num INT,
    include_hdfs NUMBER(1),
    include_kerberos_auth NUMBER(1),
    sa_knowledge_transfer_hours DECIMAL(20,2),
    include_vipr_content_address NUMBER(1),
    include_vipr_sofwtare_install NUMBER(1),
    tenants_defined_num INT,
    openstack_cinder_arrays_num INT,
    scaleio_protection_domains_num INT,
    block_file_virtual_pools_num INT,
    projects_num INT,
    additional_hours DECIMAL(20,2)
)
/
CREATE TRIGGER TViprImplementation
BEFORE INSERT ON ViprImplementation
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SViprImplementation.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SHostBasedMigrationTool
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE
/
CREATE TABLE HostBasedMigrationTool (
    id NUMBER NOT NULL PRIMARY KEY, 
    name VARCHAR2(256)
)
/

CREATE SEQUENCE SXtremeHostBasedMigrationTool
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE
/
CREATE TABLE XtremeHostBasedMigrationTool (
    id NUMBER NOT NULL PRIMARY KEY, 
    name VARCHAR2(256)
)
/

CREATE SEQUENCE SECSApplianceDesignImpl
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE
/
CREATE TABLE ECSApplianceDesignImpl (
    id NUMBER NOT NULL PRIMARY KEY,
    include_data_services_for_hdfs NUMBER(1),
    include_integration_ad_ldap NUMBER(1),
    include_kerberos_auth_mode NUMBER(1),
    include_vipr_content_address NUMBER(1),
    watch4net_platform_exists NUMBER(1),
    ecs_systems_with_block_num INT,
    ecs_unstructured_systems_num INT,
    tenants_defined_num INT,
    hadoop_clusters_num INT,
    total_hadoop_cluster_nodes_num INT,
    virtual_arrays_num INT,
    block_virtual_pools_num INT,
    object_virtual_pools_num INT,
    projects_num INT,
    data_service_buckets_num INT,
    user_roles_defined_num INT,
    catalog_services_customize_num INT,
    cas_required_num INT
)
/

CREATE SEQUENCE SViprDataServiceCommodity
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE
/
CREATE TABLE ViprDataServiceCommodity (
    id NUMBER NOT NULL PRIMARY KEY,
    include_data_services_for_hdfs NUMBER(1),
    include_integration_ad_ldap NUMBER(1),
    include_kerberos_auth_mode NUMBER(1),
    include_vipr_content_address NUMBER(1),
    watch4net_platform_exists NUMBER(1),
    commodity_storage_systems_num INT,
    tenants_defined_num INT,
    hadoop_clusters_num INT,
    total_hadoop_cluster_nodes_num INT,
    virtual_arrays_num INT,
    object_virtual_pools_num INT,
    projects_num INT,
    user_roles_defined_num INT,
    catalog_services_customize_num INT,
    cas_required_num INT
)
/

CREATE SEQUENCE SViprDataMigrationPPMEDesign
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE
/
CREATE TABLE ViprDataMigrationPPMEDesign (
    id NUMBER NOT NULL PRIMARY KEY,
    total_source_target_sites_num INT,
    new_physical_hosts_num INT,
    new_esx_servers_num INT,
    new_enterprise_directors_num INT,
    new_department_switches_num INT,
    new_vnx_block_stor_arrays_num INT,
    data_migration_factor_percent DECIMAL(20,2),
    new_symmetrix_stor_arrays_num INT,
    vnx_blocks_to_upgrade_num INT,
    symmetrix_to_upgrade_num INT,
    xtreme_io_clusters_num INT,
    non_emc_storage_arrays_num INT
)
/

CREATE SEQUENCE SViprDataMigrationPPMEImpl
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE
/
CREATE TABLE ViprDataMigrationPPMEImpl (
    id NUMBER NOT NULL PRIMARY KEY,
    remove_existing_emc_storage NUMBER(1),
    relocate_existing_emc_storage NUMBER(1),
    include_storage_data_erasure NUMBER(1),
    include_add_bin_file_work NUMBER(1),
    bin_files_design_impl_num INT,
    hours_per_bin_file DECIMAL(20,2),
    include_xtreme_io_config NUMBER(1),
    tb_migrated_source_data_amount INT,
    data_migration_factor_percent DECIMAL(20,2),
    total_hosts_migrate_by_emc_num INT,
    new_design_included_hosts_num INT,
    new_esx_servers_num INT,
    customer_zonning_switches NUMBER(1),
    existing_san_fabrics_num INT,
    hosts_booted_from_san_num INT,
    customer_lun_device_allocation NUMBER(1),
    new_vnx_blocks_stor_arrays_num INT,
    vnx_blocks_upgrade_num INT,
    xtreme_io_clusters_num INT,
    xtreme_io_bricks_num INT,
    hosts_migrated_via_ppme_num INT,
    include_device_size_changes NUMBER(1),
    servers_lun_size_percent DECIMAL(20,2),
    vnx_arrays_to_erase_data_num INT,
    vnx_arrays_serial_numbers VARCHAR2(256),
    sym_storage_to_erase_data_num INT,
    sym_storage_serial_numbers VARCHAR2(256)
)
/

CREATE SEQUENCE SViprDataMigrationPPME
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE
/
CREATE TABLE ViprDataMigrationPPME (
    id NUMBER NOT NULL PRIMARY KEY,
    planning_and_design NUMBER(1),
    implementation_and_migration NUMBER(1),
    customer_mig_work_themselves NUMBER(1),
    emc_onsite_support NUMBER(1),
    host_based_migration_tool_id NUMBER,
    include_esx_hosts_mig_vmotion NUMBER(1),
    include_sec_round_data_gather NUMBER(1),
    include_eca NUMBER(1),
    storage_array_vnx_clariion NUMBER(1),
    storage_array_vmax_dmax_symm NUMBER(1),
    storage_array_3rd_party_stor NUMBER(1),
    storage_array_no_source NUMBER(1),
    storage_array_xtreme_io_clus NUMBER(1),
    existing_physical_hosts_num INT,
    existing_esx_servers_num INT,
    swing_frame_required NUMBER(1),
    total_source_array_involved INT,
    total_target_array_involved INT,
    include_device_size_changes NUMBER(1),
    servers_lun_size_percent DECIMAL(20,2),
    tb_data_migration_amount INT,
    hosts_migrated_via_ppme_num INT,
    vmware_machines_num INT,
    ppme_planning_design_id NUMBER,
    ppme_impl_migration_id NUMBER,
    FOREIGN KEY (host_based_migration_tool_id) REFERENCES HostBasedMigrationTool (id),
    FOREIGN KEY (ppme_planning_design_id) REFERENCES ViprDataMigrationPPMEDesign (id),
    FOREIGN KEY (ppme_impl_migration_id) REFERENCES ViprDataMigrationPPMEImpl (id)
)
/

CREATE SEQUENCE SViprRequestData
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE ViprRequestData (
    id NUMBER NOT NULL PRIMARY KEY,
    knowledge_transfer_hours DECIMAL(20,2),
    general_comment VARCHAR2(256),
    planning_design_impl NUMBER(1),
    data_migration_with_ppme NUMBER(1),
    design_impl_for_commodity NUMBER(1),
    ecs_appliance_design_impl NUMBER(1),
    impl_id NUMBER,
    vipr_data_migration_ppme_id NUMBER,
    ecs_appliance_design_impl_id NUMBER,
    vipr_data_service_id NUMBER,
    FOREIGN KEY (impl_id) REFERENCES ViprImplementation (id),
    FOREIGN KEY (vipr_data_migration_ppme_id) REFERENCES ViprDataMigrationPPME (id),
    FOREIGN KEY (ecs_appliance_design_impl_id) REFERENCES ECSApplianceDesignImpl (id),
    FOREIGN KEY (vipr_data_service_id) REFERENCES ViprDataServiceCommodity (id)
)
/
CREATE TRIGGER TViprRequestData
BEFORE INSERT ON ViprRequestData
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SViprRequestData.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SVblockProject
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE VblockProject (
    id NUMBER NOT NULL PRIMARY KEY,
    custom_project_description VARCHAR2(256)
)
/
CREATE TRIGGER TVblockProject
BEFORE INSERT ON VblockProject
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SVblockProject.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SVblockDesignImpl
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE VblockDesignImpl (
    id NUMBER NOT NULL PRIMARY KEY,
    vnx_type NUMBER(1),
    symmetrix_type NUMBER(1),
    vnx_luns_num INT,
    symmetrix_luns_num INT,
    include_unified_file NUMBER(1),
    include_ionix_uim NUMBER(1),
    type1_vsphere_servers_num INT,
    type2_vsphere_servers_num INT,
    cisco_partner_hours DECIMAL(20,2),
    vmware_partner_hours DECIMAL(20,2),
    type1_luns_num INT,
    type2_luns_num INT,
    uft_type1_num INT,
    uft_type2_num INT
)
/
CREATE TRIGGER TVblockDesignImpl
BEFORE INSERT ON VblockDesignImpl
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SVblockDesignImpl.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SVblockInfrastructure
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE VblockInfrastructure (
    id NUMBER NOT NULL PRIMARY KEY,
    vblock_series300_num INT,
    vblock_series700_num INT
)
/
CREATE TRIGGER TVblockInfrastructure
BEFORE INSERT ON VblockInfrastructure
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SVblockInfrastructure.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SVblockTechAssessment
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE VblockTechAssessment (
    id NUMBER NOT NULL PRIMARY KEY,
    assessed_sites INT,
    vmware_identified_servers_num INT
)
/
CREATE TRIGGER TVblockTechAssessment
BEFORE INSERT ON VblockTechAssessment
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SVblockTechAssessment.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SVblockServices
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE VblockServices (
    id NUMBER NOT NULL PRIMARY KEY,
    design_impl NUMBER(1),
    infrastructure NUMBER(1),
    tech_assessment NUMBER(1)
)
/
CREATE TRIGGER TVblockServices
BEFORE INSERT ON VblockServices
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SVblockServices.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SVblockRequestData
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE VblockRequestData (
    id NUMBER NOT NULL PRIMARY KEY,
    describe_options VARCHAR2(256),
    general_comment VARCHAR2(256),
    services_id NUMBER,
    design_impl_id NUMBER,
    infrastructure_id NUMBER,
    tech_assessment_id NUMBER,
    project_id NUMBER,
    FOREIGN KEY (services_id) REFERENCES VblockServices (id),
    FOREIGN KEY (design_impl_id) REFERENCES VblockDesignImpl (id),
    FOREIGN KEY (infrastructure_id) REFERENCES VblockInfrastructure (id),
    FOREIGN KEY (tech_assessment_id) REFERENCES VblockTechAssessment (id),
    FOREIGN KEY (project_id) REFERENCES VblockProject (id)
)
/
CREATE TRIGGER TVblockRequestData
BEFORE INSERT ON VblockRequestData
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SVblockRequestData.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SCenteraToAtmosMigration
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE CenteraToAtmosMigration (
    id NUMBER NOT NULL PRIMARY KEY,
    applications_num INT,
    protection_type INT,
    data_amount INT
)
/
CREATE TRIGGER TCenteraToAtmosMigration
BEFORE INSERT ON CenteraToAtmosMigration
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SCenteraToAtmosMigration.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SCenteraFileErasure
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE CenteraFileErasure (
    id NUMBER NOT NULL PRIMARY KEY,
    clips_to_delete_num INT
)
/
CREATE TRIGGER TCenteraFileErasure
BEFORE INSERT ON CenteraFileErasure
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SCenteraFileErasure.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SCenteraUniversalAccess
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE CenteraUniversalAccess (
    id NUMBER NOT NULL PRIMARY KEY,
    active_cuas_num INT,
    data_pools_num INT,
    standby_cuas_num INT,
    cua_hardware_type_id NUMBER,
    relocated_cuas_num INT,
    FOREIGN KEY (cua_hardware_type_id) REFERENCES CUAHardwareType (id)
)
/
CREATE TRIGGER TCenteraUniversalAccess
BEFORE INSERT ON CenteraUniversalAccess
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SCenteraUniversalAccess.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SCenteraIntraClusterMigration
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE CenteraIntraClusterMigration (
    id NUMBER NOT NULL PRIMARY KEY,
    source_cubes_num INT,
    target_cubes_num INT,
    new_nodes_num INT,
    removed_nodes_num INT,
    existing_nodes_gen3 NUMBER(1)
)
/
CREATE TRIGGER TCenteraIntraClusterMigration
BEFORE INSERT ON CenteraIntraClusterMigration
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SCenteraIntraClusterMigration.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SExpansionNodeOnly
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE ExpansionNodeOnly (
    id NUMBER NOT NULL PRIMARY KEY,
    flex_kits_num INT
)
/
CREATE TRIGGER TExpansionNodeOnly
BEFORE INSERT ON ExpansionNodeOnly
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SExpansionNodeOnly.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SExistingCenteraCluster
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE ExistingCenteraCluster (
    id NUMBER NOT NULL PRIMARY KEY,
    location VARCHAR2(256),
    serial_number VARCHAR2(256),
    modem_number VARCHAR2(256),
    edition_id NUMBER,
    generation_id NUMBER,
    health_check_id NUMBER,
    replication_target VARCHAR2(256),
    migration_source VARCHAR2(256),
    migration_target VARCHAR2(256),
    cicm NUMBER(1),
    applications_writting VARCHAR2(256),
    array_action_id NUMBER,
    certified_data_erasure_req NUMBER(1),
    data_deletion_required NUMBER(1),
    customer_clip_list NUMBER(1),
    FOREIGN KEY (edition_id) REFERENCES CenteraEditionType (id),
    FOREIGN KEY (generation_id) REFERENCES CenteraGenerationType (id),
    FOREIGN KEY (health_check_id) REFERENCES CenteraHealthCheckType (id),
    FOREIGN KEY (array_action_id) REFERENCES CenteraArrayActionType (id)
)
/
CREATE TRIGGER TExistingCenteraCluster
BEFORE INSERT ON ExistingCenteraCluster
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SExistingCenteraCluster.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SNewCenteraCluster
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE NewCenteraCluster (
    id NUMBER NOT NULL PRIMARY KEY,
    location VARCHAR2(256),
    edition_id NUMBER,
    generation_id NUMBER,
    protection_scheme_id NUMBER,
    nodes_num INT,
    replication_target VARCHAR2(256),
    migration_source VARCHAR2(256),
    located_at_target_site NUMBER(1),
    moved_from_target_site NUMBER(1),
    applications_writting VARCHAR2(256),
    FOREIGN KEY (edition_id) REFERENCES CenteraEditionType (id),
    FOREIGN KEY (generation_id) REFERENCES CenteraGenerationType (id),
    FOREIGN KEY (protection_scheme_id) REFERENCES CenteraProtectionSchemeType (id)
)
/
CREATE TRIGGER TNewCenteraCluster
BEFORE INSERT ON NewCenteraCluster
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SNewCenteraCluster.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SCenteraDesignImpl
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE CenteraDesignImpl (
    id NUMBER NOT NULL PRIMARY KEY,
    centeras_exist NUMBER(1),
    ex_centeras_require_review NUMBER(1),
    ex_centeras_review_detail VARCHAR2(256),
    hardware_repurposing_detail VARCHAR2(256),
    array_relocation_detail VARCHAR2(256),
    shipping_arranger_id NUMBER,
    need_develop_code NUMBER(1),
    develop_code_detail VARCHAR2(256),
    custom_scripting NUMBER(1),
    custom_scripting_detail VARCHAR2(256),
    expected_timeline VARCHAR2(256),
    replication_type_id NUMBER,
    implement_tape_backup NUMBER(1),
    FOREIGN KEY (shipping_arranger_id) REFERENCES CenteraShippingArranger (id),
    FOREIGN KEY (replication_type_id) REFERENCES CenteraReplicationType (id)
)
/
CREATE TRIGGER TCenteraDesignImpl
BEFORE INSERT ON CenteraDesignImpl
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SCenteraDesignImpl.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE TABLE CenteraDesignImpl_exClusters (
    centera_design_impl_id NUMBER NOT NULL,
    existing_centera_cluster_id NUMBER NOT NULL,
    FOREIGN KEY (centera_design_impl_id) REFERENCES CenteraDesignImpl (id),
    FOREIGN KEY (existing_centera_cluster_id) REFERENCES ExistingCenteraCluster (id)
)
/

CREATE TABLE CenteraDesignImpl_newClusters (
    centera_design_impl_id NUMBER NOT NULL,
    new_centera_cluster_id NUMBER NOT NULL,
    FOREIGN KEY (centera_design_impl_id) REFERENCES CenteraDesignImpl (id),
    FOREIGN KEY (new_centera_cluster_id) REFERENCES NewCenteraCluster (id)
)
/

CREATE SEQUENCE SAtmosDesignImpl
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE AtmosDesignImpl (
    id NUMBER NOT NULL PRIMARY KEY,
    include_acdp NUMBER(1),
    rmgs_num INT,
    rmgs_ve_num INT,
    installation_segments_num INT,
    cabinet_type_ws2 NUMBER(1),
    hardware_servers_num INT,
    cifs_servers_num INT,
    nfs_servers_num INT,
    ifs_servers_num INT,
    ws_servers_num INT,
    tenants_num INT,
    sub_tenants_num INT,
    policies_num INT,
    include_secondary_acdpsite NUMBER(1)
)
/
CREATE TRIGGER TAtmosDesignImpl
BEFORE INSERT ON AtmosDesignImpl
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SAtmosDesignImpl.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SAtmosCenteraServicesScope
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE AtmosCenteraServicesScope (
    id NUMBER NOT NULL PRIMARY KEY,
    centera_design_impl NUMBER(1),
    atmos_design_impl NUMBER(1),
    centera_to_atmos_mig NUMBER(1),
    acdp NUMBER(1),
    cva NUMBER(1),
    cua NUMBER(1),
    cicm NUMBER(1),
    centera_file_erasure NUMBER(1),
    expansion_node_only NUMBER(1)
)
/
CREATE TRIGGER TAtmosCenteraServicesScope
BEFORE INSERT ON AtmosCenteraServicesScope
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SAtmosCenteraServicesScope.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SAtmosCenteraRequestData
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE AtmosCenteraRequestData (
    id NUMBER NOT NULL PRIMARY KEY,
    have_high_level_design NUMBER(1),
    sites_involved_id NUMBER,
    days_of_knowledge_transfer DECIMAL(20,2),
    customer_has_centera NUMBER(1),
    general_comment VARCHAR2(256),
    services_scope_id NUMBER,
    atmos_design_impl_id NUMBER,
    centera_design_impl_id NUMBER,
    centera_to_atmos_migration_id NUMBER,
    centera_file_erasure_id NUMBER,
    centera_universal_access_id NUMBER,
    centera_intra_cluster_migr_id NUMBER,
    expansion_node_only_id NUMBER,
    FOREIGN KEY (sites_involved_id) REFERENCES SitesInvolved (id),
    FOREIGN KEY (services_scope_id) REFERENCES AtmosCenteraServicesScope (id),
    FOREIGN KEY (atmos_design_impl_id) REFERENCES AtmosDesignImpl (id),
    FOREIGN KEY (centera_design_impl_id) REFERENCES CenteraDesignImpl (id),
    FOREIGN KEY (centera_to_atmos_migration_id) REFERENCES CenteraToAtmosMigration (id),
    FOREIGN KEY (centera_file_erasure_id) REFERENCES CenteraFileErasure (id),
    FOREIGN KEY (centera_universal_access_id) REFERENCES CenteraUniversalAccess (id),
    FOREIGN KEY (centera_intra_cluster_migr_id) REFERENCES CenteraIntraClusterMigration (id),
    FOREIGN KEY (expansion_node_only_id) REFERENCES ExpansionNodeOnly (id)
)
/
CREATE TRIGGER TAtmosCenteraRequestData
BEFORE INSERT ON AtmosCenteraRequestData
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SAtmosCenteraRequestData.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SVMwareAssessment
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE VMwareAssessment (
    id NUMBER NOT NULL PRIMARY KEY,
    assessment_type INT,
    include_single_config NUMBER(1),
    include_multiple_config NUMBER(1),
    present_emc_report NUMBER(1),
    capacity_planner_sites_num INT,
    cap_planner_collectors_num INT,
    days_to_capt_collection_data INT,
    additional_servers_num INT,
    vsphere_clusters_num INT
)
/
CREATE TRIGGER TVMwareAssessment
BEFORE INSERT ON VMwareAssessment
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SVMwareAssessment.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SVMwareBackupRecovery
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE VMwareBackupRecovery (
    id NUMBER NOT NULL PRIMARY KEY,
    virtual_center_install_num INT,
    esx_servers_num INT,
    virtual_hosts_num INT,
    assessment_interviews_num INT
)
/
CREATE TRIGGER TVMwareBackupRecovery
BEFORE INSERT ON VMwareBackupRecovery
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SVMwareBackupRecovery.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SVMwareHealthChecks
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE VMwareHealthChecks (
    id NUMBER NOT NULL PRIMARY KEY,
    incl_executive_summary_review NUMBER(1),
    assessment_interviews_num INT,
    esx_servers_num INT,
    virtual_hosts_num INT
)
/
CREATE TRIGGER TVMwareHealthChecks
BEFORE INSERT ON VMwareHealthChecks
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SVMwareHealthChecks.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SVMwareReplication
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE VMwareReplication (
    id NUMBER NOT NULL PRIMARY KEY,
    install_srm NUMBER(1),
    customer_require_srm_training NUMBER(1),
    srm_adopters_num INT,
    srm_plans_num INT,
    celerra_ip NUMBER(1),
    vnx_block NUMBER(1),
    recover_point NUMBER(1),
    symmetrix_srdf NUMBER(1),
    new_symmetrix_num INT,
    existing_symmetrix_num INT,
    new_vnx_block_num INT,
    existing_vnx_block_num INT,
    new_rec_point_clusters_num INT,
    ex_rec_point_clusters_num INT,
    new_unified_file_servers_num INT,
    ex_celerra_file_servers_num INT
)
/
CREATE TRIGGER TVMwareReplication
BEFORE INSERT ON VMwareReplication
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SVMwareReplication.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SVMwareTCOAssessment
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE VMwareTCOAssessment (
    id NUMBER NOT NULL PRIMARY KEY,
    assessment_scenario INT,
    data_center_locations_num INT,
    conducted_interviews_num INT
)
/
CREATE TRIGGER TVMwareTCOAssessment
BEFORE INSERT ON VMwareTCOAssessment
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SVMwareTCOAssessment.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SVMwareVblockDesignImpl
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE VMwareVblockDesignImpl (
    id NUMBER NOT NULL PRIMARY KEY,
    include_partner_loe NUMBER(1),
    cisco NUMBER(1),
    vmware NUMBER(1),
    cisco_partner_hours DECIMAL(20,2),
    vmware_partner_hours DECIMAL(20,2),
    include_unified_file_options NUMBER(1),
    include_ionix_uim NUMBER(1),
    type1 NUMBER(1),
    type2 NUMBER(1),
    type1_vblocks_num INT,
    type1_luns_num INT,
    type1_vsphere_servers_num INT,
    type2_vblocks_num INT,
    type2_luns_num INT,
    type2_vsphere_servers_num INT,
    unified_file_type_vg2_num INT,
    unified_file_type_vg8_num INT
)
/
CREATE TRIGGER TVMwareVblockDesignImpl
BEFORE INSERT ON VMwareVblockDesignImpl
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SVMwareVblockDesignImpl.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SVMwareVblockInfraImpl
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE VMwareVblockInfraImpl (
    id NUMBER NOT NULL PRIMARY KEY,
    vblock_300series_num INT,
    vblock_700series_num INT
)
/
CREATE TRIGGER TVMwareVblockInfraImpl
BEFORE INSERT ON VMwareVblockInfraImpl
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SVMwareVblockInfraImpl.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SVMwareVblockInfraTechAss
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE VMwareVblockInfraTechAss (
    id NUMBER NOT NULL PRIMARY KEY,
    assessed_sites_num INT,
    identified_servers_num INT
)
/
CREATE TRIGGER TVMwareVblockInfraTechAss
BEFORE INSERT ON VMwareVblockInfraTechAss
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SVMwareVblockInfraTechAss.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SVMwareVblock
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE VMwareVblock (
    id NUMBER NOT NULL PRIMARY KEY,
    design_impl NUMBER(1),
    infra_tech_assessment NUMBER(1),
    infra_impl NUMBER(1),
    vblock_design_impl_id NUMBER,
    vblock_infra_impl_id NUMBER,
    vblock_infra_tech_ass_id NUMBER,
    FOREIGN KEY (vblock_design_impl_id) REFERENCES VMwareVblockDesignImpl (id),
    FOREIGN KEY (vblock_infra_impl_id) REFERENCES VMwareVblockInfraImpl (id),
    FOREIGN KEY (vblock_infra_tech_ass_id) REFERENCES VMwareVblockInfraTechAss (id)
)
/
CREATE TRIGGER TVMwareVblock
BEFORE INSERT ON VMwareVblock
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SVMwareVblock.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SVMwareConverter
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE VMwareConverter (
    id NUMBER NOT NULL PRIMARY KEY,
    migration_performed NUMBER(1),
    include_jump_start_workshops NUMBER(1),
    installs_num INT,
    servers_num INT,
    additional_hours DECIMAL(20,2),
    billable_hours_per_str DECIMAL(20,2),
    billable_hours_for_testing DECIMAL(20,2)
)
/
CREATE TRIGGER TVMwareConverter
BEFORE INSERT ON VMwareConverter
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SVMwareConverter.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SVMwareSvMotion
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE VMwareSvMotion (
    id NUMBER NOT NULL PRIMARY KEY,
    include_virtual_infra_35 NUMBER(1),
    virtual_machines_num INT,
    additional_hours DECIMAL(20,2)
)
/
CREATE TRIGGER TVMwareSvMotion
BEFORE INSERT ON VMwareSvMotion
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SVMwareSvMotion.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SVMwareViewDesign
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE VMwareViewDesign (
    id NUMBER NOT NULL PRIMARY KEY,
    include_mssql NUMBER(1),
    include_oracle NUMBER(1),
    esx_servers_num INT,
    virtual_center_install_num INT,
    automated_desktop_pools_num INT,
    manual_desktop_pools_num INT,
    manager_conn_servers_num INT,
    manager_replica_servers_num INT,
    composer_instances_num INT,
    sql_databases_num INT,
    oracle_databases_num INT,
    manager_pods_num INT,
    manager_partitions_num INT,
    desktop_profiles_num INT,
    application_profiles_num INT,
    virt_desk_per_esx_host_num INT
)
/
CREATE TRIGGER TVMwareViewDesign
BEFORE INSERT ON VMwareViewDesign
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SVMwareViewDesign.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SVMwareViewImpl
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE VMwareViewImpl (
    id NUMBER NOT NULL PRIMARY KEY,
    include_mssql NUMBER(1),
    include_oracle NUMBER(1),
    esx_servers_num INT,
    virtual_center_install_num INT,
    automated_desktop_pools_num INT,
    manual_desktop_pools_num INT,
    manager_conn_servers_num INT,
    manager_replica_servers_num INT,
    composer_instances_num INT,
    sql_databases_num INT,
    oracle_databases_num INT,
    billable_hours_for_testing DECIMAL(20,2)
)
/
CREATE TRIGGER TVMwareViewImpl
BEFORE INSERT ON VMwareViewImpl
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SVMwareViewImpl.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SVMwareView
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE VMwareView (
    id NUMBER NOT NULL PRIMARY KEY,
    design NUMBER(1),
    impl NUMBER(1),
    view_design_id NUMBER,
    view_impl_id NUMBER,
    FOREIGN KEY (view_design_id) REFERENCES VMwareViewDesign (id),
    FOREIGN KEY (view_impl_id) REFERENCES VMwareViewImpl (id)
)
/
CREATE TRIGGER TVMwareView
BEFORE INSERT ON VMwareView
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SVMwareView.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SVMwareVirtualInfra
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE VMwareVirtualInfra (
    id NUMBER NOT NULL PRIMARY KEY,
    server_storage_design_service NUMBER(1),
    infra_impl_service NUMBER(1),
    des_impl_jump_start_service NUMBER(1),
    design_impl_service NUMBER(1),
    jump_start_only_service NUMBER(1),
    storage_config_varieties_num INT,
    esx_hosts_num INT,
    identified_servers_num INT,
    include_rdm NUMBER(1),
    impl_vcenter_servers_num INT,
    impl_esxi_servers_num INT,
    impl_esxi_clusters_num INT,
    dij_vcenter_servers_num INT,
    dij_esx_clusters_num INT,
    dij_esx_servers_num INT,
    dij_billable_hour_for_testing DECIMAL(20,2),
    des_impl_vcenter_servers_num INT,
    design_impl_esx_clusters_num INT,
    design_impl_esx_servers_num INT
)
/
CREATE TRIGGER TVMwareVirtualInfra
BEFORE INSERT ON VMwareVirtualInfra
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SVMwareVirtualInfra.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SVMwareVSphere
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE VMwareVSphere (
    id NUMBER NOT NULL PRIMARY KEY,
    include_upgrades NUMBER(1),
    include_jump_start_workshops NUMBER(1),
    billable_hours_for_testing DECIMAL(20,2),
    vcenter_instances_num INT,
    esx_servers_num INT,
    jump_start_workshops_num INT
)
/
CREATE TRIGGER TVMwareVSphere
BEFORE INSERT ON VMwareVSphere
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SVMwareVSphere.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SVMwareServicesScope
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE VMwareServicesScope (
    id NUMBER NOT NULL PRIMARY KEY,
    assessment NUMBER(1),
    backup_recovery NUMBER(1),
    health_checks NUMBER(1),
    replication NUMBER(1),
    tco_assessment NUMBER(1),
    vce_vblock NUMBER(1),
    converter NUMBER(1),
    sv_motion NUMBER(1),
    vm_view NUMBER(1),
    virtual_infrastructure NUMBER(1),
    vsphere NUMBER(1)
)
/
CREATE TRIGGER TVMwareServicesScope
BEFORE INSERT ON VMwareServicesScope
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SVMwareServicesScope.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SVMwareRequestData
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE VMwareRequestData (
    id NUMBER NOT NULL PRIMARY KEY,
    general_comments VARCHAR2(256),
    services_scope_id NUMBER,
    assessment_id NUMBER,
    backup_recovery_id NUMBER,
    health_checks_id NUMBER,
    replication_id NUMBER,
    tco_assessment_id NUMBER,
    vce_vblock_id NUMBER,
    converter_id NUMBER,
    sv_motion_id NUMBER,
    view_id NUMBER,
    virtual_infrastructure_id NUMBER,
    vsphere_id NUMBER,
    FOREIGN KEY (services_scope_id) REFERENCES VMwareServicesScope (id),
    FOREIGN KEY (assessment_id) REFERENCES VMwareAssessment (id),
    FOREIGN KEY (backup_recovery_id) REFERENCES VMwareBackupRecovery (id),
    FOREIGN KEY (health_checks_id) REFERENCES VMwareHealthChecks (id),
    FOREIGN KEY (replication_id) REFERENCES VMwareReplication (id),
    FOREIGN KEY (tco_assessment_id) REFERENCES VMwareTCOAssessment (id),
    FOREIGN KEY (vce_vblock_id) REFERENCES VMwareVblock (id),
    FOREIGN KEY (converter_id) REFERENCES VMwareConverter (id),
    FOREIGN KEY (sv_motion_id) REFERENCES VMwareSvMotion (id),
    FOREIGN KEY (view_id) REFERENCES VMwareView (id),
    FOREIGN KEY (virtual_infrastructure_id) REFERENCES VMwareVirtualInfra (id),
    FOREIGN KEY (vsphere_id) REFERENCES VMwareVSphere (id)
)
/
CREATE TRIGGER TVMwareRequestData
BEFORE INSERT ON VMwareRequestData
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SVMwareRequestData.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SRecoverPointInstallationAndIm
INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE
/

CREATE TABLE RecoverPointInstallationAndIm (
  id                                          NUMBER NOT NULL PRIMARY KEY,
  delivery_option_design                      NUMERIC(1),
  delivery_option_impl NUMERIC(1),
  recover_point_option_id NUMBER,
  rp_replication_method_local NUMERIC(1),
  rp_replication_method_remote NUMERIC(1),
  include_cluster_enabler NUMERIC(1),
  recover_point_splitter_type_id NUMBER,
  vnx_or_clariion_involved NUMERIC(1),
  vmax_dmx_or_symm_involved NUMERIC(1),
  non_emc_or_3rd_party_storage_i NUMERIC(1),
  no_source_array_involved NUMERIC(1),
  xtrem_io_cluster_involved NUMERIC(1),
  existing_physical_hosts_num                 INT,
  existing_esx_servers_num                    INT,
  rp_env_clients_servers_num                  INT,
  rp_appliances_num                           INT,
  storage_systems_req_splitter_n            INT,
  include_bandwidth_analysis NUMERIC(1),
  dispatch_emc_team NUMERIC(1),
  include_3rd_party_storage_arr NUMERIC(1),
  include_3rd_party_storage_arri NUMERIC(1),
  non_emc_storage_arrays_num                  INT,
  include_replication_manager_ei NUMERIC(1),
  include_vmware_vcenter_site_i NUMERIC(1),
  ms_failover_clusters_num                    INT,
  rp_ce_cluster_nodes_num                     INT,
  rp_consistency_groups_num                   INT,
  FOREIGN KEY (recover_point_splitter_type_id) REFERENCES RecoverPointSplitterType (id),
  FOREIGN KEY (recover_point_option_id) REFERENCES RecoverPointOption (id)
)/

CREATE TRIGGER TRecoverPointInstallationAndIm
BEFORE INSERT ON RecoverPointInstallationAndIm
FOR EACH ROW
WHEN (new.id = 0 OR new.id IS NULL)
  BEGIN
    SELECT
      SRecoverPointInstallationAndIm.NEXTVAL
    INTO :new.id
    FROM dual;
  END;
/

CREATE SEQUENCE SRPAHardwareUpgrade
INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE
/

CREATE TABLE RPAHardwareUpgrade (
  id                    NUMBER NOT NULL PRIMARY KEY,
  use_gen1_rpa_hardware NUMERIC(1),
  rpas_to_upgrade_num   INT
)/

CREATE TRIGGER TRPAHardwareUpgrade
BEFORE INSERT ON RPAHardwareUpgrade
FOR EACH ROW
WHEN (new.id = 0 OR new.id IS NULL)
  BEGIN
    SELECT
      SRPAHardwareUpgrade.NEXTVAL
    INTO :new.id
    FROM dual;
  END;
/

CREATE SEQUENCE SIntelligentFabricSplitterMig
INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE
/

CREATE TABLE IntelligentFabricSplitterMig (
  id                                        NUMBER NOT NULL PRIMARY KEY,
  intelligent_fabric_migration_m    NUMBER,
  grid_analysis_required                NUMBER,
  vnx_or_clariion_involved              NUMBER,
  vmax_dmx_or_symm_involved             NUMBER,
  non_emc_or_3rd_party_storage_i NUMBER,
  no_source_array_involved              NUMBER,
  xtrem_io_cluster_involved             NUMBER,
  rpa_clusters_to_migrate_num               INT,
  rpa_volumes_hosts_to_migrate_n          INT,
  include_bandwidth_analysis            NUMBER,
  include_3rd_party_storage_arr       NUMBER,
  recover_point_option_id               NUMBER,
  vplex_clusters_num                        INT,
  volumes_to_encapsulate_num                INT,
  encaps_events_per_emc_rn INT,
  host_encapsulations_to_vplex_n          INT,
  maintenance_windows_hours                 FLOAT,
  rp_env_clients_servers_num                INT,
  rp_replication_method_local               NUMERIC(1),
  rp_replication_method_remote          NUMBER,
  FOREIGN KEY (intelligent_fabric_migration_m) REFERENCES IntelligentFabricMigrationMet (id),
  FOREIGN KEY (recover_point_option_id) REFERENCES RecoverPointOption (id)
)/

CREATE TRIGGER TIntelligentFabricSplitterMig
BEFORE INSERT ON IntelligentFabricSplitterMig
FOR EACH ROW
WHEN ( NEW .id = 0 OR NEW.id IS NULL)
BEGIN
  SELECT
    SIntelligentFabricSplitterMig.NEXTVAL
  INTO :NEW.id
  FROM dual;
END;
/

CREATE SEQUENCE SRecoverPoint
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE
/
CREATE TABLE RecoverPoint (
  id                                       NUMBER NOT NULL PRIMARY KEY,
  install_and_implement                    NUMERIC(1),
  migrate_intelligent_fabric_spl NUMERIC(1),
  upgrade_rpa_hardware NUMERIC(1),
  installation_implementation_id           NUMBER,
  intelligent_fabric_splitter_mi NUMBER,
  rpa_hardware_upgrade_id NUMBER,
  FOREIGN KEY (installation_implementation_id) REFERENCES RecoverPointInstallationAndIm (id),
  FOREIGN KEY (intelligent_fabric_splitter_mi) REFERENCES IntelligentFabricSplitterMig (id),
  FOREIGN KEY (rpa_hardware_upgrade_id) REFERENCES RPAHardwareUpgrade (id)
)
/
CREATE TRIGGER TRecoverPoint
BEFORE INSERT ON RecoverPoint
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SRecoverPoint.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SEDLDesignImpl
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE EDLDesignImpl (
    id NUMBER NOT NULL PRIMARY KEY,
    replication NUMBER(1),
    acsls NUMBER(1),
    auto_engine_failover NUMBER(1),
    integrated_backup_application NUMBER(1),
    backend_storage_arrays_num INT,
    backup_servers_num INT,
    physical_tape_lib_units_num INT,
    virtual_tape_libraries_num INT,
    virtual_tapes_num INT,
    virtual_tape_drives_num INT,
    replications_created_num INT
)
/
CREATE TRIGGER TEDLDesignImpl
BEFORE INSERT ON EDLDesignImpl
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SEDLDesignImpl.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SEDL
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE EDL (
    id NUMBER NOT NULL PRIMARY KEY,
    knowledge_transfer_hours DECIMAL(20,2),
    design NUMBER(1),
    implementation NUMBER(1),
    design_impl_id NUMBER,
    FOREIGN KEY (design_impl_id) REFERENCES EDLDesignImpl (id)
)
/
CREATE TRIGGER TEDL
BEFORE INSERT ON EDL
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SEDL.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SAvamarOptions
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE AvamarOptions (
    id NUMBER NOT NULL PRIMARY KEY,
    configure_clients NUMBER(1),
    configure_ndmp NUMBER(1),
    configure_avf NUMBER(1),
    configure_advanced_network NUMBER(1),
    configure_download_server NUMBER(1),
    configure_replication NUMBER(1),
    vmware_integeration NUMBER(1),
    data_domain_integration NUMBER(1),
    configure_vcloud_director NUMBER(1)
)
/
CREATE TRIGGER TAvamarOptions
BEFORE INSERT ON AvamarOptions
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SAvamarOptions.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SAvamarPlugins
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE AvamarPlugins (
    id NUMBER NOT NULL PRIMARY KEY,
    exchange NUMBER(1),
    sql_server NUMBER(1),
    oracle NUMBER(1),
    db2 NUMBER(1),
    sharepoint NUMBER(1),
    lotus_domino NUMBER(1),
    exchange_plugins_num INT,
    sql_server_plugins_num INT,
    oracle_plugins_num INT,
    db2_plugins_num INT,
    sharepoint_plugins_num INT,
    lotus_domino_plugins_num INT
)
/
CREATE TRIGGER TAvamarPlugins
BEFORE INSERT ON AvamarPlugins
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SAvamarPlugins.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SAvamarNDMP
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE AvamarNDMP (
    id NUMBER NOT NULL PRIMARY KEY,
    emc_celerra NUMBER(1),
    network_appliance NUMBER(1),
    emc_isilon NUMBER(1),
    emc_vnx NUMBER(1),
    ndmp_nodes_num INT,
    include_multistream_support NUMBER(1),
    streams_per_node_num INT,
    celerra_targets_num INT,
    net_app_filer_targets_num INT,
    isilon_targets_num INT,
    vnx_targets_num INT,
    data_set_creation_hours DECIMAL(20,2)
)
/
CREATE TRIGGER TAvamarNDMP
BEFORE INSERT ON AvamarNDMP
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SAvamarNDMP.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SAvamarDesign
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE AvamarDesign (
    id NUMBER NOT NULL PRIMARY KEY,
    plugins_id NUMBER,
    options_id NUMBER,
    servers_num INT,
    clients_num INT,
    esx_servers_num INT,
    image_level_backups_num INT,
    ndmp_nodes_num INT,
    ndmp_targets_num INT,
    expansion_nodes_num INT,
    FOREIGN KEY (plugins_id) REFERENCES AvamarPlugins (id),
    FOREIGN KEY (options_id) REFERENCES AvamarOptions (id)
)
/
CREATE TRIGGER TAvamarDesign
BEFORE INSERT ON AvamarDesign
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SAvamarDesign.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SAvamarImplementation
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE AvamarImplementation (
    id NUMBER NOT NULL PRIMARY KEY,
    plugins_id NUMBER,
    options_id NUMBER,
    servers_num INT,
    clients_num INT,
    esx_servers_num INT,
    image_level_backups_num INT,
    billable_hours DECIMAL(20,2),
    incl_backup_recovery_manager NUMBER(1),
    include_hardware_installation NUMBER(1),
    data_nodes_num INT,
    data_set_creation_hours DECIMAL(20,2),
    install_type INT,
    auth_method INT,
    clients_percent DECIMAL(20,2),
    ndmp_id NUMBER,
    proxies_num INT,
    replication_sets_num INT,
    data_domain_servers_num INT,
    dd_boost_plugins_num INT,
    FOREIGN KEY (plugins_id) REFERENCES AvamarPlugins (id),
    FOREIGN KEY (options_id) REFERENCES AvamarOptions (id),
    FOREIGN KEY (ndmp_id) REFERENCES AvamarNDMP (id)
)
/
CREATE TRIGGER TAvamarImplementation
BEFORE INSERT ON AvamarImplementation
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SAvamarImplementation.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SAvamarTapeOutImplementation
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE AvamarTapeOutImplementation (
    id NUMBER NOT NULL PRIMARY KEY,
    adt_type INT,
    grids_num INT,
    archive_servers_num INT,
    esx_servers_num INT,
    replication_connections_num INT,
    adt_transport_nodes_num INT,
    adt_controllers_num INT
)
/
CREATE TRIGGER TAvamarTapeOutImplementation
BEFORE INSERT ON AvamarTapeOutImplementation
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SAvamarTapeOutImplementation.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SAvamarTapeOutDesign
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE AvamarTapeOutDesign (
    id NUMBER NOT NULL PRIMARY KEY,
    include_domain_reconfiguring NUMBER(1),
    adt_controllers_num INT,
    adt_domains_num INT,
    adt_clients_num INT
)
/
CREATE TRIGGER TAvamarTapeOutDesign
BEFORE INSERT ON AvamarTapeOutDesign
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SAvamarTapeOutDesign.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SAvamarOperationalAssurance
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE AvamarOperationalAssurance (
    id NUMBER NOT NULL PRIMARY KEY,
    include_operations_guide NUMBER(1),
    include_troubleshooting_guide NUMBER(1),
    include_high_level_arch NUMBER(1),
    grids_num INT,
    replication_sites_num INT
)
/
CREATE TRIGGER TAvamarOperationalAssurance
BEFORE INSERT ON AvamarOperationalAssurance
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SAvamarOperationalAssurance.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SAvamarHealthCheck
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE AvamarHealthCheck (
    id NUMBER NOT NULL PRIMARY KEY,
    grids_num INT,
    assessment_interviews_num INT
)
/
CREATE TRIGGER TAvamarHealthCheck
BEFORE INSERT ON AvamarHealthCheck
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SAvamarHealthCheck.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SAvamarMigration
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE AvamarMigration (
    id NUMBER NOT NULL PRIMARY KEY,
    migration_type INT,
    include_client_reconf NUMBER(1),
    include_source_data_wipe NUMBER(1),
    source_sys_nodes_num INT,
    target_sys_nodes_num INT,
    repl_monitoring_events_num INT,
    reconfigure_clients_num INT
)
/
CREATE TRIGGER TAvamarMigration
BEFORE INSERT ON AvamarMigration
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SAvamarMigration.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SAvamarIntegration
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE AvamarIntegration (
    id NUMBER NOT NULL PRIMARY KEY,
    workshop NUMBER(1),
    pilot NUMBER(1),
    clients_num INT,
    configured_clients_num INT,
    dtlt_clients_activated NUMBER(1),
    grids_num INT
)
/
CREATE TRIGGER TAvamarIntegration
BEFORE INSERT ON AvamarIntegration
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SAvamarIntegration.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SAvamar
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE Avamar (
    id NUMBER NOT NULL PRIMARY KEY,
    knowledge_transfer_hours DECIMAL(20,2),
    design_impl_service NUMBER(1),
    tape_out_design_impl_service NUMBER(1),
    operational_assurance_service NUMBER(1),
    health_check_service NUMBER(1),
    migration_service NUMBER(1),
    integration_service NUMBER(1),
    vcloud_director_service NUMBER(1),
    server_type_id NUMBER,
    design_deliver_option NUMBER(1),
    implementation_deliver_option NUMBER(1),
    design_id NUMBER,
    implementation_id NUMBER,
    tape_out_design_id NUMBER,
    tape_out_implementation_id NUMBER,
    operational_assurance_id NUMBER,
    health_check_id NUMBER,
    migration_id NUMBER,
    integration_id NUMBER,
    FOREIGN KEY (server_type_id) REFERENCES AvamarServerType (id),
    FOREIGN KEY (design_id) REFERENCES AvamarDesign (id),
    FOREIGN KEY (implementation_id) REFERENCES AvamarImplementation (id),
    FOREIGN KEY (tape_out_design_id) REFERENCES AvamarTapeOutDesign (id),
    FOREIGN KEY (tape_out_implementation_id) REFERENCES AvamarTapeOutImplementation (id),
    FOREIGN KEY (operational_assurance_id) REFERENCES AvamarOperationalAssurance (id),
    FOREIGN KEY (health_check_id) REFERENCES AvamarHealthCheck (id),
    FOREIGN KEY (migration_id) REFERENCES AvamarMigration (id),
    FOREIGN KEY (integration_id) REFERENCES AvamarIntegration (id)
)
/
CREATE TRIGGER TAvamar
BEFORE INSERT ON Avamar
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SAvamar.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/
CREATE SEQUENCE SDataDomainBoostBackupServer
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE DataDomainBoostBackupServer (
    id NUMBER NOT NULL PRIMARY KEY,
    nbu NUMBER(1),
    rman NUMBER(1)
)
/
CREATE TRIGGER TDataDomainBoostBackupServer
BEFORE INSERT ON DataDomainBoostBackupServer
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SDataDomainBoostBackupServer.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SDataDomainDesignImplContent
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE DataDomainDesignImplContent (
    id NUMBER NOT NULL PRIMARY KEY,
    boost_backup_server_id NUMBER,
    integrate_sap_hana NUMBER(1),
    plan_design_implement_vtl NUMBER(1),
    include_ibm_iseries_brms NUMBER(1),
    ibm_pars_num INT,
    vtl_appliances_num INT,
    install_fibre_cards_num INT,
    create_vtls_num INT,
    backup_servers_num INT,
    appliances_for_ddboost_num INT,
    ora_rman_backup_servers_num INT,
    ora_backup_config_servers_num INT,
    sap_hana_databases_num INT,
    FOREIGN KEY (boost_backup_server_id) REFERENCES DataDomainBoostBackupServer (id)
)
/
CREATE TRIGGER TDataDomainDesignImplContent
BEFORE INSERT ON DataDomainDesignImplContent
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SDataDomainDesignImplContent.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SDataDomainDesign
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE DataDomainDesign (
    id NUMBER NOT NULL PRIMARY KEY,
    boost_backup_server_id NUMBER,
    integrate_sap_hana NUMBER(1),
    plan_design_implement_vtl NUMBER(1),
    include_ibm_iseries_brms NUMBER(1),
    ibm_pars_num INT,
    vtl_appliances_num INT,
    install_fibre_cards_num INT,
    create_vtls_num INT,
    backup_servers_num INT,
    appliances_for_ddboost_num INT,
    ora_rman_backup_servers_num INT,
    ora_backup_config_servers_num INT,
    sap_hana_databases_num INT,
    FOREIGN KEY (boost_backup_server_id) REFERENCES DataDomainBoostBackupServer (id)
)
/
CREATE TRIGGER TDataDomainDesign
BEFORE INSERT ON DataDomainDesign
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SDataDomainDesign.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SDataDomainDesignAppModel
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE DataDomainDesignAppModel (
    id NUMBER NOT NULL PRIMARY KEY,
    model_name VARCHAR2(256),
    appliances_num INT
)
/
CREATE TRIGGER TDataDomainDesignAppModel
BEFORE INSERT ON DataDomainDesignAppModel
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SDataDomainDesignAppModel.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE TABLE DataDomainDesign_appModels (
    data_domain_design_id NUMBER NOT NULL,
    data_dom_design_app_model_id NUMBER NOT NULL,
    FOREIGN KEY (data_domain_design_id) REFERENCES DataDomainDesign (id),
    FOREIGN KEY (data_dom_design_app_model_id) REFERENCES DataDomainDesignAppModel (id)
)
/


CREATE SEQUENCE SDataDomainImplementation
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE DataDomainImplementation (
    id NUMBER NOT NULL PRIMARY KEY,
    boost_backup_server_id NUMBER,
    integrate_sap_hana NUMBER(1),
    plan_design_implement_vtl NUMBER(1),
    include_ibm_iseries_brms NUMBER(1),
    ibm_pars_num INT,
    vtl_appliances_num INT,
    install_fibre_cards_num INT,
    create_vtls_num INT,
    backup_servers_num INT,
    appliances_for_ddboost_num INT,
    ora_rman_backup_servers_num INT,
    ora_backup_config_servers_num INT,
    sap_hana_databases_num INT,
    FOREIGN KEY (boost_backup_server_id) REFERENCES DataDomainBoostBackupServer (id)
)
/
CREATE TRIGGER TDataDomainImplementation
BEFORE INSERT ON DataDomainImplementation
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SDataDomainImplementation.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SDataDomainImplApplianceModel
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE DataDomainImplApplianceModel (
    id NUMBER NOT NULL PRIMARY KEY,
    model_name VARCHAR2(256),
    appliances_num INT,
    expansion_shelves_num INT,
    include_ipreplication NUMBER(1),
    device_type_id NUMBER,
    virtual_tape_library_app NUMBER(1),
    db_boost NUMBER(1),
    edl_virtual_tape_libs_num INT,
    dd_boost_servers_num INT,
    FOREIGN KEY (device_type_id) REFERENCES DataDomainDeviceType (id)
)
/
CREATE TRIGGER TDataDomainImplApplianceModel
BEFORE INSERT ON DataDomainImplApplianceModel
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SDataDomainImplApplianceModel.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE TABLE DataDomainImpl_appModels (
    data_domain_impl_id NUMBER NOT NULL,
    data_domain_impl_app_model_id NUMBER NOT NULL,
    FOREIGN KEY (data_domain_impl_id) REFERENCES DataDomainImplementation (id),
    FOREIGN KEY (data_domain_impl_app_model_id) REFERENCES DataDomainImplApplianceModel (id)
)
/

CREATE SEQUENCE SDataDomainUpgrade
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE DataDomainUpgrade (
    id NUMBER NOT NULL PRIMARY KEY,
    upgrade_type_id NUMBER,
    appliances_num INT,
    dd890 NUMBER(1),
    dd890_appliances_num INT,
    dd990 NUMBER(1),
    dd990_appliances_num INT,
    dd4200 NUMBER(1),
    dd4200_appliances_num INT,
    dd4500 NUMBER(1),
    dd4500_appliances_num INT,
    dd7200 NUMBER(1),
    dd7200_appliances_num INT,
    storage_expansion_shelves_num INT,
    system_ctrl_upgrades_num INT,
    FOREIGN KEY (upgrade_type_id) REFERENCES DataDomainUpgradeType (id)
)
/
CREATE TRIGGER TDataDomainUpgrade
BEFORE INSERT ON DataDomainUpgrade
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SDataDomainUpgrade.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SDataDomainVTL
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE DataDomainVTL (
    id NUMBER NOT NULL PRIMARY KEY,
    include_ibm_iseries_brms NUMBER(1),
    ibm_pars_num INT,
    vtl_appliances_num INT,
    install_fibre_cards_num INT,
    create_vtls_num INT
)
/
CREATE TRIGGER TDataDomainVTL
BEFORE INSERT ON DataDomainVTL
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SDataDomainVTL.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SDataDomainExpansionShelf
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE DataDomainExpansionShelf (
    id NUMBER NOT NULL PRIMARY KEY,
    storage_expansion_shelves_num INT
)
/
CREATE TRIGGER TDataDomainExpansionShelf
BEFORE INSERT ON DataDomainExpansionShelf
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SDataDomainExpansionShelf.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SDataDomainDataStaging
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE DataDomainDataStaging (
    id NUMBER NOT NULL PRIMARY KEY,
    data_staging_type_id NUMBER,
    FOREIGN KEY (data_staging_type_id) REFERENCES DataDomainDataStagingType (id)
)
/
CREATE TRIGGER TDataDomainDataStaging
BEFORE INSERT ON DataDomainDataStaging
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SDataDomainDataStaging.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SDataDomainIntegration
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE DataDomainIntegration (
    id NUMBER NOT NULL PRIMARY KEY,
    include_rman_scripting NUMBER(1),
    max_backup_window_time_id NUMBER,
    appliances_for_ddboost_num INT,
    servers_for_ddboost_num INT,
    ora_rman_backup_servers_num INT,
    ora_backup_config_servers_num INT,
    integration_type_id NUMBER,
    ibm_tivoli_storage_manager NUMBER(1),
    networker NUMBER(1),
    net_backup NUMBER(1),
    rman NUMBER(1),
    conducted_interviews_num INT,
    ibm_tsm_instances_num INT,
    networker_data_zones_num INT,
    sym_net_backup_domains_num INT,
    oracle_data_servers_num INT,
    sap_hana_databases_num INT,
    FOREIGN KEY (max_backup_window_time_id) REFERENCES DataDomainMaxBackupWindowTime (id),
    FOREIGN KEY (integration_type_id) REFERENCES DataDomainIntegrationType (id)
)
/
CREATE TRIGGER TDataDomainIntegration
BEFORE INSERT ON DataDomainIntegration
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SDataDomainIntegration.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SDataDomainHealthCheck
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE DataDomainHealthCheck (
    id NUMBER NOT NULL PRIMARY KEY,
    data_domain_appliances_num INT,
    assessment_interviews_num INT
)
/
CREATE TRIGGER TDataDomainHealthCheck
BEFORE INSERT ON DataDomainHealthCheck
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SDataDomainHealthCheck.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SDataDomainMigration
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE DataDomainMigration (
    id NUMBER NOT NULL PRIMARY KEY,
    migration_type_id NUMBER,
    centera2dd_migrations_num INT,
    dd2dd_migrations_num INT,
    monitoring_events_num INT,
    FOREIGN KEY (migration_type_id) REFERENCES DataDomainMigrationType (id)
)
/
CREATE TRIGGER TDataDomainMigration
BEFORE INSERT ON DataDomainMigration
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SDataDomainMigration.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SDataDomainPreRack
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE DataDomainPreRack (
    id NUMBER NOT NULL PRIMARY KEY,
    boost_backup_server_id NUMBER,
    integrate_sap_hana NUMBER(1),
    plan_design_implement_vtl NUMBER(1),
    include_ibm_iseries_brms NUMBER(1),
    ibm_pars_num INT,
    vtl_appliances_num INT,
    install_fibre_cards_num INT,
    create_vtls_num INT,
    backup_servers_num INT,
    appliances_for_ddboost_num INT,
    ora_rman_backup_servers_num INT,
    ora_backup_config_servers_num INT,
    sap_hana_databases_num INT,
    pre_rack_type_id NUMBER,
    pre_racked_system_racks_num INT,
    edl_virtual_tape_libs_num INT,
    servers_for_ddboost_num INT,
    FOREIGN KEY (pre_rack_type_id) REFERENCES DataDomainPreRackType (id),
    FOREIGN KEY (boost_backup_server_id) REFERENCES DataDomainBoostBackupServer (id)
)
/
CREATE TRIGGER TDataDomainPreRack
BEFORE INSERT ON DataDomainPreRack
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SDataDomainPreRack.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SDataDomainBoost
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE DataDomainBoost (
    id NUMBER NOT NULL PRIMARY KEY,
    include_rman_scripting NUMBER(1),
    max_backup_window_time_id NUMBER,
    appliances_for_ddboost_num INT,
    servers_for_ddboost_num INT,
    ora_rman_backup_servers_num INT,
    ora_backup_config_servers_num INT,
    boost_type_id NUMBER,
    FOREIGN KEY (max_backup_window_time_id) REFERENCES DataDomainMaxBackupWindowTime (id),
    FOREIGN KEY (boost_type_id) REFERENCES DataDomainBoostType (id)
)
/
CREATE TRIGGER TDataDomainBoost
BEFORE INSERT ON DataDomainBoost
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SDataDomainBoost.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SDataDomainExtRetentionConv
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE DataDomainExtRetentionConv (
    id NUMBER NOT NULL PRIMARY KEY,
    applicances_to_convert_num INT
)
/
CREATE TRIGGER TDataDomainExtRetentionConv
BEFORE INSERT ON DataDomainExtRetentionConv
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SDataDomainExtRetentionConv.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SDataDomainManCenterConf
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE DataDomainManCenterConf (
    id NUMBER NOT NULL PRIMARY KEY,
    management_center_config_type INT
)
/
CREATE TRIGGER TDataDomainManCenterConf
BEFORE INSERT ON DataDomainManCenterConf
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SDataDomainManCenterConf.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SDataDomainSapHana
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE DataDomainSapHana (
    id NUMBER NOT NULL PRIMARY KEY,
    sap_hana_databases_num INT
)
/
CREATE TRIGGER TDataDomainSapHana
BEFORE INSERT ON DataDomainSapHana
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SDataDomainSapHana.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SDataDomain
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE DataDomain (
    id NUMBER NOT NULL PRIMARY KEY,
    knowledge_transfer_hours DECIMAL(20,2),
    implement_service NUMBER(1),
    upgrade_service NUMBER(1),
    implement_vtl_service NUMBER(1),
    data_staging_service NUMBER(1),
    expansion_shelf_service NUMBER(1),
    integration_service NUMBER(1),
    health_check_service NUMBER(1),
    migration_service NUMBER(1),
    pre_racked_service NUMBER(1),
    boost_service NUMBER(1),
    ext_retention_conv_service NUMBER(1),
    mgmt_center_config_service NUMBER(1),
    sap_hana_service NUMBER(1),
    design_activity NUMBER(1),
    implementation_activity NUMBER(1),
    design_impl_identical NUMBER(1),
    design_id NUMBER,
    implementation_id NUMBER,
    upgrade_id NUMBER,
    vtl_id NUMBER,
    expansion_shelf_id NUMBER,
    data_staging_id NUMBER,
    integration_id NUMBER,
    health_check_id NUMBER,
    migration_id NUMBER,
    pre_rack_id NUMBER,
    boost_id NUMBER,
    ext_retention_conversion_id NUMBER,
    management_center_config_id NUMBER,
    sap_hana_id NUMBER,
    design_impl_content_id NUMBER,
    FOREIGN KEY (design_impl_content_id) REFERENCES DataDomainDesignImplContent (id),
    FOREIGN KEY (design_id) REFERENCES DataDomainDesign (id),
    FOREIGN KEY (implementation_id) REFERENCES DataDomainImplementation (id),
    FOREIGN KEY (upgrade_id) REFERENCES DataDomainUpgrade (id),
    FOREIGN KEY (vtl_id) REFERENCES DataDomainVTL (id),
    FOREIGN KEY (expansion_shelf_id) REFERENCES DataDomainExpansionShelf (id),
    FOREIGN KEY (data_staging_id) REFERENCES DataDomainDataStaging (id),
    FOREIGN KEY (integration_id) REFERENCES DataDomainIntegration (id),
    FOREIGN KEY (health_check_id) REFERENCES DataDomainHealthCheck (id),
    FOREIGN KEY (migration_id) REFERENCES DataDomainMigration (id),
    FOREIGN KEY (pre_rack_id) REFERENCES DataDomainPreRack (id),
    FOREIGN KEY (boost_id) REFERENCES DataDomainBoost (id),
    FOREIGN KEY (ext_retention_conversion_id) REFERENCES DataDomainExtRetentionConv (id),
    FOREIGN KEY (management_center_config_id) REFERENCES DataDomainManCenterConf (id),
    FOREIGN KEY (sap_hana_id) REFERENCES DataDomainSapHana (id)
)
/
CREATE TRIGGER TDataDomain
BEFORE INSERT ON DataDomain
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SDataDomain.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SDPADesign
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE DPADesign (
    id NUMBER NOT NULL PRIMARY KEY,
    install_on_extended_database NUMBER(1),
    include_analysis_jobs NUMBER(1),
    incl_recoverability_analysis NUMBER(1),
    incl_custom_report_dev NUMBER(1),
    incl_interface_customization NUMBER(1),
    include_scale_plan NUMBER(1),
    collection_nodes_num INT,
    collector_nodes_num INT
)
/
CREATE TRIGGER TDPADesign
BEFORE INSERT ON DPADesign
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SDPADesign.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SDPAImplementation
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE DPAImplementation (
    id NUMBER NOT NULL PRIMARY KEY,
    upgrade_from_v5_environment NUMBER(1),
    incl_custom_report_dev NUMBER(1),
    incl_interface_customization NUMBER(1),
    incl_recoverability_analysis NUMBER(1),
    include_analysis_jobs NUMBER(1),
    upgrade_install_on_ext_db NUMBER(1),
    upgrade_incl_edl_monitoring NUMBER(1),
    upgrade_collection_nodes_num INT,
    upgrade_collector_nodes_num INT,
    upgrade_emc_disk_libs_num INT,
    crd_install_on_ext_db NUMBER(1),
    crd_include_edl_monitoring NUMBER(1),
    crd_collection_nodes_num INT,
    crd_collector_nodes_num INT,
    crd_emc_disk_libraries_num INT,
    ic_install_on_ext_db NUMBER(1),
    ic_include_edl_monitoring NUMBER(1),
    ic_collection_nodes_num INT,
    ic_collector_nodes_num INT,
    ic_emc_disk_libraries_num INT,
    ra_install_on_ext_db NUMBER(1),
    ra_include_edl_monitoring NUMBER(1),
    ra_collection_nodes_num INT,
    ra_collector_nodes_num INT,
    ra_emc_disk_libraries_num INT,
    recoverability_agents_num INT,
    aj_install_on_ext_db NUMBER(1),
    aj_include_edl_monitoring NUMBER(1),
    aj_collection_nodes_num INT,
    aj_collector_nodes_num INT,
    aj_emc_disk_libraries_num INT,
    analysis_jobs_num INT
)
/
CREATE TRIGGER TDPAImplementation
BEFORE INSERT ON DPAImplementation
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SDPAImplementation.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SDPACustomization
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE DPACustomization (
    id NUMBER NOT NULL PRIMARY KEY,
    incl_third_party_integ_dev NUMBER(1),
    include_analysis_jobs NUMBER(1),
    incl_interface_customization NUMBER(1),
    incl_custom_report_dev NUMBER(1),
    tpid_include_req_workshop NUMBER(1),
    tpid_include_scale_plan NUMBER(1),
    tpid_collection_nodes_num INT,
    tpid_collector_nodes_num INT,
    aj_include_req_workshop NUMBER(1),
    aj_include_scale_plan NUMBER(1),
    aj_collection_nodes_num INT,
    aj_collector_nodes_num INT,
    analysis_jobs_num INT,
    ic_include_req_workshop NUMBER(1),
    ic_include_scale_plan NUMBER(1),
    ic_collection_nodes_num INT,
    ic_collector_nodes_num INT,
    crd_include_req_workshop NUMBER(1),
    crd_include_scale_plan NUMBER(1),
    crd_collection_nodes_num INT,
    crd_collector_nodes_num INT
)
/
CREATE TRIGGER TDPACustomization
BEFORE INSERT ON DPACustomization
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SDPACustomization.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SDPAOperationalAssurance
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE DPAOperationalAssurance (
    id NUMBER NOT NULL PRIMARY KEY,
    include_requirements_workshop NUMBER(1),
    analysis_site_impl_num INT
)
/
CREATE TRIGGER TDPAOperationalAssurance
BEFORE INSERT ON DPAOperationalAssurance
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SDPAOperationalAssurance.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SDPAUpgradeMigration
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE DPAUpgradeMigration (
    id NUMBER NOT NULL PRIMARY KEY,
    upgrade_migration_version INT,
    manual_migrations NUMBER(1),
    customization_migration NUMBER(1),
    estimated_migration_volumes INT,
    reconfigure_agents_num INT
)
/
CREATE TRIGGER TDPAUpgradeMigration
BEFORE INSERT ON DPAUpgradeMigration
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SDPAUpgradeMigration.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SDPAHealthCheck
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE DPAHealthCheck (
    id NUMBER NOT NULL PRIMARY KEY,
    site_implementations_num INT
)
/
CREATE TRIGGER TDPAHealthCheck
BEFORE INSERT ON DPAHealthCheck
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SDPAHealthCheck.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SDPA
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE DPA (
    id NUMBER NOT NULL PRIMARY KEY,
    knowledge_transfer_hours DECIMAL(20,2),
    implement_service NUMBER(1),
    operational_assurance_service NUMBER(1),
    customization_service NUMBER(1),
    upgrade_migration_service NUMBER(1),
    health_check_service NUMBER(1),
    design_activity NUMBER(1),
    implementation_activity NUMBER(1),
    design_id NUMBER,
    implementation_id NUMBER,
    operational_assurance_id NUMBER,
    customization_id NUMBER,
    upgrade_migration_id NUMBER,
    health_check_id NUMBER,
    FOREIGN KEY (design_id) REFERENCES DPADesign (id),
    FOREIGN KEY (implementation_id) REFERENCES DPAImplementation (id),
    FOREIGN KEY (operational_assurance_id) REFERENCES DPAOperationalAssurance (id),
    FOREIGN KEY (customization_id) REFERENCES DPACustomization (id),
    FOREIGN KEY (upgrade_migration_id) REFERENCES DPAUpgradeMigration (id),
    FOREIGN KEY (health_check_id) REFERENCES DPAHealthCheck (id)
)
/
CREATE TRIGGER TDPA
BEFORE INSERT ON DPA
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SDPA.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SNetworkerComponents
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE NetworkerComponents (
    id NUMBER NOT NULL PRIMARY KEY,
    server NUMBER(1),
    advanced_backup_tech NUMBER(1),
    storage_nodes NUMBER(1),
    file_system_client_backups NUMBER(1),
    media_devices NUMBER(1),
    application_backups NUMBER(1),
    emc_backup_recovery_manager NUMBER(1)
)
/
CREATE TRIGGER TNetworkerComponents
BEFORE INSERT ON NetworkerComponents
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SNetworkerComponents.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SNetworkerStorageNodes
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE NetworkerStorageNodes (
    id NUMBER NOT NULL PRIMARY KEY,
    storage_node NUMBER(1),
    dedicated_storage_node NUMBER(1),
    de_duplication_node NUMBER(1),
    storage_nodes_num INT,
    dedicated_storage_nodes_num INT,
    de_duplication_nodes_num INT
)
/
CREATE TRIGGER TNetworkerStorageNodes
BEFORE INSERT ON NetworkerStorageNodes
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SNetworkerStorageNodes.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SNetworkerMediaDevices
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE NetworkerMediaDevices (
    id NUMBER NOT NULL PRIMARY KEY,
    auto_changer NUMBER(1),
    dd_boost NUMBER(1),
    tape_device NUMBER(1),
    atmos NUMBER(1),
    advanced_file_type_device NUMBER(1),
    auto_changers_num INT,
    tape_devices_num INT,
    adv_file_type_devices_num INT,
    dd_boost_devices_num INT,
    atmos_devices_num INT
)
/
CREATE TRIGGER TNetworkerMediaDevices
BEFORE INSERT ON NetworkerMediaDevices
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SNetworkerMediaDevices.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SNetworkerServerDesign
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE NetworkerServerDesign (
    id NUMBER NOT NULL PRIMARY KEY,
    impl_env INT,
    servers_num INT
)
/
CREATE TRIGGER TNetworkerServerDesign
BEFORE INSERT ON NetworkerServerDesign
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SNetworkerServerDesign.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SNetAdvancedBackupTechDesign
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE NetAdvancedBackupTechDesign  (
    id NUMBER NOT NULL PRIMARY KEY,
    snmp NUMBER(1),
    vmware NUMBER(1),
    snapshot_management NUMBER(1),
    nas NUMBER(1),
    incl_vmware_protect_backups NUMBER(1),
    vmware_backup_appliances_num INT,
    snapshot_mgmt_app_hosts_num INT,
    snapshot_mgmt_mount_hosts_num INT,
    nas_data_movers_num INT,
    vmware_vsphere_hosts_num INT
)
/
CREATE TRIGGER TNetAdvancedBackupTechDesign
BEFORE INSERT ON NetAdvancedBackupTechDesign
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SNetAdvancedBackupTechDesign.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SNetFileSystemClientBackDesign
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE NetFileSystemClientBackDesign (
    id NUMBER NOT NULL PRIMARY KEY,
    clients_num INT,
    cluster_client_conn_num INT
)
/
CREATE TRIGGER TNetFileSystemClientBackDesign
BEFORE INSERT ON NetFileSystemClientBackDesign
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SNetFileSystemClientBackDesign.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SNetApplicationBackDesign
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE NetApplicationBackDesign (
    id NUMBER NOT NULL PRIMARY KEY,
    ms_sql NUMBER(1),
    exchange NUMBER(1),
    share_point NUMBER(1),
    hyperv NUMBER(1),
    oracle NUMBER(1),
    my_sql NUMBER(1),
    lotus_notes NUMBER(1),
    sap NUMBER(1),
    meditech NUMBER(1),
    include_mssql_server_cluster NUMBER(1),
    ms_sql_servers_num INT,
    impl_exch_granular_backups NUMBER(1),
    incl_clustered_exch_servers NUMBER(1),
    exchange_mailbox_servers_num INT,
    exchange_database_stores_num INT,
    share_point_incl_mssql_sc NUMBER(1),
    incl_gran_share_point_backups NUMBER(1),
    incl_share_point_dist_env NUMBER(1),
    share_point_mssql_servers_num INT,
    share_point_farms_num INT,
    share_point_web_apps_num INT,
    share_point_sites_num INT,
    share_point_sub_sites_num INT,
    hyperv_env_clustered NUMBER(1),
    hyperv_servers_num INT,
    clustered_oracle_servers NUMBER(1),
    ora_rman_backup_servers_num INT,
    ora_backup_config_dbs_num INT,
    my_sql_env_clustered NUMBER(1),
    my_sql_servers_num INT,
    lotus_notes_apps_clustered NUMBER(1),
    lotus_domino_instances_num INT,
    sap_env_clustered NUMBER(1),
    sap_app_servers_num INT,
    ms_sql_databases_num INT,
    exchange_data_domain_boost NUMBER(1),
    share_point_sql_databases_num INT,
    share_point_data_domain_boost NUMBER(1),
    incl_extensive_rman_scripting NUMBER(1),
    meditech_backup_type_id NUMBER,
    num_of_meditech_hosts INT,
    num_of_meditech_storage_arr INT,
    FOREIGN KEY (meditech_backup_type_id) REFERENCES MeditechBackupType (id)
)
/
CREATE TRIGGER TNetApplicationBackDesign
BEFORE INSERT ON NetApplicationBackDesign
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SNetApplicationBackDesign.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SNetworkerDesign
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE NetworkerDesign (
    id NUMBER NOT NULL PRIMARY KEY,
    components_id NUMBER,
    storage_nodes_id NUMBER,
    media_devices_id NUMBER,
    server_id NUMBER,
    advanced_backup_tech_id NUMBER,
    file_system_client_backups_id NUMBER,
    application_backups_id NUMBER,
    FOREIGN KEY (components_id) REFERENCES NetworkerComponents (id),
    FOREIGN KEY (storage_nodes_id) REFERENCES NetworkerStorageNodes (id),
    FOREIGN KEY (media_devices_id) REFERENCES NetworkerMediaDevices (id),
    FOREIGN KEY (server_id) REFERENCES NetworkerServerDesign (id),
    FOREIGN KEY (advanced_backup_tech_id) REFERENCES NetAdvancedBackupTechDesign (id),
    FOREIGN KEY (file_system_client_backups_id) REFERENCES NetFileSystemClientBackDesign (id),
    FOREIGN KEY (application_backups_id) REFERENCES NetApplicationBackDesign (id)
)
/
CREATE TRIGGER TNetworkerDesign
BEFORE INSERT ON NetworkerDesign
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SNetworkerDesign.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SNetworkerServerImpl
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE NetworkerServerImpl (
    id NUMBER NOT NULL PRIMARY KEY,
    impl_env INT,
    servers_num INT,
    management_consoles_num INT
)
/
CREATE TRIGGER TNetworkerServerImpl
BEFORE INSERT ON NetworkerServerImpl
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SNetworkerServerImpl.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SNetAdvancedBackupTechImpl
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE NetAdvancedBackupTechImpl (
    id NUMBER NOT NULL PRIMARY KEY,
    snmp NUMBER(1),
    vmware NUMBER(1),
    snapshot_management NUMBER(1),
    nas NUMBER(1),
    incl_vmware_protect_backups NUMBER(1),
    vmware_backup_appliances_num INT,
    snapshot_mgmt_app_hosts_num INT,
    snapshot_mgmt_mount_hosts_num INT,
    nas_data_movers_num INT,
    snmp_modules_num INT,
    ext_vmware_protect_app_num INT,
    virtual_machine_clients_num INT,
    emc_disk_arrays_num INT
)
/
CREATE TRIGGER TNetAdvancedBackupTechImpl
BEFORE INSERT ON NetAdvancedBackupTechImpl
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SNetAdvancedBackupTechImpl.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SNetFileSystemClientBackImpl
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE NetFileSystemClientBackImpl (
    id NUMBER NOT NULL PRIMARY KEY,
    clients_num INT,
    cluster_client_conn_num INT,
    firewall_support NUMBER(1)
)
/
CREATE TRIGGER TNetFileSystemClientBackImpl
BEFORE INSERT ON NetFileSystemClientBackImpl
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SNetFileSystemClientBackImpl.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SNetApplicationBackImpl
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE NetApplicationBackImpl (
    id NUMBER NOT NULL PRIMARY KEY,
    ms_sql NUMBER(1),
    exchange NUMBER(1),
    share_point NUMBER(1),
    hyperv NUMBER(1),
    oracle NUMBER(1),
    my_sql NUMBER(1),
    lotus_notes NUMBER(1),
    sap NUMBER(1),
    include_mssql_server_cluster NUMBER(1),
    ms_sql_servers_num INT,
    impl_exch_granular_backups NUMBER(1),
    incl_clustered_exch_servers NUMBER(1),
    exchange_mailbox_servers_num INT,
    exchange_database_stores_num INT,
    share_point_incl_mssql_sc NUMBER(1),
    incl_gran_share_point_backups NUMBER(1),
    incl_share_point_dist_env NUMBER(1),
    share_point_mssql_servers_num INT,
    share_point_farms_num INT,
    share_point_web_apps_num INT,
    share_point_sites_num INT,
    share_point_sub_sites_num INT,
    hyperv_env_clustered NUMBER(1),
    hyperv_servers_num INT,
    clustered_oracle_servers NUMBER(1),
    ora_rman_backup_servers_num INT,
    ora_backup_config_dbs_num INT,
    my_sql_env_clustered NUMBER(1),
    my_sql_servers_num INT,
    lotus_notes_apps_clustered NUMBER(1),
    lotus_domino_instances_num INT,
    sap_env_clustered NUMBER(1),
    sap_app_servers_num INT,
    ms_sql_incl_hardware_provider NUMBER(1),
    ms_sql_proxy_nodes_num INT,
    ms_sql_sc_nodes_num INT,
    exchange_incl_hw_provider NUMBER(1),
    exchange_proxy_nodes_num INT,
    exchange_db_stores_av_size INT,
    exchange_cluster_nodes_num INT,
    ccr_clusters_num INT,
    share_point_incl_hw_provider NUMBER(1),
    share_point_proxy_nodes_num INT,
    share_point_mssql_sc_node_num INT,
    share_point_phys_servers_num INT,
    hyperv_incl_hardware_provider NUMBER(1),
    hyperv_proxy_nodes_num INT,
    hyperv_nmm_configured NUMBER(1),
    hyperv_physical_servers_num INT,
    hyperv_virtual_machines_num INT,
    oracle_physical_servers_num INT,
    my_sql_physical_servers_num INT,
    lotus_notes_phys_servers_num INT,
    sap_physical_servers_num INT
)
/
CREATE TRIGGER TNetApplicationBackImpl
BEFORE INSERT ON NetApplicationBackImpl
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SNetApplicationBackImpl.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SNetworkerImplementation
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE NetworkerImplementation (
    id NUMBER NOT NULL PRIMARY KEY,
    select_datazone_size NUMERIC(1),
    datazone_size_id NUMBER,
    FOREIGN KEY (datazone_size_id) REFERENCES NetworkerDatazoneSize (id)
)
/
CREATE TRIGGER TNetworkerImplementation
BEFORE INSERT ON NetworkerImplementation
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SNetworkerImplementation.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SNetworkerUpgrade
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE NetworkerUpgrade (
    id NUMBER NOT NULL PRIMARY KEY,
    server NUMBER(1),
    storage_nodes NUMBER(1),
    clients NUMBER(1),
    management_console NUMBER(1),
    current_version INT,
    upgrade_version INT,
    upgrade_to_new_hardware NUMBER(1),
    servers_num INT,
    storage_nodes_num INT,
    clients_num INT,
    management_consoles_num INT
)
/
CREATE TRIGGER TNetworkerUpgrade
BEFORE INSERT ON NetworkerUpgrade
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SNetworkerUpgrade.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SNetWorkerHealthCheck
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE
/
CREATE TABLE NetWorkerHealthCheck (
    id NUMBER NOT NULL PRIMARY KEY,
    include_emc_assessment NUMERIC(1),
    data_zones_num INT,
    assessment_interviews_num INT
)
/
CREATE TRIGGER TNetWorkerHealthCheck
BEFORE INSERT ON NetWorkerHealthCheck
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SNetWorkerHealthCheck.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;
/

CREATE SEQUENCE SNetworker
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE Networker (
    id NUMBER NOT NULL PRIMARY KEY,
    knowledge_transfer_hours DECIMAL(20,2),
    implementation_service NUMBER(1),
    upgrade_planning_service NUMBER(1),
    health_check_service NUMBER(1),
    upgrade_service NUMBER(1),
    design_activity NUMBER(1),
    implementation_activity NUMBER(1),
    design_id NUMBER,
    implementation_id NUMBER,
    upgrade_id NUMBER,
    healthcheck_id NUMBER,
    FOREIGN KEY (design_id) REFERENCES NetworkerDesign (id),
    FOREIGN KEY (implementation_id) REFERENCES NetworkerImplementation (id),
    FOREIGN KEY (upgrade_id) REFERENCES NetworkerUpgrade (id),
    FOREIGN KEY (healthcheck_id) REFERENCES NetWorkerHealthCheck (id)
)
/
CREATE TRIGGER TNetworker
BEFORE INSERT ON Networker
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SNetworker.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SDPADServicesScope
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE DPADServicesScope (
    id NUMBER NOT NULL PRIMARY KEY,
    avamar NUMBER(1),
    data_domain NUMBER(1),
    dpa NUMBER(1),
    edl NUMBER(1),
    networker NUMBER(1),
    dlm NUMBER(1),
    recover_point NUMBER(1),
    mozy NUMBER(1)
)
/
CREATE TRIGGER TDPADServicesScope
BEFORE INSERT ON DPADServicesScope
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SDPADServicesScope.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SMozyCustom
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE
/
CREATE TABLE MozyCustom (
    id NUMBER NOT NULL PRIMARY KEY,
    account_setup_structure_config NUMBER(1),
    solutions_assurance NUMBER(1),
    branding NUMBER(1),
    federated_id_config NUMBER(1),
    develop_beta_plan_assist_roll NUMBER(1),
    administration_training NUMBER(1),
    api_workshop NUMBER(1),
    l1_support_training NUMBER(1),
    api_workshop_planning_hours DECIMAL(20,2),
    assist_pilot_rollout_hours DECIMAL(20,2),
    administration_training_hours DECIMAL(20,2),
    client_branding_hours DECIMAL(20,2),
    admin_console_branding_hours DECIMAL(20,2),
    web_access_branding_hours DECIMAL(20,2),
    api_workshop_hours DECIMAL(20,2),
    l1_support_training_hours DECIMAL(20,2)
)
/

CREATE SEQUENCE SMozyOEMBranding
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE
/
CREATE TABLE MozyOEMBranding (
    id NUMBER NOT NULL PRIMARY KEY,
    client_branding_hours DECIMAL(20,2),
    admin_console_hours DECIMAL(20,2),
    web_access_hours DECIMAL(20,2)
)
/

CREATE SEQUENCE SMozyOutTasking
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE
/
CREATE TABLE MozyOutTasking (
    id NUMBER NOT NULL PRIMARY KEY,
    start_date DATE,
    out_tasking_hours DECIMAL(20,2)
)
/


CREATE SEQUENCE SMozy
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE
/
CREATE TABLE Mozy (
    id NUMBER NOT NULL PRIMARY KEY,
    custom NUMBER(1),
    oem_branding NUMBER(1),
    out_tasking NUMBER(1),
    custom_id NUMBER,
    oem_branding_id NUMBER,
    out_tasking_id NUMBER,
    FOREIGN KEY (custom_id) REFERENCES MozyCustom (id),
    FOREIGN KEY (oem_branding_id) REFERENCES MozyOEMBranding (id),
    FOREIGN KEY (out_tasking_id) REFERENCES MozyOutTasking (id)
)
/

CREATE SEQUENCE SDPADRequestData
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE DPADRequestData (
    id NUMBER NOT NULL PRIMARY KEY,
    sites_involved VARCHAR2(256),
    general_comments VARCHAR2(256),
    services_scope_id NUMBER,
    avamar_id NUMBER,
    edl_id NUMBER,
    recover_point_id NUMBER,
    data_domain_id NUMBER,
    dpa_id NUMBER,
    networker_id NUMBER,
    mozy_id NUMBER,
    FOREIGN KEY (services_scope_id) REFERENCES DPADServicesScope (id),
    FOREIGN KEY (recover_point_id) REFERENCES RecoverPoint (id),
    FOREIGN KEY (edl_id) REFERENCES EDL (id),
    FOREIGN KEY (avamar_id) REFERENCES Avamar (id),
    FOREIGN KEY (data_domain_id) REFERENCES DataDomain (id),
    FOREIGN KEY (dpa_id) REFERENCES DPA (id),
    FOREIGN KEY (networker_id) REFERENCES Networker (id),
    FOREIGN KEY (mozy_id) REFERENCES Mozy (id)
)
/
CREATE TRIGGER TDPADRequestData
BEFORE INSERT ON DPADRequestData
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SDPADRequestData.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SCoreOptions
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE CoreOptions (
    id NUMBER NOT NULL PRIMARY KEY, 
    symm_os NUMBER(1),
    symm_mf NUMBER(1),
    vblock NUMBER(1),
    unified NUMBER(1),
    replication NUMBER(1),
    san NUMBER(1),
    isilon NUMBER(1),
    xtremeIO NUMBER(1),
    vplex NUMBER(1),
    cta NUMBER(1),
    mainframe NUMBER(1),
    change_request NUMBER(1)
)
/
CREATE TRIGGER TCoreOptions
BEFORE INSERT ON CoreOptions
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SCoreOptions.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SOtherRequestOptions
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE OtherRequestOptions (
    id NUMBER NOT NULL PRIMARY KEY, 
    residency NUMBER(1),
    i_series NUMBER(1),
    disk_retention NUMBER(1),
    move_request NUMBER(1),
    health_checks NUMBER(1),
    not_listed NUMBER(1)
)
/
CREATE TRIGGER TOtherRequestOptions
BEFORE INSERT ON OtherRequestOptions
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SOtherRequestOptions.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SDPADOptions
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE DPADOptions (
    id NUMBER NOT NULL PRIMARY KEY, 
    avamar NUMBER(1),
    source_one NUMBER(1),
    data_domain NUMBER(1),
    networker NUMBER(1),
    edl NUMBER(1),
    mozy NUMBER(1),
    dlm NUMBER(1),
    dpa NUMBER(1),
    recover_point NUMBER(1)
)
/
CREATE TRIGGER TDPADOptions
BEFORE INSERT ON DPADOptions
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SDPADOptions.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SASDOptions
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE ASDOptions (
    id NUMBER NOT NULL PRIMARY KEY, 
    srm NUMBER(1),
    app_sync NUMBER(1),
    atmos NUMBER(1),
    w4n NUMBER(1),
    centera NUMBER(1),
    vipr NUMBER(1),
    uim NUMBER(1),
    ncm NUMBER(1)
)
/
CREATE TRIGGER TASDOptions
BEFORE INSERT ON ASDOptions
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SASDOptions.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SAffinityOptions
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE AffinityOptions (
    id NUMBER NOT NULL PRIMARY KEY, 
    vmware NUMBER(1),
    pivotal NUMBER(1),
    rsa NUMBER(1),
    vce NUMBER(1),
    ecd NUMBER(1)
)
/
CREATE TRIGGER TAffinityOptions
BEFORE INSERT ON AffinityOptions
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SAffinityOptions.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SConsultingOptions
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE ConsultingOptions (
    id NUMBER NOT NULL PRIMARY KEY, 
    blue_printing NUMBER(1),
    dcm NUMBER(1),
    staff NUMBER(1),
    p2v NUMBER(1),
    vmware NUMBER(1)
)
/
CREATE TRIGGER TConsultingOptions
BEFORE INSERT ON ConsultingOptions
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SConsultingOptions.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SAttachment
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE Attachment (
  id NUMBER NOT NULL PRIMARY KEY, 
  attachment_filename VARCHAR2(256),
  attachment_filepath VARCHAR2(256),
  attachment_size NUMBER
)
/
CREATE TRIGGER TAttachment
BEFORE INSERT ON Attachment
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SAttachment.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SRequestContractData
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE RequestContractData (
    id NUMBER NOT NULL PRIMARY KEY, 
    sow_type_id NUMBER,
    customer_format_required NUMBER(1),
    services_agreement_type_id NUMBER,
    services_agreement_date TIMESTAMP,
    partner_information VARCHAR2(256),
    FOREIGN KEY (sow_type_id) REFERENCES SowType (id),
    FOREIGN KEY (services_agreement_type_id) REFERENCES ServicesAgreementType (id)
)
/
CREATE TRIGGER TRequestContractData
BEFORE INSERT ON RequestContractData
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SRequestContractData.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SStartRequestData
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE StartRequestData (
    id NUMBER NOT NULL PRIMARY KEY, 
    core_options_id NUMBER,
    dpad_options_id NUMBER,
    asd_options_id NUMBER,
    affinity_options_id NUMBER,
    consulting_options_id NUMBER,
    other_request_options_id NUMBER,
    selected_division_id NUMBER,
    selected_geography_id NUMBER,
    selected_state_id NUMBER,
    selected_district_id NUMBER,
    selected_pdm_name_id NUMBER,
    customer_name VARCHAR2(256),
    project_name VARCHAR2(256),
    project_type_id NUMBER,
    work_city VARCHAR2(256),
    dx_quote_number VARCHAR2(256),
    se_csd_name VARCHAR2(256),
    pdm_name VARCHAR2(256),
    pm_name VARCHAR2(256),
    sfdc_number VARCHAR2(256),
    se_csd_phone_country_code VARCHAR2(256),
    se_csd_phone_number VARCHAR2(256),
    meeting_status_id NUMBER,
    se_manager_name VARCHAR2(256),
    program_delivery_manager_name VARCHAR2(256),
    risk_level_id NUMBER,
    sow_language_id NUMBER,
    phone_call_request NUMBER(1),
    reseller_sold NUMBER(1),
    requested_return_date TIMESTAMP,
    return_equipment NUMBER(1),
    remote_access NUMBER(1),
    clearance_level_id NUMBER,
    request_contract_data_id NUMBER,
    service_request_scope CLOB,
    travel_requirements VARCHAR2(256),
    expense_type_id NUMBER,
    oracle_party_id NUMBER,
    FOREIGN KEY (core_options_id) REFERENCES CoreOptions (id),
    FOREIGN KEY (dpad_options_id) REFERENCES DPADOptions (id),
    FOREIGN KEY (asd_options_id) REFERENCES ASDOptions (id),
    FOREIGN KEY (affinity_options_id) REFERENCES AffinityOptions (id),
    FOREIGN KEY (consulting_options_id) REFERENCES ConsultingOptions (id),
    FOREIGN KEY (other_request_options_id) REFERENCES OtherRequestOptions (id),
    FOREIGN KEY (selected_division_id) REFERENCES Division (id),
    FOREIGN KEY (selected_geography_id) REFERENCES Geography (id),
    FOREIGN KEY (selected_state_id) REFERENCES GeoState (id),
    FOREIGN KEY (selected_district_id) REFERENCES SalesDistrict (id),
    FOREIGN KEY (selected_pdm_name_id) REFERENCES PdmName (id),
    FOREIGN KEY (project_type_id) REFERENCES ProjectType (id),
    FOREIGN KEY (meeting_status_id) REFERENCES MeetingStatus (id),
    FOREIGN KEY (risk_level_id) REFERENCES RiskLevel (id),
    FOREIGN KEY (sow_language_id) REFERENCES SowLanguage (id),
    FOREIGN KEY (clearance_level_id) REFERENCES ClearanceLevel (id),
    FOREIGN KEY (request_contract_data_id) REFERENCES RequestContractData (id),
    FOREIGN KEY (expense_type_id) REFERENCES ExpenseType (id)
)
/
CREATE TRIGGER TStartRequestData
BEFORE INSERT ON StartRequestData
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SStartRequestData.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SStartRequestData_attachments
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE StartRequestData_attachments (
    id NUMBER NOT NULL PRIMARY KEY, 
    start_request_data_id NUMBER,
    attachment_id NUMBER,
    FOREIGN KEY (start_request_data_id) REFERENCES StartRequestData (id),
    FOREIGN KEY (attachment_id) REFERENCES Attachment (id)
)
/
CREATE TRIGGER TStartRequestData_attachments
BEFORE INSERT ON StartRequestData_attachments
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SStartRequestData_attachments.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SSiteInformation
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE SiteInformation (
    id NUMBER NOT NULL PRIMARY KEY,
    address VARCHAR2(2048),
    trailer_access NUMBER(1),
    loading_docks NUMBER(1),
    second_floor NUMBER(1),
    lift_gate NUMBER(1),
    packing_date VARCHAR2(2048),
    pickup_date VARCHAR2(2048),
    delivery_date VARCHAR2(2048)
)
/
CREATE TRIGGER TSiteInformation
BEFORE INSERT ON SiteInformation
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SSiteInformation.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SMoveRequestData
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE MoveRequestData (
    id NUMBER NOT NULL PRIMARY KEY,
    general_comments VARCHAR2(2048),
    description VARCHAR2(2048),
    after_hours_mss NUMBER(1),
    project_timeline VARCHAR2(2048),
    target_date VARCHAR2(2048),
    emc_racks_cnt INT,
    non_emc_racks_cnt INT,
    no_rack VARCHAR2(2048),
    equip_no_maint_contract NUMBER(1),
    emc_mv_svcs NUMBER(1),
    after_hours_pickup NUMBER(1),
    single_event NUMBER(1),
    cfg_reset NUMBER(1),
    emc_packing_needed NUMBER(1),
    total_value VARCHAR2(2048),
    comments VARCHAR2(2048),
    shipping_timeline VARCHAR2(2048),
    equipment VARCHAR2(2048),
    recertification_required NUMBER(1),
    scope_move_services NUMBER(1) DEFAULT 0 NOT NULL,
    scope_power_up_down NUMBER(1) DEFAULT 0 NOT NULL,
    scope_reinstall NUMBER(1) DEFAULT 0 NOT NULL,
    scope_configuration NUMBER(1) DEFAULT 0 NOT NULL,
    pu_equipment VARCHAR2(2048),
    install_equipment VARCHAR2(2048),
    ip_change_required NUMBER(1),
    cust_requirements VARCHAR2(2048)
)
/
CREATE TRIGGER TMoveRequestData
BEFORE INSERT ON MoveRequestData
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SMoveRequestData.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE TABLE MoveRequestData_SI (
    move_request_data_id NUMBER NOT NULL,
    site_information_id NUMBER NOT NULL,
    FOREIGN KEY (move_request_data_id) REFERENCES MoveRequestData (id),
    FOREIGN KEY (site_information_id) REFERENCES SiteInformation (id)
)
/

CREATE SEQUENCE SChangeRequestData
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE ChangeRequestData (
    id NUMBER NOT NULL PRIMARY KEY,
    general_comments VARCHAR2(2048),    
    no_of_months INT
)
/
CREATE TRIGGER TChangeRequestData
BEFORE INSERT ON ChangeRequestData
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SChangeRequestData.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SChangeRequestData_HBM
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE ChangeRequestData_HBM (
    id NUMBER NOT NULL PRIMARY KEY,
    rows_id NUMBER,
    ChangeRequestData_id NUMBER,
    FOREIGN KEY (ChangeRequestData_id) REFERENCES ChangeRequestData (id)
)
/
CREATE TRIGGER TChangeRequestData_HBM
BEFORE INSERT ON ChangeRequestData_HBM
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SChangeRequestData_HBM.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SHoursByMonth
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE HoursByMonth (
    id NUMBER NOT NULL PRIMARY KEY,
    sap_wbs_element_no VARCHAR2(2048)
)
/
CREATE TRIGGER THoursByMonth
BEFORE INSERT ON HoursByMonth
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SHoursByMonth.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SHoursByMonth_RoleHoursByMonth
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE HoursByMonth_RoleHoursByMonth (
    id NUMBER NOT NULL PRIMARY KEY,
    rows_id NUMBER,
    HoursByMonth_id NUMBER,
    FOREIGN KEY (HoursByMonth_id) REFERENCES HoursByMonth (id)
)
/
CREATE TRIGGER THoursByMonth_RoleHoursByMonth
BEFORE INSERT ON HoursByMonth_RoleHoursByMonth
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SHoursByMonth_RoleHoursByMonth.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SRoleHoursByMonth
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE RoleHoursByMonth (
    id NUMBER NOT NULL PRIMARY KEY,
    role VARCHAR2(2048)
)
/
CREATE TRIGGER TRoleHoursByMonth
BEFORE INSERT ON RoleHoursByMonth
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SRoleHoursByMonth.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SRoleHoursByMonth_Hours
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE RoleHoursByMonth_Hours (
    id NUMBER NOT NULL PRIMARY KEY,
    month_num INT,
    hours VARCHAR2(10),
    RoleHoursByMonth_id NUMBER,
    FOREIGN KEY (RoleHoursByMonth_id) REFERENCES RoleHoursByMonth (id)
)
/
CREATE TRIGGER TRoleHoursByMonth_Hours
BEFORE INSERT ON RoleHoursByMonth_Hours
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SRoleHoursByMonth_Hours.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/


CREATE SEQUENCE SCollector
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE Collector (
    id NUMBER NOT NULL PRIMARY KEY, 
    name VARCHAR2(256) NOT NULL
)
/
CREATE TRIGGER TCollector
BEFORE INSERT ON Collector
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SCollector.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/
CREATE SEQUENCE SDCSolutionPack
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE DCSolutionPack (
    id NUMBER NOT NULL PRIMARY KEY, 
    name VARCHAR2(256) NOT NULL
)
/
CREATE TRIGGER TDCSolutionPack
BEFORE INSERT ON DCSolutionPack
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SDCSolutionPack.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/
CREATE SEQUENCE SEMCSolutionPack
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE EMCSolutionPack (
    id NUMBER NOT NULL PRIMARY KEY, 
    name VARCHAR2(256) NOT NULL
)
/
CREATE TRIGGER TEMCSolutionPack
BEFORE INSERT ON EMCSolutionPack
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SEMCSolutionPack.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/
CREATE SEQUENCE SMobileSolutionPack
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE MobileSolutionPack (
    id NUMBER NOT NULL PRIMARY KEY, 
    name VARCHAR2(256) NOT NULL
)
/
CREATE TRIGGER TMobileSolutionPack
BEFORE INSERT ON MobileSolutionPack
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SMobileSolutionPack.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/
CREATE SEQUENCE SNetworkReportPack
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE NetworkReportPack (
    id NUMBER NOT NULL PRIMARY KEY, 
    name VARCHAR2(256) NOT NULL
)
/
CREATE TRIGGER TNetworkReportPack
BEFORE INSERT ON NetworkReportPack
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SNetworkReportPack.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/
CREATE SEQUENCE SServerReportPack
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE ServerReportPack (
    id NUMBER NOT NULL PRIMARY KEY, 
    name VARCHAR2(256) NOT NULL
)
/
CREATE TRIGGER TServerReportPack
BEFORE INSERT ON ServerReportPack
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SServerReportPack.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/
CREATE SEQUENCE SSmartsDomainType
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE SmartsDomainType (
    id NUMBER NOT NULL PRIMARY KEY, 
    name VARCHAR2(256) NOT NULL
)
/
CREATE TRIGGER TSmartsDomainType
BEFORE INSERT ON SmartsDomainType
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SSmartsDomainType.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/
CREATE SEQUENCE SStorageReportPack
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE StorageReportPack (
    id NUMBER NOT NULL PRIMARY KEY, 
    name VARCHAR2(256) NOT NULL
)
/
CREATE TRIGGER TStorageReportPack
BEFORE INSERT ON StorageReportPack
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SStorageReportPack.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/
CREATE SEQUENCE SVOIPSolutionPack
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE VOIPSolutionPack (
    id NUMBER NOT NULL PRIMARY KEY, 
    name VARCHAR2(256) NOT NULL
)
/
CREATE TRIGGER TVOIPSolutionPack
BEFORE INSERT ON VOIPSolutionPack
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SVOIPSolutionPack.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/
CREATE SEQUENCE SVPNReportPack
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE VPNReportPack (
    id NUMBER NOT NULL PRIMARY KEY, 
    name VARCHAR2(256) NOT NULL
)
/
CREATE TRIGGER TVPNReportPack
BEFORE INSERT ON VPNReportPack
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SVPNReportPack.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/
CREATE SEQUENCE SWANAccelerator
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE WANAccelerator (
    id NUMBER NOT NULL PRIMARY KEY, 
    name VARCHAR2(256) NOT NULL
)
/
CREATE TRIGGER TWANAccelerator
BEFORE INSERT ON WANAccelerator
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SWANAccelerator.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/
CREATE SEQUENCE SWiFiReportPack
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE WiFiReportPack (
    id NUMBER NOT NULL PRIMARY KEY, 
    name VARCHAR2(256) NOT NULL
)
/
CREATE TRIGGER TWiFiReportPack
BEFORE INSERT ON WiFiReportPack
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SWiFiReportPack.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SSRMRequestData
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE SRMRequestData (
    id NUMBER NOT NULL PRIMARY KEY,
    new_install NUMBER(1),
    migration NUMBER(1),
    v_app NUMBER(1),
    emc_control_center NUMBER(1),
    onsite_or_remote NUMBER(1),
    keyboard_access NUMBER(1),
    general_comments VARCHAR2(2048),
    aix_vio INT,
    brocade INT,
    cisco_mds INT,
    cisco_ucs INT,
    converged_infra INT,
    data_centers INT,
    data_domain INT,
    emc_atmos INT,
    emc_avamar INT,
    emc_centera INT,
    emc_data_prot_adv INT,
    emc_isilon_nas INT,
    emc_recover_pt INT,
    emc_vipr INT,
    emc_vmax_symm INT,
    emc_vnx_block INT,
    emc_vnx_file_nas INT,
    emc_vplex INT,
    vmware_esx_servers INT,
    xtrem_io INT,
    hitachi_dev_mgr INT,
    hp_par_store INT,
    hp_eva INT,
    hp_storage_works INT,
    hyperv INT,
    ibm_ds_series INT,
    ibm_san_vol_contrlr INT,
    ibm_svc INT,
    ibm_xiv INT,
    net_app_filer_nas INT,
    oracle INT,
    physical_hosts INT,
    san_ports INT,
    vi_san_perf_probes INT
)
/
CREATE TRIGGER TSRMRequestData
BEFORE INSERT ON SRMRequestData
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SSRMRequestData.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SW4NData
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE W4NData (
    id NUMBER NOT NULL PRIMARY KEY,
    general_comments VARCHAR2(2048),
    w4n_install NUMBER(1) DEFAULT 0 NOT NULL,
    w4n_upgrade NUMBER(1) DEFAULT 0 NOT NULL,
    existing_smarts_cust NUMBER(1) DEFAULT 0 NOT NULL,
    add_lab_install NUMBER(1) DEFAULT 0 NOT NULL,
    itpr_migration NUMBER(1) DEFAULT 0 NOT NULL,
    w4n_failover NUMBER(1),
    total_managed_devices INT,
    total_managed_pi INT,
    other_not_listed VARCHAR2(1024),
    number_luns INT,
    number_disks INT,
    number_arrays INT,
    storage_soln_pack NUMBER(1),
    traffic_flows NUMBER(1),
    transactions NUMBER(1),
    enabled_flows_count INT
)
/
CREATE TRIGGER TW4NData
BEFORE INSERT ON W4NData
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SW4NData.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SW4NData_SmartsDomainType
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE W4NData_SmartsDomainType (
    id NUMBER NOT NULL PRIMARY KEY, 
    w4n_data_id NUMBER,
    smarts_domain_type_id NUMBER,
    FOREIGN KEY (w4n_data_id) REFERENCES W4NData (id),
    FOREIGN KEY (smarts_domain_type_id) REFERENCES SmartsDomainType (id)
)
/
CREATE TRIGGER TW4NData_SmartsDomainType
BEFORE INSERT ON W4NData_SmartsDomainType
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SW4NData_SmartsDomainType.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SW4NData_EMCSolutionPack
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE W4NData_EMCSolutionPack (
    id NUMBER NOT NULL PRIMARY KEY, 
    w4n_data_id NUMBER,
    EMCSolutionPack_id NUMBER,
    FOREIGN KEY (w4n_data_id) REFERENCES W4NData (id),
    FOREIGN KEY (EMCSolutionPack_id) REFERENCES EMCSolutionPack (id)
)
/
CREATE TRIGGER TW4NData_EMCSolutionPack
BEFORE INSERT ON W4NData_EMCSolutionPack
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SW4NData_EMCSolutionPack.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SW4NData_WiFiReportPack
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE W4NData_WiFiReportPack (
    id NUMBER NOT NULL PRIMARY KEY, 
    w4n_data_id NUMBER,
    WiFiReportPack_id NUMBER,
    FOREIGN KEY (w4n_data_id) REFERENCES W4NData (id),
    FOREIGN KEY (WiFiReportPack_id) REFERENCES WiFiReportPack (id)
)
/
CREATE TRIGGER TW4NData_WiFiReportPack
BEFORE INSERT ON W4NData_WiFiReportPack
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SW4NData_WiFiReportPack.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SW4NData_DCSolutionPack
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE W4NData_DCSolutionPack (
    id NUMBER NOT NULL PRIMARY KEY, 
    w4n_data_id NUMBER,
    DCSolutionPack_id NUMBER,
    FOREIGN KEY (w4n_data_id) REFERENCES W4NData (id),
    FOREIGN KEY (DCSolutionPack_id) REFERENCES DCSolutionPack (id)
)
/
CREATE TRIGGER TW4NData_DCSolutionPack
BEFORE INSERT ON W4NData_DCSolutionPack
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SW4NData_DCSolutionPack.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SW4NData_VOIPSolutionPack
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE W4NData_VOIPSolutionPack (
    id NUMBER NOT NULL PRIMARY KEY, 
    w4n_data_id NUMBER,
    VOIPSolutionPack_id NUMBER,
    FOREIGN KEY (w4n_data_id) REFERENCES W4NData (id),
    FOREIGN KEY (VOIPSolutionPack_id) REFERENCES VOIPSolutionPack (id)
)
/
CREATE TRIGGER TW4NData_VOIPSolutionPack
BEFORE INSERT ON W4NData_VOIPSolutionPack
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SW4NData_VOIPSolutionPack.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SW4NData_MobileSolutionPack
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE W4NData_MobileSolutionPack (
    id NUMBER NOT NULL PRIMARY KEY, 
    w4n_data_id NUMBER,
    MobileSolutionPack_id NUMBER,
    FOREIGN KEY (w4n_data_id) REFERENCES W4NData (id),
    FOREIGN KEY (MobileSolutionPack_id) REFERENCES MobileSolutionPack (id)
)
/
CREATE TRIGGER TW4NData_MobileSolutionPack
BEFORE INSERT ON W4NData_MobileSolutionPack
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SW4NData_MobileSolutionPack.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SW4NData_Collector
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE W4NData_Collector (
    id NUMBER NOT NULL PRIMARY KEY, 
    w4n_data_id NUMBER,
    Collector_id NUMBER,
    FOREIGN KEY (w4n_data_id) REFERENCES W4NData (id),
    FOREIGN KEY (Collector_id) REFERENCES Collector (id)
)
/
CREATE TRIGGER TW4NData_Collector
BEFORE INSERT ON W4NData_Collector
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SW4NData_Collector.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SW4NData_NetworkReportPack
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE W4NData_NetworkReportPack (
    id NUMBER NOT NULL PRIMARY KEY, 
    w4n_data_id NUMBER,
    NetworkReportPack_id NUMBER,
    FOREIGN KEY (w4n_data_id) REFERENCES W4NData (id),
    FOREIGN KEY (NetworkReportPack_id) REFERENCES NetworkReportPack (id)
)
/
CREATE TRIGGER TW4NData_NetworkReportPack
BEFORE INSERT ON W4NData_NetworkReportPack
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SW4NData_NetworkReportPack.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SW4NData_VPNReportPack
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE W4NData_VPNReportPack (
    id NUMBER NOT NULL PRIMARY KEY, 
    w4n_data_id NUMBER,
    VPNReportPack_id NUMBER,
    FOREIGN KEY (w4n_data_id) REFERENCES W4NData (id),
    FOREIGN KEY (VPNReportPack_id) REFERENCES VPNReportPack (id)
)
/
CREATE TRIGGER TW4NData_VPNReportPack
BEFORE INSERT ON W4NData_VPNReportPack
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SW4NData_VPNReportPack.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SW4NData_WANAccelerator
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE W4NData_WANAccelerator (
    id NUMBER NOT NULL PRIMARY KEY, 
    w4n_data_id NUMBER,
    WANAccelerator_id NUMBER,
    FOREIGN KEY (w4n_data_id) REFERENCES W4NData (id),
    FOREIGN KEY (WANAccelerator_id) REFERENCES WANAccelerator (id)
)
/
CREATE TRIGGER TW4NData_WANAccelerator
BEFORE INSERT ON W4NData_WANAccelerator
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SW4NData_WANAccelerator.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SW4NData_ServerReportPack
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE W4NData_ServerReportPack (
    id NUMBER NOT NULL PRIMARY KEY, 
    w4n_data_id NUMBER,
    ServerReportPack_id NUMBER,
    FOREIGN KEY (w4n_data_id) REFERENCES W4NData (id),
    FOREIGN KEY (ServerReportPack_id) REFERENCES ServerReportPack (id)
)
/
CREATE TRIGGER TW4NData_ServerReportPack
BEFORE INSERT ON W4NData_ServerReportPack
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SW4NData_ServerReportPack.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SW4NData_StorageReportPack
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE W4NData_StorageReportPack (
    id NUMBER NOT NULL PRIMARY KEY, 
    w4n_data_id NUMBER,
    StorageReportPack_id NUMBER,
    FOREIGN KEY (w4n_data_id) REFERENCES W4NData (id),
    FOREIGN KEY (StorageReportPack_id) REFERENCES StorageReportPack (id)
)
/
CREATE TRIGGER TW4NData_StorageReportPack
BEFORE INSERT ON W4NData_StorageReportPack
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SW4NData_StorageReportPack.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SUnfundedProjectData
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE UnfundedProjectData (
    id NUMBER NOT NULL PRIMARY KEY,
    general_comments VARCHAR2(2048),
    summary VARCHAR2(1024),
    roi VARCHAR2(1024),
    environment_type VARCHAR2(1024),
    est_book_value DECIMAL,
    purchase_decision_dt TIMESTAMP,
    special_req VARCHAR2(1024),
    start_dt TIMESTAMP,
    end_dt TIMESTAMP
)
/
CREATE TRIGGER TUnfundedProjectData
BEFORE INSERT ON UnfundedProjectData
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SUnfundedProjectData.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SXtremeDataMobilityType
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE
/
CREATE TABLE XtremeDataMobilityType (
    id NUMBER NOT NULL PRIMARY KEY, 
    name VARCHAR2(256) NOT NULL
)
/

CREATE SEQUENCE SXtremeServices
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE
/
CREATE TABLE XtremeServices (
    id NUMBER NOT NULL PRIMARY KEY,
    design_and_impl NUMBER(1),
    cluster_expansion NUMBER(1),
    cache NUMBER(1),
    sf NUMBER(1),
    oracle_local_replication NUMBER(1)
)
/

CREATE SEQUENCE SXtremeDataMigration
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE
/
CREATE TABLE XtremeDataMigration (
    id NUMBER NOT NULL PRIMARY KEY,
    planning_and_design NUMBER(1),
    impl_and_migration NUMBER(1),
    xtreme_host_migration_tool_id NUMBER,
    hosts_migrated_by_migrator_num INT,
    hosts_migrated_by_ppme_num INT,
    include_esx_host_mig_vmotion NUMBER(1),
    rcli_installs_num INT,
    vmware_vm_vmotion_storage_num INT,
    storage_vmotion_addit_hours DECIMAL(20,2),
    implement_vplex_data_mobility NUMBER(1),
    xtreme_data_mobility_type_id NUMBER,
    use_encapsulation_under_vplex NUMBER(1),
    storage_volums_vplex_num INT,
    vplex_virtual_volumes_num INT,
    vplex_mirrors_num INT,
    vplex_data_mobility_jobs_num INT,
    implement_xtreme_io_snapshots NUMBER(1),
    swing_frame_box_required NUMBER(1),
    swing_box_hosts_emc_num INT,
    swing_box_hosts_migrator_num INT,
    swing_box_hosts_ppme_num INT,
    include_vmware_35_infra NUMBER(1),
    total_source_target_sites_num INT,
    new_physical_hosts_design_num INT,
    new_esx_servers_in_design_num INT,
    new_enterprise_directors_num INT,
    new_departmental_switches_num INT,
    new_vnx_block_stor_arrays_num INT,
    new_symmetrix_stor_arrays_num INT,
    vnx_blocks_to_upgrade_num INT,
    symmetrix_to_upgrade_num INT,
    total_source_arrays_num INT,
    total_target_arrays_num INT,
    device_size_changes_required NUMBER(1),
    source_data_amount_to_migrate INT,
    hosts_to_migrate_by_emc_num INT,
    total_hosts_to_migrate_num INT,
    customer_zonning_switches NUMBER(1),
    hosts_booted_from_san_num INT,
    customer_lun_device_allocation NUMBER(1),    
    FOREIGN KEY (xtreme_host_migration_tool_id) REFERENCES XtremeHostBasedMigrationTool (id),
    FOREIGN KEY (xtreme_data_mobility_type_id) REFERENCES XtremeDataMobilityType (id)
)
/

CREATE SEQUENCE SXtremeDesignImpl
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE
/
CREATE TABLE XtremeDesignImpl (
    id NUMBER NOT NULL PRIMARY KEY,
    emc_customer_rack NUMBER(1),
    cluster_config_2_4_bricks NUMBER(1),
    additional_testing NUMBER(1),
    additional_monitoring NUMBER(1),
    scripting_work NUMBER(1),
    include_emc_equipment_removal NUMBER(1),
    include_xtreme_io_migration NUMBER(1),
    xtreme_io_clusters_num NUMBER,
    xtreme_io_bricks_num NUMBER,
    xtreme_io_hosts_num NUMBER,
    xtreme_snapshots_num NUMBER,
    xtreme_io_bricks_added_num NUMBER,
    deployed_infin_switches_num NUMBER,
    xtreme_data_migration_id NUMBER,
    FOREIGN KEY (xtreme_data_migration_id) REFERENCES XtremeDataMigration (id)
)
/

CREATE SEQUENCE SXtremeCache
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE
/
CREATE TABLE XtremeCache (
    id NUMBER NOT NULL PRIMARY KEY,
    is_assessment NUMBER(1),
    flash_cards_num NUMBER,
    include_cache_install_config NUMBER(1),
    cache_install_hosts_num NUMBER
)
/

CREATE SEQUENCE SXtremeSF
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE
/
CREATE TABLE XtremeSF (
    id NUMBER NOT NULL PRIMARY KEY,
    flash_cards_num NUMBER,
    cards_install_hosts_num NUMBER,
    cache_install_hosts_num NUMBER
)
/

CREATE SEQUENCE SXtremeOracleLocalReplication
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE
/
CREATE TABLE XtremeOracleLocalReplication (
    id NUMBER NOT NULL PRIMARY KEY,
    perform_planning_design_shots NUMBER(1),
    functional_overview_hours DECIMAL(20,2)
)
/


CREATE SEQUENCE SXtremeRequestData
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE
/
CREATE TABLE XtremeRequestData (
    id NUMBER NOT NULL PRIMARY KEY,
    knowledge_transfer_hours DECIMAL(20,2),
    general_comments VARCHAR2(2048),
    xtreme_design_impl_id NUMBER,
    xtreme_services_id NUMBER,
    xtreme_cache_id NUMBER,
    xtreme_sf_id NUMBER,
    xtreme_oracle_local_repl_id NUMBER,
    FOREIGN KEY (xtreme_design_impl_id) REFERENCES XtremeDesignImpl (id),
    FOREIGN KEY (xtreme_services_id) REFERENCES XtremeServices (id),
    FOREIGN KEY (xtreme_cache_id) REFERENCES XtremeCache (id),
    FOREIGN KEY (xtreme_sf_id) REFERENCES XtremeSF (id),
    FOREIGN KEY (xtreme_oracle_local_repl_id) REFERENCES XtremeOracleLocalReplication (id)
)
/


CREATE SEQUENCE SMultipleTheatersLangsInvOpt
INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE
/

CREATE TABLE MultipleTheatersLangsInvOpt (
  id NUMBER NOT NULL PRIMARY KEY,
  name VARCHAR(256),
  risk INT
)
/

CREATE SEQUENCE SMultipleWorkgroupsDiscOpt
INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE
/

CREATE TABLE MultipleWorkgroupsDiscOpt (
  id NUMBER NOT NULL PRIMARY KEY,
  name VARCHAR(256),
  risk INT
)
/

CREATE SEQUENCE SEMCClientOption
INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE
/

CREATE TABLE EMCClientOption (
  id NUMBER NOT NULL PRIMARY KEY,
  name VARCHAR(256),
  risk INT
)
/

CREATE SEQUENCE SEMCClientRelationshipOption
INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE
/

CREATE TABLE EMCClientRelationshipOption (
  id NUMBER NOT NULL PRIMARY KEY,
  name VARCHAR(256),
  risk INT
)
/

CREATE SEQUENCE SProcessStaffMaturityOption
INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE
/

CREATE TABLE ProcessStaffMaturityOption (
  id NUMBER NOT NULL PRIMARY KEY,
  name VARCHAR(256),
  risk INT
)
/

CREATE SEQUENCE SClientEnvDocumentationOption
INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE
/

CREATE TABLE ClientEnvDocumentationOption (
  id NUMBER NOT NULL PRIMARY KEY,
  name VARCHAR(256),
  risk INT
)
/

CREATE SEQUENCE SProjectScopeUnderstandOption
INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE
/

CREATE TABLE ProjectScopeUnderstandOption (
  id NUMBER NOT NULL PRIMARY KEY,
  name VARCHAR(256),
  risk INT
)
/

CREATE SEQUENCE SProjectImpactOption
INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE
/

CREATE TABLE ProjectImpactOption (
  id NUMBER NOT NULL PRIMARY KEY,
  name VARCHAR(256),
  risk INT
)
/

CREATE SEQUENCE SProjectSponsorInvOption
INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE
/

CREATE TABLE ProjectSponsorInvOption (
  id NUMBER NOT NULL PRIMARY KEY,
  name VARCHAR(256),
  risk INT
)
/

CREATE SEQUENCE SOfferingMaturityOption
INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE
/

CREATE TABLE OfferingMaturityOption (
  id NUMBER NOT NULL PRIMARY KEY,
  name VARCHAR(256),
  risk INT
)
/

CREATE SEQUENCE SProjectComplexityLevelOption
INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE
/

CREATE TABLE ProjectComplexityLevelOption (
  id NUMBER NOT NULL PRIMARY KEY,
  name VARCHAR(256),
  risk INT
)
/

CREATE SEQUENCE SExternalFactorsOption
INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE
/

CREATE TABLE ExternalFactorsOption (
  id NUMBER NOT NULL PRIMARY KEY,
  name VARCHAR(256),
  risk INT
)
/

CREATE SEQUENCE SEMCStaffAvailabilityOption
INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE
/

CREATE TABLE EMCStaffAvailabilityOption (
  id NUMBER NOT NULL PRIMARY KEY,
  name VARCHAR(256),
  risk INT
)
/

CREATE SEQUENCE SPartnerStaffAvailOption
INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE
/

CREATE TABLE PartnerStaffAvailOption (
  id NUMBER NOT NULL PRIMARY KEY,
  name VARCHAR(256),
  risk INT
)
/

CREATE SEQUENCE SRiskLevelOption
INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE
/

CREATE TABLE RiskLevelOption (
  id NUMBER NOT NULL PRIMARY KEY,
  name VARCHAR(256),
  risk INT
)
/

CREATE SEQUENCE SEMCFederatedCompaniesInvOpt
INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE
/

CREATE TABLE EMCFederatedCompaniesInvOpt (
  id NUMBER NOT NULL PRIMARY KEY,
  name VARCHAR(256),
  risk INT
)
/

CREATE SEQUENCE SThirdPartyInvolvementOption
INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE
/

CREATE TABLE ThirdPartyInvolvementOption (
  id NUMBER NOT NULL PRIMARY KEY,
  name VARCHAR(256),
  risk INT
)
/

CREATE SEQUENCE STMBillingUsageOption
INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE
/

CREATE TABLE TMBillingUsageOption (
  id NUMBER NOT NULL PRIMARY KEY,
  name VARCHAR(256),
  risk INT
)
/

CREATE SEQUENCE SEMCAccountabilityOption
INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE
/

CREATE TABLE EMCAccountabilityOption (
  id NUMBER NOT NULL PRIMARY KEY,
  name VARCHAR(256),
  risk INT
)
/

CREATE SEQUENCE SProgramMgmtUseCaseOption
INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE
/

CREATE TABLE ProgramMgmtUseCaseOption (
  id NUMBER NOT NULL PRIMARY KEY,
  name VARCHAR(256)
)
/

CREATE SEQUENCE SRiskCalculationData
INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE
/
CREATE TABLE RiskCalculationData (
  id                           NUMBER NOT NULL PRIMARY KEY,
  theater_id                   NUMBER,
  division_id                  NUMBER,
  multi_theatre_lang_inv_opt_id NUMBER,
  multi_workgroups_disc_opt_id NUMBER,
  emc_client_type_id           NUMBER,
  emc_client_rel_type_id       NUMBER,
  proc_staff_maturity_type_id  NUMBER,
  client_env_doc_type_id       NUMBER,
  project_scope_under_type_id  NUMBER,
  project_impact_type_id       NUMBER,
  project_sponsor_inv_type_id  NUMBER,
  list_price                   INT,
  potential_value              INT,
  offering_maturity_type_id    NUMBER,
  project_complexity_type_id   NUMBER,
  external_factors_type_id     NUMBER,
  emc_staff_avail_type_id      NUMBER,
  partner_staff_avail_type_id  NUMBER,
  risk_level_type_id           NUMBER,
  risk                         VARCHAR2(256),
  rationale                    VARCHAR2(256),
  adjustment                   INT,
  emc_fed_comps_inv_type_id    NUMBER,
  third_party_inv_type_id      NUMBER,
  tm_billing_usage_type_id     NUMBER,
  emc_acc_type_id              NUMBER,
  pg_mgmt_use_case_type_id     NUMBER,
  FOREIGN KEY (theater_id) REFERENCES Geography (id),
  FOREIGN KEY (division_id) REFERENCES Division (id),
  FOREIGN KEY (multi_theatre_lang_inv_opt_id) REFERENCES MultipleTheatersLangsInvOpt (ID),
  FOREIGN KEY (multi_workgroups_disc_opt_id) REFERENCES MultipleWorkgroupsDiscOpt (id),
  FOREIGN KEY (emc_client_type_id) REFERENCES EMCClientOption (ID),
  FOREIGN KEY (emc_client_rel_type_id) REFERENCES EMCClientRelationshipOption (id),
  FOREIGN KEY (proc_staff_maturity_type_id) REFERENCES ProcessStaffMaturityOption (id),
  FOREIGN KEY (client_env_doc_type_id) REFERENCES ClientEnvDocumentationOption (id),
  FOREIGN KEY (project_scope_under_type_id) REFERENCES ProjectScopeUnderstandOption (id),
  FOREIGN KEY (project_impact_type_id) REFERENCES ProjectImpactOption (id),
  FOREIGN KEY (project_sponsor_inv_type_id) REFERENCES ProjectSponsorInvOption (id),
  FOREIGN KEY (offering_maturity_type_id) REFERENCES OfferingMaturityOption (id),
  FOREIGN KEY (project_complexity_type_id) REFERENCES ProjectComplexityLevelOption (id),
  FOREIGN KEY (external_factors_type_id) REFERENCES ExternalFactorsOption (id),
  FOREIGN KEY (emc_staff_avail_type_id) REFERENCES EMCStaffAvailabilityOption (id),
  FOREIGN KEY (partner_staff_avail_type_id) REFERENCES PartnerStaffAvailOption (id),
  FOREIGN KEY (risk_level_type_id) REFERENCES RiskLevelOption (id),
  FOREIGN KEY (emc_fed_comps_inv_type_id) REFERENCES EMCFederatedCompaniesInvOpt (id),
  FOREIGN KEY (third_party_inv_type_id) REFERENCES ThirdPartyInvolvementOption (id),
  FOREIGN KEY (tm_billing_usage_type_id) REFERENCES TMBillingUsageOption (id),
  FOREIGN KEY (emc_acc_type_id) REFERENCES EMCAccountabilityOption (id),
  FOREIGN KEY (pg_mgmt_use_case_type_id) REFERENCES ProgramMgmtUseCaseOption (id)
)
/

CREATE SEQUENCE SUsers
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE Users (
    id NUMBER NOT NULL PRIMARY KEY,
    user_identifier VARCHAR2(128) NOT NULL,
    first_name VARCHAR2(128),
    last_name VARCHAR2(128),
    email VARCHAR2(128),
    title VARCHAR2(128),
    country VARCHAR2(128),
    correlated_id NUMBER,
    constraint unique_user_identifier UNIQUE (user_identifier)
)
/
CREATE TRIGGER TUsers
BEFORE INSERT ON Users
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SUsers.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SRequest
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE Request (
    id NUMBER NOT NULL PRIMARY KEY, 
    customer_id NUMBER,
    request_status VARCHAR2(256),
    request_type_id NUMBER,
    project_name VARCHAR2(256),
    project_type_id NUMBER,
    project_regulatory_type_id NUMBER,
    start_request_data_id NUMBER,
    engagement_type_data_id NUMBER,
    mainframe_request_data_id NUMBER,
    infrastucture_request_data_id NUMBER,
    bc_request_data_id NUMBER,
    unified_request_data_id NUMBER,
    mss_request_data_id NUMBER,
    cta_request_data_id NUMBER,
    residency_request_data_id NUMBER,
    sourceone_request_data_id NUMBER,
    asd_request_data_id NUMBER,
    healthcheck_request_data_id NUMBER,
    isilon_request_data_id NUMBER,
    vipr_request_data_id NUMBER,
    atmos_request_data_id NUMBER,
    vblock_request_data_id NUMBER,
    dpad_request_data_id NUMBER,
    vmware_request_data_id NUMBER,
    change_request_data_id NUMBER,
    move_request_data_id NUMBER,
    srm_request_data_id NUMBER,
    w4n_data_id NUMBER,
    unfunded_proj_data_id NUMBER,
    xtreme_request_data_id NUMBER,
    deal_governance_data_id NUMBER,
    estimates_data_id NUMBER,
    user_identifier VARCHAR2(128) NOT NULL,
    correlated_id NUMBER,
    project_start_date DATE,
    project_end_date DATE,
    risk_calculation_data_id NUMBER,
    project_description VARCHAR2(150),
    san_tan_information_id NUMBER,
    approver_id NUMBER,
    FOREIGN KEY (customer_id) REFERENCES Customer (id),
    FOREIGN KEY (request_type_id) REFERENCES RequestType (id),
    FOREIGN KEY (project_type_id) REFERENCES ProjectType (id),
    FOREIGN KEY (project_regulatory_type_id) REFERENCES ProjectRegulatoryType (id),
    FOREIGN KEY (start_request_data_id) REFERENCES StartRequestData (id),
    FOREIGN KEY (mainframe_request_data_id) REFERENCES MainframeRequestData (id),
    FOREIGN KEY (infrastucture_request_data_id) REFERENCES InfrastructureRequestData (id),
    FOREIGN KEY (bc_request_data_id) REFERENCES BcRequestData (id),
    FOREIGN KEY (unified_request_data_id) REFERENCES UnifiedRequestData (id),
    FOREIGN KEY (change_request_data_id) REFERENCES ChangeRequestData (id),
    FOREIGN KEY (move_request_data_id) REFERENCES MoveRequestData (id),
    FOREIGN KEY (srm_request_data_id) REFERENCES SRMRequestData (id),
    FOREIGN KEY (w4n_data_id) REFERENCES W4NData (id),
    FOREIGN KEY (unfunded_proj_data_id) REFERENCES UnfundedProjectData (id),
    FOREIGN KEY (mss_request_data_id) REFERENCES MSSRequestData (id),
    FOREIGN KEY (cta_request_data_id) REFERENCES CTARequestData (id),
    FOREIGN KEY (residency_request_data_id) REFERENCES ResidencyRequestData (id),
    FOREIGN KEY (sourceone_request_data_id) REFERENCES SourceOneRequestData (id),
    FOREIGN KEY (asd_request_data_id) REFERENCES ASDRequestData (id),
    FOREIGN KEY (healthcheck_request_data_id) REFERENCES HealthCheckRequestData (id),
    FOREIGN KEY (isilon_request_data_id) REFERENCES IsilonRequestData (id),
    FOREIGN KEY (vipr_request_data_id) REFERENCES ViprRequestData (id),
    FOREIGN KEY (atmos_request_data_id) REFERENCES AtmosCenteraRequestData (id),
    FOREIGN KEY (vblock_request_data_id) REFERENCES VblockRequestData (id),
    FOREIGN KEY (dpad_request_data_id) REFERENCES DPADRequestData (id),
    FOREIGN KEY (vmware_request_data_id) REFERENCES VMwareRequestData (id),
    FOREIGN KEY (xtreme_request_data_id) REFERENCES XtremeRequestData (id),
    FOREIGN KEY (engagement_type_data_id) REFERENCES EngagementTypeData (id),
    FOREIGN KEY (deal_governance_data_id) REFERENCES DealGovernanceData (id),
    FOREIGN KEY (estimates_data_id) REFERENCES EstimatesData (id),
    FOREIGN KEY (risk_calculation_data_id) REFERENCES RiskCalculationData (ID),
    FOREIGN KEY (san_tan_information_id) REFERENCES SanTanInformation (id),
    FOREIGN KEY (approver_id) REFERENCES Profile (id)
)
/
CREATE TRIGGER TRequest
BEFORE INSERT ON Request
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SRequest.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

CREATE SEQUENCE SOperationLog
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE OperationLog (
    log_id VARCHAR2(256) NOT NULL PRIMARY KEY,
    entity_id NUMBER NOT NULL,
    entity_type VARCHAR2(128) NOT NULL,
    operation INT NOT NULL,
    timestamp NUMBER NOT NULL,
    user_identifier VARCHAR2(128) NOT NULL,
    correlated_id NUMBER,
    seq NUMBER NULL,
    constraint unique_operation_log UNIQUE (entity_id, entity_type, user_identifier)
)
/

CREATE TABLE SynchronizedOperationLog (
    log_id VARCHAR2(256) NOT NULL PRIMARY KEY,
    entity_id NUMBER NOT NULL,
    entity_type VARCHAR2(128) NOT NULL,
    operation INT NOT NULL,
    timestamp NUMBER NOT NULL,
    user_identifier VARCHAR2(128) NOT NULL,
    correlated_id NUMBER,
    seq NUMBER NULL
)

/

CREATE SEQUENCE SRequest_AdditionalRecipients
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE

/
CREATE TABLE Request_AdditionalRecipients (
    id NUMBER NOT NULL PRIMARY KEY, 
    request_id NUMBER,
    recipient_id NUMBER,
    FOREIGN KEY (request_id) REFERENCES Request (id),
    FOREIGN KEY (recipient_id) REFERENCES Profile (id)
)
/
CREATE TRIGGER TRequest_AdditionalRecipients
BEFORE INSERT ON Request_AdditionalRecipients
FOR EACH ROW
when (new.id = 0 or new.id is null)
BEGIN
    SELECT SRequest_AdditionalRecipients.NEXTVAL
    INTO   :new.id
    FROM   dual;
END;

/

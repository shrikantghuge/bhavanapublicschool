CREATE SEQUENCE SIPEDUData INCREMENT BY 1 START WITH 1000;
CREATE TABLE IPEDUData (
  id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SIPEDUData'),
  estimates_data_id  BIGINT,
  data_type   VARCHAR(3),
  material_id BIGINT,
  competency_id BIGINT,
  hosts_number INT,
  amount DECIMAL(20, 2),
  FOREIGN KEY (estimates_data_id) REFERENCES EstimatesData (id),
  FOREIGN KEY (material_id) REFERENCES MaterialCode (id),
  FOREIGN KEY (competency_id) REFERENCES Competency (id)
);

/*
 * This code is copyright (c) 2014 EMC Corporation.
 */
package com.emc.gs.tools.srf.services.impl;

import com.emc.gs.tools.srf.services.AppService;


/**
 * <p>
 * This is the cloud side implementation of AppService.
 * </p>
 *
 * <p>
 * <strong>Thread safety</strong>: This class is immutable and thread safe.
 * </p>
 *
 * @author TCSASSEMBLER
 * @version 1.1
 * @since SRT Phase 4 - ET Assembly 2
 */
public class CloudAppServiceImpl implements AppService {

    /**
     * Empty constructor.
     */
    public CloudAppServiceImpl() {
    }

    /**
     * Cloud app, return true always.
     * 
     * @return true always
     */
    public boolean isCloudApp() {
        return true;
    }

    /**
     * Gets application identifier.
     * 
     * @return "cloud" always
     */
    public String getAppIdentifier() {
        return "cloud";
    }

    /**
     * <p>Gets the flag indicating if application is operating in standalone mode or not.</p>
     *
     * @return a <code>boolean</code> providing the value for standalone property.
     * @since 1.1
     */
    @Override
    public boolean isStandaloneMode() {
        return false;
    }
}

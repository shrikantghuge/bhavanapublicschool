/*
 * This code is copyright (c) 2015 EMC Corporation.
 */
package com.emc.gs.tools.srf.services.impl;

import java.util.List;

import javax.annotation.PostConstruct;
import com.emc.gs.tools.srf.services.ServiceRequestToolException;
import com.emc.gs.tools.srf.services.UserAdminService;

/**
 * <p>
 * This class is the cloud side implementation of the UserAdminService.
 * </p>
 *
 * <p>
 * <strong>Thread safety</strong>: This class is effectively thread safe after
 * configuration, the configuration is done in a thread safe manner.
 * </p>
 *
 * @author TCSASSEMBLER
 * @version 1.0
 * @since SRT 1.1 Approval Process Assembly
 */
public class CloudUserAdminServiceImpl implements UserAdminService {

    /**
     * <p>
     * The userAdmins.
     * </p>
     */
    private List<String> userAdmins;
    
    /**
     * <p>
     * Retrieves the userAdmins field.
     * </p>
     *
     * @return the userAdmins
     */
    public List<String> getUserAdmins() {
        return userAdmins;
    }

    /**
     * <p>
     * Sets the value to userAdmins field.
     * </p>
     *
     * @param userAdmins the userAdmins to set
     */
    public void setUserAdmins(List<String> userAdmins) {
        this.userAdmins = userAdmins;
    }

    /**
     * Default constructor.
     */
    public CloudUserAdminServiceImpl() {
        // Empty
    }

    /**
     * Decides if a user has user management permission.
     *
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     * @param userIdentifier
     *            the user's identifier
     * @return true if the user has management user permission; false otherwise
     */
    @Override
    public boolean hasUserManagementPermission(String userIdentifier) throws ServiceRequestToolException {
        return userAdmins.contains(userIdentifier);
    }
    
    /**
     * This method checks whether the instance of the class was initialized properly.
     *
     * @throws ServiceRequestToolConfigurationException
     *             if userAdmins is null
     */
    @PostConstruct
    protected void checkInit() {
        Helper.checkState(userAdmins == null, "'userAdmins' can't be null.");
    }
}

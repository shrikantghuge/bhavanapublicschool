insert into Profile values(1, null, null, null, '+44', null, null, null, null, null, null, null, null, null, false, 'user0', 1, false, false, null, null, null, null);
insert into Profile values(2, 'Jim', 'Morrison', 'job1', '+44', '+44', '1234567899', '+44', '1234567890', '+44', '1234567891', 'bob@tc.com', 1, 1, true, 'user1', 2, false, false, null, null, null, null);
insert into Profile values(3, 'Ray', 'Manzarek', 'job2', '+44', '+44', '1234567899', '+44', '1234567890', '+44', '1234567891', 'bob@tc.com', 1, 1, true, 'user2', 3, false, false, null, null, null, null);
insert into Profile values(4, 'Robbie', 'Krieger', 'job3', '+44', '+44', '1234567899', '+44', '1234567890', '+44', '1234567891', 'bob@tc.com', 1, 1, true, 'user3', 4, false, false, null, null, null, null);
insert into Profile values(5, 'John', 'Densmore', 'job5', '+44', '+44', '1234567899', '+44', '1234567890', '+44', '1234567891', 'bob@tc.com', 1, 1, true, 'admin', 5, true, true, null, null, null, null);
insert into Profile values(6, 'Pete', 'Townshend', 'job5', '+44', '+44', '1234567899', '+44', '1234567890', '+44', '1234567891', 'bob@tc.com', 24, 341, true, 'thewho1', 6, true, true, null, null, null, null);
insert into Profile values(7, 'Keith', 'Moon', 'job5', '+44', '+44', '1234567899', '+44', '1234567890', '+44', '1234567891', 'bob@tc.com', 24, 341, true, 'thewho2', 7, false, false, null, null, null, null);
insert into Profile values(8, 'Roger', 'Daltrey', 'job5', '+44', '+44', '1234567899', '+44', '1234567890', '+44', '1234567891', 'bob@tc.com', 24, 341, true, 'thewho3', 8, false, false, null, null, null, null);
insert into Profile values(9, 'John', 'Entwistle', 'job5', '+44', '+44', '1234567899', '+44', '1234567890', '+44', '1234567891', 'bob@tc.com', 24, 341, true, 'thewho4', 9, false, false, null, null, null, null);
insert into Profile values(10, 'Tom', 'Araya', 'job5', '+44', '+44', '1234567899', '+44', '1234567890', '+44', '1234567891', 'bob@tc.com', 25, 331, true, 'slayer1', 10, true, true, null, null, null, null);
insert into Profile values(11, 'Kerry', 'King', 'job5', '+44', '+44', '1234567899', '+44', '1234567890', '+44', '1234567891', 'bob@tc.com', 25, 331, true, 'slayer2', 11, false, false, null, null, null, null);
insert into Profile values(12, 'Jeff', 'Hannemann', 'job5', '+44', '+44', '1234567899', '+44', '1234567890', '+44', '1234567891', 'bob@tc.com', 25, 331, true, 'slayer3', 12, false, false, null, null, null, null);
insert into Profile values(13, 'Dave', 'Lombardo', 'job5', '+44', '+44', '1234567899', '+44', '1234567890', '+44', '1234567891', 'bob@tc.com', 25, 331, true, 'slayer4', 13, false, false, null, null, null, null);

insert into CustomerWorkSite values(1, 'New York', 'New York', 53, 1701);
insert into CustomerWorkSite values(2, 'Chicago', 'Chicago', 53, 1702);
insert into CustomerWorkSite values(3, 'Washionton', 'Washionton', 53, 1703);

insert into Customer values(1, 'name1', 'formalname1', 'address1', 'address2', 'city1', '123456', 'title1', '111', '2223333', '444', '2223333', '555', '2223333', 'bob@tc.com', '123', TO_DATE('2013-09-01 12:30:00','YYYY-MM-DD HH24:MI:SS'), 'note1', 1, 1, 2, false, 'user1', 0);
insert into Customer values(2, 'name2', 'formalname2', 'address3', 'address4', 'city2', '223456', 'title2', '111', '2223333', '444', '2223333', '555', '2223333', 'bob@tc.com', '223', TO_DATE('2013-09-01 12:30:00','YYYY-MM-DD HH24:MI:SS'), 'note2', 71, 2, 2, false, 'user2', 0);
insert into Customer values(3, 'name3', 'formalname3', 'address5', 'address6', 'city3', '445567', 'title3', '111', '2223333', '444', '2223333', '555', '2223333', 'bob@tc.com', '565', TO_DATE('2013-09-01 12:30:00','YYYY-MM-DD HH24:MI:SS'), 'note3', 3, 3, 3, false, 'user1', 0);

insert into Customer_CustomerWorkSite values(1, 1, 1);
insert into Customer_CustomerWorkSite values(2, 1, 2);
insert into Customer_CustomerWorkSite values(3, 2, 3);

INSERT INTO startrequestdata VALUES(1, 1, 1, 1, 1, 1, 1, 1, null, null, 1, 1, 'Graham Paul', 'project_name1', 1, 'Miami', '1001000000', 'se_csd_name1', 'Eduardo Morales', 'pm_name1', 'sfdc_number1', '123', '456111', 1, 'se_manager_name1', 'pdmn1', 1, 1, true, true, TO_DATE('2013-09-09 12:30:21','YYYY-MM-DD HH24:MI:SS'), true, true, 1, 1, 'serviceRequestScope1', 'travelRequirements1', 1, null);
INSERT INTO startrequestdata VALUES(2, 2, 2, 2, 2, 2, 2, 2, null, null, 2, 2, 'James Scott', 'project_name2', 2, 'Houston', '1001000000', 'se_csd_name2', 'David Kennedy', 'pm_name2', 'sfdc_number2', '123', '456222', 2, 'se_manager_name2', 'pdmn2', 2, 2, false, false, TO_DATE('2013-09-09 12:30:21','YYYY-MM-DD HH24:MI:SS'), false, false, 2, 2, 'serviceRequestScope2', 'travelRequirements2', 3, null);
INSERT INTO startrequestdata VALUES(3, 3, 3, 3, 3, 3, 3, 3, null, null, 1, 3, 'Golding William', 'project_name3', 3, 'Denver', '1001000000', 'se_csd_name3', 'Eduardo Morales', 'pm_name3', 'sfdc_number3', '123', '456333', 3, 'se_manager_name3', 'pdmn3', 3, 3, true, true, TO_DATE('2013-09-09 12:30:21','YYYY-MM-DD HH24:MI:SS'), true, true, 3, 3, 'serviceRequestScope3', 'travelRequirements3', 1, null);

INSERT INTO startrequestdata_attachments VALUES(1, 2, 1);
INSERT INTO startrequestdata_attachments VALUES(2, 2, 2);
INSERT INTO startrequestdata_attachments VALUES(3, 3, 3);

INSERT INTO request VALUES(1, 1, 'DRAFT', 1, 'project_name1', 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, null, null, null, null, null, null, null, null, 'user1', 1, null, null, null, null, 1, null);
INSERT INTO request VALUES(2, 2, 'SUBMITTED', 2, 'project_name2', 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, null, null, null, null, null, null, null, null, 'user2', 2, null, null, null, null, 2, null);

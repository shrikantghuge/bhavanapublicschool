
CREATE TABLE IPEDUData (
  id        BIGINT AUTO_INCREMENT NOT NULL PRIMARY KEY,
  estimates_data_id  BIGINT,
  data_type   VARCHAR(3),
  material_id BIGINT,
  competency_id BIGINT,
  hosts_number INT,
  amount DECIMAL(20, 2),
  FOREIGN KEY (estimates_data_id) REFERENCES EstimatesData (id),
  FOREIGN KEY (material_id) REFERENCES MaterialCode (id),
  FOREIGN KEY (competency_id) REFERENCES Competency (id)
);

/*
 * This code is copyright (c) 2013 - 2014 EMC Corporation.
 */
package com.emc.gs.tools.srf.model.bc;

import java.util.Map;

import com.emc.gs.tools.srf.model.IdentifiableEntity;

/**
 * <p>
 * This is ReplicationManagerInformation entity class.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safety.
 * </p>
 * <p>
 * <strong>Changes V1.1:</strong> <strong>SRT Bug Fixes - F121, F153, F154, F162</strong>
 * <ul>
 * <li>Add knowledgeTransferHours field.</li>
 * </ul>
 * </p>
 * <p>
 * <strong>Changes V1.2:</strong>
 * <ul>
 * <li>Removed prePostSalesQualifiers, databaseNumber fields.</li>
 * </ul>
 * </p>
 * <p>
 * <strong>Changes V1.3:</strong> <strong>https://apps.topcoder.com/bugs/browse/SRT-35</strong>
 * <ul>
 * <li>Added includeAppIntegration, replicationManagerProductSpecificPreparation, nrOfReplicas, nrOfReplicatedApps,
 * nrOfReplicationJobs fields.</li>
 * </ul>
 * </p>
 * 
 * @author faeton, stevenfrog, MonicaMuranyi
 * @version 1.3
 */
public class ReplicationManagerInformation extends IdentifiableEntity {

    /**
     * <p>
     * The knowledgeTransferHours.
     * </p>
     */
    private String knowledgeTransferHours;

    /**
     * <p>
     * The timeFinderManaged.
     * </p>
     */
    private boolean timeFinderManaged;

    /**
     * <p>
     * The openReplicatorManaged.
     * </p>
     */
    private boolean openReplicatorManaged;

    /**
     * <p>
     * The snapViewManaged.
     * </p>
     */
    private boolean snapViewManaged;

    /**
     * <p>
     * The recoverPointManaged.
     * </p>
     */
    private boolean recoverPointManaged;

    /**
     * <p>
     * The sanCopyManaged.
     * </p>
     */
    private boolean sanCopyManaged;

    /**
     * <p>
     * The celerraManaged.
     * </p>
     */
    private boolean celerraManaged;

    /**
     * <p>
     * The snapSureManaged.
     * </p>
     */
    private boolean snapSureManaged;

    /**
     * <p>
     * The replicationInstalled.
     * </p>
     */
    private boolean replicationInstalled;

    /**
     * <p>
     * The replicationManagerImplementation.
     * </p>
     */
    private ReplicationManagerImplementation replicationManagerImplementation;

    /**
     * <p>
     * The replicatedStorageSize.
     * </p>
     */
    private Integer replicatedStorageSize;

    /**
     * <p>
     * The configChangeType.
     * </p>
     */
    private ConfigChangeType configChangeType;

    /**
     * <p>
     * The managerServersNumber.
     * </p>
     */
    private Integer managerServersNumber;

    /**
     * <p>
     * The clusteredRmServerOption.
     * </p>
     */
    private boolean clusteredRmServerOption;

    /**
     * <p>
     * The Integer>.
     * </p>
     */
    private Map<String, Integer> sourceHostNumber;

    /**
     * <p>
     * The Integer>.
     * </p>
     */
    private Map<String, Integer> targetHostNumber;

    /**
     * <p>
     * The customScriptingRequired.
     * </p>
     */
    private boolean customScriptingRequired;

    /**
     * <p>
     * The includeAppIntegration.
     * </p>
     */
    private boolean includeAppIntegration;

    /**
     * <p>
     * The replicationManagerProductSpecificPreparation.
     * </p>
     */
    private ReplicationManagerProductSpecificPreparation replicationManagerProductSpecificPreparation;

    /**
     * <p>
     * The nrOfReplicas.
     * </p>
     */
    private Integer nrOfReplicas;

    /**
     * <p>
     * The nrOfReplicatedApps.
     * </p>
     */
    private Integer nrOfReplicatedApps;

    /**
     * <p>
     * The nrOfReplicatedApps.
     * </p>
     */
    private Integer nrOfReplicationJobs;

    /**
     * <p>
     * The default constructor.
     * </p>
     */
    public ReplicationManagerInformation() {
        // Empty
    }

    /**
     * <p>
     * Retrieves the knowledgeTransferHours field.
     * </p>
     * 
     * @return the knowledgeTransferHours
     */
    public String getKnowledgeTransferHours() {
        return knowledgeTransferHours;
    }

    /**
     * <p>
     * Sets the value to knowledgeTransferHours field.
     * </p>
     * 
     * @param knowledgeTransferHours
     *            the knowledgeTransferHours to set
     */
    public void setKnowledgeTransferHours(String knowledgeTransferHours) {
        this.knowledgeTransferHours = knowledgeTransferHours;
    }

    /**
     * <p>
     * Retrieves the timeFinderManaged field.
     * </p>
     * 
     * @return the timeFinderManaged
     */
    public boolean isTimeFinderManaged() {
        return timeFinderManaged;
    }

    /**
     * <p>
     * Sets the value to timeFinderManaged field.
     * </p>
     * 
     * @param timeFinderManaged
     *            the timeFinderManaged to set
     */
    public void setTimeFinderManaged(boolean timeFinderManaged) {
        this.timeFinderManaged = timeFinderManaged;
    }

    /**
     * <p>
     * Retrieves the openReplicatorManaged field.
     * </p>
     * 
     * @return the openReplicatorManaged
     */
    public boolean isOpenReplicatorManaged() {
        return openReplicatorManaged;
    }

    /**
     * <p>
     * Sets the value to openReplicatorManaged field.
     * </p>
     * 
     * @param openReplicatorManaged
     *            the openReplicatorManaged to set
     */
    public void setOpenReplicatorManaged(boolean openReplicatorManaged) {
        this.openReplicatorManaged = openReplicatorManaged;
    }

    /**
     * <p>
     * Retrieves the snapViewManaged field.
     * </p>
     * 
     * @return the snapViewManaged
     */
    public boolean isSnapViewManaged() {
        return snapViewManaged;
    }

    /**
     * <p>
     * Sets the value to snapViewManaged field.
     * </p>
     * 
     * @param snapViewManaged
     *            the snapViewManaged to set
     */
    public void setSnapViewManaged(boolean snapViewManaged) {
        this.snapViewManaged = snapViewManaged;
    }

    /**
     * <p>
     * Retrieves the recoverPointManaged field.
     * </p>
     * 
     * @return the recoverPointManaged
     */
    public boolean isRecoverPointManaged() {
        return recoverPointManaged;
    }

    /**
     * <p>
     * Sets the value to recoverPointManaged field.
     * </p>
     * 
     * @param recoverPointManaged
     *            the recoverPointManaged to set
     */
    public void setRecoverPointManaged(boolean recoverPointManaged) {
        this.recoverPointManaged = recoverPointManaged;
    }

    /**
     * <p>
     * Retrieves the sanCopyManaged field.
     * </p>
     * 
     * @return the sanCopyManaged
     */
    public boolean isSanCopyManaged() {
        return sanCopyManaged;
    }

    /**
     * <p>
     * Sets the value to sanCopyManaged field.
     * </p>
     * 
     * @param sanCopyManaged
     *            the sanCopyManaged to set
     */
    public void setSanCopyManaged(boolean sanCopyManaged) {
        this.sanCopyManaged = sanCopyManaged;
    }

    /**
     * <p>
     * Retrieves the celerraManaged field.
     * </p>
     * 
     * @return the celerraManaged
     */
    public boolean isCelerraManaged() {
        return celerraManaged;
    }

    /**
     * <p>
     * Sets the value to celerraManaged field.
     * </p>
     * 
     * @param celerraManaged
     *            the celerraManaged to set
     */
    public void setCelerraManaged(boolean celerraManaged) {
        this.celerraManaged = celerraManaged;
    }

    /**
     * <p>
     * Retrieves the snapSureManaged field.
     * </p>
     * 
     * @return the snapSureManaged
     */
    public boolean isSnapSureManaged() {
        return snapSureManaged;
    }

    /**
     * <p>
     * Sets the value to snapSureManaged field.
     * </p>
     * 
     * @param snapSureManaged
     *            the snapSureManaged to set
     */
    public void setSnapSureManaged(boolean snapSureManaged) {
        this.snapSureManaged = snapSureManaged;
    }

    /**
     * <p>
     * Retrieves the replicationInstalled field.
     * </p>
     * 
     * @return the replicationInstalled
     */
    public boolean isReplicationInstalled() {
        return replicationInstalled;
    }

    /**
     * <p>
     * Sets the value to replicationInstalled field.
     * </p>
     * 
     * @param replicationInstalled
     *            the replicationInstalled to set
     */
    public void setReplicationInstalled(boolean replicationInstalled) {
        this.replicationInstalled = replicationInstalled;
    }

    /**
     * <p>
     * Retrieves the replicationManagerImplementation field.
     * </p>
     * 
     * @return the replicationManagerImplementation
     */
    public ReplicationManagerImplementation getReplicationManagerImplementation() {
        return replicationManagerImplementation;
    }

    /**
     * <p>
     * Sets the value to replicationManagerImplementation field.
     * </p>
     * 
     * @param replicationManagerImplementation
     *            the replicationManagerImplementation to set
     */
    public void setReplicationManagerImplementation(
            ReplicationManagerImplementation replicationManagerImplementation) {
        this.replicationManagerImplementation = replicationManagerImplementation;
    }

    /**
     * <p>
     * Retrieves the replicatedStorageSize field.
     * </p>
     * 
     * @return the replicatedStorageSize
     */
    public Integer getReplicatedStorageSize() {
        return replicatedStorageSize;
    }

    /**
     * <p>
     * Sets the value to replicatedStorageSize field.
     * </p>
     * 
     * @param replicatedStorageSize
     *            the replicatedStorageSize to set
     */
    public void setReplicatedStorageSize(Integer replicatedStorageSize) {
        this.replicatedStorageSize = replicatedStorageSize;
    }

    /**
     * <p>
     * Retrieves the configChangeType field.
     * </p>
     * 
     * @return the configChangeType
     */
    public ConfigChangeType getConfigChangeType() {
        return configChangeType;
    }

    /**
     * <p>
     * Sets the value to configChangeType field.
     * </p>
     * 
     * @param configChangeType
     *            the configChangeType to set
     */
    public void setConfigChangeType(ConfigChangeType configChangeType) {
        this.configChangeType = configChangeType;
    }

    /**
     * <p>
     * Retrieves the managerServersNumber field.
     * </p>
     * 
     * @return the managerServersNumber
     */
    public Integer getManagerServersNumber() {
        return managerServersNumber;
    }

    /**
     * <p>
     * Sets the value to managerServersNumber field.
     * </p>
     * 
     * @param managerServersNumber
     *            the managerServersNumber to set
     */
    public void setManagerServersNumber(Integer managerServersNumber) {
        this.managerServersNumber = managerServersNumber;
    }

    /**
     * <p>
     * Retrieves the clusteredRmServerOption field.
     * </p>
     * 
     * @return the clusteredRmServerOption
     */
    public boolean isClusteredRmServerOption() {
        return clusteredRmServerOption;
    }

    /**
     * <p>
     * Sets the value to clusteredRmServerOption field.
     * </p>
     * 
     * @param clusteredRmServerOption
     *            the clusteredRmServerOption to set
     */
    public void setClusteredRmServerOption(boolean clusteredRmServerOption) {
        this.clusteredRmServerOption = clusteredRmServerOption;
    }

    /**
     * <p>
     * Retrieves the sourceHostNumber field.
     * </p>
     * 
     * @return the sourceHostNumber
     */
    public Map<String, Integer> getSourceHostNumber() {
        return sourceHostNumber;
    }

    /**
     * <p>
     * Sets the value to sourceHostNumber field.
     * </p>
     * 
     * @param sourceHostNumber
     *            the sourceHostNumber to set
     */
    public void setSourceHostNumber(Map<String, Integer> sourceHostNumber) {
        this.sourceHostNumber = sourceHostNumber;
    }

    /**
     * <p>
     * Retrieves the targetHostNumber field.
     * </p>
     * 
     * @return the targetHostNumber
     */
    public Map<String, Integer> getTargetHostNumber() {
        return targetHostNumber;
    }

    /**
     * <p>
     * Sets the value to targetHostNumber field.
     * </p>
     * 
     * @param targetHostNumber
     *            the targetHostNumber to set
     */
    public void setTargetHostNumber(Map<String, Integer> targetHostNumber) {
        this.targetHostNumber = targetHostNumber;
    }

    /**
     * <p>
     * Retrieves the customScriptingRequired field.
     * </p>
     * 
     * @return the customScriptingRequired
     */
    public boolean isCustomScriptingRequired() {
        return customScriptingRequired;
    }

    /**
     * <p>
     * Sets the value to customScriptingRequired field.
     * </p>
     * 
     * @param customScriptingRequired
     *            the customScriptingRequired to set
     */
    public void setCustomScriptingRequired(boolean customScriptingRequired) {
        this.customScriptingRequired = customScriptingRequired;
    }

    /**
     * <p>
     * Retrieves the includeAppIntegration field.
     * </p>
     * 
     * @return the includeAppIntegration
     */
    public boolean isIncludeAppIntegration() {
        return includeAppIntegration;
    }

    /**
     * <p>
     * Sets the value to includeAppIntegration field.
     * </p>
     * 
     * @param includeAppIntegration
     *            the includeAppIntegration to set
     */
    public void setIncludeAppIntegration(boolean includeAppIntegration) {
        this.includeAppIntegration = includeAppIntegration;
    }

    /**
     * <p>
     * Retrieves the replicationManagerProductSpecificPreparation field.
     * </p>
     * 
     * @return the replicationManagerProductSpecificPreparation
     */
    public ReplicationManagerProductSpecificPreparation getReplicationManagerProductSpecificPreparation() {
        return replicationManagerProductSpecificPreparation;
    }

    /**
     * <p>
     * Sets the value to replicationManagerProductSpecificPreparation field.
     * </p>
     * 
     * @param replicationManagerProductSpecificPreparation
     *            the replicationManagerProductSpecificPreparation to set
     */
    public void setReplicationManagerProductSpecificPreparation(
            ReplicationManagerProductSpecificPreparation replicationManagerProductSpecificPreparation) {
        this.replicationManagerProductSpecificPreparation = replicationManagerProductSpecificPreparation;
    }

    /**
     * <p>
     * Retrieves the nrOfReplicas field.
     * </p>
     * 
     * @return the nrOfReplicas
     */
    public Integer getNrOfReplicas() {
        return nrOfReplicas;
    }

    /**
     * <p>
     * Sets the value to nrOfReplicas field.
     * </p>
     * 
     * @param nrOfReplicas
     *            the nrOfReplicas to set
     */
    public void setNrOfReplicas(Integer nrOfReplicas) {
        this.nrOfReplicas = nrOfReplicas;
    }

    /**
     * <p>
     * Retrieves the nrOfReplicatedApps field.
     * </p>
     * 
     * @return the nrOfReplicatedApps
     */
    public Integer getNrOfReplicatedApps() {
        return nrOfReplicatedApps;
    }

    /**
     * <p>
     * Sets the value to nrOfReplicatedApps field.
     * </p>
     * 
     * @param nrOfReplicatedApps
     *            the nrOfReplicatedApps to set
     */
    public void setNrOfReplicatedApps(Integer nrOfReplicatedApps) {
        this.nrOfReplicatedApps = nrOfReplicatedApps;
    }

    /**
     * <p>
     * Retrieves the nrOfReplicationJobs field.
     * </p>
     * 
     * @return the nrOfReplicationJobs
     */
    public Integer getNrOfReplicationJobs() {
        return nrOfReplicationJobs;
    }

    /**
     * <p>
     * Sets the value to nrOfReplicationJobs field.
     * </p>
     * 
     * @param nrOfReplicationJobs
     *            the nrOfReplicationJobs to set
     */
    public void setNrOfReplicationJobs(Integer nrOfReplicationJobs) {
        this.nrOfReplicationJobs = nrOfReplicationJobs;
    }

    /**
     * The toString method.
     * 
     * @return the string for this entity
     */
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("{").append(super.toString());
        sb.append(", knowledgeTransferHours:").append(knowledgeTransferHours);
        sb.append(", timeFinderManaged:").append(timeFinderManaged);
        sb.append(", openReplicatorManaged:").append(openReplicatorManaged);
        sb.append(", snapViewManaged:").append(snapViewManaged);
        sb.append(", recoverPointManaged:").append(recoverPointManaged);
        sb.append(", sanCopyManaged:").append(sanCopyManaged);
        sb.append(", celerraManaged:").append(celerraManaged);
        sb.append(", snapSureManaged:").append(snapSureManaged);
        sb.append(", replicationInstalled:").append(replicationInstalled);
        sb.append(", replicationManagerImplementation:").append(replicationManagerImplementation);
        sb.append(", replicatedStorageSize:").append(replicatedStorageSize);
        sb.append(", configChangeType:").append(configChangeType);
        sb.append(", managerServersNumber:").append(managerServersNumber);
        sb.append(", clusteredRmServerOption:").append(clusteredRmServerOption);
        sb.append(", sourceHostNumber:").append(sourceHostNumber);
        sb.append(", targetHostNumber:").append(targetHostNumber);
        sb.append(", includeAppIntegration:").append(includeAppIntegration);
        sb.append(", replicationManagerProductSpecificPreparation:").append(
                replicationManagerProductSpecificPreparation);
        sb.append(", nrOfReplicas:").append(nrOfReplicas);
        sb.append(", nrOfReplicatedApps:").append(nrOfReplicatedApps);
        sb.append(", nrOfReplicationJobs:").append(nrOfReplicationJobs);
        sb.append(", customScriptingRequired:").append(customScriptingRequired).append("}");
        return sb.toString();
    }
}

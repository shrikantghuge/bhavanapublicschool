/*
 * This code is copyright (c) 2014 EMC Corporation.
 */
package com.emc.gs.tools.srf.model.deal;

import com.emc.gs.tools.srf.model.LookupEntity;

/**
 * <p>
 * This is DealQuestion entity class.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safety.
 * </p>
 * 
 * @author TCSASSEMBLER
 * @version 1.0
 * @since SRT Phase 4 - ET Assembly 1
 */
public class DealQuestion extends LookupEntity {

    /**
     * The comment condition.
     */
    private boolean commentCondition;

    /**
     * The comment place holder.
     */
    private String commentPlaceHolder;

    /**
     * Empty constructor.
     */
    public DealQuestion() {
    }

    /**
     * Getter method for property <tt>commentCondition</tt>.
     * 
     * @return property value of commentCondition
     */
    public boolean isCommentCondition() {
        return commentCondition;
    }

    /**
     * Setter method for property <tt>commentCondition</tt>.
     * 
     * @param commentCondition
     *            value to be assigned to property commentCondition
     */
    public void setCommentCondition(boolean commentCondition) {
        this.commentCondition = commentCondition;
    }

    /**
     * Getter method for property <tt>commentPlaceHolder</tt>.
     * 
     * @return property value of commentPlaceHolder
     */
    public String getCommentPlaceHolder() {
        return commentPlaceHolder;
    }

    /**
     * Setter method for property <tt>commentPlaceHolder</tt>.
     * 
     * @param commentPlaceHolder
     *            value to be assigned to property commentPlaceHolder
     */
    public void setCommentPlaceHolder(String commentPlaceHolder) {
        this.commentPlaceHolder = commentPlaceHolder;
    }

}

/*
 * This code is copyright (c) 2013 - 2014 EMC Corporation.
 */
package com.emc.gs.tools.srf.model.infrastructure;

import com.emc.gs.tools.srf.model.IdentifiableEntity;

/**
 * <p>
 * This is SanTanInformation entity class.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safety.
 * </p>
 * 
 * <p>
 * <strong>Changes V1.1:</strong>
 * <strong>SRT Bug Fixes - F121, F153, F154, F162</strong>
 * <ul>
 * <li>Add knowledgeTransferHours field.</li>
 * </ul>
 * </p>
 * 
 * <p>
 * <strong>Changes V1.2:</strong>
 * <ul>
 * <li>Removed tapeLibrariesNumber, tapeHostsNumber fields.</li>
 * </ul>
 * </p>
 * 
 * <p>
 * <strong>Changes V1.3:</strong>
 * <strong>https://apps.topcoder.com/bugs/browse/SRT-35</strong>
 * <ul>
 * <li>Added totalPortsToMigrate field.</li>
 * </ul>
 * </p>
 * 
 * @author faeton, stevenfrog, MonicaMuranyi
 * @version 1.3
 */
public class SanTanInformation extends IdentifiableEntity {
    
    /**
     * <p>
     * The knowledgeTransferHours.
     * </p>
     */
    private String knowledgeTransferHours;
    
    /**
     * <p>
     * The sanMigrationInScopeOption.
     * </p>
     */
    private boolean sanMigrationInScopeOption;

    /**
     * <p>
     * The sanDirectorsNumber.
     * </p>
     */
    private Integer sanDirectorsNumber;
    
    /**
     * <p>
     * The totalPortsToMigrate.
     * </p>
     */
    private Integer totalPortsToMigrate;

    /**
     * <p>
     * The sanSwitchesNumber.
     * </p>
     */
    private Integer sanSwitchesNumber;

    /**
     * <p>
     * The bladesNumber.
     * </p>
     */
    private Integer bladesNumber;

    /**
     * <p>
     * The fcoeSwitchesNumber.
     * </p>
     */
    private Integer fcoeSwitchesNumber;

    /**
     * <p>
     * The fcoeVlanNumber.
     * </p>
     */
    private Integer fcoeVlanNumber;

    /**
     * <p>
     * The fcoeChannelNumber.
     * </p>
     */
    private Integer fcoeChannelNumber;

    /**
     * <p>
     * The sanExtensionDevicesNumber.
     * </p>
     */
    private Integer sanExtensionDevicesNumber;

    /**
     * <p>
     * The nasToCxUnitsNumber.
     * </p>
     */
    private Integer nasToCxUnitsNumber;

    /**
     * <p>
     * The nasToSymmetrixUnitsNumber.
     * </p>
     */
    private Integer nasToSymmetrixUnitsNumber;

    /**
     * <p>
     * The nasToCxHostsNumber.
     * </p>
     */
    private Integer nasToCxHostsNumber;

    /**
     * <p>
     * The nasToSymmetrixHostsNumber.
     * </p>
     */
    private Integer nasToSymmetrixHostsNumber;

    /**
     * <p>
     * The verifyMajorOutageConnectivityHostsNumber.
     * </p>
     */
    private Integer verifyMajorOutageConnectivityHostsNumber;

    /**
     * <p>
     * The deinstalledSanDirectorsNumber.
     * </p>
     */
    private Integer deinstalledSanDirectorsNumber;

    /**
     * <p>
     * The deinstalledSanSwitchesNumber.
     * </p>
     */
    private Integer deinstalledSanSwitchesNumber;

    /**
     * <p>
     * The deinstalledSanExtensionDevicesNumber.
     * </p>
     */
    private Integer deinstalledSanExtensionDevicesNumber;

    /**
     * <p>
     * The default constructor.
     * </p>
     */
    public SanTanInformation() {
        // Empty
    }
    
    /**
     * <p>
     * Retrieves the knowledgeTransferHours field.
     * </p>
     *
     * @return the knowledgeTransferHours
     */
    public String getKnowledgeTransferHours() {
        return knowledgeTransferHours;
    }

    /**
     * <p>
     * Sets the value to knowledgeTransferHours field.
     * </p>
     *
     * @param knowledgeTransferHours
     *            the knowledgeTransferHours to set
     */
    public void setKnowledgeTransferHours(String knowledgeTransferHours) {
        this.knowledgeTransferHours = knowledgeTransferHours;
    }

    /**
     * <p>
     * Retrieves the verifyMajorOutageConnectivityHostsNumber field.
     * </p>
     *
     * @return the value of verifyMajorOutageConnectivityHostsNumber
     */
    public Integer getVerifyMajorOutageConnectivityHostsNumber() {
        return verifyMajorOutageConnectivityHostsNumber;
    }

    /**
     * <p>
     * Sets the value to verifyMajorOutageConnectivityHostsNumber field.
     * </p>
     *
     * @param verifyMajorOutageConnectivityHostsNumber the value of verifyMajorOutageConnectivityHostsNumber to set
     */
    public void setVerifyMajorOutageConnectivityHostsNumber(Integer verifyMajorOutageConnectivityHostsNumber) {
        this.verifyMajorOutageConnectivityHostsNumber = verifyMajorOutageConnectivityHostsNumber;
    }

    /**
     * <p>
     * Retrieves the sanMigrationInScopeOption field.
     * </p>
     *
     * @return the sanMigrationInScopeOption
     */
    public boolean isSanMigrationInScopeOption() {
        return sanMigrationInScopeOption;
    }

    /**
     * <p>
     * Sets the value to sanMigrationInScopeOption field.
     * </p>
     *
     * @param sanMigrationInScopeOption
     *            the sanMigrationInScopeOption to set
     */
    public void setSanMigrationInScopeOption(boolean sanMigrationInScopeOption) {
        this.sanMigrationInScopeOption = sanMigrationInScopeOption;
    }

    /**
     * <p>
     * Retrieves the sanDirectorsNumber field.
     * </p>
     *
     * @return the sanDirectorsNumber
     */
    public Integer getSanDirectorsNumber() {
        return sanDirectorsNumber;
    }

    /**
     * <p>
     * Sets the value to sanDirectorsNumber field.
     * </p>
     *
     * @param sanDirectorsNumber
     *            the sanDirectorsNumber to set
     */
    public void setSanDirectorsNumber(Integer sanDirectorsNumber) {
        this.sanDirectorsNumber = sanDirectorsNumber;
    }
    
    /**
     * <p>
     * Retrieves the totalPortsToMigrate field.
     * </p>
     *
     * @return the totalPortsToMigrate
     */
    public Integer getTotalPortsToMigrate() {
        return totalPortsToMigrate;
    }
    
    /**
     * <p>
     * Sets the value to totalPortsToMigrate field.
     * </p>
     *
     * @param totalPortsToMigrate
     *            the totalPortsToMigrate to set
     */
    public void setTotalPortsToMigrate(Integer totalPortsToMigrate) {
        this.totalPortsToMigrate = totalPortsToMigrate;
    }

    /**
     * <p>
     * Retrieves the sanSwitchesNumber field.
     * </p>
     *
     * @return the sanSwitchesNumber
     */
    public Integer getSanSwitchesNumber() {
        return sanSwitchesNumber;
    }

    /**
     * <p>
     * Sets the value to sanSwitchesNumber field.
     * </p>
     *
     * @param sanSwitchesNumber
     *            the sanSwitchesNumber to set
     */
    public void setSanSwitchesNumber(Integer sanSwitchesNumber) {
        this.sanSwitchesNumber = sanSwitchesNumber;
    }

    /**
     * <p>
     * Retrieves the bladesNumber field.
     * </p>
     *
     * @return the bladesNumber
     */
    public Integer getBladesNumber() {
        return bladesNumber;
    }

    /**
     * <p>
     * Sets the value to bladesNumber field.
     * </p>
     *
     * @param bladesNumber
     *            the bladesNumber to set
     */
    public void setBladesNumber(Integer bladesNumber) {
        this.bladesNumber = bladesNumber;
    }

    /**
     * <p>
     * Retrieves the fcoeSwitchesNumber field.
     * </p>
     *
     * @return the fcoeSwitchesNumber
     */
    public Integer getFcoeSwitchesNumber() {
        return fcoeSwitchesNumber;
    }

    /**
     * <p>
     * Sets the value to fcoeSwitchesNumber field.
     * </p>
     *
     * @param fcoeSwitchesNumber
     *            the fcoeSwitchesNumber to set
     */
    public void setFcoeSwitchesNumber(Integer fcoeSwitchesNumber) {
        this.fcoeSwitchesNumber = fcoeSwitchesNumber;
    }

    /**
     * <p>
     * Retrieves the fcoeVlanNumber field.
     * </p>
     *
     * @return the fcoeVlanNumber
     */
    public Integer getFcoeVlanNumber() {
        return fcoeVlanNumber;
    }

    /**
     * <p>
     * Sets the value to fcoeVlanNumber field.
     * </p>
     *
     * @param fcoeVlanNumber
     *            the fcoeVlanNumber to set
     */
    public void setFcoeVlanNumber(Integer fcoeVlanNumber) {
        this.fcoeVlanNumber = fcoeVlanNumber;
    }

    /**
     * <p>
     * Retrieves the fcoeChannelNumber field.
     * </p>
     *
     * @return the fcoeChannelNumber
     */
    public Integer getFcoeChannelNumber() {
        return fcoeChannelNumber;
    }

    /**
     * <p>
     * Sets the value to fcoeChannelNumber field.
     * </p>
     *
     * @param fcoeChannelNumber
     *            the fcoeChannelNumber to set
     */
    public void setFcoeChannelNumber(Integer fcoeChannelNumber) {
        this.fcoeChannelNumber = fcoeChannelNumber;
    }

    /**
     * <p>
     * Retrieves the sanExtensionDevicesNumber field.
     * </p>
     *
     * @return the sanExtensionDevicesNumber
     */
    public Integer getSanExtensionDevicesNumber() {
        return sanExtensionDevicesNumber;
    }

    /**
     * <p>
     * Sets the value to sanExtensionDevicesNumber field.
     * </p>
     *
     * @param sanExtensionDevicesNumber
     *            the sanExtensionDevicesNumber to set
     */
    public void setSanExtensionDevicesNumber(Integer sanExtensionDevicesNumber) {
        this.sanExtensionDevicesNumber = sanExtensionDevicesNumber;
    }

    /**
     * <p>
     * Retrieves the nasToCxUnitsNumber field.
     * </p>
     *
     * @return the nasToCxUnitsNumber
     */
    public Integer getNasToCxUnitsNumber() {
        return nasToCxUnitsNumber;
    }

    /**
     * <p>
     * Sets the value to nasToCxUnitsNumber field.
     * </p>
     *
     * @param nasToCxUnitsNumber
     *            the nasToCxUnitsNumber to set
     */
    public void setNasToCxUnitsNumber(Integer nasToCxUnitsNumber) {
        this.nasToCxUnitsNumber = nasToCxUnitsNumber;
    }

    /**
     * <p>
     * Retrieves the nasToSymmetrixUnitsNumber field.
     * </p>
     *
     * @return the nasToSymmetrixUnitsNumber
     */
    public Integer getNasToSymmetrixUnitsNumber() {
        return nasToSymmetrixUnitsNumber;
    }

    /**
     * <p>
     * Sets the value to nasToSymmetrixUnitsNumber field.
     * </p>
     *
     * @param nasToSymmetrixUnitsNumber
     *            the nasToSymmetrixUnitsNumber to set
     */
    public void setNasToSymmetrixUnitsNumber(Integer nasToSymmetrixUnitsNumber) {
        this.nasToSymmetrixUnitsNumber = nasToSymmetrixUnitsNumber;
    }

    /**
     * <p>
     * Retrieves the nasToCxHostsNumber field.
     * </p>
     *
     * @return the nasToCxHostsNumber
     */
    public Integer getNasToCxHostsNumber() {
        return nasToCxHostsNumber;
    }

    /**
     * <p>
     * Sets the value to nasToCxHostsNumber field.
     * </p>
     *
     * @param nasToCxHostsNumber
     *            the nasToCxHostsNumber to set
     */
    public void setNasToCxHostsNumber(Integer nasToCxHostsNumber) {
        this.nasToCxHostsNumber = nasToCxHostsNumber;
    }

    /**
     * <p>
     * Retrieves the nasToSymmetrixHostsNumber field.
     * </p>
     *
     * @return the nasToSymmetrixHostsNumber
     */
    public Integer getNasToSymmetrixHostsNumber() {
        return nasToSymmetrixHostsNumber;
    }

    /**
     * <p>
     * Sets the value to nasToSymmetrixHostsNumber field.
     * </p>
     *
     * @param nasToSymmetrixHostsNumber
     *            the nasToSymmetrixHostsNumber to set
     */
    public void setNasToSymmetrixHostsNumber(Integer nasToSymmetrixHostsNumber) {
        this.nasToSymmetrixHostsNumber = nasToSymmetrixHostsNumber;
    }

    /**
     * <p>
     * Retrieves the deinstalledSanDirectorsNumber field.
     * </p>
     *
     * @return the deinstalledSanDirectorsNumber
     */
    public Integer getDeinstalledSanDirectorsNumber() {
        return deinstalledSanDirectorsNumber;
    }

    /**
     * <p>
     * Sets the value to deinstalledSanDirectorsNumber field.
     * </p>
     *
     * @param deinstalledSanDirectorsNumber
     *            the deinstalledSanDirectorsNumber to set
     */
    public void setDeinstalledSanDirectorsNumber(Integer deinstalledSanDirectorsNumber) {
        this.deinstalledSanDirectorsNumber = deinstalledSanDirectorsNumber;
    }

    /**
     * <p>
     * Retrieves the deinstalledSanSwitchesNumber field.
     * </p>
     *
     * @return the deinstalledSanSwitchesNumber
     */
    public Integer getDeinstalledSanSwitchesNumber() {
        return deinstalledSanSwitchesNumber;
    }

    /**
     * <p>
     * Sets the value to deinstalledSanSwitchesNumber field.
     * </p>
     *
     * @param deinstalledSanSwitchesNumber
     *            the deinstalledSanSwitchesNumber to set
     */
    public void setDeinstalledSanSwitchesNumber(Integer deinstalledSanSwitchesNumber) {
        this.deinstalledSanSwitchesNumber = deinstalledSanSwitchesNumber;
    }

    /**
     * <p>
     * Retrieves the deinstalledSanExtensionDevicesNumber field.
     * </p>
     *
     * @return the deinstalledSanExtensionDevicesNumber
     */
    public Integer getDeinstalledSanExtensionDevicesNumber() {
        return deinstalledSanExtensionDevicesNumber;
    }

    /**
     * <p>
     * Sets the value to deinstalledSanExtensionDevicesNumber field.
     * </p>
     *
     * @param deinstalledSanExtensionDevicesNumber
     *            the deinstalledSanExtensionDevicesNumber to set
     */
    public void setDeinstalledSanExtensionDevicesNumber(Integer deinstalledSanExtensionDevicesNumber) {
        this.deinstalledSanExtensionDevicesNumber = deinstalledSanExtensionDevicesNumber;
    }

    /**
     * The toString method.
     *
     * @return the string for this entity
     */
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("{").append(super.toString());
        sb.append(", knowledgeTransferHours:").append(knowledgeTransferHours);
        sb.append(", sanMigrationInScopeOption:").append(sanMigrationInScopeOption);
        sb.append(", sanDirectorsNumber:").append(sanDirectorsNumber);
        sb.append(", totalPortsToMigrate:").append(totalPortsToMigrate);
        sb.append(", sanSwitchesNumber:").append(sanSwitchesNumber);
        sb.append(", bladesNumber:").append(bladesNumber);
        sb.append(", fcoeSwitchesNumber:").append(fcoeSwitchesNumber);
        sb.append(", fcoeVlanNumber:").append(fcoeVlanNumber);
        sb.append(", fcoeChannelNumber:").append(fcoeChannelNumber);
        sb.append(", sanExtensionDevicesNumber:").append(sanExtensionDevicesNumber);
        sb.append(", nasToCxUnitsNumber:").append(nasToCxUnitsNumber);
        sb.append(", nasToSymmetrixUnitsNumber:").append(nasToSymmetrixUnitsNumber);
        sb.append(", nasToCxHostsNumber:").append(nasToCxHostsNumber);
        sb.append(", nasToSymmetrixHostsNumber:").append(nasToSymmetrixHostsNumber);
        sb.append(", deinstalledSanDirectorsNumber:").append(deinstalledSanDirectorsNumber);
        sb.append(", deinstalledSanSwitchesNumber:").append(deinstalledSanSwitchesNumber);
        sb.append(", deinstalledSanExtensionDevicesNumber:").append(deinstalledSanExtensionDevicesNumber).append("}");
        return sb.toString();
    }
}

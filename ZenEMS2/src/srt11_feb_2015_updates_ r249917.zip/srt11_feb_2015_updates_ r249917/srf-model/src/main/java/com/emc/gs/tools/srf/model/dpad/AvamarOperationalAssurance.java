/*
 * This code is copyright (c) 2014 EMC Corporation
 */
package com.emc.gs.tools.srf.model.dpad;

import com.emc.gs.tools.srf.model.IdentifiableEntity;

/**
 * <p>
 * This is AvamarOperationalAssurance entity class.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safety.
 * </p>
 * 
 * @author TCSASSEMBLER
 * @version 1.0
 * @since SRT Phase 3-5 - BRS Tabs Part 1 Assembly
 */
public class AvamarOperationalAssurance extends IdentifiableEntity {

    /**
     * Include Avamar Custom Operations Guide.
     */
    private Boolean includeOperationsGuide;

    /**
     * Include Avamar Custom Troubleshooting Guide.
     */
    private Boolean includeTroubleshootingGuide;

    /**
     * Include Avamar High Level Architectural Improvement Diagram.
     */
    private Boolean includeHighLevelArch;

    /**
     * # of Avamar Grids.
     */
    private Integer gridsNum;

    /**
     * # of Archive Replication Sites.
     */
    private Integer replicationSitesNum;

    /**
     * <p>
     * The default constructor.
     * </p>
     */
    public AvamarOperationalAssurance() {
    }

    /**
     * Getter method for property <tt>includeOperationsGuide</tt>.
     * 
     * @return property value of includeOperationsGuide
     */
    public Boolean getIncludeOperationsGuide() {
        return includeOperationsGuide;
    }

    /**
     * Setter method for property <tt>includeOperationsGuide</tt>.
     * 
     * @param includeOperationsGuide
     *            value to be assigned to property includeOperationsGuide
     */
    public void setIncludeOperationsGuide(Boolean includeOperationsGuide) {
        this.includeOperationsGuide = includeOperationsGuide;
    }

    /**
     * Getter method for property <tt>includeTroubleshootingGuide</tt>.
     * 
     * @return property value of includeTroubleshootingGuide
     */
    public Boolean getIncludeTroubleshootingGuide() {
        return includeTroubleshootingGuide;
    }

    /**
     * Setter method for property <tt>includeTroubleshootingGuide</tt>.
     * 
     * @param includeTroubleshootingGuide
     *            value to be assigned to property includeTroubleshootingGuide
     */
    public void setIncludeTroubleshootingGuide(Boolean includeTroubleshootingGuide) {
        this.includeTroubleshootingGuide = includeTroubleshootingGuide;
    }

    /**
     * Getter method for property <tt>includeHighLevelArch</tt>.
     * 
     * @return property value of includeHighLevelArch
     */
    public Boolean getIncludeHighLevelArch() {
        return includeHighLevelArch;
    }

    /**
     * Setter method for property <tt>includeHighLevelArch</tt>.
     * 
     * @param includeHighLevelArch
     *            value to be assigned to property includeHighLevelArch
     */
    public void setIncludeHighLevelArch(Boolean includeHighLevelArch) {
        this.includeHighLevelArch = includeHighLevelArch;
    }

    /**
     * Getter method for property <tt>gridsNum</tt>.
     * 
     * @return property value of gridsNum
     */
    public Integer getGridsNum() {
        return gridsNum;
    }

    /**
     * Setter method for property <tt>gridsNum</tt>.
     * 
     * @param gridsNum
     *            value to be assigned to property gridsNum
     */
    public void setGridsNum(Integer gridsNum) {
        this.gridsNum = gridsNum;
    }

    /**
     * Getter method for property <tt>replicationSitesNum</tt>.
     * 
     * @return property value of replicationSitesNum
     */
    public Integer getReplicationSitesNum() {
        return replicationSitesNum;
    }

    /**
     * Setter method for property <tt>replicationSitesNum</tt>.
     * 
     * @param replicationSitesNum
     *            value to be assigned to property replicationSitesNum
     */
    public void setReplicationSitesNum(Integer replicationSitesNum) {
        this.replicationSitesNum = replicationSitesNum;
    }

}

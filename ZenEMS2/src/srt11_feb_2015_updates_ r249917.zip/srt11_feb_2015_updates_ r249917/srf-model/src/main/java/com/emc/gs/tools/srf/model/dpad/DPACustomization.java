/*
 * This code is copyright (c) 2014 EMC Corporation
 */
package com.emc.gs.tools.srf.model.dpad;

/**
 * <p>
 * This is DPACustomization entity class.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safety.
 * </p>
 * 
 * @author TCSASSEMBLER
 * @version 1.0
 * @since SRT Phase 3-5 - BRS Tabs Part 2 Assembly
 */
public class DPACustomization extends DPABase {

    /**
     * Include Data Protection Advisor Third Party Integration Development.
     */
    private Boolean includeThirdPartyIntegrationDevelopment;

    /**
     * The customization data associated with "Include Data Protection Advisor Third Party Integration Development".
     */
    private DPACustomizationData thirdPartyIntegrationDevelopmentData;

    /**
     * The customization data associated with "Include Data Protection Advisor Analysis Jobs".
     */
    private DPACustomizationData analysisJobsData;

    /**
     * # of Data Protection Advisor Analysis Jobs (Estimated).
     */
    private Integer analysisJobsNum;

    /**
     * The customization data associated with "Include Data Protection Advisor Interface Customization".
     */
    private DPACustomizationData interfaceCustomizationData;

    /**
     * The customization data associated with "Include Data Protection Advisor Custom Report Development".
     */
    private DPACustomizationData customReportDevelopmentData;

    /**
     * <p>
     * The default constructor.
     * </p>
     */
    public DPACustomization() {
    }

    /**
     * Getter method for property <tt>includeThirdPartyIntegrationDevelopment</tt>.
     * 
     * @return property value of includeThirdPartyIntegrationDevelopment
     */
    public Boolean getIncludeThirdPartyIntegrationDevelopment() {
        return includeThirdPartyIntegrationDevelopment;
    }

    /**
     * Setter method for property <tt>includeThirdPartyIntegrationDevelopment</tt>.
     * 
     * @param includeThirdPartyIntegrationDevelopment
     *            value to be assigned to property includeThirdPartyIntegrationDevelopment
     */
    public void setIncludeThirdPartyIntegrationDevelopment(Boolean includeThirdPartyIntegrationDevelopment) {
        this.includeThirdPartyIntegrationDevelopment = includeThirdPartyIntegrationDevelopment;
    }

    /**
     * Getter method for property <tt>thirdPartyIntegrationDevelopmentData</tt>.
     * 
     * @return property value of thirdPartyIntegrationDevelopmentData
     */
    public DPACustomizationData getThirdPartyIntegrationDevelopmentData() {
        return thirdPartyIntegrationDevelopmentData;
    }

    /**
     * Setter method for property <tt>thirdPartyIntegrationDevelopmentData</tt>.
     * 
     * @param thirdPartyIntegrationDevelopmentData
     *            value to be assigned to property thirdPartyIntegrationDevelopmentData
     */
    public void setThirdPartyIntegrationDevelopmentData(DPACustomizationData thirdPartyIntegrationDevelopmentData) {
        this.thirdPartyIntegrationDevelopmentData = thirdPartyIntegrationDevelopmentData;
    }

    /**
     * Getter method for property <tt>analysisJobsData</tt>.
     * 
     * @return property value of analysisJobsData
     */
    public DPACustomizationData getAnalysisJobsData() {
        return analysisJobsData;
    }

    /**
     * Setter method for property <tt>analysisJobsData</tt>.
     * 
     * @param analysisJobsData
     *            value to be assigned to property analysisJobsData
     */
    public void setAnalysisJobsData(DPACustomizationData analysisJobsData) {
        this.analysisJobsData = analysisJobsData;
    }

    /**
     * Getter method for property <tt>analysisJobsNum</tt>.
     * 
     * @return property value of analysisJobsNum
     */
    public Integer getAnalysisJobsNum() {
        return analysisJobsNum;
    }

    /**
     * Setter method for property <tt>analysisJobsNum</tt>.
     * 
     * @param analysisJobsNum
     *            value to be assigned to property analysisJobsNum
     */
    public void setAnalysisJobsNum(Integer analysisJobsNum) {
        this.analysisJobsNum = analysisJobsNum;
    }

    /**
     * Getter method for property <tt>interfaceCustomizationData</tt>.
     * 
     * @return property value of interfaceCustomizationData
     */
    public DPACustomizationData getInterfaceCustomizationData() {
        return interfaceCustomizationData;
    }

    /**
     * Setter method for property <tt>interfaceCustomizationData</tt>.
     * 
     * @param interfaceCustomizationData
     *            value to be assigned to property interfaceCustomizationData
     */
    public void setInterfaceCustomizationData(DPACustomizationData interfaceCustomizationData) {
        this.interfaceCustomizationData = interfaceCustomizationData;
    }

    /**
     * Getter method for property <tt>customReportDevelopmentData</tt>.
     * 
     * @return property value of customReportDevelopmentData
     */
    public DPACustomizationData getCustomReportDevelopmentData() {
        return customReportDevelopmentData;
    }

    /**
     * Setter method for property <tt>customReportDevelopmentData</tt>.
     * 
     * @param customReportDevelopmentData
     *            value to be assigned to property customReportDevelopmentData
     */
    public void setCustomReportDevelopmentData(DPACustomizationData customReportDevelopmentData) {
        this.customReportDevelopmentData = customReportDevelopmentData;
    }

}

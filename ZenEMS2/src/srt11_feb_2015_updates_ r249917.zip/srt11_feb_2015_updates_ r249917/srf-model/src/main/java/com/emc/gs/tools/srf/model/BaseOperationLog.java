/*
 * This code is copyright (c) 2014 EMC Corporation.
 */
package com.emc.gs.tools.srf.model;


/**
 * <p>
 * This is the BaseOperationLog entity class.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safe.
 * </p>
 * 
 * @author TCSASSEMBLER
 * @version 1.0
 * @since SRT Phase 4 - ET Assembly 2
 */
public abstract class BaseOperationLog {

    /**
     * <p>
     * The log identifier.
     * </p>
     */
    private String logId;

    /**
     * <p>
     * The entityId.
     * </p>
     */
    private long entityId;

    /**
     * <p>
     * The operation.
     * </p>
     */
    private Operation operation;

    /**
     * <p>
     * The timestamp.
     * </p>
     */
    private long timestamp;

    /**
     * <p>
     * The entityType.
     * </p>
     */
    private String entityType;

    /**
     * <p>
     * The correlated entity Id.
     * </p>
     * <p>
     * On cloud app, it represents the entity id in local app; On local app, it represents the entity id in cloud app.
     * </p>
     */
    private long correlatedId;

    /**
     * <p>
     * The unique user identifier to tie this record to a user.
     * </p>
     * <p>
     * The user identifier is same at both cloud/local sides for given entity.
     * </p>
     */
    private String userIdentifier;

    /**
     * <p>
     * Represent the sequence.
     * </p>
     */
    private long seq;

    /**
     * <p>
     * The default constructor.
     * </p>
     */
    protected BaseOperationLog() {
        // empty
    }

    /**
     * Getter method for property <tt>logId</tt>.
     *
     * @return property value of logId
     */
    public String getLogId() {
        return logId;
    }

    /**
     * Setter method for property <tt>logId</tt>.
     *
     * @param logId
     *            value to be assigned to property logId
     */
    public void setLogId(String logId) {
        this.logId = logId;
    }

    /**
     * <p>
     * Retrieves the entityId field.
     * </p>
     *
     * @return the entityId
     */
    public long getEntityId() {
        return entityId;
    }

    /**
     * <p>
     * Sets the value to entityId field.
     * </p>
     *
     * @param entityId the entityId to set
     */
    public void setEntityId(long entityId) {
        this.entityId = entityId;
    }

    /**
     * <p>
     * Retrieves the operation field.
     * </p>
     *
     * @return the operation
     */
    public Operation getOperation() {
        return operation;
    }

    /**
     * <p>
     * Sets the value to operation field.
     * </p>
     *
     * @param operation the operation to set
     */
    public void setOperation(Operation operation) {
        this.operation = operation;
    }

    /**
     * <p>
     * Retrieves the timestamp field.
     * </p>
     *
     * @return the timestamp
     */
    public long getTimestamp() {
        return timestamp;
    }

    /**
     * <p>
     * Sets the value to timestamp field.
     * </p>
     *
     * @param timestamp the timestamp to set
     */
    public void setTimestamp(long timestamp) {
        this.timestamp = timestamp;
    }

    /**
     * <p>
     * Retrieves the entityType field.
     * </p>
     *
     * @return the entityType
     */
    public String getEntityType() {
        return entityType;
    }

    /**
     * <p>
     * Sets the value to entityType field.
     * </p>
     *
     * @param entityType the entityType to set
     */
    public void setEntityType(String entityType) {
        this.entityType = entityType;
    }

    /**
     * Getter method for property <tt>correlatedId</tt>.
     *
     * @return property value of correlatedId
     */
    public long getCorrelatedId() {
        return correlatedId;
    }

    /**
     * Setter method for property <tt>correlatedId</tt>.
     *
     * @param correlatedId
     *            value to be assigned to property correlatedId
     */
    public void setCorrelatedId(long correlatedId) {
        this.correlatedId = correlatedId;
    }

    /**
     * Getter method for property <tt>userIdentifier</tt>.
     *
     * @return property value of userIdentifier
     */
    public String getUserIdentifier() {
        return userIdentifier;
    }

    /**
     * Setter method for property <tt>userIdentifier</tt>.
     *
     * @param userIdentifier
     *            value to be assigned to property userIdentifier
     */
    public void setUserIdentifier(String userIdentifier) {
        this.userIdentifier = userIdentifier;
    }

    /**
     * Getter method for property <tt>seq</tt>.
     *
     * @return property value of seq
     */
    public long getSeq() {
        return seq;
    }

    /**
     * Setter method for property <tt>seq</tt>.
     *
     * @param seq
     *            value to be assigned to property seq
     */
    public void setSeq(long seq) {
        this.seq = seq;
    }
}

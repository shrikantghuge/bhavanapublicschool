/*
 * This code is copyright (c) 2013 - 2014 EMC Corporation.
 */
package com.emc.gs.tools.srf.model;

/**
 * <p>
 * This is Identifiable entity class.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it's not thread safety.
 * </p>
 *
 * @author faeton, stevenfrog
 * @version 1.0
 */
public abstract class IdentifiableEntity {
    /**
     * The id attribute.
     */
    private long id;

    /**
     * The constructor.
     */
    protected IdentifiableEntity() {
        // Empty
    }

    /**
     * <p>
     * Retrieves the id field.
     * </p>
     *
     * @return the id
     */
    public long getId() {
        return id;
    }

    /**
     * <p>
     * Sets the value to id field.
     * </p>
     *
     * @param id
     *            the id to set
     */
    public void setId(long id) {
        this.id = id;
    }

    /**
     * The toString method.
     *
     * @return the string of this entity
     */
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("id:").append(id);
        return sb.toString();
    }
}

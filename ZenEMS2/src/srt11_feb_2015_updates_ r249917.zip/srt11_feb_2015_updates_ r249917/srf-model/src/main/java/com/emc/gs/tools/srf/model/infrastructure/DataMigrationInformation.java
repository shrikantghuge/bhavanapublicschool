/*
 * This code is copyright (c) 2013 - 2014 EMC Corporation.
 */
package com.emc.gs.tools.srf.model.infrastructure;

import java.util.List;

import com.emc.gs.tools.srf.model.IdentifiableEntity;

/**
 * <p>
 * This is DataMigrationInformation entity class.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safety.
 * </p>
 *
 * <p>
 * <strong>Changes:</strong>
 * <strong>SRT Release Assembly - Mainframe tab</strong>
 * <ul>
 * <li>removed otherArrayToolsHostsNumber</li>
 * </ul>
 * </p>
 * 
 * <p>
 * <strong>Changes V1.1:</strong>
 * <strong>SRT Bug Fixes - F121, F153, F154, F162</strong>
 * <ul>
 * <li>Add knowledgeTransferHours field.</li>
 * </ul>
 * </p>
 * 
 * <p>
 * <strong>Changes V1.2:</strong>
 * <ul>
 * <li>Removed newSitesNumber, migrationTopology, recoverPointMigrationOption, swingFrameMigration, 
 * targetFrameMigration, newTargetHostsNumber, symmetrixSourceArraysNumber, clariionSourceArraysNumber, 
 * symmetrixTargetArraysNumber, clariionTargetArraysNumber fields.</li>
 * </ul>
 * </p>
 * 
 * <p>
 * <strong>Changes V1.3:</strong>
 * <strong>https://apps.topcoder.com/bugs/browse/SRT-35</strong>
 * <ul>
 * <li>Added weekendMigrationsNumber field.</li>
 * </ul>
 * </p>
 *
 * <p>
 * Version 1.4 (SRT 4 OCT2014 Updates Part 1 Assembly) Change notes:
 *   <ol>
 *     <li>Added {@link #includeECA} property.</li>
 *     <li>Added {@link #includeStorageDataErasure} property.</li>
 *     <li>Added {@link #removeRelocateEMCStorage} property.</li>
 *     <li>Added {@link #proposedMigrationTools} property.</li>
 *   </ol>
 * </p>
 * 
 * @author faeton, stevenfrog, MonicaMuranyi, isv
 * @version 1.4
 */
public class DataMigrationInformation extends IdentifiableEntity {
    
    /**
     * <p>
     * The knowledgeTransferHours.
     * </p>
     */
    private String knowledgeTransferHours;

    /**
     * <p>
     * The array information.
     * </p>
     */
    private List<DataMigrationInformationArray> arrayInformation;

    /**
     * <p>
     * The migrationWorker.
     * </p>
     */
    private MigrationWorker migrationWorker;

    /**
     * <p>
     * The migrateLunsToSymmetrixOption.
     * </p>
     */
    private boolean migrateLunsToSymmetrixOption;

    /**
     * <p>
     * The migrateLunsToClariionOption.
     * </p>
     */
    private boolean migrateLunsToClariionOption;

    /**
     * <p>
     * The symmetrixVolumeSizeChange.
     * </p>
     */
    private VolumeSizeChange symmetrixVolumeSizeChange;

    /**
     * <p>
     * The clariionVolumeSizeChange.
     * </p>
     */
    private VolumeSizeChange clariionVolumeSizeChange;

    /**
     * <p>
     * The emcMigrationInvolvement.
     * </p>
     */
    private EmcMigrationInvolvement emcMigrationInvolvement;

    /**
     * <p>
     * The weekendMaintenanceHours.
     * </p>
     */
    private Integer weekendMaintenanceHours;

    /**
     * <p>
     * The migrationCutoverHostsNumber.
     * </p>
     */
    private Integer migrationCutoverHostsNumber;
    
    /**
     * <p>
     * The weekendMigrationsNumber.
     * </p>
     */
    private Integer weekendMigrationsNumber;
    
    /**
     * <p>
     * The migrationCutoverTestsNumber.
     * </p>
     */
    private Integer migrationCutoverTestsNumber;

    /**
     * <p>
     * The migrationCutoverEventsNumber.
     * </p>
     */
    private Integer migrationCutoverEventsNumber;

    /**
     * <p>
     * The scriptAdjustmentOption.
     * </p>
     */
    private boolean scriptAdjustmentOption;

    /**
     * <p>A <code>Boolean</code> providing the value for "Include Environment Collection Appliance (ECA)?"
     * property.</p>
     * 
     * @since 1.4
     */
    private Boolean includeECA;

    /**
     * <p>A <code>Boolean</code> providing the value for "Include Data Erasure of Storage?" property.</p>
     * 
     * @since 1.4
     */
    private Boolean includeStorageDataErasure;

    /**
     * <p>A <code>Boolean</code> providing the value for "Remove or relocate existing EMC storage?" property.</p>
     * 
     * @since 1.4
     */
    private Boolean removeRelocateEMCStorage;

    /**
     * <p>A <code>String</code> providing the value for "Proposed Migration Tools" property.</p>
     * 
     * @since 1.4
     */
    private String proposedMigrationTools;

    /**
     * <p>
     * The default constructor.
     * </p>
     */
    public DataMigrationInformation() {
        // Empty
    }
    
    /**
     * <p>
     * Retrieves the knowledgeTransferHours field.
     * </p>
     *
     * @return the knowledgeTransferHours
     */
    public String getKnowledgeTransferHours() {
        return knowledgeTransferHours;
    }

    /**
     * <p>
     * Sets the value to knowledgeTransferHours field.
     * </p>
     *
     * @param knowledgeTransferHours
     *            the knowledgeTransferHours to set
     */
    public void setKnowledgeTransferHours(String knowledgeTransferHours) {
        this.knowledgeTransferHours = knowledgeTransferHours;
    }

    /**
     * Getter method for property <tt>arrayInformation</tt>.
     * @return property value of arrayInformation
     */
    public List<DataMigrationInformationArray> getArrayInformation() {
        return arrayInformation;
    }

    /**
     * Setter method for property <tt>arrayInformation</tt>.
     * @param arrayInformation value to be assigned to property arrayInformation
     */
    public void setArrayInformation(List<DataMigrationInformationArray> arrayInformation) {
        this.arrayInformation = arrayInformation;
    }

    /**
     * <p>
     * Retrieves the migrationWorker field.
     * </p>
     *
     * @return the migrationWorker
     */
    public MigrationWorker getMigrationWorker() {
        return migrationWorker;
    }

    /**
     * <p>
     * Sets the value to migrationWorker field.
     * </p>
     *
     * @param migrationWorker
     *            the migrationWorker to set
     */
    public void setMigrationWorker(MigrationWorker migrationWorker) {
        this.migrationWorker = migrationWorker;
    }

    /**
     * <p>
     * Retrieves the migrateLunsToSymmetrixOption field.
     * </p>
     *
     * @return the migrateLunsToSymmetrixOption
     */
    public boolean isMigrateLunsToSymmetrixOption() {
        return migrateLunsToSymmetrixOption;
    }

    /**
     * <p>
     * Sets the value to migrateLunsToSymmetrixOption field.
     * </p>
     *
     * @param migrateLunsToSymmetrixOption
     *            the migrateLunsToSymmetrixOption to set
     */
    public void setMigrateLunsToSymmetrixOption(boolean migrateLunsToSymmetrixOption) {
        this.migrateLunsToSymmetrixOption = migrateLunsToSymmetrixOption;
    }

    /**
     * <p>
     * Retrieves the migrateLunsToClariionOption field.
     * </p>
     *
     * @return the migrateLunsToClariionOption
     */
    public boolean isMigrateLunsToClariionOption() {
        return migrateLunsToClariionOption;
    }

    /**
     * <p>
     * Sets the value to migrateLunsToClariionOption field.
     * </p>
     *
     * @param migrateLunsToClariionOption
     *            the migrateLunsToClariionOption to set
     */
    public void setMigrateLunsToClariionOption(boolean migrateLunsToClariionOption) {
        this.migrateLunsToClariionOption = migrateLunsToClariionOption;
    }

    /**
     * <p>
     * Retrieves the symmetrixVolumeSizeChange field.
     * </p>
     *
     * @return the symmetrixVolumeSizeChange
     */
    public VolumeSizeChange getSymmetrixVolumeSizeChange() {
        return symmetrixVolumeSizeChange;
    }

    /**
     * <p>
     * Sets the value to symmetrixVolumeSizeChange field.
     * </p>
     *
     * @param symmetrixVolumeSizeChange
     *            the symmetrixVolumeSizeChange to set
     */
    public void setSymmetrixVolumeSizeChange(VolumeSizeChange symmetrixVolumeSizeChange) {
        this.symmetrixVolumeSizeChange = symmetrixVolumeSizeChange;
    }

    /**
     * <p>
     * Retrieves the clariionVolumeSizeChange field.
     * </p>
     *
     * @return the clariionVolumeSizeChange
     */
    public VolumeSizeChange getClariionVolumeSizeChange() {
        return clariionVolumeSizeChange;
    }

    /**
     * <p>
     * Sets the value to clariionVolumeSizeChange field.
     * </p>
     *
     * @param clariionVolumeSizeChange
     *            the clariionVolumeSizeChange to set
     */
    public void setClariionVolumeSizeChange(VolumeSizeChange clariionVolumeSizeChange) {
        this.clariionVolumeSizeChange = clariionVolumeSizeChange;
    }

    /**
     * <p>
     * Retrieves the emcMigrationInvolvement field.
     * </p>
     *
     * @return the emcMigrationInvolvement
     */
    public EmcMigrationInvolvement getEmcMigrationInvolvement() {
        return emcMigrationInvolvement;
    }

    /**
     * <p>
     * Sets the value to emcMigrationInvolvement field.
     * </p>
     *
     * @param emcMigrationInvolvement
     *            the emcMigrationInvolvement to set
     */
    public void setEmcMigrationInvolvement(EmcMigrationInvolvement emcMigrationInvolvement) {
        this.emcMigrationInvolvement = emcMigrationInvolvement;
    }

    /**
     * <p>
     * Retrieves the weekendMaintenanceHours field.
     * </p>
     *
     * @return the weekendMaintenanceHours
     */
    public Integer getWeekendMaintenanceHours() {
        return weekendMaintenanceHours;
    }

    /**
     * <p>
     * Sets the value to weekendMaintenanceHours field.
     * </p>
     *
     * @param weekendMaintenanceHours
     *            the weekendMaintenanceHours to set
     */
    public void setWeekendMaintenanceHours(Integer weekendMaintenanceHours) {
        this.weekendMaintenanceHours = weekendMaintenanceHours;
    }

    /**
     * <p>
     * Retrieves the migrationCutoverHostsNumber field.
     * </p>
     *
     * @return the migrationCutoverHostsNumber
     */
    public Integer getMigrationCutoverHostsNumber() {
        return migrationCutoverHostsNumber;
    }

    /**
     * <p>
     * Sets the value to migrationCutoverHostsNumber field.
     * </p>
     *
     * @param migrationCutoverHostsNumber
     *            the migrationCutoverHostsNumber to set
     */
    public void setMigrationCutoverHostsNumber(Integer migrationCutoverHostsNumber) {
        this.migrationCutoverHostsNumber = migrationCutoverHostsNumber;
    }
    
    /**
     * <p>
     * Retrieves the weekendMigrationsNumber field.
     * </p>
     *
     * @return the weekendMigrationsNumber
     */
    public Integer getWeekendMigrationsNumber() {
        return weekendMigrationsNumber;
    }

    /**
     * <p>
     * Sets the value to weekendMigrationsNumber field.
     * </p>
     *
     * @param weekendMigrationsNumber
     *            the weekendMigrationsNumber to set
     */
    public void setWeekendMigrationsNumber(Integer weekendMigrationsNumber) {
        this.weekendMigrationsNumber = weekendMigrationsNumber;
    }
    
    /**
     * <p>
     * Retrieves the migrationCutoverTestsNumber field.
     * </p>
     *
     * @return the migrationCutoverTestsNumber
     */
    public Integer getMigrationCutoverTestsNumber() {
        return migrationCutoverTestsNumber;
    }

    /**
     * <p>
     * Sets the value to migrationCutoverTestsNumber field.
     * </p>
     *
     * @param migrationCutoverTestsNumber
     *            the migrationCutoverTestsNumber to set
     */
    public void setMigrationCutoverTestsNumber(Integer migrationCutoverTestsNumber) {
        this.migrationCutoverTestsNumber = migrationCutoverTestsNumber;
    }

    /**
     * <p>
     * Retrieves the migrationCutoverEventsNumber field.
     * </p>
     *
     * @return the migrationCutoverEventsNumber
     */
    public Integer getMigrationCutoverEventsNumber() {
        return migrationCutoverEventsNumber;
    }

    /**
     * <p>
     * Sets the value to migrationCutoverEventsNumber field.
     * </p>
     *
     * @param migrationCutoverEventsNumber
     *            the migrationCutoverEventsNumber to set
     */
    public void setMigrationCutoverEventsNumber(Integer migrationCutoverEventsNumber) {
        this.migrationCutoverEventsNumber = migrationCutoverEventsNumber;
    }

    /**
     * <p>
     * Retrieves the scriptAdjustmentOption field.
     * </p>
     *
     * @return the value of scriptAdjustmentOption
     */
    public boolean isScriptAdjustmentOption() {
        return scriptAdjustmentOption;
    }

    /**
     * <p>
     * Sets the value to scriptAdjustmentOption field.
     * </p>
     *
     * @param scriptAdjustmentOption the value of scriptAdjustmentOption to set
     */
    public void setScriptAdjustmentOption(boolean scriptAdjustmentOption) {
        this.scriptAdjustmentOption = scriptAdjustmentOption;
    }

    /**
     * <p>Gets the "Proposed Migration Tools" property.</p>
     *
     * @return a <code>String</code> providing the value for "Proposed Migration Tools" property.
     * @since 1.4
     */
    public String getProposedMigrationTools() {
        return this.proposedMigrationTools;
    }

    /**
     * <p>Sets the "Proposed Migration Tools" property.</p>
     *
     * @param proposedMigrationTools a <code>String</code> providing the value for "Proposed Migration Tools" property.
     * @since 1.4
     */
    public void setProposedMigrationTools(String proposedMigrationTools) {
        this.proposedMigrationTools = proposedMigrationTools;
    }

    /**
     * <p>Gets the "Remove or relocate existing EMC storage?" property.</p>
     *
     * @return a <code>Boolean</code> providing the value for "Remove or relocate existing EMC storage?" property.
     * @since 1.4
     */
    public Boolean getRemoveRelocateEMCStorage() {
        return this.removeRelocateEMCStorage;
    }

    /**
     * <p>Sets the "Remove or relocate existing EMC storage?" property.</p>
     *
     * @param removeRelocateEMCStorage a <code>Boolean</code> providing the value for "Remove or relocate existing EMC
     * storage?" property.
     * @since 1.4
     */
    public void setRemoveRelocateEMCStorage(Boolean removeRelocateEMCStorage) {
        this.removeRelocateEMCStorage = removeRelocateEMCStorage;
    }

    /**
     * <p>Gets the "Include Data Erasure of Storage?" property.</p>
     *
     * @return a <code>Boolean</code> providing the value for "Include Data Erasure of Storage?" property.
     * @since 1.4
     */
    public Boolean getIncludeStorageDataErasure() {
        return this.includeStorageDataErasure;
    }

    /**
     * <p>Sets the "Include Data Erasure of Storage?" property.</p>
     *
     * @param includeStorageDataErasure a <code>Boolean</code> providing the value for "Include Data Erasure of
     * Storage?" property.
     * @since 1.4
     */
    public void setIncludeStorageDataErasure(Boolean includeStorageDataErasure) {
        this.includeStorageDataErasure = includeStorageDataErasure;
    }

    /**
     * <p>Gets the "Include Environment Collection Appliance (ECA)?" property.</p>
     *
     * @return a <code>Boolean</code> providing the value for "Include Environment Collection Appliance (ECA)?"
     * property.
     * @since 1.4
     */
    public Boolean getIncludeECA() {
        return this.includeECA;
    }

    /**
     * <p>Sets the "Include Environment Collection Appliance (ECA)?" property.</p>
     *
     * @param includeECA a <code>Boolean</code> providing the value for "Include Environment Collection Appliance
     * (ECA)?" property.
     * @since 1.4
     */
    public void setIncludeECA(Boolean includeECA) {
        this.includeECA = includeECA;
    }

    /**
     * The toString method.
     *
     * @return the string for this entity
     */
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("{").append(super.toString());
        sb.append(", knowledgeTransferHours:").append(knowledgeTransferHours);
        sb.append(", arrayInformation:").append(arrayInformation);
        sb.append(", migrationWorker:").append(migrationWorker);
        sb.append(", migrateLunsToSymmetrixOption:").append(migrateLunsToSymmetrixOption);
        sb.append(", migrateLunsToClariionOption:").append(migrateLunsToClariionOption);
        sb.append(", symmetrixVolumeSizeChange:").append(symmetrixVolumeSizeChange);
        sb.append(", clariionVolumeSizeChange:").append(clariionVolumeSizeChange);
        sb.append(", emcMigrationInvolvement:").append(emcMigrationInvolvement);
        sb.append(", weekendMaintenanceHours:").append(weekendMaintenanceHours);
        sb.append(", weekendMigrationsNumber:").append(weekendMigrationsNumber);
        sb.append(", migrationCutoverTestsNumber:").append(migrationCutoverTestsNumber);
        sb.append(", migrationCutoverEventsNumber:").append(migrationCutoverEventsNumber);
        sb.append(", scriptAdjustmentOption:").append(scriptAdjustmentOption);
        sb.append(", includeECA:").append(includeECA);
        sb.append(", includeStorageDataErasure:").append(includeStorageDataErasure);
        sb.append(", removeRelocateEMCStorage:").append(removeRelocateEMCStorage);
        sb.append(", proposedMigrationTools:").append(proposedMigrationTools);
        sb.append(", migrationCutoverHostsNumber:").append(migrationCutoverHostsNumber).append("}");
        return sb.toString();
    }
}

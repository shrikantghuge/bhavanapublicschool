/*
 * This code is copyright (c) 2014 EMC Corporation
 */
package com.emc.gs.tools.srf.model.dpad;

/**
 * <p>
 * This is DPADesign entity class.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safety.
 * </p>
 * 
 * @author TCSASSEMBLER
 * @version 1.0
 * @since SRT Phase 3-5 - BRS Tabs Part 2 Assembly
 */
public class DPADesign extends DPABase {

    /**
     * Install Data Protection Advisor on Extended Database (Oracle, MS SQL, etc.).
     */
    private Boolean installOnExtendedDatabase;

    /**
     * Include Data Protection Advisor Recoverability Analysis.
     */
    private Boolean includeRecoverabilityAnalysis;

    /**
     * Include Data Protection Advisor Scale Plan.
     */
    private Boolean includeScalePlan;

    /**
     * # of Data Protection Advisor Collection Nodes.
     */
    private Integer collectionNodesNum;

    /**
     * # of Data Protection Collector Nodes to Configure.
     */
    private Integer collectorNodesNum;

    /**
     * <p>
     * The default constructor.
     * </p>
     */
    public DPADesign() {
    }

    /**
     * Getter method for property <tt>installOnExtendedDatabase</tt>.
     * 
     * @return property value of installOnExtendedDatabase
     */
    public Boolean getInstallOnExtendedDatabase() {
        return installOnExtendedDatabase;
    }

    /**
     * Setter method for property <tt>installOnExtendedDatabase</tt>.
     * 
     * @param installOnExtendedDatabase
     *            value to be assigned to property installOnExtendedDatabase
     */
    public void setInstallOnExtendedDatabase(Boolean installOnExtendedDatabase) {
        this.installOnExtendedDatabase = installOnExtendedDatabase;
    }

    /**
     * Getter method for property <tt>includeRecoverabilityAnalysis</tt>.
     * 
     * @return property value of includeRecoverabilityAnalysis
     */
    public Boolean getIncludeRecoverabilityAnalysis() {
        return includeRecoverabilityAnalysis;
    }

    /**
     * Setter method for property <tt>includeRecoverabilityAnalysis</tt>.
     * 
     * @param includeRecoverabilityAnalysis
     *            value to be assigned to property includeRecoverabilityAnalysis
     */
    public void setIncludeRecoverabilityAnalysis(Boolean includeRecoverabilityAnalysis) {
        this.includeRecoverabilityAnalysis = includeRecoverabilityAnalysis;
    }

    /**
     * Getter method for property <tt>includeScalePlan</tt>.
     * 
     * @return property value of includeScalePlan
     */
    public Boolean getIncludeScalePlan() {
        return includeScalePlan;
    }

    /**
     * Setter method for property <tt>includeScalePlan</tt>.
     * 
     * @param includeScalePlan
     *            value to be assigned to property includeScalePlan
     */
    public void setIncludeScalePlan(Boolean includeScalePlan) {
        this.includeScalePlan = includeScalePlan;
    }

    /**
     * Getter method for property <tt>collectionNodesNum</tt>.
     * 
     * @return property value of collectionNodesNum
     */
    public Integer getCollectionNodesNum() {
        return collectionNodesNum;
    }

    /**
     * Setter method for property <tt>collectionNodesNum</tt>.
     * 
     * @param collectionNodesNum
     *            value to be assigned to property collectionNodesNum
     */
    public void setCollectionNodesNum(Integer collectionNodesNum) {
        this.collectionNodesNum = collectionNodesNum;
    }

    /**
     * Getter method for property <tt>collectorNodesNum</tt>.
     * 
     * @return property value of collectorNodesNum
     */
    public Integer getCollectorNodesNum() {
        return collectorNodesNum;
    }

    /**
     * Setter method for property <tt>collectorNodesNum</tt>.
     * 
     * @param collectorNodesNum
     *            value to be assigned to property collectorNodesNum
     */
    public void setCollectorNodesNum(Integer collectorNodesNum) {
        this.collectorNodesNum = collectorNodesNum;
    }

}

/*
 * This code is copyright (c) 2014 EMC Corporation.
 */
package com.emc.gs.tools.srf.model.deal;

import com.emc.gs.tools.srf.model.Division;
import com.emc.gs.tools.srf.model.Geography;
import com.emc.gs.tools.srf.model.IdentifiableEntity;

/**
 * <p>This is RiskCalculationData entity class.</p>
 *
 * <p><strong>Thread safety</strong>: This class is mutable, it is not thread safety.</p>
 *
 * @author isv
 * @version 1.0 (SRT 1.1 DEC 2014 Risk Calculation Assembly)
 */
public class RiskCalculationData extends IdentifiableEntity {

    /**
     * <p>A <code>Geography</code> providing the value for "theater" property.</p>
     */
    private Geography theater;

    /**
     * <p>A <code>Division</code> providing the value for "division" property.</p>
     */
    private Division division;

    /**
     * <p>A <code>MultipleTheatersLanguagesInvolvementOption</code> providing the value for "Will delivery involve
     * multiple Theaters or Languages?" property.</p>
     */
    private MultipleTheatersLanguagesInvolvementOption multipleTheatresLanguagesInvolvement;

    /**
     * <p>A <code>EMCFederatedCompaniesInvolvementOption</code> providing the value for "Will delivery involve any EMC
     * Federated companies?" property.</p>
     */
    private EMCFederatedCompaniesInvolvementOption emcFederatedCompaniesInvolvement;

    /**
     * <p>A <code>MultipleWorkgroupsDisciplinesOption</code> providing the value for "Will delivery involve multiple
     * Workgroups or Disciplines?" property.</p>
     */
    private MultipleWorkgroupsDisciplinesOption multipleWorkgroupsDisciplinesInvolvement;

    /**
     * <p>A <code>ThirdPartyInvolvementOption</code> providing the value for "Is there a 3rd Party between us and the
     * end Client?" property.</p>
     */
    private ThirdPartyInvolvementOption thirdPartyInvolvement;

    /**
     * <p>A <code>Integer</code> providing the value for "What is the list price ($) of this opportunity?"
     * property.</p>
     */
    private Integer listPrice;

    /**
     * <p>A <code>Integer</code> providing the value for "What is the potential value of subsequent phases?"
     * property.</p>
     */
    private Integer potentialValue;

    /**
     * <p>A <code>TMBillingUsageOption</code> providing the value for "Will standard T&M billing will be used?"
     * property.</p>
     */
    private TMBillingUsageOption tmBillingUsageType;

    /**
     * <p>A <code>EMCAccountabilityOption</code> providing the value for "Will EMC be accountable for any deliverables?"
     * property .</p>
     */
    private EMCAccountabilityOption emcAccountabilityType;

    /**
     * <p>A <code>EMCClientOption</code> providing the value for "Is this a new or existing EMC Client?" property .</p>
     */
    private EMCClientOption emcClientType;

    /**
     * <p>A <code>EMCClientRelationshipOption</code> providing the value for "What is the state of the EMC relationship
     * with this Client?" property.</p>
     */
    private EMCClientRelationshipOption emcClientRelationshipType;

    /**
     * <p>A <code>ProcessStaffMaturityOption</code> providing the value for "What is the client's process and staff
     * maturity?" property.</p>
     */
    private ProcessStaffMaturityOption clientProcessStaffMaturityType;

    /**
     * <p>A <code>ClientEnvironmentDocumentationQualityOption</code> providing the value for "How well is the client's
     * environment documented?" property.</p>
     */
    private ClientEnvironmentDocumentationQualityOption clientEnvironmentDocumentationType;

    /**
     * <p>A <code>ProjectScopeUnderstandingOption</code> providing the value for "Does EMC and the client fully
     * understand the Project Scope?" property.</p>
     */
    private ProjectScopeUnderstandingOption projectScopeUnderstandingType;

    /**
     * <p>A <code>ProjectImpactOption</code> providing the value for "How strategic is the Project to EMC and Client?"
     * property.</p>
     */
    private ProjectImpactOption projectImpactType;

    /**
     * <p>A <code>ProjectSponsorInvolvementOption</code> providing the value for "How involved will the client project
     * sponsor be?" property.</p>
     */
    private ProjectSponsorInvolvementOption projectSponsorInvolvementType;

    /**
     * <p>A <code>OfferingMaturityOption</code> providing the value for "What is the maturity of the offering being
     * proposed?" property.</p>
     */
    private OfferingMaturityOption offeringMaturityType;

    /**
     * <p>A <code>ProjectComplexityLevelOption</code> providing the value for "What is the expected complexity level of
     * the project?" property.</p>
     */
    private ProjectComplexityLevelOption projectComplexityLevel;

    /**
     * <p>A <code>ExternalFactorsOption</code> providing the value for "Are there any external factors impacting the
     * project schedule?" property.</p>
     */
    private ExternalFactorsOption externalFactorsType;

    /**
     * <p>A <code>EMCStaffAvailabilityOption</code> providing the value for "What is the availability of EMC staff to
     * deliver this?" property.</p>
     */
    private EMCStaffAvailabilityOption emcStaffAvailability;

    /**
     * <p>A <code>PartnerStaffAvailabilityOption</code> providing the value for "What is the availability of partner
     * staff to deliver this?" property.</p>
     */
    private PartnerStaffAvailabilityOption partnerStaffAvailability;

    /**
     * <p>A <code>RiskLevelOption</code> providing the value for "Any additional risks not mentioned above?"
     * property.</p>
     */
    private RiskLevelOption additionalRiskLevel;

    /**
     * <p>A <code>String</code> providing the value for "Risk" property.</p>
     */
    private String risk;

    /**
     * <p>A <code>String</code> providing the value for "Rationale" property.</p>
     */
    private String rationale;

    /**
     * <p>A <code>Integer</code> providing the value for "Adjustment" property.</p>
     */
    private Integer adjustment;

    /**
     * <p>A <code>ProgramManagementUseCaseOption</code> providing the value for "Does Opportunity Meet PgM Use 
     * Case(s)"
     * property.</p>
     */
    private ProgramManagementUseCaseOption programManagementUseCaseType;

    /**
     * <p>Constructs new <code>RiskCalculationData</code> instance. This implementation does nothing.</p>
     */
    public RiskCalculationData() {
    }

    /**
     * <p>Gets the "Does Opportunity Meet PgM Use Case(s)" property.</p>
     *
     * @return a <code>ProgramManagementUseCaseOption</code> providing the value for "Does Opportunity Meet PgM Use
     * Case(s)" property.
     */
    public ProgramManagementUseCaseOption getProgramManagementUseCaseType() {
        return this.programManagementUseCaseType;
    }

    /**
     * <p>Sets the "Does Opportunity Meet PgM Use Case(s)" property.</p>
     *
     * @param programManagementUseCaseType a <code>ProgramManagementUseCaseOption</code> providing the value for 
     * "Does
     * Opportunity Meet PgM Use Case(s)" property.
     */
    public void setProgramManagementUseCaseType(ProgramManagementUseCaseOption programManagementUseCaseType) {
        this.programManagementUseCaseType = programManagementUseCaseType;
    }

    /**
     * <p>Gets the "Adjustment" property.</p>
     *
     * @return a <code>Integer</code> providing the value for "Adjustment" property.
     */
    public Integer getAdjustment() {
        return this.adjustment;
    }

    /**
     * <p>Sets the "Adjustment" property.</p>
     *
     * @param adjustment a <code>Integer</code> providing the value for "Adjustment" property.
     */
    public void setAdjustment(Integer adjustment) {
        this.adjustment = adjustment;
    }

    /**
     * <p>Gets the "Rationale" property.</p>
     *
     * @return a <code>String</code> providing the value for "Rationale" property.
     */
    public String getRationale() {
        return this.rationale;
    }

    /**
     * <p>Sets the "Rationale" property.</p>
     *
     * @param rationale a <code>String</code> providing the value for "Rationale" property.
     */
    public void setRationale(String rationale) {
        this.rationale = rationale;
    }

    /**
     * <p>Gets the "Risk" property.</p>
     *
     * @return a <code>String</code> providing the value for "Risk" property.
     */
    public String getRisk() {
        return this.risk;
    }

    /**
     * <p>Sets the "Risk" property.</p>
     *
     * @param risk a <code>String</code> providing the value for "Risk" property.
     */
    public void setRisk(String risk) {
        this.risk = risk;
    }

    /**
     * <p>Gets the "Any additional risks not mentioned above?" property.</p>
     *
     * @return a <code>RiskLevelOption</code> providing the value for "Any additional risks not mentioned above?"
     * property.
     */
    public RiskLevelOption getAdditionalRiskLevel() {
        return this.additionalRiskLevel;
    }

    /**
     * <p>Sets the "Any additional risks not mentioned above?" property.</p>
     *
     * @param additionalRiskLevel a <code>RiskLevelOption</code> providing the value for "Any additional risks not
     * mentioned above?" property.
     */
    public void setAdditionalRiskLevel(RiskLevelOption additionalRiskLevel) {
        this.additionalRiskLevel = additionalRiskLevel;
    }

    /**
     * <p>Gets the "What is the availability of partner staff to deliver this?" property.</p>
     *
     * @return a <code>PartnerStaffAvailabilityOption</code> providing the value for "What is the availability of
     * partner staff to deliver this?" property.
     */
    public PartnerStaffAvailabilityOption getPartnerStaffAvailability() {
        return this.partnerStaffAvailability;
    }

    /**
     * <p>Sets the "What is the availability of partner staff to deliver this?" property.</p>
     *
     * @param partnerStaffAvailability a <code>PartnerStaffAvailabilityOption</code> providing the value for "What is
     * the availability of partner staff to deliver this?" property.
     */
    public void setPartnerStaffAvailability(PartnerStaffAvailabilityOption partnerStaffAvailability) {
        this.partnerStaffAvailability = partnerStaffAvailability;
    }

    /**
     * <p>Gets the "What is the availability of EMC staff to deliver this?" property.</p>
     *
     * @return a <code>EMCStaffAvailabilityOption</code> providing the value for "What is the availability of EMC staff
     * to deliver this?" property.
     */
    public EMCStaffAvailabilityOption getEmcStaffAvailability() {
        return this.emcStaffAvailability;
    }

    /**
     * <p>Sets the "What is the availability of EMC staff to deliver this?" property.</p>
     *
     * @param emcStaffAvailability a <code>EMCStaffAvailabilityOption</code> providing the value for "What is the
     * availability of EMC staff to deliver this?" property.
     */
    public void setEmcStaffAvailability(EMCStaffAvailabilityOption emcStaffAvailability) {
        this.emcStaffAvailability = emcStaffAvailability;
    }

    /**
     * <p>Gets the "Are there any external factors impacting the project schedule?" property.</p>
     *
     * @return a <code>ExternalFactorsOption</code> providing the value for "Are there any external factors impacting
     * the project schedule?" property.
     */
    public ExternalFactorsOption getExternalFactorsType() {
        return this.externalFactorsType;
    }

    /**
     * <p>Sets the "Are there any external factors impacting the project schedule?" property.</p>
     *
     * @param externalFactorsType a <code>ExternalFactorsOption</code> providing the value for "Are there any external
     * factors impacting the project schedule?" property.
     */
    public void setExternalFactorsType(ExternalFactorsOption externalFactorsType) {
        this.externalFactorsType = externalFactorsType;
    }

    /**
     * <p>Gets the "What is the expected complexity level of the project?" property.</p>
     *
     * @return a <code>ProjectComplexityLevelOption</code> providing the value for "What is the expected complexity
     * level of the project?" property.
     */
    public ProjectComplexityLevelOption getProjectComplexityLevel() {
        return this.projectComplexityLevel;
    }

    /**
     * <p>Sets the "What is the expected complexity level of the project?" property.</p>
     *
     * @param projectComplexityLevel a <code>ProjectComplexityLevelOption</code> providing the value for "What is the
     * expected complexity level of the project?" property.
     */
    public void setProjectComplexityLevel(ProjectComplexityLevelOption projectComplexityLevel) {
        this.projectComplexityLevel = projectComplexityLevel;
    }

    /**
     * <p>Gets the "What is the maturity of the offering being proposed?" property.</p>
     *
     * @return a <code>OfferingMaturityOption</code> providing the value for "What is the maturity of the offering being
     * proposed?" property.
     */
    public OfferingMaturityOption getOfferingMaturityType() {
        return this.offeringMaturityType;
    }

    /**
     * <p>Sets the "What is the maturity of the offering being proposed?" property.</p>
     *
     * @param offeringMaturityType a <code>OfferingMaturityOption</code> providing the value for "What is the maturity
     * of the offering being proposed?" property.
     */
    public void setOfferingMaturityType(OfferingMaturityOption offeringMaturityType) {
        this.offeringMaturityType = offeringMaturityType;
    }

    /**
     * <p>Gets the "How involved will the client project sponsor be?" property.</p>
     *
     * @return a <code>ProjectSponsorInvolvementOption</code> providing the value for "How involved will the client
     * project sponsor be?" property.
     */
    public ProjectSponsorInvolvementOption getProjectSponsorInvolvementType() {
        return this.projectSponsorInvolvementType;
    }

    /**
     * <p>Sets the "How involved will the client project sponsor be?" property.</p>
     *
     * @param projectSponsorInvolvementType a <code>ProjectSponsorInvolvementOption</code> providing the value for "How
     * involved will the client project sponsor be?" property.
     */
    public void setProjectSponsorInvolvementType(ProjectSponsorInvolvementOption projectSponsorInvolvementType) {
        this.projectSponsorInvolvementType = projectSponsorInvolvementType;
    }

    /**
     * <p>Gets the "How strategic is the Project to EMC and Client?" property.</p>
     *
     * @return a <code>ProjectImpactOption</code> providing the value for "How strategic is the Project to EMC and
     * Client?" property.
     */
    public ProjectImpactOption getProjectImpactType() {
        return this.projectImpactType;
    }

    /**
     * <p>Sets the "How strategic is the Project to EMC and Client?" property.</p>
     *
     * @param projectImpactType a <code>ProjectImpactOption</code> providing the value for "How strategic is the Project
     * to EMC and Client?" property.
     */
    public void setProjectImpactType(ProjectImpactOption projectImpactType) {
        this.projectImpactType = projectImpactType;
    }

    /**
     * <p>Gets the "Does EMC and the client fully understand the Project Scope?" property.</p>
     *
     * @return a <code>ProjectScopeUnderstandingOption</code> providing the value for "Does EMC and the client fully
     * understand the Project Scope?" property.
     */
    public ProjectScopeUnderstandingOption getProjectScopeUnderstandingType() {
        return this.projectScopeUnderstandingType;
    }

    /**
     * <p>Sets the "Does EMC and the client fully understand the Project Scope?" property.</p>
     *
     * @param projectScopeUnderstandingType a <code>ProjectScopeUnderstandingOption</code> providing the value for "Does
     * EMC and the client fully understand the Project Scope?" property.
     */
    public void setProjectScopeUnderstandingType(ProjectScopeUnderstandingOption projectScopeUnderstandingType) {
        this.projectScopeUnderstandingType = projectScopeUnderstandingType;
    }

    /**
     * <p>Gets the "How well is the client's environment documented?" property.</p>
     *
     * @return a <code>ClientEnvironmentDocumentationQualityOption</code> providing the value for "How well is the client's
     * environment documented?" property.
     */
    public ClientEnvironmentDocumentationQualityOption getClientEnvironmentDocumentationType() {
        return this.clientEnvironmentDocumentationType;
    }

    /**
     * <p>Sets the "How well is the client's environment documented?" property.</p>
     *
     * @param clientEnvironmentDocumentationType a <code>ClientEnvironmentDocumentationQualityOption</code> providing the value
     * for "How well is the client's environment documented?" property.
     */
    public void setClientEnvironmentDocumentationType(
        ClientEnvironmentDocumentationQualityOption clientEnvironmentDocumentationType) {
        this.clientEnvironmentDocumentationType = clientEnvironmentDocumentationType;
    }

    /**
     * <p>Gets the "What is the client's process and staff maturity?" property.</p>
     *
     * @return a <code>ProcessStaffMaturityOption</code> providing the value for "What is the client's process and staff
     * maturity?" property.
     */
    public ProcessStaffMaturityOption getClientProcessStaffMaturityType() {
        return this.clientProcessStaffMaturityType;
    }

    /**
     * <p>Sets the "What is the client's process and staff maturity?" property.</p>
     *
     * @param clientProcessStaffMaturityType a <code>ProcessStaffMaturityOption</code> providing the value for "What is
     * the client's process and staff maturity?" property.
     */
    public void setClientProcessStaffMaturityType(ProcessStaffMaturityOption clientProcessStaffMaturityType) {
        this.clientProcessStaffMaturityType = clientProcessStaffMaturityType;
    }

    /**
     * <p>Gets the "What is the state of the EMC relationship with this Client?" property.</p>
     *
     * @return a <code>EMCClientRelationshipOption</code> providing the value for "What is the state of the EMC
     * relationship with this Client?" property.
     */
    public EMCClientRelationshipOption getEmcClientRelationshipType() {
        return this.emcClientRelationshipType;
    }

    /**
     * <p>Sets the "What is the state of the EMC relationship with this Client?" property.</p>
     *
     * @param emcClientRelationshipType a <code>EMCClientRelationshipOption</code> providing the value for "What is the
     * state of the EMC relationship with this Client?" property.
     */
    public void setEmcClientRelationshipType(EMCClientRelationshipOption emcClientRelationshipType) {
        this.emcClientRelationshipType = emcClientRelationshipType;
    }

    /**
     * <p>Gets the "Is this a new or existing EMC Client?" property.</p>
     *
     * @return a <code>EMCClientOption</code> providing the value for "Is this a new or existing EMC Client?" property.
     */
    public EMCClientOption getEmcClientType() {
        return this.emcClientType;
    }

    /**
     * <p>Sets the "Is this a new or existing EMC Client?" property.</p>
     *
     * @param emcClientType a <code>EMCClientOption</code> providing the value for "Is this a new or existing EMC
     * Client?" property.
     */
    public void setEmcClientType(EMCClientOption emcClientType) {
        this.emcClientType = emcClientType;
    }


    /**
     * <p>Gets the "Will EMC be accountable for any deliverables?" property.</p>
     *
     * @return a <code>EMCAccountabilityOption</code> providing the value for "Will EMC be accountable for any
     * deliverables?" property.
     */
    public EMCAccountabilityOption getEmcAccountabilityType() {
        return this.emcAccountabilityType;
    }

    /**
     * <p>Sets the "Will EMC be accountable for any deliverables?" property.</p>
     *
     * @param emcAccountabilityType a <code>EMCAccountabilityOption</code> providing the value for "Will EMC be
     * accountable for any deliverables?" property.
     */
    public void setEmcAccountabilityType(EMCAccountabilityOption emcAccountabilityType) {
        this.emcAccountabilityType = emcAccountabilityType;
    }

    /**
     * <p>Gets the "Will standard T&M billing will be used?" property.</p>
     *
     * @return a <code>TMBillingUsageOption</code> providing the value for "Will standard T&M billing will be used?"
     * property.
     */
    public TMBillingUsageOption getTmBillingUsageType() {
        return this.tmBillingUsageType;
    }

    /**
     * <p>Sets the "Will standard T&M billing will be used?" property.</p>
     *
     * @param tmBillingUsageType a <code>TMBillingUsageOption</code> providing the value for "Will standard T&M billing
     * will be used?" property.
     */
    public void setTmBillingUsageType(TMBillingUsageOption tmBillingUsageType) {
        this.tmBillingUsageType = tmBillingUsageType;
    }

    /**
     * <p>Gets the "What is the potential value of subsequent phases?" property.</p>
     *
     * @return a <code>Integer</code> providing the value for "What is the potential value of subsequent phases?"
     * property.
     */
    public Integer getPotentialValue() {
        return this.potentialValue;
    }

    /**
     * <p>Sets the "What is the potential value of subsequent phases?" property.</p>
     *
     * @param potentialValue a <code>Integer</code> providing the value for "What is the potential value of subsequent
     * phases?" property.
     */
    public void setPotentialValue(Integer potentialValue) {
        this.potentialValue = potentialValue;
    }

    /**
     * <p>Gets the "What is the list price ($) of this opportunity?" property.</p>
     *
     * @return a <code>Integer</code> providing the value for "What is the list price ($) of this opportunity?"
     * property.
     */
    public Integer getListPrice() {
        return this.listPrice;
    }

    /**
     * <p>Sets the "What is the list price ($) of this opportunity?" property.</p>
     *
     * @param listPrice a <code>Integer</code> providing the value for "What is the list price ($) of this opportunity?"
     * property.
     */
    public void setListPrice(Integer listPrice) {
        this.listPrice = listPrice;
    }


    /**
     * <p>Gets the "Is there a 3rd Party between us and the end Client?" property.</p>
     *
     * @return a <code>ThirdPartyInvolvementOption</code> providing the value for "Is there a 3rd Party between us and
     * the end Client?" property.
     */
    public ThirdPartyInvolvementOption getThirdPartyInvolvement() {
        return this.thirdPartyInvolvement;
    }

    /**
     * <p>Sets the "Is there a 3rd Party between us and the end Client?" property.</p>
     *
     * @param thirdPartyInvolvement a <code>ThirdPartyInvolvementOption</code> providing the value for "Is there a 3rd
     * Party between us and the end Client?" property.
     */
    public void setThirdPartyInvolvement(ThirdPartyInvolvementOption thirdPartyInvolvement) {
        this.thirdPartyInvolvement = thirdPartyInvolvement;
    }

    /**
     * <p>Gets the "Will delivery involve any EMC Federated companies?" property.</p>
     *
     * @return a <code>EMCFederatedCompaniesInvolvementOption</code> providing the value for "Will delivery involve any
     * EMC Federated companies?" property.
     */
    public EMCFederatedCompaniesInvolvementOption getEmcFederatedCompaniesInvolvement() {
        return this.emcFederatedCompaniesInvolvement;
    }

    /**
     * <p>Sets the "Will delivery involve any EMC Federated companies?" property.</p>
     *
     * @param emcFederatedCompaniesInvolvement a <code>EMCFederatedCompaniesInvolvementOption</code> providing the value
     * for "Will delivery involve any EMC Federated companies?" property.
     */
    public void setEmcFederatedCompaniesInvolvement(
        EMCFederatedCompaniesInvolvementOption emcFederatedCompaniesInvolvement) {
        this.emcFederatedCompaniesInvolvement = emcFederatedCompaniesInvolvement;
    }

    /**
     * <p>Gets the "division" property.</p>
     *
     * @return a <code>Division</code> providing the value for "division" property.
     */
    public Division getDivision() {
        return this.division;
    }

    /**
     * <p>Sets the "division" property.</p>
     *
     * @param division a <code>Division</code> providing the value for "division" property.
     */
    public void setDivision(Division division) {
        this.division = division;
    }

    /**
     * <p>Gets the "theater" property.</p>
     *
     * @return a <code>Geography</code> providing the value for "theater" property.
     */
    public Geography getTheater() {
        return this.theater;
    }

    /**
     * <p>Sets the "theater" property.</p>
     *
     * @param theater a <code>Geography</code> providing the value for "theater" property.
     */
    public void setTheater(Geography theater) {
        this.theater = theater;
    }

    /**
     * <p>Gets the "Will delivery involve multiple Theaters or Languages?" property.</p>
     *
     * @return a <code>MultipleTheatersLanguagesInvolvementOption</code> providing the value for "Will delivery involve
     * multiple Theaters or Languages?" property.
     */
    public MultipleTheatersLanguagesInvolvementOption getMultipleTheatresLanguagesInvolvement() {
        return this.multipleTheatresLanguagesInvolvement;
    }

    /**
     * <p>Sets the "Will delivery involve multiple Theaters or Languages?" property.</p>
     *
     * @param multipleTheatresLanguagesInvolvement a <code>MultipleTheatersLanguagesInvolvementOption</code> providing
     * the value for "Will delivery involve multiple Theaters or Languages?" property.
     */
    public void setMultipleTheatresLanguagesInvolvement(
        MultipleTheatersLanguagesInvolvementOption multipleTheatresLanguagesInvolvement) {
        this.multipleTheatresLanguagesInvolvement = multipleTheatresLanguagesInvolvement;
    }

    /**
     * <p>Gets the "Will delivery involve multiple Workgroups or Disciplines?" property.</p>
     *
     * @return a <code>MultipleWorkgroupsDisciplinesOption</code> providing the value for "Will delivery involve
     * multiple Workgroups or Disciplines?" property.
     */
    public MultipleWorkgroupsDisciplinesOption getMultipleWorkgroupsDisciplinesInvolvement() {
        return this.multipleWorkgroupsDisciplinesInvolvement;
    }

    /**
     * <p>Sets the "Will delivery involve multiple Workgroups or Disciplines?" property.</p>
     *
     * @param multipleWorkgroupsDisciplinesInvolvement a <code>MultipleWorkgroupsDisciplinesOption</code> providing the
     * value for "Will delivery involve multiple Workgroups or Disciplines?" property.
     */
    public void setMultipleWorkgroupsDisciplinesInvolvement(
        MultipleWorkgroupsDisciplinesOption multipleWorkgroupsDisciplinesInvolvement) {
        this.multipleWorkgroupsDisciplinesInvolvement = multipleWorkgroupsDisciplinesInvolvement;
    }
}

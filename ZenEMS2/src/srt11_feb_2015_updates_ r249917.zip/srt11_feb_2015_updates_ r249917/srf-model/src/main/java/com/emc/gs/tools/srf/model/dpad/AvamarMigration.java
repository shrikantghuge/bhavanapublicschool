/*
 * This code is copyright (c) 2014 EMC Corporation
 */
package com.emc.gs.tools.srf.model.dpad;

import com.emc.gs.tools.srf.model.IdentifiableEntity;

/**
 * <p>
 * This is AvamarMigration entity class.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safety.
 * </p>
 * 
 * @author TCSASSEMBLER
 * @version 1.0
 * @since SRT Phase 3-5 - BRS Tabs Part 1 Assembly
 */
public class AvamarMigration extends IdentifiableEntity {

    /**
     * Select Migration Type.
     */
    private AvamarMigrationType migrationType;

    /**
     * Include Client Reconfiguration.
     */
    private Boolean includeClientReconfiguration;

    /**
     * Include Source Avamar Data Wipe.
     */
    private Boolean includeSourceDataWipe;

    /**
     * # of Source System Nodes.
     */
    private Integer sourceSysNodesNum;

    /**
     * # of Target System Nodes.
     */
    private Integer targetSysNodesNum;

    /**
     * # of Replication Monitoring Events(1 Hour Per).
     */
    private Integer replicationMonitoringEventsNum;

    /**
     * # of Avamar Clients to Reconfigure.
     */
    private Integer reconfigureClientsNum;

    /**
     * <p>
     * The default constructor.
     * </p>
     */
    public AvamarMigration() {
    }

    /**
     * Getter method for property <tt>migrationType</tt>.
     * 
     * @return property value of migrationType
     */
    public AvamarMigrationType getMigrationType() {
        return migrationType;
    }

    /**
     * Setter method for property <tt>migrationType</tt>.
     * 
     * @param migrationType
     *            value to be assigned to property migrationType
     */
    public void setMigrationType(AvamarMigrationType migrationType) {
        this.migrationType = migrationType;
    }

    /**
     * Getter method for property <tt>includeClientReconfiguration</tt>.
     * 
     * @return property value of includeClientReconfiguration
     */
    public Boolean getIncludeClientReconfiguration() {
        return includeClientReconfiguration;
    }

    /**
     * Setter method for property <tt>includeClientReconfiguration</tt>.
     * 
     * @param includeClientReconfiguration
     *            value to be assigned to property includeClientReconfiguration
     */
    public void setIncludeClientReconfiguration(Boolean includeClientReconfiguration) {
        this.includeClientReconfiguration = includeClientReconfiguration;
    }

    /**
     * Getter method for property <tt>includeSourceDataWipe</tt>.
     * 
     * @return property value of includeSourceDataWipe
     */
    public Boolean getIncludeSourceDataWipe() {
        return includeSourceDataWipe;
    }

    /**
     * Setter method for property <tt>includeSourceDataWipe</tt>.
     * 
     * @param includeSourceDataWipe
     *            value to be assigned to property includeSourceDataWipe
     */
    public void setIncludeSourceDataWipe(Boolean includeSourceDataWipe) {
        this.includeSourceDataWipe = includeSourceDataWipe;
    }

    /**
     * Getter method for property <tt>sourceSysNodesNum</tt>.
     * 
     * @return property value of sourceSysNodesNum
     */
    public Integer getSourceSysNodesNum() {
        return sourceSysNodesNum;
    }

    /**
     * Setter method for property <tt>sourceSysNodesNum</tt>.
     * 
     * @param sourceSysNodesNum
     *            value to be assigned to property sourceSysNodesNum
     */
    public void setSourceSysNodesNum(Integer sourceSysNodesNum) {
        this.sourceSysNodesNum = sourceSysNodesNum;
    }

    /**
     * Getter method for property <tt>targetSysNodesNum</tt>.
     * 
     * @return property value of targetSysNodesNum
     */
    public Integer getTargetSysNodesNum() {
        return targetSysNodesNum;
    }

    /**
     * Setter method for property <tt>targetSysNodesNum</tt>.
     * 
     * @param targetSysNodesNum
     *            value to be assigned to property targetSysNodesNum
     */
    public void setTargetSysNodesNum(Integer targetSysNodesNum) {
        this.targetSysNodesNum = targetSysNodesNum;
    }

    /**
     * Getter method for property <tt>replicationMonitoringEventsNum</tt>.
     * 
     * @return property value of replicationMonitoringEventsNum
     */
    public Integer getReplicationMonitoringEventsNum() {
        return replicationMonitoringEventsNum;
    }

    /**
     * Setter method for property <tt>replicationMonitoringEventsNum</tt>.
     * 
     * @param replicationMonitoringEventsNum
     *            value to be assigned to property replicationMonitoringEventsNum
     */
    public void setReplicationMonitoringEventsNum(Integer replicationMonitoringEventsNum) {
        this.replicationMonitoringEventsNum = replicationMonitoringEventsNum;
    }

    /**
     * Getter method for property <tt>reconfigureClientsNum</tt>.
     * 
     * @return property value of reconfigureClientsNum
     */
    public Integer getReconfigureClientsNum() {
        return reconfigureClientsNum;
    }

    /**
     * Setter method for property <tt>reconfigureClientsNum</tt>.
     * 
     * @param reconfigureClientsNum
     *            value to be assigned to property reconfigureClientsNum
     */
    public void setReconfigureClientsNum(Integer reconfigureClientsNum) {
        this.reconfigureClientsNum = reconfigureClientsNum;
    }

}

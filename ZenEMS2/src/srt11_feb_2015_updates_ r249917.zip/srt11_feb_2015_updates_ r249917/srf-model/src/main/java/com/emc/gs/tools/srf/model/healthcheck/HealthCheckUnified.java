/*
 * This code is copyright (c) 2014 EMC Corporation
 */
package com.emc.gs.tools.srf.model.healthcheck;

import com.emc.gs.tools.srf.model.IdentifiableEntity;

/**
 * <p>
 * This is HealthCheckUnified entity class.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safety.
 * </p>
 * <p>
 * 
 * @author TCSASSEMBLER
 * @version 1.0
 * @since SRT Phase 3-4 - ASD and Healthcheck Tabs Assembly
 */
public class HealthCheckUnified extends IdentifiableEntity {

    /**
     * Type of Healthcheck?
     */
    private UnifiedHealthCheckType healthCheckType;

    /**
     * # of Health Checks Events sold to customer.
     */
    private Integer eventsSoldNum;

    /**
     * # of Celerra or VNX Unified File Based Arrays.
     */
    private Integer fileArraysNum;

    /**
     * # of Clariion or VNX Unified Unified Block Arrays.
     */
    private Integer blockArraysNum;

    /**
     * <p>
     * The default constructor.
     * </p>
     */
    public HealthCheckUnified() {
    }

    /**
     * Getter method for property <tt>healthCheckType</tt>.
     * 
     * @return property value of healthCheckType
     */
    public UnifiedHealthCheckType getHealthCheckType() {
        return healthCheckType;
    }

    /**
     * Setter method for property <tt>healthCheckType</tt>.
     * 
     * @param healthCheckType
     *            value to be assigned to property healthCheckType
     */
    public void setHealthCheckType(UnifiedHealthCheckType healthCheckType) {
        this.healthCheckType = healthCheckType;
    }

    /**
     * Getter method for property <tt>eventsSoldNum</tt>.
     * 
     * @return property value of eventsSoldNum
     */
    public Integer getEventsSoldNum() {
        return eventsSoldNum;
    }

    /**
     * Setter method for property <tt>eventsSoldNum</tt>.
     * 
     * @param eventsSoldNum
     *            value to be assigned to property eventsSoldNum
     */
    public void setEventsSoldNum(Integer eventsSoldNum) {
        this.eventsSoldNum = eventsSoldNum;
    }

    /**
     * Getter method for property <tt>fileArraysNum</tt>.
     * 
     * @return property value of fileArraysNum
     */
    public Integer getFileArraysNum() {
        return fileArraysNum;
    }

    /**
     * Setter method for property <tt>fileArraysNum</tt>.
     * 
     * @param fileArraysNum
     *            value to be assigned to property fileArraysNum
     */
    public void setFileArraysNum(Integer fileArraysNum) {
        this.fileArraysNum = fileArraysNum;
    }

    /**
     * Getter method for property <tt>blockArraysNum</tt>.
     * 
     * @return property value of blockArraysNum
     */
    public Integer getBlockArraysNum() {
        return blockArraysNum;
    }

    /**
     * Setter method for property <tt>blockArraysNum</tt>.
     * 
     * @param blockArraysNum
     *            value to be assigned to property blockArraysNum
     */
    public void setBlockArraysNum(Integer blockArraysNum) {
        this.blockArraysNum = blockArraysNum;
    }

}

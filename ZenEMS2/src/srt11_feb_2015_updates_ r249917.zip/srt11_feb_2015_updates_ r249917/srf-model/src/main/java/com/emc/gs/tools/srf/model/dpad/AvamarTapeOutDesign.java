/*
 * This code is copyright (c) 2014 EMC Corporation
 */
package com.emc.gs.tools.srf.model.dpad;

import com.emc.gs.tools.srf.model.IdentifiableEntity;

/**
 * <p>
 * This is AvamarTapeOutDesign entity class.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safety.
 * </p>
 * 
 * @author TCSASSEMBLER
 * @version 1.0
 * @since SRT Phase 3-5 - BRS Tabs Part 1 Assembly
 */
public class AvamarTapeOutDesign extends IdentifiableEntity {

    /**
     * Include Avamar Domain Reconfiguring and Tuning?
     */
    private Boolean includeDomainReconfiguring;

    /**
     * # of ADT Controllers.
     */
    private Integer adtControllersNum;

    /**
     * # of Avamar Domains Needing Tuning and Reconfiguring for ADT Implementation.
     */
    private Integer adtDomainsNum;

    /**
     * # of ADT Clients.
     */
    private Integer adtClientsNum;

    /**
     * <p>
     * The default constructor.
     * </p>
     */
    public AvamarTapeOutDesign() {
    }

    /**
     * Getter method for property <tt>includeDomainReconfiguring</tt>.
     * 
     * @return property value of includeDomainReconfiguring
     */
    public Boolean getIncludeDomainReconfiguring() {
        return includeDomainReconfiguring;
    }

    /**
     * Setter method for property <tt>includeDomainReconfiguring</tt>.
     * 
     * @param includeDomainReconfiguring
     *            value to be assigned to property includeDomainReconfiguring
     */
    public void setIncludeDomainReconfiguring(Boolean includeDomainReconfiguring) {
        this.includeDomainReconfiguring = includeDomainReconfiguring;
    }

    /**
     * Getter method for property <tt>adtControllersNum</tt>.
     * 
     * @return property value of adtControllersNum
     */
    public Integer getAdtControllersNum() {
        return adtControllersNum;
    }

    /**
     * Setter method for property <tt>adtControllersNum</tt>.
     * 
     * @param adtControllersNum
     *            value to be assigned to property adtControllersNum
     */
    public void setAdtControllersNum(Integer adtControllersNum) {
        this.adtControllersNum = adtControllersNum;
    }

    /**
     * Getter method for property <tt>adtDomainsNum</tt>.
     * 
     * @return property value of adtDomainsNum
     */
    public Integer getAdtDomainsNum() {
        return adtDomainsNum;
    }

    /**
     * Setter method for property <tt>adtDomainsNum</tt>.
     * 
     * @param adtDomainsNum
     *            value to be assigned to property adtDomainsNum
     */
    public void setAdtDomainsNum(Integer adtDomainsNum) {
        this.adtDomainsNum = adtDomainsNum;
    }

    /**
     * Getter method for property <tt>adtClientsNum</tt>.
     * 
     * @return property value of adtClientsNum
     */
    public Integer getAdtClientsNum() {
        return adtClientsNum;
    }

    /**
     * Setter method for property <tt>adtClientsNum</tt>.
     * 
     * @param adtClientsNum
     *            value to be assigned to property adtClientsNum
     */
    public void setAdtClientsNum(Integer adtClientsNum) {
        this.adtClientsNum = adtClientsNum;
    }

}

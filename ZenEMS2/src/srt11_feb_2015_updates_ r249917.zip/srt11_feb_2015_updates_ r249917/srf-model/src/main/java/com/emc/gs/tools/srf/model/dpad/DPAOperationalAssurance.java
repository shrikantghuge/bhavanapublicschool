/*
 * This code is copyright (c) 2014 EMC Corporation
 */
package com.emc.gs.tools.srf.model.dpad;

import com.emc.gs.tools.srf.model.IdentifiableEntity;

/**
 * <p>
 * This is DPAOperationalAssurance entity class.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safety.
 * </p>
 * 
 * @author TCSASSEMBLER
 * @version 1.0
 * @since SRT Phase 3-5 - BRS Tabs Part 2 Assembly
 */
public class DPAOperationalAssurance extends IdentifiableEntity {

    /**
     * Include Requirements Workshop.
     */
    private Boolean includeRequirementsWorkshop;

    /**
     * # of Data Protection Advisor Analysis Site Implementations.
     */
    private Integer analysisSiteImplementationsNum;

    /**
     * <p>
     * The default constructor.
     * </p>
     */
    public DPAOperationalAssurance() {
    }

    /**
     * Getter method for property <tt>includeRequirementsWorkshop</tt>.
     * 
     * @return property value of includeRequirementsWorkshop
     */
    public Boolean getIncludeRequirementsWorkshop() {
        return includeRequirementsWorkshop;
    }

    /**
     * Setter method for property <tt>includeRequirementsWorkshop</tt>.
     * 
     * @param includeRequirementsWorkshop
     *            value to be assigned to property includeRequirementsWorkshop
     */
    public void setIncludeRequirementsWorkshop(Boolean includeRequirementsWorkshop) {
        this.includeRequirementsWorkshop = includeRequirementsWorkshop;
    }

    /**
     * Getter method for property <tt>analysisSiteImplementationsNum</tt>.
     * 
     * @return property value of analysisSiteImplementationsNum
     */
    public Integer getAnalysisSiteImplementationsNum() {
        return analysisSiteImplementationsNum;
    }

    /**
     * Setter method for property <tt>analysisSiteImplementationsNum</tt>.
     * 
     * @param analysisSiteImplementationsNum
     *            value to be assigned to property analysisSiteImplementationsNum
     */
    public void setAnalysisSiteImplementationsNum(Integer analysisSiteImplementationsNum) {
        this.analysisSiteImplementationsNum = analysisSiteImplementationsNum;
    }

}

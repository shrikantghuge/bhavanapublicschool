/*
 * This code is copyright (c) 2014 EMC Corporation.
 */
package com.emc.gs.tools.srf.model.estimate;

import java.math.BigDecimal;

import com.emc.gs.tools.srf.model.LookupEntity;

/**
 * <p>
 * This is DealCurrency entity class.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safety.
 * </p>
 *
 * @author TCSASSEMBLER
 * @version 1.0
 * @since SRT Phase 4 - ET Assembly 1
 */
public class DealCurrency extends LookupEntity {

    /**
     * The exchange rate to USD.
     */
    private BigDecimal exchangeRate;

    /**
     * Empty constructor.
     */
    public DealCurrency() {
    }

    /**
     * Getter method for property <tt>exchangeRate</tt>.
     * @return property value of exchangeRate
     */
    public BigDecimal getExchangeRate() {
        return exchangeRate;
    }

    /**
     * Setter method for property <tt>exchangeRate</tt>.
     * @param exchangeRate value to be assigned to property exchangeRate
     */
    public void setExchangeRate(BigDecimal exchangeRate) {
        this.exchangeRate = exchangeRate;
    }

}

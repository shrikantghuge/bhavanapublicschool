/*
 * This code is copyright (c) 2014 EMC Corporation
 */
package com.emc.gs.tools.srf.model.dpad;

import com.emc.gs.tools.srf.model.IdentifiableEntity;

/**
 * <p>
 * This is DataDomainMigration entity class.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safety.
 * </p>
 * 
 * @author TCSASSEMBLER
 * @version 1.0
 * @since SRT Phase 3-5 - BRS Tabs Part 2 Assembly
 */
public class DataDomainMigration extends IdentifiableEntity {

    /**
     * Select Data Migration Type.
     */
    private DataDomainMigrationType migrationType;

    /**
     * # of Centera to Data Domain Migrations.
     */
    private Integer centera2ddMigrationsNum;

    /**
     * # of DD to DD Migrations.
     */
    private Integer dd2ddMigrationsNum;

    /**
     * # of Data Migration Monitoring Events(1 hr.each).
     */
    private Integer monitoringEventsNum;

    /**
     * <p>
     * The default constructor.
     * </p>
     */
    public DataDomainMigration() {
    }

    /**
     * Getter method for property <tt>migrationType</tt>.
     * 
     * @return property value of migrationType
     */
    public DataDomainMigrationType getMigrationType() {
        return migrationType;
    }

    /**
     * Setter method for property <tt>migrationType</tt>.
     * 
     * @param migrationType
     *            value to be assigned to property migrationType
     */
    public void setMigrationType(DataDomainMigrationType migrationType) {
        this.migrationType = migrationType;
    }

    /**
     * Getter method for property <tt>centera2ddMigrationsNum</tt>.
     * 
     * @return property value of centera2ddMigrationsNum
     */
    public Integer getCentera2ddMigrationsNum() {
        return centera2ddMigrationsNum;
    }

    /**
     * Setter method for property <tt>centera2ddMigrationsNum</tt>.
     * 
     * @param centera2ddMigrationsNum
     *            value to be assigned to property centera2ddMigrationsNum
     */
    public void setCentera2ddMigrationsNum(Integer centera2ddMigrationsNum) {
        this.centera2ddMigrationsNum = centera2ddMigrationsNum;
    }

    /**
     * Getter method for property <tt>dd2ddMigrationsNum</tt>.
     * 
     * @return property value of dd2ddMigrationsNum
     */
    public Integer getDd2ddMigrationsNum() {
        return dd2ddMigrationsNum;
    }

    /**
     * Setter method for property <tt>dd2ddMigrationsNum</tt>.
     * 
     * @param dd2ddMigrationsNum
     *            value to be assigned to property dd2ddMigrationsNum
     */
    public void setDd2ddMigrationsNum(Integer dd2ddMigrationsNum) {
        this.dd2ddMigrationsNum = dd2ddMigrationsNum;
    }

    /**
     * Getter method for property <tt>monitoringEventsNum</tt>.
     * 
     * @return property value of monitoringEventsNum
     */
    public Integer getMonitoringEventsNum() {
        return monitoringEventsNum;
    }

    /**
     * Setter method for property <tt>monitoringEventsNum</tt>.
     * 
     * @param monitoringEventsNum
     *            value to be assigned to property monitoringEventsNum
     */
    public void setMonitoringEventsNum(Integer monitoringEventsNum) {
        this.monitoringEventsNum = monitoringEventsNum;
    }

}

/*
 * This code is copyright (c) 2014 EMC Corporation.
 */
package com.emc.gs.tools.srf.model.engagement;

/**
 * <p>
 * This is SRTPath enumeration.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: Enum is thread safety.
 * </p>
 * 
 * @author TCSASSEMBLER
 * @version 1.0
 * @since SRT Phase 4 - ET Assembly 1
 */
public enum SRTPath {

    /**
     * Represents the path is unknown.
     */
    UNKNOWN,

    /**
     * Represents SRT 3 path.
     */
    SRT3,

    /**
     * Represents SRT 4 path.
     */
    SRT4,

    /**
     * Represents SRT hybrid path.
     */
    SRT_HYBRID;
}

/*
 * This code is copyright (c) 2014 EMC Corporation
 */
package com.emc.gs.tools.srf.model.dpad;

import com.emc.gs.tools.srf.model.IdentifiableEntity;

/**
 * <p>
 * This is DataDomainBoostBase entity class.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safety.
 * </p>
 * 
 * @author TCSASSEMBLER
 * @version 1.0
 * @since SRT Phase 3-5 - BRS Tabs Part 2 Assembly
 */
public abstract class DataDomainBoostBase extends IdentifiableEntity {

    /**
     * Include RMAN Scripting for Backup and Recovery.
     */
    private Boolean includeRMANScripting;

    /**
     * Backup Window Time is Less than.
     */
    private DataDomainMaxBackupWindowTime maxBackupWindowTime;

    /**
     * # of Data Domain Appliances for DD Boost Implementation.
     */
    private Integer appliancesForDDBoostNum;

    /**
     * # of Servers for DD Boost Device Installation and Configuration.
     */
    private Integer serversForDDBoostNum;

    /**
     * # of Oracle Database Servers for RMAN Backup.
     */
    private Integer oracleRMANBackupServersNum;

    /**
     * # of Oracle Databases for Backup Configuration.
     */
    private Integer oracleBackupConfigServersNum;

    /**
     * <p>
     * The default constructor.
     * </p>
     */
    protected DataDomainBoostBase() {
    }

    /**
     * Getter method for property <tt>includeRMANScripting</tt>.
     * 
     * @return property value of includeRMANScripting
     */
    public Boolean getIncludeRMANScripting() {
        return includeRMANScripting;
    }

    /**
     * Setter method for property <tt>includeRMANScripting</tt>.
     * 
     * @param includeRMANScripting
     *            value to be assigned to property includeRMANScripting
     */
    public void setIncludeRMANScripting(Boolean includeRMANScripting) {
        this.includeRMANScripting = includeRMANScripting;
    }

    /**
     * Getter method for property <tt>maxBackupWindowTime</tt>.
     * 
     * @return property value of maxBackupWindowTime
     */
    public DataDomainMaxBackupWindowTime getMaxBackupWindowTime() {
        return maxBackupWindowTime;
    }

    /**
     * Setter method for property <tt>maxBackupWindowTime</tt>.
     * 
     * @param maxBackupWindowTime
     *            value to be assigned to property maxBackupWindowTime
     */
    public void setMaxBackupWindowTime(DataDomainMaxBackupWindowTime maxBackupWindowTime) {
        this.maxBackupWindowTime = maxBackupWindowTime;
    }

    /**
     * Getter method for property <tt>appliancesForDDBoostNum</tt>.
     * 
     * @return property value of appliancesForDDBoostNum
     */
    public Integer getAppliancesForDDBoostNum() {
        return appliancesForDDBoostNum;
    }

    /**
     * Setter method for property <tt>appliancesForDDBoostNum</tt>.
     * 
     * @param appliancesForDDBoostNum
     *            value to be assigned to property appliancesForDDBoostNum
     */
    public void setAppliancesForDDBoostNum(Integer appliancesForDDBoostNum) {
        this.appliancesForDDBoostNum = appliancesForDDBoostNum;
    }

    /**
     * Getter method for property <tt>serversForDDBoostNum</tt>.
     * 
     * @return property value of serversForDDBoostNum
     */
    public Integer getServersForDDBoostNum() {
        return serversForDDBoostNum;
    }

    /**
     * Setter method for property <tt>serversForDDBoostNum</tt>.
     * 
     * @param serversForDDBoostNum
     *            value to be assigned to property serversForDDBoostNum
     */
    public void setServersForDDBoostNum(Integer serversForDDBoostNum) {
        this.serversForDDBoostNum = serversForDDBoostNum;
    }

    /**
     * Getter method for property <tt>oracleRMANBackupServersNum</tt>.
     * 
     * @return property value of oracleRMANBackupServersNum
     */
    public Integer getOracleRMANBackupServersNum() {
        return oracleRMANBackupServersNum;
    }

    /**
     * Setter method for property <tt>oracleRMANBackupServersNum</tt>.
     * 
     * @param oracleRMANBackupServersNum
     *            value to be assigned to property oracleRMANBackupServersNum
     */
    public void setOracleRMANBackupServersNum(Integer oracleRMANBackupServersNum) {
        this.oracleRMANBackupServersNum = oracleRMANBackupServersNum;
    }

    /**
     * Getter method for property <tt>oracleBackupConfigServersNum</tt>.
     * 
     * @return property value of oracleBackupConfigServersNum
     */
    public Integer getOracleBackupConfigServersNum() {
        return oracleBackupConfigServersNum;
    }

    /**
     * Setter method for property <tt>oracleBackupConfigServersNum</tt>.
     * 
     * @param oracleBackupConfigServersNum
     *            value to be assigned to property oracleBackupConfigServersNum
     */
    public void setOracleBackupConfigServersNum(Integer oracleBackupConfigServersNum) {
        this.oracleBackupConfigServersNum = oracleBackupConfigServersNum;
    }
}

/*
 * This code is copyright (c) 2014 EMC Corporation.
 */
package com.emc.gs.tools.srf.model.estimate;

import java.math.BigDecimal;
import java.util.Date;
import java.util.Map;

import com.emc.gs.tools.srf.model.IdentifiableEntity;

/**
 * <p>
 * This is LOBResource entity class.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safety.
 * </p>
 * 
 * @author TCSASSEMBLER
 * @version 1.0
 * @since SRT Phase 4 - ET Assembly 1
 */
public class LOBResource extends IdentifiableEntity {

    /**
     * The selected BOE role.
     */
    private BOERole role;

    /**
     * The selected competency.
     */
    private Competency competency;

    /**
     * The month hours.
     */
    private Map<Integer, Integer> monthHours;

    /**
     * The start date.
     */
    private Date startDate;

    /**
     * The number of weeks.
     */
    private Integer weeks;

    /**
     * The end date.
     */
    private Date endDate;

    /**
     * The bill rate override.
     */
    private BigDecimal billRateOverride;

    /**
     * The contingency percent.
     */
    private BigDecimal contingencyPercent;

    /**
     * The project staff data.
     */
    private ProjectStaff projectStaff;

    /**
     * Empty constructor.
     */
    public LOBResource() {
    }

    /**
     * Getter method for property <tt>role</tt>.
     * 
     * @return property value of role
     */
    public BOERole getRole() {
        return role;
    }

    /**
     * Setter method for property <tt>role</tt>.
     * 
     * @param role
     *            value to be assigned to property role
     */
    public void setRole(BOERole role) {
        this.role = role;
    }

    /**
     * Getter method for property <tt>competency</tt>.
     * 
     * @return property value of competency
     */
    public Competency getCompetency() {
        return competency;
    }

    /**
     * Setter method for property <tt>competency</tt>.
     * 
     * @param competency
     *            value to be assigned to property competency
     */
    public void setCompetency(Competency competency) {
        this.competency = competency;
    }

    /**
     * Getter method for property <tt>monthHours</tt>.
     * 
     * @return property value of monthHours
     */
    public Map<Integer, Integer> getMonthHours() {
        return monthHours;
    }

    /**
     * Setter method for property <tt>monthHours</tt>.
     * 
     * @param monthHours
     *            value to be assigned to property monthHours
     */
    public void setMonthHours(Map<Integer, Integer> monthHours) {
        this.monthHours = monthHours;
    }

    /**
     * Getter method for property <tt>startDate</tt>.
     * 
     * @return property value of startDate
     */
    public Date getStartDate() {
        return startDate;
    }

    /**
     * Setter method for property <tt>startDate</tt>.
     * 
     * @param startDate
     *            value to be assigned to property startDate
     */
    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }

    /**
     * Getter method for property <tt>weeks</tt>.
     * 
     * @return property value of weeks
     */
    public Integer getWeeks() {
        return weeks;
    }

    /**
     * Setter method for property <tt>weeks</tt>.
     * 
     * @param weeks
     *            value to be assigned to property weeks
     */
    public void setWeeks(Integer weeks) {
        this.weeks = weeks;
    }

    /**
     * Getter method for property <tt>endDate</tt>.
     * 
     * @return property value of endDate
     */
    public Date getEndDate() {
        return endDate;
    }

    /**
     * Setter method for property <tt>endDate</tt>.
     * 
     * @param endDate
     *            value to be assigned to property endDate
     */
    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }

    /**
     * Getter method for property <tt>contingencyPercent</tt>.
     * 
     * @return property value of contingencyPercent
     */
    public BigDecimal getContingencyPercent() {
        return contingencyPercent;
    }

    /**
     * Setter method for property <tt>contingencyPercent</tt>.
     * 
     * @param contingencyPercent
     *            value to be assigned to property contingencyPercent
     */
    public void setContingencyPercent(BigDecimal contingencyPercent) {
        this.contingencyPercent = contingencyPercent;
    }

    /**
     * Getter method for property <tt>billRateOverride</tt>.
     * 
     * @return property value of billRateOverride
     */
    public BigDecimal getBillRateOverride() {
        return billRateOverride;
    }

    /**
     * Setter method for property <tt>billRateOverride</tt>.
     * 
     * @param billRateOverride
     *            value to be assigned to property billRateOverride
     */
    public void setBillRateOverride(BigDecimal billRateOverride) {
        this.billRateOverride = billRateOverride;
    }

    /**
     * Getter method for property <tt>projectStaff</tt>.
     * 
     * @return property value of projectStaff
     */
    public ProjectStaff getProjectStaff() {
        return projectStaff;
    }

    /**
     * Setter method for property <tt>projectStaff</tt>.
     * 
     * @param projectStaff
     *            value to be assigned to property projectStaff
     */
    public void setProjectStaff(ProjectStaff projectStaff) {
        this.projectStaff = projectStaff;
    }

}

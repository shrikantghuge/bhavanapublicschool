/*
 * This code is copyright (c) 2013 - 2014 EMC Corporation.
 */
package com.emc.gs.tools.srf.model.bc;

import java.util.List;
import java.util.Map;

import com.emc.gs.tools.srf.model.IdentifiableEntity;

/**
 * <p>
 * This is MirrorViewInformation entity class.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread
 * safety.
 * </p>
 * 
 * <p>
 * <strong>Changes V1.1:</strong> <strong>SRT Release Assembly - BC Tab</strong>
 * <ul>
 * <li>Change hostNumbers to type of Map<String, Integer></li>
 * <li>Change sourceArrayInformation and targetArrayInformation to type of List</li>
 * <li>Remove srdfStaticDynamicType field</li>
 * </ul>
 * </p>
 * 
 * <p>
 * <strong>Changes V1.2:</strong>
 * <strong>SRT Bug Fixes - F121, F153, F154, F162</strong>
 * <ul>
 * <li>Add knowledgeTransferHours field.</li>
 * </ul>
 * </p>
 * 
 * <p>
 * <strong>Changes V1.3:</strong>
 * <ul>
 * <li>Removed networkConnectionType, networkDistance, rpoDescription, rtoDescription, 
 * totalTargetServers, bcPractiveScriptingLevel, monitoringScripts, emcMapPointsOption fields.</li>
 * </ul>
 * </p>
 * 
 * <p>
 * <strong>Changes V1.4:</strong>
 * <strong>https://apps.topcoder.com/bugs/browse/SRT-35</strong>
 * <ul>
 * <li>Added mirrorViewCEFunctionalityRequired, mirrorViewCe, nrOfConsistencyGroups fields.</li>
 * </ul>
 * </p>
 *
 * <p>
 * Version 1.5 (SRT 4 OCT2014 Updates Part 1 Assembly Assembly 1.0) Change notes:
 *   <ol>
 *     <li>Removed <code>customScriptingRequired</code> property.</li>
 *     <li>Added {@link #numberOfRemoteMirrors} property.</li>
 *     <li>Added {@link #numberOfSecondaryImagesCreated} property.</li>
 *   </ol>
 * </p>
 * 
 * @author faeton, stevenfrog, MonicaMuranyi, isv
 * @version 1.5
 */
public class MirrorViewInformation extends IdentifiableEntity {

    /**
     * <p>
     * The knowledgeTransferHours.
     * </p>
     */
    private String knowledgeTransferHours;

    /**
     * <p>
     * The mirrorViewSFunctionalityRequired.
     * </p>
     */
    private boolean mirrorViewSFunctionalityRequired;

    /**
     * <p>
     * The mirrorViewAFunctionalityRequired.
     * </p>
     */
    private boolean mirrorViewAFunctionalityRequired;
    
    /**
     * <p>
     * The mirrorViewCEFunctionalityRequired.
     * </p>
     */
    private boolean mirrorViewCEFunctionalityRequired;

    /**
     * <p>
     * The networkLinkStatus.
     * </p>
     */
    private NetworkLinkStatus networkLinkStatus;

    /**
     * <p>
     * The hostNumbers.
     * </p>
     */
    private Map<String, Integer> hostNumbers;

    /**
     * <p>
     * The sourceArrayInformation.
     * </p>
     */
    private List<MirrorViewSourceArrayInformation> sourceArrayInformation;

    /**
     * <p>
     * The targetArrayInformation.
     * </p>
     */
    private List<MirrorViewTargetArrayInformation> targetArrayInformation;

    /**
     * <p>
     * The mirrowViewScriptingLevel.
     * </p>
     */
    private ScriptingLevel mirrowViewScriptingLevel;

    /**
     * <p>
     * The customScriptingDetails.
     * </p>
     */
    private String customScriptingDetails;
    
    /**
     * <p>
     * The nrOfConsistencyGroups.
     * </p>
     */
    private Integer nrOfConsistencyGroups;

    /**
     * <p>A <code>Integer</code> providing the value for ""# of MirrorView Remote Mirrors" property.</p>
     * @since 1.1
     */
    private Integer numberOfRemoteMirrors;

    /**
     * <p>A <code>Integer</code> providing the value for "# of MirrorView Secondary Images Created?"" property.</p>
     * 
     * @since 1.1
     */
    private Integer numberOfSecondaryImagesCreated;

    /**
     * <p>
     * The default constructor.
     * </p>
     */
    public MirrorViewInformation() {
        // Empty
    }

    /**
     * <p>
     * Retrieves the knowledgeTransferHours field.
     * </p>
     * 
     * @return the knowledgeTransferHours
     */
    public String getKnowledgeTransferHours() {
        return knowledgeTransferHours;
    }

    /**
     * <p>
     * Sets the value to knowledgeTransferHours field.
     * </p>
     * 
     * @param knowledgeTransferHours
     *            the knowledgeTransferHours to set
     */
    public void setKnowledgeTransferHours(String knowledgeTransferHours) {
        this.knowledgeTransferHours = knowledgeTransferHours;
    }

    /**
     * <p>
     * Retrieves the mirrorViewSFunctionalityRequired field.
     * </p>
     * 
     * @return the mirrorViewSFunctionalityRequired
     */
    public boolean isMirrorViewSFunctionalityRequired() {
        return mirrorViewSFunctionalityRequired;
    }

    /**
     * <p>
     * Sets the value to mirrorViewSFunctionalityRequired field.
     * </p>
     * 
     * @param mirrorViewSFunctionalityRequired
     *            the mirrorViewSFunctionalityRequired to set
     */
    public void setMirrorViewSFunctionalityRequired(boolean mirrorViewSFunctionalityRequired) {
        this.mirrorViewSFunctionalityRequired = mirrorViewSFunctionalityRequired;
    }

    /**
     * <p>
     * Retrieves the mirrorViewAFunctionalityRequired field.
     * </p>
     * 
     * @return the mirrorViewAFunctionalityRequired
     */
    public boolean isMirrorViewAFunctionalityRequired() {
        return mirrorViewAFunctionalityRequired;
    }

    /**
     * <p>
     * Sets the value to mirrorViewAFunctionalityRequired field.
     * </p>
     * 
     * @param mirrorViewAFunctionalityRequired
     *            the mirrorViewAFunctionalityRequired to set
     */
    public void setMirrorViewAFunctionalityRequired(boolean mirrorViewAFunctionalityRequired) {
        this.mirrorViewAFunctionalityRequired = mirrorViewAFunctionalityRequired;
    }

    /**
     * <p>
     * Retrieves the mirrorViewCEFunctionalityRequired field.
     * </p>
     * 
     * @return the mirrorViewCEFunctionalityRequired
     */
    public boolean isMirrorViewCEFunctionalityRequired() {
        return mirrorViewCEFunctionalityRequired;
    }

    /**
     * <p>
     * Sets the value to mirrorViewCEFunctionalityRequired field.
     * </p>
     * 
     * @param mirrorViewCEFunctionalityRequired
     *            the mirrorViewCEFunctionalityRequired to set
     */
    public void setMirrorViewCEFunctionalityRequired(boolean mirrorViewCEFunctionalityRequired) {
        this.mirrorViewCEFunctionalityRequired = mirrorViewCEFunctionalityRequired;
    }

    /**
     * <p>
     * Retrieves the networkLinkStatus field.
     * </p>
     * 
     * @return the networkLinkStatus
     */
    public NetworkLinkStatus getNetworkLinkStatus() {
        return networkLinkStatus;
    }

    /**
     * <p>
     * Sets the value to networkLinkStatus field.
     * </p>
     * 
     * @param networkLinkStatus
     *            the networkLinkStatus to set
     */
    public void setNetworkLinkStatus(NetworkLinkStatus networkLinkStatus) {
        this.networkLinkStatus = networkLinkStatus;
    }

    /**
     * <p>
     * Retrieves the hostNumbers field.
     * </p>
     * 
     * @return the hostNumbers
     */
    public Map<String, Integer> getHostNumbers() {
        return hostNumbers;
    }

    /**
     * <p>
     * Sets the value to hostNumbers field.
     * </p>
     * 
     * @param hostNumbers
     *            the hostNumbers to set
     */
    public void setHostNumbers(Map<String, Integer> hostNumbers) {
        this.hostNumbers = hostNumbers;
    }

    /**
     * <p>
     * Retrieves the sourceArrayInformation field.
     * </p>
     * 
     * @return the sourceArrayInformation
     */
    public List<MirrorViewSourceArrayInformation> getSourceArrayInformation() {
        return sourceArrayInformation;
    }

    /**
     * <p>
     * Sets the value to sourceArrayInformation field.
     * </p>
     * 
     * @param sourceArrayInformation
     *            the sourceArrayInformation to set
     */
    public void setSourceArrayInformation(List<MirrorViewSourceArrayInformation> sourceArrayInformation) {
        this.sourceArrayInformation = sourceArrayInformation;
    }

    /**
     * <p>
     * Retrieves the targetArrayInformation field.
     * </p>
     * 
     * @return the targetArrayInformation
     */
    public List<MirrorViewTargetArrayInformation> getTargetArrayInformation() {
        return targetArrayInformation;
    }

    /**
     * <p>
     * Sets the value to targetArrayInformation field.
     * </p>
     * 
     * @param targetArrayInformation
     *            the targetArrayInformation to set
     */
    public void setTargetArrayInformation(List<MirrorViewTargetArrayInformation> targetArrayInformation) {
        this.targetArrayInformation = targetArrayInformation;
    }

    /**
     * <p>
     * Retrieves the mirrowViewScriptingLevel field.
     * </p>
     * 
     * @return the mirrowViewScriptingLevel
     */
    public ScriptingLevel getMirrowViewScriptingLevel() {
        return mirrowViewScriptingLevel;
    }

    /**
     * <p>
     * Sets the value to mirrowViewScriptingLevel field.
     * </p>
     * 
     * @param mirrowViewScriptingLevel
     *            the mirrowViewScriptingLevel to set
     */
    public void setMirrowViewScriptingLevel(ScriptingLevel mirrowViewScriptingLevel) {
        this.mirrowViewScriptingLevel = mirrowViewScriptingLevel;
    }

    /**
     * <p>
     * Retrieves the customScriptingDetails field.
     * </p>
     * 
     * @return the customScriptingDetails
     */
    public String getCustomScriptingDetails() {
        return customScriptingDetails;
    }

    /**
     * <p>
     * Sets the value to customScriptingDetails field.
     * </p>
     * 
     * @param customScriptingDetails
     *            the customScriptingDetails to set
     */
    public void setCustomScriptingDetails(String customScriptingDetails) {
        this.customScriptingDetails = customScriptingDetails;
    }
    
    /**
     * <p>
     * Retrieves the nrOfConsistencyGroups field.
     * </p>
     * 
     * @return the nrOfConsistencyGroups
     */
    public Integer getNrOfConsistencyGroups() {
        return nrOfConsistencyGroups;
    }

    /**
     * <p>
     * Sets the value to nrOfConsistencyGroups field.
     * </p>
     * 
     * @param nrOfConsistencyGroups
     *            the nrOfConsistencyGroups to set
     */
    public void setNrOfConsistencyGroups(Integer nrOfConsistencyGroups) {
        this.nrOfConsistencyGroups = nrOfConsistencyGroups;
    }

    /**
     * <p>Gets the "# of MirrorView Secondary Images Created?"" property.</p>
     *
     * @return a <code>Integer</code> providing the value for "# of MirrorView Secondary Images Created?"" property.
     * @since 1.1
     */
    public Integer getNumberOfSecondaryImagesCreated() {
        return this.numberOfSecondaryImagesCreated;
    }

    /**
     * <p>Sets the "# of MirrorView Secondary Images Created?"" property.</p>
     *
     * @param numberOfSecondaryImagesCreated a <code>Integer</code> providing the value for "# of MirrorView Secondary
     * Images Created?"" property.
     * @since 1.1
     */
    public void setNumberOfSecondaryImagesCreated(Integer numberOfSecondaryImagesCreated) {
        this.numberOfSecondaryImagesCreated = numberOfSecondaryImagesCreated;
    }

    /**
     * <p>Gets the ""# of MirrorView Remote Mirrors" property.</p>
     *
     * @return a <code>Integer</code> providing the value for ""# of MirrorView Remote Mirrors" property.
     * @since 1.1
     */
    public Integer getNumberOfRemoteMirrors() {
        return this.numberOfRemoteMirrors;
    }

    /**
     * <p>Sets the ""# of MirrorView Remote Mirrors" property.</p>
     *
     * @param numberOfRemoteMirrors a <code>Integer</code> providing the value for ""# of MirrorView Remote Mirrors"
     * property.
     * @since 1.1
     */
    public void setNumberOfRemoteMirrors(Integer numberOfRemoteMirrors) {
        this.numberOfRemoteMirrors = numberOfRemoteMirrors;
    }

    /**
     * The toString method.
     * 
     * @return the string for this entity
     */
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("{").append(super.toString());
        sb.append(", knowledgeTransferHours:").append(knowledgeTransferHours);
        sb.append(", mirrorViewSFunctionalityRequired:").append(mirrorViewSFunctionalityRequired);
        sb.append(", mirrorViewAFunctionalityRequired:").append(mirrorViewAFunctionalityRequired);
        sb.append(", networkLinkStatus:").append(networkLinkStatus);
        sb.append(", hostNumbers:").append(hostNumbers);
        sb.append(", sourceArrayInformation:").append(sourceArrayInformation);
        sb.append(", targetArrayInformation:").append(targetArrayInformation);
        sb.append(", mirrowViewScriptingLevel:").append(mirrowViewScriptingLevel);
        sb.append(", nrOfConsistencyGroups:").append(nrOfConsistencyGroups);
        sb.append(", numberOfRemoteMirrors:").append(numberOfRemoteMirrors);
        sb.append(", numberOfSecondaryImagesCreated:").append(numberOfSecondaryImagesCreated);
        sb.append(", customScriptingDetails:").append(customScriptingDetails).append("}");
        return sb.toString();
    }
}

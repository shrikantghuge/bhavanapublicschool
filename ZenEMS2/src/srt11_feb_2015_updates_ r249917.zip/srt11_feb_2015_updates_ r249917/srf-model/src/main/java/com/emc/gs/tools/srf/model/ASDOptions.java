/*
 * This code is copyright (c) 2014 EMC Corporation.
 */
package com.emc.gs.tools.srf.model;

/**
 * <p>
 * This is ASDOptions entity class.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safety.
 * </p>
 * <p>
 * <strong>Changes V1.1:</strong>
 * <strong>SRT Phase 3-4 - ASD and Healthcheck Tabs Assembly</strong>
 * <ul>
 * <li>Remove dpa/smarts/powerPath/replicationManager fields.</li>
 * <li>Add ncm field.</li>
 * </ul>
 * </p>
 * 
 * @author liuliquan
 * @version 1.1
 */
public class ASDOptions extends IdentifiableEntity {

    /**
     * <p>
     * The srm.
     * </p>
     */
    private boolean srm;

    /**
     * <p>
     * The appSync.
     * </p>
     */
    private boolean appSync;

    /**
     * <p>
     * The atmos.
     * </p>
     */
    private boolean atmos;

    /**
     * <p>
     * The w4n.
     * </p>
     */
    private boolean w4n;

    /**
     * <p>
     * The centera.
     * </p>
     */
    private boolean centera;

    /**
     * <p>
     * The vipr.
     * </p>
     */
    private boolean vipr;

    /**
     * <p>
     * The uim.
     * </p>
     */
    private boolean uim;

    /**
     * <p>
     * The ncm.
     * </p>
     * @since SRT Phase 3-4 - ASD and Healthcheck Tabs Assembly
     */
    private boolean ncm;

    /**
     * <p>
     * The default constructor.
     * </p>
     */
    public ASDOptions() {
        // Empty
    }

    /**
     * Getter method for property <tt>srm</tt>.
     * 
     * @return property value of srm
     */
    public boolean isSrm() {
        return srm;
    }

    /**
     * Setter method for property <tt>srm</tt>.
     * 
     * @param srm
     *            value to be assigned to property srm
     */
    public void setSrm(boolean srm) {
        this.srm = srm;
    }

    /**
     * Getter method for property <tt>appSync</tt>.
     * 
     * @return property value of appSync
     */
    public boolean isAppSync() {
        return appSync;
    }

    /**
     * Setter method for property <tt>appSync</tt>.
     * 
     * @param appSync
     *            value to be assigned to property appSync
     */
    public void setAppSync(boolean appSync) {
        this.appSync = appSync;
    }

    /**
     * Getter method for property <tt>atmos</tt>.
     * 
     * @return property value of atmos
     */
    public boolean isAtmos() {
        return atmos;
    }

    /**
     * Setter method for property <tt>atmos</tt>.
     * 
     * @param atmos
     *            value to be assigned to property atmos
     */
    public void setAtmos(boolean atmos) {
        this.atmos = atmos;
    }

    /**
     * Getter method for property <tt>w4n</tt>.
     * 
     * @return property value of w4n
     */
    public boolean isW4n() {
        return w4n;
    }

    /**
     * Setter method for property <tt>w4n</tt>.
     * 
     * @param w4n
     *            value to be assigned to property w4n
     */
    public void setW4n(boolean w4n) {
        this.w4n = w4n;
    }

    /**
     * Getter method for property <tt>centera</tt>.
     * 
     * @return property value of centera
     */
    public boolean isCentera() {
        return centera;
    }

    /**
     * Setter method for property <tt>centera</tt>.
     * 
     * @param centera
     *            value to be assigned to property centera
     */
    public void setCentera(boolean centera) {
        this.centera = centera;
    }

    /**
     * Getter method for property <tt>vipr</tt>.
     * 
     * @return property value of vipr
     */
    public boolean isVipr() {
        return vipr;
    }

    /**
     * Setter method for property <tt>vipr</tt>.
     * 
     * @param vipr
     *            value to be assigned to property vipr
     */
    public void setVipr(boolean vipr) {
        this.vipr = vipr;
    }

    /**
     * Getter method for property <tt>uim</tt>.
     * 
     * @return property value of uim
     */
    public boolean isUim() {
        return uim;
    }

    /**
     * Setter method for property <tt>uim</tt>.
     * 
     * @param uim
     *            value to be assigned to property uim
     */
    public void setUim(boolean uim) {
        this.uim = uim;
    }

    /**
     * Getter method for property <tt>ncm</tt>.
     * 
     * @return property value of ncm
     * @since SRT Phase 3-4 - ASD and Healthcheck Tabs Assembly
     */
    public boolean isNcm() {
        return ncm;
    }

    /**
     * Setter method for property <tt>ncm</tt>.
     * 
     * @param ncm
     *            value to be assigned to property ncm
     * @since SRT Phase 3-4 - ASD and Healthcheck Tabs Assembly
     */
    public void setNcm(boolean ncm) {
        this.ncm = ncm;
    }

    /**
     * The toString method.
     * 
     * @return the string for this entity
     */
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("{").append(super.toString());
        sb.append(", srm:").append(srm);
        sb.append(", appSync:").append(appSync);
        sb.append(", atmos:").append(atmos);
        sb.append(", centera:").append(centera);
        sb.append(", vipr:").append(vipr);
        sb.append(", uim:").append(uim);
        sb.append(", ncm:").append(ncm).append("}");
        return sb.toString();
    }
}

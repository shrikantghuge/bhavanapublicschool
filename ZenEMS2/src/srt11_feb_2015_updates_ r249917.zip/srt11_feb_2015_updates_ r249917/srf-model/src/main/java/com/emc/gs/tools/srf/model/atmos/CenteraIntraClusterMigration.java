/*
 * This code is copyright (c) 2014 EMC Corporation
 */
package com.emc.gs.tools.srf.model.atmos;

import com.emc.gs.tools.srf.model.IdentifiableEntity;

/**
 * <p>
 * This is CenteraIntraClusterMigration entity class.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safety.
 * </p>
 * 
 * @author TCSASSEMBLER
 * @version 1.0
 * @since SRT Phase 3-1 - Atmos Centera and Vblock Tabs Assembly
 */
public class CenteraIntraClusterMigration extends IdentifiableEntity {

    /**
     * # of Centera source cubes.
     */
    private Integer sourceCubesNum;

    /**
     * # of Centera target cubes.
     */
    private Integer targetCubesNum;

    /**
     * # of new nodes to be added to this Centera for CICM?
     */
    private Integer newNodesNum;

    /**
     * # of nodes to be removed from this Centera by CICM?
     */
    private Integer removedNodesNum;

    /**
     * Are any of the existing nodes GEN3?
     */
    private Boolean existingNodesGEN3;

    /**
     * <p>
     * The default constructor.
     * </p>
     */
    public CenteraIntraClusterMigration() {
    }

    /**
     * Getter method for property <tt>sourceCubesNum</tt>.
     * 
     * @return property value of sourceCubesNum
     */
    public Integer getSourceCubesNum() {
        return sourceCubesNum;
    }

    /**
     * Setter method for property <tt>sourceCubesNum</tt>.
     * 
     * @param sourceCubesNum
     *            value to be assigned to property sourceCubesNum
     */
    public void setSourceCubesNum(Integer sourceCubesNum) {
        this.sourceCubesNum = sourceCubesNum;
    }

    /**
     * Getter method for property <tt>targetCubesNum</tt>.
     * 
     * @return property value of targetCubesNum
     */
    public Integer getTargetCubesNum() {
        return targetCubesNum;
    }

    /**
     * Setter method for property <tt>targetCubesNum</tt>.
     * 
     * @param targetCubesNum
     *            value to be assigned to property targetCubesNum
     */
    public void setTargetCubesNum(Integer targetCubesNum) {
        this.targetCubesNum = targetCubesNum;
    }

    /**
     * Getter method for property <tt>newNodesNum</tt>.
     * 
     * @return property value of newNodesNum
     */
    public Integer getNewNodesNum() {
        return newNodesNum;
    }

    /**
     * Setter method for property <tt>newNodesNum</tt>.
     * 
     * @param newNodesNum
     *            value to be assigned to property newNodesNum
     */
    public void setNewNodesNum(Integer newNodesNum) {
        this.newNodesNum = newNodesNum;
    }

    /**
     * Getter method for property <tt>removedNodesNum</tt>.
     * 
     * @return property value of removedNodesNum
     */
    public Integer getRemovedNodesNum() {
        return removedNodesNum;
    }

    /**
     * Setter method for property <tt>removedNodesNum</tt>.
     * 
     * @param removedNodesNum
     *            value to be assigned to property removedNodesNum
     */
    public void setRemovedNodesNum(Integer removedNodesNum) {
        this.removedNodesNum = removedNodesNum;
    }

    /**
     * Getter method for property <tt>existingNodesGEN3</tt>.
     * 
     * @return property value of existingNodesGEN3
     */
    public Boolean getExistingNodesGEN3() {
        return existingNodesGEN3;
    }

    /**
     * Setter method for property <tt>existingNodesGEN3</tt>.
     * 
     * @param existingNodesGEN3
     *            value to be assigned to property existingNodesGEN3
     */
    public void setExistingNodesGEN3(Boolean existingNodesGEN3) {
        this.existingNodesGEN3 = existingNodesGEN3;
    }

}

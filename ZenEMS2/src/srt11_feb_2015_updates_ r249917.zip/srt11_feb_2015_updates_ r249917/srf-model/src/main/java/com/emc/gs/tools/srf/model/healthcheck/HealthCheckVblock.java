/*
 * This code is copyright (c) 2014 EMC Corporation
 */
package com.emc.gs.tools.srf.model.healthcheck;

import com.emc.gs.tools.srf.model.IdentifiableEntity;

/**
 * <p>
 * This is HealthCheckVBlock entity class.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safety.
 * </p>
 * <p>
 * 
 * @author TCSASSEMBLER
 * @version 1.0
 * @since SRT Phase 3-4 - ASD and Healthcheck Tabs Assembly
 */
public class HealthCheckVblock extends IdentifiableEntity {

    /**
     * Include Interoperability Check?
     */
    private Boolean includeInteroperabilityCheck;

    /**
     * Include Performance Check?
     */
    private Boolean includePerformanceCheck;

    /**
     * Include Capacity Analysis?
     */
    private Boolean includeCapacityAnalysis;

    /**
     * Include VNX Block Flare Software Update?
     */
    private Boolean includeFlareSoftwareUpdate;

    /**
     * # of existing VNX Block arrays for Health Check.
     */
    private Integer blockArraysNum;

    /**
     * # of existing SAN switches for Health Check.
     */
    private Integer sanSwitchesNum;

    /**
     * # of existing SAN hosts for health check.
     */
    private Integer sanHostsNum;

    /**
     * <p>
     * The default constructor.
     * </p>
     */
    public HealthCheckVblock() {
    }

    /**
     * Getter method for property <tt>includeInteroperabilityCheck</tt>.
     * 
     * @return property value of includeInteroperabilityCheck
     */
    public Boolean getIncludeInteroperabilityCheck() {
        return includeInteroperabilityCheck;
    }

    /**
     * Setter method for property <tt>includeInteroperabilityCheck</tt>.
     * 
     * @param includeInteroperabilityCheck
     *            value to be assigned to property includeInteroperabilityCheck
     */
    public void setIncludeInteroperabilityCheck(Boolean includeInteroperabilityCheck) {
        this.includeInteroperabilityCheck = includeInteroperabilityCheck;
    }

    /**
     * Getter method for property <tt>includePerformanceCheck</tt>.
     * 
     * @return property value of includePerformanceCheck
     */
    public Boolean getIncludePerformanceCheck() {
        return includePerformanceCheck;
    }

    /**
     * Setter method for property <tt>includePerformanceCheck</tt>.
     * 
     * @param includePerformanceCheck
     *            value to be assigned to property includePerformanceCheck
     */
    public void setIncludePerformanceCheck(Boolean includePerformanceCheck) {
        this.includePerformanceCheck = includePerformanceCheck;
    }

    /**
     * Getter method for property <tt>includeCapacityAnalysis</tt>.
     * 
     * @return property value of includeCapacityAnalysis
     */
    public Boolean getIncludeCapacityAnalysis() {
        return includeCapacityAnalysis;
    }

    /**
     * Setter method for property <tt>includeCapacityAnalysis</tt>.
     * 
     * @param includeCapacityAnalysis
     *            value to be assigned to property includeCapacityAnalysis
     */
    public void setIncludeCapacityAnalysis(Boolean includeCapacityAnalysis) {
        this.includeCapacityAnalysis = includeCapacityAnalysis;
    }

    /**
     * Getter method for property <tt>includeFlareSoftwareUpdate</tt>.
     * 
     * @return property value of includeFlareSoftwareUpdate
     */
    public Boolean getIncludeFlareSoftwareUpdate() {
        return includeFlareSoftwareUpdate;
    }

    /**
     * Setter method for property <tt>includeFlareSoftwareUpdate</tt>.
     * 
     * @param includeFlareSoftwareUpdate
     *            value to be assigned to property includeFlareSoftwareUpdate
     */
    public void setIncludeFlareSoftwareUpdate(Boolean includeFlareSoftwareUpdate) {
        this.includeFlareSoftwareUpdate = includeFlareSoftwareUpdate;
    }

    /**
     * Getter method for property <tt>blockArraysNum</tt>.
     * 
     * @return property value of blockArraysNum
     */
    public Integer getBlockArraysNum() {
        return blockArraysNum;
    }

    /**
     * Setter method for property <tt>blockArraysNum</tt>.
     * 
     * @param blockArraysNum
     *            value to be assigned to property blockArraysNum
     */
    public void setBlockArraysNum(Integer blockArraysNum) {
        this.blockArraysNum = blockArraysNum;
    }

    /**
     * Getter method for property <tt>sanSwitchesNum</tt>.
     * 
     * @return property value of sanSwitchesNum
     */
    public Integer getSanSwitchesNum() {
        return sanSwitchesNum;
    }

    /**
     * Setter method for property <tt>sanSwitchesNum</tt>.
     * 
     * @param sanSwitchesNum
     *            value to be assigned to property sanSwitchesNum
     */
    public void setSanSwitchesNum(Integer sanSwitchesNum) {
        this.sanSwitchesNum = sanSwitchesNum;
    }

    /**
     * Getter method for property <tt>sanHostsNum</tt>.
     * 
     * @return property value of sanHostsNum
     */
    public Integer getSanHostsNum() {
        return sanHostsNum;
    }

    /**
     * Setter method for property <tt>sanHostsNum</tt>.
     * 
     * @param sanHostsNum
     *            value to be assigned to property sanHostsNum
     */
    public void setSanHostsNum(Integer sanHostsNum) {
        this.sanHostsNum = sanHostsNum;
    }

}

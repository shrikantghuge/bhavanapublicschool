/*
 * This code is copyright (c) 2014 EMC Corporation
 */
package com.emc.gs.tools.srf.model.dpad;

/**
 * <p>
 * This is NetworkerAdvancedBackupTechDesign entity class.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safety.
 * </p>
 * 
 * @author TCSASSEMBLER
 * @version 1.0
 * @since SRT Phase 3-5 - BRS Tabs Part 3 Assembly
 */
public class NetworkerAdvancedBackupTechDesign extends NetworkerAdvancedBackupTechBase {

    /**
     * # of VMWare vSphere Hosts.
     */
    private Integer vmwareVsphereHostsNum;

    /**
     * <p>
     * The default constructor.
     * </p>
     */
    public NetworkerAdvancedBackupTechDesign() {
    }

    /**
     * Getter method for property <tt>vmwareVsphereHostsNum</tt>.
     * 
     * @return property value of vmwareVsphereHostsNum
     */
    public Integer getVmwareVsphereHostsNum() {
        return vmwareVsphereHostsNum;
    }

    /**
     * Setter method for property <tt>vmwareVsphereHostsNum</tt>.
     * 
     * @param vmwareVsphereHostsNum
     *            value to be assigned to property vmwareVsphereHostsNum
     */
    public void setVmwareVsphereHostsNum(Integer vmwareVsphereHostsNum) {
        this.vmwareVsphereHostsNum = vmwareVsphereHostsNum;
    }

}

/*
 * This code is copyright (c) 2014 EMC Corporation
 */
package com.emc.gs.tools.srf.model.healthcheck;

import com.emc.gs.tools.srf.model.IdentifiableEntity;

/**
 * <p>
 * This is HealthCheckSymmetrixVmaxStorageReplication entity class.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safety.
 * </p>
 * <p>
 * 
 * @author TCSASSEMBLER
 * @version 1.0
 * @since SRT Phase 3-4 - ASD and Healthcheck Tabs Assembly
 */
public class HealthCheckSymmetrixVmaxStorageReplication extends IdentifiableEntity {

    /**
     * Include Final Report?
     */
    private Boolean includeFinalReport;

    /**
     * Include Executive Summary Review Presentation?
     */
    private Boolean includeExecutiveSummaryReviewPresentation;

    /**
     * # of Assessment interviews?
     */
    private Integer assessmentInterviewsNum;

    /**
     * # of Consistency Groups for Symmetrix Health Check?
     */
    private Integer consistencyGroupsNum;

    /**
     * # of Symmetrix arrays for Symmetrix Health Check?
     */
    private Integer symmetrixArraysNum;

    /**
     * # of Open Systems Hosts for Symmetrix Health Check?
     */
    private Integer openSystemsHostsNum;

    /**
     * # of Symmetrix Logical Devices for Symmetrix Health Check?
     */
    private Integer logicalDevicesNum;

    /**
     * <p>
     * The default constructor.
     * </p>
     */
    public HealthCheckSymmetrixVmaxStorageReplication() {
    }

    /**
     * Getter method for property <tt>includeFinalReport</tt>.
     * 
     * @return property value of includeFinalReport
     */
    public Boolean getIncludeFinalReport() {
        return includeFinalReport;
    }

    /**
     * Setter method for property <tt>includeFinalReport</tt>.
     * 
     * @param includeFinalReport
     *            value to be assigned to property includeFinalReport
     */
    public void setIncludeFinalReport(Boolean includeFinalReport) {
        this.includeFinalReport = includeFinalReport;
    }

    /**
     * Getter method for property <tt>includeExecutiveSummaryReviewPresentation</tt>.
     * 
     * @return property value of includeExecutiveSummaryReviewPresentation
     */
    public Boolean getIncludeExecutiveSummaryReviewPresentation() {
        return includeExecutiveSummaryReviewPresentation;
    }

    /**
     * Setter method for property <tt>includeExecutiveSummaryReviewPresentation</tt>.
     * 
     * @param includeExecutiveSummaryReviewPresentation
     *            value to be assigned to property includeExecutiveSummaryReviewPresentation
     */
    public void setIncludeExecutiveSummaryReviewPresentation(Boolean includeExecutiveSummaryReviewPresentation) {
        this.includeExecutiveSummaryReviewPresentation = includeExecutiveSummaryReviewPresentation;
    }

    /**
     * Getter method for property <tt>assessmentInterviewsNum</tt>.
     * 
     * @return property value of assessmentInterviewsNum
     */
    public Integer getAssessmentInterviewsNum() {
        return assessmentInterviewsNum;
    }

    /**
     * Setter method for property <tt>assessmentInterviewsNum</tt>.
     * 
     * @param assessmentInterviewsNum
     *            value to be assigned to property assessmentInterviewsNum
     */
    public void setAssessmentInterviewsNum(Integer assessmentInterviewsNum) {
        this.assessmentInterviewsNum = assessmentInterviewsNum;
    }

    /**
     * Getter method for property <tt>consistencyGroupsNum</tt>.
     * 
     * @return property value of consistencyGroupsNum
     */
    public Integer getConsistencyGroupsNum() {
        return consistencyGroupsNum;
    }

    /**
     * Setter method for property <tt>consistencyGroupsNum</tt>.
     * 
     * @param consistencyGroupsNum
     *            value to be assigned to property consistencyGroupsNum
     */
    public void setConsistencyGroupsNum(Integer consistencyGroupsNum) {
        this.consistencyGroupsNum = consistencyGroupsNum;
    }

    /**
     * Getter method for property <tt>symmetrixArraysNum</tt>.
     * 
     * @return property value of symmetrixArraysNum
     */
    public Integer getSymmetrixArraysNum() {
        return symmetrixArraysNum;
    }

    /**
     * Setter method for property <tt>symmetrixArraysNum</tt>.
     * 
     * @param symmetrixArraysNum
     *            value to be assigned to property symmetrixArraysNum
     */
    public void setSymmetrixArraysNum(Integer symmetrixArraysNum) {
        this.symmetrixArraysNum = symmetrixArraysNum;
    }

    /**
     * Getter method for property <tt>openSystemsHostsNum</tt>.
     * 
     * @return property value of openSystemsHostsNum
     */
    public Integer getOpenSystemsHostsNum() {
        return openSystemsHostsNum;
    }

    /**
     * Setter method for property <tt>openSystemsHostsNum</tt>.
     * 
     * @param openSystemsHostsNum
     *            value to be assigned to property openSystemsHostsNum
     */
    public void setOpenSystemsHostsNum(Integer openSystemsHostsNum) {
        this.openSystemsHostsNum = openSystemsHostsNum;
    }

    /**
     * Getter method for property <tt>logicalDevicesNum</tt>.
     * 
     * @return property value of logicalDevicesNum
     */
    public Integer getLogicalDevicesNum() {
        return logicalDevicesNum;
    }

    /**
     * Setter method for property <tt>logicalDevicesNum</tt>.
     * 
     * @param logicalDevicesNum
     *            value to be assigned to property logicalDevicesNum
     */
    public void setLogicalDevicesNum(Integer logicalDevicesNum) {
        this.logicalDevicesNum = logicalDevicesNum;
    }

}

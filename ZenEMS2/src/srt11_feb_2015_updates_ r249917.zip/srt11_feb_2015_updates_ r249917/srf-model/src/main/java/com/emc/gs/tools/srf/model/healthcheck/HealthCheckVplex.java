/*
 * This code is copyright (c) 2014 EMC Corporation
 */
package com.emc.gs.tools.srf.model.healthcheck;

import com.emc.gs.tools.srf.model.IdentifiableEntity;

/**
 * <p>
 * This is HealthCheckVplex entity class.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safety.
 * </p>
 * <p>
 * 
 * @author TCSASSEMBLER
 * @version 1.0
 * @since SRT Phase 3-4 - ASD and Healthcheck Tabs Assembly
 */
public class HealthCheckVplex extends IdentifiableEntity {

    /**
     * # of VPLEX Clusters reviewed in each Health Check event?
     */
    private Integer clustersReviewedNum;

    /**
     * # of Health Checks Events sold to customer.
     */
    private Integer eventsSoldNum;

    /**
     * <p>
     * The default constructor.
     * </p>
     */
    public HealthCheckVplex() {
    }

    /**
     * Getter method for property <tt>clustersReviewedNum</tt>.
     * 
     * @return property value of clustersReviewedNum
     */
    public Integer getClustersReviewedNum() {
        return clustersReviewedNum;
    }

    /**
     * Setter method for property <tt>clustersReviewedNum</tt>.
     * 
     * @param clustersReviewedNum
     *            value to be assigned to property clustersReviewedNum
     */
    public void setClustersReviewedNum(Integer clustersReviewedNum) {
        this.clustersReviewedNum = clustersReviewedNum;
    }

    /**
     * Getter method for property <tt>eventsSoldNum</tt>.
     * 
     * @return property value of eventsSoldNum
     */
    public Integer getEventsSoldNum() {
        return eventsSoldNum;
    }

    /**
     * Setter method for property <tt>eventsSoldNum</tt>.
     * 
     * @param eventsSoldNum
     *            value to be assigned to property eventsSoldNum
     */
    public void setEventsSoldNum(Integer eventsSoldNum) {
        this.eventsSoldNum = eventsSoldNum;
    }

}

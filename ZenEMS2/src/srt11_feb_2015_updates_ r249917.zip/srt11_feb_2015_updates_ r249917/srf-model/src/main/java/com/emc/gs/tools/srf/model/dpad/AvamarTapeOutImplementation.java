/*
 * This code is copyright (c) 2014 EMC Corporation
 */
package com.emc.gs.tools.srf.model.dpad;

import com.emc.gs.tools.srf.model.IdentifiableEntity;

/**
 * <p>
 * This is AvamarTapeOutImplementation entity class.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safety.
 * </p>
 * 
 * @author TCSASSEMBLER
 * @version 1.0
 * @since SRT Phase 3-5 - BRS Tabs Part 1 Assembly
 */
public class AvamarTapeOutImplementation extends IdentifiableEntity {

    /**
     * Select for ADT Implementation?
     */
    private AvamarADType adtType;

    /**
     * # of Avamar Grids.
     */
    private Integer gridsNum;

    /**
     * # of Archive Servers.
     */
    private Integer archiveServersNum;

    /**
     * # of Existing ESX/ESXi Servers.
     */
    private Integer esxServersNum;

    /**
     * # of Avamar Replication Connections.
     */
    private Integer replicationConnectionsNum;

    /**
     * # of ADT Transport Nodes Needed to Support ADT Processing Requirements.
     */
    private Integer adtTransportNodesNum;

    /**
     * # of ADT Controllers.
     */
    private Integer adtControllersNum;

    /**
     * <p>
     * The default constructor.
     * </p>
     */
    public AvamarTapeOutImplementation() {
    }

    /**
     * Getter method for property <tt>adtType</tt>.
     * 
     * @return property value of adtType
     */
    public AvamarADType getAdtType() {
        return adtType;
    }

    /**
     * Setter method for property <tt>adtType</tt>.
     * 
     * @param adtType
     *            value to be assigned to property adtType
     */
    public void setAdtType(AvamarADType adtType) {
        this.adtType = adtType;
    }

    /**
     * Getter method for property <tt>gridsNum</tt>.
     * 
     * @return property value of gridsNum
     */
    public Integer getGridsNum() {
        return gridsNum;
    }

    /**
     * Setter method for property <tt>gridsNum</tt>.
     * 
     * @param gridsNum
     *            value to be assigned to property gridsNum
     */
    public void setGridsNum(Integer gridsNum) {
        this.gridsNum = gridsNum;
    }

    /**
     * Getter method for property <tt>archiveServersNum</tt>.
     * 
     * @return property value of archiveServersNum
     */
    public Integer getArchiveServersNum() {
        return archiveServersNum;
    }

    /**
     * Setter method for property <tt>archiveServersNum</tt>.
     * 
     * @param archiveServersNum
     *            value to be assigned to property archiveServersNum
     */
    public void setArchiveServersNum(Integer archiveServersNum) {
        this.archiveServersNum = archiveServersNum;
    }

    /**
     * Getter method for property <tt>esxServersNum</tt>.
     * 
     * @return property value of esxServersNum
     */
    public Integer getEsxServersNum() {
        return esxServersNum;
    }

    /**
     * Setter method for property <tt>esxServersNum</tt>.
     * 
     * @param esxServersNum
     *            value to be assigned to property esxServersNum
     */
    public void setEsxServersNum(Integer esxServersNum) {
        this.esxServersNum = esxServersNum;
    }

    /**
     * Getter method for property <tt>replicationConnectionsNum</tt>.
     * 
     * @return property value of replicationConnectionsNum
     */
    public Integer getReplicationConnectionsNum() {
        return replicationConnectionsNum;
    }

    /**
     * Setter method for property <tt>replicationConnectionsNum</tt>.
     * 
     * @param replicationConnectionsNum
     *            value to be assigned to property replicationConnectionsNum
     */
    public void setReplicationConnectionsNum(Integer replicationConnectionsNum) {
        this.replicationConnectionsNum = replicationConnectionsNum;
    }

    /**
     * Getter method for property <tt>adtTransportNodesNum</tt>.
     * 
     * @return property value of adtTransportNodesNum
     */
    public Integer getAdtTransportNodesNum() {
        return adtTransportNodesNum;
    }

    /**
     * Setter method for property <tt>adtTransportNodesNum</tt>.
     * 
     * @param adtTransportNodesNum
     *            value to be assigned to property adtTransportNodesNum
     */
    public void setAdtTransportNodesNum(Integer adtTransportNodesNum) {
        this.adtTransportNodesNum = adtTransportNodesNum;
    }

    /**
     * Getter method for property <tt>adtControllersNum</tt>.
     * 
     * @return property value of adtControllersNum
     */
    public Integer getAdtControllersNum() {
        return adtControllersNum;
    }

    /**
     * Setter method for property <tt>adtControllersNum</tt>.
     * 
     * @param adtControllersNum
     *            value to be assigned to property adtControllersNum
     */
    public void setAdtControllersNum(Integer adtControllersNum) {
        this.adtControllersNum = adtControllersNum;
    }

}

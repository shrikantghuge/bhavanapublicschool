/*
 * This code is copyright (c) 2014 EMC Corporation
 */
package com.emc.gs.tools.srf.model.dpad;

import com.emc.gs.tools.srf.model.IdentifiableEntity;

/**
 * <p>
 * This is AvamarHealthCheck entity class.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safety.
 * </p>
 * 
 * @author TCSASSEMBLER
 * @version 1.0
 * @since SRT Phase 3-5 - BRS Tabs Part 1 Assembly
 */
public class AvamarHealthCheck extends IdentifiableEntity {

    /**
     * # of Avamar Grids.
     */
    private Integer gridsNum;

    /**
     * # of assessment interviews.
     */
    private Integer assessmentInterviewsNum;

    /**
     * <p>
     * The default constructor.
     * </p>
     */
    public AvamarHealthCheck() {
    }

    /**
     * Getter method for property <tt>gridsNum</tt>.
     * 
     * @return property value of gridsNum
     */
    public Integer getGridsNum() {
        return gridsNum;
    }

    /**
     * Setter method for property <tt>gridsNum</tt>.
     * 
     * @param gridsNum
     *            value to be assigned to property gridsNum
     */
    public void setGridsNum(Integer gridsNum) {
        this.gridsNum = gridsNum;
    }

    /**
     * Getter method for property <tt>assessmentInterviewsNum</tt>.
     * 
     * @return property value of assessmentInterviewsNum
     */
    public Integer getAssessmentInterviewsNum() {
        return assessmentInterviewsNum;
    }

    /**
     * Setter method for property <tt>assessmentInterviewsNum</tt>.
     * 
     * @param assessmentInterviewsNum
     *            value to be assigned to property assessmentInterviewsNum
     */
    public void setAssessmentInterviewsNum(Integer assessmentInterviewsNum) {
        this.assessmentInterviewsNum = assessmentInterviewsNum;
    }

}

/*
 * This code is copyright (c) 2014 EMC Corporation.
 */
package com.emc.gs.tools.srf.model;

/**
 * <p>
 * This is CoreOptions entity class.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safety.
 * </p>
 * <p>
 * <strong>Changes V1.1:</strong>
 * <strong>SRT Phase 3-2 - Move Request and Change Request Tabs Assembly</strong>
 * <ul>
 * <li>Added changeRequest flag.</li>
 * </ul>
 * </p>
 * @author liuliquan, TCSASSEMBLER
 * @version 1.1
 */
public class CoreOptions extends IdentifiableEntity {

    /**
     * <p>
     * The symmOs.
     * </p>
     */
    private boolean symmOs;

    /**
     * <p>
     * The symmMf.
     * </p>
     */
    private boolean symmMf;

    /**
     * <p>
     * The vblock.
     * </p>
     */
    private boolean vblock;

    /**
     * <p>
     * The unified.
     * </p>
     */
    private boolean unified;

    /**
     * <p>
     * The san.
     * </p>
     */
    private boolean san;

    /**
     * <p>
     * The isilon.
     * </p>
     */
    private boolean isilon;

    /**
     * <p>
     * The vplex.
     * </p>
     */
    private boolean vplex;

    /**
     * <p>
     * The cta.
     * </p>
     */
    private boolean cta;

    /**
     * <p>
     * The replication.
     * </p>
     */
    private boolean replication;

    /**
     * <p>
     * The xtremeIO.
     * </p>
     */
    private boolean xtremeIO;

    /**
     * <p>
     * The mainframe.
     * </p>
     */
    private boolean mainframe;
    
    /**
     * <p>
     * The changeRequest.
     * </p>
     * @since 1.1
     */
    private boolean changeRequest;

    /**
     * <p>
     * The default constructor.
     * </p>
     */
    public CoreOptions() {
        // Empty
    }

    /**
     * <p>
     * Retrieves the symmOs field.
     * </p>
     * @return the symmOs
     */
    public boolean isSymmOs() {
        return symmOs;
    }

    /**
     * <p>
     * Sets the value to symmOs field.
     * </p>
     * @param symmOs
     *            the symmOs to set
     */
    public void setSymmOs(boolean symmOs) {
        this.symmOs = symmOs;
    }

    /**
     * <p>
     * Retrieves the symmMf field.
     * </p>
     * @return the symmMf
     */
    public boolean isSymmMf() {
        return symmMf;
    }

    /**
     * <p>
     * Sets the value to symmMf field.
     * </p>
     * @param symmMf
     *            the symmMf to set
     */
    public void setSymmMf(boolean symmMf) {
        this.symmMf = symmMf;
    }

    /**
     * <p>
     * Retrieves the vblock field.
     * </p>
     * @return the vblock
     */
    public boolean isVblock() {
        return vblock;
    }

    /**
     * <p>
     * Sets the value to vblock field.
     * </p>
     * @param vblock
     *            the vblock to set
     */
    public void setVblock(boolean vblock) {
        this.vblock = vblock;
    }

    /**
     * <p>
     * Retrieves the san field.
     * </p>
     * @return the san
     */
    public boolean isSan() {
        return san;
    }

    /**
     * <p>
     * Sets the value to san field.
     * </p>
     * @param san
     *            the san to set
     */
    public void setSan(boolean san) {
        this.san = san;
    }

    /**
     * <p>
     * Retrieves the isilon field.
     * </p>
     * @return the isilon
     */
    public boolean isIsilon() {
        return isilon;
    }

    /**
     * <p>
     * Sets the value to isilon field.
     * </p>
     * @param isilon
     *            the isilon to set
     */
    public void setIsilon(boolean isilon) {
        this.isilon = isilon;
    }

    /**
     * <p>
     * Retrieves the vplex field.
     * </p>
     * @return the vplex
     */
    public boolean isVplex() {
        return vplex;
    }

    /**
     * <p>
     * Sets the value to vplex field.
     * </p>
     * @param vplex
     *            the vplex to set
     */
    public void setVplex(boolean vplex) {
        this.vplex = vplex;
    }

    /**
     * <p>
     * Retrieves the cta field.
     * </p>
     * @return the cta
     */
    public boolean isCta() {
        return cta;
    }

    /**
     * <p>
     * Sets the value to cta field.
     * </p>
     * @param cta
     *            the cta to set
     */
    public void setCta(boolean cta) {
        this.cta = cta;
    }

    /**
     * Getter method for property <tt>unified</tt>.
     * @return property value of unified
     */
    public boolean isUnified() {
        return unified;
    }

    /**
     * Setter method for property <tt>unified</tt>.
     * @param unified
     *            value to be assigned to property unified
     */
    public void setUnified(boolean unified) {
        this.unified = unified;
    }

    /**
     * Getter method for property <tt>replication</tt>.
     * @return property value of replication
     */
    public boolean isReplication() {
        return replication;
    }

    /**
     * Setter method for property <tt>replication</tt>.
     * @param replication
     *            value to be assigned to property replication
     */
    public void setReplication(boolean replication) {
        this.replication = replication;
    }

    /**
     * Getter method for property <tt>xtremeIO</tt>.
     * @return property value of xtremeIO
     */
    public boolean isXtremeIO() {
        return xtremeIO;
    }

    /**
     * Setter method for property <tt>xtremeIO</tt>.
     * @param xtremeIO
     *            value to be assigned to property xtremeIO
     */
    public void setXtremeIO(boolean xtremeIO) {
        this.xtremeIO = xtremeIO;
    }

    /**
     * Getter method for property <tt>mainframe</tt>.
     * @return property value of mainframe
     */
    public boolean isMainframe() {
        return mainframe;
    }

    /**
     * Setter method for property <tt>mainframe</tt>.
     * @param mainframe
     *            value to be assigned to property mainframe
     */
    public void setMainframe(boolean mainframe) {
        this.mainframe = mainframe;
    }

    /**
     * The toString method.
     * @return the string for this entity
     */
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("{").append(super.toString());
        sb.append(", symmOs:").append(symmOs);
        sb.append(", symmMf:").append(symmMf);
        sb.append(", vblock:").append(vblock);
        sb.append(", unified:").append(unified);
        sb.append(", san:").append(san);
        sb.append(", isilon:").append(isilon);
        sb.append(", vplex:").append(vplex);
        sb.append(", cta:").append(cta);
        sb.append(", replication:").append(replication);
        sb.append(", mainframe:").append(mainframe);
        sb.append(", changeRequest:").append(changeRequest);
        sb.append(", xtremeIO:").append(xtremeIO).append("}");
        return sb.toString();
    }

    /**
     * Gets the value of the field <code>changeRequest</code>.
     * @return the changeRequest
     * @since 1.1
     */
    public boolean isChangeRequest() {
        return changeRequest;
    }

    /**
     * Sets the value of the field <code>changeRequest</code>.
     * @param changeRequest the changeRequest to set
     * @since 1.1
     */
    public void setChangeRequest(boolean changeRequest) {
        this.changeRequest = changeRequest;
    }
}

/*
 * This code is copyright (c) 2014 EMC Corporation
 */
package com.emc.gs.tools.srf.model.dpad;

/**
 * <p>
 * This is NetworkerApplicationBackupsDesign entity class.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safety.
 * </p>
 *
 * <p>
 * Version 1.1 (SRT 4 OCT2014 Updates Part 1 Assembly) Change notes:
 *   <ol>
 *     <li>Added {@link #meditechBackupType} property.</li>
 *     <li>Added {@link #numberOfMeditechHosts} property.</li>
 *     <li>Added {@link #numberOfMeditechStorageArrays} property.</li>
 *   </ol>
 * </p>
 * 
 * @author isv
 * @version 1.1
 * @since SRT Phase 3-5 - BRS Tabs Part 3 Assembly
 */
public class NetworkerApplicationBackupsDesign extends NetworkerApplicationBackupsBase {

    /**
     * # of SQL Databases.
     */
    private Integer msSqlDatabasesNum;

    /**
     * Data Domain Boost?
     */
    private Boolean exchangeDataDomainBoost;

    /**
     * # of SQL Databases.
     */
    private Integer sharePointSqlDatabasesNum;

    /**
     * Data Domain Boost?
     */
    private Boolean sharePointDataDomainBoost;

    /**
     * Include Extensive RMAN Scripting?
     */
    private Boolean includeExtensiveRMANScripting;

    /**
     * <p>A <code>MeditechBackupType</code> providing the value for meditechBackupType property.</p>
     * 
     * @since 1.1
     */
    private MeditechBackupType meditechBackupType;

    /**
     * <p>A <code>Integer</code> providing the value for "# of Meditech Hosts?" property.</p>
     * 
     * @since 1.1
     */
    private Integer numberOfMeditechHosts;

    /**
     * <p>A <code>Integer</code> providing the value for "# of Storage Arrays in the Meditech Environment?"
     * property.</p>
     * 
     * @since 1.1
     */
    private Integer numberOfMeditechStorageArrays;

    /**
     * <p>
     * The default constructor.
     * </p>
     */
    public NetworkerApplicationBackupsDesign() {
    }

    /**
     * Getter method for property <tt>msSqlDatabasesNum</tt>.
     * 
     * @return property value of msSqlDatabasesNum
     */
    public Integer getMsSqlDatabasesNum() {
        return msSqlDatabasesNum;
    }

    /**
     * Setter method for property <tt>msSqlDatabasesNum</tt>.
     * 
     * @param msSqlDatabasesNum
     *            value to be assigned to property msSqlDatabasesNum
     */
    public void setMsSqlDatabasesNum(Integer msSqlDatabasesNum) {
        this.msSqlDatabasesNum = msSqlDatabasesNum;
    }

    /**
     * Getter method for property <tt>exchangeDataDomainBoost</tt>.
     * 
     * @return property value of exchangeDataDomainBoost
     */
    public Boolean getExchangeDataDomainBoost() {
        return exchangeDataDomainBoost;
    }

    /**
     * Setter method for property <tt>exchangeDataDomainBoost</tt>.
     * 
     * @param exchangeDataDomainBoost
     *            value to be assigned to property exchangeDataDomainBoost
     */
    public void setExchangeDataDomainBoost(Boolean exchangeDataDomainBoost) {
        this.exchangeDataDomainBoost = exchangeDataDomainBoost;
    }

    /**
     * Getter method for property <tt>sharePointSqlDatabasesNum</tt>.
     * 
     * @return property value of sharePointSqlDatabasesNum
     */
    public Integer getSharePointSqlDatabasesNum() {
        return sharePointSqlDatabasesNum;
    }

    /**
     * Setter method for property <tt>sharePointSqlDatabasesNum</tt>.
     * 
     * @param sharePointSqlDatabasesNum
     *            value to be assigned to property sharePointSqlDatabasesNum
     */
    public void setSharePointSqlDatabasesNum(Integer sharePointSqlDatabasesNum) {
        this.sharePointSqlDatabasesNum = sharePointSqlDatabasesNum;
    }

    /**
     * Getter method for property <tt>sharePointDataDomainBoost</tt>.
     * 
     * @return property value of sharePointDataDomainBoost
     */
    public Boolean getSharePointDataDomainBoost() {
        return sharePointDataDomainBoost;
    }

    /**
     * Setter method for property <tt>sharePointDataDomainBoost</tt>.
     * 
     * @param sharePointDataDomainBoost
     *            value to be assigned to property sharePointDataDomainBoost
     */
    public void setSharePointDataDomainBoost(Boolean sharePointDataDomainBoost) {
        this.sharePointDataDomainBoost = sharePointDataDomainBoost;
    }

    /**
     * Getter method for property <tt>includeExtensiveRMANScripting</tt>.
     * 
     * @return property value of includeExtensiveRMANScripting
     */
    public Boolean getIncludeExtensiveRMANScripting() {
        return includeExtensiveRMANScripting;
    }

    /**
     * Setter method for property <tt>includeExtensiveRMANScripting</tt>.
     * 
     * @param includeExtensiveRMANScripting
     *            value to be assigned to property includeExtensiveRMANScripting
     */
    public void setIncludeExtensiveRMANScripting(Boolean includeExtensiveRMANScripting) {
        this.includeExtensiveRMANScripting = includeExtensiveRMANScripting;
    }

    /**
     * <p>Gets the "# of Storage Arrays in the Meditech Environment?" property.</p>
     *
     * @return a <code>Integer</code> providing the value for "# of Storage Arrays in the Meditech Environment?"
     * property.
     * @since 1.1
     */
    public Integer getNumberOfMeditechStorageArrays() {
        return this.numberOfMeditechStorageArrays;
    }

    /**
     * <p>Sets the "# of Storage Arrays in the Meditech Environment?" property.</p>
     *
     * @param numberOfMeditechStorageArrays a <code>Integer</code> providing the value for "# of Storage Arrays in the
     * Meditech Environment?" property.
     * @since 1.1
     */
    public void setNumberOfMeditechStorageArrays(Integer numberOfMeditechStorageArrays) {
        this.numberOfMeditechStorageArrays = numberOfMeditechStorageArrays;
    }

    /**
     * <p>Gets the "# of Meditech Hosts?" property.</p>
     *
     * @return a <code>Integer</code> providing the value for "# of Meditech Hosts?" property.
     * @since 1.1
     */
    public Integer getNumberOfMeditechHosts() {
        return this.numberOfMeditechHosts;
    }

    /**
     * <p>Sets the "# of Meditech Hosts?" property.</p>
     *
     * @param numberOfMeditechHosts a <code>Integer</code> providing the value for "# of Meditech Hosts?" property.
     * @since 1.1
     */
    public void setNumberOfMeditechHosts(Integer numberOfMeditechHosts) {
        this.numberOfMeditechHosts = numberOfMeditechHosts;
    }

    /**
     * <p>Gets the meditechBackupType property.</p>
     *
     * @return a <code>MeditechBackupType</code> providing the value for meditechBackupType property.
     * @since 1.1
     */
    public MeditechBackupType getMeditechBackupType() {
        return this.meditechBackupType;
    }

    /**
     * <p>Sets the meditechBackupType property.</p>
     *
     * @param meditechBackupType a <code>MeditechBackupType</code> providing the value for meditechBackupType property.
     * @since 1.1
     */
    public void setMeditechBackupType(MeditechBackupType meditechBackupType) {
        this.meditechBackupType = meditechBackupType;
    }
}

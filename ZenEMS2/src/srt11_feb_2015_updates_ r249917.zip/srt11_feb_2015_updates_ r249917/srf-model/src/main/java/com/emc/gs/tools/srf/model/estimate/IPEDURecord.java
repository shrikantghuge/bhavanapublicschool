/*
 * This code is copyright (c) 2015 EMC Corporation.
 */
package com.emc.gs.tools.srf.model.estimate;

import com.emc.gs.tools.srf.model.IdentifiableEntity;

import java.math.BigDecimal;

/**
 * <p>This is IPEDURecord entity class.</p>
 *
 * <p><strong>Thread safety</strong>: This class is mutable, it is not thread safety.</p>
 *
 * <p>
 * Version 1.1 Change notes:
 *   <ol>
 *     <li>Removed <code>hostsNumber</code> property.</li>
 *   </ol>
 * </p>
 *
 * @author isv
 * @version 1.1
 */
public class IPEDURecord extends IdentifiableEntity {

    /**
     * <p>A <code>IPEDUOption</code> providing the value for type property.</p>
     */
    private IPEDUOption type;

    /**
     * <p>A <code>MaterialCode</code> providing the value for materialCode property.</p>
     */
    private MaterialCode materialCode;

    /**
     * <p>A <code>Competency</code> providing the value for competency property.</p>
     */
    private Competency competency;

    /**
     * <p>A <code>BigDecimal</code> providing the value for amount property.</p>
     */
    private BigDecimal amount;

    /**
     * <p>Constructs new <code>IPEDURecord</code> instance. This implementation does nothing.</p>
     */
    public IPEDURecord() {
    }

    /**
     * <p>Gets the amount property.</p>
     *
     * @return a <code>BigDecimal</code> providing the value for amount property.
     */
    public BigDecimal getAmount() {
        return this.amount;
    }

    /**
     * <p>Sets the amount property.</p>
     *
     * @param amount a <code>BigDecimal</code> providing the value for amount property.
     */
    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    /**
     * <p>Gets the competency property.</p>
     *
     * @return a <code>Competency</code> providing the value for competency property.
     */
    public Competency getCompetency() {
        return this.competency;
    }

    /**
     * <p>Sets the competency property.</p>
     *
     * @param competency a <code>Competency</code> providing the value for competency property.
     */
    public void setCompetency(Competency competency) {
        this.competency = competency;
    }

    /**
     * <p>Gets the materialCode property.</p>
     *
     * @return a <code>MaterialCode</code> providing the value for materialCode property.
     */
    public MaterialCode getMaterialCode() {
        return this.materialCode;
    }

    /**
     * <p>Sets the materialCode property.</p>
     *
     * @param materialCode a <code>MaterialCode</code> providing the value for materialCode property.
     */
    public void setMaterialCode(MaterialCode materialCode) {
        this.materialCode = materialCode;
    }

    /**
     * <p>Gets the type property.</p>
     *
     * @return a <code>IPEDUOption</code> providing the value for type property.
     */
    public IPEDUOption getType() {
        return this.type;
    }

    /**
     * <p>Sets the type property.</p>
     *
     * @param type a <code>IPEDUOption</code> providing the value for type property.
     */
    public void setType(IPEDUOption type) {
        this.type = type;
    }

}

/*
 * This code is copyright (c) 2014 EMC Corporation
 */
package com.emc.gs.tools.srf.model.healthcheck;

import com.emc.gs.tools.srf.model.IdentifiableEntity;

/**
 * <p>
 * This is HealthCheckSymmetrixVmax entity class.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safety.
 * </p>
 * <p>
 * 
 * @author TCSASSEMBLER
 * @version 1.0
 * @since SRT Phase 3-4 - ASD and Healthcheck Tabs Assembly
 */
public class HealthCheckSymmetrixVmax extends IdentifiableEntity {

    /**
     * # of Health Checks Events sold to customer?
     */
    private Integer eventsSoldNum;

    /**
     * # of Symmetrix DMX and/or VMAX arrays?
     */
    private Integer dmxVmaxArraysNum;

    /**
     * <p>
     * The default constructor.
     * </p>
     */
    public HealthCheckSymmetrixVmax() {
    }

    /**
     * Getter method for property <tt>eventsSoldNum</tt>.
     * 
     * @return property value of eventsSoldNum
     */
    public Integer getEventsSoldNum() {
        return eventsSoldNum;
    }

    /**
     * Setter method for property <tt>eventsSoldNum</tt>.
     * 
     * @param eventsSoldNum
     *            value to be assigned to property eventsSoldNum
     */
    public void setEventsSoldNum(Integer eventsSoldNum) {
        this.eventsSoldNum = eventsSoldNum;
    }

    /**
     * Getter method for property <tt>dmxVmaxArraysNum</tt>.
     * 
     * @return property value of dmxVmaxArraysNum
     */
    public Integer getDmxVmaxArraysNum() {
        return dmxVmaxArraysNum;
    }

    /**
     * Setter method for property <tt>dmxVmaxArraysNum</tt>.
     * 
     * @param dmxVmaxArraysNum
     *            value to be assigned to property dmxVmaxArraysNum
     */
    public void setDmxVmaxArraysNum(Integer dmxVmaxArraysNum) {
        this.dmxVmaxArraysNum = dmxVmaxArraysNum;
    }

}

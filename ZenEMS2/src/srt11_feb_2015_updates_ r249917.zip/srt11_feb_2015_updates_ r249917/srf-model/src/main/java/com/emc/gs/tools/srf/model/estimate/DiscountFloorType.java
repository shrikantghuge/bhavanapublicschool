/*
 * This code is copyright (c) 2014 EMC Corporation.
 */
package com.emc.gs.tools.srf.model.estimate;

import com.emc.gs.tools.srf.model.LookupCodeEntity;

/**
 * <p>This is DiscountFloorType entity class.</p>
 *
 * <p><strong>Thread safety</strong>: This class is mutable, it is not thread safety.</p>
 *
 * @author isv
 */
public class DiscountFloorType extends LookupCodeEntity {

    /**
     * <p>Constructs new <code>DiscountFloorType</code> instance. This implementation does nothing.</p>
     */
    public DiscountFloorType() {
    }

}

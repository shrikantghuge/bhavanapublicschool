/*
 * This code is copyright (c) 2014 EMC Corporation
 */
package com.emc.gs.tools.srf.model.atmos;

import com.emc.gs.tools.srf.model.IdentifiableEntity;

/**
 * <p>
 * This is ExistingCenteraCluster entity class.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safety.
 * </p>
 * 
 * @author TCSASSEMBLER
 * @version 1.0
 * @since SRT Phase 3-1 - Atmos Centera and Vblock Tabs Assembly
 */
public class ExistingCenteraCluster extends IdentifiableEntity {

    /**
     * Existing Centera Location.
     */
    private String location;

    /**
     * Existing Centera serial number (mandatory).
     */
    private String serialNumber;

    /**
     * Existing Centera modem number or ESRS.
     */
    private String modemNumber;

    /**
     * Existing Centera edition.
     */
    private CenteraEditionType edition;

    /**
     * Existing Centera generation.
     */
    private CenteraGenerationType generation;

    /**
     * Does this array/cluster require a HealthCheck?
     */
    private CenteraHealthCheckType healthCheck;

    /**
     * What is the replication target for this Centera (or N/A)?
     */
    private String replicationTarget;

    /**
     * What is/will be the C2C migration source for this Centera (or N/A)?
     */
    private String migrationSource;

    /**
     * What is/will be the C2C migration target for this Centera (or N/A)?
     */
    private String migrationTarget;

    /**
     * Will there be a CICM on this Centera?
     */
    private Boolean cicm;

    /**
     * List any new applications that will be writing to the Centera. Include vendor, application name, versions and SDK
     * versions (if known).
     */
    private String applicationsWritting;

    /**
     * What will happen to this array as part of this project?
     */
    private CenteraArrayActionType arrayAction;

    /**
     * Is Certified Data Erasure Required?
     */
    private Boolean certifiedDataErasureRequired;

    /**
     * Is Data Deletion Required?
     */
    private Boolean dataDeletionRequired;

    /**
     * Can the customer provide a clip list for partial erasure?
     */
    private Boolean customerClipList;

    /**
     * <p>
     * The default constructor.
     * </p>
     */
    public ExistingCenteraCluster() {
    }

    /**
     * Getter method for property <tt>location</tt>.
     * 
     * @return property value of location
     */
    public String getLocation() {
        return location;
    }

    /**
     * Setter method for property <tt>location</tt>.
     * 
     * @param location
     *            value to be assigned to property location
     */
    public void setLocation(String location) {
        this.location = location;
    }

    /**
     * Getter method for property <tt>serialNumber</tt>.
     * 
     * @return property value of serialNumber
     */
    public String getSerialNumber() {
        return serialNumber;
    }

    /**
     * Setter method for property <tt>serialNumber</tt>.
     * 
     * @param serialNumber
     *            value to be assigned to property serialNumber
     */
    public void setSerialNumber(String serialNumber) {
        this.serialNumber = serialNumber;
    }

    /**
     * Getter method for property <tt>modemNumber</tt>.
     * 
     * @return property value of modemNumber
     */
    public String getModemNumber() {
        return modemNumber;
    }

    /**
     * Setter method for property <tt>modemNumber</tt>.
     * 
     * @param modemNumber
     *            value to be assigned to property modemNumber
     */
    public void setModemNumber(String modemNumber) {
        this.modemNumber = modemNumber;
    }

    /**
     * Getter method for property <tt>edition</tt>.
     * 
     * @return property value of edition
     */
    public CenteraEditionType getEdition() {
        return edition;
    }

    /**
     * Setter method for property <tt>edition</tt>.
     * 
     * @param edition
     *            value to be assigned to property edition
     */
    public void setEdition(CenteraEditionType edition) {
        this.edition = edition;
    }

    /**
     * Getter method for property <tt>generation</tt>.
     * 
     * @return property value of generation
     */
    public CenteraGenerationType getGeneration() {
        return generation;
    }

    /**
     * Setter method for property <tt>generation</tt>.
     * 
     * @param generation
     *            value to be assigned to property generation
     */
    public void setGeneration(CenteraGenerationType generation) {
        this.generation = generation;
    }

    /**
     * Getter method for property <tt>healthCheck</tt>.
     * 
     * @return property value of healthCheck
     */
    public CenteraHealthCheckType getHealthCheck() {
        return healthCheck;
    }

    /**
     * Setter method for property <tt>healthCheck</tt>.
     * 
     * @param healthCheck
     *            value to be assigned to property healthCheck
     */
    public void setHealthCheck(CenteraHealthCheckType healthCheck) {
        this.healthCheck = healthCheck;
    }

    /**
     * Getter method for property <tt>replicationTarget</tt>.
     * 
     * @return property value of replicationTarget
     */
    public String getReplicationTarget() {
        return replicationTarget;
    }

    /**
     * Setter method for property <tt>replicationTarget</tt>.
     * 
     * @param replicationTarget
     *            value to be assigned to property replicationTarget
     */
    public void setReplicationTarget(String replicationTarget) {
        this.replicationTarget = replicationTarget;
    }

    /**
     * Getter method for property <tt>migrationSource</tt>.
     * 
     * @return property value of migrationSource
     */
    public String getMigrationSource() {
        return migrationSource;
    }

    /**
     * Setter method for property <tt>migrationSource</tt>.
     * 
     * @param migrationSource
     *            value to be assigned to property migrationSource
     */
    public void setMigrationSource(String migrationSource) {
        this.migrationSource = migrationSource;
    }

    /**
     * Getter method for property <tt>migrationTarget</tt>.
     * 
     * @return property value of migrationTarget
     */
    public String getMigrationTarget() {
        return migrationTarget;
    }

    /**
     * Setter method for property <tt>migrationTarget</tt>.
     * 
     * @param migrationTarget
     *            value to be assigned to property migrationTarget
     */
    public void setMigrationTarget(String migrationTarget) {
        this.migrationTarget = migrationTarget;
    }

    /**
     * Getter method for property <tt>cicm</tt>.
     * 
     * @return property value of cicm
     */
    public Boolean getCicm() {
        return cicm;
    }

    /**
     * Setter method for property <tt>cicm</tt>.
     * 
     * @param cicm
     *            value to be assigned to property cicm
     */
    public void setCicm(Boolean cicm) {
        this.cicm = cicm;
    }

    /**
     * Getter method for property <tt>applicationsWritting</tt>.
     * 
     * @return property value of applicationsWritting
     */
    public String getApplicationsWritting() {
        return applicationsWritting;
    }

    /**
     * Setter method for property <tt>applicationsWritting</tt>.
     * 
     * @param applicationsWritting
     *            value to be assigned to property applicationsWritting
     */
    public void setApplicationsWritting(String applicationsWritting) {
        this.applicationsWritting = applicationsWritting;
    }

    /**
     * Getter method for property <tt>arrayAction</tt>.
     * 
     * @return property value of arrayAction
     */
    public CenteraArrayActionType getArrayAction() {
        return arrayAction;
    }

    /**
     * Setter method for property <tt>arrayAction</tt>.
     * 
     * @param arrayAction
     *            value to be assigned to property arrayAction
     */
    public void setArrayAction(CenteraArrayActionType arrayAction) {
        this.arrayAction = arrayAction;
    }

    /**
     * Getter method for property <tt>certifiedDataErasureRequired</tt>.
     * 
     * @return property value of certifiedDataErasureRequired
     */
    public Boolean getCertifiedDataErasureRequired() {
        return certifiedDataErasureRequired;
    }

    /**
     * Setter method for property <tt>certifiedDataErasureRequired</tt>.
     * 
     * @param certifiedDataErasureRequired
     *            value to be assigned to property certifiedDataErasureRequired
     */
    public void setCertifiedDataErasureRequired(Boolean certifiedDataErasureRequired) {
        this.certifiedDataErasureRequired = certifiedDataErasureRequired;
    }

    /**
     * Getter method for property <tt>dataDeletionRequired</tt>.
     * 
     * @return property value of dataDeletionRequired
     */
    public Boolean getDataDeletionRequired() {
        return dataDeletionRequired;
    }

    /**
     * Setter method for property <tt>dataDeletionRequired</tt>.
     * 
     * @param dataDeletionRequired
     *            value to be assigned to property dataDeletionRequired
     */
    public void setDataDeletionRequired(Boolean dataDeletionRequired) {
        this.dataDeletionRequired = dataDeletionRequired;
    }

    /**
     * Getter method for property <tt>customerClipList</tt>.
     * 
     * @return property value of customerClipList
     */
    public Boolean getCustomerClipList() {
        return customerClipList;
    }

    /**
     * Setter method for property <tt>customerClipList</tt>.
     * 
     * @param customerClipList
     *            value to be assigned to property customerClipList
     */
    public void setCustomerClipList(Boolean customerClipList) {
        this.customerClipList = customerClipList;
    }

}

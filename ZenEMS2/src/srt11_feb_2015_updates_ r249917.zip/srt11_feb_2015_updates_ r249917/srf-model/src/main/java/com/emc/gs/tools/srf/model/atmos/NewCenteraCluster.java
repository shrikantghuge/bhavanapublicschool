/*
 * This code is copyright (c) 2014 EMC Corporation
 */
package com.emc.gs.tools.srf.model.atmos;

import com.emc.gs.tools.srf.model.IdentifiableEntity;

/**
 * <p>
 * This is NewCenteraCluster entity class.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safety.
 * </p>
 * 
 * @author TCSASSEMBLER
 * @version 1.0
 * @since SRT Phase 3-1 - Atmos Centera and Vblock Tabs Assembly
 */
public class NewCenteraCluster extends IdentifiableEntity {

    /**
     * New Centera Location.
     */
    private String location;

    /**
     * New Centera edition.
     */
    private CenteraEditionType edition;

    /**
     * New Centera generation.
     */
    private CenteraGenerationType generation;

    /**
     * What protection scheme will each new Centera use?
     */
    private CenteraProtectionSchemeType protectionScheme;

    /**
     * How many nodes will each new Centera have?
     */
    private Integer nodesNum;

    /**
     * What will be the replication target for this Centera?
     */
    private String replicationTarget;

    /**
     * What will be the C2C migration source for this Centera?
     */
    private String migrationSource;

    /**
     * Will this be located at the target site during the migration?
     */
    private Boolean locatedAtTargetSite;

    /**
     * Will this be moved from the target site after the migration?
     */
    private Boolean movedFromTargetSite;

    /**
     * List the applications that will be writing to the Centera. Include vendor, application name, versions and SDK
     * versions (if known).
     */
    private String applicationsWritting;

    /**
     * <p>
     * The default constructor.
     * </p>
     */
    public NewCenteraCluster() {
    }

    /**
     * Getter method for property <tt>location</tt>.
     * 
     * @return property value of location
     */
    public String getLocation() {
        return location;
    }

    /**
     * Setter method for property <tt>location</tt>.
     * 
     * @param location
     *            value to be assigned to property location
     */
    public void setLocation(String location) {
        this.location = location;
    }

    /**
     * Getter method for property <tt>edition</tt>.
     * 
     * @return property value of edition
     */
    public CenteraEditionType getEdition() {
        return edition;
    }

    /**
     * Setter method for property <tt>edition</tt>.
     * 
     * @param edition
     *            value to be assigned to property edition
     */
    public void setEdition(CenteraEditionType edition) {
        this.edition = edition;
    }

    /**
     * Getter method for property <tt>generation</tt>.
     * 
     * @return property value of generation
     */
    public CenteraGenerationType getGeneration() {
        return generation;
    }

    /**
     * Setter method for property <tt>generation</tt>.
     * 
     * @param generation
     *            value to be assigned to property generation
     */
    public void setGeneration(CenteraGenerationType generation) {
        this.generation = generation;
    }

    /**
     * Getter method for property <tt>protectionScheme</tt>.
     * 
     * @return property value of protectionScheme
     */
    public CenteraProtectionSchemeType getProtectionScheme() {
        return protectionScheme;
    }

    /**
     * Setter method for property <tt>protectionScheme</tt>.
     * 
     * @param protectionScheme
     *            value to be assigned to property protectionScheme
     */
    public void setProtectionScheme(CenteraProtectionSchemeType protectionScheme) {
        this.protectionScheme = protectionScheme;
    }

    /**
     * Getter method for property <tt>nodesNum</tt>.
     * 
     * @return property value of nodesNum
     */
    public Integer getNodesNum() {
        return nodesNum;
    }

    /**
     * Setter method for property <tt>nodesNum</tt>.
     * 
     * @param nodesNum
     *            value to be assigned to property nodesNum
     */
    public void setNodesNum(Integer nodesNum) {
        this.nodesNum = nodesNum;
    }

    /**
     * Getter method for property <tt>replicationTarget</tt>.
     * 
     * @return property value of replicationTarget
     */
    public String getReplicationTarget() {
        return replicationTarget;
    }

    /**
     * Setter method for property <tt>replicationTarget</tt>.
     * 
     * @param replicationTarget
     *            value to be assigned to property replicationTarget
     */
    public void setReplicationTarget(String replicationTarget) {
        this.replicationTarget = replicationTarget;
    }

    /**
     * Getter method for property <tt>migrationSource</tt>.
     * 
     * @return property value of migrationSource
     */
    public String getMigrationSource() {
        return migrationSource;
    }

    /**
     * Setter method for property <tt>migrationSource</tt>.
     * 
     * @param migrationSource
     *            value to be assigned to property migrationSource
     */
    public void setMigrationSource(String migrationSource) {
        this.migrationSource = migrationSource;
    }

    /**
     * Getter method for property <tt>locatedAtTargetSite</tt>.
     * 
     * @return property value of locatedAtTargetSite
     */
    public Boolean getLocatedAtTargetSite() {
        return locatedAtTargetSite;
    }

    /**
     * Setter method for property <tt>locatedAtTargetSite</tt>.
     * 
     * @param locatedAtTargetSite
     *            value to be assigned to property locatedAtTargetSite
     */
    public void setLocatedAtTargetSite(Boolean locatedAtTargetSite) {
        this.locatedAtTargetSite = locatedAtTargetSite;
    }

    /**
     * Getter method for property <tt>movedFromTargetSite</tt>.
     * 
     * @return property value of movedFromTargetSite
     */
    public Boolean getMovedFromTargetSite() {
        return movedFromTargetSite;
    }

    /**
     * Setter method for property <tt>movedFromTargetSite</tt>.
     * 
     * @param movedFromTargetSite
     *            value to be assigned to property movedFromTargetSite
     */
    public void setMovedFromTargetSite(Boolean movedFromTargetSite) {
        this.movedFromTargetSite = movedFromTargetSite;
    }

    /**
     * Getter method for property <tt>applicationsWritting</tt>.
     * 
     * @return property value of applicationsWritting
     */
    public String getApplicationsWritting() {
        return applicationsWritting;
    }

    /**
     * Setter method for property <tt>applicationsWritting</tt>.
     * 
     * @param applicationsWritting
     *            value to be assigned to property applicationsWritting
     */
    public void setApplicationsWritting(String applicationsWritting) {
        this.applicationsWritting = applicationsWritting;
    }

}

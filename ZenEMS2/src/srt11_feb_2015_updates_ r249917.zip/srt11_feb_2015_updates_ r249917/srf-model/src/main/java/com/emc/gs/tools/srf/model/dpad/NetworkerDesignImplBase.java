/*
 * This code is copyright (c) 2014 EMC Corporation
 */
package com.emc.gs.tools.srf.model.dpad;

import com.emc.gs.tools.srf.model.IdentifiableEntity;

/**
 * <p>
 * This is NetworkerDesignImplBase entity class.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safety.
 * </p>
 * 
 * @author TCSASSEMBLER
 * @version 1.0
 * @since SRT Phase 3-5 - BRS Tabs Part 3 Assembly
 */
public abstract class NetworkerDesignImplBase extends IdentifiableEntity {

    /**
     * The networker components selected.
     */
    private NetworkerComponents components;

    /**
     * The networker storage nodes data.
     */
    private NetworkerStorageNodes storageNodes;

    /**
     * The networker media devices data.
     */
    private NetworkerMediaDevices mediaDevices;

    /**
     * <p>
     * The default constructor.
     * </p>
     */
    protected NetworkerDesignImplBase() {
    }

    /**
     * Getter method for property <tt>components</tt>.
     * 
     * @return property value of components
     */
    public NetworkerComponents getComponents() {
        return components;
    }

    /**
     * Setter method for property <tt>components</tt>.
     * 
     * @param components
     *            value to be assigned to property components
     */
    public void setComponents(NetworkerComponents components) {
        this.components = components;
    }

    /**
     * Getter method for property <tt>storageNodes</tt>.
     * 
     * @return property value of storageNodes
     */
    public NetworkerStorageNodes getStorageNodes() {
        return storageNodes;
    }

    /**
     * Setter method for property <tt>storageNodes</tt>.
     * 
     * @param storageNodes
     *            value to be assigned to property storageNodes
     */
    public void setStorageNodes(NetworkerStorageNodes storageNodes) {
        this.storageNodes = storageNodes;
    }

    /**
     * Getter method for property <tt>mediaDevices</tt>.
     * 
     * @return property value of mediaDevices
     */
    public NetworkerMediaDevices getMediaDevices() {
        return mediaDevices;
    }

    /**
     * Setter method for property <tt>mediaDevices</tt>.
     * 
     * @param mediaDevices
     *            value to be assigned to property mediaDevices
     */
    public void setMediaDevices(NetworkerMediaDevices mediaDevices) {
        this.mediaDevices = mediaDevices;
    }

}

/*
 * This code is copyright (c) 2014 EMC Corporation.
 */
package com.emc.gs.tools.srf.model.dpad;

import java.math.BigDecimal;

import com.emc.gs.tools.srf.model.IdentifiableEntity;

/**
 * <p>
 * This is Vplex entity class.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safety.
 * </p>
 * 
 * @author TCSASSEMBLER
 * @version 1.0
 * @since SRT Phase 3-5 - BRS Tabs Part 1 Assembly
 */
public class Vplex extends IdentifiableEntity {

    /**
     * # of Hours of Knowledge Transfer.
     */
    private BigDecimal knowledgeTransferHours;

    /**
     * # of sites to install VPlex.
     */
    private Integer sitesNumber;

    /**
     * # of VPlex engines to install (total).
     */
    private Integer engineNumber;

    /**
     * # of VPlex directors to install (total).
     */
    private Integer directorsNumber;

    /**
     * # of existing CX4 arrays to be upgraded.
     */
    private Integer existingC4UpgradedNumber;

    /**
     * # of VPlex Virtual Volumes.
     */
    private Integer virtualVolumesNumber;

    /**
     * # of VPlex Mirrors.
     */
    private Integer mirrorsNumber;

    /**
     * # of VPlex MetroClusters to configure.
     */
    private Integer metroClustersNumber;

    /**
     * # of VPlex GeoClusters to configure.
     */
    private Integer geoClustersNumber;

    /**
     * # of hosts using VPlex.
     */
    private Integer hostsNumber;

    /**
     * # of arrays attached to VPlex.
     */
    private Integer arraysNumber;

    /**
     * # of storage ports dedicated to VPlex.
     */
    private Integer storagePortsNumber;

    /**
     * # of storage volumes imported into VPlex.
     */
    private Integer storageVolumesNumber;

    /**
     * # of VPlex Witness Servers.
     */
    private Integer witnessServerNumber;

    /**
     * Type of data mobility to be implemented.
     */
    private VplexDataMobilityType dataMobilityType;

    /**
     * # of data mobility jobs.
     */
    private Integer dataMobilityJobsNumber;

    /**
     * # of hosts to have data encapsulated.
     */
    private Integer encapsulatedHostsNumber;

    /**
     * Will hardware be installed in a customer's rack by EMC?
     */
    private Boolean emcInstalledOption;

    /**
     * Does RecoverPoint have to be installed with VPLEX?
     */
    private Boolean recoverPointInstalledOption;

    /**
     * <p>
     * The default constructor.
     * </p>
     */
    public Vplex() {
        // Empty
    }

    /**
     * <p>
     * Retrieves the knowledgeTransferHours field.
     * </p>
     * 
     * @return the knowledgeTransferHours
     */
    public BigDecimal getKnowledgeTransferHours() {
        return knowledgeTransferHours;
    }

    /**
     * <p>
     * Sets the value to knowledgeTransferHours field.
     * </p>
     * 
     * @param knowledgeTransferHours
     *            the knowledgeTransferHours to set
     */
    public void setKnowledgeTransferHours(BigDecimal knowledgeTransferHours) {
        this.knowledgeTransferHours = knowledgeTransferHours;
    }

    /**
     * <p>
     * Retrieves the sitesNumber field.
     * </p>
     * 
     * @return the sitesNumber
     */
    public Integer getSitesNumber() {
        return sitesNumber;
    }

    /**
     * <p>
     * Sets the value to sitesNumber field.
     * </p>
     * 
     * @param sitesNumber
     *            the sitesNumber to set
     */
    public void setSitesNumber(Integer sitesNumber) {
        this.sitesNumber = sitesNumber;
    }

    /**
     * <p>
     * Retrieves the engineNumber field.
     * </p>
     * 
     * @return the engineNumber
     */
    public Integer getEngineNumber() {
        return engineNumber;
    }

    /**
     * <p>
     * Sets the value to engineNumber field.
     * </p>
     * 
     * @param engineNumber
     *            the engineNumber to set
     */
    public void setEngineNumber(Integer engineNumber) {
        this.engineNumber = engineNumber;
    }

    /**
     * <p>
     * Retrieves the directorsNumber field.
     * </p>
     * 
     * @return the directorsNumber
     */
    public Integer getDirectorsNumber() {
        return directorsNumber;
    }

    /**
     * <p>
     * Sets the value to directorsNumber field.
     * </p>
     * 
     * @param directorsNumber
     *            the directorsNumber to set
     */
    public void setDirectorsNumber(Integer directorsNumber) {
        this.directorsNumber = directorsNumber;
    }

    /**
     * <p>
     * Retrieves the virtualVolumesNumber field.
     * </p>
     * 
     * @return the virtualVolumesNumber
     */
    public Integer getVirtualVolumesNumber() {
        return virtualVolumesNumber;
    }

    /**
     * <p>
     * Sets the value to virtualVolumesNumber field.
     * </p>
     * 
     * @param virtualVolumesNumber
     *            the virtualVolumesNumber to set
     */
    public void setVirtualVolumesNumber(Integer virtualVolumesNumber) {
        this.virtualVolumesNumber = virtualVolumesNumber;
    }

    /**
     * <p>
     * Retrieves the mirrorsNumber field.
     * </p>
     * 
     * @return the mirrorsNumber
     */
    public Integer getMirrorsNumber() {
        return mirrorsNumber;
    }

    /**
     * <p>
     * Sets the value to mirrorsNumber field.
     * </p>
     * 
     * @param mirrorsNumber
     *            the mirrorsNumber to set
     */
    public void setMirrorsNumber(Integer mirrorsNumber) {
        this.mirrorsNumber = mirrorsNumber;
    }

    /**
     * <p>
     * Retrieves the metroClustersNumber field.
     * </p>
     * 
     * @return the metroClustersNumber
     */
    public Integer getMetroClustersNumber() {
        return metroClustersNumber;
    }

    /**
     * <p>
     * Sets the value to metroClustersNumber field.
     * </p>
     * 
     * @param metroClustersNumber
     *            the metroClustersNumber to set
     */
    public void setMetroClustersNumber(Integer metroClustersNumber) {
        this.metroClustersNumber = metroClustersNumber;
    }

    /**
     * <p>
     * Retrieves the geoClustersNumber field.
     * </p>
     * 
     * @return the geoClustersNumber
     */
    public Integer getGeoClustersNumber() {
        return geoClustersNumber;
    }

    /**
     * <p>
     * Sets the value to geoClustersNumber field.
     * </p>
     * 
     * @param geoClustersNumber
     *            the geoClustersNumber to set
     */
    public void setGeoClustersNumber(Integer geoClustersNumber) {
        this.geoClustersNumber = geoClustersNumber;
    }

    /**
     * <p>
     * Retrieves the hostsNumber field.
     * </p>
     * 
     * @return the hostsNumber
     */
    public Integer getHostsNumber() {
        return hostsNumber;
    }

    /**
     * <p>
     * Sets the value to hostsNumber field.
     * </p>
     * 
     * @param hostsNumber
     *            the hostsNumber to set
     */
    public void setHostsNumber(Integer hostsNumber) {
        this.hostsNumber = hostsNumber;
    }

    /**
     * <p>
     * Retrieves the arraysNumber field.
     * </p>
     * 
     * @return the arraysNumber
     */
    public Integer getArraysNumber() {
        return arraysNumber;
    }

    /**
     * <p>
     * Sets the value to arraysNumber field.
     * </p>
     * 
     * @param arraysNumber
     *            the arraysNumber to set
     */
    public void setArraysNumber(Integer arraysNumber) {
        this.arraysNumber = arraysNumber;
    }

    /**
     * <p>
     * Retrieves the storagePortsNumber field.
     * </p>
     * 
     * @return the storagePortsNumber
     */
    public Integer getStoragePortsNumber() {
        return storagePortsNumber;
    }

    /**
     * <p>
     * Sets the value to storagePortsNumber field.
     * </p>
     * 
     * @param storagePortsNumber
     *            the storagePortsNumber to set
     */
    public void setStoragePortsNumber(Integer storagePortsNumber) {
        this.storagePortsNumber = storagePortsNumber;
    }

    /**
     * <p>
     * Retrieves the storageVolumesNumber field.
     * </p>
     * 
     * @return the storageVolumesNumber
     */
    public Integer getStorageVolumesNumber() {
        return storageVolumesNumber;
    }

    /**
     * <p>
     * Sets the value to storageVolumesNumber field.
     * </p>
     * 
     * @param storageVolumesNumber
     *            the storageVolumesNumber to set
     */
    public void setStorageVolumesNumber(Integer storageVolumesNumber) {
        this.storageVolumesNumber = storageVolumesNumber;
    }

    /**
     * <p>
     * Retrieves the witnessServerNumber field.
     * </p>
     * 
     * @return the witnessServerNumber
     */
    public Integer getWitnessServerNumber() {
        return witnessServerNumber;
    }

    /**
     * <p>
     * Sets the value to witnessServerNumber field.
     * </p>
     * 
     * @param witnessServerNumber
     *            the witnessServerNumber to set
     */
    public void setWitnessServerNumber(Integer witnessServerNumber) {
        this.witnessServerNumber = witnessServerNumber;
    }

    /**
     * Getter method for property <tt>dataMobilityType</tt>.
     * 
     * @return property value of dataMobilityType
     */
    public VplexDataMobilityType getDataMobilityType() {
        return dataMobilityType;
    }

    /**
     * Setter method for property <tt>dataMobilityType</tt>.
     * 
     * @param dataMobilityType
     *            value to be assigned to property dataMobilityType
     */
    public void setDataMobilityType(VplexDataMobilityType dataMobilityType) {
        this.dataMobilityType = dataMobilityType;
    }

    /**
     * <p>
     * Retrieves the dataMobilityJobsNumber field.
     * </p>
     * 
     * @return the dataMobilityJobsNumber
     */
    public Integer getDataMobilityJobsNumber() {
        return dataMobilityJobsNumber;
    }

    /**
     * <p>
     * Sets the value to dataMobilityJobsNumber field.
     * </p>
     * 
     * @param dataMobilityJobsNumber
     *            the dataMobilityJobsNumber to set
     */
    public void setDataMobilityJobsNumber(Integer dataMobilityJobsNumber) {
        this.dataMobilityJobsNumber = dataMobilityJobsNumber;
    }

    /**
     * <p>
     * Retrieves the encapsulatedHostsNumber field.
     * </p>
     * 
     * @return the encapsulatedHostsNumber
     */
    public Integer getEncapsulatedHostsNumber() {
        return encapsulatedHostsNumber;
    }

    /**
     * <p>
     * Sets the value to encapsulatedHostsNumber field.
     * </p>
     * 
     * @param encapsulatedHostsNumber
     *            the encapsulatedHostsNumber to set
     */
    public void setEncapsulatedHostsNumber(Integer encapsulatedHostsNumber) {
        this.encapsulatedHostsNumber = encapsulatedHostsNumber;
    }

    /**
     * <p>
     * Retrieves the emcInstalledOption field.
     * </p>
     * 
     * @return the emcInstalledOption
     */
    public Boolean getEmcInstalledOption() {
        return emcInstalledOption;
    }

    /**
     * <p>
     * Sets the value to emcInstalledOption field.
     * </p>
     * 
     * @param emcInstalledOption
     *            the emcInstalledOption to set
     */
    public void setEmcInstalledOption(Boolean emcInstalledOption) {
        this.emcInstalledOption = emcInstalledOption;
    }

    /**
     * <p>
     * Retrieves the recoverPointInstalledOption field.
     * </p>
     * 
     * @return the recoverPointInstalledOption
     */
    public Boolean getRecoverPointInstalledOption() {
        return recoverPointInstalledOption;
    }

    /**
     * <p>
     * Sets the value to recoverPointInstalledOption field.
     * </p>
     * 
     * @param recoverPointInstalledOption
     *            the recoverPointInstalledOption to set
     */
    public void setRecoverPointInstalledOption(Boolean recoverPointInstalledOption) {
        this.recoverPointInstalledOption = recoverPointInstalledOption;
    }

    /**
     * <p>
     * Retrieves the existingC4UpgradedNumber field.
     * </p>
     * 
     * @return the value of existingC4UpgradedNumber
     */
    public Integer getExistingC4UpgradedNumber() {
        return existingC4UpgradedNumber;
    }

    /**
     * <p>
     * Sets the value to existingC4UpgradedNumber field.
     * </p>
     * 
     * @param existingC4UpgradedNumber
     *            the value of existingC4UpgradedNumber to set
     */
    public void setExistingC4UpgradedNumber(Integer existingC4UpgradedNumber) {
        this.existingC4UpgradedNumber = existingC4UpgradedNumber;
    }
}

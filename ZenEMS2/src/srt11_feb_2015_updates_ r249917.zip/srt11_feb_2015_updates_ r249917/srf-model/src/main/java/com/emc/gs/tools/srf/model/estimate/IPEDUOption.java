/*
 * This code is copyright (c) 2015 EMC Corporation.
 */
package com.emc.gs.tools.srf.model.estimate;

/**
 * <p>This is IPEDUOption enum.</p>
 *
 * @author isv
 */
public enum IPEDUOption {
    
    IP("IP"),
    
    EDU("EDU");

    /**
     * <p>A name for this item.</p>
     */
    private String name; 

    /**
     * <p>Constructs new <code>IPEDUOption</code> instance. This implementation does nothing.</p>
     */
    private IPEDUOption(String name) {
        this.name = name;
    }

    /**
     * <p>Gets the textual presentation for this item.</p>
     * 
     * @return the textual presentation for this item.
     */
    @Override
    public String toString() {
        return this.name;
    }
}

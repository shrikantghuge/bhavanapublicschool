/*
 * This code is copyright (c) 2014 EMC Corporation
 */
package com.emc.gs.tools.srf.model.healthcheck;

import com.emc.gs.tools.srf.model.IdentifiableEntity;

/**
 * <p>
 * This is HealthCheckServicesScope entity class.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safety.
 * </p>
 * <p>
 * 
 * @author TCSASSEMBLER
 * @version 1.0
 * @since SRT Phase 3-4 - ASD and Healthcheck Tabs Assembly
 */
public class HealthCheckServicesScope extends IdentifiableEntity {

    /**
     * Represents whether Avamar service is in scope.
     */
    private boolean avamar;

    /**
     * Represents whether Data Domain service is in scope.
     */
    private boolean dataDomain;

    /**
     * Represents whether Data Protection Advisor service is in scope.
     */
    private boolean dpa;

    /**
     * Represents whether DLM service is in scope.
     */
    private boolean dlm;

    /**
     * Represents whether GreenPlum service is in scope.
     */
    private boolean greenPlum;

    /**
     * Represents whether Ionix service is in scope.
     */
    private boolean ionix;

    /**
     * Represents whether NetWorker service is in scope.
     */
    private boolean netWorker;

    /**
     * Represents whether San Security service is in scope.
     */
    private boolean sanSecurity;

    /**
     * Represents whether SAP service is in scope.
     */
    private boolean sap;

    /**
     * Represents whether SourceOne service is in scope.
     */
    private boolean sourceOne;

    /**
     * Represents whether Symmetrix / Vmax service is in scope.
     */
    private boolean symmetrixVmax;

    /**
     * Represents whether Symmetrix / Vmax Storage Replication service is in scope.
     */
    private boolean symmetrixVmaxStorageReplication;

    /**
     * Represents whether Unified service is in scope.
     */
    private boolean unified;

    /**
     * Represents whether Vblock service is in scope.
     */
    private boolean vblock;

    /**
     * Represents whether VMWare Virtual Infrastructure service is in scope.
     */
    private boolean vmwareVirtualInfrastructure;

    /**
     * Represents whether Vplex service is in scope.
     */
    private boolean vplex;

    /**
     * <p>
     * The default constructor.
     * </p>
     */
    public HealthCheckServicesScope() {
    }

    /**
     * Getter method for property <tt>avamar</tt>.
     * 
     * @return property value of avamar
     */
    public boolean isAvamar() {
        return avamar;
    }

    /**
     * Setter method for property <tt>avamar</tt>.
     * 
     * @param avamar
     *            value to be assigned to property avamar
     */
    public void setAvamar(boolean avamar) {
        this.avamar = avamar;
    }

    /**
     * Getter method for property <tt>dataDomain</tt>.
     * 
     * @return property value of dataDomain
     */
    public boolean isDataDomain() {
        return dataDomain;
    }

    /**
     * Setter method for property <tt>dataDomain</tt>.
     * 
     * @param dataDomain
     *            value to be assigned to property dataDomain
     */
    public void setDataDomain(boolean dataDomain) {
        this.dataDomain = dataDomain;
    }

    /**
     * Getter method for property <tt>dpa</tt>.
     * 
     * @return property value of dpa
     */
    public boolean isDpa() {
        return dpa;
    }

    /**
     * Setter method for property <tt>dpa</tt>.
     * 
     * @param dpa
     *            value to be assigned to property dpa
     */
    public void setDpa(boolean dpa) {
        this.dpa = dpa;
    }

    /**
     * Getter method for property <tt>dlm</tt>.
     * 
     * @return property value of dlm
     */
    public boolean isDlm() {
        return dlm;
    }

    /**
     * Setter method for property <tt>dlm</tt>.
     * 
     * @param dlm
     *            value to be assigned to property dlm
     */
    public void setDlm(boolean dlm) {
        this.dlm = dlm;
    }

    /**
     * Getter method for property <tt>greenPlum</tt>.
     * 
     * @return property value of greenPlum
     */
    public boolean isGreenPlum() {
        return greenPlum;
    }

    /**
     * Setter method for property <tt>greenPlum</tt>.
     * 
     * @param greenPlum
     *            value to be assigned to property greenPlum
     */
    public void setGreenPlum(boolean greenPlum) {
        this.greenPlum = greenPlum;
    }

    /**
     * Getter method for property <tt>ionix</tt>.
     * 
     * @return property value of ionix
     */
    public boolean isIonix() {
        return ionix;
    }

    /**
     * Setter method for property <tt>ionix</tt>.
     * 
     * @param ionix
     *            value to be assigned to property ionix
     */
    public void setIonix(boolean ionix) {
        this.ionix = ionix;
    }

    /**
     * Getter method for property <tt>netWorker</tt>.
     * 
     * @return property value of netWorker
     */
    public boolean isNetWorker() {
        return netWorker;
    }

    /**
     * Setter method for property <tt>netWorker</tt>.
     * 
     * @param netWorker
     *            value to be assigned to property netWorker
     */
    public void setNetWorker(boolean netWorker) {
        this.netWorker = netWorker;
    }

    /**
     * Getter method for property <tt>sanSecurity</tt>.
     * 
     * @return property value of sanSecurity
     */
    public boolean isSanSecurity() {
        return sanSecurity;
    }

    /**
     * Setter method for property <tt>sanSecurity</tt>.
     * 
     * @param sanSecurity
     *            value to be assigned to property sanSecurity
     */
    public void setSanSecurity(boolean sanSecurity) {
        this.sanSecurity = sanSecurity;
    }

    /**
     * Getter method for property <tt>sap</tt>.
     * 
     * @return property value of sap
     */
    public boolean isSap() {
        return sap;
    }

    /**
     * Setter method for property <tt>sap</tt>.
     * 
     * @param sap
     *            value to be assigned to property sap
     */
    public void setSap(boolean sap) {
        this.sap = sap;
    }

    /**
     * Getter method for property <tt>sourceOne</tt>.
     * 
     * @return property value of sourceOne
     */
    public boolean isSourceOne() {
        return sourceOne;
    }

    /**
     * Setter method for property <tt>sourceOne</tt>.
     * 
     * @param sourceOne
     *            value to be assigned to property sourceOne
     */
    public void setSourceOne(boolean sourceOne) {
        this.sourceOne = sourceOne;
    }

    /**
     * Getter method for property <tt>symmetrixVmax</tt>.
     * 
     * @return property value of symmetrixVmax
     */
    public boolean isSymmetrixVmax() {
        return symmetrixVmax;
    }

    /**
     * Setter method for property <tt>symmetrixVmax</tt>.
     * 
     * @param symmetrixVmax
     *            value to be assigned to property symmetrixVmax
     */
    public void setSymmetrixVmax(boolean symmetrixVmax) {
        this.symmetrixVmax = symmetrixVmax;
    }

    /**
     * Getter method for property <tt>symmetrixVmaxStorageReplication</tt>.
     * 
     * @return property value of symmetrixVmaxStorageReplication
     */
    public boolean isSymmetrixVmaxStorageReplication() {
        return symmetrixVmaxStorageReplication;
    }

    /**
     * Setter method for property <tt>symmetrixVmaxStorageReplication</tt>.
     * 
     * @param symmetrixVmaxStorageReplication
     *            value to be assigned to property symmetrixVmaxStorageReplication
     */
    public void setSymmetrixVmaxStorageReplication(boolean symmetrixVmaxStorageReplication) {
        this.symmetrixVmaxStorageReplication = symmetrixVmaxStorageReplication;
    }

    /**
     * Getter method for property <tt>unified</tt>.
     * 
     * @return property value of unified
     */
    public boolean isUnified() {
        return unified;
    }

    /**
     * Setter method for property <tt>unified</tt>.
     * 
     * @param unified
     *            value to be assigned to property unified
     */
    public void setUnified(boolean unified) {
        this.unified = unified;
    }

    /**
     * Getter method for property <tt>vblock</tt>.
     * 
     * @return property value of vblock
     */
    public boolean isVblock() {
        return vblock;
    }

    /**
     * Setter method for property <tt>vblock</tt>.
     * 
     * @param vblock
     *            value to be assigned to property vblock
     */
    public void setVblock(boolean vblock) {
        this.vblock = vblock;
    }

    /**
     * Getter method for property <tt>vmwareVirtualInfrastructure</tt>.
     * 
     * @return property value of vmwareVirtualInfrastructure
     */
    public boolean isVmwareVirtualInfrastructure() {
        return vmwareVirtualInfrastructure;
    }

    /**
     * Setter method for property <tt>vmwareVirtualInfrastructure</tt>.
     * 
     * @param vmwareVirtualInfrastructure
     *            value to be assigned to property vmwareVirtualInfrastructure
     */
    public void setVmwareVirtualInfrastructure(boolean vmwareVirtualInfrastructure) {
        this.vmwareVirtualInfrastructure = vmwareVirtualInfrastructure;
    }

    /**
     * Getter method for property <tt>vplex</tt>.
     * 
     * @return property value of vplex
     */
    public boolean isVplex() {
        return vplex;
    }

    /**
     * Setter method for property <tt>vplex</tt>.
     * 
     * @param vplex
     *            value to be assigned to property vplex
     */
    public void setVplex(boolean vplex) {
        this.vplex = vplex;
    }

}

/*
 * This code is copyright (c) 2014 EMC Corporation
 */
package com.emc.gs.tools.srf.model.dpad;

/**
 * <p>
 * This is DataDomainPreRack entity class.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safety.
 * </p>
 *
 * <p>
 * Version 1.1 (SRT 4 OCT2014 Updates Part 1 Assembly) Change notes:
 *   <ol>
 *     <li>Removed <code>enableRetentionLocking</code> property.</li>
 *     <li>Removed <code>ddrsNum</code> property.</li>
 *     <li>Removed <code>mtreesNum</code> property.</li>
 *   </ol>
 * </p>
 * 
 * @author isv
 * @version 1.1
 * @since SRT Phase 3-5 - BRS Tabs Part 2 Assembly
 */
public class DataDomainPreRack extends DataDomainImplBase {

    /**
     * Pre-Racked Implementation Type.
     */
    private DataDomainPreRackType preRackType;

    /**
     * # of Pre-Racked System Racks.
     */
    private Integer preRackedSystemRacksNum;

    /**
     * # of EDL Virtual Tape Libraries(VTL).
     */
    private Integer edlVirtualTapeLibrariesNum;

    /**
     * # of Servers for DD Boost Device Installation and Configuration.
     */
    private Integer serversForDDBoostNum;

    /**
     * <p>
     * The default constructor.
     * </p>
     */
    public DataDomainPreRack() {
    }

    /**
     * Getter method for property <tt>preRackType</tt>.
     * 
     * @return property value of preRackType
     */
    public DataDomainPreRackType getPreRackType() {
        return preRackType;
    }

    /**
     * Setter method for property <tt>preRackType</tt>.
     * 
     * @param preRackType
     *            value to be assigned to property preRackType
     */
    public void setPreRackType(DataDomainPreRackType preRackType) {
        this.preRackType = preRackType;
    }

    /**
     * Getter method for property <tt>preRackedSystemRacksNum</tt>.
     * 
     * @return property value of preRackedSystemRacksNum
     */
    public Integer getPreRackedSystemRacksNum() {
        return preRackedSystemRacksNum;
    }

    /**
     * Setter method for property <tt>preRackedSystemRacksNum</tt>.
     * 
     * @param preRackedSystemRacksNum
     *            value to be assigned to property preRackedSystemRacksNum
     */
    public void setPreRackedSystemRacksNum(Integer preRackedSystemRacksNum) {
        this.preRackedSystemRacksNum = preRackedSystemRacksNum;
    }

    /**
     * Getter method for property <tt>edlVirtualTapeLibrariesNum</tt>.
     * 
     * @return property value of edlVirtualTapeLibrariesNum
     */
    public Integer getEdlVirtualTapeLibrariesNum() {
        return edlVirtualTapeLibrariesNum;
    }

    /**
     * Setter method for property <tt>edlVirtualTapeLibrariesNum</tt>.
     * 
     * @param edlVirtualTapeLibrariesNum
     *            value to be assigned to property edlVirtualTapeLibrariesNum
     */
    public void setEdlVirtualTapeLibrariesNum(Integer edlVirtualTapeLibrariesNum) {
        this.edlVirtualTapeLibrariesNum = edlVirtualTapeLibrariesNum;
    }

    /**
     * Getter method for property <tt>serversForDDBoostNum</tt>.
     * 
     * @return property value of serversForDDBoostNum
     */
    public Integer getServersForDDBoostNum() {
        return serversForDDBoostNum;
    }

    /**
     * Setter method for property <tt>serversForDDBoostNum</tt>.
     * 
     * @param serversForDDBoostNum
     *            value to be assigned to property serversForDDBoostNum
     */
    public void setServersForDDBoostNum(Integer serversForDDBoostNum) {
        this.serversForDDBoostNum = serversForDDBoostNum;
    }

}

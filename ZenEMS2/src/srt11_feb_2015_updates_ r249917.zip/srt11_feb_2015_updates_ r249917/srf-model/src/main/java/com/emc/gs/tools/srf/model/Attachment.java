/*
 * This code is copyright (c) 2013 - 2014 EMC Corporation.
 */
package com.emc.gs.tools.srf.model;

import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

/**
 * <p>
 * This is Attachment entity class.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safety.
 * </p>
 * 
 * <p>
 * <strong>Changes V1.1:</strong>
 * <strong>SRT Bug Fixes</strong>
 * <ul>
 * <li>Added attachmentSize field.</li>
 * </ul>
 * </p>
 *
 * @author faeton, stevenfrog, MonicaMuranyi
 * @version 1.1
 */
@XmlType
@XmlRootElement
public class Attachment extends IdentifiableEntity {
    /**
     * <p>
     * The attachmentFilename.
     * </p>
     */
    private String attachmentFilename;

    /**
     * <p>
     * The attachmentFilepath.
     * </p>
     */
    private String attachmentFilepath;
    
    /**
     * <p>
     * The attachmentSize.
     * </p>
     */
    private long attachmentSize;

    /**
     * <p>
     * The default constructor.
     * </p>
     */
    public Attachment() {
        // Empty
    }

    /**
     * <p>
     * Retrieves the attachmentFilename field.
     * </p>
     *
     * @return the attachmentFilename
     */
    public String getAttachmentFilename() {
        return attachmentFilename;
    }

    /**
     * <p>
     * Sets the value to attachmentFilename field.
     * </p>
     *
     * @param attachmentFilename
     *            the attachmentFilename to set
     */
    public void setAttachmentFilename(String attachmentFilename) {
        this.attachmentFilename = attachmentFilename;
    }

    /**
     * <p>
     * Retrieves the attachmentFilepath field.
     * </p>
     *
     * @return the attachmentFilepath
     */
    public String getAttachmentFilepath() {
        return attachmentFilepath;
    }

    /**
     * <p>
     * Sets the value to attachmentFilepath field.
     * </p>
     *
     * @param attachmentFilepath
     *            the attachmentFilepath to set
     */
    public void setAttachmentFilepath(String attachmentFilepath) {
        this.attachmentFilepath = attachmentFilepath;
    }
    
    

    /**
     * <p>
     * Retrieves the attachmentSize field.
     * </p>
     *
     * @return the attachmentSize
     */
    public long getAttachmentSize() {
        return attachmentSize;
    }

    /**
     * <p>
     * Sets the value to attachmentSize field.
     * </p>
     *
     * @param attachmentSize
     *            the attachmentSize to set
     */
    public void setAttachmentSize(long attachmentSize) {
        this.attachmentSize = attachmentSize;
    }

    /**
     * The toString method.
     *
     * @return the string for this entity
     */
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("{").append(super.toString());
        sb.append(", attachmentFilename:").append(attachmentFilename);
        sb.append(", attachmentFilepath:").append(attachmentFilepath);
        sb.append(", attachmentSize:").append(attachmentSize).append("}");
        return sb.toString();
    }
}

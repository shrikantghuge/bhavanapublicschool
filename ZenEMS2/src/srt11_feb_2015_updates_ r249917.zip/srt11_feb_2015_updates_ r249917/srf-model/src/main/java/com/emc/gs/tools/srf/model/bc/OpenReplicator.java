/*
 * This code is copyright (c) 2013 - 2014 EMC Corporation.
 */
package com.emc.gs.tools.srf.model.bc;

import com.emc.gs.tools.srf.model.IdentifiableEntity;

/**
 * <p>
 * This is OpenReplicator entity class.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safety.
 * </p>
 * 
 * <p>
 * <strong>Changes V1.1:</strong>
 * <strong>SRT Bug Fixes - F121, F153, F154, F162</strong>
 * <ul>
 * <li>Add knowledgeTransferHours field.</li>
 * </ul>
 * </p>
 *
 * <p>
 * Version 1.2 (SRT 4 OCT2014 Updates Part 1) Change notes:
 *   <ol>
 *     <li>Removed almost all properties as the class is going to be not used in future.</li>
 *   </ol>
 * </p>
 * 
 * @author faeton, stevenfrog, MonicaMuranyi, isv
 * @version 1.2
 */
public class OpenReplicator extends IdentifiableEntity {
    
    /**
     * <p>
     * The knowledgeTransferHours.
     * </p>
     */
    private String knowledgeTransferHours;
    
    /**
     * <p>
     * The postSalesCompletionQualifier.
     * </p>
     */
    private PostSalesCompletionQualifier postSalesCompletionQualifier;

    /**
     * <p>
     * The default constructor.
     * </p>
     */
    public OpenReplicator() {
        // Empty
    }
    
    /**
     * <p>
     * Retrieves the knowledgeTransferHours field.
     * </p>
     *
     * @return the knowledgeTransferHours
     */
    public String getKnowledgeTransferHours() {
        return knowledgeTransferHours;
    }

    /**
     * <p>
     * Sets the value to knowledgeTransferHours field.
     * </p>
     *
     * @param knowledgeTransferHours
     *            the knowledgeTransferHours to set
     */
    public void setKnowledgeTransferHours(String knowledgeTransferHours) {
        this.knowledgeTransferHours = knowledgeTransferHours;
    }

    /**
     * <p>
     * Retrieves the postSalesCompletionQualifier field.
     * </p>
     *
     * @return the postSalesCompletionQualifier
     */
    public PostSalesCompletionQualifier getPostSalesCompletionQualifier() {
        return postSalesCompletionQualifier;
    }

    /**
     * <p>
     * Sets the value to postSalesCompletionQualifier field.
     * </p>
     *
     * @param postSalesCompletionQualifier
     *            the postSalesCompletionQualifier to set
     */
    public void setPostSalesCompletionQualifier(PostSalesCompletionQualifier postSalesCompletionQualifier) {
        this.postSalesCompletionQualifier = postSalesCompletionQualifier;
    }


    /**
     * The toString method.
     *
     * @return the string for this entity
     */
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("{").append(super.toString());
        sb.append(", knowledgeTransferHours:").append(knowledgeTransferHours);
        sb.append(", postSalesCompletionQualifier:").append(postSalesCompletionQualifier);
        sb.append("}");
        return sb.toString();
    }
}

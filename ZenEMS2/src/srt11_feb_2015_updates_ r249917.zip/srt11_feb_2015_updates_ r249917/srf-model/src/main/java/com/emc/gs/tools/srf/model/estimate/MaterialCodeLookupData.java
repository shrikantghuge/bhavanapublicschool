/*
 * This code is copyright (c) 2014 EMC Corporation.
 */
package com.emc.gs.tools.srf.model.estimate;

import java.util.Map;

import com.emc.gs.tools.srf.model.LookupCodeEntity;

/**
 * <p>
 * This is MaterialCodeLookupData entity class.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safety.
 * </p>
 *
 * <p>
 * Version 1.1 Change notes:
 *   <ol>
 *     <li>Added {@link #discountFloors} property.</li>
 *   </ol>
 * </p>
 * 
 * @author TCSASSEMBLER
 * @version 1.1
 * @since SRT Phase 4 - ET Assembly 1
 */
public class MaterialCodeLookupData extends LookupCodeEntity {

    /**
     * The map of competences of this material code. The key is competence ID.
     */
    private Map<Long, CompetencyLookupData> competences;

    /**
     * <p>A <code>DiscountFloorGroup</code> providing the value for discountFloors property.</p>
     *
     * @since 1.1
     */
    private DiscountFloorGroup discountFloors;

    /**
     * Empty constructor.
     */
    public MaterialCodeLookupData() {
    }

    /**
     * Getter method for property <tt>competences</tt>.
     * 
     * @return property value of competences
     */
    public Map<Long, CompetencyLookupData> getCompetences() {
        return competences;
    }

    /**
     * Setter method for property <tt>competences</tt>.
     * 
     * @param competences
     *            value to be assigned to property competences
     */
    public void setCompetences(Map<Long, CompetencyLookupData> competences) {
        this.competences = competences;
    }

    /**
     * <p>Gets the discountFloors property.</p>
     *
     * @return a <code>DiscountFloorGroup</code> providing the value for discountFloors property.
     * @since 1.1
     */
    public DiscountFloorGroup getDiscountFloors() {
        return this.discountFloors;
    }

    /**
     * <p>Sets the discountFloors property.</p>
     *
     * @param discountFloors a <code>DiscountFloorGroup</code> providing the value for discountFloors property.
     * @since 1.1
     */
    public void setDiscountFloors(DiscountFloorGroup discountFloors) {
        this.discountFloors = discountFloors;
    }

}

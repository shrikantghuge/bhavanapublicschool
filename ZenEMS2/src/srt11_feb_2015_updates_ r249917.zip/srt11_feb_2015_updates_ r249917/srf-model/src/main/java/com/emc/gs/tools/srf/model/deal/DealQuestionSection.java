/*
 * This code is copyright (c) 2014 EMC Corporation.
 */
package com.emc.gs.tools.srf.model.deal;

import java.util.List;

import com.emc.gs.tools.srf.model.LookupEntity;

/**
 * <p>
 * This is DealQuestionSection entity class.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safety.
 * </p>
 * 
 * @author TCSASSEMBLER
 * @version 1.0
 */
public class DealQuestionSection extends LookupEntity {

    /**
     * List of questions.
     */
    private List<DealQuestion> questions;

    /**
     * Empty constructor.
     */
    public DealQuestionSection() {
    }

    /**
     * Getter method for property <tt>questions</tt>.
     * 
     * @return property value of questions
     */
    public List<DealQuestion> getQuestions() {
        return questions;
    }

    /**
     * Setter method for property <tt>questions</tt>.
     * 
     * @param questions
     *            value to be assigned to property questions
     */
    public void setQuestions(List<DealQuestion> questions) {
        this.questions = questions;
    }

}

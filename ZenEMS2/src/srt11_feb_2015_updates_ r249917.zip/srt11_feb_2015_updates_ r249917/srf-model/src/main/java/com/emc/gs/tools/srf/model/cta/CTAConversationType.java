/*
 * This code is copyright (c) 2014 EMC Corporation
 */
package com.emc.gs.tools.srf.model.cta;

/**
 * The CTA conversation type enum.
 * <p>
 * <strong>Thread safety</strong>: Enum is thread safety.
 * </p>
 * 
 * @author TCSASSEMBLER
 * @version 1.0
 * @since SRT Phase 3-1 - CTA Rainfinity and MSS Tabs Update Assembly
 */
public enum CTAConversationType {

    /**
     * CFA.
     */
    CFA,

    /**
     * DX_NAS.
     */
    DX_NAS,
}

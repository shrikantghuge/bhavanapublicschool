/*
 * This code is copyright (c) 2014 EMC Corporation
 */
package com.emc.gs.tools.srf.model.dpad;

import com.emc.gs.tools.srf.model.IdentifiableEntity;

/**
 * <p>This is Mozy entity class.</p>
 *
 * <p><strong>Thread safety</strong>: This class is mutable, it is not thread safety.</p>
 *
 * @author TCSASSEMBLER
 * @version 1.0
 * @since SRT Phase 3 Pilot - Mozy and Xtrem and Vipr Tabs Assembly
 */
public class Mozy extends IdentifiableEntity {

    /**
     * <p>A <code>boolean</code> providing the value for Mozy Custom flag.</p>
     */
    private boolean mozyCustom;

    /**
     * <p>A <code>boolean</code> providing the value for Mozy OEM Branding flag.</p>
     */
    private boolean mozyOEMBranding;

    /**
     * <p>A <code>boolean</code> providing the value for Mozy Out Tasking flag.</p>
     */
    private boolean mozyOutTasking;

    /**
     * <p>A <code>MozyCustom</code> providing the Mozy Custom data.</p>
     */
    private MozyCustom custom;

    /**
     * <p>A <code>MozyOEMBranding</code> providing the Mozy OEM Branding data.</p>
     */
    private MozyOEMBranding oemBranding;

    /**
     * <p>A <code>MozyOutTasking</code> providing the Mozy Out Tasking data.</p>
     */
    private MozyOutTasking outTasking;

    /**
     * <p>Constructs new <code>Mozy</code> instance. This implementation does nothing.</p>
     */
    public Mozy() {
    }

    /**
     * <p>Gets the Mozy Out Tasking data.</p>
     *
     * @return a <code>MozyOutTasking</code> providing the Mozy Out Tasking data.
     */
    public MozyOutTasking getOutTasking() {
        return this.outTasking;
    }

    /**
     * <p>Sets the Mozy Out Tasking data.</p>
     *
     * @param outTasking a <code>MozyOutTasking</code> providing the Mozy Out Tasking data.
     */
    public void setOutTasking(MozyOutTasking outTasking) {
        this.outTasking = outTasking;
    }

    /**
     * <p>Gets the Mozy OEM Branding data.</p>
     *
     * @return a <code>MozyOEMBranding</code> providing the Mozy OEM Branding data.
     */
    public MozyOEMBranding getOemBranding() {
        return this.oemBranding;
    }

    /**
     * <p>Sets the Mozy OEM Branding data.</p>
     *
     * @param oemBranding a <code>MozyOEMBranding</code> providing the Mozy OEM Branding data.
     */
    public void setOemBranding(MozyOEMBranding oemBranding) {
        this.oemBranding = oemBranding;
    }

    /**
     * <p>Gets the Mozy Custom data.</p>
     *
     * @return a <code>MozyCustom</code> providing the Mozy Custom data.
     */
    public MozyCustom getCustom() {
        return this.custom;
    }

    /**
     * <p>Sets the Mozy Custom data.</p>
     *
     * @param custom a <code>MozyCustom</code> providing the Mozy Custom data.
     */
    public void setCustom(MozyCustom custom) {
        this.custom = custom;
    }

    /**
     * <p>Gets the value for Mozy Out Tasking flag.</p>
     *
     * @return a <code>boolean</code> providing the value for Mozy Out Tasking flag.
     */
    public boolean getMozyOutTasking() {
        return this.mozyOutTasking;
    }

    /**
     * <p>Sets the value for Mozy Out Tasking flag.</p>
     *
     * @param mozyOutTasking a <code>boolean</code> providing the value for Mozy Out Tasking flag.
     */
    public void setMozyOutTasking(boolean mozyOutTasking) {
        this.mozyOutTasking = mozyOutTasking;
    }

    /**
     * <p>Gets the value for Mozy OEM Branding flag.</p>
     *
     * @return a <code>boolean</code> providing the value for Mozy OEM Branding flag.
     */
    public boolean getMozyOEMBranding() {
        return this.mozyOEMBranding;
    }

    /**
     * <p>Sets the value for Mozy OEM Branding flag.</p>
     *
     * @param mozyOEMBranding a <code>boolean</code> providing the value for Mozy OEM Branding flag.
     */
    public void setMozyOEMBranding(boolean mozyOEMBranding) {
        this.mozyOEMBranding = mozyOEMBranding;
    }

    /**
     * <p>Gets the value for Mozy Custom flag.</p>
     *
     * @return a <code>boolean</code> providing the value for Mozy Custom flag.
     */
    public boolean getMozyCustom() {
        return this.mozyCustom;
    }

    /**
     * <p>Sets the value for Mozy Custom flag.</p>
     *
     * @param mozyCustom a <code>boolean</code> providing the value for Mozy Custom flag.
     */
    public void setMozyCustom(boolean mozyCustom) {
        this.mozyCustom = mozyCustom;
    }
}

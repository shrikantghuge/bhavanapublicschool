/*
 * This code is copyright (c) 2013 - 2014 EMC Corporation.
 */
package com.emc.gs.tools.srf.model.bc;

import com.emc.gs.tools.srf.model.IdentifiableEntity;

/**
 * <p>
 * This is BCServicesScope entity class.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safety.
 * </p>
 * 
 * <p>
 * <strong>Changes V1.1:</strong>
 * <ul>
 * <li>Removed migrationServices, autostart, replistor, srdfCe, mirrorViewCe fields.</li>
 * </ul>
 * </p>
 *
 * <p>
 * <strong>Changes V1.2:</strong>
 * <strong>SRT Phase 3-5 - BRS Tabs Part 1 Assembly</strong>
 * <ul>
 * <li>Remove recoverPoint field.</li>
 * </ul>
 * </p>
 *
 * <p>
 * Version 1.3 (SRT 4 OCT2014 Updates Part 1 Assembly) Change notes:
 *   <ol>
 *     <li>Removed <code>openReplicator</code> property.</li>
 *   </ol>
 * </p>
 *
 * @author faeton, stevenfrog, MonicaMuranyi, isv
 * @version 1.3
 */
public class BCServicesScope extends IdentifiableEntity {
    /**
     * <p>
     * The srdf.
     * </p>
     */
    private boolean srdf;

    /**
     * <p>
     * The timeFinder.
     * </p>
     */
    private boolean timeFinder;

    /**
     * <p>
     * The mirrowView.
     * </p>
     */
    private boolean mirrowView;

    /**
     * <p>
     * The snapView.
     * </p>
     */
    private boolean snapView;

    /**
     * <p>
     * The replicationServices.
     * </p>
     */
    private boolean replicationServices;

    /**
     * <p>
     * The default constructor.
     * </p>
     */
    public BCServicesScope() {
        // Empty
    }

    /**
     * <p>
     * Retrieves the srdf field.
     * </p>
     *
     * @return the srdf
     */
    public boolean isSrdf() {
        return srdf;
    }

    /**
     * <p>
     * Sets the value to srdf field.
     * </p>
     *
     * @param srdf
     *            the srdf to set
     */
    public void setSrdf(boolean srdf) {
        this.srdf = srdf;
    }

    /**
     * <p>
     * Retrieves the timeFinder field.
     * </p>
     *
     * @return the timeFinder
     */
    public boolean isTimeFinder() {
        return timeFinder;
    }

    /**
     * <p>
     * Sets the value to timeFinder field.
     * </p>
     *
     * @param timeFinder
     *            the timeFinder to set
     */
    public void setTimeFinder(boolean timeFinder) {
        this.timeFinder = timeFinder;
    }

    /**
     * <p>
     * Retrieves the mirrowView field.
     * </p>
     *
     * @return the mirrowView
     */
    public boolean isMirrowView() {
        return mirrowView;
    }

    /**
     * <p>
     * Sets the value to mirrowView field.
     * </p>
     *
     * @param mirrowView
     *            the mirrowView to set
     */
    public void setMirrowView(boolean mirrowView) {
        this.mirrowView = mirrowView;
    }

    /**
     * <p>
     * Retrieves the snapView field.
     * </p>
     *
     * @return the snapView
     */
    public boolean isSnapView() {
        return snapView;
    }

    /**
     * <p>
     * Sets the value to snapView field.
     * </p>
     *
     * @param snapView
     *            the snapView to set
     */
    public void setSnapView(boolean snapView) {
        this.snapView = snapView;
    }

    /**
     * <p>
     * Retrieves the replicationServices field.
     * </p>
     *
     * @return the replicationServices
     */
    public boolean isReplicationServices() {
        return replicationServices;
    }

    /**
     * <p>
     * Sets the value to replicationServices field.
     * </p>
     *
     * @param replicationServices
     *            the replicationServices to set
     */
    public void setReplicationServices(boolean replicationServices) {
        this.replicationServices = replicationServices;
    }
    
    /**
     * The toString method.
     *
     * @return the string for this entity
     */
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("{").append(super.toString());
        sb.append(", srdf:").append(srdf);
        sb.append(", timeFinder:").append(timeFinder);
        sb.append(", mirrowView:").append(mirrowView);
        sb.append(", snapView:").append(snapView);
        sb.append(", replicationServices:").append(replicationServices).append("}");
        return sb.toString();
    }
}

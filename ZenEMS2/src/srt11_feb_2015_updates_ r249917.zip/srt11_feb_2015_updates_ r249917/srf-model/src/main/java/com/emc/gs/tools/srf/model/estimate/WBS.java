/*
 * This code is copyright (c) 2014 EMC Corporation.
 */
package com.emc.gs.tools.srf.model.estimate;

/**
 * <p>
 * This is WBS entity class.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safety.
 * </p>
 * 
 * @author TCSASSEMBLER
 * @version 1.0
 * @since SRT Phase 4 - ET Assembly 1
 */
public class WBS {

    /**
     * WBS Number.
     */
    private String wbsNumber;

    /**
     * Sales Order Item Number.
     */
    private String salesOrderItemNumber;

    /**
     * Expense WBS Number.
     */
    private String expenseWBSNumber;

    /**
     * Expense Sales Order Item Number.
     */
    private String expenseSalesOrderItemNumber;

    /**
     * Empty constructor.
     */
    public WBS() {
    }

    /**
     * Getter method for property <tt>wbsNumber</tt>.
     * 
     * @return property value of wbsNumber
     */
    public String getWbsNumber() {
        return wbsNumber;
    }

    /**
     * Setter method for property <tt>wbsNumber</tt>.
     * 
     * @param wbsNumber
     *            value to be assigned to property wbsNumber
     */
    public void setWbsNumber(String wbsNumber) {
        this.wbsNumber = wbsNumber;
    }

    /**
     * Getter method for property <tt>salesOrderItemNumber</tt>.
     * 
     * @return property value of salesOrderItemNumber
     */
    public String getSalesOrderItemNumber() {
        return salesOrderItemNumber;
    }

    /**
     * Setter method for property <tt>salesOrderItemNumber</tt>.
     * 
     * @param salesOrderItemNumber
     *            value to be assigned to property salesOrderItemNumber
     */
    public void setSalesOrderItemNumber(String salesOrderItemNumber) {
        this.salesOrderItemNumber = salesOrderItemNumber;
    }

    /**
     * Getter method for property <tt>expenseWBSNumber</tt>.
     * 
     * @return property value of expenseWBSNumber
     */
    public String getExpenseWBSNumber() {
        return expenseWBSNumber;
    }

    /**
     * Setter method for property <tt>expenseWBSNumber</tt>.
     * 
     * @param expenseWBSNumber
     *            value to be assigned to property expenseWBSNumber
     */
    public void setExpenseWBSNumber(String expenseWBSNumber) {
        this.expenseWBSNumber = expenseWBSNumber;
    }

    /**
     * Getter method for property <tt>expenseSalesOrderItemNumber</tt>.
     * 
     * @return property value of expenseSalesOrderItemNumber
     */
    public String getExpenseSalesOrderItemNumber() {
        return expenseSalesOrderItemNumber;
    }

    /**
     * Setter method for property <tt>expenseSalesOrderItemNumber</tt>.
     * 
     * @param expenseSalesOrderItemNumber
     *            value to be assigned to property expenseSalesOrderItemNumber
     */
    public void setExpenseSalesOrderItemNumber(String expenseSalesOrderItemNumber) {
        this.expenseSalesOrderItemNumber = expenseSalesOrderItemNumber;
    }

}

/*
 * This code is copyright (c) 2014 EMC Corporation.
 */
package com.emc.gs.tools.srf.model.deal;

/**
 * <p>
 * This is DealAnswer entity class.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safety.
 * </p>
 * 
 * @author TCSASSEMBLER
 * @version 1.0
 * @since SRT Phase 4 - ET Assembly 1
 */
public class DealAnswer {

    /**
     * The Yes/No answer.
     */
    private Boolean yesNo;

    /**
     * The comment.
     */
    private String comment;

    /**
     * Empty constructor.
     */
    public DealAnswer() {
    }

    /**
     * Getter method for property <tt>yesNo</tt>.
     * 
     * @return property value of yesNo
     */
    public Boolean getYesNo() {
        return yesNo;
    }

    /**
     * Setter method for property <tt>yesNo</tt>.
     * 
     * @param yesNo
     *            value to be assigned to property yesNo
     */
    public void setYesNo(Boolean yesNo) {
        this.yesNo = yesNo;
    }

    /**
     * Getter method for property <tt>comment</tt>.
     * 
     * @return property value of comment
     */
    public String getComment() {
        return comment;
    }

    /**
     * Setter method for property <tt>comment</tt>.
     * 
     * @param comment
     *            value to be assigned to property comment
     */
    public void setComment(String comment) {
        this.comment = comment;
    }

}

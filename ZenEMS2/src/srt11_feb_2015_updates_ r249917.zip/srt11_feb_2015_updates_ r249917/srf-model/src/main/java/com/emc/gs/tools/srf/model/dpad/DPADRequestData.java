/*
 * This code is copyright (c) 2014 EMC Corporation
 */
package com.emc.gs.tools.srf.model.dpad;

import com.emc.gs.tools.srf.model.IdentifiableEntity;

/**
 * <p>
 * This is DPADRequestData entity class.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safety.
 * </p>
 *
 * <p>
 * <strong>Changes V1.1:</strong>
 * <strong>SRT Phase 3-5 - BRS Tabs Part 2 Assembly</strong>
 * <ul>
 * <li>Add dataDomain/dpa fields.</li>
 * </ul>
 * </p>
 *
 * <p>
 * <strong>Changes V1.2:</strong>
 * <strong>SRT Phase 3-5 - BRS Tabs Part 3 Assembly</strong>
 * <ul>
 * <li>Add networker field.</li>
 * </ul>
 * </p>
 *
 * <p>
 * Version 1.3 (SRT Phase 3 Pilot - Mozy and Xtrem and Vipr Tabs Assembly) Change notes:
 *   <ol>
 *     <li>Added {@link #mozy} property.</li>
 *   </ol>
 * </p>
 *
 * <p>
 * Version 1.4 Change notes:
 *   <ol>
 *     <li>Removed <code>vplex</code> property.</li>
 *   </ol>
 * </p>
 * 
 * @author TCSASSEMBLER
 * @version 1.4
 * @since SRT Phase 3-5 - BRS Tabs Part 1 Assembly
 */
public class DPADRequestData extends IdentifiableEntity {

    /**
     * # of sites involved?
     */
    private String sitesInvolved;

    /**
     * General Comments.
     */
    private String generalComments;

    /**
     * Services scoped.
     */
    private DPADServicesScope servicesScope;

    /**
     * Avamar.
     */
    private Avamar avamar;

    /**
     * EMC Disk Library.
     */
    private EDL edl;

    /**
     * RecoverPoint;
     */
    private RecoverPoint recoverPoint;

    /**
     * Data Domain.
     * @since SRT Phase 3-5 - BRS Tabs Part 2 Assembly
     */
    private DataDomain dataDomain;

    /**
     * Data Protection Advisor.
     * @since SRT Phase 3-5 - BRS Tabs Part 2 Assembly
     */
    private DPA dpa;

    /**
     * Networker.
     * @since SRT Phase 3-5 - BRS Tabs Part 3 Assembly
     */
    private Networker networker;

    /**
     * <p>A <code>Mozy</code> providing the data for Mozy tab.</p>
     * 
     * @since 1.3
     */
    private Mozy mozy;

    /**
     * <p>
     * The default constructor.
     * </p>
     */
    public DPADRequestData() {
    }

    /**
     * Getter method for property <tt>sitesInvolved</tt>.
     * 
     * @return property value of sitesInvolved
     */
    public String getSitesInvolved() {
        return sitesInvolved;
    }

    /**
     * Setter method for property <tt>sitesInvolved</tt>.
     * 
     * @param sitesInvolved
     *            value to be assigned to property sitesInvolved
     */
    public void setSitesInvolved(String sitesInvolved) {
        this.sitesInvolved = sitesInvolved;
    }

    /**
     * Getter method for property <tt>generalComments</tt>.
     * 
     * @return property value of generalComments
     */
    public String getGeneralComments() {
        return generalComments;
    }

    /**
     * Setter method for property <tt>generalComments</tt>.
     * 
     * @param generalComments
     *            value to be assigned to property generalComments
     */
    public void setGeneralComments(String generalComments) {
        this.generalComments = generalComments;
    }

    /**
     * Getter method for property <tt>servicesScope</tt>.
     * 
     * @return property value of servicesScope
     */
    public DPADServicesScope getServicesScope() {
        return servicesScope;
    }

    /**
     * Setter method for property <tt>servicesScope</tt>.
     * 
     * @param servicesScope
     *            value to be assigned to property servicesScope
     */
    public void setServicesScope(DPADServicesScope servicesScope) {
        this.servicesScope = servicesScope;
    }

    /**
     * Getter method for property <tt>avamar</tt>.
     * 
     * @return property value of avamar
     */
    public Avamar getAvamar() {
        return avamar;
    }

    /**
     * Setter method for property <tt>avamar</tt>.
     * 
     * @param avamar
     *            value to be assigned to property avamar
     */
    public void setAvamar(Avamar avamar) {
        this.avamar = avamar;
    }

    /**
     * Getter method for property <tt>recoverPoint</tt>.
     * 
     * @return property value of recoverPoint
     */
    public RecoverPoint getRecoverPoint() {
        return recoverPoint;
    }

    /**
     * Setter method for property <tt>recoverPoint</tt>.
     * 
     * @param recoverPoint
     *            value to be assigned to property recoverPoint
     */
    public void setRecoverPoint(RecoverPoint recoverPoint) {
        this.recoverPoint = recoverPoint;
    }

    /**
     * Getter method for property <tt>edl</tt>.
     * 
     * @return property value of edl
     */
    public EDL getEdl() {
        return edl;
    }

    /**
     * Setter method for property <tt>edl</tt>.
     * 
     * @param edl
     *            value to be assigned to property edl
     */
    public void setEdl(EDL edl) {
        this.edl = edl;
    }

    /**
     * Getter method for property <tt>dataDomain</tt>.
     * 
     * @return property value of dataDomain
     * @since SRT Phase 3-5 - BRS Tabs Part 2 Assembly
     */
    public DataDomain getDataDomain() {
        return dataDomain;
    }

    /**
     * Setter method for property <tt>dataDomain</tt>.
     * 
     * @param dataDomain
     *            value to be assigned to property dataDomain
     * @since SRT Phase 3-5 - BRS Tabs Part 2 Assembly
     */
    public void setDataDomain(DataDomain dataDomain) {
        this.dataDomain = dataDomain;
    }

    /**
     * Getter method for property <tt>dpa</tt>.
     * 
     * @return property value of dpa
     * @since SRT Phase 3-5 - BRS Tabs Part 2 Assembly
     */
    public DPA getDpa() {
        return dpa;
    }

    /**
     * Setter method for property <tt>dpa</tt>.
     * 
     * @param dpa
     *            value to be assigned to property dpa
     * @since SRT Phase 3-5 - BRS Tabs Part 2 Assembly
     */
    public void setDpa(DPA dpa) {
        this.dpa = dpa;
    }

    /**
     * Getter method for property <tt>networker</tt>.
     * 
     * @return property value of networker
     * @since SRT Phase 3-5 - BRS Tabs Part 3 Assembly
     */
    public Networker getNetworker() {
        return networker;
    }

    /**
     * Setter method for property <tt>networker</tt>.
     * 
     * @param networker
     *            value to be assigned to property networker
     * @since SRT Phase 3-5 - BRS Tabs Part 3 Assembly
     */
    public void setNetworker(Networker networker) {
        this.networker = networker;
    }

    /**
     * <p>Gets the data for Mozy tab.</p>
     *
     * @return a <code>Mozy</code> providing the data for Mozy tab.
     * @since 1.3
     */
    public Mozy getMozy() {
        return this.mozy;
    }

    /**
     * <p>Sets the data for Mozy tab.</p>
     *
     * @param mozy a <code>Mozy</code> providing the data for Mozy tab.
     * @since 1.3
     */
    public void setMozy(Mozy mozy) {
        this.mozy = mozy;
    }

}

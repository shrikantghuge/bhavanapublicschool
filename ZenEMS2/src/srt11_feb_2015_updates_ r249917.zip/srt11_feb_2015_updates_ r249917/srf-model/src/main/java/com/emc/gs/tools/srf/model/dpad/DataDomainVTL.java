/*
 * This code is copyright (c) 2014 EMC Corporation
 */
package com.emc.gs.tools.srf.model.dpad;

import com.emc.gs.tools.srf.model.IdentifiableEntity;

/**
 * <p>
 * This is DataDomainVTL entity class.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safety.
 * </p>
 * 
 * @author TCSASSEMBLER
 * @version 1.0
 * @since SRT Phase 3-5 - BRS Tabs Part 2 Assembly
 */
public class DataDomainVTL extends IdentifiableEntity {

    /**
     * Include IBM iSeries BRMS Integration.
     */
    private Boolean includeIBMiseriesBRMS;

    /**
     * # of IBM i PARs for Backup Configuration.
     */
    private Integer ibmPARsNum;

    /**
     * # of Data Domain Appliances for VTL.
     */
    private Integer vtlAppliancesNum;

    /**
     * # of Data Domain Fibre Cards to install.
     */
    private Integer installFibreCardsNum;

    /**
     * # of Data Domain Emulated VTLs to Create.
     */
    private Integer createVTLsNum;

    /**
     * <p>
     * The default constructor.
     * </p>
     */
    public DataDomainVTL() {
    }

    /**
     * Getter method for property <tt>includeIBMiseriesBRMS</tt>.
     * 
     * @return property value of includeIBMiseriesBRMS
     */
    public Boolean getIncludeIBMiseriesBRMS() {
        return includeIBMiseriesBRMS;
    }

    /**
     * Setter method for property <tt>includeIBMiseriesBRMS</tt>.
     * 
     * @param includeIBMiseriesBRMS
     *            value to be assigned to property includeIBMiseriesBRMS
     */
    public void setIncludeIBMiseriesBRMS(Boolean includeIBMiseriesBRMS) {
        this.includeIBMiseriesBRMS = includeIBMiseriesBRMS;
    }

    /**
     * Getter method for property <tt>ibmPARsNum</tt>.
     * 
     * @return property value of ibmPARsNum
     */
    public Integer getIbmPARsNum() {
        return ibmPARsNum;
    }

    /**
     * Setter method for property <tt>ibmPARsNum</tt>.
     * 
     * @param ibmPARsNum
     *            value to be assigned to property ibmPARsNum
     */
    public void setIbmPARsNum(Integer ibmPARsNum) {
        this.ibmPARsNum = ibmPARsNum;
    }

    /**
     * Getter method for property <tt>vtlAppliancesNum</tt>.
     * 
     * @return property value of vtlAppliancesNum
     */
    public Integer getVtlAppliancesNum() {
        return vtlAppliancesNum;
    }

    /**
     * Setter method for property <tt>vtlAppliancesNum</tt>.
     * 
     * @param vtlAppliancesNum
     *            value to be assigned to property vtlAppliancesNum
     */
    public void setVtlAppliancesNum(Integer vtlAppliancesNum) {
        this.vtlAppliancesNum = vtlAppliancesNum;
    }

    /**
     * Getter method for property <tt>installFibreCardsNum</tt>.
     * 
     * @return property value of installFibreCardsNum
     */
    public Integer getInstallFibreCardsNum() {
        return installFibreCardsNum;
    }

    /**
     * Setter method for property <tt>installFibreCardsNum</tt>.
     * 
     * @param installFibreCardsNum
     *            value to be assigned to property installFibreCardsNum
     */
    public void setInstallFibreCardsNum(Integer installFibreCardsNum) {
        this.installFibreCardsNum = installFibreCardsNum;
    }

    /**
     * Getter method for property <tt>createVTLsNum</tt>.
     * 
     * @return property value of createVTLsNum
     */
    public Integer getCreateVTLsNum() {
        return createVTLsNum;
    }

    /**
     * Setter method for property <tt>createVTLsNum</tt>.
     * 
     * @param createVTLsNum
     *            value to be assigned to property createVTLsNum
     */
    public void setCreateVTLsNum(Integer createVTLsNum) {
        this.createVTLsNum = createVTLsNum;
    }

}

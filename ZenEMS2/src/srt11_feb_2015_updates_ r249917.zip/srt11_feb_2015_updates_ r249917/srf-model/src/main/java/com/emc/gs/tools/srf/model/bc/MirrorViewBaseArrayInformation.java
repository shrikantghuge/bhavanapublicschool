/*
 * This code is copyright (c) 2014 EMC Corporation.
 */
package com.emc.gs.tools.srf.model.bc;


/**
 * <p>
 * This is base array information for MirrorViewSourceArrayInformation and MirrorViewTargetArrayInformation entity.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safety.
 * </p>
 * 
 * <p>
 * <strong>Changes V1.1:</strong>
 * <ul>
 * <li>Removed flarecodeFamily, currentMvMode, newMvMode fields.</li>
 * </ul>
 * </p>
 *
 * @author faeton, TCSASSEMBLER, MonicaMuranyi
 * @version 1.1
 * @since SRT Release Assembly - BC Tab
 */
public abstract class MirrorViewBaseArrayInformation {
    /**
     * <p>
     * The arrayModel.
     * </p>
     */
    private ArrayModel arrayModel;

    /**
     * <p>
     * The existingOptionEnabled.
     * </p>
     */
    private Boolean existingOptionEnabled;

    /**
     * <p>
     * The mirrowViewInstalledStatus.
     * </p>
     */
    private Boolean mirrowViewInstalledStatus;

    /**
     * Empty constructor.
     */
    public MirrorViewBaseArrayInformation() {
    }

    /**
     * Getter method for property <tt>arrayModel</tt>.
     * @return property value of arrayModel
     */
    public ArrayModel getArrayModel() {
        return arrayModel;
    }

    /**
     * Getter method for property <tt>existingOptionEnabled</tt>.
     * @return property value of existingOptionEnabled
     */
    public Boolean getExistingOptionEnabled() {
        return existingOptionEnabled;
    }

    /**
     * Getter method for property <tt>mirrowViewInstalledStatus</tt>.
     * @return property value of mirrowViewInstalledStatus
     */
    public Boolean getMirrowViewInstalledStatus() {
        return mirrowViewInstalledStatus;
    }

    /**
     * Setter method for property <tt>arrayModel</tt>.
     * @param arrayModel value to be assigned to property arrayModel
     */
    public void setArrayModel(ArrayModel arrayModel) {
        this.arrayModel = arrayModel;
    }

    /**
     * Setter method for property <tt>existingOptionEnabled</tt>.
     * @param existingOptionEnabled value to be assigned to property existingOptionEnabled
     */
    public void setExistingOptionEnabled(Boolean existingOptionEnabled) {
        this.existingOptionEnabled = existingOptionEnabled;
    }

    /**
     * Setter method for property <tt>mirrowViewInstalledStatus</tt>.
     * @param mirrowViewInstalledStatus value to be assigned to property mirrowViewInstalledStatus
     */
    public void setMirrowViewInstalledStatus(Boolean mirrowViewInstalledStatus) {
        this.mirrowViewInstalledStatus = mirrowViewInstalledStatus;
    }

    /**
     * The toString method.
     *
     * @return the string for this entity
     */
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("arrayModel:").append(arrayModel);
        sb.append(", mirrowViewInstalledStatus:").append(mirrowViewInstalledStatus);
        sb.append(", existingOptionEnabled:").append(existingOptionEnabled);
        return sb.toString();
    }
}

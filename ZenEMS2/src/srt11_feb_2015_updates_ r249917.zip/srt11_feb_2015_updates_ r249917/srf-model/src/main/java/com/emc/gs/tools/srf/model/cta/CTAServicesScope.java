/*
 * This code is copyright (c) 2014 EMC Corporation
 */
package com.emc.gs.tools.srf.model.cta;

import com.emc.gs.tools.srf.model.IdentifiableEntity;

/**
 * <p>
 * This is CTAServicesScope entity class.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safety.
 * </p>
 * <p>
 * <strong>Changes V1.1:</strong> <strong>SRT Phase 3-1 - CTA Rainfinity and MSS Tabs Update Assembly</strong>
 * <ul>
 * <li>Remove rainfinityImplementation/rainfinityMigration fields.</li>
 * <li>Add ctaDesignAndImplementation/ctaImplementation/ctaConversion/rainfinityDesignAndImplementation fields.</li>
 * </ul>
 * </p>
 * 
 * @author TCSASSEMBLER
 * @version 1.1
 * @since SRT Phase 3-1 - CTA Rainfinity and MSS Tabs Assembly
 */
public class CTAServicesScope extends IdentifiableEntity {

    /**
     * Design and Implementation of CTA.
     */
    private boolean ctaDesignAndImplementation;

    /**
     * Implementation of CTA.
     */
    private boolean ctaImplementation;

    /**
     * Conversion for CTA.
     */
    private boolean ctaConversion;

    /**
     * Rainfinity: Design & Imp for File Virtualization Appliance.
     */
    private boolean rainfinityDesignAndImplementation;

    /**
     * <p>
     * The default constructor.
     * </p>
     */
    public CTAServicesScope() {
    }

    /**
     * Getter method for property <tt>ctaDesignAndImplementation</tt>.
     * 
     * @return property value of ctaDesignAndImplementation
     */
    public boolean isCtaDesignAndImplementation() {
        return ctaDesignAndImplementation;
    }

    /**
     * Setter method for property <tt>ctaDesignAndImplementation</tt>.
     * 
     * @param ctaDesignAndImplementation
     *            value to be assigned to property ctaDesignAndImplementation
     */
    public void setCtaDesignAndImplementation(boolean ctaDesignAndImplementation) {
        this.ctaDesignAndImplementation = ctaDesignAndImplementation;
    }

    /**
     * Getter method for property <tt>ctaImplementation</tt>.
     * 
     * @return property value of ctaImplementation
     */
    public boolean isCtaImplementation() {
        return ctaImplementation;
    }

    /**
     * Setter method for property <tt>ctaImplementation</tt>.
     * 
     * @param ctaImplementation
     *            value to be assigned to property ctaImplementation
     */
    public void setCtaImplementation(boolean ctaImplementation) {
        this.ctaImplementation = ctaImplementation;
    }

    /**
     * Getter method for property <tt>ctaConversion</tt>.
     * 
     * @return property value of ctaConversion
     */
    public boolean isCtaConversion() {
        return ctaConversion;
    }

    /**
     * Setter method for property <tt>ctaConversion</tt>.
     * 
     * @param ctaConversion
     *            value to be assigned to property ctaConversion
     */
    public void setCtaConversion(boolean ctaConversion) {
        this.ctaConversion = ctaConversion;
    }

    /**
     * Getter method for property <tt>rainfinityDesignAndImplementation</tt>.
     * 
     * @return property value of rainfinityDesignAndImplementation
     */
    public boolean isRainfinityDesignAndImplementation() {
        return rainfinityDesignAndImplementation;
    }

    /**
     * Setter method for property <tt>rainfinityDesignAndImplementation</tt>.
     * 
     * @param rainfinityDesignAndImplementation
     *            value to be assigned to property rainfinityDesignAndImplementation
     */
    public void setRainfinityDesignAndImplementation(boolean rainfinityDesignAndImplementation) {
        this.rainfinityDesignAndImplementation = rainfinityDesignAndImplementation;
    }

}

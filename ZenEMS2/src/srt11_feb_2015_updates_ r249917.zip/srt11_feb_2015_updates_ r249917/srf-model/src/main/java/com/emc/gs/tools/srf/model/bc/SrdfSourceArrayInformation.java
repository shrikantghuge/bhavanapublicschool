/*
 * This code is copyright (c) 2014 EMC Corporation.
 */
package com.emc.gs.tools.srf.model.bc;


/**
 * <p>
 * This is source array information for SrdfInformation entity.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safety.
 * </p>
 * 
 * <p>
 * <strong>Changes V1.1:</strong>
 * <ul>
 * <li>Removed targetName field.</li>
 * </ul>
 * </p>
 * 
 * <p>
 * <strong>Changes V1.2:</strong>
 * <strong>https://apps.topcoder.com/bugs/browse/SRT-35</strong>
 * <ul>
 * <li>Added nrOfRDFPairs, nrOfRDFGroups fields.</li>
 * </ul>
 * </p>
 *
 * <p>
 * Version 1.3 (SRT 4 OCT2014 Updates Part 1 Assembly) Change notes:
 *   <ol>
 *     <li>Added {@link #numOfSymmetrixRDFSourceDevices} property.</li>
 *     <li>Added {@link #numOfSymmetrixDevicesNeededAtRDFRemoteSites} property.</li>
 *   </ol>
 * </p>
 *
 * @author faeton, MonicaMuranyi, isv
 * @version 1.3
 * @since SRT Release Assembly - BC Tab
 */
public class SrdfSourceArrayInformation extends SrdfBaseArrayInformation {

    /**
     * <p>
     * The replicateSize.
     * </p>
     */
    private Integer replicateSize;

    /**
     * <p>A <code>Integer</code> providing the value for "Number of Symmetrix RDF Source Devices" property.</p>
     *
     * @since 1.3
     */
    private Integer numOfSymmetrixRDFSourceDevices;

    /**
     * <p>A <code>Integer</code> providing the value for "Number of Symmetrix Devices Needed at RDF Remote Sites"
     * property.</p>
     *
     * @since 1.3
     */
    private Integer numOfSymmetrixDevicesNeededAtRDFRemoteSites;

    /**
     * <p>
     * The uniOptionEnabled.
     * </p>
     */
    private Boolean uniOptionEnabled;

    /**
     * <p>
     * The srdfConnectionType.
     * </p>
     */
    private SrdfConnectionType srdfConnectionType;
    
    /**
     * <p>
     * The nrOfRDFPairs.
     * </p>
     */
    private Integer nrOfRDFPairs;
    
    /**
     * <p>
     * The nrOfRDFGroups.
     * </p>
     */
    private Integer nrOfRDFGroups;

    /**
     * Empty constructor.
     */
    public SrdfSourceArrayInformation() {
    }

    /**
     * Getter method for property <tt>replicateSize</tt>.
     * @return property value of replicateSize
     */
    public Integer getReplicateSize() {
        return replicateSize;
    }

    /**
     * Getter method for property <tt>uniOptionEnabled</tt>.
     * @return property value of uniOptionEnabled
     */
    public Boolean getUniOptionEnabled() {
        return uniOptionEnabled;
    }

    /**
     * Getter method for property <tt>srdfConnectionType</tt>.
     * @return property value of srdfConnectionType
     */
    public SrdfConnectionType getSrdfConnectionType() {
        return srdfConnectionType;
    }

    /**
     * Setter method for property <tt>replicateSize</tt>.
     * @param replicateSize value to be assigned to property replicateSize
     */
    public void setReplicateSize(Integer replicateSize) {
        this.replicateSize = replicateSize;
    }

    /**
     * Setter method for property <tt>uniOptionEnabled</tt>.
     * @param uniOptionEnabled value to be assigned to property uniOptionEnabled
     */
    public void setUniOptionEnabled(Boolean uniOptionEnabled) {
        this.uniOptionEnabled = uniOptionEnabled;
    }

    /**
     * Setter method for property <tt>srdfConnectionType</tt>.
     * @param srdfConnectionType value to be assigned to property srdfConnectionType
     */
    public void setSrdfConnectionType(SrdfConnectionType srdfConnectionType) {
        this.srdfConnectionType = srdfConnectionType;
    }
    
    /**
     * Getter method for property <tt>nrOfRDFPairs</tt>.
     * @return property value of nrOfRDFPairs
     */
    public Integer getNrOfRDFPairs() {
        return nrOfRDFPairs;
    }

    /**
     * Setter method for property <tt>nrOfRDFPairs</tt>.
     * @param nrOfRDFPairs value to be assigned to property nrOfRDFPairs
     */
    public void setNrOfRDFPairs(Integer nrOfRDFPairs) {
        this.nrOfRDFPairs = nrOfRDFPairs;
    }

    /**
     * Getter method for property <tt>nrOfRDFGroups</tt>.
     * @return property value of nrOfRDFGroups
     */
    public Integer getNrOfRDFGroups() {
        return nrOfRDFGroups;
    }

    /**
     * Setter method for property <tt>nrOfRDFGroups</tt>.
     * @param nrOfRDFGroups value to be assigned to property nrOfRDFGroups
     */
    public void setNrOfRDFGroups(Integer nrOfRDFGroups) {
        this.nrOfRDFGroups = nrOfRDFGroups;
    }

    /**
     * <p>Gets the "Number of Symmetrix RDF Source Devices" property.</p>
     *
     * @return a <code>Integer</code> providing the value for "Number of Symmetrix RDF Source Devices" property.
     * @since 1.3
     */
    public Integer getNumOfSymmetrixRDFSourceDevices() {
        return this.numOfSymmetrixRDFSourceDevices;
    }

    /**
     * <p>Sets the "Number of Symmetrix RDF Source Devices" property.</p>
     *
     * @param numOfSymmetrixRDFSourceDevices a <code>Integer</code> providing the value for "Number of Symmetrix RDF
     * Source Devices" property.
     * @since 1.3
     */
    public void setNumOfSymmetrixRDFSourceDevices(Integer numOfSymmetrixRDFSourceDevices) {
        this.numOfSymmetrixRDFSourceDevices = numOfSymmetrixRDFSourceDevices;
    }

    /**
     * <p>Gets the "Number of Symmetrix Devices Needed at RDF Remote Sites" property.</p>
     *
     * @return a <code>Integer</code> providing the value for "Number of Symmetrix Devices Needed at RDF Remote Sites"
     * property.
     * @since 1.3
     */
    public Integer getNumOfSymmetrixDevicesNeededAtRDFRemoteSites() {
        return this.numOfSymmetrixDevicesNeededAtRDFRemoteSites;
    }

    /**
     * <p>Sets the "Number of Symmetrix Devices Needed at RDF Remote Sites" property.</p>
     *
     * @param numOfSymmetrixDevicesNeededAtRDFRemoteSites a <code>Integer</code> providing the value for "Number of
     * Symmetrix Devices Needed at RDF Remote Sites" property.
     * @since 1.3
     */
    public void setNumOfSymmetrixDevicesNeededAtRDFRemoteSites(Integer numOfSymmetrixDevicesNeededAtRDFRemoteSites) {
        this.numOfSymmetrixDevicesNeededAtRDFRemoteSites = numOfSymmetrixDevicesNeededAtRDFRemoteSites;
    }

    /**
     * The toString method.
     *
     * @return the string for this entity
     */
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("{").append(super.toString());
        sb.append(", replicateSize:").append(replicateSize);
        sb.append(", numOfSymmetrixRDFSourceDevices:").append(numOfSymmetrixRDFSourceDevices);
        sb.append(", numOfSymmetrixDevicesNeededAtRDFRemoteSites:").append(numOfSymmetrixDevicesNeededAtRDFRemoteSites);
        sb.append(", uniOptionEnabled:").append(uniOptionEnabled);
        sb.append(", nrOfRDFPairs:").append(nrOfRDFPairs);
        sb.append(", nrOfRDFGroups:").append(nrOfRDFGroups);
        sb.append(", srdfConnectionType:").append(srdfConnectionType).append("}");
        return sb.toString();
    }

}

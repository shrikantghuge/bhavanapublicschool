/*
 * This code is copyright (c) 2014 EMC Corporation
 */
package com.emc.gs.tools.srf.model.dpad;

import com.emc.gs.tools.srf.model.IdentifiableEntity;

/**
 * <p>
 * This is DataDomainManagementCenterConfig entity class.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safety.
 * </p>
 * 
 * @author TCSASSEMBLER
 * @version 1.0
 * @since SRT Phase 3-5 - BRS Tabs Part 2 Assembly
 */
public class DataDomainManagementCenterConfig extends IdentifiableEntity {

    /**
     * Select the type of DDMC Deployment Configuration the Cus.
     */
    private DataDomainManagementCenterConfigType managementCenterConfigType;

    /**
     * <p>
     * The default constructor.
     * </p>
     */
    public DataDomainManagementCenterConfig() {
    }

    /**
     * Getter method for property <tt>managementCenterConfigType</tt>.
     * 
     * @return property value of managementCenterConfigType
     */
    public DataDomainManagementCenterConfigType getManagementCenterConfigType() {
        return managementCenterConfigType;
    }

    /**
     * Setter method for property <tt>managementCenterConfigType</tt>.
     * 
     * @param managementCenterConfigType
     *            value to be assigned to property managementCenterConfigType
     */
    public void setManagementCenterConfigType(DataDomainManagementCenterConfigType managementCenterConfigType) {
        this.managementCenterConfigType = managementCenterConfigType;
    }

}

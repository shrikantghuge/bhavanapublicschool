/*
 * This code is copyright (c) 2014 EMC Corporation.
 */
package com.emc.gs.tools.srf.model.estimate;

import java.util.Map;

import com.emc.gs.tools.srf.model.LookupCodeEntity;

/**
 * <p>
 * This is LOBLookupData entity class.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safety.
 * </p>
 * 
 * @author TCSASSEMBLER
 * @version 1.0
 * @since SRT Phase 4 - ET Assembly 1
 */
public class LOBLookupData extends LookupCodeEntity {

    /**
     * The map of counties of this LOB.
     */
    private Map<String, LOBCountry> countries;

    /**
     * The map of material codes of this LOB.
     */
    private Map<Long, MaterialCodeLookupData> materialCodes;

    /**
     * Empty constructor.
     */
    public LOBLookupData() {
    }

    /**
     * Getter method for property <tt>countries</tt>.
     * 
     * @return property value of countries
     */
    public Map<String, LOBCountry> getCountries() {
        return countries;
    }

    /**
     * Setter method for property <tt>countries</tt>.
     * 
     * @param countries
     *            value to be assigned to property countries
     */
    public void setCountries(Map<String, LOBCountry> countries) {
        this.countries = countries;
    }

    /**
     * Getter method for property <tt>materialCodes</tt>.
     * 
     * @return property value of materialCodes
     */
    public Map<Long, MaterialCodeLookupData> getMaterialCodes() {
        return materialCodes;
    }

    /**
     * Setter method for property <tt>materialCodes</tt>.
     * 
     * @param materialCodes
     *            value to be assigned to property materialCodes
     */
    public void setMaterialCodes(Map<Long, MaterialCodeLookupData> materialCodes) {
        this.materialCodes = materialCodes;
    }

}

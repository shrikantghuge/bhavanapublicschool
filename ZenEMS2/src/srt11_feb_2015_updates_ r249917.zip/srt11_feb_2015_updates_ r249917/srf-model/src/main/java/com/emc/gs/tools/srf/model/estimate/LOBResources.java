/*
 * This code is copyright (c) 2014 EMC Corporation.
 */
package com.emc.gs.tools.srf.model.estimate;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import com.emc.gs.tools.srf.model.IdentifiableEntity;

/**
 * <p>
 * This is LOBResources entity class.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safety.
 * </p>
 * 
 * @author TCSASSEMBLER
 * @version 1.0
 * @since SRT Phase 4 - ET Assembly 1
 */
public class LOBResources extends IdentifiableEntity {

    /**
     * The selected LOB.
     */
    private LOB lob;

    /**
     * The selected material code.
     */
    private MaterialCode materialCode;

    /**
     * The selected competency.
     */
    private Competency competency;

    /**
     * The selected billing type.
     */
    private BillingType billingType;

    /**
     * The number of months.
     */
    private Integer monthsNum;

    /**
     * The list of resources.
     */
    private List<LOBResource> resources = new ArrayList<LOBResource>();

    /**
     * The expense amount.
     */
    private BigDecimal expenseAmount;

    /**
     * The discount percent.
     */
    private BigDecimal discountPercent;

    /**
     * The discount amount.
     */
    private BigDecimal discountAmount;

    /**
     * The WBS numbers data.
     */
    private WBS wbs;

    /**
     * Empty constructor.
     */
    public LOBResources() {
    }

    /**
     * Getter method for property <tt>lob</tt>.
     * 
     * @return property value of lob
     */
    public LOB getLob() {
        return lob;
    }

    /**
     * Setter method for property <tt>lob</tt>.
     * 
     * @param lob
     *            value to be assigned to property lob
     */
    public void setLob(LOB lob) {
        this.lob = lob;
    }

    /**
     * Getter method for property <tt>materialCode</tt>.
     * 
     * @return property value of materialCode
     */
    public MaterialCode getMaterialCode() {
        return materialCode;
    }

    /**
     * Setter method for property <tt>materialCode</tt>.
     * 
     * @param materialCode
     *            value to be assigned to property materialCode
     */
    public void setMaterialCode(MaterialCode materialCode) {
        this.materialCode = materialCode;
    }

    /**
     * Getter method for property <tt>competency</tt>.
     * 
     * @return property value of competency
     */
    public Competency getCompetency() {
        return competency;
    }

    /**
     * Setter method for property <tt>competency</tt>.
     * 
     * @param competency
     *            value to be assigned to property competency
     */
    public void setCompetency(Competency competency) {
        this.competency = competency;
    }

    /**
     * Getter method for property <tt>billingType</tt>.
     * 
     * @return property value of billingType
     */
    public BillingType getBillingType() {
        return billingType;
    }

    /**
     * Setter method for property <tt>billingType</tt>.
     * 
     * @param billingType
     *            value to be assigned to property billingType
     */
    public void setBillingType(BillingType billingType) {
        this.billingType = billingType;
    }

    /**
     * Getter method for property <tt>monthsNum</tt>.
     * 
     * @return property value of monthsNum
     */
    public Integer getMonthsNum() {
        return monthsNum;
    }

    /**
     * Setter method for property <tt>monthsNum</tt>.
     * 
     * @param monthsNum
     *            value to be assigned to property monthsNum
     */
    public void setMonthsNum(Integer monthsNum) {
        this.monthsNum = monthsNum;
    }

    /**
     * Getter method for property <tt>resources</tt>.
     * 
     * @return property value of resources
     */
    public List<LOBResource> getResources() {
        return resources;
    }

    /**
     * Setter method for property <tt>resources</tt>.
     * 
     * @param resources
     *            value to be assigned to property resources
     */
    public void setResources(List<LOBResource> resources) {
        this.resources = resources;
    }

    /**
     * Getter method for property <tt>expenseAmount</tt>.
     * 
     * @return property value of expenseAmount
     */
    public BigDecimal getExpenseAmount() {
        return expenseAmount;
    }

    /**
     * Setter method for property <tt>expenseAmount</tt>.
     * 
     * @param expenseAmount
     *            value to be assigned to property expenseAmount
     */
    public void setExpenseAmount(BigDecimal expenseAmount) {
        this.expenseAmount = expenseAmount;
    }

    /**
     * Getter method for property <tt>discountPercent</tt>.
     * 
     * @return property value of discountPercent
     */
    public BigDecimal getDiscountPercent() {
        return discountPercent;
    }

    /**
     * Setter method for property <tt>discountPercent</tt>.
     * 
     * @param discountPercent
     *            value to be assigned to property discountPercent
     */
    public void setDiscountPercent(BigDecimal discountPercent) {
        this.discountPercent = discountPercent;
    }

    /**
     * Getter method for property <tt>discountAmount</tt>.
     * 
     * @return property value of discountAmount
     */
    public BigDecimal getDiscountAmount() {
        return discountAmount;
    }

    /**
     * Setter method for property <tt>discountAmount</tt>.
     * 
     * @param discountAmount
     *            value to be assigned to property discountAmount
     */
    public void setDiscountAmount(BigDecimal discountAmount) {
        this.discountAmount = discountAmount;
    }

    /**
     * Getter method for property <tt>wbs</tt>.
     * 
     * @return property value of wbs
     */
    public WBS getWbs() {
        return wbs;
    }

    /**
     * Setter method for property <tt>wbs</tt>.
     * 
     * @param wbs
     *            value to be assigned to property wbs
     */
    public void setWbs(WBS wbs) {
        this.wbs = wbs;
    }

}

/*
 * This code is copyright (c) 2014 EMC Corporation.
 */
package com.emc.gs.tools.srf.model.deal;

/**
 * <p>This is EMCClientOption entity class.</p>
 *
 * <p><strong>Thread safety</strong>: This class is mutable, it is not thread safety.</p>
 *
 * @author isv
 * @version 1.0 (SRT 1.1 DEC 2014 Risk Calculation Assembly)
 */
public class EMCClientOption extends RiskCalculationOption {

    /**
     * <p>Constructs new <code>EMCClientOption</code> instance. This implementation does nothing.</p>
     */
    public EMCClientOption() {
    }
}

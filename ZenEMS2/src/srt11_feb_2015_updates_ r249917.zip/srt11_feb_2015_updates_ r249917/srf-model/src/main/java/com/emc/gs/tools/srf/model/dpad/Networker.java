/*
 * This code is copyright (c) 2014 EMC Corporation
 */
package com.emc.gs.tools.srf.model.dpad;

import java.math.BigDecimal;

import com.emc.gs.tools.srf.model.IdentifiableEntity;

/**
 * <p>
 * This is Networker entity class.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safety.
 * </p>
 *
 * <p>
 * Version 1.1 (SRT 4 OCT2014 Updates Part 1 Assembly) Change notes:
 *   <ol>
 *     <li>Added {@link #healthcheck} property.</li>
 *   </ol>
 * </p>
 * 
 * @author isv
 * @version 1.1
 * @since SRT Phase 3-5 - BRS Tabs Part 3 Assembly
 */
public class Networker extends IdentifiableEntity {

    /**
     * # of Hours of Knowledge Transfer.
     */
    private BigDecimal knowledgeTransferHours;

    /**
     * Represents whether "Networker Implementation" service is selected.
     */
    private boolean implementationService;

    /**
     * Represents whether "Networker Upgrade Planning" service is selected.
     */
    private boolean upgradePlanningService;

    /**
     * Represents whether "Networker Healthcheck" service is selected.
     */
    private boolean healthCheckService;

    /**
     * Represents whether "Networker Upgrade" service is selected.
     */
    private boolean upgradeService;

    /**
     * Represents whether "Design" activity type is selected.
     */
    private boolean designActivity;

    /**
     * Represents whether "Implementation" activity type is selected.
     */
    private boolean implementationActivity;

    /**
     * Networker Design.
     */
    private NetworkerDesign design;

    /**
     * Networker Implementation.
     */
    private NetworkerImplementation implementation;

    /**
     * Networker Upgrade.
     */
    private NetworkerUpgrade upgrade;

    /**
     * <p>A <code>NetworkerHealthcheck</code> providing the value for healthcheck property.</p>
     *
     * @since 1.1
     */
    private NetworkerHealthcheck healthcheck;

    /**
     * <p>
     * The default constructor.
     * </p>
     */
    public Networker() {
    }

    /**
     * Getter method for property <tt>knowledgeTransferHours</tt>.
     * 
     * @return property value of knowledgeTransferHours
     */
    public BigDecimal getKnowledgeTransferHours() {
        return knowledgeTransferHours;
    }

    /**
     * Setter method for property <tt>knowledgeTransferHours</tt>.
     * 
     * @param knowledgeTransferHours
     *            value to be assigned to property knowledgeTransferHours
     */
    public void setKnowledgeTransferHours(BigDecimal knowledgeTransferHours) {
        this.knowledgeTransferHours = knowledgeTransferHours;
    }

    /**
     * Getter method for property <tt>implementationService</tt>.
     * 
     * @return property value of implementationService
     */
    public boolean isImplementationService() {
        return implementationService;
    }

    /**
     * Setter method for property <tt>implementationService</tt>.
     * 
     * @param implementationService
     *            value to be assigned to property implementationService
     */
    public void setImplementationService(boolean implementationService) {
        this.implementationService = implementationService;
    }

    /**
     * Getter method for property <tt>upgradePlanningService</tt>.
     * 
     * @return property value of upgradePlanningService
     */
    public boolean isUpgradePlanningService() {
        return upgradePlanningService;
    }

    /**
     * Setter method for property <tt>upgradePlanningService</tt>.
     * 
     * @param upgradePlanningService
     *            value to be assigned to property upgradePlanningService
     */
    public void setUpgradePlanningService(boolean upgradePlanningService) {
        this.upgradePlanningService = upgradePlanningService;
    }

    /**
     * Getter method for property <tt>healthCheckService</tt>.
     * 
     * @return property value of healthCheckService
     */
    public boolean isHealthCheckService() {
        return healthCheckService;
    }

    /**
     * Setter method for property <tt>healthCheckService</tt>.
     * 
     * @param healthCheckService
     *            value to be assigned to property healthCheckService
     */
    public void setHealthCheckService(boolean healthCheckService) {
        this.healthCheckService = healthCheckService;
    }

    /**
     * Getter method for property <tt>upgradeService</tt>.
     * 
     * @return property value of upgradeService
     */
    public boolean isUpgradeService() {
        return upgradeService;
    }

    /**
     * Setter method for property <tt>upgradeService</tt>.
     * 
     * @param upgradeService
     *            value to be assigned to property upgradeService
     */
    public void setUpgradeService(boolean upgradeService) {
        this.upgradeService = upgradeService;
    }

    /**
     * Getter method for property <tt>designActivity</tt>.
     * 
     * @return property value of designActivity
     */
    public boolean isDesignActivity() {
        return designActivity;
    }

    /**
     * Setter method for property <tt>designActivity</tt>.
     * 
     * @param designActivity
     *            value to be assigned to property designActivity
     */
    public void setDesignActivity(boolean designActivity) {
        this.designActivity = designActivity;
    }

    /**
     * Getter method for property <tt>implementationActivity</tt>.
     * 
     * @return property value of implementationActivity
     */
    public boolean isImplementationActivity() {
        return implementationActivity;
    }

    /**
     * Setter method for property <tt>implementationActivity</tt>.
     * 
     * @param implementationActivity
     *            value to be assigned to property implementationActivity
     */
    public void setImplementationActivity(boolean implementationActivity) {
        this.implementationActivity = implementationActivity;
    }

    /**
     * Getter method for property <tt>design</tt>.
     * 
     * @return property value of design
     */
    public NetworkerDesign getDesign() {
        return design;
    }

    /**
     * Setter method for property <tt>design</tt>.
     * 
     * @param design
     *            value to be assigned to property design
     */
    public void setDesign(NetworkerDesign design) {
        this.design = design;
    }

    /**
     * Getter method for property <tt>implementation</tt>.
     * 
     * @return property value of implementation
     */
    public NetworkerImplementation getImplementation() {
        return implementation;
    }

    /**
     * Setter method for property <tt>implementation</tt>.
     * 
     * @param implementation
     *            value to be assigned to property implementation
     */
    public void setImplementation(NetworkerImplementation implementation) {
        this.implementation = implementation;
    }

    /**
     * Getter method for property <tt>upgrade</tt>.
     * 
     * @return property value of upgrade
     */
    public NetworkerUpgrade getUpgrade() {
        return upgrade;
    }

    /**
     * Setter method for property <tt>upgrade</tt>.
     * 
     * @param upgrade
     *            value to be assigned to property upgrade
     */
    public void setUpgrade(NetworkerUpgrade upgrade) {
        this.upgrade = upgrade;
    }

    /**
     * <p>Gets the healthcheck property.</p>
     *
     * @return a <code>NetworkerHealthcheck</code> providing the value for healthcheck property.
     * @since 1.1
     */
    public NetworkerHealthcheck getHealthcheck() {
        return this.healthcheck;
    }

    /**
     * <p>Sets the healthcheck property.</p>
     *
     * @param healthcheck a <code>NetworkerHealthcheck</code> providing the value for healthcheck property.
     * @since 1.1
     */
    public void setHealthcheck(NetworkerHealthcheck healthcheck) {
        this.healthcheck = healthcheck;
    }
}

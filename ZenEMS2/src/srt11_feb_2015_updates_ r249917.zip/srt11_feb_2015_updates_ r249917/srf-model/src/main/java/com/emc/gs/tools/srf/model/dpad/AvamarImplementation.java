/*
 * This code is copyright (c) 2014 EMC Corporation
 */
package com.emc.gs.tools.srf.model.dpad;

import java.math.BigDecimal;

/**
 * <p>
 * This is AvamarImplementation entity class.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safety.
 * </p>
 * 
 * @author TCSASSEMBLER
 * @version 1.0
 * @since SRT Phase 3-5 - BRS Tabs Part 1 Assembly
 */
public class AvamarImplementation extends AvamarDesignImplBase {

    /**
     * # of billable hours for additional testing to be done by an Implementation Specialist.
     */
    private BigDecimal billableHours;

    /**
     * Include Backup & Recovery Manager?
     */
    private Boolean includeBackupRecoveryManager;

    /**
     * Include Hardware Installation?
     */
    private Boolean includeHardwareInstallation;

    /**
     * # of Avamar Data Nodes(Data Store).
     */
    private Integer dataNodesNum;

    /**
     * Estimate # of hours for DataSet creation (4 hours avg).
     */
    private BigDecimal dataSetCreationHours;

    /**
     * Select Avamar Install Type.
     */
    private AvamarInstallType installType;

    /**
     * Select Avamar Authentication Method.
     */
    private AvamarAuthMethod authMethod;

    /**
     * % of Avamar Clients to implement.
     */
    private BigDecimal clientsPercent;

    /**
     * NDMP data.
     */
    private AvamarNDMP ndmp;

    /**
     * # of Avamar VMware Proxies.
     */
    private Integer proxiesNum;

    /**
     * # of Avamar Replication Sets.
     */
    private Integer replicationSetsNum;

    /**
     * # of Avamar Servers to configure for Data Domain.
     */
    private Integer dataDomainServersNum;

    /**
     * # of Avamar Plug-ins configured with DDBoost.
     */
    private Integer ddBoostPluginsNum;

    /**
     * <p>
     * The default constructor.
     * </p>
     */
    public AvamarImplementation() {
    }

    /**
     * Getter method for property <tt>billableHours</tt>.
     * 
     * @return property value of billableHours
     */
    public BigDecimal getBillableHours() {
        return billableHours;
    }

    /**
     * Setter method for property <tt>billableHours</tt>.
     * 
     * @param billableHours
     *            value to be assigned to property billableHours
     */
    public void setBillableHours(BigDecimal billableHours) {
        this.billableHours = billableHours;
    }

    /**
     * Getter method for property <tt>includeBackupRecoveryManager</tt>.
     * 
     * @return property value of includeBackupRecoveryManager
     */
    public Boolean getIncludeBackupRecoveryManager() {
        return includeBackupRecoveryManager;
    }

    /**
     * Setter method for property <tt>includeBackupRecoveryManager</tt>.
     * 
     * @param includeBackupRecoveryManager
     *            value to be assigned to property includeBackupRecoveryManager
     */
    public void setIncludeBackupRecoveryManager(Boolean includeBackupRecoveryManager) {
        this.includeBackupRecoveryManager = includeBackupRecoveryManager;
    }

    /**
     * Getter method for property <tt>includeHardwareInstallation</tt>.
     * 
     * @return property value of includeHardwareInstallation
     */
    public Boolean getIncludeHardwareInstallation() {
        return includeHardwareInstallation;
    }

    /**
     * Setter method for property <tt>includeHardwareInstallation</tt>.
     * 
     * @param includeHardwareInstallation
     *            value to be assigned to property includeHardwareInstallation
     */
    public void setIncludeHardwareInstallation(Boolean includeHardwareInstallation) {
        this.includeHardwareInstallation = includeHardwareInstallation;
    }

    /**
     * Getter method for property <tt>dataNodesNum</tt>.
     * 
     * @return property value of dataNodesNum
     */
    public Integer getDataNodesNum() {
        return dataNodesNum;
    }

    /**
     * Setter method for property <tt>dataNodesNum</tt>.
     * 
     * @param dataNodesNum
     *            value to be assigned to property dataNodesNum
     */
    public void setDataNodesNum(Integer dataNodesNum) {
        this.dataNodesNum = dataNodesNum;
    }

    /**
     * Getter method for property <tt>dataSetCreationHours</tt>.
     * 
     * @return property value of dataSetCreationHours
     */
    public BigDecimal getDataSetCreationHours() {
        return dataSetCreationHours;
    }

    /**
     * Setter method for property <tt>dataSetCreationHours</tt>.
     * 
     * @param dataSetCreationHours
     *            value to be assigned to property dataSetCreationHours
     */
    public void setDataSetCreationHours(BigDecimal dataSetCreationHours) {
        this.dataSetCreationHours = dataSetCreationHours;
    }

    /**
     * Getter method for property <tt>installType</tt>.
     * 
     * @return property value of installType
     */
    public AvamarInstallType getInstallType() {
        return installType;
    }

    /**
     * Setter method for property <tt>installType</tt>.
     * 
     * @param installType
     *            value to be assigned to property installType
     */
    public void setInstallType(AvamarInstallType installType) {
        this.installType = installType;
    }

    /**
     * Getter method for property <tt>authMethod</tt>.
     * 
     * @return property value of authMethod
     */
    public AvamarAuthMethod getAuthMethod() {
        return authMethod;
    }

    /**
     * Setter method for property <tt>authMethod</tt>.
     * 
     * @param authMethod
     *            value to be assigned to property authMethod
     */
    public void setAuthMethod(AvamarAuthMethod authMethod) {
        this.authMethod = authMethod;
    }

    /**
     * Getter method for property <tt>clientsPercent</tt>.
     * 
     * @return property value of clientsPercent
     */
    public BigDecimal getClientsPercent() {
        return clientsPercent;
    }

    /**
     * Setter method for property <tt>clientsPercent</tt>.
     * 
     * @param clientsPercent
     *            value to be assigned to property clientsPercent
     */
    public void setClientsPercent(BigDecimal clientsPercent) {
        this.clientsPercent = clientsPercent;
    }

    /**
     * Getter method for property <tt>ndmp</tt>.
     * 
     * @return property value of ndmp
     */
    public AvamarNDMP getNdmp() {
        return ndmp;
    }

    /**
     * Setter method for property <tt>ndmp</tt>.
     * 
     * @param ndmp
     *            value to be assigned to property ndmp
     */
    public void setNdmp(AvamarNDMP ndmp) {
        this.ndmp = ndmp;
    }

    /**
     * Getter method for property <tt>proxiesNum</tt>.
     * 
     * @return property value of proxiesNum
     */
    public Integer getProxiesNum() {
        return proxiesNum;
    }

    /**
     * Setter method for property <tt>proxiesNum</tt>.
     * 
     * @param proxiesNum
     *            value to be assigned to property proxiesNum
     */
    public void setProxiesNum(Integer proxiesNum) {
        this.proxiesNum = proxiesNum;
    }

    /**
     * Getter method for property <tt>replicationSetsNum</tt>.
     * 
     * @return property value of replicationSetsNum
     */
    public Integer getReplicationSetsNum() {
        return replicationSetsNum;
    }

    /**
     * Setter method for property <tt>replicationSetsNum</tt>.
     * 
     * @param replicationSetsNum
     *            value to be assigned to property replicationSetsNum
     */
    public void setReplicationSetsNum(Integer replicationSetsNum) {
        this.replicationSetsNum = replicationSetsNum;
    }

    /**
     * Getter method for property <tt>dataDomainServersNum</tt>.
     * 
     * @return property value of dataDomainServersNum
     */
    public Integer getDataDomainServersNum() {
        return dataDomainServersNum;
    }

    /**
     * Setter method for property <tt>dataDomainServersNum</tt>.
     * 
     * @param dataDomainServersNum
     *            value to be assigned to property dataDomainServersNum
     */
    public void setDataDomainServersNum(Integer dataDomainServersNum) {
        this.dataDomainServersNum = dataDomainServersNum;
    }

    /**
     * Getter method for property <tt>ddBoostPluginsNum</tt>.
     * 
     * @return property value of ddBoostPluginsNum
     */
    public Integer getDdBoostPluginsNum() {
        return ddBoostPluginsNum;
    }

    /**
     * Setter method for property <tt>ddBoostPluginsNum</tt>.
     * 
     * @param ddBoostPluginsNum
     *            value to be assigned to property ddBoostPluginsNum
     */
    public void setDdBoostPluginsNum(Integer ddBoostPluginsNum) {
        this.ddBoostPluginsNum = ddBoostPluginsNum;
    }

}

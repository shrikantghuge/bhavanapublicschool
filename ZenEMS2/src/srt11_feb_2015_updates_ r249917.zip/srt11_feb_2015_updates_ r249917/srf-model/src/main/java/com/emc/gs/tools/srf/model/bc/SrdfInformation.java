/*
 * This code is copyright (c) 2013 - 2014 EMC Corporation.
 */
package com.emc.gs.tools.srf.model.bc;

import java.util.List;
import java.util.Map;

import com.emc.gs.tools.srf.model.IdentifiableEntity;

/**
 * <p>
 * This is SrdfInformation entity class.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safety.
 * </p>
 *
 * <p>
 * <strong>Changes V1.1:</strong>
 * <strong>SRT Release Assembly - BC Tab</strong>
 * <ul>
 * <li>Change sourceArrayInformation and targetArrayInformation to type of List</li>
 * </ul>
 * </p>
 * 
 * <p>
 * <strong>Changes V1.1:</strong>
 * <strong>SRT Bug Fixes - F121, F153, F154, F162</strong>
 * <ul>
 * <li>Add knowledgeTransferHours field.</li>
 * </ul>
 * </p>
 * 
 * <p>
 * <strong>Changes V1.2:</strong>
 * <ul>
 * <li>Removed srdfARSingleHopFunctionalityRequired, srdfARMultiHopFunctionalityRequired fields.</li>
 * </ul>
 * </p>
 * 
 * <p>
 * <strong>Changes V1.3:</strong>
 * <strong>https://apps.topcoder.com/bugs/browse/SRT-35</strong>
 * <ul>
 * <li>Added srdfCe field.</li>
 * </ul>
 * </p>
 *
 * <p>
 * Version 1.4 (SRT 4 OCT2014 Updates Part 1 Assembly) Change notes:
 *   <ol>
 *     <li>Added {@link #numOfSymmetrixDirectorsRequiringFA2RAConversion} property.</li>
 *     <li>Added {@link #numOfSymmetrixRADirectorsRequiringCompression} property.</li>
 *     <li>Added {@link #numOfSymmetrixGigabitEthernetDirectors} property.</li>
 *   </ol>
 * </p>
 * 
 * @author faeton, stevenfrog, MonicaMuranyi, isv
 * @version 1.4
 */
public class SrdfInformation extends IdentifiableEntity {
    
    /**
     * <p>
     * The knowledgeTransferHours.
     * </p>
     */
    private String knowledgeTransferHours;
    
    /**
     * <p>
     * The srdfSFunctionalityRequired.
     * </p>
     */
    private boolean srdfSFunctionalityRequired;

    /**
     * <p>
     * The srdfAFunctionalityRequired.
     * </p>
     */
    private boolean srdfAFunctionalityRequired;

    /**
     * <p>
     * The cascadingSrdfFunctionalityRequired.
     * </p>
     */
    private boolean cascadingSrdfFunctionalityRequired;

    /**
     * <p>
     * The srdfStarFunctionalityRequired.
     * </p>
     */
    private boolean srdfStarFunctionalityRequired;
    
    /**
     * <p>
     * The concurrentSrdfFunctionalityRequired.
     * </p>
     */
    private boolean concurrentSrdfFunctionalityRequired;

    /**
     * <p>
     * The networkLinkStatus.
     * </p>
     */
    private NetworkLinkStatus networkLinkStatus;

    /**
     * <p>
     * The srdfStaticDynamicType.
     * </p>
     */
    private SrdfStaticDynamicType srdfStaticDynamicType;

    /**
     * <p>
     * The Integer>.
     * </p>
     */
    private Map<String, Integer> hostNumbers;

    /**
     * <p>
     * The sourceArrayInformation.
     * </p>
     */
    private List<SrdfSourceArrayInformation> sourceArrayInformation;

    /**
     * <p>
     * The targetArrayInformation.
     * </p>
     */
    private List<SrdfTargetArrayInformation> targetArrayInformation;

    /**
     * <p>
     * The bcPractiveScriptingLevel.
     * </p>
     */
    private ScriptingLevel bcPractiveScriptingLevel2;

    /**
     * <p>
     * The emcMapPointsOption.
     * </p>
     */
    private boolean emcMapPointsOption;
    
    /**
     * <p>
     * The srdfCe.
     * </p>
     */
    private boolean srdfCe;

    /**
     * <p>A <code>Integer</code> providing the value for "Number of Symmetrix Directors Requiring FA to RA 
     * Conversion" property.</p>
     *
     * @since 1.4
     */
    private Integer numOfSymmetrixDirectorsRequiringFA2RAConversion;

    /**
     * <p>A <code>Integer</code> providing the value for "Number of Symmetrix RA Directors Requiring Compression"
     * property.</p>
     *
     * @since 1.4
     */
    private Integer numOfSymmetrixRADirectorsRequiringCompression;

    /**
     * <p>A <code>Integer</code> providing the value for "Number of Symmetrix Gigabit Ethernet Directors" 
     * property.</p>
     *
     * @since 1.4
     */
    private Integer numOfSymmetrixGigabitEthernetDirectors;

    /**
     * <p>
     * The default constructor.
     * </p>
     */
    public SrdfInformation() {
        // Empty
    }
    
    /**
     * <p>
     * Retrieves the knowledgeTransferHours field.
     * </p>
     *
     * @return the knowledgeTransferHours
     */
    public String getKnowledgeTransferHours() {
        return knowledgeTransferHours;
    }

    /**
     * <p>
     * Sets the value to knowledgeTransferHours field.
     * </p>
     *
     * @param knowledgeTransferHours
     *            the knowledgeTransferHours to set
     */
    public void setKnowledgeTransferHours(String knowledgeTransferHours) {
        this.knowledgeTransferHours = knowledgeTransferHours;
    }

    /**
     * <p>
     * Retrieves the srdfSFunctionalityRequired field.
     * </p>
     *
     * @return the srdfSFunctionalityRequired
     */
    public boolean isSrdfSFunctionalityRequired() {
        return srdfSFunctionalityRequired;
    }

    /**
     * <p>
     * Sets the value to srdfSFunctionalityRequired field.
     * </p>
     *
     * @param srdfSFunctionalityRequired
     *            the srdfSFunctionalityRequired to set
     */
    public void setSrdfSFunctionalityRequired(boolean srdfSFunctionalityRequired) {
        this.srdfSFunctionalityRequired = srdfSFunctionalityRequired;
    }

    /**
     * <p>
     * Retrieves the srdfAFunctionalityRequired field.
     * </p>
     *
     * @return the srdfAFunctionalityRequired
     */
    public boolean isSrdfAFunctionalityRequired() {
        return srdfAFunctionalityRequired;
    }

    /**
     * <p>
     * Sets the value to srdfAFunctionalityRequired field.
     * </p>
     *
     * @param srdfAFunctionalityRequired
     *            the srdfAFunctionalityRequired to set
     */
    public void setSrdfAFunctionalityRequired(boolean srdfAFunctionalityRequired) {
        this.srdfAFunctionalityRequired = srdfAFunctionalityRequired;
    }

    /**
     * <p>
     * Retrieves the cascadingSrdfFunctionalityRequired field.
     * </p>
     *
     * @return the cascadingSrdfFunctionalityRequired
     */
    public boolean isCascadingSrdfFunctionalityRequired() {
        return cascadingSrdfFunctionalityRequired;
    }

    /**
     * <p>
     * Sets the value to cascadingSrdfFunctionalityRequired field.
     * </p>
     *
     * @param cascadingSrdfFunctionalityRequired
     *            the cascadingSrdfFunctionalityRequired to set
     */
    public void setCascadingSrdfFunctionalityRequired(boolean cascadingSrdfFunctionalityRequired) {
        this.cascadingSrdfFunctionalityRequired = cascadingSrdfFunctionalityRequired;
    }

    /**
     * <p>
     * Retrieves the srdfStarFunctionalityRequired field.
     * </p>
     *
     * @return the srdfStarFunctionalityRequired
     */
    public boolean isSrdfStarFunctionalityRequired() {
        return srdfStarFunctionalityRequired;
    }

    /**
     * <p>
     * Sets the value to srdfStarFunctionalityRequired field.
     * </p>
     *
     * @param srdfStarFunctionalityRequired
     *            the srdfStarFunctionalityRequired to set
     */
    public void setSrdfStarFunctionalityRequired(boolean srdfStarFunctionalityRequired) {
        this.srdfStarFunctionalityRequired = srdfStarFunctionalityRequired;
    }

    /**
     * <p>
     * Retrieves the concurrentSrdfFunctionalityRequired field.
     * </p>
     *
     * @return the concurrentSrdfFunctionalityRequired
     */
    public boolean isConcurrentSrdfFunctionalityRequired() {
        return concurrentSrdfFunctionalityRequired;
    }

    /**
     * <p>
     * Sets the value to concurrentSrdfFunctionalityRequired field.
     * </p>
     *
     * @param concurrentSrdfFunctionalityRequired
     *            the concurrentSrdfFunctionalityRequired to set
     */
    public void setConcurrentSrdfFunctionalityRequired(boolean concurrentSrdfFunctionalityRequired) {
        this.concurrentSrdfFunctionalityRequired = concurrentSrdfFunctionalityRequired;
    }

    /**
     * <p>
     * Retrieves the networkLinkStatus field.
     * </p>
     *
     * @return the networkLinkStatus
     */
    public NetworkLinkStatus getNetworkLinkStatus() {
        return networkLinkStatus;
    }

    /**
     * <p>
     * Sets the value to networkLinkStatus field.
     * </p>
     *
     * @param networkLinkStatus
     *            the networkLinkStatus to set
     */
    public void setNetworkLinkStatus(NetworkLinkStatus networkLinkStatus) {
        this.networkLinkStatus = networkLinkStatus;
    }

    /**
     * <p>
     * Retrieves the srdfStaticDynamicType field.
     * </p>
     *
     * @return the srdfStaticDynamicType
     */
    public SrdfStaticDynamicType getSrdfStaticDynamicType() {
        return srdfStaticDynamicType;
    }

    /**
     * <p>
     * Sets the value to srdfStaticDynamicType field.
     * </p>
     *
     * @param srdfStaticDynamicType
     *            the srdfStaticDynamicType to set
     */
    public void setSrdfStaticDynamicType(SrdfStaticDynamicType srdfStaticDynamicType) {
        this.srdfStaticDynamicType = srdfStaticDynamicType;
    }

    /**
     * <p>
     * Retrieves the hostNumbers field.
     * </p>
     *
     * @return the hostNumbers
     */
    public Map<String, Integer> getHostNumbers() {
        return hostNumbers;
    }

    /**
     * <p>
     * Sets the value to hostNumbers field.
     * </p>
     *
     * @param hostNumbers
     *            the hostNumbers to set
     */
    public void setHostNumbers(Map<String, Integer> hostNumbers) {
        this.hostNumbers = hostNumbers;
    }

    /**
     * <p>
     * Retrieves the sourceArrayInformation field.
     * </p>
     *
     * @return the sourceArrayInformation
     */
    public List<SrdfSourceArrayInformation> getSourceArrayInformation() {
        return sourceArrayInformation;
    }

    /**
     * <p>
     * Sets the value to sourceArrayInformation field.
     * </p>
     *
     * @param sourceArrayInformation
     *            the sourceArrayInformation to set
     */
    public void setSourceArrayInformation(List<SrdfSourceArrayInformation> sourceArrayInformation) {
        this.sourceArrayInformation = sourceArrayInformation;
    }

    /**
     * <p>
     * Retrieves the targetArrayInformation field.
     * </p>
     *
     * @return the targetArrayInformation
     */
    public List<SrdfTargetArrayInformation> getTargetArrayInformation() {
        return targetArrayInformation;
    }

    /**
     * <p>
     * Sets the value to targetArrayInformation field.
     * </p>
     *
     * @param targetArrayInformation
     *            the targetArrayInformation to set
     */
    public void setTargetArrayInformation(List<SrdfTargetArrayInformation> targetArrayInformation) {
        this.targetArrayInformation = targetArrayInformation;
    }


    /**
     * <p>
     * Retrieves the emcMapPointsOption field.
     * </p>
     *
     * @return the emcMapPointsOption
     */
    public boolean isEmcMapPointsOption() {
        return emcMapPointsOption;
    }

    /**
     * <p>
     * Sets the value to emcMapPointsOption field.
     * </p>
     *
     * @param emcMapPointsOption
     *            the emcMapPointsOption to set
     */
    public void setEmcMapPointsOption(boolean emcMapPointsOption) {
        this.emcMapPointsOption = emcMapPointsOption;
    }

    /**
     * <p>
     * Retrieves the bcPractiveScriptingLevel2 field.
     * </p>
     *
     * @return the value of bcPractiveScriptingLevel2
     */
    public ScriptingLevel getBcPractiveScriptingLevel2() {
        return bcPractiveScriptingLevel2;
    }

    /**
     * <p>
     * Sets the value to bcPractiveScriptingLevel2 field.
     * </p>
     *
     * @param bcPractiveScriptingLevel2 the value of bcPractiveScriptingLevel2 to set
     */
    public void setBcPractiveScriptingLevel2(ScriptingLevel bcPractiveScriptingLevel2) {
        this.bcPractiveScriptingLevel2 = bcPractiveScriptingLevel2;
    }
    
    /**
     * <p>
     * Retrieves the srdfCe field.
     * </p>
     *
     * @return the value of srdfCe
     */
    public boolean isSrdfCe() {
        return srdfCe;
    }

    /**
     * <p>
     * Sets the value to srdfCe field.
     * </p>
     *
     * @param srdfCe the value of srdfCe to set
     */
    public void setSrdfCe(boolean srdfCe) {
        this.srdfCe = srdfCe;
    }

    /**
     * <p>Gets the "Number of Symmetrix Gigabit Ethernet Directors" property.</p>
     *
     * @return a <code>Integer</code> providing the value for "Number of Symmetrix Gigabit Ethernet Directors" property.
     * @since 1.4
     */
    public Integer getNumOfSymmetrixGigabitEthernetDirectors() {
        return this.numOfSymmetrixGigabitEthernetDirectors;
    }

    /**
     * <p>Sets the "Number of Symmetrix Gigabit Ethernet Directors" property.</p>
     *
     * @param numOfSymmetrixGigabitEthernetDirectors a <code>Integer</code> providing the value for "Number of Symmetrix
     * Gigabit Ethernet Directors" property.
     * @since 1.4
     */
    public void setNumOfSymmetrixGigabitEthernetDirectors(Integer numOfSymmetrixGigabitEthernetDirectors) {
        this.numOfSymmetrixGigabitEthernetDirectors = numOfSymmetrixGigabitEthernetDirectors;
    }

    /**
     * <p>Gets the "Number of Symmetrix RA Directors Requiring Compression" property.</p>
     *
     * @return a <code>Integer</code> providing the value for "Number of Symmetrix RA Directors Requiring Compression"
     * property.
     * @since 1.4
     */
    public Integer getNumOfSymmetrixRADirectorsRequiringCompression() {
        return this.numOfSymmetrixRADirectorsRequiringCompression;
    }

    /**
     * <p>Sets the "Number of Symmetrix RA Directors Requiring Compression" property.</p>
     *
     * @param numOfSymmetrixRADirectorsRequiringCompression a <code>Integer</code> providing the value for "Number of
     * Symmetrix RA Directors Requiring Compression" property.
     * @since 1.4
     */
    public void setNumOfSymmetrixRADirectorsRequiringCompression(
        Integer numOfSymmetrixRADirectorsRequiringCompression) {
        this.numOfSymmetrixRADirectorsRequiringCompression = numOfSymmetrixRADirectorsRequiringCompression;
    }

    /**
     * <p>Gets the "Number of Symmetrix Directors Requiring FA to RA Conversion" property.</p>
     *
     * @return a <code>Integer</code> providing the value for "Number of Symmetrix Directors Requiring FA to RA
     * Conversion" property.
     * @since 1.4
     */
    public Integer getNumOfSymmetrixDirectorsRequiringFA2RAConversion() {
        return this.numOfSymmetrixDirectorsRequiringFA2RAConversion;
    }

    /**
     * <p>Sets the "Number of Symmetrix Directors Requiring FA to RA Conversion" property.</p>
     *
     * @param numOfSymmetrixDirectorsRequiringFA2RAConversion a <code>Integer</code> providing the value for "Number of
     * Symmetrix Directors Requiring FA to RA Conversion" property.
     * @since 1.4
     */
    public void setNumOfSymmetrixDirectorsRequiringFA2RAConversion(
        Integer numOfSymmetrixDirectorsRequiringFA2RAConversion) {
        this.numOfSymmetrixDirectorsRequiringFA2RAConversion = numOfSymmetrixDirectorsRequiringFA2RAConversion;
    }

    /**
     * The toString method.
     *
     * @return the string for this entity
     */
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("{").append(super.toString());
        sb.append(", knowledgeTransferHours:").append(knowledgeTransferHours);
        sb.append(", srdfSFunctionalityRequired:").append(srdfSFunctionalityRequired);
        sb.append(", srdfAFunctionalityRequired:").append(srdfAFunctionalityRequired);
        sb.append(", cascadingSrdfFunctionalityRequired:").append(cascadingSrdfFunctionalityRequired);
        sb.append(", srdfStarFunctionalityRequired:").append(srdfStarFunctionalityRequired);
        sb.append(", concurrentSrdfFunctionalityRequired:").append(concurrentSrdfFunctionalityRequired);
        sb.append(", networkLinkStatus:").append(networkLinkStatus);
        sb.append(", srdfStaticDynamicType:").append(srdfStaticDynamicType);
        sb.append(", hostNumbers:").append(hostNumbers);
        sb.append(", sourceArrayInformation:").append(sourceArrayInformation);
        sb.append(", targetArrayInformation:").append(targetArrayInformation);
        sb.append(", bcPractiveScriptingLevel2:").append(bcPractiveScriptingLevel2);
        sb.append(", srdfCe:").append(srdfCe);
        sb.append(", numOfSymmetrixDirectorsRequiringFA2RAConversion:").append(numOfSymmetrixDirectorsRequiringFA2RAConversion);
        sb.append(", numOfSymmetrixRADirectorsRequiringCompression:").append(numOfSymmetrixRADirectorsRequiringCompression);
        sb.append(", numOfSymmetrixGigabitEthernetDirectors:").append(numOfSymmetrixGigabitEthernetDirectors);
        sb.append(", emcMapPointsOption:").append(emcMapPointsOption).append("}");
        return sb.toString();
    }
}

/*
 * This code is copyright (c) 2014 EMC Corporation
 */
package com.emc.gs.tools.srf.model.dpad;

import com.emc.gs.tools.srf.model.IdentifiableEntity;

import java.math.BigDecimal;

/**
 * <p>This is IntelligentFabricSplitterMigration entity class.</p>
 *
 * <p><strong>Thread safety</strong>: This class is mutable, it is not thread safety.</p>
 *
 * @author isv
 * @version 1.0 (SRT 4 OCT2014 Updates Part 2)
 */
public class IntelligentFabricSplitterMigration extends IdentifiableEntity {

    /**
     * <p>A <code>IntelligentFabricMigrationMethod</code> providing the value for "Intelligent Fabric Migration Method"
     * property.</p>
     */
    private IntelligentFabricMigrationMethod intelligentFabricMigrationMethod;

    /**
     * <p>A <code>Boolean</code> providing the value for "Will host data gathering (Grid Analysis) be Required?"
     * property.</p>
     */
    private Boolean gridAnalysisRequired;

    /**
     * <p>A <code>boolean</code> providing the value for "VNX or CLARiiON" storage array option property.</p>
     */
    private boolean vnxOrClariionInvolved;

    /**
     * <p>A <code>boolean</code> providing the value for "VMAX DMX or SYMM" storage array option property.</p>
     */
    private boolean vmaxDMXorSYMMInvolved;

    /**
     * <p>A <code>boolean</code> providing the value for "3rd PArty or Non-EMC Storage" storage array option
     * property.</p>
     */
    private boolean nonEMCor3rdPartyStorageInvolved;

    /**
     * <p>A <code>boolean</code> providing the value for "No Source Array" storage array option property.</p>
     */
    private boolean noSourceArrayInvolved;

    /**
     * <p>A <code>boolean</code> providing the value for "XtremIO Cluster" storage array option property.</p>
     */
    private boolean xtremIOClusterInvolved;

    /**
     * <p>A <code>Integer</code> providing the value for "# of RPA Clusters to be Migrated Off of IF splitters?"
     * property.</p>
     */
    private Integer numberOfRPAClustersToMigrate;

    /**
     * <p>A <code>Integer</code> providing the value for "# of Hosts Using RPA Volumes to be Migrated Off of IF
     * Splitters?" property.</p>
     */
    private Integer numberOfRPAVolumesHostsToMigrate;

    /**
     * <p>A <code>Boolean</code> providing the value for "Include Bandwidth Analysis as Part of Planning and Design?"
     * property.</p>
     */
    private Boolean includeBandwidthAnalysis;

    /**
     * <p>A <code>Boolean</code> providing the value for "Include 3rd Party Storage Array Planning and Design?"
     * property.</p>
     */
    private Boolean include3rdPartyStorageArrayPlanningAndDesign;

    /**
     * <p>A <code>RecoverPointOption</code> providing the value for "RecoverPoint Option" property.</p>
     */
    private RecoverPointOption recoverPointOption;

    /**
     * <p>A <code>Integer</code> providing the value for "# of VPLEX Clusters?" property.</p>
     */
    private Integer numberOfVPLEXClusters;

    /**
     * <p>A <code>Integer</code> providing the value for "# of Volumes to Encapsulate?" property.</p>
     */
    private Integer numberOfEncapsulatedVolumes;

    /**
     * <p>A <code>Integer</code> providing the value for "# of Encapsulation Events by a Single EMC Resource?"
     * property.</p>
     */
    private Integer numberOfEncapsulationEventsPerEMCResource;

    /**
     * <p>A <code>Integer</code> providing the value for "# of Hosts to be Encapsulated into VPLEX?" property.</p>
     */
    private Integer numberOfHostVPLEXEncapsulations;

    /**
     * <p>A <code>BigDecimal</code> providing the value for "# of Hours in Maintenance Windows?" property.</p>
     */
    private BigDecimal maintenanceWindowsHours;

    /**
     * <p>A <code>Integer</code> providing the value for "# of client / servers / ESX servers in RP Environment?"
     * property.</p>
     */
    private Integer numberOfRPEnvironmentClientsServers;

    /**
     * <p>A <code>boolean</code> providing the value for "RecoverPoint Replication Method - Local" flag property.</p>
     */
    private boolean localReplicationMethod;

    /**
     * <p>A <code>boolean</code> providing the value for "RecoverPoint Replication Method - Remote" flag property.</p>
     */
    private boolean remoteReplicationMethod;

    /**
     * <p>Constructs new <code>IntelligentFabricSplitterMigration</code> instance. This implementation does nothing.</p>
     */
    public IntelligentFabricSplitterMigration() {
    }

    /**
     * <p>Gets the "RecoverPoint Replication Method - Remote" flag property.</p>
     *
     * @return a <code>boolean</code> providing the value for "RecoverPoint Replication Method - Remote" flag property.
     */
    public boolean getRemoteReplicationMethod() {
        return this.remoteReplicationMethod;
    }

    /**
     * <p>Sets the "RecoverPoint Replication Method - Remote" flag property.</p>
     *
     * @param remoteReplicationMethod a <code>boolean</code> providing the value for "RecoverPoint Replication Method -
     * Remote" flag property.
     */
    public void setRemoteReplicationMethod(boolean remoteReplicationMethod) {
        this.remoteReplicationMethod = remoteReplicationMethod;
    }

    /**
     * <p>Gets the "RecoverPoint Replication Method - Local" flag property.</p>
     *
     * @return a <code>boolean</code> providing the value for "RecoverPoint Replication Method - Local" flag property.
     */
    public boolean getLocalReplicationMethod() {
        return this.localReplicationMethod;
    }

    /**
     * <p>Sets the "RecoverPoint Replication Method - Local" flag property.</p>
     *
     * @param localReplicationMethod a <code>boolean</code> providing the value for "RecoverPoint Replication Method -
     * Local" flag property.
     */
    public void setLocalReplicationMethod(boolean localReplicationMethod) {
        this.localReplicationMethod = localReplicationMethod;
    }

    /**
     * <p>Gets the "# of client / servers / ESX servers in RP Environment?" property.</p>
     *
     * @return a <code>Integer</code> providing the value for "# of client / servers / ESX servers in RP Environment?"
     * property.
     */
    public Integer getNumberOfRPEnvironmentClientsServers() {
        return this.numberOfRPEnvironmentClientsServers;
    }

    /**
     * <p>Sets the "# of client / servers / ESX servers in RP Environment?" property.</p>
     *
     * @param numberOfRPEnvironmentClientsServers a <code>Integer</code> providing the value for "# of client / servers
     * / ESX servers in RP Environment?" property.
     */
    public void setNumberOfRPEnvironmentClientsServers(Integer numberOfRPEnvironmentClientsServers) {
        this.numberOfRPEnvironmentClientsServers = numberOfRPEnvironmentClientsServers;
    }

    /**
     * <p>Gets the "# of Hours in Maintenance Windows?" property.</p>
     *
     * @return a <code>BigDecimal</code> providing the value for "# of Hours in Maintenance Windows?" property.
     */
    public BigDecimal getMaintenanceWindowsHours() {
        return this.maintenanceWindowsHours;
    }

    /**
     * <p>Sets the "# of Hours in Maintenance Windows?" property.</p>
     *
     * @param maintenanceWindowsHours a <code>BigDecimal</code> providing the value for "# of Hours in Maintenance
     * Windows?" property.
     */
    public void setMaintenanceWindowsHours(BigDecimal maintenanceWindowsHours) {
        this.maintenanceWindowsHours = maintenanceWindowsHours;
    }

    /**
     * <p>Gets the "# of Hosts to be Encapsulated into VPLEX?" property.</p>
     *
     * @return a <code>Integer</code> providing the value for "# of Hosts to be Encapsulated into VPLEX?" property.
     */
    public Integer getNumberOfHostVPLEXEncapsulations() {
        return this.numberOfHostVPLEXEncapsulations;
    }

    /**
     * <p>Sets the "# of Hosts to be Encapsulated into VPLEX?" property.</p>
     *
     * @param numberOfHostVPLEXEncapsulations a <code>Integer</code> providing the value for "# of Hosts to be
     * Encapsulated into VPLEX?" property.
     */
    public void setNumberOfHostVPLEXEncapsulations(Integer numberOfHostVPLEXEncapsulations) {
        this.numberOfHostVPLEXEncapsulations = numberOfHostVPLEXEncapsulations;
    }

    /**
     * <p>Gets the "# of Encapsulation Events by a Single EMC Resource? property.</p>
     *
     * @return a <code>Integer</code> providing the value for "# of Encapsulation Events by a Single EMC Resource?
     * property.
     */
    public Integer getNumberOfEncapsulationEventsPerEMCResource() {
        return this.numberOfEncapsulationEventsPerEMCResource;
    }

    /**
     * <p>Sets the "# of Encapsulation Events by a Single EMC Resource? property.</p>
     *
     * @param numberOfEncapsulationEventsPerEMCResource a <code>Integer</code> providing the value for "# of
     * Encapsulation Events by a Single EMC Resource? property.
     */
    public void setNumberOfEncapsulationEventsPerEMCResource(Integer numberOfEncapsulationEventsPerEMCResource) {
        this.numberOfEncapsulationEventsPerEMCResource = numberOfEncapsulationEventsPerEMCResource;
    }


    /**
     * <p>Gets the "# of Volumes to Encapsulate?" property.</p>
     *
     * @return a <code>Integer</code> providing the value for "# of Volumes to Encapsulate?" property.
     */
    public Integer getNumberOfEncapsulatedVolumes() {
        return this.numberOfEncapsulatedVolumes;
    }

    /**
     * <p>Sets the "# of Volumes to Encapsulate?" property.</p>
     *
     * @param numberOfEncapsulatedVolumes a <code>Integer</code> providing the value for "# of Volumes to Encapsulate?"
     * property.
     */
    public void setNumberOfEncapsulatedVolumes(Integer numberOfEncapsulatedVolumes) {
        this.numberOfEncapsulatedVolumes = numberOfEncapsulatedVolumes;
    }

    /**
     * <p>Gets the "# of VPLEX Clusters?" property.</p>
     *
     * @return a <code>Integer</code> providing the value for "# of VPLEX Clusters?" property.
     */
    public Integer getNumberOfVPLEXClusters() {
        return this.numberOfVPLEXClusters;
    }

    /**
     * <p>Sets the "# of VPLEX Clusters?" property.</p>
     *
     * @param numberOfVPLEXClusters a <code>Integer</code> providing the value for "# of VPLEX Clusters?" property.
     */
    public void setNumberOfVPLEXClusters(Integer numberOfVPLEXClusters) {
        this.numberOfVPLEXClusters = numberOfVPLEXClusters;
    }

    /**
     * <p>Gets the "RecoverPoint Option" property.</p>
     *
     * @return a <code>RecoverPointOption</code> providing the value for "RecoverPoint Option" property.
     */
    public RecoverPointOption getRecoverPointOption() {
        return this.recoverPointOption;
    }

    /**
     * <p>Sets the "RecoverPoint Option" property.</p>
     *
     * @param recoverPointOption a <code>RecoverPointOption</code> providing the value for "RecoverPoint Option"
     * property.
     */
    public void setRecoverPointOption(RecoverPointOption recoverPointOption) {
        this.recoverPointOption = recoverPointOption;
    }

    /**
     * <p>Gets the "Include 3rd Party Storage Array Planning and Design?" property.</p>
     *
     * @return a <code>Boolean</code> providing the value for "Include 3rd Party Storage Array Planning and Design?"
     * property.
     */
    public Boolean getInclude3rdPartyStorageArrayPlanningAndDesign() {
        return this.include3rdPartyStorageArrayPlanningAndDesign;
    }

    /**
     * <p>Sets the "Include 3rd Party Storage Array Planning and Design?" property.</p>
     *
     * @param include3rdPartyStorageArrayPlanningAndDesign a <code>Boolean</code> providing the value for "Include 3rd
     * Party Storage Array Planning and Design?" property.
     */
    public void setInclude3rdPartyStorageArrayPlanningAndDesign(Boolean include3rdPartyStorageArrayPlanningAndDesign) {
        this.include3rdPartyStorageArrayPlanningAndDesign = include3rdPartyStorageArrayPlanningAndDesign;
    }

    /**
     * <p>Gets the "Include Bandwidth Analysis as Part of Planning and Design?" property.</p>
     *
     * @return a <code>Boolean</code> providing the value for "Include Bandwidth Analysis as Part of Planning and
     * Design?" property.
     */
    public Boolean getIncludeBandwidthAnalysis() {
        return this.includeBandwidthAnalysis;
    }

    /**
     * <p>Sets the "Include Bandwidth Analysis as Part of Planning and Design?" property.</p>
     *
     * @param includeBandwidthAnalysis a <code>Boolean</code> providing the value for "Include Bandwidth Analysis as
     * Part of Planning and Design?" property.
     */
    public void setIncludeBandwidthAnalysis(Boolean includeBandwidthAnalysis) {
        this.includeBandwidthAnalysis = includeBandwidthAnalysis;
    }

    /**
     * <p>Gets the "# of Hosts Using RPA Volumes to be Migrated Off of IF Splitters?" property.</p>
     *
     * @return a <code>Integer</code> providing the value for "# of Hosts Using RPA Volumes to be Migrated Off of IF
     * Splitters?" property.
     */
    public Integer getNumberOfRPAVolumesHostsToMigrate() {
        return this.numberOfRPAVolumesHostsToMigrate;
    }

    /**
     * <p>Sets the "# of Hosts Using RPA Volumes to be Migrated Off of IF Splitters?" property.</p>
     *
     * @param numberOfRPAVolumesHostsToMigrate a <code>Integer</code> providing the value for "# of Hosts Using RPA
     * Volumes to be Migrated Off of IF Splitters?" property.
     */
    public void setNumberOfRPAVolumesHostsToMigrate(Integer numberOfRPAVolumesHostsToMigrate) {
        this.numberOfRPAVolumesHostsToMigrate = numberOfRPAVolumesHostsToMigrate;
    }

    /**
     * <p>Gets the "# of RPA Clusters to be Migrated Off of IF splitters?" property.</p>
     *
     * @return a <code>Integer</code> providing the value for "# of RPA Clusters to be Migrated Off of IF splitters?"
     * property.
     */
    public Integer getNumberOfRPAClustersToMigrate() {
        return this.numberOfRPAClustersToMigrate;
    }

    /**
     * <p>Sets the "# of RPA Clusters to be Migrated Off of IF splitters?" property.</p>
     *
     * @param numberOfRPAClustersToMigrate a <code>Integer</code> providing the value for "# of RPA Clusters to be
     * Migrated Off of IF splitters?" property.
     */
    public void setNumberOfRPAClustersToMigrate(Integer numberOfRPAClustersToMigrate) {
        this.numberOfRPAClustersToMigrate = numberOfRPAClustersToMigrate;
    }

    /**
     * <p>Gets the "XtremIO Cluster" storage array option property.</p>
     *
     * @return a <code>boolean</code> providing the value for "XtremIO Cluster" storage array option property.
     */
    public boolean getXtremIOClusterInvolved() {
        return this.xtremIOClusterInvolved;
    }

    /**
     * <p>Sets the "XtremIO Cluster" storage array option property.</p>
     *
     * @param xtremIOClusterInvolved a <code>boolean</code> providing the value for "XtremIO Cluster" storage array
     * option property.
     */
    public void setXtremIOClusterInvolved(boolean xtremIOClusterInvolved) {
        this.xtremIOClusterInvolved = xtremIOClusterInvolved;
    }

    /**
     * <p>Gets the "No Source Array" storage array option property.</p>
     *
     * @return a <code>boolean</code> providing the value for "No Source Array" storage array option property.
     */
    public boolean getNoSourceArrayInvolved() {
        return this.noSourceArrayInvolved;
    }

    /**
     * <p>Sets the "No Source Array" storage array option property.</p>
     *
     * @param noSourceArrayInvolved a <code>boolean</code> providing the value for "No Source Array" storage array
     * option property.
     */
    public void setNoSourceArrayInvolved(boolean noSourceArrayInvolved) {
        this.noSourceArrayInvolved = noSourceArrayInvolved;
    }

    /**
     * <p>Gets the "3rd PArty or Non-EMC Storage" storage array option property.</p>
     *
     * @return a <code>boolean</code> providing the value for "3rd PArty or Non-EMC Storage" storage array option
     * property.
     */
    public boolean getNonEMCor3rdPartyStorageInvolved() {
        return this.nonEMCor3rdPartyStorageInvolved;
    }

    /**
     * <p>Sets the "3rd PArty or Non-EMC Storage" storage array option property.</p>
     *
     * @param nonEMCor3rdPartyStorageInvolved a <code>boolean</code> providing the value for "3rd PArty or Non-EMC
     * Storage" storage array option property.
     */
    public void setNonEMCor3rdPartyStorageInvolved(boolean nonEMCor3rdPartyStorageInvolved) {
        this.nonEMCor3rdPartyStorageInvolved = nonEMCor3rdPartyStorageInvolved;
    }

    /**
     * <p>Gets the "VMAX DMX or SYMM" storage array option property.</p>
     *
     * @return a <code>boolean</code> providing the value for "VMAX DMX or SYMM" storage array option property.
     */
    public boolean getVmaxDMXorSYMMInvolved() {
        return this.vmaxDMXorSYMMInvolved;
    }

    /**
     * <p>Sets the "VMAX DMX or SYMM" storage array option property.</p>
     *
     * @param vmaxDMXorSYMMInvolved a <code>boolean</code> providing the value for "VMAX DMX or SYMM" storage array
     * option property.
     */
    public void setVmaxDMXorSYMMInvolved(boolean vmaxDMXorSYMMInvolved) {
        this.vmaxDMXorSYMMInvolved = vmaxDMXorSYMMInvolved;
    }

    /**
     * <p>Gets the "VNX or CLARiiON" storage array option property.</p>
     *
     * @return a <code>boolean</code> providing the value for "VNX or CLARiiON" storage array option property.
     */
    public boolean getVnxOrClariionInvolved() {
        return this.vnxOrClariionInvolved;
    }

    /**
     * <p>Sets the "VNX or CLARiiON" storage array option property.</p>
     *
     * @param vnxOrClariionInvolved a <code>boolean</code> providing the value for "VNX or CLARiiON" storage array
     * option property.
     */
    public void setVnxOrClariionInvolved(boolean vnxOrClariionInvolved) {
        this.vnxOrClariionInvolved = vnxOrClariionInvolved;
    }

    /**
     * <p>Gets the "Will host data gathering (Grid Analysis) be Required?" property.</p>
     *
     * @return a <code>Boolean</code> providing the value for "Will host data gathering (Grid Analysis) be Required?"
     * property.
     */
    public Boolean getGridAnalysisRequired() {
        return this.gridAnalysisRequired;
    }

    /**
     * <p>Sets the "Will host data gathering (Grid Analysis) be Required?" property.</p>
     *
     * @param gridAnalysisRequired a <code>Boolean</code> providing the value for "Will host data gathering (Grid
     * Analysis) be Required?" property.
     */
    public void setGridAnalysisRequired(Boolean gridAnalysisRequired) {
        this.gridAnalysisRequired = gridAnalysisRequired;
    }


    /**
     * <p>Gets the "Intelligent Fabric Migration Method" property.</p>
     *
     * @return a <code>IntelligentFabricMigrationMethod</code> providing the value for "Intelligent Fabric Migration
     * Method" property.
     */
    public IntelligentFabricMigrationMethod getIntelligentFabricMigrationMethod() {
        return this.intelligentFabricMigrationMethod;
    }

    /**
     * <p>Sets the "Intelligent Fabric Migration Method" property.</p>
     *
     * @param intelligentFabricMigrationMethod a <code>IntelligentFabricMigrationMethod</code> providing the value for
     * "Intelligent Fabric Migration Method" property.
     */
    public void setIntelligentFabricMigrationMethod(IntelligentFabricMigrationMethod intelligentFabricMigrationMethod) {
        this.intelligentFabricMigrationMethod = intelligentFabricMigrationMethod;
    }
}

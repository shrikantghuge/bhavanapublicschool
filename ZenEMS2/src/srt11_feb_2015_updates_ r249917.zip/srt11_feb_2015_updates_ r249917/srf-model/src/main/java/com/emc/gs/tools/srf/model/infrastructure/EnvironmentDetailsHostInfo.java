/*
 * This code is copyright (c) 2014 EMC Corporation.
 */
package com.emc.gs.tools.srf.model.infrastructure;

import com.emc.gs.tools.srf.model.IdentifiableEntity;

/**
 * <p>
 * This is host information for EnvironmentDetailsInformation entity.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safety.
 * </p>
 *
 * <p>
 * Version 1.1 Change notes:
 *   <ol>
 *     <li>Added {@link #platform} property.</li>
 *   </ol>
 * </p>
 * 
 * @author liuliquan, isv
 * @version 1.1
 */
public class EnvironmentDetailsHostInfo extends IdentifiableEntity {

    /**
     * <p>A <code>String</code> providing the value for platform property.</p>
     * 
     * @since 1.1
     */
    private String platform; 

    /**
     * <p>
     * The hostNumber.
     * </p>
     */
    private Integer hostNumber;

    /**
     * <p>
     * The newHostNumber.
     * </p>
     */
    private Integer newHostNumber;

    /**
     * <p>
     * The numberOfClusters.
     * </p>
     */
    private Integer numberOfClusters;

    /**
     * <p>
     * The numberBootFromSan.
     * </p>
     */
    private Integer numberBootFromSan;

    /**
     * <p>
     * The arrayHostAttachedTo.
     * </p>
     */
    private String arrayHostAttachedTo;

    /**
     * Empty constructor.
     */
    public EnvironmentDetailsHostInfo() {
    }

    /**
     * Getter method for property <tt>hostNumber</tt>.
     * @return property value of hostNumber
     */
    public Integer getHostNumber() {
        return hostNumber;
    }

    /**
     * Setter method for property <tt>hostNumber</tt>.
     * @param hostNumber
     *            value to be assigned to property hostNumber
     */
    public void setHostNumber(Integer hostNumber) {
        this.hostNumber = hostNumber;
    }

    /**
     * Getter method for property <tt>newHostNumber</tt>.
     * @return property value of newHostNumber
     */
    public Integer getNewHostNumber() {
        return newHostNumber;
    }

    /**
     * Setter method for property <tt>newHostNumber</tt>.
     * @param newHostNumber
     *            value to be assigned to property newHostNumber
     */
    public void setNewHostNumber(Integer newHostNumber) {
        this.newHostNumber = newHostNumber;
    }

    /**
     * Getter method for property <tt>numberOfClusters</tt>.
     * @return property value of numberOfClusters
     */
    public Integer getNumberOfClusters() {
        return numberOfClusters;
    }

    /**
     * Setter method for property <tt>numberOfClusters</tt>.
     * @param numberOfClusters
     *            value to be assigned to property numberOfClusters
     */
    public void setNumberOfClusters(Integer numberOfClusters) {
        this.numberOfClusters = numberOfClusters;
    }

    /**
     * Getter method for property <tt>numberBootFromSan</tt>.
     * @return property value of numberBootFromSan
     */
    public Integer getNumberBootFromSan() {
        return numberBootFromSan;
    }

    /**
     * Setter method for property <tt>numberBootFromSan</tt>.
     * @param numberBootFromSan
     *            value to be assigned to property numberBootFromSan
     */
    public void setNumberBootFromSan(Integer numberBootFromSan) {
        this.numberBootFromSan = numberBootFromSan;
    }

    /**
     * Getter method for property <tt>arrayHostAttachedTo</tt>.
     * @return property value of arrayHostAttachedTo
     */
    public String getArrayHostAttachedTo() {
        return arrayHostAttachedTo;
    }

    /**
     * Setter method for property <tt>arrayHostAttachedTo</tt>.
     * @param arrayHostAttachedTo
     *            value to be assigned to property arrayHostAttachedTo
     */
    public void setArrayHostAttachedTo(String arrayHostAttachedTo) {
        this.arrayHostAttachedTo = arrayHostAttachedTo;
    }

    /**
     * <p>Gets the platform property.</p>
     *
     * @return a <code>String</code> providing the value for platform property.
     * @since 1.1
     */
    public String getPlatform() {
        return this.platform;
    }

    /**
     * <p>Sets the platform property.</p>
     *
     * @param platform a <code>String</code> providing the value for platform property.
     * @since 1.1
     */
    public void setPlatform(String platform) {
        this.platform = platform;
    }

    /**
     * The toString method.
     * @return the string for this entity
     */
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("{");
        sb.append("platform:").append(platform);
        sb.append(", newHostNumber:").append(newHostNumber);
        sb.append(", numberOfClusters:").append(numberOfClusters);
        sb.append(", numberBootFromSan:").append(numberBootFromSan);
        sb.append(", hostNumber:").append(hostNumber);
        sb.append(", arrayHostAttachedTo:").append(arrayHostAttachedTo).append("}");
        return sb.toString();
    }
}

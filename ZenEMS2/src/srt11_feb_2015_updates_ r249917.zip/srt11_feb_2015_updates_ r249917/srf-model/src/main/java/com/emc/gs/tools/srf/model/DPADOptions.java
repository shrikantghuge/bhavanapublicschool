/*
 * This code is copyright (c) 2014 EMC Corporation.
 */
package com.emc.gs.tools.srf.model;

/**
 * <p>
 * This is DPADOptions entity class.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safety.
 * </p>
 * 
 * <p>
 * <strong>Changes V1.1:</strong>
 * <strong>SRT Phase 3-5 - BRS Tabs Part 1 Assembly</strong>
 * <ul>
 * <li>Add dpa/recoverPoint fields.</li>
 * </ul>
 * </p>
 * 
 * @author liuliquan, TCSASSEMBLER
 * @version 1.1
 */
public class DPADOptions extends IdentifiableEntity {

    /**
     * <p>
     * The avamar.
     * </p>
     */
    private boolean avamar;

    /**
     * <p>
     * The sourceOne.
     * </p>
     */
    private boolean sourceOne;

    /**
     * <p>
     * The dataDomain.
     * </p>
     */
    private boolean dataDomain;

    /**
     * <p>
     * The networker.
     * </p>
     */
    private boolean networker;

    /**
     * <p>
     * The edl.
     * </p>
     */
    private boolean edl;

    /**
     * <p>
     * The mozy.
     * </p>
     */
    private boolean mozy;

    /**
     * <p>
     * The dlm.
     * </p>
     */
    private boolean dlm;

    /**
     * <p>
     * The dpa.
     * </p>
     * @since SRT Phase 3-5 - BRS Tabs Part 1 Assembly
     */
    private boolean dpa;

    /**
     * <p>
     * The recoverPoint.
     * </p>
     * @since SRT Phase 3-5 - BRS Tabs Part 1 Assembly
     */
    private boolean recoverPoint;

    /**
     * Empty constructor.
     */
    public DPADOptions() {
    }

    /**
     * Getter method for property <tt>avamar</tt>.
     * @return property value of avamar
     */
    public boolean isAvamar() {
        return avamar;
    }

    /**
     * Setter method for property <tt>avamar</tt>.
     * @param avamar
     *            value to be assigned to property avamar
     */
    public void setAvamar(boolean avamar) {
        this.avamar = avamar;
    }

    /**
     * Getter method for property <tt>sourceOne</tt>.
     * @return property value of sourceOne
     */
    public boolean isSourceOne() {
        return sourceOne;
    }

    /**
     * Setter method for property <tt>sourceOne</tt>.
     * @param sourceOne
     *            value to be assigned to property sourceOne
     */
    public void setSourceOne(boolean sourceOne) {
        this.sourceOne = sourceOne;
    }

    /**
     * Getter method for property <tt>dataDomain</tt>.
     * @return property value of dataDomain
     */
    public boolean isDataDomain() {
        return dataDomain;
    }

    /**
     * Setter method for property <tt>dataDomain</tt>.
     * @param dataDomain
     *            value to be assigned to property dataDomain
     */
    public void setDataDomain(boolean dataDomain) {
        this.dataDomain = dataDomain;
    }

    /**
     * Getter method for property <tt>networker</tt>.
     * @return property value of networker
     */
    public boolean isNetworker() {
        return networker;
    }

    /**
     * Setter method for property <tt>networker</tt>.
     * @param networker
     *            value to be assigned to property networker
     */
    public void setNetworker(boolean networker) {
        this.networker = networker;
    }

    /**
     * Getter method for property <tt>edl</tt>.
     * @return property value of edl
     */
    public boolean isEdl() {
        return edl;
    }

    /**
     * Setter method for property <tt>edl</tt>.
     * @param edl
     *            value to be assigned to property edl
     */
    public void setEdl(boolean edl) {
        this.edl = edl;
    }

    /**
     * Getter method for property <tt>mozy</tt>.
     * @return property value of mozy
     */
    public boolean isMozy() {
        return mozy;
    }

    /**
     * Setter method for property <tt>mozy</tt>.
     * @param mozy
     *            value to be assigned to property mozy
     */
    public void setMozy(boolean mozy) {
        this.mozy = mozy;
    }

    /**
     * Getter method for property <tt>dlm</tt>.
     * @return property value of dlm
     */
    public boolean isDlm() {
        return dlm;
    }

    /**
     * Setter method for property <tt>dlm</tt>.
     * @param dlm
     *            value to be assigned to property dlm
     */
    public void setDlm(boolean dlm) {
        this.dlm = dlm;
    }

    /**
     * Getter method for property <tt>dpa</tt>.
     * 
     * @return property value of dpa
     * @since SRT Phase 3-5 - BRS Tabs Part 1 Assembly
     */
    public boolean isDpa() {
        return dpa;
    }

    /**
     * Setter method for property <tt>dpa</tt>.
     * 
     * @param dpa
     *            value to be assigned to property dpa
     * @since SRT Phase 3-5 - BRS Tabs Part 1 Assembly
     */
    public void setDpa(boolean dpa) {
        this.dpa = dpa;
    }

    /**
     * Getter method for property <tt>recoverPoint</tt>.
     * 
     * @return property value of recoverPoint
     * @since SRT Phase 3-5 - BRS Tabs Part 1 Assembly
     */
    public boolean isRecoverPoint() {
        return recoverPoint;
    }

    /**
     * Setter method for property <tt>recoverPoint</tt>.
     * 
     * @param recoverPoint
     *            value to be assigned to property recoverPoint
     * @since SRT Phase 3-5 - BRS Tabs Part 1 Assembly
     */
    public void setRecoverPoint(boolean recoverPoint) {
        this.recoverPoint = recoverPoint;
    }

    /**
     * The toString method.
     * @return the string for this entity
     */
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("{").append(super.toString());
        sb.append(", avamar:").append(avamar);
        sb.append(", sourceOne:").append(sourceOne);
        sb.append(", dataDomain:").append(dataDomain);
        sb.append(", networker:").append(networker);
        sb.append(", edl:").append(edl);
        sb.append(", mozy:").append(mozy);
        sb.append(", dpa:").append(dpa);
        sb.append(", recoverPoint:").append(recoverPoint);
        sb.append(", dlm:").append(dlm).append("}");
        return sb.toString();
    }
}

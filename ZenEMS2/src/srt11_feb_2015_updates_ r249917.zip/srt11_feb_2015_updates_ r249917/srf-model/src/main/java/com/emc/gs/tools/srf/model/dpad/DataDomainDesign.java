/*
 * This code is copyright (c) 2014 EMC Corporation
 */
package com.emc.gs.tools.srf.model.dpad;

import java.util.Map;

import com.emc.gs.tools.srf.model.IdentifiableEntity;

/**
 * <p>
 * This is DataDomainDesign entity class.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safety.
 * </p>
 *
 * <p>
 * Version 1.1 (SRT 4 OCT2014 Updates Part 1 Assembly) Change notes:
 *   <ol>
 *     <li>Removed <code>ddrsNum</code> property.</li>
 *     <li>Removed <code>mtreesNum</code> property.</li>
 *     <li>Expanded DataDomainDesign entity with same set of properties as DataDomainImplementation entity.</li>
 *   </ol>
 * </p>
 * 
 * @author isv
 * @version 1.1
 * @since SRT Phase 3-5 - BRS Tabs Part 2 Assembly
 */
public class DataDomainDesign extends DataDomainImplBase {

    /**
     * Data Domain Appliance Models that are part of the engagement.
     */
    private Map<String, DataDomainDesignApplianceModel> applianceModels;

    /**
     * <p>
     * The default constructor.
     * </p>
     */
    public DataDomainDesign() {
    }

    /**
     * Getter method for property <tt>applianceModels</tt>.
     * 
     * @return property value of applianceModels
     */
    public Map<String, DataDomainDesignApplianceModel> getApplianceModels() {
        return applianceModels;
    }

    /**
     * Setter method for property <tt>applianceModels</tt>.
     * 
     * @param applianceModels
     *            value to be assigned to property applianceModels
     */
    public void setApplianceModels(Map<String, DataDomainDesignApplianceModel> applianceModels) {
        this.applianceModels = applianceModels;
    }
}

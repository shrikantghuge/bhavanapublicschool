/*
 * This code is copyright (c) 2014 EMC Corporation
 */
package com.emc.gs.tools.srf.model.atmos;

import java.util.ArrayList;
import java.util.List;

import com.emc.gs.tools.srf.model.IdentifiableEntity;

/**
 * <p>
 * This is CenteraDesignImpl entity class.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safety.
 * </p>
 * 
 * @author TCSASSEMBLER
 * @version 1.0
 * @since SRT Phase 3-1 - Atmos Centera and Vblock Tabs Assembly
 */
public class CenteraDesignImpl extends IdentifiableEntity {

    /**
     * Do any (in-Scope) Centeras exist in the environment?
     */
    private Boolean centerasExist;

    /**
     * Does the existing Centeras require an Architecture Review?
     */
    private Boolean existingCenterasRequireReview;

    /**
     * Existing centeras review detail.
     */
    private String existingCenterasReviewDetail;

    /**
     * Provide detail for any hardware repurposing.
     */
    private String hardwareRepurposingDetail;

    /**
     * Provide detail for any array/cluster relocation.
     */
    private String arrayRelocationDetail;

    /**
     * Who arranges shipping for relocation?
     */
    private CenteraShippingArranger shippingArranger;

    /**
     * Does EMC need to develop code for new home-grown applications to connect to Centera?
     */
    private Boolean needDevelopCode;

    /**
     * Develop code detail.
     */
    private String developCodeDetail;

    /**
     * Are there custom scripting or reporting requirements?
     */
    private Boolean customScripting;

    /**
     * Custom scripting detail.
     */
    private String customScriptingDetail;

    /**
     * Define the customers expected timeline.
     */
    private String expectedTimeline;

    /**
     * Is there Centera replication today, or are we adding a replica?
     */
    private CenteraReplicationType replicationType;

    /**
     * Will Tape Backup of Centera be implemented?
     */
    private Boolean implementTapeBackup;

    /**
     * Existing In-Scope New Centeras / Clusters.
     */
    private List<ExistingCenteraCluster> existingClusters = new ArrayList<ExistingCenteraCluster>();

    /**
     * New Centeras / Clusters.
     */
    private List<NewCenteraCluster> newClusters = new ArrayList<NewCenteraCluster>();

    /**
     * <p>
     * The default constructor.
     * </p>
     */
    public CenteraDesignImpl() {
    }

    /**
     * Getter method for property <tt>centerasExist</tt>.
     * 
     * @return property value of centerasExist
     */
    public Boolean getCenterasExist() {
        return centerasExist;
    }

    /**
     * Setter method for property <tt>centerasExist</tt>.
     * 
     * @param centerasExist
     *            value to be assigned to property centerasExist
     */
    public void setCenterasExist(Boolean centerasExist) {
        this.centerasExist = centerasExist;
    }

    /**
     * Getter method for property <tt>existingCenterasRequireReview</tt>.
     * 
     * @return property value of existingCenterasRequireReview
     */
    public Boolean getExistingCenterasRequireReview() {
        return existingCenterasRequireReview;
    }

    /**
     * Setter method for property <tt>existingCenterasRequireReview</tt>.
     * 
     * @param existingCenterasRequireReview
     *            value to be assigned to property existingCenterasRequireReview
     */
    public void setExistingCenterasRequireReview(Boolean existingCenterasRequireReview) {
        this.existingCenterasRequireReview = existingCenterasRequireReview;
    }

    /**
     * Getter method for property <tt>existingCenterasReviewDetail</tt>.
     * 
     * @return property value of existingCenterasReviewDetail
     */
    public String getExistingCenterasReviewDetail() {
        return existingCenterasReviewDetail;
    }

    /**
     * Setter method for property <tt>existingCenterasReviewDetail</tt>.
     * 
     * @param existingCenterasReviewDetail
     *            value to be assigned to property existingCenterasReviewDetail
     */
    public void setExistingCenterasReviewDetail(String existingCenterasReviewDetail) {
        this.existingCenterasReviewDetail = existingCenterasReviewDetail;
    }

    /**
     * Getter method for property <tt>hardwareRepurposingDetail</tt>.
     * 
     * @return property value of hardwareRepurposingDetail
     */
    public String getHardwareRepurposingDetail() {
        return hardwareRepurposingDetail;
    }

    /**
     * Setter method for property <tt>hardwareRepurposingDetail</tt>.
     * 
     * @param hardwareRepurposingDetail
     *            value to be assigned to property hardwareRepurposingDetail
     */
    public void setHardwareRepurposingDetail(String hardwareRepurposingDetail) {
        this.hardwareRepurposingDetail = hardwareRepurposingDetail;
    }

    /**
     * Getter method for property <tt>arrayRelocationDetail</tt>.
     * 
     * @return property value of arrayRelocationDetail
     */
    public String getArrayRelocationDetail() {
        return arrayRelocationDetail;
    }

    /**
     * Setter method for property <tt>arrayRelocationDetail</tt>.
     * 
     * @param arrayRelocationDetail
     *            value to be assigned to property arrayRelocationDetail
     */
    public void setArrayRelocationDetail(String arrayRelocationDetail) {
        this.arrayRelocationDetail = arrayRelocationDetail;
    }

    /**
     * Getter method for property <tt>shippingArranger</tt>.
     * 
     * @return property value of shippingArranger
     */
    public CenteraShippingArranger getShippingArranger() {
        return shippingArranger;
    }

    /**
     * Setter method for property <tt>shippingArranger</tt>.
     * 
     * @param shippingArranger
     *            value to be assigned to property shippingArranger
     */
    public void setShippingArranger(CenteraShippingArranger shippingArranger) {
        this.shippingArranger = shippingArranger;
    }

    /**
     * Getter method for property <tt>needDevelopCode</tt>.
     * 
     * @return property value of needDevelopCode
     */
    public Boolean getNeedDevelopCode() {
        return needDevelopCode;
    }

    /**
     * Setter method for property <tt>needDevelopCode</tt>.
     * 
     * @param needDevelopCode
     *            value to be assigned to property needDevelopCode
     */
    public void setNeedDevelopCode(Boolean needDevelopCode) {
        this.needDevelopCode = needDevelopCode;
    }

    /**
     * Getter method for property <tt>developCodeDetail</tt>.
     * 
     * @return property value of developCodeDetail
     */
    public String getDevelopCodeDetail() {
        return developCodeDetail;
    }

    /**
     * Setter method for property <tt>developCodeDetail</tt>.
     * 
     * @param developCodeDetail
     *            value to be assigned to property developCodeDetail
     */
    public void setDevelopCodeDetail(String developCodeDetail) {
        this.developCodeDetail = developCodeDetail;
    }

    /**
     * Getter method for property <tt>customScripting</tt>.
     * 
     * @return property value of customScripting
     */
    public Boolean getCustomScripting() {
        return customScripting;
    }

    /**
     * Setter method for property <tt>customScripting</tt>.
     * 
     * @param customScripting
     *            value to be assigned to property customScripting
     */
    public void setCustomScripting(Boolean customScripting) {
        this.customScripting = customScripting;
    }

    /**
     * Getter method for property <tt>customScriptingDetail</tt>.
     * 
     * @return property value of customScriptingDetail
     */
    public String getCustomScriptingDetail() {
        return customScriptingDetail;
    }

    /**
     * Setter method for property <tt>customScriptingDetail</tt>.
     * 
     * @param customScriptingDetail
     *            value to be assigned to property customScriptingDetail
     */
    public void setCustomScriptingDetail(String customScriptingDetail) {
        this.customScriptingDetail = customScriptingDetail;
    }

    /**
     * Getter method for property <tt>expectedTimeline</tt>.
     * 
     * @return property value of expectedTimeline
     */
    public String getExpectedTimeline() {
        return expectedTimeline;
    }

    /**
     * Setter method for property <tt>expectedTimeline</tt>.
     * 
     * @param expectedTimeline
     *            value to be assigned to property expectedTimeline
     */
    public void setExpectedTimeline(String expectedTimeline) {
        this.expectedTimeline = expectedTimeline;
    }

    /**
     * Getter method for property <tt>replicationType</tt>.
     * 
     * @return property value of replicationType
     */
    public CenteraReplicationType getReplicationType() {
        return replicationType;
    }

    /**
     * Setter method for property <tt>replicationType</tt>.
     * 
     * @param replicationType
     *            value to be assigned to property replicationType
     */
    public void setReplicationType(CenteraReplicationType replicationType) {
        this.replicationType = replicationType;
    }

    /**
     * Getter method for property <tt>implementTapeBackup</tt>.
     * 
     * @return property value of implementTapeBackup
     */
    public Boolean getImplementTapeBackup() {
        return implementTapeBackup;
    }

    /**
     * Setter method for property <tt>implementTapeBackup</tt>.
     * 
     * @param implementTapeBackup
     *            value to be assigned to property implementTapeBackup
     */
    public void setImplementTapeBackup(Boolean implementTapeBackup) {
        this.implementTapeBackup = implementTapeBackup;
    }

    /**
     * Getter method for property <tt>existingClusters</tt>.
     * 
     * @return property value of existingClusters
     */
    public List<ExistingCenteraCluster> getExistingClusters() {
        return existingClusters;
    }

    /**
     * Setter method for property <tt>existingClusters</tt>.
     * 
     * @param existingClusters
     *            value to be assigned to property existingClusters
     */
    public void setExistingClusters(List<ExistingCenteraCluster> existingClusters) {
        this.existingClusters = existingClusters;
    }

    /**
     * Getter method for property <tt>newClusters</tt>.
     * 
     * @return property value of newClusters
     */
    public List<NewCenteraCluster> getNewClusters() {
        return newClusters;
    }

    /**
     * Setter method for property <tt>newClusters</tt>.
     * 
     * @param newClusters
     *            value to be assigned to property newClusters
     */
    public void setNewClusters(List<NewCenteraCluster> newClusters) {
        this.newClusters = newClusters;
    }

}

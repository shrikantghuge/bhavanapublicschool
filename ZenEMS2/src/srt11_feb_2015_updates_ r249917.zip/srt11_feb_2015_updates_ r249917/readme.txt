Development Scripts Usage
==========================

1. Start Cloud App Test Server using Oracle database

Un-comment <resource-ref> element for Oracle datasource in srf-webapp/src/main/webapp/WEB-INF/web.xml
The value of <res-ref-name> element must match the value of <datasource.jndi.name> element in "oracle"
profile in srf-cloud-app/pom.xml file. 

./StartCloudOracleTest.sh or StartCloudOracleTest.bat
This will start an embedded Tomcat server at port 9090. The Oracle database will be automatically setup.

TIP: If you do not want to automatically setup Oracle, then include the “-DskipDB=true” argument:
./StartCloudOracleTest.sh -DskipDB=true or StartCloudOracleTest.bat -DskipDB=true


2. Start Cloud App Test Server using PostgreSQL database

Un-comment <resource-ref> element for PostgreSQL datasource in srf-webapp/src/main/webapp/WEB-INF/web.xml 
The value of <res-ref-name> element must match the value of <datasource.jndi.name> element in "postgresql"
profile in srf-cloud-app/pom.xml file. 

./StartCloudPostgresqlTest.sh or StartCloudPostgresqlTest.bat
This will start an embedded Tomcat server at port 9090. The Postgresql database will be automatically setup.

TIP: If you do not want to automatically setup Postgresql, then include the “-DskipDB=true” argument:
./StartCloudPostgresqlTest.sh -DskipDB=true or StartCloudPostgresqlTest.bat -DskipDB=true


3. Start Local App Test Server

Comment out <resource-ref> elements in srf-webapp/src/main/webapp/WEB-INF/web.xml 

./StartLocalTest.sh or StartLocalTest.bat
This will start an embedded Jetty server at port 8081. The H2 database will be automatically setup.


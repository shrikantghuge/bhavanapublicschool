/*
 * This code is copyright (c) 2013 - 2014 EMC Corporation.
 */
package com.emc.gs.tools.srf.services;

/**
 * <p>
 * This exception is thrown when entity is not found in the persistence.
 * </p>
 *
 * <p>
 * <strong>Thread safety</strong>: exception class is not thread safety.
 * </p>
 *
 * <p>
 * <strong>Changes V1.1:</strong>
 * <strong>SRT Phase 4 - ET Assembly 3</strong>
 * <ul>
 * <li>added ENTITY_NOT_FOUND_PREFIX. Used to differentiate a general 404 or a 404 for entity not found.</li>
 * </ul>
 * </p>
 *
 * @author faeton, stevenfrog, TCSASSEMBLER
 * @version 1.1
 */
public class EntityNotFoundException extends ServiceRequestToolException {

    /**
     * This prefix will be prepended to the message in the http status message.
     */
    public static final String ENTITY_NOT_FOUND_PREFIX = "Entity not found. ";

    /**
     * The serial version UID.
     */
    private static final long serialVersionUID = -6814175520769929496L;

    /**
     * Creates the exception with the provided message.
     *
     * @param message
     *            the error message.
     */
    public EntityNotFoundException(String message) {
        super(message);
    }

    /**
     * Creates the exception with the provided message and cause.
     *
     * @param message
     *            the error message.
     * @param cause
     *            the error cause.
     */
    public EntityNotFoundException(String message, Throwable cause) {
        super(message, cause);
    }
}

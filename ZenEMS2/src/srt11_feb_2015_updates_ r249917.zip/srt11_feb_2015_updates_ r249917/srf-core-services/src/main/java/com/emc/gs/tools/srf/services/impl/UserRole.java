/*
 * This code is copyright (c) 2015 EMC Corporation.
 */
package com.emc.gs.tools.srf.services.impl;

/**
 * Represents the user role enumeration
 *
 * <p>
 * Version 1.1 Change notes:
 *   <ol>
 *     <li>Added {@link #TEMPLATE_FOLDER_EDITOR} item.</li>
 *   </ol>
 * </p>
 *
 * <p>
 * Version 1.2 Change notes:
 *   <ol>
 *     <li>Removed <code>SUBMITTER</code> role.</li>
 *   </ol>
 * </p>
 * 
 * @author MonicaMuranyi, isv
 * @version 1.2
 * @since SRT 1.1 Approval Process Assembly.
 */
public enum UserRole {
    /**
     * <p>
     * The APPROVER role.
     * </p>
     */
    APPROVER ("approver"),

    /**
     * <p> The TEMPLATE_FOLDER_EDITOR role. </p>
     * 
     * @since 1.1
     */
    TEMPLATE_FOLDER_EDITOR("templatePermission");

    /**
     * <p>
     * The name.
     * </p>
     */
    private final String name;       

    /**
     * Constructor
     * @param name The name of the role
     */
    private UserRole(String name) {
        this.name = name;
    }

    /**
     * <p>
     * Retrieves the name field.
     * </p>
     *
     * @return the name
     */
    public String getName() {
        return name;
    }
}

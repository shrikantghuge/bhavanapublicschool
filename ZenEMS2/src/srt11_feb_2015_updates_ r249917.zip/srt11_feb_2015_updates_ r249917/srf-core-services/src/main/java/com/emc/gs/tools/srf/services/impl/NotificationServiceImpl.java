/*
 * This code is copyright (c) 2013 - 2015 EMC Corporation.
 */
package com.emc.gs.tools.srf.services.impl;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.StringWriter;
import java.text.SimpleDateFormat;
import java.util.List;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.annotation.PostConstruct;
import javax.mail.MessagingException;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeUtility;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.apache.velocity.Template;
import org.apache.velocity.VelocityContext;
import org.apache.velocity.app.VelocityEngine;
import org.springframework.mail.MailException;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;

import com.emc.gs.tools.srf.model.Attachment;
import com.emc.gs.tools.srf.model.Customer;
import com.emc.gs.tools.srf.model.Division;
import com.emc.gs.tools.srf.model.Profile;
import com.emc.gs.tools.srf.model.Request;
import com.emc.gs.tools.srf.model.SalesDistrict;
import com.emc.gs.tools.srf.model.StartRequestData;
import com.emc.gs.tools.srf.model.engagement.SRTPath;
import com.emc.gs.tools.srf.services.AppService;
import com.emc.gs.tools.srf.services.MailSenderFactory;
import com.emc.gs.tools.srf.services.NotificationService;
import com.emc.gs.tools.srf.services.NotificationServiceException;
import com.emc.gs.tools.srf.services.SubmitResult;

/**
 * <p>
 * This class is the implementation of the NotificationService. It utilizes Java Mail API for necessary
 * operations.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is effectively thread safe after configuration, the
 * configuration is done in a thread safe manner.
 * </p>
 *
 * <p>
 * <strong>Changes:</strong>
 * <strong>SRT Release Assembly - Base</strong>
 * <ul>
 * <li>Fixed district, area and PDM</li>
 * <li>Allowed blank username to skip authentication</li>
 * </ul>
 * </p>
 * 
 * <p>
 * <strong>Changes V1.7:</strong>
 * <strong>SRT Bug Bixes - F157, F158, F159, F160, F161</strong>
 * <ul>
 * <li>Changed sendRequest() method to set the "From" field to "fromEmailAddress" field from profile.</li>
 * </ul>
 * </p>
 * 
 * <p>
 * <strong>Changes V1.8:</strong>
 * <ul>
 * <li>Removed shortName field related logic.</li>
 * </ul>
 * </p>
 *
 * <p>
 * <strong>Changes V1.9:</strong>
 * <strong>SRT Phase 2 Release Assembly</strong>
 * <ul>
 * <li>Add smtpHost/smtpPort config fields</li>
 * </ul>
 * </p>
 *
 * <p>
 * <strong>Change 1.10:</strong>
 * <strong>SRT Cloud Synchronization - Cloud App Assembly</strong>
 * <ul>
 * <li>changed service to use jndi injected mailSender</li>
 * <li>changed sendRequest to use these new field</li>
 * <li>updated checkInit() to validate new fields</li>
 * </ul>
 * </p>
 *
 * <p>
 * <strong>Changes V1.11:</strong>
 * <strong>SRT Phase 4 - ET Assembly 1</strong>
 * <ul>
 * <li>Add support for Phase 4 request.</li>
 * </ul>
 * </p>
 *
 * <p>
 * Version 1.11 (SRT Phase 3 Pilot - Mozy and Xtrem and Vipr Tabs Assembly) Change notes:
 *   <ol>
 *     <li>Updated {@link #getPhase3Context(Request)} method to set tcName and tcPhone placeholders with valid values.
 *     </li>
 *   </ol>
 * </p>
 *
 * <p>
 * <strong>Changes V1.12:</strong>
 * <strong>SRT Phase 4 - ET Assembly 2</strong>
 * <ul>
 * <li>Use MailSenderFactory to create mail sender.</li>
 * </ul>
 * </p>
 *
 * <p>
 * Version 1.13 Change notes:
 *   <ol>
 *     <li>Updated {@link #sendRequest(Request, File, Profile)} method to send emails based on latest clarifications
 *     from client.</li>
 *   </ol>
 * </p>
 *
 * <p>
 * Version 1.14 Change notes:
 *   <ol>
 *     <li>Removed <code>testSubmitEmailAddress</code> property from profile.</li>
 *     <li>Removed <code>emailOptions</code> property from profile.</li>
 *   </ol>
 * </p>
 * 
 * <p>
 * Version 1.15 Change notes:
 * <ol>
 * <li>Added <code>approvalEmailBodyTemplate</code> field.</li>
 * <li>Added <code>emailSubjectApproval</code> field.</li>
 * <li>Added <code>cloudServiceUrlBase</code> field.</li>
 * <li>Added <code>appService</code> field.</li>
 * <li>Added <code>sendRequestApprovalEmails</code> method.</li>
 * <li>Added <code>getApprovalEmailContext</code> method.</li>
 * </ol>
 * </p>
 *
 * <p>
 * Version 1.16 Change notes:
 *   <ol>
 *     <li>Updated {@link #sendRequest(Request, File, Profile, File)} method to send email to sales district's instead
 *     of division's mailbox (if former is set).</li>
 *     <li>Updated {@link #sendRequest(Request, File, Profile, File)} and
 *     {@link #sendRequestApprovalEmail(String, String, Request, File, Profile)} to include project name into name of
 *     generated PDF file.</li>
 *     <li>Updated {@link #sendRequest(Request, File, Profile, File)} method to skip sending email to SQC for Service
 *     Led deals.</li>
 *   </ol>
 * </p>
 * 
 * @author faeton, stevenfrog, isv, MonicaMuranyi
 * @version 1.16
 */
public class NotificationServiceImpl extends BaseLoggerService implements NotificationService {
    /**
     * <p>
     * Represents the class name.
     * </p>
     */
    private static final String CLASSNAME = NotificationServiceImpl.class.getName();

    /**
     * Represents the VelocityEngine instance used to render the email body template. It is modified by
     * setter. It is injected by Spring. It can not be null after injected.
     */
    private VelocityEngine velocityEngine;

    /**
     * Represents the upload folder for attachments. It is modified by setter. It is injected by Spring.
     * It can not be null or empty after injected.
     */
    private String attachmentUploadFolder;

    /**
     * Represents the path to email body template. It is modified by setter. It is injected by Spring. It can
     * not be null after injected.
     */
    private String emailBodyTemplate;
    
    /**
     * Represents the path to approval email body template. It is modified by setter. It is injected by Spring. 
     * It can not be null after injected.
     * @since 1.15
     */
    private String approvalEmailBodyTemplate;

    /**
     * Represents the attachment filename. It is modified by setter. It is injected by Spring. It can not be
     * null after injected.
     */
    private String attachmentFilename;

    /**
     * Represents the path to email body template for phase 4 request. It is modified by setter. It is injected by
     * Spring. It can not be null after injected.
     */
    private String emailBodyTemplatePhase4;

    /**
     * Represents the path to email recipient for phase 4 request. It is modified by setter. It is injected by
     * Spring. It can not be null after injected.
     */
    private String emailRecipientPhase4;

    /**
     * Represents the path to email subject for phase 4 request. It is modified by setter. It is injected by
     * Spring. It can not be null after injected.
     */
    private String emailSubjectPhase4;
    
    /**
     * Represents the path to email subject for approval. It is modified by setter. It is injected by Spring. 
     * It can not be null after injected.
     * @since 1.15
     */
    private String emailSubjectApproval;

    /**
     * Represents the attachment filename for phase 4 request. It is modified by setter. It is injected by Spring. It
     * can not be null after injected.
     */
    private String attachmentFilenamePhase4;

    /**
     * Represents the mail sender factory. It is modified by setter. It is injected by Spring. It
     * can not be null after injected.
     * @since SRT Phase 4 - ET Assembly 2
     */
    private MailSenderFactory mailSenderFactory;
    
    /**
     * Represents the cloud service URL base. It is modified by setter. It is injected by Spring. It can not be null 
     * after injected.
     * @since 1.15
     */
    private String cloudServiceUrlBase;
 
    /**
     * Represents the appService. It is modified by setter. It is injected by Spring. It can not be null after injected.
     * @since 1.15
     */
    private AppService appService;

    /**
     * Creates instance of the class.
     */
    public NotificationServiceImpl() {
        // Empty
    }

    /**
     * This method checks whether the instance of the class was initialized properly.
     *
     * @throws com.emc.gs.tools.srf.ServiceRequestToolConfigurationException
     *             if velocityEngine is null, attachmentUploadFolder/emailBodyTemplate/emailRecipient/attachmentFilename
     *             /emailBodyTemplatePhase4/emailSubjectPhase4/emailRecipientPhase4/attachmentFilenamePhase4 is null/empty,
     *             mailSenderFactory is null
     */
    @PostConstruct
    protected void checkInit() {
        Helper.checkState(velocityEngine == null, "'velocityEngine' can't be null.");
        Helper.checkState(mailSenderFactory == null, "'mailSenderFactory' can't be null.");
        Helper.checkState(appService == null, "'appService' can't be null.");
        Helper.checkState(Helper.isStringNullOrEmpty(attachmentUploadFolder),
                "'attachmentUploadFolder' can't be null/empty.");
        Helper.checkState(Helper.isStringNullOrEmpty(emailBodyTemplate),
                "'emailBodyTemplate' can't be null/empty.");
        Helper.checkState(Helper.isStringNullOrEmpty(approvalEmailBodyTemplate),
                "'approvalEmailBodyTemplate' can't be null/empty.");
        Helper.checkState(Helper.isStringNullOrEmpty(approvalEmailBodyTemplate),
                "'approvalEmailBodyTemplate' can't be null/empty.");
        Helper.checkState(Helper.isStringNullOrEmpty(attachmentFilename),
                "'attachmentFilename' can't be null/empty.");
        Helper.checkState(Helper.isStringNullOrEmpty(emailBodyTemplatePhase4),
                "'emailBodyTemplatePhase4' can't be null/empty.");
        Helper.checkState(Helper.isStringNullOrEmpty(emailSubjectPhase4),
                "'emailSubjectPhase4' can't be null/empty.");
        Helper.checkState(Helper.isStringNullOrEmpty(emailSubjectApproval),
                "'emailSubjectApproval' can't be null/empty.");
        Helper.checkState(Helper.isStringNullOrEmpty(emailRecipientPhase4),
                "'emailRecipientPhase4' can't be null/empty.");
        Helper.checkState(Helper.isStringNullOrEmpty(attachmentFilenamePhase4),
                "'attachmentFilenamePhase4' can't be null/empty.");
        Helper.checkState(Helper.isStringNullOrEmpty(cloudServiceUrlBase), 
                "'cloudServiceUrlBase' can't be null/empty.");
    }

    /**
     * This method is used to send the request to the sender.
     *
     * @param exportedRequest
     *            the PDF file of exported request. It is set as an attachment.
     * @param request
     *            the Request object to be send. It is used to generate the email body
     * @param profile
     *            the profile instance holding information necessary to send email
     * @param additionalFile additional file to attach.           
     * @throws IllegalArgumentException
     *             request/exportedRequest/profile is null.
     * @throws com.emc.gs.tools.srf.services.NotificationServiceException
     *             if there is any problem when performing operation.
     */
    public void sendRequest(Request request, File exportedRequest, Profile profile, File additionalFile)
        throws NotificationServiceException {
        final String signature = CLASSNAME
            + "#sendRequest(Request request, File exportedRequest, Profile profile)";
        Logger logger = getLogger();

        // Log entry
        Helper.logEntrance(logger, signature, new String[]{"request", "exportedRequest", "profile", "additionalFile"},
                new Object[]{request, exportedRequest, profile, additionalFile});

        Helper.checkNull(logger, signature, request, "request");
        Helper.checkNull(logger, signature, exportedRequest, "exportedRequest");
        Helper.checkNull(logger, signature, profile, "profile");

        boolean phase4 = request.getEngagementTypeData() != null
                && request.getEngagementTypeData().calculateSRTPath() == SRTPath.SRT4;
        boolean isServiceLedDeal = request.getEngagementTypeData() != null
            && request.getEngagementTypeData().isServiceLead();


        try {
            // Render message with Velocity
            Template template = velocityEngine.getTemplate(phase4 ? emailBodyTemplatePhase4 : emailBodyTemplate);

            // Put necessary data
            // Merge the template and convert to string
            StringWriter sw = new StringWriter();
            VelocityContext context = phase4 ? getPhase4Context(request) : getPhase3Context(request);
            template.merge(context, sw);
            String body = sw.toString();

            // Set email data
            JavaMailSender mailSender = mailSenderFactory.createJavaMailSender(profile);
            MimeMessage message = mailSender.createMimeMessage();
            MimeMessageHelper helper = new MimeMessageHelper(message, true, "UTF-8");

            String email = profile.getEmail();
            
            if (StringUtils.isNotBlank(email)) {
                helper.setFrom(email);
            }
            
            StartRequestData startRequestData = request.getStartRequestData();

            // Send an email to selected sales district or sales division and a copy to selected PDM manager
            boolean toAddressSet = false;
            if (startRequestData != null) {
                String salesDistrictEmailAddress = null;
                if (startRequestData.getSelectedDistrict() != null) {
                    salesDistrictEmailAddress = startRequestData.getSelectedDistrict().getEmailAddress();
                }
                String divisionEmailAddress = null;
                if (startRequestData.getSelectedDivision() != null) {
                    divisionEmailAddress = startRequestData.getSelectedDivision().getEmailAddress();
                }
                if (StringUtils.isNotBlank(salesDistrictEmailAddress) && !isServiceLedDeal) {
                    helper.setTo(salesDistrictEmailAddress);
                    toAddressSet = true;
                } else if (StringUtils.isNotBlank(divisionEmailAddress) && !isServiceLedDeal) {
                    helper.setTo(divisionEmailAddress);
                    toAddressSet = true;
                }
                if (startRequestData.getSelectedPdmName() != null &&
                    StringUtils.isNotBlank(startRequestData.getSelectedPdmName().getEmailAddress())) {
                    if (toAddressSet) {
                        helper.addCc(startRequestData.getSelectedPdmName().getEmailAddress());
                    } else {
                        helper.setTo(startRequestData.getSelectedPdmName().getEmailAddress());
                        toAddressSet = true;
                    }
                }
            }

            // Always send a copy to request author
            if (StringUtils.isNotBlank(email)) {
                if (toAddressSet) {
                    helper.addCc(email);
                } else {
                    helper.setTo(email);
                    toAddressSet = true;
                }
            }
            
            // For SRT4 path send copy to dedicated mailbox also
            if (phase4) {
                if (toAddressSet) {
                    helper.addCc(emailRecipientPhase4);
                } else {
                    helper.setTo(emailRecipientPhase4);
                    toAddressSet = true;
                }
            }

            helper.setSubject(phase4 ? emailSubjectPhase4 : getEmailSubject(request));
            helper.setText(body, true);

            // Add exported file and form attachments
            String fileName = attachmentFilename.replaceAll("\\$PROJECT_NAME\\$", request.getProjectName());
            helper.getRootMimeMultipart().addBodyPart(
                    createMailAttachment(phase4 ? attachmentFilenamePhase4 : fileName, exportedRequest));
            if (additionalFile != null) {
                helper.getRootMimeMultipart().addBodyPart(createMailAttachment(fileName, additionalFile));
            }

            if (startRequestData != null && startRequestData.getAttachments() != null) {
                for (Attachment attachment : startRequestData.getAttachments()) {
                    File localFile = new File(attachmentUploadFolder, attachment.getAttachmentFilepath());
                    if (localFile.exists()) {
                        helper.getRootMimeMultipart().addBodyPart(
                                createMailAttachment(attachment.getAttachmentFilename(), localFile));
                    } else {
                        logger.warn("Missing attachment: " + localFile);
                    }
                }
            }

            mailSender.send(message);

            // Log exit
            Helper.logExit(logger, signature, null);
        } catch (MailException e) {
            // Log exception
            throw Helper.logException(logger, signature, new NotificationServiceException(
                    "Error occurs while sending email.", e));
        } catch (MessagingException e) {
            // Log exception
            throw Helper.logException(logger, signature, new NotificationServiceException(
                    "Error occurs while sending email.", e));
        } catch (IOException e) {
            // Log exception
            throw Helper.logException(logger, signature, new NotificationServiceException(
                    "Error occurs while transfer request stream to byte array.", e));
        } catch (Exception e) {
             // Log exception
            throw Helper.logException(logger, signature, new NotificationServiceException(
                    "Error occurs while velocityEngine working.", e));
        }
    }
    
    /**
     * This method is used to send an email to the submitting user, the approver
     * and all additional recipients configured for a PENDING request.
     *
     * @param exportedRequest
     *            the PDF file of exported request. It is set as an attachment.
     * @param approvalEmail
     *            the approver's email
     * @param additionalRecipientsEmails
     *            the additional recipients emails
     * @param request
     *            the Request object to be send. It is used to generate the
     *            email body
     * @param profile
     *            the submitter's profile
     * @throws IllegalArgumentException
     *             request/exportedRequest/profile is null.
     * @throws com.emc.gs.tools.srf.services.NotificationServiceException
     *             if there is any problem when performing operation.
     * @since 1.1
     */
    @Override
    public void sendRequestApprovalEmails(String approvalEmail, List<String> additionalRecipientsEmails,
            Request request, File exportedRequest, Profile profile) throws NotificationServiceException {
        final String signature = CLASSNAME
                + "#sendRequestApprovalEmail(Request request, File exportedRequest, Profile profile)";
        Logger logger = getLogger();
 
        // Log entry
        Helper.logEntrance(logger, signature, new String[] { "request", "exportedRequest", "profile" }, new Object[] {
                request, exportedRequest, profile });
 
        Helper.checkNull(logger, signature, request, "request");
        Helper.checkNull(logger, signature, exportedRequest, "exportedRequest");
        Helper.checkNull(logger, signature, profile, "profile");
 
        try {
            String email = profile.getEmail();
            if (StringUtils.isNotBlank(email)) {
                sendRequestApprovalEmail(email, "review", request, exportedRequest, profile);
            }
            if (StringUtils.isNotBlank(approvalEmail)) {
                sendRequestApprovalEmail(approvalEmail, "approval", request, exportedRequest, profile);
            }
            for (int i = 0; i < additionalRecipientsEmails.size(); i++) {
                String recipientEmail = additionalRecipientsEmails.get(i);
                if (StringUtils.isNotBlank(recipientEmail)) {
                    sendRequestApprovalEmail(recipientEmail, "review", request, exportedRequest, profile);
                }
            }
        } catch (MailException e) {
            // Log exception
            throw Helper.logException(logger, signature, new NotificationServiceException(
                    "Error occurs while sending email.", e));
        } catch (MessagingException e) {
            // Log exception
            throw Helper.logException(logger, signature, new NotificationServiceException(
                    "Error occurs while sending email.", e));
        } catch (IOException e) {
            // Log exception
            throw Helper.logException(logger, signature, new NotificationServiceException(
                    "Error occurs while transfer request stream to byte array.", e));
        } catch (Exception e) {
            // Log exception
            throw Helper.logException(logger, signature, new NotificationServiceException(
                    "Error occurs while velocityEngine working.", e));
        }
    }
 
    /**
     * Sends a request approval email.
     * 
     * @param email
     *            The "To" email
     * @param action
     *            The action
     * @param request
     *            The request
     * @param exportedRequest
     *            The exported request
     * @param profile
     *            The profile
     * @throws Exception
     *             If any exception occurs
     * @since 1.15
     */
    private void sendRequestApprovalEmail(String email, String action, Request request, File exportedRequest,
            Profile profile) throws Exception {
        final String signature = CLASSNAME
                + "#sendRequestApprovalEmail(String email, String action, Request request, File exportedRequest, Profile profile)";
        Logger logger = getLogger();
 
        // Render message with Velocity
        Template template = velocityEngine.getTemplate(approvalEmailBodyTemplate);
 
        // Put necessary data
        // Merge the template and convert to string
        StringWriter sw = new StringWriter();
        VelocityContext context = getApprovalEmailContext(request, profile, action);
        template.merge(context, sw);
        String body = sw.toString();
 
        // Set email data
        JavaMailSender mailSender = mailSenderFactory.createJavaMailSender(profile);
        MimeMessage message = mailSender.createMimeMessage();
        MimeMessageHelper helper = new MimeMessageHelper(message, true, "UTF-8");
 
        String profileEmail = profile.getEmail();
        if (StringUtils.isNotBlank(profileEmail)) {
            helper.setFrom(profileEmail);
        }
 
        StartRequestData startRequestData = request.getStartRequestData();
 
        helper.setTo(email);
 
        helper.setSubject(emailSubjectApproval);
        helper.setText(body, true);
 
        // Add exported file and form attachments
        String fileName = attachmentFilename.replaceAll("\\$PROJECT_NAME\\$", request.getProjectName());
        helper.getRootMimeMultipart().addBodyPart(createMailAttachment(fileName, exportedRequest));
 
        if (startRequestData != null && startRequestData.getAttachments() != null) {
            for (Attachment attachment : startRequestData.getAttachments()) {
                File localFile = new File(attachmentUploadFolder, attachment.getAttachmentFilepath());
                if (localFile.exists()) {
                    helper.getRootMimeMultipart().addBodyPart(
                            createMailAttachment(attachment.getAttachmentFilename(), localFile));
                } else {
                    logger.warn("Missing attachment: " + localFile);
                }
            }
        }
 
        mailSender.send(message);
 
        // Log exit
        Helper.logExit(logger, signature, null);
    }

    /**
     * Gets velocity context for Phase 4 request.
     * 
     * @param request Phase 4 request.
     * @return velocity context for Phase 4 request.
     */
    private VelocityContext getPhase4Context(Request request) {
        VelocityContext context = new VelocityContext();
        return context;
    }
    
    /**
     * Gets velocity context for request approval email.
     * 
     * @param request
     *            The request.
     * @param action
     *            The action
     * @return velocity context for request approval email.
     * @since 1.15
     */
    private VelocityContext getApprovalEmailContext(Request request, Profile profile, String action) {
        VelocityContext context = new VelocityContext();
        StringBuilder name = new StringBuilder();
        if (StringUtils.isNotBlank(profile.getFirstName())) {
            name.append(profile.getFirstName());
        }
        if (StringUtils.isNotBlank(profile.getLastName())) {
            if (name.length() > 0) {
                name.append(" ");
            }
            name.append(profile.getLastName());
        }
        if (name.length() == 0) {
            name.append(profile.getUserIdentifier());
        }
        context.put("name", name);
        long requestId = appService.isCloudApp() ? request.getId() : request.getCorrelatedId();
        context.put("requestId", requestId);
        context.put("action", action);
        context.put("requestLink", cloudServiceUrlBase + "/request/" + requestId);
        return context;
    }

    /**
     * Gets velocity context for Phase 3 request.
     * 
     * @param request Phase 3 request.
     * @return velocity context for Phase 3 request.
     */
    private VelocityContext getPhase3Context(Request request) {
        VelocityContext context = new VelocityContext();
        StartRequestData startRequestData = request.getStartRequestData();
        if (startRequestData != null) {
            Division selectedDivision = startRequestData.getSelectedDivision();
            if (selectedDivision != null) {
                context.put("divisionName", selectedDivision.getDivisionName());
            }
            String districtName = "";
            String areaName = "";
            SalesDistrict selectedDistrict = startRequestData.getSelectedDistrict();
            if (selectedDistrict != null) {
                districtName = selectedDistrict.getDistrictName();
                areaName = selectedDistrict.getAreaName();
            }
            context.put("districtName", districtName);
            context.put("areaName", areaName);
            context.put("pdmName", startRequestData.getPdmName());
            context.put("pmName", startRequestData.getPmName());
            context.put("dxp", startRequestData.getDxQuoteNumber());
            if (startRequestData.getRequestedReturnDate() != null) {
                context.put("requestedReturnDate", new SimpleDateFormat("MM/dd/yyyy").format(
                        startRequestData.getRequestedReturnDate()));
            } else {
                context.put("requestedReturnDate", "");
            }
            context.put("serviceRequestScope", startRequestData.getServiceRequestScope());
        }
        context.put("requestType", getRequestType(request));
        context.put("projectName", request.getProjectName());
        Customer customer = request.getCustomer();
        if (customer != null) {
            context.put("customerName", customer.getFormalName());
        }
        if (startRequestData != null) {
            context.put("tcName", startRequestData.getSeCsdName());
            context.put("tcPhone", startRequestData.getSeCsdPhone());
        } else {
            context.put("tcName", "");
            context.put("tcPhone", "");
        }
        return context;
    }

    /**
     * Create mail attachment.
     * @param attachmentName
     *            The attachment name
     * @param attachment
     *            The attachment file
     * @return The MIME part represents the mail attachment
     * @throws javax.mail.MessagingException
     *             if any message error occurs
     * @throws java.io.IOException
     *             if any I/O error occurs
     * @since SRT Phase 2 Release Assembly
     */
    private MimeBodyPart createMailAttachment(String attachmentName, File attachment) throws MessagingException, IOException {
        MimeBodyPart mimeBodyPart = new MimeBodyPart();
        mimeBodyPart.setDisposition(MimeBodyPart.ATTACHMENT);
        mimeBodyPart.setFileName(MimeUtility.encodeText(attachmentName));
        mimeBodyPart.setDataHandler(new TraceDataHandler(new FileDataSource(attachment)));
        return mimeBodyPart;
    }

    /**
     * The data handler to trace the bytes size sent.
     *
     * @author liuliquan
     * @version 1.0
     * @since SRT Phase 2 Release Assembly
     */
    public class TraceDataHandler extends DataHandler {

        /**
         * Constructor with data source.
         * @param dataSource
         *            The data source
         */
        public TraceDataHandler(DataSource dataSource) {
            super(dataSource);
        }

        /**
         * Write to attachment data to output stream.
         * @param output
         *            the OutputStream to write to
         * @throws java.io.IOException
         *             if any I/O error occurs
         */
        public void writeTo(OutputStream output) throws IOException {

            InputStream input = getDataSource().getInputStream();

            int bytesRead;
            byte[] buffer = new byte[8 * 1024];

            try {
                while ((bytesRead = input.read(buffer)) > 0) {
                    output.write(buffer, 0, bytesRead);

                    // Trace the bytes sent
                    SubmitResult submitResult = SubmitResult.SUBMIT_RESULT.get();
                    if (submitResult != null) {
                        submitResult.setSizeSent(submitResult.getSizeSent() + bytesRead);
                    }
                }
            } finally {
                IOUtils.closeQuietly(input);
            }
        }
    }
    
    /**
     * Get request type.
     *
     * @param request
     *            the Request object to be send.
     * @return request type
     */
    private String getRequestType(Request request) {
        if ("BOE and SOW/TPD".equals(request.getRequestType().getName())) {
            if ("Federal".equals(request.getStartRequestData().getSelectedDivision().getDivisionName())) {
                return "BOE/TPD Request";
            } else {
                return "BOE/SOW Request";
            }
        }
        return "BOE Request";
    }

    /**
     * Get email subject.
     *
     * @param request
     *            the Request object to be send.
     * @return email subject
     */
    private String getEmailSubject(Request request) {
        Customer customer = request.getCustomer();
        String customerName = customer != null ? customer.getFormalName()
                : request.getStartRequestData().getCustomerName();
        String result = request.getStartRequestData().getSelectedDivision().getShortName()
                + "-" + request.getStartRequestData().getSelectedDistrict().getMarketName()
                + "-" + customerName
                + " " + request.getProjectName();
        return "[" + getRequestType(request) + "] SQC " + result;
    }

    /**
     * <p>
     * Sets the value to velocityEngine field.
     * </p>
     *
     * @param velocityEngine
     *            the velocityEngine to set
     */
    public void setVelocityEngine(VelocityEngine velocityEngine) {
        this.velocityEngine = velocityEngine;
    }

    /**
     * Setter method for property <tt>attachmentUploadFolder</tt>.
     * @param attachmentUploadFolder value to be assigned to property attachmentUploadFolder
     */
    public void setAttachmentUploadFolder(String attachmentUploadFolder) {
        this.attachmentUploadFolder = attachmentUploadFolder;
    }

    /**
     * <p>
     * Sets the value to emailBodyTemplate field.
     * </p>
     *
     * @param emailBodyTemplate
     *            the emailBodyTemplate to set
     */
    public void setEmailBodyTemplate(String emailBodyTemplate) {
        this.emailBodyTemplate = emailBodyTemplate;
    }
    
    /**
     * <p>
     * Sets the value to approvalEmailBodyTemplate field.
     * </p>
     *
     * @param approvalEmailBodyTemplate
     *            the approvalEmailBodyTemplate to set
     * @since 1.15
     */
    public void setApprovalEmailBodyTemplate(String approvalEmailBodyTemplate) {
        this.approvalEmailBodyTemplate = approvalEmailBodyTemplate;
    }

    /**
     * <p>
     * Sets the value to attachmentFilename field.
     * </p>
     *
     * @param attachmentFilename
     *            the attachmentFilename to set
     */
    public void setAttachmentFilename(String attachmentFilename) {
        this.attachmentFilename = attachmentFilename;
    }

    /**
     * Setter method for property <tt>emailBodyTemplatePhase4</tt>.
     * 
     * @param emailBodyTemplatePhase4
     *            value to be assigned to property emailBodyTemplatePhase4
     */
    public void setEmailBodyTemplatePhase4(String emailBodyTemplatePhase4) {
        this.emailBodyTemplatePhase4 = emailBodyTemplatePhase4;
    }

    /**
     * Setter method for property <tt>emailRecipientPhase4</tt>.
     * 
     * @param emailRecipientPhase4
     *            value to be assigned to property emailRecipientPhase4
     */
    public void setEmailRecipientPhase4(String emailRecipientPhase4) {
        this.emailRecipientPhase4 = emailRecipientPhase4;
    }

    /**
     * Setter method for property <tt>emailSubjectPhase4</tt>.
     * 
     * @param emailSubjectPhase4
     *            value to be assigned to property emailSubjectPhase4
     */
    public void setEmailSubjectPhase4(String emailSubjectPhase4) {
        this.emailSubjectPhase4 = emailSubjectPhase4;
    }
    
    /**
     * Setter method for property <tt>emailSubjectApproval</tt>.
     * 
     * @param emailSubjectApproval
     *            value to be assigned to property emailSubjectApproval
     * @since 1.15
     */
    public void setEmailSubjectApproval(String emailSubjectApproval) {
        this.emailSubjectApproval = emailSubjectApproval;
    }

    /**
     * Setter method for property <tt>attachmentFilenamePhase4</tt>.
     * 
     * @param attachmentFilenamePhase4
     *            value to be assigned to property attachmentFilenamePhase4
     */
    public void setAttachmentFilenamePhase4(String attachmentFilenamePhase4) {
        this.attachmentFilenamePhase4 = attachmentFilenamePhase4;
    }

    /**
     * Setter method for property <tt>mailSenderFactory</tt>.
     * 
     * @param mailSenderFactory
     *            value to be assigned to property mailSenderFactory
     * @since SRT Phase 4 - ET Assembly 2
     */
    public void setMailSenderFactory(MailSenderFactory mailSenderFactory) {
        this.mailSenderFactory = mailSenderFactory;
    }

    /**
     * Setter method for property <tt>cloudServiceUrlBase</tt>.
     * 
     * @param cloudServiceUrlBase
     *            value to be assigned to property cloudServiceUrlBase
     * @since 1.15
     */
    public void setCloudServiceUrlBase(String cloudServiceUrlBase) {
        this.cloudServiceUrlBase = cloudServiceUrlBase;
    }
 
    /**
     * Setter method for property <tt>appService</tt>.
     * 
     * @param appService
     *            value to be assigned to property appService
     * @since 1.15
     */
    public void setAppService(AppService appService) {
        this.appService = appService;
    }
}

/*
 * This code is copyright (c) 2013 - 2014 EMC Corporation.
 */
package com.emc.gs.tools.srf.services;

import java.util.List;

import com.emc.gs.tools.srf.model.Customer;
import com.emc.gs.tools.srf.model.Division;
import com.emc.gs.tools.srf.model.GeoState;
import com.emc.gs.tools.srf.model.Geography;
import com.emc.gs.tools.srf.model.PdmName;
import com.emc.gs.tools.srf.model.Region;
import com.emc.gs.tools.srf.model.SalesDistrict;

/**
 * <p>
 * This interface defines a contract for managing a additional data for start tab. It provides necessary methods for
 * retrieving divisions, sales districts and PDM data.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: The implementation are required to be thread safe.
 * </p>
 *
 * <p>
 * <strong>Changes:</strong>
 * <strong>SRT Release Assembly - Base</strong>
 * <ul>
 * <li>Added new methods</li>
 * </ul>
 * </p>
 * 
 * <p>
 * <strong>Changes V1.2:</strong>
 * <strong>Commercial / Mid-Market Division Special Handling Logic</strong>
 * <ul>
 * <li>Added getAllGeographies() and getStatesByGeography() methods.</li>
 * </ul>
 * </p>
 * 
 * <p>
 * <strong>Changes V1.3:</strong>
 * <strong>SRT 1.1 DEC 2014 Updates Assembly</strong>
 * <ul>
 * <li>Added getRegionsByCountry() method.</li>
 * </ul>
 * </p>
 * 
 * @author faeton, stevenfrog, TCSASSEMBLER, MonicaMuranyi
 * @version 1.3
 */
public interface StartRequestDataService {
    /**
     * Returns all available divisions.
     *
     * @return Whole list of divisions, may be empty
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     */
    public List<Division> getAllDivisions() throws ServiceRequestToolException;
    
    /**
     * Returns all available geographies.
     *
     * @return Whole list of geographies, may be empty
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     */
    public List<Geography> getAllGeographies() throws ServiceRequestToolException;
    
    /**
     * Returns all states associated with the given geography.
     * 
     * @param geographyId The geography id
     * @return List of states, may be empty
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     */
    public List<GeoState> getStatesByGeography(long geographyId) throws ServiceRequestToolException;
    
    /**
     * Returns all states associated with the given country.
     * 
     * @param countryId The country id
     * @return List of regions, may be empty
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     */
    public List<Region> getRegionsByCountry(long countryId) throws ServiceRequestToolException;

    /**
     * Returns all sales district for the division id.
     *
     * @param divisionId
     *            the division id
     * @return List of sales district for the division, may be empty
     * @throws IllegalArgumentException
     *             if the divisionId is not positive.
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     */
    public List<SalesDistrict> getDistrictsForDivision(long divisionId) throws ServiceRequestToolException;

    /**
     * Returns all PDM names for the district name.
     *
     * @param districtName
     *            the district name
     * @return List of PDM names for the district name, may be empty.
     * @throws IllegalArgumentException
     *             if the districtName is null/empty.
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     */
    public List<PdmName> getPdmNamesForDistrict(String districtName) throws ServiceRequestToolException;
    
    /**
     * Returns all PDM names for the selected division.
     *
     * @param divisionId
     *            the division id
     * @return List of PDM names for the division, may be empty
     * @throws IllegalArgumentException
     *             if the divisionId is not positive.
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     * @since 1.1
     */
    public List<PdmName> getPdmNamesForDivision(long divisionId) throws ServiceRequestToolException;

    /**
     * Returns all customers with the given name.
     *
     * @param name
     *            the customer name
     * @return List of customers, may be empty
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     * @throws IllegalArgumentException
     *             if the name is null.
     * @since 1.1
     */
    public List<Customer> getCustomerByName(String name) throws ServiceRequestToolException;
}

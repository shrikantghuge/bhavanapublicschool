/*
 * This code is copyright (c) 2013 - 2015 EMC Corporation.
 */
package com.emc.gs.tools.srf.services.impl;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceException;
import javax.persistence.TypedQuery;

import org.apache.log4j.Logger;

import com.emc.gs.tools.srf.model.Profile;
import com.emc.gs.tools.srf.model.ProfileSearchCriteria;
import com.emc.gs.tools.srf.model.SearchResult;
import com.emc.gs.tools.srf.model.ServiceContext;
import com.emc.gs.tools.srf.model.SortOrder;
import com.emc.gs.tools.srf.model.User;
import com.emc.gs.tools.srf.services.ProfileService;
import com.emc.gs.tools.srf.services.ServiceRequestToolException;

/**
 * <p>
 * This class is the implementation of the ProfileService. It utilizes JPA EntityManager for necessary
 * operations.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is effectively thread safe after configuration, the
 * configuration is done in a thread safe manner.
 * </p>
 *
 * <p>
 * <strong>Changes V1.1:</strong>
 * <strong>SRT Release Assembly - Unified Tab</strong>
 * <ul>
 * <li>Add getDefaultProfile() method</li>
 * </ul>
 * </p>
 *
 * <p>
 * <strong>Change 1.2:</strong>
 * <strong>SRT Cloud Synchronization - Cloud App Assembly</strong>
 * <ul>
 * <li>added create, update, get and delete methods</li>
 * <li>added userIdentifier parameter to query in getDefaultProfile</li>
 * </ul>
 * </p>
 *
 * <p>
 * <strong>Changes V1.3:</strong>
 * <strong>SRT Phase 4 - ET Assembly 2</strong>
 * <ul>
 * <li>Extend from BaseCorrelatedEntityService.</li>
 * </ul>
 * </p>
 *
 * <p>
 * <strong>Changes V1.4:</strong>
 * <strong>SRT 1.1 Approval Process Assembly</strong>
 * <ul>
 * <li>Added SQL_PROFILES and SQL_PROFILE_COUNT fields.</li>
 * <li>Added SQL_PROFILES and SQL_PROFILE_COUNT fields.</li>
 * <li>Added search related methods.</li>
 * </ul>
 * </p>
 *
 * <p>
 * Version 1.5 Change notes:
 *   <ol>
 *     <li>Added support for managing <code>Template Folder Editor</code> permissions.</li>
 *   </ol>
 * </p>
 *
 * <p>
 * Version 1.6 Change notes:
 *   <ol>
 *     <li>Added support for searching profiles by division.</li>
 *     <li>Removed support for searching profiles by <code>Submitter</code> permission.</li>
 *   </ol>
 * </p>
 *
 * @author faeton, stevenfrog, MonicaMuranyi, isv
 * @version 1.6
 */
public class ProfileServiceImpl extends BaseCorrelatedEntityService<Profile> implements ProfileService {
    /**
     * <p>
     * Represents the class name.
     * </p>
     */
    private static final String CLASSNAME = ProfileServiceImpl.class.getName();
    
    /**
     * The query string to get users.
     * @since 1.4
     */
    private static final String SQL_PROFILES = "SELECT p FROM Profile p WHERE 1 = 1";
    
    /**
     * The query string to get users count.
     * @since 1.4
     */
    private static final String SQL_PROFILE_COUNT = "SELECT COUNT(p) FROM Profile p WHERE 1 = 1";

    /**
     * Creates instance of the class.
     */
    public ProfileServiceImpl() {
        super(Profile.class);
    }

    /**
     * Retrieves default profile.
     *
     * @return The default profile, if there's no default profile
     * @throws IllegalArgumentException
     *             if id is not positive
     * @throws com.emc.gs.tools.srf.services.ServiceRequestToolException
     *             if any other error occurred during the operation
     * @since SRT Release Assembly - Unified Tab
     */
    public Profile getDefaultProfile() throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#getDefaultProfile()";
        Logger logger = getLogger();

        // Log entry
        Helper.logEntrance(logger, signature, null, null);

        try {
            User currentUser = ServiceContext.getCurrentUser();

            String q = "select p from Profile p where p.defaultProfile = true";
            if (currentUser != null && !Helper.isStringNullOrEmpty(currentUser.getUserIdentifier())) {
                q += " and p.userIdentifier = :userIdentifier";
            }
            q += " order by p.id asc";

            TypedQuery<Profile> query = getEntityManager().createQuery(q, Profile.class);
            if (currentUser != null && !Helper.isStringNullOrEmpty(currentUser.getUserIdentifier())) {
                query.setParameter("userIdentifier", currentUser.getUserIdentifier());
            }
            List<Profile> result = query.setMaxResults(1).getResultList();

            Profile defaultProfile = result.isEmpty() ? null : result.get(0);

            // Log exit
            Helper.logExit(logger, signature, new Object[]{defaultProfile});
            return defaultProfile;
        } catch (IllegalStateException e) {
            // Log exception
            throw Helper.logException(logger, signature, new ServiceRequestToolException(
                    "The entity manager has been closed.", e));
        } catch (PersistenceException e) {
            // Log exception
            throw Helper.logException(logger, signature, new ServiceRequestToolException(
                    "An error has occurred while accessing the persistence.", e));
        }
    }

    /**
     * Search profiles based on the search criteria.
     *
     * @throws IllegalArgumentException
     *             if criteria is null, or if criteria.pageNumber is positive, criteria.pageSize is not
     *             positive
     * @throws com.emc.gs.tools.srf.services.ServiceRequestToolException
     *             if any other error occurred during the operation
     * @param criteria
     *            the search criteria
     * @return the search result
     * @since 1.4
     */
    public SearchResult<Profile> search(ProfileSearchCriteria criteria) throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#search(UserSearchCriteria criteria)";
        Logger logger = getLogger();

        // Log entry
        Helper.logEntrance(logger, signature, new String[]{"criteria"}, new Object[]{criteria});
        
        Helper.checkNull(logger, signature, criteria, "criteria");
        if (criteria.getPageNumber() > 0 && criteria.getPageSize() <= 0) {
            // Log exception
            throw Helper.logException(logger, signature, new IllegalArgumentException(
                    "'criteria.pageSize' must be positive when criteria.pageNumber is positive."));
        }

        try {
            // Set default sorting order and column
            if (criteria.getSortBy() == null) {
                criteria.setSortBy("id");
            }
            if (criteria.getSortOrder() == null) {
                criteria.setSortOrder(SortOrder.DESC);
            }

            EntityManager entityManager = getEntityManager();

            // Create the query string
            StringBuffer sb = new StringBuffer(SQL_PROFILES);
            setQueryByCriteria(criteria, sb);

            sb.append(" ORDER BY ").append(criteria.getSortBy()).append(" ")
                .append(criteria.getSortOrder().name());

            // Create query
            TypedQuery<Profile> query = entityManager.createQuery(sb.toString(), Profile.class);

            setParaByCriteria(criteria, query);

            // Set paging
            if (criteria.getPageNumber() > 0) {
                query.setMaxResults(criteria.getPageSize());
                query.setFirstResult((criteria.getPageNumber() - 1) * criteria.getPageSize());
            }

            List<Profile> records = query.getResultList();

            SearchResult<Profile> result = new SearchResult<Profile>();
            result.setValues(records);
            result.setPageNumber(criteria.getPageNumber());
            result.setPageSize(criteria.getPageSize());

            if (criteria.getPageNumber() > 0) {
                // get total page count
                sb = new StringBuffer(SQL_PROFILE_COUNT);
                setQueryByCriteria(criteria, sb);

                // Create query
                TypedQuery<Long> countQuery = entityManager.createQuery(sb.toString(), Long.class);

                setParaByCriteria(criteria, countQuery);

                int totalCount = countQuery.getSingleResult().intValue();
                int totalPageCount = (totalCount + criteria.getPageSize() - 1) / criteria.getPageSize();

                result.setTotalItems(totalCount);
                result.setTotalPages(totalPageCount);
            } else {
                result.setTotalItems(records.size());
                result.setTotalPages(1);
            }

            // Log exit
            Helper.logExit(logger, signature, new Object[]{result});

            return result;

        } catch (IllegalStateException e) {
            // Log exception
            throw Helper.logException(logger, signature, new ServiceRequestToolException(
                    "The entity manager has been closed.", e));
        } catch (PersistenceException e) {
            // Log exception
            throw Helper.logException(logger, signature, new ServiceRequestToolException(
                    "An error has occurred while accessing the persistence.", e));
        }
    }

    /**
     * Set the query string by criteria.
     *
     * @param criteria
     *            the criteria
     * @param sb
     *            the string builder
     * @since 1.4
     */
    private void setQueryByCriteria(ProfileSearchCriteria criteria, StringBuffer sb) {
        if (criteria.getUserIdentifier() != null) {
            sb.append(" AND LOWER(p.userIdentifier) LIKE :userIdentifier");
        }
        if (criteria.getFullName() != null) {
            sb.append(" AND (LOWER(p.firstName) LIKE :fullName OR LOWER(p.lastName) LIKE :fullName " +
                "OR (LOWER(p.firstName) || ' ' || LOWER(p.lastName)) LIKE :fullName )");
        }
        if (criteria.isApprover() != null) {
            sb.append(" AND p."+UserRole.APPROVER.getName()+" = :"+UserRole.APPROVER.getName());
            if(!criteria.isApprover()){
                sb.append(" OR p."+UserRole.APPROVER.getName()+" = null");
            }
        }
        if (criteria.getTemplateFolderEditor() != null) {
            sb.append(" AND p." + UserRole.TEMPLATE_FOLDER_EDITOR.getName() + " = :" + UserRole.TEMPLATE_FOLDER_EDITOR.getName());
            if (!criteria.getTemplateFolderEditor()) {
                sb.append(" OR p." + UserRole.TEMPLATE_FOLDER_EDITOR.getName() + " = null");
            }
        }
        if (criteria.getDivisionId() != null) {
            sb.append(" AND p.division.id  = :divisionId");
        }
    }

    /**
     * Set the parameter for query by criteria.
     *
     * @param criteria
     *            the criteria
     * @param query
     *            the query
     * @since 1.4
     */
    private void setParaByCriteria(ProfileSearchCriteria criteria, TypedQuery<?> query) {
        if (criteria.getUserIdentifier() != null) {
            query.setParameter("userIdentifier", Helper.fixStringForLike(criteria.getUserIdentifier()));
        }
        if (criteria.getFullName() != null) {
            query.setParameter("fullName", Helper.fixStringForLike(criteria.getFullName()));
        }
        if (criteria.isApprover() != null) {
            query.setParameter(UserRole.APPROVER.getName(), criteria.isApprover());
        }
        if (criteria.getTemplateFolderEditor() != null) {
            query.setParameter(UserRole.TEMPLATE_FOLDER_EDITOR.getName(), criteria.getTemplateFolderEditor());
        }
        if (criteria.getDivisionId() != null) {
            query.setParameter("divisionId", criteria.getDivisionId());
        }
    }
}

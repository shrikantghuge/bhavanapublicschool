/*
 * This code is copyright (c) 2014 EMC Corporation.
 */
package com.emc.gs.tools.srf.services.estimate.dto;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.emc.gs.tools.srf.model.estimate.LOBResource;
import com.emc.gs.tools.srf.model.estimate.LOBResources;

/**
 * <p>
 * This is EstimatedLOB DTO class. It extends form LOBResources.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safety.
 * </p>
 * 
 * @author TCSASSEMBLER
 * @version 1.0
 * @since SRT Phase 4 - ET Assembly 1
 */
public class EstimatedLOB extends LOBResources {

    /**
     * The Standard Fees.
     */
    private BigDecimal standardFees = BigDecimal.ZERO;

    /**
     * The Discounted Fees.
     */
    private BigDecimal discountedFees = BigDecimal.ZERO;

    /**
     * The Total Hours.
     */
    private BigDecimal totalHours = BigDecimal.ZERO;

    /* Cost data may be null */

    /**
     * The Standard Cost.
     */
    private BigDecimal standardCost;

    /**
     * The Gross Margin.
     */
    private BigDecimal grossMargin;

    /**
     * The Gross Margin percent.
     */
    private BigDecimal grossMarginPercent;

    /**
     * The LOB start date.
     */
    private Date lobStartDate;

    /**
     * The LOB end date.
     */
    private Date lobEndDate;

    /**
     * The list of estimated resources.
     */
    private List<EstimatedResource> estimatedResources = new ArrayList<EstimatedResource>();

    /**
     * The LOB's pricing overview.
     */
    private PricingOverview pricingOverview = new PricingOverview();

    /**
     * Constructor with the LOB resources entity.
     * 
     * @param lob
     *            the LOB resources entity
     */
    public EstimatedLOB(LOBResources lob) {

        // Copy all properties
        super.setId(lob.getId());

        super.setLob(lob.getLob());
        super.setCompetency(lob.getCompetency());
        super.setMaterialCode(lob.getMaterialCode());
        super.setBillingType(lob.getBillingType());

        super.setMonthsNum(lob.getMonthsNum());

        super.setDiscountAmount(lob.getDiscountAmount());
        super.setDiscountPercent(lob.getDiscountPercent());
        super.setExpenseAmount(lob.getExpenseAmount());

        super.setWbs(lob.getWbs());

        if (lob.getResources() != null) {
            for (LOBResource resource : lob.getResources()) {
                estimatedResources.add(new EstimatedResource(resource));
            }
        }
    }

    /**
     * Getter method for property <tt>estimatedResources</tt>.
     * 
     * @return property value of estimatedResources
     */
    public List<EstimatedResource> getEstimatedResources() {
        return estimatedResources;
    }

    /**
     * Setter method for property <tt>estimatedResources</tt>.
     * 
     * @param estimatedResources
     *            value to be assigned to property estimatedResources
     */
    public void setEstimatedResources(List<EstimatedResource> estimatedResources) {
        this.estimatedResources = estimatedResources;
    }

    /**
     * Getter method for property <tt>standardFees</tt>.
     * 
     * @return property value of standardFees
     */
    public BigDecimal getStandardFees() {
        return standardFees;
    }

    /**
     * Setter method for property <tt>standardFees</tt>.
     * 
     * @param standardFees
     *            value to be assigned to property standardFees
     */
    public void setStandardFees(BigDecimal standardFees) {
        this.standardFees = standardFees;
    }

    /**
     * Getter method for property <tt>discountedFees</tt>.
     * 
     * @return property value of discountedFees
     */
    public BigDecimal getDiscountedFees() {
        return discountedFees;
    }

    /**
     * Setter method for property <tt>discountedFees</tt>.
     * 
     * @param discountedFees
     *            value to be assigned to property discountedFees
     */
    public void setDiscountedFees(BigDecimal discountedFees) {
        this.discountedFees = discountedFees;
    }

    /**
     * Getter method for property <tt>standardCost</tt>.
     * 
     * @return property value of standardCost
     */
    public BigDecimal getStandardCost() {
        return standardCost;
    }

    /**
     * Setter method for property <tt>standardCost</tt>.
     * 
     * @param standardCost
     *            value to be assigned to property standardCost
     */
    public void setStandardCost(BigDecimal standardCost) {
        this.standardCost = standardCost;
    }

    /**
     * Getter method for property <tt>grossMargin</tt>.
     * 
     * @return property value of grossMargin
     */
    public BigDecimal getGrossMargin() {
        return grossMargin;
    }

    /**
     * Setter method for property <tt>grossMargin</tt>.
     * 
     * @param grossMargin
     *            value to be assigned to property grossMargin
     */
    public void setGrossMargin(BigDecimal grossMargin) {
        this.grossMargin = grossMargin;
    }

    /**
     * Getter method for property <tt>grossMarginPercent</tt>.
     * 
     * @return property value of grossMarginPercent
     */
    public BigDecimal getGrossMarginPercent() {
        return grossMarginPercent;
    }

    /**
     * Setter method for property <tt>grossMarginPercent</tt>.
     * 
     * @param grossMarginPercent
     *            value to be assigned to property grossMarginPercent
     */
    public void setGrossMarginPercent(BigDecimal grossMarginPercent) {
        this.grossMarginPercent = grossMarginPercent;
    }

    /**
     * Getter method for property <tt>totalHours</tt>.
     * 
     * @return property value of totalHours
     */
    public BigDecimal getTotalHours() {
        return totalHours;
    }

    /**
     * Setter method for property <tt>totalHours</tt>.
     * 
     * @param totalHours
     *            value to be assigned to property totalHours
     */
    public void setTotalHours(BigDecimal totalHours) {
        this.totalHours = totalHours;
    }

    /**
     * Getter method for property <tt>lobStartDate</tt>.
     * 
     * @return property value of lobStartDate
     */
    public Date getLobStartDate() {
        return lobStartDate;
    }

    /**
     * Setter method for property <tt>lobStartDate</tt>.
     * 
     * @param lobStartDate
     *            value to be assigned to property lobStartDate
     */
    public void setLobStartDate(Date lobStartDate) {
        this.lobStartDate = lobStartDate;
    }

    /**
     * Getter method for property <tt>lobEndDate</tt>.
     * 
     * @return property value of lobEndDate
     */
    public Date getLobEndDate() {
        return lobEndDate;
    }

    /**
     * Setter method for property <tt>lobEndDate</tt>.
     * 
     * @param lobEndDate
     *            value to be assigned to property lobEndDate
     */
    public void setLobEndDate(Date lobEndDate) {
        this.lobEndDate = lobEndDate;
    }

    /**
     * Getter method for property <tt>pricingOverview</tt>.
     * 
     * @return property value of pricingOverview
     */
    public PricingOverview getPricingOverview() {
        return pricingOverview;
    }

    /**
     * Setter method for property <tt>pricingOverview</tt>.
     * 
     * @param pricingOverview
     *            value to be assigned to property pricingOverview
     */
    public void setPricingOverview(PricingOverview pricingOverview) {
        this.pricingOverview = pricingOverview;
    }

}

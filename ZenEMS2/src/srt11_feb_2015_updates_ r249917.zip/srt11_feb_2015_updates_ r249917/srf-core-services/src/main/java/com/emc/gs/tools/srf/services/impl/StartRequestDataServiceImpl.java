/*
 * This code is copyright (c) 2013 - 2014 EMC Corporation.
 */
package com.emc.gs.tools.srf.services.impl;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceException;
import javax.persistence.TypedQuery;

import org.apache.log4j.Logger;

import com.emc.gs.tools.srf.model.Customer;
import com.emc.gs.tools.srf.model.Division;
import com.emc.gs.tools.srf.model.GeoState;
import com.emc.gs.tools.srf.model.Geography;
import com.emc.gs.tools.srf.model.IdentifiableEntity;
import com.emc.gs.tools.srf.model.PdmName;
import com.emc.gs.tools.srf.model.Region;
import com.emc.gs.tools.srf.model.SalesDistrict;
import com.emc.gs.tools.srf.services.ServiceRequestToolException;
import com.emc.gs.tools.srf.services.StartRequestDataService;

/**
 * <p>
 * This class is the implementation of the StartRequestDataService. It utilizes JPA EntityManager for necessary
 * operations.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is effectively thread safe after configuration, the configuration is done
 * in a thread safe manner.
 * </p>
 * <p>
 * <strong>Changes:</strong> <strong>SRT Release Assembly - Base</strong>
 * <ul>
 * <li>Added new methods</li>
 * </ul>
 * </p>
 * <p>
 * <strong>Changes V1.2:</strong> <strong>Commercial / Mid-Market Division Special Handling Logic</strong>
 * <ul>
 * <li>Added getAllGeographies() and getStatesByGeography() methods.</li>
 * </ul>
 * </p>
 * <p>
 * <strong>Changes V1.3:</strong>
 * <ul>
 * <li>Changed the field based on which the customer is retrieved (from shortName to formalName).</li>
 * </ul>
 * </p>
 * <p>
 * <strong>Changes V1.4:</strong>
 * <ul>
 * <li>Added getRegionsByCountry() method and SQL_QUERY_REGIONS constant.</li>
 * </ul>
 * </p>
 * @author faeton, stevenfrog, TCSASSEMBLER, MonicaMuranyi
 * @version 1.4
 */
public class StartRequestDataServiceImpl extends BasePersistenceService implements
        StartRequestDataService {
    /**
     * <p>
     * Represents the class name.
     * </p>
     */
    private static final String CLASSNAME = StartRequestDataServiceImpl.class.getName();

    /**
     * The query string to get Division.
     */
    private static final String SQL_QUERY_DIVISION = "SELECT d FROM Division d";

    /**
     * The query string to get Geography.
     */
    private static final String SQL_QUERY_GEOGRAPHY = "SELECT g FROM Geography g";

    /**
     * The query string to get GeoState given a geography id.
     */
    private static final String SQL_QUERY_STATES = "SELECT s FROM GeoState s WHERE" + " s.geography.id = :id";
    
    /**
     * The query string to get Region given a country id.
     */
    private static final String SQL_QUERY_REGIONS = "SELECT s FROM Region s WHERE" + " s.country.id = :id";

    /**
     * The query string to get SalesDistrict.
     */
    private static final String SQL_QUERY_SALESDISTRICT = "SELECT s FROM SalesDistrict s WHERE"
            + " s.division.id = :id";

    /**
     * The query string to get PdmName.
     */
    private static final String SQL_QUERY_PDMNAME = "SELECT p FROM PdmName p WHERE"
            + " p.salesDistrict.districtName = :name";

    /**
     * The query string to get PdmName by division.
     */
    private static final String SQL_QUERY_PDMNAME2 = "SELECT p FROM PdmName p WHERE" + " p.division.id = :id";

    /**
     * The query string to get Customers by name.
     */
    private static final String SQL_QUERY_CUST = "SELECT s FROM Customer s WHERE" + " s.formalName = :name";

    /**
     * Empty constructor.
     */
    public StartRequestDataServiceImpl() {
    }

    /**
     * Returns all available divisions.
     * 
     * @return Whole list of divisions, may be empty
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     */
    public List<Division> getAllDivisions() throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#getAllDivisions()";

        return getEnities(getLogger(), signature, SQL_QUERY_DIVISION, Division.class, null, false);
    }

    /**
     * Returns all available geographies.
     * 
     * @return Whole list of geographies, may be empty
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     */
    public List<Geography> getAllGeographies() throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#getAllGeographies()";

        return getEnities(getLogger(), signature, SQL_QUERY_GEOGRAPHY, Geography.class, null, false);
    }

    /**
     * Returns all states associated with the given geography.
     * 
     * @param geographyId
     *            The geography id
     * @return List of states, may be empty
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     */
    public List<GeoState> getStatesByGeography(long geographyId) throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#getStatesByGeography(long geographyId)";

        return getEnities(getLogger(), signature, SQL_QUERY_STATES, GeoState.class, geographyId, false);
    }
    
    /**
     * Returns all states associated with the given country.
     * 
     * @param countryId
     *            The country id
     * @return List of regions, may be empty
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     */
    public List<Region> getRegionsByCountry(long countryId) throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#getRegionsByCountry(long countryId)";

        return getEnities(getLogger(), signature, SQL_QUERY_REGIONS, Region.class, countryId, false);
    }

    /**
     * Returns all sales district for the division name.
     * 
     * @param divisionId
     *            the division id
     * @return List of sales district for the division, may be empty
     * @throws IllegalArgumentException
     *             if the divisionName is null/empty.
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     */
    public List<SalesDistrict> getDistrictsForDivision(long divisionId) throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#getDistrictsForDivision(long divisionId)";

        return getEnities(getLogger(), signature, SQL_QUERY_SALESDISTRICT, SalesDistrict.class, divisionId, true);
    }

    /**
     * Returns all PDM names for the district name.
     * 
     * @param districtName
     *            the district name
     * @return List of PDM names for the district name, may be empty.
     * @throws IllegalArgumentException
     *             if the districtName is null/empty.
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     */
    public List<PdmName> getPdmNamesForDistrict(String districtName) throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#getPdmNamesForDistrict(String districtName)";

        return getEnities(getLogger(), signature, SQL_QUERY_PDMNAME, PdmName.class, districtName, true);
    }

    /**
     * Returns all PDM names for the selected division.
     * 
     * @param divisionId
     *            the division id
     * @return List of PDM names for the division, may be empty
     * @throws IllegalArgumentException
     *             if the divisionId is not positive.
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     * @since 1.1
     */
    public List<PdmName> getPdmNamesForDivision(long divisionId) throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#getPdmNamesForDivision(long divisionId)";
        return getEnities(getLogger(), signature, SQL_QUERY_PDMNAME2, PdmName.class, divisionId, true);
    }

    /**
     * Returns all customers with the given name.
     * 
     * @param name
     *            the customer name
     * @return List of customers, up to one max, may be empty
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     * @throws IllegalArgumentException
     *             if the name is null.
     * @since 1.1
     */
    public List<Customer> getCustomerByName(String name) throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#getCustomerByName(String name)";
        List<Customer> customers = getEnities(getLogger(), signature, SQL_QUERY_CUST, Customer.class, name, true);
        return customers;
    }

    /**
     * Get the entities from DB.
     * 
     * @param <T>
     *            the class type
     * @param logger
     *            the logger
     * @param signature
     *            the signature
     * @param queryStr
     *            the query string
     * @param clazz
     *            the class
     * @param param
     *            the param value
     * @param hasParam
     *            the flag whether has parameter
     * @return the entities
     * @throws IllegalArgumentException
     *             if param is invalid
     * @throws ServiceRequestToolException
     *             if any error occurs
     */
    private <T extends IdentifiableEntity> List<T> getEnities(Logger logger, String signature, String queryStr,
            Class<T> clazz, Object param, boolean hasParam) throws ServiceRequestToolException {
        // Log entry
        if (!hasParam) {
            Helper.logEntrance(logger, signature, null, null);
        } else {
            Helper.logEntrance(logger, signature, new String[] {
                "divisionName"
            }, new Object[] {
                param
            });

            if (param instanceof String) {
                Helper.checkStrNullEmpty(logger, signature, (String) param, "divisionName");
            } else if (param instanceof Long) {
                Helper.checkPositive(logger, signature, (Long) param, "divisionId");
            }
        }

        try {
            EntityManager entityManager = getEntityManager();
            TypedQuery<T> query = entityManager.createQuery(queryStr, clazz);
            if (param != null) {
                if (param instanceof String) {
                    query.setParameter("name", param);
                } else if (param instanceof Long) {
                    query.setParameter("id", param);
                }
            }
            List<T> result = query.getResultList();

            // Log exit
            Helper.logExit(logger, signature, new Object[] {
                result
            });

            return result;
        } catch (IllegalStateException e) {
            // Log exception
            throw Helper.logException(logger, signature, new ServiceRequestToolException(
                    "The entity manager has been closed.", e));
        } catch (PersistenceException e) {
            // Log exception
            throw Helper.logException(logger, signature, new ServiceRequestToolException(
                    "An error has occurred while accessing the persistence.", e));
        }
    }

    // /**
    // * Get the entities from DB.
    // *
    // * @param <T>
    // * the class type
    // * @param logger
    // * the logger
    // * @param signature
    // * the signature
    // * @param queryStr
    // * the query string
    // * @param clazz
    // * the class
    // * @param param
    // * the param value
    // * @param hasParam
    // * the flag whether has parameter
    // * @return the entities
    // * @throws ServiceRequestToolException
    // * if any error occurs
    // */
    // private <T extends IdentifiableEntity> List<T> getEnities(Logger logger, String signature, String queryStr,
    // Class<T> clazz, long param, boolean hasParam) throws ServiceRequestToolException {
    // // Log entry
    // if (!hasParam) {
    // Helper.logEntrance(logger, signature, null, null);
    // } else {
    // Helper.logEntrance(logger, signature, new String[] {"divisionId"}, new Object[] {param});
    //
    // Helper.checkPositive(logger, signature, param, "divisionId");
    // }
    //
    // try {
    // EntityManager entityManager = getEntityManager();
    // TypedQuery<T> query = entityManager.createQuery(queryStr, clazz);
    // query.setParameter("id", param);
    // List<T> result = query.getResultList();
    //
    // // Log exit
    // Helper.logExit(logger, signature, new Object[] {result});
    //
    // return result;
    // } catch (IllegalStateException e) {
    // // Log exception
    // throw Helper.logException(logger, signature, new ServiceRequestToolException(
    // "The entity manager has been closed.", e));
    // } catch (PersistenceException e) {
    // // Log exception
    // throw Helper.logException(logger, signature, new ServiceRequestToolException(
    // "An error has occurred while accessing the persistence.", e));
    // }
    // }
}

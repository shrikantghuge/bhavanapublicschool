/*
 * This code is copyright (c) 2013 - 2015 EMC Corporation.
 */
package com.emc.gs.tools.srf.services;

import java.io.File;
import java.util.List;

import org.springframework.transaction.annotation.Transactional;

import com.emc.gs.tools.srf.model.Profile;
import com.emc.gs.tools.srf.model.Request;

/**
 * <p>
 * This interface defines a contract for notifying the responsible person about submitted request.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: The implementation are required to be thread safe.
 * </p>
 *
 * <p>
 * Version 1.1 Change notes:
 *   <ol>
 *     <li>Added <code>sendRequestApprovalEmails</code> method.</li>
 *   </ol>
 * </p>
 * 
 * @author faeton, stevenfrog, MonicaMuranyi
 * @version 1.1
 */
public interface NotificationService {
    /**
     * This method is used to send the request to the sender.
     *
     * @param exportedRequest
     *            the PDF file of exported request. It is set as an attachment.
     * @param request
     *            the Request object to be send. It is used to generate the email body
     * @param profile
     *            the Profile instance holding information necessary to send email
     * @param additionalFile additional file to attach.           
     * @throws IllegalArgumentException
     *             request/exportedRequest/profile is null.
     * @throws NotificationServiceException
     *             if there is any problem when performing operation.
     */
    public void sendRequest(Request request, File exportedRequest, Profile profile, File additionalFile)
        throws NotificationServiceException;

    /**
     * This method is used to send an email to the submitting user, 
     * the approver and all additional recipients configured for a PENDING request.
     *
     * @param exportedRequest
     *            the PDF file of exported request. It is set as an attachment.
     * @param approverEmail
     *            the approver's email
     * @param additionalRecipientsEmails
     *            the additional recipients emails
     * @param request
     *            the Request object to be send. It is used to generate the email body
     * @param profile
     *            the submitter's profile
     * @throws IllegalArgumentException
     *             request/exportedRequest/profile is null.
     * @throws com.emc.gs.tools.srf.services.NotificationServiceException
     *             if there is any problem when performing operation.
     * @since 1.1
     */
    void sendRequestApprovalEmails(String approverEmail, List<String> additionalRecipientsEmails, Request request,
            File exportedRequest, Profile profile) throws NotificationServiceException;
}

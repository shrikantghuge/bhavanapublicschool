/*
 * This code is copyright (c) 2014-2015 EMC Corporation.
 */
package com.emc.gs.tools.srf.services.impl;

import java.util.List;

import javax.annotation.PostConstruct;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceException;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.apache.log4j.Logger;
import org.springframework.transaction.annotation.Transactional;

import com.emc.gs.tools.srf.AuthorizationException;
import com.emc.gs.tools.srf.ServiceRequestToolConfigurationException;
import com.emc.gs.tools.srf.model.Operation;
import com.emc.gs.tools.srf.model.OperationLog;
import com.emc.gs.tools.srf.model.ServiceContext;
import com.emc.gs.tools.srf.model.SynchronizedOperationLog;
import com.emc.gs.tools.srf.model.User;
import com.emc.gs.tools.srf.services.AppService;
import com.emc.gs.tools.srf.services.OperationLogService;
import com.emc.gs.tools.srf.services.ServiceRequestToolException;

/**
 * <p>
 * This class is the implementation of the OperationLogService. It utilizes JPA EntityManager for necessary
 * operations.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is effectively thread safe after configuration, the
 * configuration is done in a thread safe manner.
 * </p>
 *
 * <p>
 * <strong>Changes V1.1:</strong>
 * <strong>SRT Phase 4 - ET Assembly 2</strong>
 * <ul>
 * <li>Change get()/add() methods to require the current user present.</li>
 * <li>Change get() method to accept entity id and begin sequence parameters.</li>
 * <li>Add getLastSynchronizedSequence() method to get last sequence of synchronized operation logs.</li>
 * <li>Add operationLogSynchronizedDown() method to process logs after it is synchronized down.</li>
 * <li>Add operationLogSynchronizedUp() method to process logs after it is synchronized up.</li>
 * </ul>
 * </p>
 *
 * <p>
 * <strong>Changes V1.2:</strong>
 * <strong>SRT Phase 4 - Add Postgresql Support Assembly</strong>
 * <ul>
 * <li>The selectOperationLogSequenceValueQuery field is added.</li>
 * <li>Setter method is added for selectOperationLogSequenceValueQuery field.</li>
 * <li>The checkInit method is updated to check selectOperationLogSequenceValueQuery field.</li>
 * <li>The add method is updated to use this new injected field to query next sequence value.</li>
 * </ul>
 * </p>
 *
 * <p>
 * <strong>Changes V1.3:</strong>
 * <strong>SRT 1.1 Approval Process Assembly</strong>
 * <ul>
 * <li>Added allUserLogs param to get method.</li>
 * <li>Extracted buildSelectOperationLogQuery method.</li>
 * </ul>
 * </p>
 *
 * @author zsudraco, MonicaMuranyi
 * @version 1.3
 */
public class OperationLogServiceImpl extends BasePersistenceService implements OperationLogService {
    /**
     * <p>
     * Represents the class name.
     * </p>
     */
    private static final String CLASSNAME = OperationLogServiceImpl.class.getName();

    /**
     * Represents the appService. It is modified by setter. It is injected by Spring. It can not be null after injected.
     *
     * @since SRT Phase 4 - ET Assembly 2
     */
    private AppService appService;

    /**
     * Represents the query to select operation log sequence value. It is modified by setter. It is injected by Spring.
     * It can not be null/empty after injected.
     *
     * @since SRT Phase 4 - Add Postgresql Support Assembly
     */
    private String selectOperationLogSequenceValueQuery;

    /**
     * Creates instance of the class.
     */
    public OperationLogServiceImpl() {
        // empty
    }

    /**
     * Add an operation log.
     *
     * @param log
     *            the log to create
     * @return The created log
     * @throws IllegalArgumentException
     *             if log is null
     * @throws AuthorizationException
     *             if user is not allowed to add operation log
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     */
    @Override
    @Transactional(rollbackFor = ServiceRequestToolException.class)
    public void add(OperationLog log) throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#add(OperationLog log)";
        Logger logger = getLogger();

        // Log entry
        Helper.logEntrance(logger, signature, new String[]{"log"}, new Object[]{log});

        Helper.checkNull(logger, signature, log, "log");

        // Check current user
        User currentUser = ServiceContext.getCurrentUser();
        if (currentUser == null) {
            throw Helper.logException(logger, signature,
                    new AuthorizationException("User must be logged in to add operation log."));
        }

        try {
            EntityManager entityManager = getEntityManager();

            // We only preserve the last log for an entity, so first to clear existing log
            Query query = entityManager.createQuery(
                    "delete from OperationLog l where l.entityType = :entityType and l.entityId = :entityId"
                    + " and l.userIdentifier = :userIdentifier");
            query.setParameter("entityType", log.getEntityType());
            query.setParameter("entityId", log.getEntityId());
            query.setParameter("userIdentifier", currentUser.getUserIdentifier());
            query.executeUpdate();

            Number seq = (Number) entityManager.createNativeQuery(
                selectOperationLogSequenceValueQuery).getSingleResult();
            log.setSeq(seq.longValue());

            // Sequence is not unique enough. Because even a single user can have multiple local apps
            // running on multiple devices, like on his desktop PC and his Smart Phone..
            // So use [user identifier] + [app identifier] + [sequence]
            log.setLogId(currentUser.getUserIdentifier() + "-" + appService.getAppIdentifier() + "-" + seq);

            // Add log
            log.setUserIdentifier(currentUser.getUserIdentifier());
            entityManager.persist(log);

            // Log exit
            Helper.logExit(logger, signature, null);
        } catch (IllegalStateException e) {
            // Log exception
            throw Helper.logException(logger, signature, new ServiceRequestToolException(
                    "The entity manager has been closed.", e));
        } catch (PersistenceException e) {
            // Log exception
            throw Helper.logException(logger, signature, new ServiceRequestToolException(
                    "An error has occurred while accessing the persistence.", e));
        }
    }

    /**
     * Gets all logs for the specified entity type, entity ID and begin sequence.
     *
     * @param entityType
     *            the entityTyp of the logs to retrieve
     * @param entityId
     *            the entityId for the search, if present then only
     *            log for that entity ID will be returned
     * @param beginSeq
     *            the begin sequence for the search, if present then only
     *            logs newer than this sequence will be returned
     * @param allUserLogs flag indicating whether to get all the logs, not only the ones related to the current user
     * @return The list of the matching operation logs
     * @throws IllegalArgumentException
     *             if entityType is null or empty
     * @throws AuthorizationException
     *             if user is not allowed to get operation log
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     */
    public List<OperationLog> get(String entityType, Long entityId, Long beginSeq, boolean allUserLogs) throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#get(String entityType, Long entityId, Long beginSeq)";
        Logger logger = getLogger();

        // Log entry
        Helper.logEntrance(logger, signature, new String[]{"entityType", "entityId", "beginSeq"},
                new Object[]{entityType, entityId, beginSeq});

        Helper.checkStrNullEmpty(logger, signature, entityType, "entityType");

        // Check current user
        User currentUser = ServiceContext.getCurrentUser();
        if (currentUser == null) {
            throw Helper.logException(logger, signature,
                    new AuthorizationException("User must be logged in to get operation logs."));
        }

        try {
            TypedQuery<OperationLog> query = buildSelectOperationLogQuery(entityId, beginSeq, entityType, allUserLogs);
            List<OperationLog> result = query.getResultList();
            // Log exit
            Helper.logExit(logger, signature, new Object[]{result});
            return result;
        } catch (IllegalStateException e) {
            // Log exception
            throw Helper.logException(logger, signature, new ServiceRequestToolException(
                    "The entity manager has been closed.", e));
        } catch (PersistenceException e) {
            // Log exception
            throw Helper.logException(logger, signature, new ServiceRequestToolException(
                    "An error has occurred while accessing the persistence.", e));
        }
    }
    
    /**
     * Constructs the query which gets all logs for the specified entity type, entity ID and begin sequence.
     *
     * @param entityId
     *            the entityId for the search, if present then only
     *            log for that entity ID will be returned
     * @param beginSeq
     *            the begin sequence for the search, if present then only
     *            logs newer than this sequence will be returned
     * @param entityType
     *            the entityTyp of the logs to retrieve
     * @param allUserLogs flag indicating whether to get all the logs, not only the ones related to the current user
     * @return The select operation logs query
     * @since 1.3
     */
    private TypedQuery<OperationLog> buildSelectOperationLogQuery(Long entityId, Long beginSeq, String entityType, boolean allUserLogs){
        String q = "select o from OperationLog o where o.entityType = :entityType";
        if(!allUserLogs){
            q += " and o.userIdentifier = :userIdentifier";
        }
        if (entityId != null) {
            q += " and o.entityId = :entityId";
        }
        if (beginSeq != null) {
            q += " and o.seq > :beginSeq";
        }
        q += " order by o.seq asc";

        TypedQuery<OperationLog> query = getEntityManager().createQuery(q, OperationLog.class);
        query.setParameter("entityType", entityType);
        if(!allUserLogs){
            query.setParameter("userIdentifier", ServiceContext.getCurrentUser().getUserIdentifier());
        }
        if (entityId != null) {
            query.setParameter("entityId", entityId);
        }
        if (beginSeq != null) {
            query.setParameter("beginSeq", beginSeq);
        }
        return query;
    }

    /**
     * Gets last synchronized sequence for the specified entity type.
     *
     * @param entityType
     *            the entityTyp retrieve last synchronized sequence
     * @return The last synchronized sequence for the specified entity type
     * @throws IllegalArgumentException
     *             if entityType is null or empty
     * @throws AuthorizationException
     *             if user is not allowed to get last synchronized sequence
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     */
    public Long getLastSynchronizedSequence(String entityType) throws ServiceRequestToolException {

        final String signature = CLASSNAME + "#getLastSynchronizedSequence(String entityType)";
        Logger logger = getLogger();

        // Log entry
        Helper.logEntrance(logger, signature, new String[]{"entityType"}, new Object[]{entityType});

        Helper.checkStrNullEmpty(logger, signature, entityType, "entityType");

        // Check current user
        User currentUser = ServiceContext.getCurrentUser();
        if (currentUser == null) {
            throw Helper.logException(logger, signature,
                    new AuthorizationException("User must be logged in to get last synchronized sequence."));
        }

        try {
            // Find max sequence in SynchronizedOperationLog
            String q = "select max(o.seq) from SynchronizedOperationLog o"
                    + " where o.entityType = :entityType"
                    + " and o.userIdentifier = :userIdentifier";

            TypedQuery<Long> query = getEntityManager().createQuery(q, Long.class);
            query.setParameter("entityType", entityType);
            query.setParameter("userIdentifier", currentUser.getUserIdentifier());
            query.setMaxResults(1);

            List<Long> result = query.getResultList();
            // Log exit
            Helper.logExit(logger, signature, new Object[]{result});
            return result != null && result.size() > 0 ? result.get(0) : null;
        } catch (IllegalStateException e) {
            // Log exception
            throw Helper.logException(logger, signature, new ServiceRequestToolException(
                    "The entity manager has been closed.", e));
        } catch (PersistenceException e) {
            // Log exception
            throw Helper.logException(logger, signature, new ServiceRequestToolException(
                    "An error has occurred while accessing the persistence.", e));
        }
    }

    /**
     * Processes operation log after it is synchronized down.
     *
     * @param log
     *            the log to process after it is synchronized down
     * @throws IllegalArgumentException
     *             if log is null
     * @throws AuthorizationException
     *             if user is not allowed to process operation log
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     */
    @Transactional(rollbackFor = ServiceRequestToolException.class)
    public void operationLogSynchronizedDown(OperationLog log) throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#operationLogSynchronizedDown(OperationLog log)";
        Logger logger = getLogger();

        // Log entry
        Helper.logEntrance(logger, signature, new String[]{"log"}, new Object[]{log});

        Helper.checkNull(logger, signature, log, "log");

        // Check current user
        User currentUser = ServiceContext.getCurrentUser();
        if (currentUser == null) {
            throw Helper.logException(logger, signature,
                    new AuthorizationException("User must be logged in to process synchronized down operation log."));
        }

        try {
            // Copy given OperationLog to SynchronizedOperationLog and save it
            SynchronizedOperationLog synchronizedLog = new SynchronizedOperationLog();
            synchronizedLog.setLogId(log.getLogId());
            synchronizedLog.setSeq(log.getSeq());
            synchronizedLog.setEntityId(log.getEntityId());
            synchronizedLog.setCorrelatedId(log.getCorrelatedId());
            synchronizedLog.setEntityType(log.getEntityType());
            synchronizedLog.setOperation(log.getOperation());
            synchronizedLog.setTimestamp(log.getTimestamp());
            synchronizedLog.setUserIdentifier(currentUser.getUserIdentifier());

            getEntityManager().persist(synchronizedLog);

            // Log exit
            Helper.logExit(logger, signature, null);
        } catch (IllegalStateException e) {
            // Log exception
            throw Helper.logException(logger, signature, new ServiceRequestToolException(
                    "The entity manager has been closed.", e));
        } catch (PersistenceException e) {
            // Log exception
            throw Helper.logException(logger, signature, new ServiceRequestToolException(
                    "An error has occurred while accessing the persistence.", e));
        }
    }

    /**
     * Processes operation log after it is synchronized up.
     *
     * @param log
     *            the log to process after it is synchronized up
     * @throws IllegalArgumentException
     *             if log is null
     * @throws AuthorizationException
     *             if user is not allowed to process operation log
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     */
    @Transactional(rollbackFor = ServiceRequestToolException.class)
    public void operationLogSynchronizedUp(OperationLog log) throws ServiceRequestToolException {

        final String signature = CLASSNAME + "#operationLogSynchronizedUp(OperationLog log)";
        Logger logger = getLogger();

        // Log entry
        Helper.logEntrance(logger, signature, new String[] {"log"}, new Object[] {log});


        // Check current user
        User currentUser = ServiceContext.getCurrentUser();
        if (currentUser == null) {
            throw Helper.logException(logger, signature,
                    new AuthorizationException("User must be logged in to process synchronized up operation log."));
        }

        try {

            // Delete log after synchronized up
            Query query = getEntityManager().createQuery(
                    "delete from OperationLog o where o.logId = :logId and o.userIdentifier = :userIdentifier");

            query.setParameter("logId", log.getLogId());
            query.setParameter("userIdentifier", currentUser.getUserIdentifier());
            query.executeUpdate();

            if (log.getOperation() == Operation.CREATE) {
                // Update the correlated id of entity
                query = getEntityManager().createQuery(
                        "update " + log.getEntityType() + " e"
                        + " set e.correlatedId = :correlatedId"
                        + " where e.id = :entityId"
                        + " and e.userIdentifier = :userIdentifier");
                query.setParameter("correlatedId", log.getCorrelatedId());
                query.setParameter("entityId", log.getEntityId());
                query.setParameter("userIdentifier", currentUser.getUserIdentifier());
                query.executeUpdate();

                // Update the correlated id of log if any
                query = getEntityManager().createQuery(
                        "update OperationLog o"
                        + " set o.correlatedId = :correlatedId"
                        + " where o.entityId = :entityId"
                        + " and o.entityType = :entityType"
                        + " and o.userIdentifier = :userIdentifier");

                query.setParameter("correlatedId", log.getCorrelatedId());
                query.setParameter("entityId", log.getEntityId());
                query.setParameter("entityType", log.getEntityType());
                query.setParameter("userIdentifier", currentUser.getUserIdentifier());
                query.executeUpdate();
            }

            // Log exit
            Helper.logExit(logger, signature, null);
        } catch (IllegalStateException e) {
            // Log exception
            throw Helper.logException(logger, signature, new ServiceRequestToolException(
                    "The entity manager has been closed.", e));
        } catch (PersistenceException e) {
            // Log exception
            throw Helper.logException(logger, signature, new ServiceRequestToolException(
                    "An error has occurred while accessing the persistence.", e));
        }
    }

    /**
     * This method checks whether the instance of the class was initialized properly.
     *
     * @throws ServiceRequestToolConfigurationException
     *             if entityManager/appService is null, or selectOperationLogSequenceValueQuery is null or empty
     */
    @PostConstruct
    @Override
    protected void checkInit() {
        super.checkInit();
        Helper.checkState(appService == null, "'appService' can't be null.");
        Helper.checkState(selectOperationLogSequenceValueQuery == null ||
            selectOperationLogSequenceValueQuery.trim().length() == 0,
            "'selectOperationLogSequenceValueQuery' can't be null or empty.");
    }

    /**
     * Setter method for property <tt>appService</tt>.
     *
     * @param appService
     *            value to be assigned to property appService
     */
    public void setAppService(AppService appService) {
        this.appService = appService;
    }

    /**
     * Setter method for property <tt>selectOperationLogSequenceValueQuery</tt>.
     *
     * @param selectOperationLogSequenceValueQuery
     *            value to be assigned to property selectOperationLogSequenceValueQuery
     */
    public void setSelectOperationLogSequenceValueQuery(String selectOperationLogSequenceValueQuery) {
        this.selectOperationLogSequenceValueQuery = selectOperationLogSequenceValueQuery;
    }
}

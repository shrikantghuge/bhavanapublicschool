/*
 * This code is copyright (c) 2014-2015 EMC Corporation.
 */
package com.emc.gs.tools.srf.services.impl;

import java.util.List;

import javax.annotation.PostConstruct;
import javax.persistence.TypedQuery;

import org.apache.commons.lang.StringUtils;

import com.emc.gs.tools.srf.AuthorizationException;
import com.emc.gs.tools.srf.ServiceRequestToolConfigurationException;
import com.emc.gs.tools.srf.model.CorrelatedIdentifiableEntity;
import com.emc.gs.tools.srf.model.Operation;
import com.emc.gs.tools.srf.model.OperationLog;
import com.emc.gs.tools.srf.model.Profile;
import com.emc.gs.tools.srf.model.Request;
import com.emc.gs.tools.srf.model.ServiceContext;
import com.emc.gs.tools.srf.model.SynchronizedOperationLog;
import com.emc.gs.tools.srf.model.User;
import com.emc.gs.tools.srf.services.AlreadySynchronizedException;
import com.emc.gs.tools.srf.services.AppService;
import com.emc.gs.tools.srf.services.EntityNotFoundException;
import com.emc.gs.tools.srf.services.OperationLogService;
import com.emc.gs.tools.srf.services.ServiceRequestToolException;

/**
 * <p>
 * This class is the base class that adds the authorization check and operation log for the create, update, delete and
 * get persistence operations of CorrelatedIdentifiableEntity. It extends from BaseGenericService.
 * </p>
 *
 * <p>
 * <strong>Thread safety</strong>: This class is effectively thread safe after configuration, the configuration is done
 * in a thread safe manner.
 * </p>
 *
 * <p>
 * <strong>Changes V1.1:</strong>
 * <strong>SRT Phase 4 - ET Assembly 3</strong>
 * <ul>
 * <li>Make beforeCreate throws ServiceRequestToolException.</li>
 * </ul>
 * </p>
 * 
 * <p>
 * <strong>Changes V1.2:</strong>
 * <strong>SRT 1.1 Approval Process Assembly</strong>
 * <ul>
 * <li>Added hasPrivilegesToAccess method.</li>
 * <li>Updated beforeUpdate and afterGet methods to call hasPrivilegesToUpdate method.</li>
 * <li>Updated createOperationLog and beforeCreate methods to handle Profile entities differently.</li>
 * </ul>
 * </p>
 * 
 * @author TCSASSEMBLER, MonicaMuranyi
 * @version 1.2
 * @since SRT Phase 4 - ET Assembly 2
 */
public class BaseCorrelatedEntityService<T extends CorrelatedIdentifiableEntity> extends BaseGenericService<T> {

    /**
     * Represents the OperationLogService. It is modified by setter. It is injected by Spring. It can not be null after
     * injected.
     */
    private OperationLogService operationLogService;

    /**
     * Represents the appService. It is modified by setter. It is injected by Spring. It can not be null after injected.
     *
     * @since SRT Phase 4 - ET Assembly 2
     */
    private AppService appService;

    /**
     * Constructor with entity class.
     * 
     * @param entityClass
     *            the entity class used for the persistence
     * @throws IllegalArgumentException
     *             if entityClass is null.
     */
    protected BaseCorrelatedEntityService(Class<T> entityClass) {
        super(entityClass);
    }

    /**
     * Creates an operation log.
     * 
     * @param entity
     *            the entity to be logged
     * @param operation
     *            the operation type to be logged
     * @throws ServiceRequestToolException
     *             if there is any error while creating an OperationLog
     */
    private void createOperationLog(CorrelatedIdentifiableEntity entity, Operation operation)
            throws ServiceRequestToolException {

        OperationLog logToSync = ServiceContext.getCurrentOperationLog();
        if (logToSync != null) {
            logToSync.setCorrelatedId(entity.getId()); // The entity ID is generated for create
            // Operation log synchronized
            operationLogService.operationLogSynchronizedDown(logToSync);

            if (!appService.isCloudApp() && !entity.getClass().equals(Profile.class)) {
                // For synchronization on local app side, no need to add operation log, return
                return;
            }
        }

        // Add operation log
        OperationLog log = new OperationLog();
        log.setEntityType(entity.getClass().getSimpleName());
        log.setEntityId(entity.getId());
        log.setCorrelatedId(entity.getCorrelatedId());
        log.setUserIdentifier(entity.getUserIdentifier());
        log.setOperation(operation);
        log.setTimestamp(System.currentTimeMillis());
        operationLogService.add(log);

        if (appService.isCloudApp()) {
            // For cloud app side, add operation log to response header
            // Refer to ServiceContextInterceptor#postHandle
            ServiceContext.setCurrentOperationLog(log);
        }
    }

    /**
     * Checks operation log is not already synchronized.
     *
     * @throws AlreadySynchronizedException if operation log is already synchronized
     */
    private void checkAlreadySynchronized() throws AlreadySynchronizedException {

        OperationLog logToSync = ServiceContext.getCurrentOperationLog();

        if (logToSync != null) {

            // Check whether the operation log has already been synchronized
            TypedQuery<SynchronizedOperationLog> query = getEntityManager().createQuery(
                    "select o from SynchronizedOperationLog o"
                    + " where o.logId = :logId",
                    SynchronizedOperationLog.class);
            query.setMaxResults(1);
            query.setParameter("logId", logToSync.getLogId());

            List<SynchronizedOperationLog> synchronizedLogs = query.getResultList();

            if (synchronizedLogs != null && synchronizedLogs.size() > 0) {
                SynchronizedOperationLog synchronizedLog = synchronizedLogs.get(0);
                throw new AlreadySynchronizedException(synchronizedLog,
                        "Operation log is already synchronized. Synchronized log id: " + logToSync.getLogId());
            }
        }
    }

    /**
     * Checks user privilege before create. Also sets the user identifier.
     *
     * @param entity
     *            the entity to be created
     * @throws AuthorizationException
     *             if user is not allowed to create
     * @throws AlreadySynchronizedException
     *             if operation log is already synchronized
     * @throws ServiceRequestToolException
     *             if any error occurs.
     */
    @Override
    protected void beforeCreate(T entity) throws AlreadySynchronizedException, ServiceRequestToolException {
        if (appService.isStandaloneMode()) {
            return;
        }

        User currentUser = ServiceContext.getCurrentUser();

        // User must log in to create the CorrelatedIdentifiableEntity
        if (currentUser == null) {
            throw new AuthorizationException("User must be logged in to create " + getEntityClass().getSimpleName());
        }

        // Set user identifier
        // The profile's user identifier corresponds to a certain user
        if(!entity.getClass().equals(Profile.class)){
            entity.setUserIdentifier(currentUser.getUserIdentifier());
        }

        checkAlreadySynchronized();
    }

    /**
     * Adds operation log after create.
     * 
     * @param entity
     *            the entity created
     * @throws ServiceRequestToolException
     *             if any error occurs.
     */
    @Override
    protected void afterCreate(T entity) throws ServiceRequestToolException {
        if (appService.isStandaloneMode()) {
            return;
        }
        createOperationLog(entity, Operation.CREATE);
    }

    /**
     * Checks user privilege before update. Also sets the user identifier.
     * 
     * @param entity
     *            the entity to be updated
     * @throws AuthorizationException
     *             if user is not allowed to update
     * @throws AlreadySynchronizedException
     *             if operation log is already synchronized
     * @throws EntityNotFoundException
     *             if the entity does not exist
     * @throws ServiceRequestToolException
     *             if any other error occurs
     */
    @Override
    protected void beforeUpdate(T entity) throws ServiceRequestToolException {
        User currentUser = ServiceContext.getCurrentUser();

        if (!appService.isStandaloneMode()) {
            // User must log in to update the CorrelatedIdentifiableEntity
            if (currentUser == null) {
                throw new AuthorizationException("User must be logged in to update " + getEntityClass().getSimpleName());
            }

            // Set user identifier if the entity is not a profile
            // The profile's user identifier corresponds to a certain user
            if(!entity.getClass().equals(Profile.class)){
                // Approvers are able to submit other user's requests so we need to make sure we don't override the submitter
                if(!entity.getClass().equals(Request.class) || StringUtils.isBlank(entity.getUserIdentifier())){
                    entity.setUserIdentifier(currentUser.getUserIdentifier());
                }
            }

            checkAlreadySynchronized();
        }

        // Check existing entity
        T existingEntity = checkEntityExist(entity.getId());

        if (!appService.isStandaloneMode()) {
            // Check user identifier against existing entity's user identifier
            if (!hasPrivilegesToAccess(existingEntity)) {
                throw new AuthorizationException("Insufficient privileges to update " + getEntityClass().getSimpleName());
            }

            // Copy correlated id if not present
            if (entity.getCorrelatedId() <= 0) {
                entity.setCorrelatedId(existingEntity.getCorrelatedId());
            }
        }
    }
    
    /**
     * Decides if the current user has access permissions on the entity
     * 
     * @param entity
     *            The entity
     * @return true if the current user has update permissions
     * @throws ServiceRequestToolException If any exception occurs
     * @since 1.2
     */
    protected boolean hasPrivilegesToAccess(T entity) throws ServiceRequestToolException {
        User currentUser = ServiceContext.getCurrentUser();
        return StringUtils.equals(currentUser.getUserIdentifier(), entity.getUserIdentifier())
                || entity.getClass().equals(Profile.class);
    }

    /**
     * Adds operation log after update.
     * 
     * @param entity
     *            the entity updated
     * @throws ServiceRequestToolException
     *             if any error occurs
     */
    @Override
    protected void afterUpdate(T entity) throws ServiceRequestToolException {
        if (appService.isStandaloneMode()) {
            return;
        }
        createOperationLog(entity, Operation.UPDATE);
    }

    /**
     * Checks user privilege before delete.
     * 
     * @param id
     *            the id of entity to be deleted
     * @return the existing entity to be deleted
     * @throws AuthorizationException
     *             if user is not allowed to delete
     * @throws AlreadySynchronizedException
     *             if operation log is already synchronized
     * @throws EntityNotFoundException
     *             if the entity does not exist
     * @throws ServiceRequestToolException
     *             if any other error occurs
     */
    @Override
    protected T beforeDelete(long id) throws ServiceRequestToolException {
        User currentUser = ServiceContext.getCurrentUser();

        // User must log in to delete the CorrelatedIdentifiableEntity
        if (!appService.isStandaloneMode()) {
            if (currentUser == null) {
                throw new AuthorizationException("User must be logged in to delete " + getEntityClass().getSimpleName());
            }

            checkAlreadySynchronized();
        }

        // Check existing entity
        T existingEntity = checkEntityExist(id);

        // Check user identifier against existing entity's user identifier
        if (!appService.isStandaloneMode()) {
            if (!StringUtils.equals(currentUser.getUserIdentifier(), existingEntity.getUserIdentifier())) {
                throw new AuthorizationException("Insufficient privileges to delete " + getEntityClass().getSimpleName());
            }
        }

        return existingEntity;
    }

    /**
     * Adds operation log after delete.
     * 
     * @param entity
     *            the entity deleted
     * @throws ServiceRequestToolException
     *             if any error occurs
     */
    @Override
    protected void afterDelete(T entity) throws ServiceRequestToolException {
        if (appService.isStandaloneMode()) {
            return;
        }
        createOperationLog(entity, Operation.DELETE);
    }

    /**
     * Checks user privilege before get.
     * 
     * @param id
     *            the id of entity to get
     * @throws AuthorizationException
     *             if user is not allowed to get
     */
    @Override
    protected void beforeGet(long id) {
        if (appService.isStandaloneMode()) {
            return;
        }

        User currentUser = ServiceContext.getCurrentUser();

        // User must log in to get the CorrelatedIdentifiableEntity
        if (currentUser == null) {
            throw new AuthorizationException("User must be logged in to get " + getEntityClass().getSimpleName());
        }
    }

    /**
     * Checks user privilege after get.
     * 
     * @param entity
     *            the entity got
     * @throws AuthorizationException
     *             if user is not allowed to get
     */
    @Override
    protected void afterGet(T entity) throws ServiceRequestToolException {
        if (appService.isStandaloneMode()) {
            return;
        }
        
        User currentUser = ServiceContext.getCurrentUser();

        // Check user identifier against existing entity's user identifier
        if (currentUser != null && entity != null) {
            if (!hasPrivilegesToAccess(entity)) {
                throw new AuthorizationException("Insufficient privileges to get " + getEntityClass().getSimpleName());
            }
        }
    }

    /**
     * This method checks whether the instance of the class was initialized properly.
     * 
     * @throws ServiceRequestToolConfigurationException
     *             if entityManager/appService/operationLogService is null
     */
    @PostConstruct
    @Override
    protected void checkInit() {
        super.checkInit();
        Helper.checkState(operationLogService == null, "'operationLogService' can't be null.");
        Helper.checkState(appService == null, "'appService' can't be null.");
    }

    /**
     * Setter method for property <tt>operationLogService</tt>.
     * 
     * @param operationLogService
     *            value to be assigned to property operationLogService
     */
    public void setOperationLogService(OperationLogService operationLogService) {
        this.operationLogService = operationLogService;
    }

    /**
     * Setter method for property <tt>appService</tt>.
     *
     * @param appService
     *            value to be assigned to property appService
     */
    public void setAppService(AppService appService) {
        this.appService = appService;
    }

    /**
     * Getter method for property <tt>appService</tt>.
     *
     * @return property value of appService
     */
    public AppService getAppService() {
        return appService;
    }

}

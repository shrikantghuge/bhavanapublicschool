/*
 * This code is copyright (c) 2013 - 2014 EMC Corporation.
 */
package com.emc.gs.tools.srf.services.impl;

import org.apache.log4j.Logger;

/**
 * <p>
 * This class is the base class of all service implementations. It simply holds a reference to log4j Logger.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is immutable and thread safe.
 * </p>
 *
 * @author faeton, stevenfrog
 * @version 1.0
 */
public abstract class BaseLoggerService {
    /**
     * This is the logger used for logging. It is initialized in constructor and never changed afterwards. It can not be
     * null.
     */
    private final Logger logger;

    /**
     * This is the constructor of this base service.
     */
    protected BaseLoggerService() {
        this.logger = Logger.getLogger(this.getClass());
    }

    /**
     * <p>
     * Retrieves the logger field.
     * </p>
     *
     * @return the logger
     */
    protected Logger getLogger() {
        return logger;
    }

}

/*
 * This code is copyright (c) 2014 EMC Corporation.
 */
package com.emc.gs.tools.srf.services;

import com.emc.gs.tools.srf.model.Request;

import java.io.File;

/**
 * <p>This interface defines a contract for managing a customer. It is simply extends GenericService to provide necessary
 * create, update, delete and get methods and additionally provides a search method based on criteria.
 * </p>
 * 
 * <p><strong>Thread safety</strong>: The implementation are required to be thread safe.</p>
 *
 * @author isv
 * @version 1.0
 */
public interface FTPService {

    /**
     * <p>Transfers the specified generated XML presentation of specified request to intended FTP server when request
     * is submitted.</p>
     * 
     * @param request a <code>Request</code> representing the request to be sent to server. 
     * @param exportedRequest a <code>File</code> referencing the generated XML presentation of specified request. 
     */
    public void sendRequest(Request request, File exportedRequest) throws ServiceRequestToolException;
}

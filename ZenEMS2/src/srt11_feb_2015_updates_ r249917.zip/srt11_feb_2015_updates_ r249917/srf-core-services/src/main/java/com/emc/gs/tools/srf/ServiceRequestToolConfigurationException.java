/*
 * This code is copyright (c) 2013 - 2014 EMC Corporation.
 */
package com.emc.gs.tools.srf;

/**
 * <p>
 * This exception is thrown when there is any problem with the configuration of application.
 * </p>
 *
 * <p>
 * <strong>Thread safety</strong>: exception class is not thread safety.
 * </p>
 *
 * @author faeton, stevenfrog
 * @version 1.0
 */
public class ServiceRequestToolConfigurationException extends RuntimeException {
    /**
     * The serial version UID.
     */
    private static final long serialVersionUID = 9111944557586413312L;

    /**
     * Creates the exception with the provided message.
     *
     * @param message
     *            the error message.
     */
    public ServiceRequestToolConfigurationException(String message) {
        super(message);
    }

    /**
     * Creates the exception with the provided message and cause.
     *
     * @param message
     *            the error message.
     * @param cause
     *            the error cause.
     */
    public ServiceRequestToolConfigurationException(String message, Throwable cause) {
        super(message, cause);
    }
}

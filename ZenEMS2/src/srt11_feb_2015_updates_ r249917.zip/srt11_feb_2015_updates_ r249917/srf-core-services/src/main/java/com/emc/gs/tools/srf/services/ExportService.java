/*
 * This code is copyright (c) 2013 - 2015 EMC Corporation.
 */
package com.emc.gs.tools.srf.services;

import java.io.OutputStream;
import java.util.List;

import com.emc.gs.tools.srf.model.Request;

/**
 * <p>
 * This interface defines a contract for exporting the data in the application.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: The implementation are required to be thread safe.
 * </p>
 *
 * <p>
 * Version 1.1 Change notes:
 * <ol>
 * <li>Added exportETRequest method.</li>
 * </ol>
 * </p>
 * 
 * @author faeton, stevenfrog, MonicaMuranyi
 * @version 1.1
 */
public interface ExportService {
    /**
     * Exports the requests to the PDF. The contents of the PDF are written to the output stream.
     *
     * @param requests
     *            the list of requests to export
     * @param stream
     *            output stream to write PDF contents.
     * @throws IllegalArgumentException
     *             if requests is null/contains null elements, stream is null.
     * @throws ExportServiceException
     *             if there is any problem when performing operation.
     */
    public void exportRequests(List<Request> requests, OutputStream stream) throws ExportServiceException;

    /**
     * Exports the requests to the PDF. The contents of the PDF are written to
     * the output stream.
     *
     * @param requests
     *            the list of requests to export
     * @param stream
     *            output stream to write PDF contents.
     * @throws IllegalArgumentException
     *             if requests is null/contains null elements, stream is null.
     * @throws ExportServiceException
     *             if there is any problem when performing operation.
     * @since 1.1
     */
    public void exportETRequest(Request request, OutputStream os) throws ExportServiceException;
}

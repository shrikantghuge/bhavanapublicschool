/*
 * This code is copyright (c) 2013 - 2015 EMC Corporation.
 */
package com.emc.gs.tools.srf.services.impl;

import com.emc.gs.tools.srf.AuthorizationException;
import com.emc.gs.tools.srf.ServiceRequestToolConfigurationException;
import com.emc.gs.tools.srf.model.Attachment;
import com.emc.gs.tools.srf.model.Customer;
import com.emc.gs.tools.srf.model.CustomerWorkSite;
import com.emc.gs.tools.srf.model.IdentifiableEntity;
import com.emc.gs.tools.srf.model.LookupCodeEntity;
import com.emc.gs.tools.srf.model.LookupEntity;
import com.emc.gs.tools.srf.model.Phone;
import com.emc.gs.tools.srf.model.Profile;
import com.emc.gs.tools.srf.model.Request;
import com.emc.gs.tools.srf.model.ServiceContext;
import com.emc.gs.tools.srf.model.StartRequestData;
import com.emc.gs.tools.srf.model.User;
import com.emc.gs.tools.srf.model.asd.ASDRequestData;
import com.emc.gs.tools.srf.model.atmos.AtmosCenteraRequestData;
import com.emc.gs.tools.srf.model.atmos.CenteraDesignImpl;
import com.emc.gs.tools.srf.model.atmos.ExistingCenteraCluster;
import com.emc.gs.tools.srf.model.atmos.NewCenteraCluster;
import com.emc.gs.tools.srf.model.bc.BcRequestData;
import com.emc.gs.tools.srf.model.change.ChangeRequestData;
import com.emc.gs.tools.srf.model.change.HoursByMonth;
import com.emc.gs.tools.srf.model.change.RoleHoursByMonth;
import com.emc.gs.tools.srf.model.cta.CTAImplementationArray;
import com.emc.gs.tools.srf.model.cta.CTARequestData;
import com.emc.gs.tools.srf.model.dpad.Avamar;
import com.emc.gs.tools.srf.model.dpad.DPA;
import com.emc.gs.tools.srf.model.dpad.DPADRequestData;
import com.emc.gs.tools.srf.model.dpad.DataDomain;
import com.emc.gs.tools.srf.model.dpad.DataDomainDesign;
import com.emc.gs.tools.srf.model.dpad.DataDomainDesignApplianceModel;
import com.emc.gs.tools.srf.model.dpad.DataDomainDesignImplContent;
import com.emc.gs.tools.srf.model.dpad.DataDomainImplApplianceModel;
import com.emc.gs.tools.srf.model.dpad.DataDomainImplementation;
import com.emc.gs.tools.srf.model.dpad.EDL;
import com.emc.gs.tools.srf.model.dpad.Mozy;
import com.emc.gs.tools.srf.model.dpad.Networker;
import com.emc.gs.tools.srf.model.dpad.RecoverPoint;
import com.emc.gs.tools.srf.model.engagement.EngagementTypeData;
import com.emc.gs.tools.srf.model.estimate.DeliverAction;
import com.emc.gs.tools.srf.model.estimate.EstimatesData;
import com.emc.gs.tools.srf.model.estimate.IPEDURecord;
import com.emc.gs.tools.srf.model.estimate.LOBResource;
import com.emc.gs.tools.srf.model.estimate.LOBResources;
import com.emc.gs.tools.srf.model.healthcheck.HealthCheckRequestData;
import com.emc.gs.tools.srf.model.infrastructure.EnvironmentDetailsHostInfo;
import com.emc.gs.tools.srf.model.infrastructure.EnvironmentDetailsInformation;
import com.emc.gs.tools.srf.model.infrastructure.InfrastructureRequestData;
import com.emc.gs.tools.srf.model.isilon.IsilonRequestData;
import com.emc.gs.tools.srf.model.mainframe.MainframeRequestData;
import com.emc.gs.tools.srf.model.mainframe.ServiceData;
import com.emc.gs.tools.srf.model.move.MoveRequestData;
import com.emc.gs.tools.srf.model.move.SiteInformation;
import com.emc.gs.tools.srf.model.mss.MSSArray;
import com.emc.gs.tools.srf.model.mss.MSSRequestData;
import com.emc.gs.tools.srf.model.residency.ResidencyRequestData;
import com.emc.gs.tools.srf.model.residency.ResidencyRoleSkillLevels;
import com.emc.gs.tools.srf.model.residency.RoleSkillLevel;
import com.emc.gs.tools.srf.model.sourceone.SourceOneRequestData;
import com.emc.gs.tools.srf.model.unified.CelerraDetailInformation;
import com.emc.gs.tools.srf.model.unified.NasIpReplicationInformation;
import com.emc.gs.tools.srf.model.unified.NasMigrationInformation;
import com.emc.gs.tools.srf.model.unified.UnifiedRequestData;
import com.emc.gs.tools.srf.model.vblock.VblockRequestData;
import com.emc.gs.tools.srf.model.vipr.ViprRequestData;
import com.emc.gs.tools.srf.model.vmware.VMwareRequestData;
import com.emc.gs.tools.srf.model.vmware.VMwareVblock;
import com.emc.gs.tools.srf.model.vmware.VMwareView;
import com.emc.gs.tools.srf.model.xtreme.XtremeDesignImpl;
import com.emc.gs.tools.srf.model.xtreme.XtremeRequestData;
import com.emc.gs.tools.srf.services.EnabledTabs;
import com.emc.gs.tools.srf.services.ServiceRequestToolException;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.hibernate3.Hibernate3Module;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.math.BigDecimal;
import java.text.NumberFormat;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * <p>
 * Helper class for the component. It provides useful common methods for all the classes in this component.
 * </p>
 * <p>
 * <strong>Thread Safety: </strong> This class has no state, and thus it is thread safe.
 * </p>
 * <p>
 * <strong>Change 1.1:</strong> <strong>BUGR-10829</strong>
 * <ul>
 * <li>change fixStringForLike to support case insensitive search</li>
 * </ul>
 * </p>
 * <p>
 * <strong>Changes V1.2:</strong> <strong>SRT Bug Fixes - F121, F153, F154, F162</strong>
 * <ul>
 * <li>Added checkDecimal method.</li>
 * </ul>
 * </p>
 *
 * <p>
 * <strong>Changes V1.3:</strong> <strong>SRT Phase 3-1 - CTA Rainfinity and MSS Tabs Assembly</strong>
 * <ul>
 * <li>Added more methods to check integer/decimal.</li>
 * </ul>
 * </p>
 *
 * <p>
 * <strong>Changes V1.4:</strong> <strong>SRT Phase 2 Release Assembly</strong>
 * <ul>
 * <li>Update checkPhone() method.</li>
 * </ul>
 * </p>
 *
 * <p>
 * <strong>Changes V1.5:</strong> <strong>SRT Phase 3-5 - BRS Tabs Part 1 Assembly</strong>
 * <ul>
 * <li>Add checkSitesInvolved() method.</li>
 * <li>Add OBJECT_MAPPER field and change toString(Object obj) method to use OBJECT_MAPPER
 * to convert object to string.</li>
 * </ul>
 * </p>
 *
 * <p>
 * <strong>Changes V1.6:</strong> <strong>SRT Phase 3-5 - BRS Tabs Part 2 Assembly</strong>
 * <ul>
 * <li>Add trimToEmpty/lookupEntity2String/enum2String/isBooleanTrue methods.</li>
 * </ul>
 * </p>
 *
 * <p>
 * <strong>Changes V1.7:</strong> <strong>SRT Phase 3-5 - BRS Tabs Part 3 Assembly</strong>
 * <ul>
 * <li>Add isBooleanFalse() method.</li>
 * </ul>
 * </p>
 *
 * <p>
 * <strong>Changes V1.8:</strong> <strong>SRT Cloud Synchronization - Cloud App Assembly</strong>
 * <ul>
 * <li>Changed toString method to exclude HttpServletRequest and HttpServletResponse.</li>
 * <li>Added helper method to check user privileges based on userIdentifier.</li>
 * </ul>
 * </p>
 *
 * <p>
 * <strong>Changes V1.9:</strong>
 * <strong>SRT Phase 4 - ET Assembly 1</strong>
 * <ul>
 * <li>SRT Phase 4 refactor.</li>
 * </ul>
 * </p>
 *
 * <p>
 * <strong>Changes V2.0:</strong>
 * <strong>SRT Phase 4 - ET Assembly 3</strong>
 * <ul>
 * <li>Moved TMP_UPLOAD_SUFFIX from RequestController to here.</li>
 * <li>Added TMP_DOWNLOAD_SUFFIX, PERSIST_FILE_PATH_PATTERN.</li>
 * <li>Merged the objectMapper from SynchronizationServiceImpl.</li>
 * <li>Moved copyEntity from SynchronizationServiceImpl to here and renamed it to deepCloneEntity.</li>
 * <li>Added zeroRequestId.</li>
 * <li>Refactored the copyRequest method into smaller ones and reused in zeroRequestId</li>
 * <li>RoleHoursByMonth was missing in the last assembly. zero their ids as well.</li>
 * </ul>
 * </p>
 *
 * <p>
 * Version 2.1 (SRT Phase 4 - ET Release Assembly Assembly 1.0) Change notes:
 *   <ol>
 *     <li>Updated {@link #copyRequest(Request, EnabledTabs)} method to copy newly defined "projectRegulatoryType"
 *     property.</li>
 *   </ol>
 * </p>
 *
 * <p>
 * Version 2.2 (SRT 4 OCT2014 Updates Part 1 Assembly) Change notes:
 *   <ol>
 *     <li>Updated {@link #zeroXtremeRequestDataId(XtremeRequestData)} method to handle newly added entity.</li>
 *   </ol>
 * </p>
 *
 * <p>
 * Version 2.3 (SRT 4 OCT2014 Updates Part 2 Assembly) Change notes:
 *   <ol>
 *     <li>Updated {@link #zeroDPADRequestDataId(DPADRequestData)} method to handle new design for <code>RecoverPoint
 *     </code> class.</li>
 *     <li>Updated {@link #zeroResidencyRequestDataId(ResidencyRequestData)} method to handle new fields for
 *     <code>ResidencyRoleSkillLevels</code> class.</li>
 *   </ol>
 * </p>
 *
 * <p>
 * Version 2.4 (SRT 1.1 DEC 2014 Risk Calculation Assembly) Change notes:
 *   <ol>
 *     <li>Updated {@link #copyRequest(Request, EnabledTabs)} method to copy <code>riskCalculationData</code> property
 *     of request.</li>
 *   </ol>
 * </p>
 *
 * <p>
 * Version 2.5 Change notes:
 *   <ol>
 *     <li>Updated {@link #copyRequest(Request, EnabledTabs)} method to copy project description.</li>
 *   </ol>
 * </p>
 *
 * <p>
 * Version 2.6 Change notes:
 *   <ol>
 *     <li>Updated {@link #zeroRequestId(Request)} method to add separate logic for SAN/Connectivity data.</li>
 *     <li>Updated {@link #copyRequest(Request, EnabledTabs)} method to add separate logic for SAN/Connectivity data.
 *     </li>
 *   </ol>
 * </p>
 *
 * <p>
 * Version 2.7 Change notes:
 *   <ol>
 *     <li>Added support for Symm MF, Symm OS data.</li>
 *   </ol>
 * </p>
 *
 * <p>
 * Version 2.8 Change notes:
 *   <ol>
 *     <li>Added {@link #generateExportFileName(Request)} method.</li>
 *   </ol>
 * </p>
 * 
 * <p>
 * Version 2.9 Change notes:
 *   <ol>
 *     <li>Added {@link #zeroProfileId(Request)} method.</li>
 *   </ol>
 * </p>
 *
 * <p>
 * Version 2.10 Change notes:
 *   <ol>
 *     <li>Added {@link #checkSalesOrderItemNumber(Logger, String, String, String)} method.</li>
 *     <li>Added {@link #checkWBSNumber(Logger, String, String, String, boolean)} method.</li>
 *     <li>Added {@link #checkZipPostalCode(Logger, String, String, String)} method.</li>
 *     <li>Added {@link #isRiskCalculationRequired(Request)} method.</li>
 *   </ol>
 * </p>
 *
 * <p>
 * Version 2.11 Change notes:
 *   <ol>
 *     <li>Updated {@link #WBS_NUMBER_PATTERN} constant.</li>
 *   </ol>
 * </p>
 * 
 * @author stevenfrog, isv, MonicaMuranyi
 * @version 2.11
 */
public final class Helper {

    /**
     * <p>
     * The Jackson mapper used to log object.
     * </p>
     * @since SRT Phase 3-5 - BRS Tabs Part 1 Assembly
     */
    public static final ObjectMapper OBJECT_MAPPER = new ObjectMapper();

    /**
     * Represents 100.
     */
    public static final BigDecimal HUNDRED = new BigDecimal(100);

    /**
     * <p>
     * Represents the suffix of temporary uploaded attachment file.
     * </p>
     */
    public static final String TMP_UPLOAD_SUFFIX = ".tmpupload";

    /**
     * <p>
     * Represents the suffix of temporary downloaded attachment file during the synchronization.
     * </p>
     */
    public static final String TMP_DOWNLOAD_SUFFIX = ".tmpdownload";

    /**
     * <p>A pattern for valid zip/postal code.</p>
     * 
     * @since 2.10
     */
    private static final Pattern ZIP_POSTAL_CODE_PATTERN = Pattern.compile("^[a-zA-Z0-9\\-\\s]+");

    /**
     * <p>
     * Represents the regular expression pattern for a persistent attachment.
     * This regular expression identifies the attachment that is synchronized up from a local app.
     * </p>
     */
    public static final Pattern PERSISTENT_ATTACHMENT_PATTERN = Pattern.compile(
            "^(.+)\\.([1-9][0-9]*)\\." +
                    "(([0-9a-fA-F]){8}-([0-9a-fA-F]){4}-([0-9a-fA-F]){4}-([0-9a-fA-F]){4}-([0-9a-fA-F]){12})$");

    /**
     * <p>
     * Represents the entrance message.
     * </p>
     */
    private static final String MESSAGE_ENTRANCE = "Entering method %1$s.";

    /**
     * <p>
     * Represents the exit message.
     * </p>
     */
    private static final String MESSAGE_EXIT = "Exiting method %1$s.";

    /**
     * <p>
     * Represents the error message.
     * </p>
     */
    private static final String MESSAGE_ERROR = "Error in method %1$s. Details:";

    /**
     * The default "Delivery Action" to be used in export file name
     * 
     * @since 2.8
     */
    private static final String DELIVERY_ACTION_FIELD_NAME = "ACTIVITYTYPE";

    /**
     * The default "DXP Opportunity Number" to be used in export file name
     * 
     * @since 2.8
     */
    private static final String DXP_OPPORTUNITY_NUMBER_FIELD_NAME = "OPPNUMBER";

    /**
     * The default "Quote Number" to be used in export file name
     * 
     * @since 2.8
     */
    private static final String DIRECT_EXPRESS_DX_QUOTE_NUMBER_FIELD_NAME = "QUOTENUMBER";

    /**
     * <p>A <code>Pattern</code></code> matching the sales order item numbers.</p>
     * 
     * @since 2.10
     */
    private static final Pattern SALES_ORDER_ITEM_NUMBER_PATTERN = Pattern.compile("\\d\\d");

    /**
     * <p>A <code>Pattern</code></code> matching the WBS numbers.</p>
     * 
     * @since 2.10
     */
    private static final Pattern WBS_NUMBER_PATTERN = Pattern.compile("PS\\-\\d\\d\\d\\d\\d\\d\\d\\-\\d\\d");

    /**
     * <p>A <code>Pattern</code></code> matching the WBS numbers for MS LOB.</p>
     * 
     * @since 2.10
     */
    private static final Pattern MS_WBS_NUMBER_PATTERN = Pattern.compile("MS\\-\\d\\d\\d\\d\\d\\d\\-\\d\\d");

    static {
        Hibernate3Module hbm = new Hibernate3Module();
        hbm.enable(Hibernate3Module.Feature.FORCE_LAZY_LOADING);

        OBJECT_MAPPER.registerModule(hbm);
        OBJECT_MAPPER.disable(SerializationFeature.FAIL_ON_EMPTY_BEANS);
        OBJECT_MAPPER.setSerializationInclusion(JsonInclude.Include.NON_NULL);
    }

    /**
     * <p>
     * Prevents to create a new instance.
     * </p>
     */
    private Helper() {
        // empty
    }

    /**
     * <p>
     * Checks state of object.
     * </p>
     * 
     * @param isInvalid
     *            the state of object.
     * @param message
     *            the error message.
     * @throws com.emc.gs.tools.srf.ServiceRequestToolConfigurationException
     *             if isInvalid is <code>true</code>
     */
    public static void checkState(boolean isInvalid, String message) {
        if (isInvalid) {
            throw new ServiceRequestToolConfigurationException(message);
        }
    }

    /**
     * <p>
     * Checks whether value is null/empty.
     * </p>
     * 
     * @param value
     *            the string value
     * @return the flag whether value is null/empty
     */
    public static boolean isStringNullOrEmpty(String value) {
        return value == null || value.trim().length() == 0;
    }

    /**
     * <p>
     * Validates the a variable. The value can not be <code>null</code>.
     * </p>
     * 
     * @param logger
     *            the logger object.
     * @param signature
     *            the signature of the method to be logged.
     * @param value
     *            the the variable to be validated.
     * @param name
     *            the name of the variable to be validated.
     * @throws IllegalArgumentException
     *             if the the variable is <code>null</code>.
     */
    public static void checkNull(Logger logger, String signature, Object value, String name) {
        if (value == null) {
            // Log exception
            throw logException(logger, signature, new IllegalArgumentException("'" + name
                    + "' should not be null."));
        }
    }

    /**
     * <p>
     * Validates the Sales Order Item Number value.
     * </p>
     * 
     * @param logger
     *            the logger object.
     * @param signature
     *            the signature of the method to be logged.
     * @param value
     *            the the variable to be validated.
     * @param name
     *            the name of the variable to be validated.
     * @throws IllegalArgumentException
     *             if the the variable is <code>null/empty</code>.
     * @since 2.10
     */
    public static void checkSalesOrderItemNumber(Logger logger, String signature, String value, String name) {
        checkStrNullEmpty(logger, signature, value, name);
        Matcher matcher = SALES_ORDER_ITEM_NUMBER_PATTERN.matcher(value);
        if (!matcher.matches()) {
            throw logException(logger, signature, new IllegalArgumentException("'" + name
                    + "' is not valid."));
        }
    }

    /**
     * <p> Validates the WBS Number.</p>
     *
     * @param logger the logger object.
     * @param signature the signature of the method to be logged.
     * @param value the the variable to be validated.
     * @param name the name of the variable to be validated.
     * @param isMS <code>true</code> if value corresponds to MS LOB; <code>false</code> otherwise.
     * @throws IllegalArgumentException if the the variable is <code>null/empty</code>.
     * @since 2.10
     */
    public static void checkWBSNumber(Logger logger, String signature, String value, String name, boolean isMS) {
        checkStrNullEmpty(logger, signature, value, name);
        Matcher matcher;
        if (isMS) {
            matcher = MS_WBS_NUMBER_PATTERN.matcher(value);
        } else {
            matcher = WBS_NUMBER_PATTERN.matcher(value);
        }
        if (!matcher.matches()) {
            throw logException(logger, signature, new IllegalArgumentException("'" + name + "' is not valid."));
        }
    }

    /**
     * <p> Validates the a variable. The value can not be <code>null/empty</code>. </p>
     *
     * @param logger the logger object.
     * @param signature the signature of the method to be logged.
     * @param value the the variable to be validated.
     * @param name the name of the variable to be validated.
     * @throws IllegalArgumentException if the the variable is <code>null/empty</code>.
     */
    public static void checkStrNullEmpty(Logger logger, String signature, String value, String name) {
        if (value == null || value.trim().length() == 0) {
            // Log exception
            throw logException(logger, signature,
                new IllegalArgumentException("'" + name + "' should not be null/empty."));
        }
    }

    /**
     * <p>
     * Checks if a string value is numeric.
     * </p>
     * 
     * @param logger
     *            the logger object.
     * @param signature
     *            the signature of the method to be logged.
     * @param value
     *            the the variable to be validated.
     * @param name
     *            the name of the variable to be validated.
     * @throws IllegalArgumentException
     *             if the the variable is <code>null/empty</code>.
     */
    public static void checkNumeric(Logger logger, String signature, String value, String name) {
        checkStrNullEmpty(logger, signature, value, name);
        try {
            Long.parseLong(value);
        } catch (Exception e) {
            throw logException(logger, signature,
                    new IllegalArgumentException("'" + name + "' should be numeric."));
        }
    }
    /**
     * <p>
     * Checks phone number.
     * </p>
     *
     * @param logger
     *            the logger object.
     * @param signature
     *            the signature of the method to be logged.
     * @param value
     *            the the variable to be validated.
     * @param name
     *            the name of the variable to be validated.
     * @throws IllegalArgumentException
     *             if the the variable is <code>null/empty</code>.
     */
    public static void checkPhone(Logger logger, String signature, Phone value, String name) {
        checkNull(logger, signature, value, name);
        checkStrNullEmpty(logger, signature, value.getCountryCode(), name + " Country Code");
        checkStrNullEmpty(logger, signature, value.getPhoneNumber(), name + " Number");

        String countryCode = value.getCountryCode();

        if (!countryCode.matches("\\+?[\\s\\d]+(, \\+?[\\s\\d]+)*")) {
            // Log exception
            throw logException(logger, signature, new IllegalArgumentException("'" + name
                    + " Country Code' is invalid."));
        }
    }

    /**
     * <p>
     * Validates the a variable. The value must be positive.
     * </p>
     * 
     * @param logger
     *            the logger object.
     * @param signature
     *            the signature of the method to be logged.
     * @param value
     *            the the variable to be validated.
     * @param name
     *            the name of the variable to be validated.
     * @throws IllegalArgumentException
     *             if the the variable is not positive
     */
    public static void checkPositive(Logger logger, String signature, long value, String name) {
        if (value <= 0) {
            // Log exception
            throw logException(logger, signature, new IllegalArgumentException("'" + name + "' must be positive."));
        }
    }

    /**
     * <p>
     * Validates the a variable. The value must be positive.
     * </p>
     * 
     * @param logger
     *            the logger object.
     * @param signature
     *            the signature of the method to be logged.
     * @param value
     *            the the variable to be validated.
     * @param name
     *            the name of the variable to be validated.
     * @throws IllegalArgumentException
     *             if the the variable is not positive
     */
    public static void checkPositive(Logger logger, String signature, Number value, String name) {
        checkNull(logger, signature, value, name);
        if (value.intValue() <= 0) {
            // Log exception
            throw logException(logger, signature, new IllegalArgumentException("'" + name
                    + "' must be strictly positive."));
        }
    }

    /**
     * <p>
     * Validates sites involved. The value must be either positive number or "More Than 4".
     * </p>
     * 
     * @param logger
     *            the logger object.
     * @param signature
     *            the signature of the method to be logged.
     * @param sitesInvovled
     *            the variable to be validated.
     * @param checkNull
     *            whether to check null value.
     * @param name
     *            the name of the variable to be validated.
     * @throws IllegalArgumentException
     *             if the value is invalid.
     * @since SRT Phase 3-5 - BRS Tabs Part 1 Assembly
     */
    public static void checkSitesInvolved(Logger logger, String signature, String sitesInvovled,
            boolean checkNull, String name) {
        if (checkNull) {
            checkStrNullEmpty(logger, signature, sitesInvovled, name);
        } else if (sitesInvovled == null || sitesInvovled.isEmpty()) {
            return;
        }

        if ("More Than 4".equals(sitesInvovled)) {
            return;
        }

        try {
            int sitesNum = Integer.parseInt(sitesInvovled);
            if (sitesNum <= 0) {
                throw logException(logger, signature,
                        new IllegalArgumentException("'" + name + "' must be greater than 0."));
            }
        } catch (NumberFormatException e) {
            throw logException(logger, signature,
                    new IllegalArgumentException("'" + name + "' should be numeric."));
        }
    }

    /**
     * <p>
     * Validates an integer. The value must be with given value range.
     * </p>
     * 
     * @param logger
     *            the logger object.
     * @param signature
     *            the signature of the method to be logged.
     * @param value
     *            the variable to be validated.
     * @param minValue
     *            minimum value (inclusive).
     * @param maxValue
     *            maximum value (inclusive).
     * @param checkNull
     *            whether to check null value.
     * @param name
     *            the name of the variable to be validated.
     * @throws IllegalArgumentException
     *             if the variable is not within range of [minValue, maxValue]
     */
    public static void checkIntegerInterval(Logger logger, String signature, Integer value,
            int minValue, int maxValue, boolean checkNull, String name) {
        if (checkNull) {
            checkNull(logger, signature, value, name);
        } else if (value == null) {
            return;
        }
        if (value < minValue) {
            // Log exception
            throw logException(logger, signature, new IllegalArgumentException("'" + name
                    + "' must be greater than or equal to " + minValue));
        }
        if (value > maxValue) {
            // Log exception
            throw logException(logger, signature, new IllegalArgumentException("'" + name
                    + "' must be less than or equal to " + maxValue));
        }
    }

    /**
     * <p>
     * Validates a decimal. The value must be with given value range.
     * </p>
     * 
     * @param logger
     *            the logger object.
     * @param signature
     *            the signature of the method to be logged.
     * @param value
     *            the variable to be validated.
     * @param minValue
     *            minimum value (inclusive).
     * @param maxValue
     *            maximum value (inclusive).
     * @param nrOfDecimalPlaces
     *            number of decimal places.
     * @param checkNull
     *            whether to check null value.
     * @param name
     *            the name of the variable to be validated.
     * @throws IllegalArgumentException
     *             if the variable is not within range of [minValue, maxValue]
     */
    public static void checkDecimalInterval(Logger logger, String signature, BigDecimal value,
            BigDecimal minValue, BigDecimal maxValue, Integer nrOfDecimalPlaces, boolean checkNull, String name) {
        if (checkNull) {
            checkNull(logger, signature, value, name);
        } else if (value == null) {
            return;
        }
        if (nrOfDecimalPlaces != null) {
            int scale = value.scale();
            if (scale > nrOfDecimalPlaces) {
                String message;
                if (nrOfDecimalPlaces == 1) {
                    message = "must be a decimal number with maximum one decimal place.";
                } else {
                    message = "must be a decimal number with maximum " + nrOfDecimalPlaces + " decimal places.";
                }
                throw logException(logger, signature, new IllegalArgumentException("'" + name + "' " + message
                        + "'"));
            }
        }
        if (value.compareTo(minValue) < 0) {
            // Log exception
            throw logException(logger, signature, new IllegalArgumentException("'" + name
                    + "' must be greater than or equal to " + minValue));
        }
        if (value.compareTo(maxValue) > 0) {
            // Log exception
            throw logException(logger, signature, new IllegalArgumentException("'" + name
                    + "' must be less than or equal to " + maxValue));
        }
    }

    /**
     * <p>
     * Validates the variable. The value must be positive or zero.
     * </p>
     * 
     * @param logger
     *            the logger object.
     * @param signature
     *            the signature of the method to be logged.
     * @param value
     *            the variable to be validated.
     * @param checkNull
     *            whether to check null value.
     * @param name
     *            the name of the variable to be validated.
     * @throws IllegalArgumentException
     *             if the variable is not positive or zero
     */
    public static void checkPositiveOrZero(Logger logger, String signature, Integer value, boolean checkNull,
            String name) {
        if (checkNull) {
            checkNull(logger, signature, value, name);
        } else if (value == null) {
            return;
        }
        if (value < 0) {
            // Log exception
            throw logException(logger, signature, new IllegalArgumentException("'" + name
                    + "' must be greater or equal with 0."));
        }
    }

    /**
     * <p>
     * Validates the variable. The value must be strict positive.
     * </p>
     * 
     * @param logger
     *            the logger object.
     * @param signature
     *            the signature of the method to be logged.
     * @param value
     *            the variable to be validated.
     * @param checkNull
     *            whether to check null value.
     * @param name
     *            the name of the variable to be validated.
     * @throws IllegalArgumentException
     *             if the variable is not strict positive
     */
    public static void checkStrictPositive(Logger logger, String signature, Integer value, boolean checkNull,
            String name) {
        if (checkNull) {
            checkNull(logger, signature, value, name);
        } else if (value == null) {
            return;
        }
        if (value <= 0) {
            // Log exception
            throw logException(logger, signature, new IllegalArgumentException("'" + name
                    + "' must be greater than 0."));
        }
    }

    /**
     * <p>
     * Validates the variable. The value must be positive or zero.
     * </p>
     * 
     * @param logger
     *            the logger object.
     * @param signature
     *            the signature of the method to be logged.
     * @param value
     *            the variable to be validated.
     * @param checkNull
     *            whether to check null value.
     * @param name
     *            the name of the variable to be validated.
     * @throws IllegalArgumentException
     *             if the variable is not positive or zero
     */
    public static void checkPositiveOrZero(Logger logger, String signature, Double value, boolean checkNull,
            String name) {
        if (checkNull) {
            checkNull(logger, signature, value, name);
        } else if (value == null) {
            return;
        }
        if (value < 0) {
            // Log exception
            throw logException(logger, signature, new IllegalArgumentException("'" + name
                    + "' must be greater or equal with 0."));
        }
    }

    /**
     * <p>
     * Validates the variable. The value must be strict positive.
     * </p>
     * 
     * @param logger
     *            the logger object.
     * @param signature
     *            the signature of the method to be logged.
     * @param value
     *            the variable to be validated.
     * @param checkNull
     *            whether to check null value.
     * @param name
     *            the name of the variable to be validated.
     * @throws IllegalArgumentException
     *             if the variable is not strict positive
     */
    public static void checkStrictPositive(Logger logger, String signature, Double value, boolean checkNull,
            String name) {
        if (checkNull) {
            checkNull(logger, signature, value, name);
        } else if (value == null) {
            return;
        }
        if (value <= 0) {
            // Log exception
            throw logException(logger, signature, new IllegalArgumentException("'" + name
                    + "' must be greater than 0."));
        }
    }

    /**
     * <p>
     * Validates the variable. The value must be positive or zero.
     * </p>
     * 
     * @param logger
     *            the logger object.
     * @param signature
     *            the signature of the method to be logged.
     * @param value
     *            the variable to be validated.
     * @param nrOfDecimalPlaces
     *            number of decimal places.
     * @param checkNull
     *            whether to check null value.
     * @param name
     *            the name of the variable to be validated.
     * @throws IllegalArgumentException
     *             if the variable is not positive or zero
     */
    public static void checkPositiveOrZero(Logger logger, String signature, BigDecimal value,
            Integer nrOfDecimalPlaces, boolean checkNull, String name) {
        if (checkNull) {
            checkNull(logger, signature, value, name);
        } else if (value == null) {
            return;
        }
        if (value.compareTo(BigDecimal.ZERO) < 0) {
            // Log exception
            throw logException(logger, signature, new IllegalArgumentException("'" + name
                    + "' must be greater or equal with 0."));
        }
        if (nrOfDecimalPlaces != null) {
            int scale = value.scale();
            if (scale > nrOfDecimalPlaces) {
                String message;
                if (nrOfDecimalPlaces == 1) {
                    message = "must be a decimal number with maximum one decimal place.";
                } else {
                    message = "must be a decimal number with maximum " + nrOfDecimalPlaces + " decimal places.";
                }
                throw logException(logger, signature, new IllegalArgumentException("'" + name + "' " + message
                        + "'"));
            }
        }
    }

    /**
     * <p>
     * Validates the variable. The value must be strict positive.
     * </p>
     * 
     * @param logger
     *            the logger object.
     * @param signature
     *            the signature of the method to be logged.
     * @param value
     *            the variable to be validated.
     * @param nrOfDecimalPlaces
     *            number of decimal places.
     * @param checkNull
     *            whether to check null value.
     * @param name
     *            the name of the variable to be validated.
     * @throws IllegalArgumentException
     *             if the variable is not strict positive
     */
    public static void checkStrictPositive(Logger logger, String signature, BigDecimal value,
            Integer nrOfDecimalPlaces, boolean checkNull, String name) {
        if (checkNull) {
            checkNull(logger, signature, value, name);
        } else if (value == null) {
            return;
        }
        if (value.compareTo(BigDecimal.ZERO) <= 0) {
            // Log exception
            throw logException(logger, signature, new IllegalArgumentException("'" + name
                    + "' must be greater than 0."));
        }
        if (nrOfDecimalPlaces != null) {
            int scale = value.scale();
            if (scale > nrOfDecimalPlaces) {
                String message;
                if (nrOfDecimalPlaces == 1) {
                    message = "must be a decimal number with maximum one decimal place.";
                } else {
                    message = "must be a decimal number with maximum " + nrOfDecimalPlaces + " decimal places.";
                }
                throw logException(logger, signature, new IllegalArgumentException("'" + name + "' " + message
                        + "'"));
            }
        }
    }

    /**
     * <p>
     * Validates the a variable. The value must be positive or zero.
     * </p>
     * 
     * @param logger
     *            the logger object.
     * @param signature
     *            the signature of the method to be logged.
     * @param value
     *            the the variable to be validated.
     * @param name
     *            the name of the variable to be validated.
     * @throws IllegalArgumentException
     *             if the the variable is not positive or zero
     */
    public static void checkDecimal(Logger logger, String signature, String value, Integer nrOfDecimalPlaces,
            String name) {
        checkNull(logger, signature, value, name);
        Pattern p = Pattern.compile("^\\d+(\\.(\\d){1," + nrOfDecimalPlaces + "})?$");
        Matcher m = p.matcher(value);
        if (!m.matches()) {
            // Log exception
            String message;
            if (nrOfDecimalPlaces == 1) {
                message = "must be a decimal number with maximum one decimal place.";
            } else {
                message = "must be a decimal number with maximum " + nrOfDecimalPlaces + " decimal places.";
            }
            throw logException(logger, signature, new IllegalArgumentException("'" + name + "' " + message + "'"));
        }
    }

    /**
     * Check string length.
     * 
     * @param logger
     *            the logger object.
     * @param signature
     *            the signature of the method to be logged.
     * @param value
     *            the variable to be validated.
     * @param minLength
     *            minimum length (inclusive).
     * @param maxLength
     *            maximum length (inclusive).
     * @param checkNull
     *            whether to check null value.
     * @param name
     *            the name of the variable to be validated.
     * @throws IllegalArgumentException
     *             if the string is not within range of [minLength, maxLength]
     */
    public static void checkStringLength(Logger logger, String signature, String value, int minLength, int maxLength,
            boolean checkNull, String name) {
        if (checkNull) {
            checkNull(logger, signature, value, name);
        } else if (value == null) {
            return;
        }

        int length = value.length();
        if (length < minLength) {
            throw logException(logger, signature, new IllegalArgumentException("'" + name
                    + "' must be with length greater than or equal to " + minLength));
        }
        if (length > maxLength) {
            throw logException(logger, signature, new IllegalArgumentException("'" + name
                    + "' must be with length less than or equal to " + maxLength));
        }
    }

    /**
     * <p>
     * Validates the a variable. The array can not be empty, or any element in ids array must be positive.
     * </p>
     * 
     * @param logger
     *            the logger object.
     * @param signature
     *            the signature of the method to be logged.
     * @param value
     *            the the variable to be validated.
     * @param name
     *            the name of the variable to be validated.
     * @throws IllegalArgumentException
     *             if the array is empty, or any element in ids array is not positive
     */
    static void checkArrayPositive(Logger logger, String signature, long[] value, String name) {
        if (value == null || value.length == 0) {
            // Log exception
            throw logException(logger, signature, new IllegalArgumentException("'" + name
                    + "' can not be null/empty."));
        }
        for (long id : value) {
            checkPositive(logger, signature, id, "element in " + name);
        }
    }

    /**
     * <p>
     * Logs for entrance into methods at <code>DEBUG</code> level.
     * </p>
     * 
     * @param logger
     *            the logger object.
     * @param signature
     *            the signature of the method to be logged.
     * @param paramNames
     *            the names of parameters to log .
     * @param params
     *            the values of parameters to log.
     */
    public static void logEntrance(Logger logger, String signature, String[] paramNames, Object[] params) {
        if (logger.isDebugEnabled()) {
            // Do logging
            logger.debug(String.format(MESSAGE_ENTRANCE, signature));
            if (paramNames != null) {
                // Log parameters
                logParameters(logger, paramNames, params);
            }
        }
    }

    /**
     * <p>
     * Logs for exit from methods at <code>DEBUG</code> level.
     * </p>
     * 
     * @param logger
     *            the logger object.
     * @param signature
     *            the signature of the method to be logged.
     * @param value
     *            the return value to log.
     * @param <T>
     *            the type of the return value.
     * @return the return value
     */
    public static <T> T logExit(Logger logger, String signature, T[] value) {
        if (logger.isDebugEnabled()) {
            // Do logging
            logger.debug(String.format(MESSAGE_EXIT, signature));

            if (value != null) {
                // Log return value
                logger.debug("The return value: " + toString(value[0]));
                return value[0];
            }
        }
        return null;
    }

    /**
     * <p>
     * Logs the given exception and message at <code>ERROR</code> level.
     * </p>
     * 
     * @param <T>
     *            the exception type.
     * @param logger
     *            the logger object).
     * @param signature
     *            the signature of the method to log.
     * @param e
     *            the exception to log.
     * @return the passed in exception.
     */
    public static <T extends Throwable> T logException(Logger logger, String signature, T e) {
        if (logger != null) {
            String errorMessage = String.format(MESSAGE_ERROR, signature);

            // Do logging
            logger.error(errorMessage, e);
        }
        return e;
    }

    /**
     * <p>
     * Logs the parameters at <code>DEBUG</code> level.
     * </p>
     * 
     * @param logger
     *            the logger object (not <code>null</code>).
     * @param paramNames
     *            the names of parameters to log (not <code>null</code>).
     * @param params
     *            the values of parameters to log (not <code>null</code>).
     */
    private static void logParameters(Logger logger, String[] paramNames, Object[] params) {
        StringBuilder sb = new StringBuilder("The parameters: {");

        for (int i = 0; i < params.length; i++) {

            if (i > 0) {
                // Append a comma
                sb.append(", ");
            }

            sb.append(paramNames[i]).append(":").append(toString(params[i]));
        }
        sb.append("}.");

        // Do logging
        logger.debug(sb.toString());
    }

    /**
     * Transfer the object to string.
     * 
     * @param obj
     *            the object
     * @return the string valid
     */
    public static String toString(Object obj) {
        if (obj == null) {
            return null;
        }

        // Don't serialize through jackson, it will call getOutputStream() on debug level logging.
        // This will mess with the JSON serialization of controller return values.
        if(obj instanceof HttpServletRequest
                || obj instanceof HttpServletResponse) {
            return obj.toString();
        }

        try {
            return OBJECT_MAPPER.writeValueAsString(obj);
        } catch (JsonProcessingException e) {
            return obj.toString();
        }
    }

    /**
     * Fix the string for query LIKE.
     * 
     * @param str
     *            the input string
     * @return the fixed string
     * @since 1.1
     */
    static String fixStringForLike(String str) {
        return ("%" + str + "%").toLowerCase();
    }

    /**
     * Trims a String. If null, return empty.
     * 
     * @param str
     *            String to trim.
     * @return empty string for null, or the trimmed string
     * @since SRT Phase 3-5 - BRS Tabs Part 2 Assembly
     */
    public static String trimToEmpty(String str) {
        if (str == null) {
            return "";
        } else {
            return str.trim();
        }
    }

    /**
     * Gets String description of Lookup entity. If null, return empty.
     * 
     * @param entity
     *            Lookup entity.
     * @return empty string for null, or the trimmed string
     * @since SRT Phase 3-5 - BRS Tabs Part 2 Assembly
     */
    public static String lookupEntity2String(LookupEntity entity) {
        if (entity == null) {
            return "";
        } else {
            return trimToEmpty(entity.getName());
        }
    }

    /**
     * Gets the code of lookup entity.
     * 
     * @param entity
     *            The lookup entity.
     * @return code of lookup entity.
     */
    public static String getLookupCode(LookupCodeEntity entity) {
        return entity == null ? "" : trimToEmpty(entity.getCode());
    }

    /**
     * Transfer Enum to string.
     * 
     * @param enume
     *            the Enum
     * @return the string
     * @since SRT Phase 3-5 - BRS Tabs Part 2 Assembly
     */
    public static String enum2String(Enum<?> enume) {
        return enume == null ? "" : enume.toString();
    }

    /**
     * Transfer decimal to String.
     *
     * @param value
     *            the decimal
     * @param minFraction
     *            the minimum fraction digits
     * @return the string
     */
    public static String decimal2String(BigDecimal value, Integer minFraction) {
        if (value == null) {
            return "";
        }
        NumberFormat nf = NumberFormat.getNumberInstance();
        nf.setGroupingUsed(false);
        nf.setMaximumFractionDigits(9);
        if (minFraction != null) {
            nf.setMinimumFractionDigits(minFraction);
        }
        return nf.format(value.doubleValue());
    }

    /**
     * Transfer decimal to grouped String.
     *
     * @param value
     *            the decimal
     * @param fraction
     *            the fraction digits
     * @param group
     *            whether group the string
     * @return the string
     */
    public static String decimal2GroupedString(BigDecimal value, int fraction, boolean group) {
        if (value == null) {
            return "";
        }
        NumberFormat nf = NumberFormat.getNumberInstance();
        nf.setGroupingUsed(group);
        nf.setMaximumFractionDigits(fraction);
        nf.setMinimumFractionDigits(fraction);
        return nf.format(value.doubleValue());
    }

    /**
     * Transfer int to String without padding.
     *
     * @param num
     *            the integer
     * @return the string
     * @since SRT Phase 3-2 - W4N and Unfunded Project Tabs Assembly
     */
    public static String int2StringNoPad(Integer num) {
        if (num == null) {
            return "";
        }
        return String.valueOf(num);
    }

    /**
     * Test whether Boolean value is true.
     * 
     * @param flag
     *            the Boolean value
     * @return true if given Boolean value is true
     * @since SRT Phase 3-5 - BRS Tabs Part 2 Assembly
     */
    public static boolean isBooleanTrue(Boolean flag) {
        return flag != null && flag;
    }

    /**
     * Test whether Boolean value is false.
     * 
     * @param flag
     *            the Boolean value
     * @return true if given Boolean value is false
     * @since SRT Phase 3-5 - BRS Tabs Part 3 Assembly
     */
    public static boolean isBooleanFalse(Boolean flag) {
        return flag != null && !flag;
    }

    /**
     * Checks if the provided userIdentifier is the identifier of the current user.
     *
     * @param logger
     *              the logger
     * @param signature
     *              the signature
     * @param entityType
     *              the entity type
     * @param userIdentifier
     *              the user identifier
     * @throws AuthorizationException
     *              if the provided userIdentifier isn't the identifier of the current user
     * @since 1.8
     */
    public static void checkPrivileges(Logger logger, String signature, String entityType, String userIdentifier) {
        // check user identifier
        User currentUser = ServiceContext.getCurrentUser();
        if (currentUser != null && userIdentifier != null && !currentUser.getUserIdentifier().equals(userIdentifier)) {
            throw Helper.logException(logger, signature, new AuthorizationException("Insufficient privileges to get this " + entityType + "."));
        }
    }

    /**
     * Set entity id to zero.
     *
     * @param idEntity
     *            Id entity.
     * @since SRT Release Assembly - BC Tab
     */
    private static void zeroId(IdentifiableEntity idEntity) {
        if (idEntity != null) {
            idEntity.setId(0);
        }
    }

    /**
     * Zero customer id.
     *
     * @param customer the customer to zero id.
     */
    public static void zeroCustomerId(Customer customer) {
        zeroId(customer);

        // zero the id of all the "cascade-all" fields.

        if (customer.getCustomerWorkSites() != null) {
            for (CustomerWorkSite cws : customer.getCustomerWorkSites()) {
                zeroId(cws);
            }
        }
    }
    
    /**
     * Zero profile id.
     *
     * @param profile the profile to zero id.
     * @since 2.9
     */
    public static void zeroProfileId(Profile profile) {
        zeroId(profile);
        zeroId(profile.getDivision());
        zeroId(profile.getSalesDistrict());
    }
    
    /**
     * Zero StartRequestData id.
     *
     * @param startRequestData the startRequestData to zero id.
     */
    private static void zeroStartRequestDataId(StartRequestData startRequestData) {
        zeroId(startRequestData);

        // zero the id of all the "cascade-all" fields.

        zeroId(startRequestData.getCoreOptions());
        zeroId(startRequestData.getDpadOptions());
        zeroId(startRequestData.getAsdOptions());
        zeroId(startRequestData.getAffinityOptions());
        zeroId(startRequestData.getConsultingOptions());
        zeroId(startRequestData.getOtherRequestOptions());
        zeroId(startRequestData.getRequestContractData());

        if (startRequestData.getAttachments() != null) {
            for (Attachment att : startRequestData.getAttachments()) {
                zeroId(att);
            }
        }
    }

    /**
     * Zero MainframeRequestData id.
     *
     * @param mainframeRequestData the mainframeRequestData to zero id.
     */
    private static void zeroMainframeRequestDataId(MainframeRequestData mainframeRequestData) {
        zeroId(mainframeRequestData);

        // zero the id of all the "cascade-all" fields.

        zeroId(mainframeRequestData.getServicesScope());

        if (mainframeRequestData.getBooleanServiceData() != null) {
            for (ServiceData sd : mainframeRequestData.getBooleanServiceData()) {
                zeroId(sd);
            }
        }

        if (mainframeRequestData.getStringServiceData() != null) {
            for (ServiceData sd : mainframeRequestData.getStringServiceData()) {
                zeroId(sd);
            }
        }
    }

    /**
     * Zero BcRequestData id.
     *
     * @param bcRequestData the bcRequestData to zero id.
     */
    private static void zeroBcRequestDataId(BcRequestData bcRequestData) {
        zeroId(bcRequestData);

        // zero the id of all the "cascade-all" fields.

        zeroId(bcRequestData.getServicesScope());
        zeroId(bcRequestData.getMirrorViewInformation());
        zeroId(bcRequestData.getReplicationManagerInformation());
        zeroId(bcRequestData.getSnapViewInformation());
        zeroId(bcRequestData.getSrdfInformation());
        zeroId(bcRequestData.getTimeFinderInformation());

        if (bcRequestData.getNasIpReplicationInformation() != null) {
            for (NasIpReplicationInformation info : bcRequestData.getNasIpReplicationInformation()) {
                zeroId(info);
            }
        }
    }

    /**
     * Zero InfrastructureRequestData id.
     *
     * @param infrastructureRequestData the infrastructureRequestData to zero id.
     */
    private static void zeroInfrastructureRequestDataId(InfrastructureRequestData infrastructureRequestData) {
        zeroId(infrastructureRequestData);

        // zero the id of all the "cascade-all" fields.

        zeroId(infrastructureRequestData.getDataMigrationInformation());
        zeroId(infrastructureRequestData.getOpenReplicator());
        EnvironmentDetailsInformation environmentDetailsInformation =
            infrastructureRequestData.getEnvironmentDetailsInformation();
        zeroId(environmentDetailsInformation);
        if (environmentDetailsInformation != null) {
            List<EnvironmentDetailsHostInfo> hostInformation = environmentDetailsInformation.getHostInformation();
            if (hostInformation != null) {
                for (EnvironmentDetailsHostInfo info : hostInformation) {
                    zeroId(info);
                }
            }
        }
        zeroId(infrastructureRequestData.getSymmetrixMF());
        zeroId(infrastructureRequestData.getSymmetrixOS());
        zeroId(infrastructureRequestData.getVnxClariionInformation());
        zeroId(infrastructureRequestData.getVplex());
    }

    /**
     * Zero UnifiedRequestData id.
     *
     * @param unifiedRequestData the unifiedRequestData to zero id.
     */
    private static void zeroUnifiedRequestDataId(UnifiedRequestData unifiedRequestData) {
        zeroId(unifiedRequestData);

        // zero the id of all the "cascade-all" fields.

        zeroId(unifiedRequestData.getServicesScope());

        if (unifiedRequestData.getCelerraDetailInformation() != null) {
            for (CelerraDetailInformation info : unifiedRequestData.getCelerraDetailInformation()) {
                zeroId(info);
            }
        }

        if (unifiedRequestData.getNasMigrationInformation() != null) {
            for (NasMigrationInformation info : unifiedRequestData.getNasMigrationInformation()) {
                zeroId(info);
            }
        }
    }

    /**
     * Zero MSSRequestData id.
     *
     * @param mssRequestData the mssRequestData to zero id.
     */
    private static void zeroMSSRequestDataId(MSSRequestData mssRequestData) {
        zeroId(mssRequestData);

        // zero the id of all the "cascade-all" fields.

        if (mssRequestData.getMssArray() != null) {
            for (MSSArray array : mssRequestData.getMssArray()) {
                zeroId(array);
                zeroId(array.getAvamarNodes());
                zeroId(array.getCenteraNodes());
                zeroId(array.getClariionAx4Drives());
                zeroId(array.getDataDomain());
                zeroId(array.getFcAtaDrives());
                zeroId(array.getFlashDrives());
                zeroId(array.getVnxSasDrives());
                zeroId(array.getAtmos());
                zeroId(array.getGreenplum());
            }
        }
    }

    /**
     * Zero CTARequestData id.
     *
     * @param ctaRequestData the ctaRequestData to zero id.
     */
    private static void zeroCTARequestDataId(CTARequestData ctaRequestData) {
        zeroId(ctaRequestData);

        // zero the id of all the "cascade-all" fields.

        zeroId(ctaRequestData.getServicesScope());
        zeroId(ctaRequestData.getConversion());
        zeroId(ctaRequestData.getRaininfinity());
        zeroId(ctaRequestData.getImplementation());

        if (ctaRequestData.getImplementation() != null && ctaRequestData.getImplementation().getArray() != null) {
            for (CTAImplementationArray array : ctaRequestData.getImplementation().getArray()) {
                zeroId(array);
                zeroId(array.getNasDestination());
            }
        }
    }

    /**
     * Zero ResidencyRequestData id.
     *
     * @param residencyRequestData the residencyRequestData to zero id.
     */
    private static void zeroResidencyRequestDataId(ResidencyRequestData residencyRequestData) {
        zeroId(residencyRequestData);

        // zero the id of all the "cascade-all" fields.

        ResidencyRoleSkillLevels rsls = residencyRequestData.getRoleSkillLevels();
        zeroId(rsls);

        if (rsls != null) {
            if (rsls.getBackup() != null) {
                for (RoleSkillLevel level : rsls.getBackup().values()) {
                    zeroId(level);
                }
            }
            if (rsls.getProjectManagement() != null) {
                for (RoleSkillLevel level : rsls.getProjectManagement().values()) {
                    zeroId(level);
                }
            }
            if (rsls.getStorage() != null) {
                for (RoleSkillLevel level : rsls.getStorage().values()) {
                    zeroId(level);
                }
            }
            if (rsls.getSupport() != null) {
                for (RoleSkillLevel level : rsls.getSupport().values()) {
                    zeroId(level);
                }
            }
            if (rsls.getSystemAdmin() != null) {
                for (RoleSkillLevel level : rsls.getSystemAdmin().values()) {
                    zeroId(level);
                }
            }
            if (rsls.getVmware() != null) {
                for (RoleSkillLevel level : rsls.getVmware().values()) {
                    zeroId(level);
                }
            }
            if (rsls.getArchive() != null) {
                for (RoleSkillLevel level : rsls.getArchive()) {
                    zeroId(level);
                }
            }
            if (rsls.getCloud() != null) {
                for (RoleSkillLevel level : rsls.getCloud()) {
                    zeroId(level);
                }
            }
            if (rsls.getDataWareHouse() != null) {
                for (RoleSkillLevel level : rsls.getDataWareHouse()) {
                    zeroId(level);
                }
            }
            if (rsls.getIsilon() != null) {
                for (RoleSkillLevel level : rsls.getIsilon()) {
                    zeroId(level);
                }
            }
            if (rsls.getStorageManagement() != null) {
                for (RoleSkillLevel level : rsls.getStorageManagement()) {
                    zeroId(level);
                }
            }
            if (rsls.getVblock() != null) {
                for (RoleSkillLevel level : rsls.getVblock()) {
                    zeroId(level);
                }
            }
            if (rsls.getVirtualizationXtremeIO() != null) {
                for (RoleSkillLevel level : rsls.getVirtualizationXtremeIO()) {
                    zeroId(level);
                }
            }
        }
    }

    /**
     * Zero SourceOneRequestData id.
     *
     * @param sourceOneRequestData the sourceOneRequestData to zero id.
     */
    private static void zeroSourceOneRequestDataId(SourceOneRequestData sourceOneRequestData) {
        zeroId(sourceOneRequestData);

        // zero the id of all the "cascade-all" fields.

        zeroId(sourceOneRequestData.getServicesScope());
        zeroId(sourceOneRequestData.getDesignImpl());
        zeroId(sourceOneRequestData.getMigration());
        zeroId(sourceOneRequestData.getUpgrade());
        zeroId(sourceOneRequestData.getHealthCheck());

        if (sourceOneRequestData.getDesignImpl() != null) {
            zeroId(sourceOneRequestData.getDesignImpl().getFeatures());
            zeroId(sourceOneRequestData.getDesignImpl().getDrOptions());
        }
    }

    /**
     * Zero ASDRequestData id.
     *
     * @param asdRequestData the asdRequestData to zero id.
     */
    private static void zeroASDRequestDataId(ASDRequestData asdRequestData) {
        zeroId(asdRequestData);

        // zero the id of all the "cascade-all" fields.

        zeroId(asdRequestData.getServicesScope());
        zeroId(asdRequestData.getAppSync());
        zeroId(asdRequestData.getUim());
    }

    /**
     * Zero HealthCheckRequestData id.
     *
     * @param healthCheckRequestData the healthCheckRequestData to zero id.
     */
    private static void zeroHealthCheckRequestDataId(HealthCheckRequestData healthCheckRequestData) {
        zeroId(healthCheckRequestData);

        // zero the id of all the "cascade-all" fields.

        zeroId(healthCheckRequestData.getServicesScope());
        zeroId(healthCheckRequestData.getAvamar());
        zeroId(healthCheckRequestData.getDataDomain());
        zeroId(healthCheckRequestData.getDlm());
        zeroId(healthCheckRequestData.getDpa());
        zeroId(healthCheckRequestData.getGreenPlum());
        zeroId(healthCheckRequestData.getIonix());
        zeroId(healthCheckRequestData.getNetWorker());
        zeroId(healthCheckRequestData.getSanSecurity());
        zeroId(healthCheckRequestData.getSap());
        zeroId(healthCheckRequestData.getSourceOne());
        zeroId(healthCheckRequestData.getSymmetrixVmax());
        zeroId(healthCheckRequestData.getSymmetrixVmaxStorageReplication());
        zeroId(healthCheckRequestData.getUnified());
        zeroId(healthCheckRequestData.getVblock());
        zeroId(healthCheckRequestData.getVmwareVirtualInfrastructure());
        zeroId(healthCheckRequestData.getVplex());
    }

    /**
     * Zero IsilonRequestData id.
     *
     * @param isilonRequestData the isilonRequestData to zero id.
     */
    private static void zeroIsilonRequestDataId(IsilonRequestData isilonRequestData) {
        zeroId(isilonRequestData);

        // zero the id of all the "cascade-all" fields.

        zeroId(isilonRequestData.getServicesScope());
        zeroId(isilonRequestData.getClusterRelocation());
        zeroId(isilonRequestData.getDesignAndImpl());
        zeroId(isilonRequestData.getHardwareUpgrade());
        zeroId(isilonRequestData.getMigration());
    }

    /**
     * Zero ViprRequestData id.
     *
     * @param viprRequestData the viprRequestData to zero id.
     */
    private static void zeroViprRequestDataId(ViprRequestData viprRequestData) {
        zeroId(viprRequestData);

        // zero the id of all the "cascade-all" fields.

        zeroId(viprRequestData.getImpl());
        zeroId(viprRequestData.getViprDataServiceOnCommodityDesignImpl());
        zeroId(viprRequestData.getEcsApplianceDesignImpl());
        zeroId(viprRequestData.getViprDataMigrationWithPPME());

        if (viprRequestData.getViprDataMigrationWithPPME() != null) {
            zeroId(viprRequestData.getViprDataMigrationWithPPME().getPpmeImplementationMigration());
            zeroId(viprRequestData.getViprDataMigrationWithPPME().getPpmePlanningDesign());
        }
    }

    /**
     * Zero VblockRequestData id.
     *
     * @param vblockRequestData the vblockRequestData to zero id.
     */
    private static void zeroVblockRequestDataId(VblockRequestData vblockRequestData) {
        zeroId(vblockRequestData);

        // zero the id of all the "cascade-all" fields.

        zeroId(vblockRequestData.getProject());
        zeroId(vblockRequestData.getServices());
        zeroId(vblockRequestData.getDesignImpl());
        zeroId(vblockRequestData.getInfrastructure());
        zeroId(vblockRequestData.getTechAssessment());
    }

    /**
     * Zero AtmosCenteraRequestData id.
     *
     * @param atmosCenteraRequestData the atmosCenteraRequestData to zero id.
     */
    private static void zeroAtmosCenteraRequestDataId(AtmosCenteraRequestData atmosCenteraRequestData) {
        zeroId(atmosCenteraRequestData);

        // zero the id of all the "cascade-all" fields.

        zeroId(atmosCenteraRequestData.getServicesScope());
        zeroId(atmosCenteraRequestData.getAtmosDesignImpl());
        zeroId(atmosCenteraRequestData.getCenteraFileErasure());
        zeroId(atmosCenteraRequestData.getCenteraIntraClusterMigration());
        zeroId(atmosCenteraRequestData.getCenteraToAtmosMigration());
        zeroId(atmosCenteraRequestData.getCenteraUniversalAccess());
        zeroId(atmosCenteraRequestData.getExpansionNodeOnly());

        CenteraDesignImpl centeraDesignImpl = atmosCenteraRequestData.getCenteraDesignImpl();
        zeroId(centeraDesignImpl);

        if (centeraDesignImpl != null) {
            List<NewCenteraCluster> newClusters = centeraDesignImpl.getNewClusters();
            if (newClusters != null) {
                for (NewCenteraCluster newCluster : newClusters) {
                    zeroId(newCluster);
                }
            }

            List<ExistingCenteraCluster> existingClusters = centeraDesignImpl.getExistingClusters();
            if (existingClusters != null) {
                for (ExistingCenteraCluster existingCluster : existingClusters) {
                    zeroId(existingCluster);
                }
            }
        }
    }

    /**
     * Zero VMwareRequestData id.
     *
     * @param vmwareRequestData the vmwareRequestData to zero id.
     */
    private static void zeroVMwareRequestDataId(VMwareRequestData vmwareRequestData) {
        zeroId(vmwareRequestData);

        // zero the id of all the "cascade-all" fields.

        zeroId(vmwareRequestData.getServicesScope());
        zeroId(vmwareRequestData.getAssessment());
        zeroId(vmwareRequestData.getBackupRecovery());
        zeroId(vmwareRequestData.getConverter());
        zeroId(vmwareRequestData.getHealthChecks());
        zeroId(vmwareRequestData.getReplication());
        zeroId(vmwareRequestData.getSvMotion());
        zeroId(vmwareRequestData.getTcoAssessment());
        zeroId(vmwareRequestData.getVsphere());
        zeroId(vmwareRequestData.getVirtualInfrastructure());

        VMwareVblock vblock = vmwareRequestData.getVceVblock();
        zeroId(vblock);
        if (vblock != null) {
            zeroId(vblock.getVblockDesignImpl());
            zeroId(vblock.getVblockInfraImpl());
            zeroId(vblock.getVblockInfraTechAssessment());
        }

        VMwareView view = vmwareRequestData.getView();
        zeroId(view);
        if (view != null) {
            zeroId(view.getViewDesign());
            zeroId(view.getViewImpl());
        }
    }

    /**
     * Zero DPADRequestData id.
     *
     * @param dpadRequestData the dpadRequestData to zero id.
     */
    private static void zeroDPADRequestDataId(DPADRequestData dpadRequestData) {
        zeroId(dpadRequestData);

        // zero the id of all the "cascade-all" fields.

        zeroId(dpadRequestData.getServicesScope());

        Avamar avamar = dpadRequestData.getAvamar();
        zeroId(avamar);
        if (avamar != null) {
            zeroId(avamar.getDesign());
            if (avamar.getDesign() != null) {
                zeroId(avamar.getDesign().getOptions());
                zeroId(avamar.getDesign().getPlugins());
            }

            zeroId(avamar.getImplementation());
            if (avamar.getImplementation() != null) {
                zeroId(avamar.getImplementation().getNdmp());
                zeroId(avamar.getImplementation().getOptions());
                zeroId(avamar.getImplementation().getPlugins());
            }

            zeroId(avamar.getTapeOutDesign());
            zeroId(avamar.getTapeOutImplementation());
            zeroId(avamar.getOperationalAssurance());
            zeroId(avamar.getHealthCheck());
            zeroId(avamar.getMigration());
            zeroId(avamar.getIntegration());
        }

        EDL edl = dpadRequestData.getEdl();
        zeroId(edl);
        if (edl != null) {
            zeroId(edl.getDesignImpl());
        }

        RecoverPoint recoverPoint = dpadRequestData.getRecoverPoint();
        zeroId(recoverPoint);
        if (recoverPoint != null) {
            zeroId(recoverPoint.getInstallationAndImplementation());
            zeroId(recoverPoint.getRpaHardwareUpgrade());
            zeroId(recoverPoint.getIntelligentFabricSplitterMigration());
        }

        DataDomain dataDomain = dpadRequestData.getDataDomain();
        zeroId(dataDomain);
        if (dataDomain != null) {
            zeroId(dataDomain.getBoost());
            zeroId(dataDomain.getDataStaging());
            DataDomainDesignImplContent designImplContent = dataDomain.getDesignImplContent();
            zeroId(designImplContent);
            if (designImplContent != null) {
                zeroId(designImplContent.getBoostBackupServer());
            }

            DataDomainDesign design = dataDomain.getDesign();
            zeroId(design);
            if (design != null) {
                zeroId(design.getBoostBackupServer());
                Map<String,DataDomainDesignApplianceModel> applianceModels = design.getApplianceModels();
                if (applianceModels != null) {
                    for (DataDomainDesignApplianceModel item : applianceModels.values()) {
                        zeroId(item);
                    }
                }
            }
            zeroId(dataDomain.getExpansionShelf());
            zeroId(dataDomain.getExtendedRetentionConversion());
            zeroId(dataDomain.getHealthCheck());
            DataDomainImplementation implementation = dataDomain.getImplementation();
            zeroId(implementation);
            if (implementation != null) {
                zeroId(implementation.getBoostBackupServer());
                Map<String,DataDomainImplApplianceModel> applianceModels = implementation.getApplianceModels();
                if (applianceModels != null) {
                    for (DataDomainImplApplianceModel item : applianceModels.values()) {
                        zeroId(item);
                    }
                }
            }
            zeroId(dataDomain.getIntegration());
            zeroId(dataDomain.getManagementCenterConfig());
            zeroId(dataDomain.getMigration());
            zeroId(dataDomain.getPreRack());
            zeroId(dataDomain.getSapHana());
            zeroId(dataDomain.getUpgrade());
            zeroId(dataDomain.getVtl());
        }

        DPA dpa = dpadRequestData.getDpa();
        zeroId(dpa);
        if (dpa != null) {
            zeroId(dpa.getDesign());
            zeroId(dpa.getImplementation());
            zeroId(dpa.getOperationalAssurance());
            zeroId(dpa.getCustomization());
            zeroId(dpa.getUpgradeMigration());
            zeroId(dpa.getHealthCheck());
        }

        Networker networker = dpadRequestData.getNetworker();
        zeroId(networker);
        if (networker != null) {
            zeroId(networker.getUpgrade());
            zeroId(networker.getDesign());
            zeroId(networker.getImplementation());
            zeroId(networker.getHealthcheck());

            if (networker.getDesign() != null) {
                zeroId(networker.getDesign().getAdvancedBackupTech());
                zeroId(networker.getDesign().getApplicationBackups());
                zeroId(networker.getDesign().getComponents());
                zeroId(networker.getDesign().getFileSystemClientBackups());
                zeroId(networker.getDesign().getMediaDevices());
                zeroId(networker.getDesign().getServer());
                zeroId(networker.getDesign().getStorageNodes());
            }
        }

        Mozy mozy = dpadRequestData.getMozy();
        zeroId(mozy);
        if (mozy != null) {
            zeroId(mozy.getCustom());
            zeroId(mozy.getOemBranding());
            zeroId(mozy.getOutTasking());
        }
    }

    /**
     * Zero XtremeRequestData id.
     *
     * @param xtremeRequestData the xtremeRequestData to zero id.
     */
    private static void zeroXtremeRequestDataId(XtremeRequestData xtremeRequestData) {
        zeroId(xtremeRequestData);

        // zero the id of all the "cascade-all" fields.

        zeroId(xtremeRequestData.getXtremeServices());
        zeroId(xtremeRequestData.getXtremeCache());
        zeroId(xtremeRequestData.getXtremeSF());
        zeroId(xtremeRequestData.getXtremeIOOracleLocalReplication());

        XtremeDesignImpl xtremeDesignAndImplementation = xtremeRequestData.getXtremeDesignAndImplementation();
        zeroId(xtremeDesignAndImplementation);
        if (xtremeDesignAndImplementation != null) {
            zeroId(xtremeDesignAndImplementation.getXtremeDataMigration());
        }
    }

    /**
     * Zero ChangeRequestData id.
     *
     * @param changeRequestData the changeRequestData to zero id.
     */
    private static void zeroChangeRequestDataId(ChangeRequestData changeRequestData) {
        zeroId(changeRequestData);

        // zero the id of all the "cascade-all" fields.

        if (changeRequestData.getRows() != null) {
            for (HoursByMonth h: changeRequestData.getRows()) {
                zeroId(h);

                // RoleHoursByMonth was missing in the last assembly. zero their ids as well.
                if (h.getRows() != null) {
                    for (RoleHoursByMonth rh: h.getRows()) {
                        zeroId(rh);
                    }
                }
            }
        }
    }

    /**
     * Zero MoveRequestData id.
     *
     * @param moveRequestData the moveRequestData to zero id.
     */
    private static void zeroMoveRequestDataId(MoveRequestData moveRequestData) {
        zeroId(moveRequestData);

        // zero the id of all the "cascade-all" fields.

        List<SiteInformation> siteInfo = moveRequestData.getSiteInformation();
        if (siteInfo != null) {
            for (SiteInformation siteInformation : siteInfo) {
                zeroId(siteInformation);
            }
        }
    }

    /**
     * Zero EstimatesData id.
     *
     * @param estimatesData the estimatesData to zero id.
     */
    private static void zeroEstimatesDataId(EstimatesData estimatesData) {
        zeroId(estimatesData);

        // zero the id of all the "cascade-all" fields.

        List<LOBResources> lobs = estimatesData.getLobResources();
        if (lobs != null) {
            for (LOBResources lob : lobs) {
                zeroId(lob);

                List<LOBResource> resources = lob.getResources();
                if (resources != null) {
                    for (LOBResource resource : resources) {
                        zeroId(resource);
                    }
                }
            }
        }
        List<IPEDURecord> ipEduData = estimatesData.getIpEduData();
        if (ipEduData != null) {
            for (IPEDURecord item : ipEduData) {
                zeroId(item);
            }
        }
    }
    
    /**
     * Zero request id.
     *
     * @param request the request to zero id.
     */
    public static void zeroRequestId(Request request) {

        zeroId(request);

        // zero the id of all the "cascade-all" fields.
        if (request.getCustomer() != null) {
            zeroCustomerId(request.getCustomer());
        }

        if (request.getStartRequestData() != null) {
            zeroStartRequestDataId(request.getStartRequestData());
        }

        if (request.getMainframeRequestData() != null) {
            zeroMainframeRequestDataId(request.getMainframeRequestData());
        }

        if (request.getBcRequestData() != null) {
            zeroBcRequestDataId(request.getBcRequestData());
        }

        if (request.getInfrastuctureRequestData() != null) {
            zeroInfrastructureRequestDataId(request.getInfrastuctureRequestData());
        }

        if (request.getUnifiedRequestData() != null) {
            zeroUnifiedRequestDataId(request.getUnifiedRequestData());
        }

        if (request.getMssRequestData() != null) {
            zeroMSSRequestDataId(request.getMssRequestData());
        }

        if (request.getCtaRequestData() != null) {
            zeroCTARequestDataId(request.getCtaRequestData());
        }

        if (request.getResidencyRequestData() != null) {
            zeroResidencyRequestDataId(request.getResidencyRequestData());
        }

        if (request.getSourceOneRequestData() != null) {
            zeroSourceOneRequestDataId(request.getSourceOneRequestData());
        }

        if (request.getAsdRequestData() != null) {
            zeroASDRequestDataId(request.getAsdRequestData());
        }

        if (request.getHealthCheckRequestData() != null) {
            zeroHealthCheckRequestDataId(request.getHealthCheckRequestData());
        }

        if (request.getIsilonRequestData() != null) {
            zeroIsilonRequestDataId(request.getIsilonRequestData());
        }

        if (request.getViprRequestData() != null) {
            zeroViprRequestDataId(request.getViprRequestData());
        }

        if (request.getVblockRequestData() != null) {
            zeroVblockRequestDataId(request.getVblockRequestData());
        }

        if (request.getAtmosRequestData() != null) {
            zeroAtmosCenteraRequestDataId(request.getAtmosRequestData());
        }

        if (request.getVmwareRequestData() != null) {
            zeroVMwareRequestDataId(request.getVmwareRequestData());
        }

        if (request.getDpadRequestData() != null) {
            zeroDPADRequestDataId(request.getDpadRequestData());
        }

        if (request.getXtremeRequestData() != null) {
            zeroXtremeRequestDataId(request.getXtremeRequestData());
        }

        zeroId(request.getUnfundedProjectData());

        if (request.getChangeRequestData() != null) {
            zeroChangeRequestDataId(request.getChangeRequestData());
        }

        if (request.getMoveRequestData() != null) {
            zeroMoveRequestDataId(request.getMoveRequestData());
        }

        zeroId(request.getW4nData());

        zeroId(request.getSrmRequestData());

        zeroId(request.getEngagementTypeData());

        zeroId(request.getDealGovernanceData());

        zeroId(request.getRiskCalculationData());

        zeroId(request.getSanTanInformation());

        if (request.getEstimatesData() != null) {
            zeroEstimatesDataId(request.getEstimatesData());
        }
    }

    /**
     * Copy request.
     *
     * @param request the request to copy
     * @param enabledTabs the enabled tabs
     * @return copied request
     */
    public static Request copyRequest(Request request, EnabledTabs enabledTabs) {

        Request copiedRequest = new Request();

        // Copy all fields from request to copied request except id, e.g.

        if (request.getCustomer() != null) {
            copiedRequest.setCustomer(request.getCustomer());
            zeroCustomerId(copiedRequest.getCustomer());
        }

        if (request.getStartRequestData() != null) {
            copiedRequest.setStartRequestData(request.getStartRequestData());
            zeroStartRequestDataId(copiedRequest.getStartRequestData());
        }

        if (request.getMainframeRequestData() != null) {
            copiedRequest.setMainframeRequestData(request.getMainframeRequestData());
            zeroMainframeRequestDataId(copiedRequest.getMainframeRequestData());
        }

        if (request.getBcRequestData() != null) {
            copiedRequest.setBcRequestData(request.getBcRequestData());
            zeroBcRequestDataId(copiedRequest.getBcRequestData());
        }

        if (request.getInfrastuctureRequestData() != null) {
            copiedRequest.setInfrastuctureRequestData(request.getInfrastuctureRequestData());
            zeroInfrastructureRequestDataId(copiedRequest.getInfrastuctureRequestData());
        }

        if (request.getSanTanInformation() != null) {
            copiedRequest.setSanTanInformation(request.getSanTanInformation());
            zeroId(copiedRequest.getSanTanInformation());
        }

        if (request.getUnifiedRequestData() != null) {
            copiedRequest.setUnifiedRequestData(request.getUnifiedRequestData());
            zeroUnifiedRequestDataId(copiedRequest.getUnifiedRequestData());
        }

        if (enabledTabs.isEnableMSS() && request.getMssRequestData() != null) {
            copiedRequest.setMssRequestData(request.getMssRequestData());
            zeroMSSRequestDataId(copiedRequest.getMssRequestData());
        }

        if (enabledTabs.isEnableCTA() && request.getCtaRequestData() != null) {
            copiedRequest.setCtaRequestData(request.getCtaRequestData());
            zeroCTARequestDataId(copiedRequest.getCtaRequestData());
        }

        if (enabledTabs.isEnableResidency() && request.getResidencyRequestData() != null) {
            copiedRequest.setResidencyRequestData(request.getResidencyRequestData());
            zeroResidencyRequestDataId(copiedRequest.getResidencyRequestData());
        }

        if (enabledTabs.isEnableSourceOne() && request.getSourceOneRequestData() != null) {
            copiedRequest.setSourceOneRequestData(request.getSourceOneRequestData());
            zeroSourceOneRequestDataId(copiedRequest.getSourceOneRequestData());
        }

        if (enabledTabs.isEnableASD() && request.getAsdRequestData() != null) {
            copiedRequest.setAsdRequestData(request.getAsdRequestData());
            zeroASDRequestDataId(copiedRequest.getAsdRequestData());
        }

        if (enabledTabs.isEnableHealthCheck() && request.getHealthCheckRequestData() != null) {
            copiedRequest.setHealthCheckRequestData(request.getHealthCheckRequestData());
            zeroHealthCheckRequestDataId(copiedRequest.getHealthCheckRequestData());
        }

        if (enabledTabs.isEnableIsilon() && request.getIsilonRequestData() != null) {
            copiedRequest.setIsilonRequestData(request.getIsilonRequestData());
            zeroIsilonRequestDataId(copiedRequest.getIsilonRequestData());
        }

        if (enabledTabs.isEnableViPR() && request.getViprRequestData() != null) {
            copiedRequest.setViprRequestData(request.getViprRequestData());
            zeroViprRequestDataId(copiedRequest.getViprRequestData());
        }

        if (enabledTabs.isEnableVblock() && request.getVblockRequestData() != null) {
            copiedRequest.setVblockRequestData(request.getVblockRequestData());
            zeroVblockRequestDataId(copiedRequest.getVblockRequestData());
        }

        if (enabledTabs.isEnableAtmos() && request.getAtmosRequestData() != null) {
            copiedRequest.setAtmosRequestData(request.getAtmosRequestData());
            zeroAtmosCenteraRequestDataId(copiedRequest.getAtmosRequestData());
        }

        if (enabledTabs.isEnableVMWare() && request.getVmwareRequestData() != null) {
            copiedRequest.setVmwareRequestData(request.getVmwareRequestData());
            zeroVMwareRequestDataId(copiedRequest.getVmwareRequestData());
        }

        if (enabledTabs.isEnableDPAD() && request.getDpadRequestData() != null) {
            copiedRequest.setDpadRequestData(request.getDpadRequestData());
            zeroDPADRequestDataId(copiedRequest.getDpadRequestData());
        }

        if (enabledTabs.isEnableXtreme() && request.getXtremeRequestData() != null) {
            copiedRequest.setXtremeRequestData(request.getXtremeRequestData());
            zeroXtremeRequestDataId(copiedRequest.getXtremeRequestData());
        }

        if (request.getUnfundedProjectData() != null) {
            copiedRequest.setUnfundedProjectData(request.getUnfundedProjectData());
            zeroId(copiedRequest.getUnfundedProjectData());
        }

        if (enabledTabs.isEnableChangeRequest() && request.getChangeRequestData() != null) {
            copiedRequest.setChangeRequestData(request.getChangeRequestData());
            zeroChangeRequestDataId(copiedRequest.getChangeRequestData());
        }

        if (enabledTabs.isEnableMoveRequest() && request.getMoveRequestData() != null) {
            copiedRequest.setMoveRequestData(request.getMoveRequestData());
            zeroMoveRequestDataId(copiedRequest.getMoveRequestData());
        }

        if (enabledTabs.isEnableW4N() && request.getW4nData() != null) {
            copiedRequest.setW4nData(request.getW4nData());
            zeroId(copiedRequest.getW4nData());
        }

        if (enabledTabs.isEnableSRM() && request.getSrmRequestData() != null) {
            copiedRequest.setSrmRequestData(request.getSrmRequestData());
            zeroId(copiedRequest.getSrmRequestData());
        }

        copiedRequest.setEngagementTypeData(request.getEngagementTypeData());
        zeroId(copiedRequest.getEngagementTypeData());

        copiedRequest.setDealGovernanceData(request.getDealGovernanceData());
        zeroId(copiedRequest.getDealGovernanceData());

        copiedRequest.setRiskCalculationData(request.getRiskCalculationData());
        zeroId(copiedRequest.getRiskCalculationData());

        if (request.getEstimatesData() != null) {
            copiedRequest.setEstimatesData(request.getEstimatesData());
            zeroEstimatesDataId(copiedRequest.getEstimatesData());
        }

        copiedRequest.setProjectType(request.getProjectType());
        copiedRequest.setProjectRegulatoryType(request.getProjectRegulatoryType());
        copiedRequest.setProjectStartDate(request.getProjectStartDate());
        copiedRequest.setProjectEndDate(request.getProjectEndDate());
        copiedRequest.setRequestStatus(request.getRequestStatus());
        copiedRequest.setRequestType(request.getRequestType());
        copiedRequest.setProjectName(request.getProjectName());
        copiedRequest.setProjectDescription(request.getProjectDescription());

        return copiedRequest;
    }

    /**
     * Clone an entity deeply.
     *
     * @param entity the entity to clone
     * @return the cloned entity
     * @throws ServiceRequestToolException if there is any error when cloning entity
     */
    @SuppressWarnings("unchecked")
    public static <T> T deepCloneEntity(T entity) throws ServiceRequestToolException {
        if (entity == null) {
            return null;
        }

        try {
            return (T) OBJECT_MAPPER.readValue(OBJECT_MAPPER.writeValueAsString(entity), entity.getClass());
        } catch (IOException e) {
            throw new ServiceRequestToolException("Failed to copy entity", e);
        }
    }

    /**
     * Generates the XML export file name.
     *
     * @param request The request for export.
     * @return The export file name.
     * @since 2.8
     */
    public static String generateExportFileName(Request request) {
        StringBuilder fileName = new StringBuilder();
        StartRequestData startRequestData = request.getStartRequestData();
        String dxQuoteNumber = startRequestData.getDxQuoteNumber();
        String sfdcNumber = startRequestData.getSfdcNumber();
        EstimatesData estimatesData = request.getEstimatesData();
        if (!StringUtils.isEmpty(dxQuoteNumber)) {
            fileName.append(dxQuoteNumber);
        } else {
            fileName.append(DIRECT_EXPRESS_DX_QUOTE_NUMBER_FIELD_NAME);
        }
        fileName.append('_');
        if (!StringUtils.isEmpty(sfdcNumber)) {
            fileName.append(sfdcNumber);
        } else {
            fileName.append(DXP_OPPORTUNITY_NUMBER_FIELD_NAME);
        }
        fileName.append('_');
        if (estimatesData != null) {
            DeliverAction deliverAction = estimatesData.getDeliverAction();
            if (deliverAction != null) {
                fileName.append(getLookupCode(deliverAction));
            } else {
                fileName.append(DELIVERY_ACTION_FIELD_NAME);
            }
        } else {
            fileName.append(DELIVERY_ACTION_FIELD_NAME);
        }
        fileName.append('_');
        fileName.append(leftPad(String.valueOf(System.currentTimeMillis()), 13, '0'));
        return fileName.toString();
    }

    /**
     * <p> Validates the value to represent a valid zip/postal code.</p>
     *
     * @param logger the logger object.
     * @param signature the signature of the method to be logged.
     * @param value the the variable to be validated.
     * @param name the name of the variable to be validated.
     * @throws IllegalArgumentException if the the value is not valid zip/postal code.
     * @since 2.10
     */
    public static void checkZipPostalCode(Logger logger, String signature, String value, String name) {
        checkStrNullEmpty(logger, signature, value, name);
        Matcher matcher = ZIP_POSTAL_CODE_PATTERN.matcher(value);
        if (!matcher.matches()) {
            throw logException(logger, signature, new IllegalArgumentException("'" + name + "' is not valid."));
        }
    }

    /**
     * <p>Checks if <code>Risk Calculation</code> must be exported for specified request or not. The risk calculation is
     * not required is just either RSA or ECD LOB is selected.</p>
     *
     * @param request a <code>Request</code> providing the data for request.
     * @return <code>true</code> if <code>Risk Calculation</code> must be exported; <code>false</code> otherwise.
     * @since 2.10
     */
    public static boolean isRiskCalculationRequired(Request request) {
        EngagementTypeData engagementTypeData = request.getEngagementTypeData();
        boolean isECDSelected = engagementTypeData.isEcd();
        boolean isRSASelected = engagementTypeData.isRsa();
        int selectedLOBsCount = engagementTypeData.countSelectedLOBs();
        boolean dealGovernanceNotUsed = (isECDSelected || isRSASelected) && selectedLOBsCount == 1 ||
            isECDSelected && isRSASelected && selectedLOBsCount == 2;

        return !dealGovernanceNotUsed;
    }

    /**
     * <p>Generates a text of specified length consisting with specified ID pre-pended with specified character.</p>
     *
     * @param id a <code>String</code> providing the ID to process.
     * @param length an <code>int</code> specifying the maximum length for resulting text.
     * @param ch a <code>char</code> to be used for extending the result text to specified length.
     * @return a <code>String</code> providing the resulting text.
     * @since 2.8
     */
    private static String leftPad(String id, int length, char ch) {
        return id != null ? StringUtils.leftPad(StringUtils.right(id, length), length, ch) : "";
    }
}

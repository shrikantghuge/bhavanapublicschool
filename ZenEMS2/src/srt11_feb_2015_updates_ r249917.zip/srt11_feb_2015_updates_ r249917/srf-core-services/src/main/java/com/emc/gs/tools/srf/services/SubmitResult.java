/*
 * Copyright (C) 2014 TopCoder Inc., All Rights Reserved.
 */
package com.emc.gs.tools.srf.services;

import java.util.List;

/**
 * The request submit result.
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safety.
 * </p>
 * @author liuliquan
 * @version 1.0
 * @since SRT Phase 2 Release Assembly
 */
public class SubmitResult {

    /**
     * The thread local.
     */
    public static final ThreadLocal<SubmitResult> SUBMIT_RESULT = new ThreadLocal<SubmitResult>();

    /**
     * The unique submit ID.
     */
    private final String submitId;

    /**
     * The submitted request ids.
     */
    private List<Long> submittedRequestIds;

    /**
     * The validate messages.
     */
    private List<String> validationMessages;

    /**
     * The error message.
     */
    private String errorMessage;

    /**
     * Total size of attachments to send.
     */
    private long totalSize;

    /**
     * Size of attachments sent.
     */
    private long sizeSent;

    /**
     * Represent whether submission is finished.
     */
    private boolean finished;

    /**
     * Empty constructor.
     */
    public SubmitResult(String submitId) {
        this.submitId = submitId;
    }

    /**
     * Getter method for property <tt>submitId</tt>.
     * @return property value of submitId
     */
    public String getSubmitId() {
        return submitId;
    }

    /**
     * Getter method for property <tt>submittedRequestIds</tt>.
     * @return property value of submittedRequestIds
     */
    public List<Long> getSubmittedRequestIds() {
        return submittedRequestIds;
    }

    /**
     * Setter method for property <tt>submittedRequestIds</tt>.
     * @param submittedRequestIds
     *            value to be assigned to property submittedRequestIds
     */
    public void setSubmittedRequestIds(List<Long> submittedRequestIds) {
        this.submittedRequestIds = submittedRequestIds;
    }

    /**
     * Getter method for property <tt>validationMessages</tt>.
     * @return property value of validationMessages
     */
    public List<String> getValidationMessages() {
        return validationMessages;
    }

    /**
     * Setter method for property <tt>validationMessages</tt>.
     * @param validationMessages
     *            value to be assigned to property validationMessages
     */
    public void setValidationMessages(List<String> validationMessages) {
        this.validationMessages = validationMessages;
    }

    /**
     * Getter method for property <tt>errorMessage</tt>.
     * @return property value of errorMessage
     */
    public String getErrorMessage() {
        return errorMessage;
    }

    /**
     * Setter method for property <tt>errorMessage</tt>.
     * @param errorMessage
     *            value to be assigned to property errorMessage
     */
    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }

    /**
     * Getter method for property <tt>totalSize</tt>.
     * @return property value of totalSize
     */
    public long getTotalSize() {
        return totalSize;
    }

    /**
     * Setter method for property <tt>totalSize</tt>.
     * @param totalSize
     *            value to be assigned to property totalSize
     */
    public void setTotalSize(long totalSize) {
        this.totalSize = totalSize;
    }

    /**
     * Getter method for property <tt>sizeSent</tt>.
     * @return property value of sizeSent
     */
    public long getSizeSent() {
        return sizeSent;
    }

    /**
     * Setter method for property <tt>sizeSent</tt>.
     * @param sizeSent
     *            value to be assigned to property sizeSent
     */
    public void setSizeSent(long sizeSent) {
        this.sizeSent = sizeSent;
    }

    /**
     * Getter method for property <tt>finished</tt>.
     * @return property value of finished
     */
    public boolean isFinished() {
        return finished;
    }

    /**
     * Setter method for property <tt>finished</tt>.
     * @param finished
     *            value to be assigned to property finished
     */
    public void setFinished(boolean finished) {
        this.finished = finished;
    }

}

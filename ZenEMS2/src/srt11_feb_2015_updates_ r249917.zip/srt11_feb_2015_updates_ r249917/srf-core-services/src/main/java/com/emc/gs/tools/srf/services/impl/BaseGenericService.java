/*
 * This code is copyright (c) 2013 - 2014 EMC Corporation.
 */
package com.emc.gs.tools.srf.services.impl;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.PersistenceException;

import org.apache.log4j.Logger;
import org.springframework.transaction.annotation.Transactional;

import com.emc.gs.tools.srf.AuthorizationException;
import com.emc.gs.tools.srf.model.IdentifiableEntity;
import com.emc.gs.tools.srf.services.AlreadySynchronizedException;
import com.emc.gs.tools.srf.services.EntityNotFoundException;
import com.emc.gs.tools.srf.services.GenericService;
import com.emc.gs.tools.srf.services.ServiceRequestToolException;

/**
 * <p>
 * This class is the base class that implements basic create,update,delete,get persistence operation for a specific
 * entity.
 * </p>
 *
 * <p>
 * <strong>Thread safety</strong>: This class is effectively thread safe after configuration, the configuration is done
 * in a thread safe manner.
 * </p>
 *
 * <p>
 * <strong>Changes in v1.1:</strong>
 * <strong>SRT Cloud Synchronization - Cloud App Assembly v1.0</strong>
 * <ul>
 * <li>delete now removed duplicate ids before executing the delete.</li>
 * </ul>
 * </p>
 *
 * <p>
 * <strong>Changes V1.2:</strong>
 * <strong>SRT Phase 4 - ET Assembly 2</strong>
 * <ul>
 * <li>Refactor the generic service to Template pattern.</li>
 * </ul>
 * </p>
 * 
 * @param <T>
 *            the class type
 * @author faeton, stevenfrog, TCSASSEMBLER
 * @version 1.2
 */
public abstract class BaseGenericService<T extends IdentifiableEntity> extends BasePersistenceService
        implements GenericService<T> {

    /**
     * <p>
     * Represents the class name.
     * </p>
     */
    private static final String CLASSNAME = BaseGenericService.class.getName();

    /**
     * Represents the entity class used for the persistence. It is initialized in constructor and never changed
     * afterwards. It can not be null.
     */
    private final Class<T> entityClass;

    /**
     * This is the constructor of this base service.
     * 
     * @param entityClass
     *            the entity class used for the persistence
     * @throws IllegalArgumentException
     *             if entityClass is null.
     */
    protected BaseGenericService(Class<T> entityClass) {
        final String signature = CLASSNAME + "#BaseGenericService(Class<T> entityClass)";
        Logger logger = getLogger();

        // Log entry
        Helper.logEntrance(logger, signature, new String[] {"entityClass"}, new Object[] {entityClass});

        Helper.checkNull(logger, signature, entityClass, "entityClass");

        this.entityClass = entityClass;

        // Log exit
        Helper.logExit(logger, signature, null);
    }

    /**
     * Getter method for property <tt>entityClass</tt>.
     * 
     * @return property value of entityClass
     * @since SRT Phase 4 - ET Assembly 2
     */
    public Class<T> getEntityClass() {
        return entityClass;
    }

    /**
     * Implementations can override this method to perform any actions before create.
     * 
     * @param entity
     *            the entity to be created
     * @throws ServiceRequestToolException
     *             if any other error occurs
     * @since SRT Phase 4 - ET Assembly 2
     */
    protected void beforeCreate(T entity) throws ServiceRequestToolException {
        // empty
    }

    /**
     * Implementations can override this method to perform any actions after create.
     * 
     * @param entity
     *            the entity created
     * @throws ServiceRequestToolException
     *             if any other error occurs
     * @since SRT Phase 4 - ET Assembly 2
     */
    protected void afterCreate(T entity) throws ServiceRequestToolException {
        // empty
    }

    /**
     * Creates an entity.
     * 
     * @param entity
     *            the entity to create
     * @return The created entity
     * @throws IllegalArgumentException
     *             if entity is null
     * @throws AuthorizationException
     *             if authorization error occurs
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     */
    @Transactional(rollbackFor = {AuthorizationException.class, ServiceRequestToolException.class},
            noRollbackFor = AlreadySynchronizedException.class)
    public T create(T entity) throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#create(T entity)";
        Logger logger = getLogger();

        // Log entry
        Helper.logEntrance(logger, signature, new String[] {"entity"}, new Object[] {entity});

        Helper.checkNull(logger, signature, entity, "entity");

        try {

            beforeCreate(entity);

            getEntityManager().persist(entity);

            afterCreate(entity);

            // Log exit
            Helper.logExit(logger, signature, new Object[] {entity});
            return entity;
        } catch (IllegalStateException e) {
            // Log exception
            throw Helper.logException(logger, signature, new ServiceRequestToolException(
                    "The entity manager has been closed.", e));
        } catch (PersistenceException e) {
            // Log exception
            throw Helper.logException(logger, signature, new ServiceRequestToolException(
                    "An error has occurred while accessing the persistence.", e));
        } catch (AuthorizationException e) {
            // Log exception
            throw Helper.logException(logger, signature, e);
        } catch (ServiceRequestToolException e) {
            // Log exception
            throw Helper.logException(logger, signature, e);
        }
    }

    /**
     * Implementations can override this method to perform any actions before update.
     * 
     * @param entity
     *            the entity to be updated
     * @throws EntityNotFoundException
     *             if the entity does not exist
     * @throws ServiceRequestToolException
     *             if any other error occurs
     * @since SRT Phase 4 - ET Assembly 2
     */
    protected void beforeUpdate(T entity) throws ServiceRequestToolException {

        // Check existing entity
        checkEntityExist(entity.getId());
    }

    /**
     * Implementations can override this method to perform any actions after update.
     * 
     * @param entity
     *            the entity updated
     * @throws ServiceRequestToolException
     *             if any other error occurs
     * @since SRT Phase 4 - ET Assembly 2
     */
    protected void afterUpdate(T entity) throws ServiceRequestToolException {
        // empty
    }

    /**
     * Updates an entity.
     * 
     * @param entity
     *            the entity to update
     * @return The updated entity
     * @throws IllegalArgumentException
     *             if entity is null
     * @throws AuthorizationException
     *             if authorization error occurs
     * @throws EntityNotFoundException
     *             if the entity to update doesn't exist
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     */
    @Transactional(rollbackFor = {AuthorizationException.class, ServiceRequestToolException.class},
            noRollbackFor = AlreadySynchronizedException.class)
    public T update(T entity) throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#update(T entity)";
        Logger logger = getLogger();

        // Log entry
        Helper.logEntrance(logger, signature, new String[] {"entity"}, new Object[] {entity});

        Helper.checkNull(logger, signature, entity, "entity");

        try {
            beforeUpdate(entity);

            entity = getEntityManager().merge(entity);

            afterUpdate(entity);

            // Log exit
            Helper.logExit(logger, signature, new Object[] {entity});
            return entity;
        } catch (IllegalStateException e) {
            // Log exception
            throw Helper.logException(logger, signature, new ServiceRequestToolException(
                    "The entity manager has been closed.", e));
        } catch (PersistenceException e) {
            // Log exception
            throw Helper.logException(logger, signature, new ServiceRequestToolException(
                    "An error has occurred while accessing the persistence.", e));
        } catch (AuthorizationException e) {
            // Log exception
            throw Helper.logException(logger, signature, e);
        } catch (ServiceRequestToolException e) {
            // Log exception
            throw Helper.logException(logger, signature, e);
        }
    }

    /**
     * Check the entity whether exists.
     * 
     * @param id
     *            the entity id
     * @return the entity retrieved from DB
     * @throws EntityNotFoundException
     *             if the entity does not exist
     */
    protected T checkEntityExist(long id) throws EntityNotFoundException {
        T result = getEntityManager().find(entityClass, id);
        if (result == null) {
            throw new EntityNotFoundException("The " + entityClass.getSimpleName() + " does not exist with id: " + id);
        }
        return result;
    }

    /**
     * Implementations can override this method to perform any actions before delete.
     * 
     * @param entity
     *            the id of entity to be deleted
     * @return the existing entity to be deleted
     * @throws EntityNotFoundException
     *             if the entity does not exist
     * @throws ServiceRequestToolException
     *             if any other error occurs
     * @since SRT Phase 4 - ET Assembly 2
     */
    protected T beforeDelete(long id) throws ServiceRequestToolException {

        return checkEntityExist(id);
    }

    /**
     * Implementations can override this method to perform any actions after delete.
     * 
     * @param entity
     *            the entity deleted
     * @throws ServiceRequestToolException
     *             if any other error occurs
     * @since SRT Phase 4 - ET Assembly 2
     */
    protected void afterDelete(T entity) throws ServiceRequestToolException {
        // empty
    }

    /**
     * Deletes one or more entities.
     * 
     * @param ids
     *            the IDs of the entities to delete
     * @throws IllegalArgumentException
     *             if ids array is null/empty, or any element in ids array is not positive
     * @throws AuthorizationException
     *             if authorization error occurs
     * @throws EntityNotFoundException
     *             if any entity to delete doesn't exist
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     */
    @Transactional(rollbackFor = {AuthorizationException.class, ServiceRequestToolException.class},
            noRollbackFor = AlreadySynchronizedException.class)
    public void delete(long[] ids) throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#delete(long[] ids)";
        Logger logger = getLogger();

        // Log entry
        Helper.logEntrance(logger, signature, new String[] {"ids"}, new Object[] {ids});

        Helper.checkArrayPositive(logger, signature, ids, "ids");

        Set<Long> alreadyDeleted = new HashSet<Long>();

        try {
            for (long id : ids) {
                // entity with id already deleted -> skip
                if (alreadyDeleted.contains(id)) {
                    continue;
                }

                T entity = beforeDelete(id);

                getEntityManager().remove(entity);
                alreadyDeleted.add(id);

                afterDelete(entity);
            }

            // Log exit
            Helper.logExit(logger, signature, null);
        } catch (IllegalStateException e) {
            // Log exception
            throw Helper.logException(logger, signature, new ServiceRequestToolException(
                    "The entity manager has been closed.", e));
        } catch (PersistenceException e) {
            // Log exception
            throw Helper.logException(logger, signature, new ServiceRequestToolException(
                    "An error has occurred while accessing the persistence.", e));
        } catch (AuthorizationException e) {
            // Log exception
            throw Helper.logException(logger, signature, e);
        } catch (ServiceRequestToolException e) {
            // Log exception
            throw Helper.logException(logger, signature, e);
        }
    }

    /**
     * Implementations can override this method to perform any actions before get.
     * 
     * @param entity
     *            the id of entity to get
     * @throws ServiceRequestToolException
     *             if any other error occurs
     * @since SRT Phase 4 - ET Assembly 2
     */
    protected void beforeGet(long id) throws ServiceRequestToolException {
        // empty
    }

    /**
     * Implementations can override this method to perform any actions after get.
     * 
     * @param entity
     *            the id of entity got
     * @throws ServiceRequestToolException
     *             if any other error occurs
     * @since SRT Phase 4 - ET Assembly 2
     */
    protected void afterGet(T entity) throws ServiceRequestToolException {
        // empty
    }

    /**
     * Retrieves an entity.
     * 
     * @param id
     *            the ID of the entity to retrieve
     * @return The entity for the id or null will, if there's no such entity
     * @throws IllegalArgumentException
     *             if id is not positive
     * @throws AuthorizationException
     *             if authorization error occurs
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     */
    public T get(long id) throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#get(long id)";
        Logger logger = getLogger();

        // Log entry
        Helper.logEntrance(logger, signature, new String[] {"id"}, new Object[] {id});

        Helper.checkPositive(logger, signature, id, "id");

        try {
            beforeGet(id);

            T entity = getEntityManager().find(entityClass, id);

            afterGet(entity);

            // Log exit
            Helper.logExit(logger, signature, new Object[] {entity});
            return entity;
        } catch (IllegalStateException e) {
            // Log exception
            throw Helper.logException(logger, signature, new ServiceRequestToolException(
                    "The entity manager has been closed.", e));
        } catch (PersistenceException e) {
            // Log exception
            throw Helper.logException(logger, signature, new ServiceRequestToolException(
                    "An error has occurred while accessing the persistence.", e));
        } catch (AuthorizationException e) {
            // Log exception
            throw Helper.logException(logger, signature, e);
        } catch (ServiceRequestToolException e) {
            // Log exception
            throw Helper.logException(logger, signature, e);
        }
    }
}

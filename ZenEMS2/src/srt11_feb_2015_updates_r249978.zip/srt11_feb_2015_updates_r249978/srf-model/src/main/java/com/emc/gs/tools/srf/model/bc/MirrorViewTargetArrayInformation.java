/*
 * This code is copyright (c) 2014 EMC Corporation.
 */
package com.emc.gs.tools.srf.model.bc;


/**
 * <p>
 * This is target array information for MirrorViewInformation entity.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safety.
 * </p>
 * 
 * <p>
 * <strong>Changes V1.1:</strong>
 * <ul>
 * <li>Removed snapViewOnTargetDevices, snapViewUsedForBackups, snapViewSizeToCopy, snapViewCopiesNumber fields.</li>
 * </ul>
 * </p>
 *
 * @author faeton, TCSASSEMBLER, MonicaMuranyi
 * @version 1.1
 * @since SRT Release Assembly - BC Tab
 */
public class MirrorViewTargetArrayInformation extends MirrorViewBaseArrayInformation {

    /**
     * Empty constructor.
     */
    public MirrorViewTargetArrayInformation() {
    }

    /**
     * The toString method.
     *
     * @return the string for this entity
     */
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("{").append(super.toString()).append("}");
        return sb.toString();
    }

}

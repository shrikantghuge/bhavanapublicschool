/*
 * This code is copyright (c) 2013 - 2015 EMC Corporation.
 */
package com.emc.gs.tools.srf.model;

/**
 * <p>
 * This is OtherRequestOptions entity class.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safety.
 * </p>
 * <p>
 * <strong>Changes V1.1:</strong>
 * <strong>SRT Phase 3-4 - ASD and Healthcheck Tabs Assembly</strong>
 * <ul>
 * <li>Add healthChecks field.</li>
 * </ul>
 * </p>
 *
 * <p>
 * Version 1.2 Change notes:
 *   <ol>
 *     <li>Added {@link #notListed} property.</li>
 *   </ol>
 * </p>
 *
 * <p>
 * Version 1.3 Change notes:
 *   <ol>
 *     <li>Added {@link #assessment} property.</li>
 *     <li>Added {@link #protectPoint} property.</li>
 *   </ol>
 * </p>
 * 
 * @author faeton, stevenfrog, isv
 * @version 1.3
 */
public class OtherRequestOptions extends IdentifiableEntity {
    /**
     * <p>
     * The residency.
     * </p>
     */
    private boolean residency;

    /**
     * <p>
     * The iSeries.
     * </p>
     */
    private boolean iSeries;

    /**
     * <p>
     * The diskRetention.
     * </p>
     */
    private boolean diskRetention;

    /**
     * <p>
     * The moveRequest.
     * </p>
     */
    private boolean moveRequest;

    /**
     * <p>
     * The healthChecks.
     * </p>
     * @since SRT Phase 3-4 - ASD and Healthcheck Tabs Assembly
     */
    private boolean healthChecks;

    /**
     * <p>A <code>boolean</code> providing the value for notListed property.</p>
     * 
     * @since 1.2
     */
    private boolean notListed;

    /**
     * <p>A <code>boolean</code> providing the value for assessment property.</p>
     * 
     * @since 1.3
     */
    private boolean assessment;

    /**
     * <p>A <code>boolean</code> providing the value for protectPoint property.</p>
     *
     * @since 1.3
     */
    private boolean protectPoint;

    /**
     * <p>
     * The default constructor.
     * </p>
     */
    public OtherRequestOptions() {
        // Empty
    }

    /**
     * <p>
     * Retrieves the residency field.
     * </p>
     * 
     * @return the residency
     */
    public boolean isResidency() {
        return residency;
    }

    /**
     * <p>
     * Sets the value to residency field.
     * </p>
     * 
     * @param residency
     *            the residency to set
     */
    public void setResidency(boolean residency) {
        this.residency = residency;
    }

    /**
     * <p>
     * Retrieves the iSeries field.
     * </p>
     * 
     * @return the iSeries
     */
    public boolean isiSeries() {
        return iSeries;
    }

    /**
     * <p>
     * Sets the value to iSeries field.
     * </p>
     * 
     * @param iSeries
     *            the iSeries to set
     */
    public void setiSeries(boolean iSeries) {
        this.iSeries = iSeries;
    }

    /**
     * <p>
     * Retrieves the diskRetention field.
     * </p>
     * 
     * @return the diskRetention
     */
    public boolean isDiskRetention() {
        return diskRetention;
    }

    /**
     * <p>
     * Sets the value to diskRetention field.
     * </p>
     * 
     * @param diskRetention
     *            the diskRetention to set
     */
    public void setDiskRetention(boolean diskRetention) {
        this.diskRetention = diskRetention;
    }

    /**
     * <p>
     * Retrieves the moveRequest field.
     * </p>
     * 
     * @return the moveRequest
     */
    public boolean isMoveRequest() {
        return moveRequest;
    }

    /**
     * <p>
     * Sets the value to moveRequest field.
     * </p>
     * 
     * @param moveRequest
     *            the moveRequest to set
     */
    public void setMoveRequest(boolean moveRequest) {
        this.moveRequest = moveRequest;
    }

    /**
     * Getter method for property <tt>healthChecks</tt>.
     * 
     * @return property value of healthChecks
     * @since SRT Phase 3-4 - ASD and Healthcheck Tabs Assembly
     */
    public boolean isHealthChecks() {
        return healthChecks;
    }

    /**
     * Setter method for property <tt>healthChecks</tt>.
     * 
     * @param healthChecks
     *            value to be assigned to property healthChecks
     * @since SRT Phase 3-4 - ASD and Healthcheck Tabs Assembly
     */
    public void setHealthChecks(boolean healthChecks) {
        this.healthChecks = healthChecks;
    }

    /**
     * <p>Gets the notListed property.</p>
     *
     * @return a <code>boolean</code> providing the value for notListed property.
     * @since 1.2
     */
    public boolean getNotListed() {
        return this.notListed;
    }

    /**
     * <p>Sets the notListed property.</p>
     *
     * @param notListed a <code>boolean</code> providing the value for notListed property.
     * @since 1.2
     */
    public void setNotListed(boolean notListed) {
        this.notListed = notListed;
    }

    /**
     * <p>Gets the assessment property.</p>
     *
     * @return a <code>boolean</code> providing the value for assessment property.
     * @since 1.3
     */
    public boolean getAssessment() {
        return this.assessment;
    }

    /**
     * <p>Sets the assessment property.</p>
     *
     * @param assessment a <code>boolean</code> providing the value for assessment property.
     * @since 1.3
     */
    public void setAssessment(boolean assessment) {
        this.assessment = assessment;
    }

    /**
     * <p>Gets the protectPoint property.</p>
     *
     * @return a <code>boolean</code> providing the value for protectPoint property.
     * @since 1.3
     */
    public boolean getProtectPoint() {
        return this.protectPoint;
    }

    /**
     * <p>Sets the protectPoint property.</p>
     *
     * @param protectPoint a <code>boolean</code> providing the value for protectPoint property.
     * @since 1.3
     */
    public void setProtectPoint(boolean protectPoint) {
        this.protectPoint = protectPoint;
    }

    /**
     * The toString method.
     * 
     * @return the string for this entity
     */
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("{").append(super.toString());
        sb.append(", residency:").append(residency);
        sb.append(", iSeries:").append(iSeries);
        sb.append(", diskRetention:").append(diskRetention);
        sb.append(", healthChecks:").append(healthChecks);
        sb.append(", notListed:").append(notListed);
        sb.append(", moveRequest:").append(moveRequest);
        sb.append(", assessment:").append(assessment);
        sb.append(", protectPoint:").append(protectPoint);
        sb.append("}");
        return sb.toString();
    }
}

/*
 * This code is copyright (c) 2014 EMC Corporation.
 */
package com.emc.gs.tools.srf.model;

/**
 * <p>This is RecoveryLevelType entity class.</p>
 *
 * <p><strong>Thread safety</strong>: This class is mutable, it is not thread safety.</p>
 *
 * @author isv
 */
public class RecoveryLevelType extends LookupEntity {

    /**
     * <p>Constructs new <code>RecoveryLevelType</code> instance. This implementation does nothing.</p>
     */
    public RecoveryLevelType() {
    }

}

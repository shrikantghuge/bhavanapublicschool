/*
 * This code is copyright (c) 2013 - 2014 EMC Corporation.
 */
package com.emc.gs.tools.srf.model;

/**
 * <p>
 * This is CountryState entity class.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safety.
 * </p>
 * 
 * <p>
 * <strong>Changes V1.1:</strong>
 * <strong>Commercial / Mid-Market Division Special Handling Logic</strong>
 * <ul>
 * <li>Added defaultDivision and defaultPdmName fields.</li>
 * </ul>
 * </p>
 *
 * @author faeton, stevenfrog, MonicaMuranyi
 * @version 1.1
 */
public class GeoState extends IdentifiableEntity {

    /**
     * The geography attribute.
     */
    private Geography geography;
    
    /**
     * The defaultDivision attribute.
     */
    private Division defaultDivision;
    
    /**
     * The defaultPdmName attribute.
     */
    private PdmName defaultPdmName;

    /**
     * The name attribute.
     */
    private String name;

    /**
     * <p>
     * The default constructor.
     * </p>
     */
    public GeoState() {
        // Empty
    }

    /**
     * <p>
     * Retrieves the geography field.
     * </p>
     *
     * @return the geography
     */
    public Geography getGeography() {
        return geography;
    }

    /**
     * <p>
     * Sets the value to geography field.
     * </p>
     *
     * @param geography the geography to set
     */
    public void setGeography(Geography geography) {
        this.geography = geography;
    }
    
    /**
     * <p>
     * Retrieves the defaultDivision field.
     * </p>
     *
     * @return the defaultDivision
     */
    public Division getDefaultDivision() {
        return defaultDivision;
    }

    /**
     * <p>
     * Sets the value to defaultDivision field.
     * </p>
     *
     * @param defaultDivision the defaultDivision to set
     */
    public void setDefaultDivision(Division defaultDivision) {
        this.defaultDivision = defaultDivision;
    }
    
    /**
     * <p>
     * Retrieves the defaultPdmName field.
     * </p>
     *
     * @return the defaultPdmName
     */
    public PdmName getDefaultPdmName() {
        return defaultPdmName;
    }

    /**
     * <p>
     * Sets the value to defaultPdmName field.
     * </p>
     *
     * @param defaultPdmName the defaultPdmName to set
     */
    public void setDefaultPdmName(PdmName defaultPdmName) {
        this.defaultPdmName = defaultPdmName;
    }

    /**
     * <p>
     * Retrieves the name field.
     * </p>
     *
     * @return the  name
     */
    public String getName() {
        return name;
    }

    /**
     * <p>
     * Sets the value to name field.
     * </p>
     *
     * @param name the name to set
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * The toString method.
     *
     * @return the string of this entity
     */
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("{").append(super.toString());
        sb.append(", name:").append(name);
        sb.append(", geography:").append(geography);
        sb.append(", defaultDivision:").append(defaultDivision);
        sb.append(", defaultPdmName:").append(defaultPdmName).append("}");
        return sb.toString();
    }

}

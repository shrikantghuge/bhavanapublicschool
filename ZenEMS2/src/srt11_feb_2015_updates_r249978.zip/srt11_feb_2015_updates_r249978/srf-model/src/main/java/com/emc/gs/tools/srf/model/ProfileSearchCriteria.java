/*
 * This code is copyright (c) 2015 EMC Corporation.
 */
package com.emc.gs.tools.srf.model;

/**
 * <p>
 * This is ProfileSearchCriteria entity class.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safety.
 * </p>
 *
 * <p>
 * Version 1.1 Change notes:
 *   <ol>
 *     <li>Added {@link #templateFolderEditor} property.</li>
 *   </ol>
 * </p>
 *
 * <p>
 * Version 1.2 Change notes:
 *   <ol>
 *     <li>Added {@link #divisionId} property.</li>
 *     <li>Removed <code>submitter</code>  property.</li>
 *   </ol>
 * </p>
 * 
 * @author isv, TCSASSEMBLER
 * @version 1.2
 * @since SRT 1.1 Approval Process Assembly
 */
public class ProfileSearchCriteria extends BaseSearchParams {
    /**
     * <p>
     * The userIdentifier.
     * </p>
     */
    private String userIdentifier;

    /**
     * <p>
     * The fullName.
     * </p>
     */
    private String fullName;
    

    /**
     * <p>
     * The approver flag.
     * </p>
     */
    private Boolean approver;

    /**
     * <p>A <code>Boolean</code> providing the value for templateFolderEditor property.</p>
     * 
     * @since 1.1
     */
    private Boolean templateFolderEditor;

    /**
     * <p>A <code>Long</code> providing the value for divisionId property.</p>
     * 
     * @since 1.2
     */
    private Long divisionId;

    /**
     * <p>
     * Retrieves the userIdentifier field.
     * </p>
     *
     * @return the userIdentifier
     */
    public String getUserIdentifier() {
        return userIdentifier;
    }

    /**
     * <p>
     * Sets the value to userIdentifier field.
     * </p>
     *
     * @param userIdentifier
     *            the userIdentifier to set
     */
    public void setUserIdentifier(String userIdentifier) {
        this.userIdentifier = userIdentifier;
    }

    /**
     * <p>
     * Retrieves the fullName field.
     * </p>
     *
     * @return the fullName
     */
    public String getFullName() {
        return fullName;
    }

    /**
     * <p>
     * Sets the value to fullName field.
     * </p>
     *
     * @param fullName
     *            the fullName to set
     */
    public void setFullName(String fullName) {
        this.fullName = fullName;
    }
    
    /**
     * <p>
     * Retrieves the approver field.
     * </p>
     *
     * @return the approver
     */
    public Boolean isApprover() {
        return approver;
    }
    
    /**
     * <p>
     * Sets the value to approver field.
     * </p>
     *
     * @param approver
     *            the approver to set
     */
    public void setApprover(Boolean approver) {
        this.approver = approver;
    }

    /**
     * <p>Gets the templateFolderEditor property.</p>
     *
     * @return a <code>Boolean</code> providing the value for templateFolderEditor property.
     * @since 1.1
     */
    public Boolean getTemplateFolderEditor() {
        return this.templateFolderEditor;
    }

    /**
     * <p>Sets the templateFolderEditor property.</p>
     *
     * @param templateFolderEditor a <code>Boolean</code> providing the value for templateFolderEditor property.
     * @since 1.1
     */
    public void setTemplateFolderEditor(Boolean templateFolderEditor) {
        this.templateFolderEditor = templateFolderEditor;
    }

    /**
     * <p>Gets the divisionId property.</p>
     *
     * @return a <code>Long</code> providing the value for divisionId property.
     * @since 1.2
     */
    public Long getDivisionId() {
        return this.divisionId;
    }

    /**
     * <p>Sets the divisionId property.</p>
     *
     * @param divisionId a <code>Long</code> providing the value for divisionId property.
     * @since 1.2
     */
    public void setDivisionId(Long divisionId) {
        this.divisionId = divisionId;
    }

    /**
     * The toString method.
     *
     * @return the string for this entity
     */
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("{").append(super.toString());
        sb.append(", userIdentifier:").append(userIdentifier);
        sb.append(", fullName:").append(fullName);
        sb.append(", approver:").append(approver);
        sb.append(", templateFolderEditor:").append(templateFolderEditor);
        sb.append(", divisionId:").append(divisionId);
        sb.append("}");
        return sb.toString();
    }
}

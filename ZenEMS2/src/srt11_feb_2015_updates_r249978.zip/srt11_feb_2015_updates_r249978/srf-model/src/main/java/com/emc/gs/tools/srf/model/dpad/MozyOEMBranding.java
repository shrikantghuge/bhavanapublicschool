/*
 * This code is copyright (c) 2014 EMC Corporation
 */
package com.emc.gs.tools.srf.model.dpad;

import com.emc.gs.tools.srf.model.IdentifiableEntity;

import java.math.BigDecimal;

/**
 * <p>This is MozyOEMBranding entity class.</p>
 *
 * <p><strong>Thread safety</strong>: This class is mutable, it is not thread safety.</p>
 *
 * @author TCSASSEMBLER
 * @version 1.0
 * @since SRT Phase 3 Pilot - Mozy and Xtrem and Vipr Tabs Assembly
 */
public class MozyOEMBranding extends IdentifiableEntity {

    /**
     * <p>A <code>BigDecimal</code> providing the hours for client branding.</p>
     */
    private BigDecimal hoursForClientBranding;

    /**
     * <p>A <code>BigDecimal</code> providing the hours for branding admin console.</p>
     */
    private BigDecimal hoursForBrandingAdminConsole;

    /**
     * <p>A <code>BigDecimal</code> providing the hours for web access branding.</p>
     */
    private BigDecimal hoursForWebAccessBranding;

    /**
     * <p>Constructs new <code>MozyOEMBranding</code> instance. This implementation does nothing.</p>
     */
    public MozyOEMBranding() {
    }

    /**
     * <p>Gets the hours for web access branding.</p>
     *
     * @return a <code>BigDecimal</code> providing the hours for web access branding.
     */
    public BigDecimal getHoursForWebAccessBranding() {
        return this.hoursForWebAccessBranding;
    }

    /**
     * <p>Sets the hours for web access branding.</p>
     *
     * @param hoursForWebAccessBranding a <code>BigDecimal</code> providing the hours for web access branding.
     */
    public void setHoursForWebAccessBranding(BigDecimal hoursForWebAccessBranding) {
        this.hoursForWebAccessBranding = hoursForWebAccessBranding;
    }

    /**
     * <p>Gets the hours for branding admin console.</p>
     *
     * @return a <code>BigDecimal</code> providing the hours for branding admin console.
     */
    public BigDecimal getHoursForBrandingAdminConsole() {
        return this.hoursForBrandingAdminConsole;
    }

    /**
     * <p>Sets the hours for branding admin console.</p>
     *
     * @param hoursForBrandingAdminConsole a <code>BigDecimal</code> providing the hours for branding admin console.
     */
    public void setHoursForBrandingAdminConsole(BigDecimal hoursForBrandingAdminConsole) {
        this.hoursForBrandingAdminConsole = hoursForBrandingAdminConsole;
    }

    /**
     * <p>Gets the hours for client branding.</p>
     *
     * @return a <code>BigDecimal</code> providing the hours for client branding.
     */
    public BigDecimal getHoursForClientBranding() {
        return this.hoursForClientBranding;
    }

    /**
     * <p>Sets the hours for client branding.</p>
     *
     * @param hoursForClientBranding a <code>BigDecimal</code> providing the hours for client branding.
     */
    public void setHoursForClientBranding(BigDecimal hoursForClientBranding) {
        this.hoursForClientBranding = hoursForClientBranding;
    }
}

/*
 * This code is copyright (c) 2013 - 2014 EMC Corporation.
 */
package com.emc.gs.tools.srf.model;

import java.util.List;

/**
 * <p>
 * This is SearchResult entity class.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safety.
 * </p>
 *
 * @param <T>
 *            the class type
 * @author faeton, stevenfrog
 * @version 1.0
 */
public class SearchResult<T> extends BaseSearchParams {
    /**
     * <p>
     * The totalItems.
     * </p>
     */
    private int totalItems;

    /**
     * <p>
     * The totalPages.
     * </p>
     */
    private int totalPages;

    /**
     * <p>
     * The values.
     * </p>
     */
    private List<T> values;

    /**
     * <p>
     * The default constructor.
     * </p>
     */
    public SearchResult() {
        // Empty
    }

    /**
     * <p>
     * Retrieves the totalItems field.
     * </p>
     *
     * @return the totalItems
     */
    public int getTotalItems() {
        return totalItems;
    }

    /**
     * <p>
     * Sets the value to totalItems field.
     * </p>
     *
     * @param totalItems
     *            the totalItems to set
     */
    public void setTotalItems(int totalItems) {
        this.totalItems = totalItems;
    }

    /**
     * <p>
     * Retrieves the totalPages field.
     * </p>
     *
     * @return the totalPages
     */
    public int getTotalPages() {
        return totalPages;
    }

    /**
     * <p>
     * Sets the value to totalPages field.
     * </p>
     *
     * @param totalPages
     *            the totalPages to set
     */
    public void setTotalPages(int totalPages) {
        this.totalPages = totalPages;
    }

    /**
     * <p>
     * Retrieves the values field.
     * </p>
     *
     * @return the values
     */
    public List<T> getValues() {
        return values;
    }

    /**
     * <p>
     * Sets the value to values field.
     * </p>
     *
     * @param values
     *            the values to set
     */
    public void setValues(List<T> values) {
        this.values = values;
    }

    /**
     * The toString method.
     *
     * @return the string for this entity
     */
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("{").append(super.toString());
        sb.append(", totalItems:").append(totalItems);
        sb.append(", totalPages:").append(totalPages);
        sb.append(", values:").append(values).append("}");
        return sb.toString();
    }

}

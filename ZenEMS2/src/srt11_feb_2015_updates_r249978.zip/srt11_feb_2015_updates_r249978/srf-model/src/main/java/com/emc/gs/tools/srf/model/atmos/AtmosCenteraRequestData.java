/*
 * This code is copyright (c) 2014 EMC Corporation
 */
package com.emc.gs.tools.srf.model.atmos;

import java.math.BigDecimal;

import com.emc.gs.tools.srf.model.IdentifiableEntity;
import com.emc.gs.tools.srf.model.SitesInvolved;

/**
 * <p>
 * This is AtmosCenteraRequestData entity class.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safety.
 * </p>
 * 
 * @author TCSASSEMBLER
 * @version 1.0
 * @since SRT Phase 3-1 - Atmos Centera and Vblock Tabs Assembly
 */
public class AtmosCenteraRequestData extends IdentifiableEntity {

    /**
     * Do you have a high-level design that shows existing and proposed end state?
     */
    private Boolean haveHighLevelDesign;

    /**
     * # of sites involved.
     */
    private SitesInvolved sitesInvolved;

    /**
     * # days of knowledge transfer.
     */
    private BigDecimal daysOfKnowledgeTransfer;

    /**
     * Does the customer currently have Centera frames onsite?
     */
    private Boolean customerHasCentera;

    /**
     * General Comment.
     */
    private String generalComment;

    /**
     * Services scope.
     */
    private AtmosCenteraServicesScope servicesScope;

    /**
     * ATMOS Design & Implementation.
     */
    private AtmosDesignImpl atmosDesignImpl;

    /**
     * Centera Design & Implementation.
     */
    private CenteraDesignImpl centeraDesignImpl;

    /**
     * Centera to ATMOS Data Migration.
     */
    private CenteraToAtmosMigration centeraToAtmosMigration;

    /**
     * Centera Universal Access.
     */
    private CenteraUniversalAccess centeraUniversalAccess;

    /**
     * Centera Intra Cluster Migration CICM.
     */
    private CenteraIntraClusterMigration centeraIntraClusterMigration;

    /**
     * Centera File Erasure.
     */
    private CenteraFileErasure centeraFileErasure;

    /**
     * Expansion Node Only.
     */
    private ExpansionNodeOnly expansionNodeOnly;

    /**
     * <p>
     * The default constructor.
     * </p>
     */
    public AtmosCenteraRequestData() {
    }

    /**
     * Getter method for property <tt>haveHighLevelDesign</tt>.
     * 
     * @return property value of haveHighLevelDesign
     */
    public Boolean getHaveHighLevelDesign() {
        return haveHighLevelDesign;
    }

    /**
     * Setter method for property <tt>haveHighLevelDesign</tt>.
     * 
     * @param haveHighLevelDesign
     *            value to be assigned to property haveHighLevelDesign
     */
    public void setHaveHighLevelDesign(Boolean haveHighLevelDesign) {
        this.haveHighLevelDesign = haveHighLevelDesign;
    }

    /**
     * Getter method for property <tt>sitesInvolved</tt>.
     * 
     * @return property value of sitesInvolved
     */
    public SitesInvolved getSitesInvolved() {
        return sitesInvolved;
    }

    /**
     * Setter method for property <tt>sitesInvolved</tt>.
     * 
     * @param sitesInvolved
     *            value to be assigned to property sitesInvolved
     */
    public void setSitesInvolved(SitesInvolved sitesInvolved) {
        this.sitesInvolved = sitesInvolved;
    }

    /**
     * Getter method for property <tt>daysOfKnowledgeTransfer</tt>.
     * 
     * @return property value of daysOfKnowledgeTransfer
     */
    public BigDecimal getDaysOfKnowledgeTransfer() {
        return daysOfKnowledgeTransfer;
    }

    /**
     * Setter method for property <tt>daysOfKnowledgeTransfer</tt>.
     * 
     * @param daysOfKnowledgeTransfer
     *            value to be assigned to property daysOfKnowledgeTransfer
     */
    public void setDaysOfKnowledgeTransfer(BigDecimal daysOfKnowledgeTransfer) {
        this.daysOfKnowledgeTransfer = daysOfKnowledgeTransfer;
    }

    /**
     * Getter method for property <tt>customerHasCentera</tt>.
     * 
     * @return property value of customerHasCentera
     */
    public Boolean getCustomerHasCentera() {
        return customerHasCentera;
    }

    /**
     * Setter method for property <tt>customerHasCentera</tt>.
     * 
     * @param customerHasCentera
     *            value to be assigned to property customerHasCentera
     */
    public void setCustomerHasCentera(Boolean customerHasCentera) {
        this.customerHasCentera = customerHasCentera;
    }

    /**
     * Getter method for property <tt>generalComment</tt>.
     * 
     * @return property value of generalComment
     */
    public String getGeneralComment() {
        return generalComment;
    }

    /**
     * Setter method for property <tt>generalComment</tt>.
     * 
     * @param generalComment
     *            value to be assigned to property generalComment
     */
    public void setGeneralComment(String generalComment) {
        this.generalComment = generalComment;
    }

    /**
     * Getter method for property <tt>servicesScope</tt>.
     * 
     * @return property value of servicesScope
     */
    public AtmosCenteraServicesScope getServicesScope() {
        return servicesScope;
    }

    /**
     * Setter method for property <tt>servicesScope</tt>.
     * 
     * @param servicesScope
     *            value to be assigned to property servicesScope
     */
    public void setServicesScope(AtmosCenteraServicesScope servicesScope) {
        this.servicesScope = servicesScope;
    }

    /**
     * Getter method for property <tt>atmosDesignImpl</tt>.
     * 
     * @return property value of atmosDesignImpl
     */
    public AtmosDesignImpl getAtmosDesignImpl() {
        return atmosDesignImpl;
    }

    /**
     * Setter method for property <tt>atmosDesignImpl</tt>.
     * 
     * @param atmosDesignImpl
     *            value to be assigned to property atmosDesignImpl
     */
    public void setAtmosDesignImpl(AtmosDesignImpl atmosDesignImpl) {
        this.atmosDesignImpl = atmosDesignImpl;
    }

    /**
     * Getter method for property <tt>centeraDesignImpl</tt>.
     * 
     * @return property value of centeraDesignImpl
     */
    public CenteraDesignImpl getCenteraDesignImpl() {
        return centeraDesignImpl;
    }

    /**
     * Setter method for property <tt>centeraDesignImpl</tt>.
     * 
     * @param centeraDesignImpl
     *            value to be assigned to property centeraDesignImpl
     */
    public void setCenteraDesignImpl(CenteraDesignImpl centeraDesignImpl) {
        this.centeraDesignImpl = centeraDesignImpl;
    }

    /**
     * Getter method for property <tt>centeraToAtmosMigration</tt>.
     * 
     * @return property value of centeraToAtmosMigration
     */
    public CenteraToAtmosMigration getCenteraToAtmosMigration() {
        return centeraToAtmosMigration;
    }

    /**
     * Setter method for property <tt>centeraToAtmosMigration</tt>.
     * 
     * @param centeraToAtmosMigration
     *            value to be assigned to property centeraToAtmosMigration
     */
    public void setCenteraToAtmosMigration(CenteraToAtmosMigration centeraToAtmosMigration) {
        this.centeraToAtmosMigration = centeraToAtmosMigration;
    }

    /**
     * Getter method for property <tt>centeraFileErasure</tt>.
     * 
     * @return property value of centeraFileErasure
     */
    public CenteraFileErasure getCenteraFileErasure() {
        return centeraFileErasure;
    }

    /**
     * Setter method for property <tt>centeraFileErasure</tt>.
     * 
     * @param centeraFileErasure
     *            value to be assigned to property centeraFileErasure
     */
    public void setCenteraFileErasure(CenteraFileErasure centeraFileErasure) {
        this.centeraFileErasure = centeraFileErasure;
    }

    /**
     * Getter method for property <tt>centeraUniversalAccess</tt>.
     * 
     * @return property value of centeraUniversalAccess
     */
    public CenteraUniversalAccess getCenteraUniversalAccess() {
        return centeraUniversalAccess;
    }

    /**
     * Setter method for property <tt>centeraUniversalAccess</tt>.
     * 
     * @param centeraUniversalAccess
     *            value to be assigned to property centeraUniversalAccess
     */
    public void setCenteraUniversalAccess(CenteraUniversalAccess centeraUniversalAccess) {
        this.centeraUniversalAccess = centeraUniversalAccess;
    }

    /**
     * Getter method for property <tt>centeraIntraClusterMigration</tt>.
     * 
     * @return property value of centeraIntraClusterMigration
     */
    public CenteraIntraClusterMigration getCenteraIntraClusterMigration() {
        return centeraIntraClusterMigration;
    }

    /**
     * Setter method for property <tt>centeraIntraClusterMigration</tt>.
     * 
     * @param centeraIntraClusterMigration
     *            value to be assigned to property centeraIntraClusterMigration
     */
    public void setCenteraIntraClusterMigration(CenteraIntraClusterMigration centeraIntraClusterMigration) {
        this.centeraIntraClusterMigration = centeraIntraClusterMigration;
    }

    /**
     * Getter method for property <tt>expansionNodeOnly</tt>.
     * 
     * @return property value of expansionNodeOnly
     */
    public ExpansionNodeOnly getExpansionNodeOnly() {
        return expansionNodeOnly;
    }

    /**
     * Setter method for property <tt>expansionNodeOnly</tt>.
     * 
     * @param expansionNodeOnly
     *            value to be assigned to property expansionNodeOnly
     */
    public void setExpansionNodeOnly(ExpansionNodeOnly expansionNodeOnly) {
        this.expansionNodeOnly = expansionNodeOnly;
    }

}

/*
 * This code is copyright (c) 2014 EMC Corporation
 */
package com.emc.gs.tools.srf.model.dpad;

import com.emc.gs.tools.srf.model.IdentifiableEntity;

/**
 * <p> This is NetworkerImplementation entity class.</p>
 * 
 * <p><strong>Thread safety</strong>: This class is mutable, it is not thread safe.</p>
 *
 * <p> Version 1.1 (SRT 4 OCT2014 Updates Part 1 Assembly) Change notes: 
 *   <ol> 
 *     <li>Removed <code>server</code> property.</li>
 *     <li>Removed <code>advancedBackupTech</code> property.</li>
 *     <li>Removed <code>fileSystemClientBackups</code> property.</li>
 *     <li>Removed <code>fileSystemClientBackups</code> property.</li>
 *     <li>Added {@link #selectDataZoneSize} property.</li>
 *     <li>Added {@link #dataZoneSize} property.</li>
 *   </ol>
 * </p>
 *
 * @author isv
 * @version 1.1
 * @since SRT Phase 3-5 - BRS Tabs Part 3 Assembly
 */
public class NetworkerImplementation extends IdentifiableEntity {

    /**
     * <p>A <code>Boolean</code> providing the value for "Select the size of Networker Datazone?" property.</p>
     *
     * @since 1.1
     */
    private Boolean selectDataZoneSize;

    /**
     * <p>A <code>NetworkerDatazoneSize</code> providing the value for dataZoneSize property.</p>
     * 
     * @since 1.1
     */
    private NetworkerDatazoneSize dataZoneSize;

    /**
     * <p> The default constructor. </p>
     */
    public NetworkerImplementation() {
    }

    /**
     * <p>Gets the dataZoneSize property.</p>
     *
     * @return a <code>NetworkerDatazoneSize</code> providing the value for dataZoneSize property.
     * @since 1.1
     */
    public NetworkerDatazoneSize getDataZoneSize() {
        return this.dataZoneSize;
    }

    /**
     * <p>Sets the dataZoneSize property.</p>
     *
     * @param dataZoneSize a <code>NetworkerDatazoneSize</code> providing the value for dataZoneSize property.
     * @since 1.1
     */
    public void setDataZoneSize(NetworkerDatazoneSize dataZoneSize) {
        this.dataZoneSize = dataZoneSize;
    }

    /**
     * <p>Gets the "Select the size of Networker Datazone?" property.</p>
     *
     * @return a <code>Boolean</code> providing the value for "Select the size of Networker Datazone?" property.
     * @since 1.1
     */
    public Boolean getSelectDataZoneSize() {
        return this.selectDataZoneSize;
    }

    /**
     * <p>Sets the "Select the size of Networker Datazone?" property.</p>
     *
     * @param selectDataZoneSize a <code>Boolean</code> providing the value for "Select the size of Networker Datazone?"
     * property.
     * @since 1.1
     */
    public void setSelectDataZoneSize(Boolean selectDataZoneSize) {
        this.selectDataZoneSize = selectDataZoneSize;
    }
}

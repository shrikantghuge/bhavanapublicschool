/*
 * This code is copyright (c) 2014 EMC Corporation
 */
package com.emc.gs.tools.srf.model.asd;

import com.emc.gs.tools.srf.model.IdentifiableEntity;

/**
 * <p>
 * This is ASDRequestData entity class.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safety.
 * </p>
 * <p>
 * 
 * @author TCSASSEMBLER
 * @version 1.0
 * @since SRT Phase 3-4 - ASD and Healthcheck Tabs Assembly
 */
public class ASDRequestData extends IdentifiableEntity {

    /**
     * General comment.
     */
    private String generalComment;

    /**
     * ASD Services scope.
     */
    private ASDServicesScope servicesScope;

    /**
     * ASD AppSync.
     */
    private ASDAppSync appSync;

    /**
     * ASD UIM.
     */
    private ASDUIM uim;

    /**
     * <p>
     * The default constructor.
     * </p>
     */
    public ASDRequestData() {
    }

    /**
     * Getter method for property <tt>generalComment</tt>.
     * 
     * @return property value of generalComment
     */
    public String getGeneralComment() {
        return generalComment;
    }

    /**
     * Setter method for property <tt>generalComment</tt>.
     * 
     * @param generalComment
     *            value to be assigned to property generalComment
     */
    public void setGeneralComment(String generalComment) {
        this.generalComment = generalComment;
    }

    /**
     * Getter method for property <tt>servicesScope</tt>.
     * 
     * @return property value of servicesScope
     */
    public ASDServicesScope getServicesScope() {
        return servicesScope;
    }

    /**
     * Setter method for property <tt>servicesScope</tt>.
     * 
     * @param servicesScope
     *            value to be assigned to property servicesScope
     */
    public void setServicesScope(ASDServicesScope servicesScope) {
        this.servicesScope = servicesScope;
    }

    /**
     * Getter method for property <tt>appSync</tt>.
     * 
     * @return property value of appSync
     */
    public ASDAppSync getAppSync() {
        return appSync;
    }

    /**
     * Setter method for property <tt>appSync</tt>.
     * 
     * @param appSync
     *            value to be assigned to property appSync
     */
    public void setAppSync(ASDAppSync appSync) {
        this.appSync = appSync;
    }

    /**
     * Getter method for property <tt>uim</tt>.
     * 
     * @return property value of uim
     */
    public ASDUIM getUim() {
        return uim;
    }

    /**
     * Setter method for property <tt>uim</tt>.
     * 
     * @param uim
     *            value to be assigned to property uim
     */
    public void setUim(ASDUIM uim) {
        this.uim = uim;
    }

}

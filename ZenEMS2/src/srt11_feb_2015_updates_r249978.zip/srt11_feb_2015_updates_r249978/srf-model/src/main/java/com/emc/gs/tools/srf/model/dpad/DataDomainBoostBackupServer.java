/*
 * This code is copyright (c) 2014 EMC Corporation
 */
package com.emc.gs.tools.srf.model.dpad;

import com.emc.gs.tools.srf.model.IdentifiableEntity;

/**
 * <p>
 * This is DataDomainBoostBackupServer entity class.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safety.
 * </p>
 *
 * <p>
 * Version 1.1 Change notes:
 *   <ol>
 *     <li>Added {@link #ddbda} property.</li>
 *     <li>Added {@link #ddbma} property.</li>
 *   </ol>
 * </p>
 * 
 * @author TCSASSEMBLER
 * @version 1.1
 * @since SRT Phase 3-5 - BRS Tabs Part 2 Assembly
 */
public class DataDomainBoostBackupServer extends IdentifiableEntity {

    /**
     * Represents whether NBU server is selected.
     */
    private boolean nbu;

    /**
     * Represents whether RMAN server is selected.
     */
    private boolean rman;

    /**
     * <p>A <code>boolean</code> providing the value for ddbda property.</p>
     * 
     * @since 1.1
     */
    private boolean ddbda;

    /**
     * <p>A <code>boolean</code> providing the value for ddbma property.</p>
     *
     * @since 1.1
     */
    private boolean ddbma;

    /**
     * <p>
     * The default constructor.
     * </p>
     */
    public DataDomainBoostBackupServer() {
    }

    /**
     * Getter method for property <tt>nbu</tt>.
     * 
     * @return property value of nbu
     */
    public boolean isNbu() {
        return nbu;
    }

    /**
     * Setter method for property <tt>nbu</tt>.
     * 
     * @param nbu
     *            value to be assigned to property nbu
     */
    public void setNbu(boolean nbu) {
        this.nbu = nbu;
    }

    /**
     * Getter method for property <tt>rman</tt>.
     * 
     * @return property value of rman
     */
    public boolean isRman() {
        return rman;
    }

    /**
     * Setter method for property <tt>rman</tt>.
     * 
     * @param rman
     *            value to be assigned to property rman
     */
    public void setRman(boolean rman) {
        this.rman = rman;
    }

    /**
     * <p>Gets the ddbma property.</p>
     *
     * @return a <code>boolean</code> providing the value for ddbma property.
     * @since 1.1
     */
    public boolean getDdbma() {
        return this.ddbma;
    }

    /**
     * <p>Sets the ddbma property.</p>
     *
     * @param ddbma a <code>boolean</code> providing the value for ddbma property.
     * @since 1.1
     */
    public void setDdbma(boolean ddbma) {
        this.ddbma = ddbma;
    }

    /**
     * <p>Gets the ddbda property.</p>
     *
     * @return a <code>boolean</code> providing the value for ddbda property.
     * @since 1.1
     */
    public boolean getDdbda() {
        return this.ddbda;
    }

    /**
     * <p>Sets the ddbda property.</p>
     *
     * @param ddbda a <code>boolean</code> providing the value for ddbda property.
     * @since 1.1
     */
    public void setDdbda(boolean ddbda) {
        this.ddbda = ddbda;
    }

}

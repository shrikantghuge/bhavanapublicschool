/*
 * This code is copyright (c) 2014 EMC Corporation.
 */
package com.emc.gs.tools.srf.model;

/**
 * <p>
 * This is the ServiceContext class. It stores the currently logged in user.
 * It is populated and cleared by ServiceContextInterceptor.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class effectively thread safe by using the thread-local.
 * </p>
 *
 * <p>
 * <strong>Changes V1.1:</strong>
 * <strong>SRT Phase 4 - ET Assembly 2</strong>
 * <ul>
 * <li>Change the thread-local to store ServiceContext bean.</li>
 * </ul>
 * </p>
 *
 * @author zsudraco, TCSASSEMBLER
 * @version 1.1
 * @since SRT Cloud Synchronization - Cloud App Assembly
 */
public class ServiceContext {

    /**
     * <p>
     * The thread-local is used to store the current context.
     * </p>
     * @since SRT Phase 4 - ET Assembly 2
     */
    private static final ThreadLocal<ServiceContext> contextThreadLocal = new ThreadLocal<ServiceContext>();

    /**
     * The user.
     */
    private User user;

    /**
     * The operation log from other side to synchronize.
     * On cloud side, it represents the operation log from local side.
     * On local side, it represents the operation log from cloud side.
     * @since SRT Phase 4 - ET Assembly 2
     */
    private OperationLog operationLog;

    /**
     * <p>
     * The private default constructor.
     * </p>
     */
    private ServiceContext() {
        // empty
    }

    /**
     * <p>
     * Retrieves the currently logged in user.
     * </p>
     *
     * @return the current user
     */
    public static User getCurrentUser() {
        ServiceContext context = contextThreadLocal.get();
        return context == null ? null : context.user;
    }

    /**
     * <p>
     * Sets the currently logged in user.
     * </p>
     *
     * @param user the user to set
     */
    public static void setCurrentUser(User user) {
        getServiceContext().user = user;
    }

    /**
     * Get current context, if not present then create it.
     * 
     * @return current context, never null.
     */
    private static ServiceContext getServiceContext() {

        ServiceContext context = contextThreadLocal.get();
        if (context == null) {
            context = new ServiceContext();
            contextThreadLocal.set(context);
        }
        return context;
    }

    /**
     * <p>
     * Gets the current operation log from other side to synchronize.
     * </p>
     *
     * @return the current operation log from other side to synchronize
     * @since SRT Phase 4 - ET Assembly 2
     */
    public static OperationLog getCurrentOperationLog() {
        ServiceContext context = contextThreadLocal.get();
        return context == null ? null : context.operationLog;
    }

    /**
     * <p>
     * Sets the current operation log from other side to synchronize.
     * </p>
     *
     * @param operationLogToSync the current operation log from other side to synchronize
     * @since SRT Phase 4 - ET Assembly 2
     */
    public static void setCurrentOperationLog(OperationLog operationLog) {
        getServiceContext().operationLog = operationLog;
    }

    /**
     * Clear the service context.
     * @since SRT Phase 4 - ET Assembly 2
     */
    public static void clear() {
        contextThreadLocal.remove();
    }
}

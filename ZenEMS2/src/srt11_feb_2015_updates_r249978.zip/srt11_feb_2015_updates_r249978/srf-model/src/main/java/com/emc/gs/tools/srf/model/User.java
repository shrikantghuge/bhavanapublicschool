/*
 * This code is copyright (c) 2014 - 2015 EMC Corporation.
 */
package com.emc.gs.tools.srf.model;

/**
 * <p>
 * This is the User entity class.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safe.
 * </p>
 *
 * <p>
 * Version 1.1 Change notes:
 *   <ol>
 *     <li>Added {@link #jobTitle} property.</li>
 *     <li>Added {@link #country} property.</li>
 *   </ol>
 * </p>
 *
 * <p>
 * Changes in version 1.2 (SRT 1.1 FEB 2015 Updates - Template Folder Assembly):
 * <ul>
 * <li>Added {@link #templatePermission} property.</li>
 * </ul>
 * <p>
 * 
 * <p>
 * <strong>Changes V1.3:</strong>
 * <strong>SRT 1.1 Approval Process Assembly</strong>
 * <ul>
 * <li>Added {@link #submitter} transient property.</li>
 * <li>Added {@link #approver} transient property.</li>
 * <li>Added {@link #userManagementPermission} transient property.</li>
 * </ul>
 * </p>
 *
 * <p>
 * Version 1.4 Change notes:
 *   <ol>
 *     <li>Removed <code>submitter</code> property. All uses who are not approvers are treated as submitters.</li>
 *   </ol>
 * </p>
 * 
 * @author zsudraco, isv, duxiaoyang, TCSASSEMBLER
 * @version 1.4
 * @since SRT Cloud Synchronization - Cloud App Assembly
 */
public class User extends IdentifiableEntity {

    /**
     * <p>
     * The user identifier.
     * </p>
     */
    private String userIdentifier;

    /**
     * <p>
     * The first name.
     * </p>
     */
    private String firstName;

    /**
     * <p>
     * The last name.
     * </p>
     */
    private String lastName;

    /**
     * <p>
     * The email address.
     * </p>
     */
    private String email;

    /**
     * <p>A <code>String</code> providing the value for jobTitle property.</p>
     * @since 1.1
     */
    private String jobTitle;

    /**
     * <p>A <code>String</code> providing the value for country property.</p>
     * @since 1.1
     */
    private String country;

    /**
     * <p>A <code>boolean</code> providing the value for template permission property.</p>
     * @since 1.2
     */
    private boolean templatePermission;
    
    /**
     * <p>A <code>boolean</code> providing the value for approver permission property.</p>
     * @since 1.3
     */
    private boolean approver;
    
    /**
     * <p>A <code>boolean</code> providing the value for user management permission property.</p>
     * @since 1.3
     */
    private boolean userManagementPermission;

    /**
     * <p>
     * The default constructor.
     * </p>
     */
    public User() {
        // empty
    }

    /**
     * <p>
     * Retrieves the userIdentifier field.
     * </p>
     *
     * @return the userIdentifier
     */
    public String getUserIdentifier() {
        return userIdentifier;
    }

    /**
     * <p>
     * Sets the value to userIdentifier field.
     * </p>
     *
     * @param userIdentifier the userIdentifier to set
     */
    public void setUserIdentifier(String userIdentifier) {
        this.userIdentifier = userIdentifier;
    }

    /**
     * <p>
     * Retrieves the firstName field.
     * </p>
     *
     * @return the firstName
     */
    public String getFirstName() {
        return firstName;
    }

    /**
     * <p>
     * Sets the value to firstName field.
     * </p>
     *
     * @param firstName the firstName to set
     */
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    /**
     * <p>
     * Retrieves the lastName field.
     * </p>
     *
     * @return the lastName
     */
    public String getLastName() {
        return lastName;
    }

    /**
     * <p>
     * Sets the value to lastName field.
     * </p>
     *
     * @param lastName the lastName to set
     */
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    /**
     * <p>
     * Retrieves the email field.
     * </p>
     *
     * @return the email
     */
    public String getEmail() {
        return email;
    }

    /**
     * <p>
     * Sets the value to email field.
     * </p>
     *
     * @param email the email to set
     */
    public void setEmail(String email) {
        this.email = email;
    }

    /**
     * <p>Gets the country property.</p>
     *
     * @return a <code>String</code> providing the value for country property.
     * @since 1.1
     */
    public String getCountry() {
        return this.country;
    }

    /**
     * <p>Sets the country property.</p>
     *
     * @param country a <code>String</code> providing the value for country property.
     * @since 1.1
     */
    public void setCountry(String country) {
        this.country = country;
    }

    /**
     * <p>Gets the jobTitle property.</p>
     *
     * @return a <code>String</code> providing the value for jobTitle property.
     * @since 1.1
     */
    public String getJobTitle() {
        return this.jobTitle;
    }

    /**
     * <p>Sets the jobTitle property.</p>
     *
     * @param jobTitle a <code>String</code> providing the value for jobTitle property.
     * @since 1.1
     */
    public void setJobTitle(String jobTitle) {
        this.jobTitle = jobTitle;
    }

    /**
     * <p>Gets the templatePermission property.</p>
     *
     * @return a <code>boolean</code> providing the value for templatePermission property.
     * @since 1.2
     */
    public boolean isTemplatePermission() {
        return templatePermission;
    }

    /**
     * <p>Sets the templatePermission property.<p>
     *
     * @param templatePermission a <code>boolean</code> providing the value for templatePermission property.
     * @since 1.2
     */
    public void setTemplatePermission(boolean templatePermission) {
        this.templatePermission = templatePermission;
    }

    /**
     * <p>Checks if this user is a submitter. All users who are not granted <code>Approver</code> role are treated as
     * submitters.</p>
     *
     * @return a <code>true</code> if user is submitter; <code>false</code> otherwise.
     * @since 1.3
     */
    public boolean isSubmitter() {
        return !isApprover();
    }
    
    /**
     * <p>Gets the approver property.</p>
     *
     * @return a <code>boolean</code> providing the value for approver property.
     * @since 1.3
     */
    public boolean isApprover() {
        return approver;
    }

    /**
     * <p>Sets the approver property.<p>
     *
     * @param approver a <code>boolean</code> providing the value for approver property.
     * @since 1.3
     */
    public void setApprover(boolean approver) {
        this.approver = approver;
    }

    /**
     * <p>Gets the userManagementPermission property.</p>
     *
     * @return a <code>boolean</code> providing the value for userManagementPermission property.
     * @since 1.3
     */
    public boolean isUserManagementPermission() {
        return userManagementPermission;
    }

    /**
     * <p>Sets the userManagementPermission property.<p>
     *
     * @param userManagementPermission a <code>boolean</code> providing the value for userManagementPermission property.
     * @since 1.3
     */
    public void setUserManagementPermission(boolean userManagementPermission) {
        this.userManagementPermission = userManagementPermission;
    }
}

/*
 * This code is copyright (c) 2014 EMC Corporation
 */
package com.emc.gs.tools.srf.model.asd;

import java.math.BigDecimal;

import com.emc.gs.tools.srf.model.IdentifiableEntity;

/**
 * <p>
 * This is ASDUIM entity class.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safety.
 * </p>
 * <p>
 * 
 * @author TCSASSEMBLER
 * @version 1.0
 * @since SRT Phase 3-4 - ASD and Healthcheck Tabs Assembly
 */
public class ASDUIM extends IdentifiableEntity {

    /**
     * Install Type?
     */
    private UIMType installType;

    /**
     * Upgrade Type?
     */
    private UIMType upgradeType;

    /**
     * Include Remote OS Install Agent?
     */
    private Boolean includeRemoteInstallAgent;

    /**
     * # of Remote Install Agents?
     */
    private Integer remoteInstallAgentsNum;

    /**
     * # of UIM / Provisioning vApps to Install.
     */
    private Integer uimProvisioningVAppsNum;

    /**
     * # of Isolation Zones to Add.
     */
    private Integer isolationZonesNum;

    /**
     * Include integration with VMware vCenter Orchestrator (vCO)?
     */
    private Boolean includeVCO;

    /**
     * Total # of vCenter Instances to Add.
     */
    private Integer vcenterInstancesNum;

    /**
     * # of UIM / Provisioning version 3.x Servers to Upgrade.
     */
    private Integer uimProvisioningServersNum;

    /**
     * # of vCloud Director Instances to Add.
     */
    private Integer vcloudDirectorInstancesNum;

    /**
     * # of Converged Hardware Systems to Discover by UIM / Provisioning.
     */
    private Integer convergedHardwareSystemsNum;

    /**
     * # of Blade and Storage Grades to Add and Assign to Pools.
     */
    private Integer bladeStorageGradesNum;

    /**
     * # of Identity (UUID, MAC, IP, WWNN, WWPN) Pools to Add.
     */
    private Integer identityPoolsNum;

    /**
     * # of Network Profiles to Set.
     */
    private Integer networkProfilesNum;

    /**
     * # of UIM / Operations vApps to Install.
     */
    private Integer uimOperationsVAppsNum;

    /**
     * # of Service Offerings to Create.
     */
    private Integer serviceOfferingsToCreateNum;

    /**
     * # of Services to Create.
     */
    private Integer servicesToCreateNum;

    /**
     * # of Blades to Provision.
     */
    private Integer bladesToProvisionNum;

    /**
     * # of LUNs (block/RDM/File) to Provision.
     */
    private Integer lunsToProvisionNum;

    /**
     * # of Services to Provision with OS Install.
     */
    private Integer servicesToProvisionNum;

    /**
     * # of Data Sources added to UIM / Operations.
     */
    private Integer dataSourcesNum;

    /**
     * # of SNMP Alerts and/or Syslogs Forwarding Setup to External Management Systems.
     */
    private Integer snmpAlertsNum;

    /**
     * # of UIM Operations Servers to Upgrade from 3.x.
     */
    private Integer uimOperationsServersNum;

    /**
     * # of UIM / Operations Users to Create.
     */
    private Integer uimOperationsUsersNum;

    /**
     * Perform Elastic Provisioning?
     */
    private Boolean performElasticProvisioning;

    /**
     * # of Services Requiring Elastic Operations.
     */
    private Integer servicesRequiringElasticOperationsNum;

    /**
     * # of Blades Impacted by vNIC Elastic Operations.
     */
    private Integer bladesImpactedNum;

    /**
     * Migrate Services from non-UIM Converged Hardware Systems to UIM management?
     */
    private Boolean migrateServices;

    /**
     * # of non-UIM Converged Hardware Systems adopted/migrated to UIM.
     */
    private Integer nonUIMConvergedHardwareSystemsNum;

    /**
     * # of Services From non-UIM Converged Hardware Systems Adopted/Migrated to UIM.
     */
    private Integer servicesAdoptedMigratedNum;

    /**
     * # of Blades Adopted/Migrated.
     */
    private Integer bladesAdoptedMigratedNum;

    /**
     * Is the Customer Known to be Difficult to Meet UIM Pre-install Requirements.
     */
    private Boolean customerKnown;

    /**
     * # of Hours to remediate UIM pre-install issues.
     */
    private BigDecimal remediateHours;

    /**
     * # of Hours for Additional Knowledge Transfer (SA effort)?
     */
    private BigDecimal saKnowledgeTransferHours;

    /**
     * # of Hours for Additional Knowledge Transfer (IS effort)?
     */
    private BigDecimal isKnowledgeTransferHours;

    /**
     * <p>
     * The default constructor.
     * </p>
     */
    public ASDUIM() {
    }

    /**
     * Getter method for property <tt>installType</tt>.
     * 
     * @return property value of installType
     */
    public UIMType getInstallType() {
        return installType;
    }

    /**
     * Setter method for property <tt>installType</tt>.
     * 
     * @param installType
     *            value to be assigned to property installType
     */
    public void setInstallType(UIMType installType) {
        this.installType = installType;
    }

    /**
     * Getter method for property <tt>upgradeType</tt>.
     * 
     * @return property value of upgradeType
     */
    public UIMType getUpgradeType() {
        return upgradeType;
    }

    /**
     * Setter method for property <tt>upgradeType</tt>.
     * 
     * @param upgradeType
     *            value to be assigned to property upgradeType
     */
    public void setUpgradeType(UIMType upgradeType) {
        this.upgradeType = upgradeType;
    }

    /**
     * Getter method for property <tt>includeRemoteInstallAgent</tt>.
     * 
     * @return property value of includeRemoteInstallAgent
     */
    public Boolean getIncludeRemoteInstallAgent() {
        return includeRemoteInstallAgent;
    }

    /**
     * Setter method for property <tt>includeRemoteInstallAgent</tt>.
     * 
     * @param includeRemoteInstallAgent
     *            value to be assigned to property includeRemoteInstallAgent
     */
    public void setIncludeRemoteInstallAgent(Boolean includeRemoteInstallAgent) {
        this.includeRemoteInstallAgent = includeRemoteInstallAgent;
    }

    /**
     * Getter method for property <tt>remoteInstallAgentsNum</tt>.
     * 
     * @return property value of remoteInstallAgentsNum
     */
    public Integer getRemoteInstallAgentsNum() {
        return remoteInstallAgentsNum;
    }

    /**
     * Setter method for property <tt>remoteInstallAgentsNum</tt>.
     * 
     * @param remoteInstallAgentsNum
     *            value to be assigned to property remoteInstallAgentsNum
     */
    public void setRemoteInstallAgentsNum(Integer remoteInstallAgentsNum) {
        this.remoteInstallAgentsNum = remoteInstallAgentsNum;
    }

    /**
     * Getter method for property <tt>uimProvisioningVAppsNum</tt>.
     * 
     * @return property value of uimProvisioningVAppsNum
     */
    public Integer getUimProvisioningVAppsNum() {
        return uimProvisioningVAppsNum;
    }

    /**
     * Setter method for property <tt>uimProvisioningVAppsNum</tt>.
     * 
     * @param uimProvisioningVAppsNum
     *            value to be assigned to property uimProvisioningVAppsNum
     */
    public void setUimProvisioningVAppsNum(Integer uimProvisioningVAppsNum) {
        this.uimProvisioningVAppsNum = uimProvisioningVAppsNum;
    }

    /**
     * Getter method for property <tt>isolationZonesNum</tt>.
     * 
     * @return property value of isolationZonesNum
     */
    public Integer getIsolationZonesNum() {
        return isolationZonesNum;
    }

    /**
     * Setter method for property <tt>isolationZonesNum</tt>.
     * 
     * @param isolationZonesNum
     *            value to be assigned to property isolationZonesNum
     */
    public void setIsolationZonesNum(Integer isolationZonesNum) {
        this.isolationZonesNum = isolationZonesNum;
    }

    /**
     * Getter method for property <tt>includeVCO</tt>.
     * 
     * @return property value of includeVCO
     */
    public Boolean getIncludeVCO() {
        return includeVCO;
    }

    /**
     * Setter method for property <tt>includeVCO</tt>.
     * 
     * @param includeVCO
     *            value to be assigned to property includeVCO
     */
    public void setIncludeVCO(Boolean includeVCO) {
        this.includeVCO = includeVCO;
    }

    /**
     * Getter method for property <tt>vcenterInstancesNum</tt>.
     * 
     * @return property value of vcenterInstancesNum
     */
    public Integer getVcenterInstancesNum() {
        return vcenterInstancesNum;
    }

    /**
     * Setter method for property <tt>vcenterInstancesNum</tt>.
     * 
     * @param vcenterInstancesNum
     *            value to be assigned to property vcenterInstancesNum
     */
    public void setVcenterInstancesNum(Integer vcenterInstancesNum) {
        this.vcenterInstancesNum = vcenterInstancesNum;
    }

    /**
     * Getter method for property <tt>uimProvisioningServersNum</tt>.
     * 
     * @return property value of uimProvisioningServersNum
     */
    public Integer getUimProvisioningServersNum() {
        return uimProvisioningServersNum;
    }

    /**
     * Setter method for property <tt>uimProvisioningServersNum</tt>.
     * 
     * @param uimProvisioningServersNum
     *            value to be assigned to property uimProvisioningServersNum
     */
    public void setUimProvisioningServersNum(Integer uimProvisioningServersNum) {
        this.uimProvisioningServersNum = uimProvisioningServersNum;
    }

    /**
     * Getter method for property <tt>vcloudDirectorInstancesNum</tt>.
     * 
     * @return property value of vcloudDirectorInstancesNum
     */
    public Integer getVcloudDirectorInstancesNum() {
        return vcloudDirectorInstancesNum;
    }

    /**
     * Setter method for property <tt>vcloudDirectorInstancesNum</tt>.
     * 
     * @param vcloudDirectorInstancesNum
     *            value to be assigned to property vcloudDirectorInstancesNum
     */
    public void setVcloudDirectorInstancesNum(Integer vcloudDirectorInstancesNum) {
        this.vcloudDirectorInstancesNum = vcloudDirectorInstancesNum;
    }

    /**
     * Getter method for property <tt>convergedHardwareSystemsNum</tt>.
     * 
     * @return property value of convergedHardwareSystemsNum
     */
    public Integer getConvergedHardwareSystemsNum() {
        return convergedHardwareSystemsNum;
    }

    /**
     * Setter method for property <tt>convergedHardwareSystemsNum</tt>.
     * 
     * @param convergedHardwareSystemsNum
     *            value to be assigned to property convergedHardwareSystemsNum
     */
    public void setConvergedHardwareSystemsNum(Integer convergedHardwareSystemsNum) {
        this.convergedHardwareSystemsNum = convergedHardwareSystemsNum;
    }

    /**
     * Getter method for property <tt>bladeStorageGradesNum</tt>.
     * 
     * @return property value of bladeStorageGradesNum
     */
    public Integer getBladeStorageGradesNum() {
        return bladeStorageGradesNum;
    }

    /**
     * Setter method for property <tt>bladeStorageGradesNum</tt>.
     * 
     * @param bladeStorageGradesNum
     *            value to be assigned to property bladeStorageGradesNum
     */
    public void setBladeStorageGradesNum(Integer bladeStorageGradesNum) {
        this.bladeStorageGradesNum = bladeStorageGradesNum;
    }

    /**
     * Getter method for property <tt>identityPoolsNum</tt>.
     * 
     * @return property value of identityPoolsNum
     */
    public Integer getIdentityPoolsNum() {
        return identityPoolsNum;
    }

    /**
     * Setter method for property <tt>identityPoolsNum</tt>.
     * 
     * @param identityPoolsNum
     *            value to be assigned to property identityPoolsNum
     */
    public void setIdentityPoolsNum(Integer identityPoolsNum) {
        this.identityPoolsNum = identityPoolsNum;
    }

    /**
     * Getter method for property <tt>networkProfilesNum</tt>.
     * 
     * @return property value of networkProfilesNum
     */
    public Integer getNetworkProfilesNum() {
        return networkProfilesNum;
    }

    /**
     * Setter method for property <tt>networkProfilesNum</tt>.
     * 
     * @param networkProfilesNum
     *            value to be assigned to property networkProfilesNum
     */
    public void setNetworkProfilesNum(Integer networkProfilesNum) {
        this.networkProfilesNum = networkProfilesNum;
    }

    /**
     * Getter method for property <tt>uimOperationsVAppsNum</tt>.
     * 
     * @return property value of uimOperationsVAppsNum
     */
    public Integer getUimOperationsVAppsNum() {
        return uimOperationsVAppsNum;
    }

    /**
     * Setter method for property <tt>uimOperationsVAppsNum</tt>.
     * 
     * @param uimOperationsVAppsNum
     *            value to be assigned to property uimOperationsVAppsNum
     */
    public void setUimOperationsVAppsNum(Integer uimOperationsVAppsNum) {
        this.uimOperationsVAppsNum = uimOperationsVAppsNum;
    }

    /**
     * Getter method for property <tt>serviceOfferingsToCreateNum</tt>.
     * 
     * @return property value of serviceOfferingsToCreateNum
     */
    public Integer getServiceOfferingsToCreateNum() {
        return serviceOfferingsToCreateNum;
    }

    /**
     * Setter method for property <tt>serviceOfferingsToCreateNum</tt>.
     * 
     * @param serviceOfferingsToCreateNum
     *            value to be assigned to property serviceOfferingsToCreateNum
     */
    public void setServiceOfferingsToCreateNum(Integer serviceOfferingsToCreateNum) {
        this.serviceOfferingsToCreateNum = serviceOfferingsToCreateNum;
    }

    /**
     * Getter method for property <tt>servicesToCreateNum</tt>.
     * 
     * @return property value of servicesToCreateNum
     */
    public Integer getServicesToCreateNum() {
        return servicesToCreateNum;
    }

    /**
     * Setter method for property <tt>servicesToCreateNum</tt>.
     * 
     * @param servicesToCreateNum
     *            value to be assigned to property servicesToCreateNum
     */
    public void setServicesToCreateNum(Integer servicesToCreateNum) {
        this.servicesToCreateNum = servicesToCreateNum;
    }

    /**
     * Getter method for property <tt>bladesToProvisionNum</tt>.
     * 
     * @return property value of bladesToProvisionNum
     */
    public Integer getBladesToProvisionNum() {
        return bladesToProvisionNum;
    }

    /**
     * Setter method for property <tt>bladesToProvisionNum</tt>.
     * 
     * @param bladesToProvisionNum
     *            value to be assigned to property bladesToProvisionNum
     */
    public void setBladesToProvisionNum(Integer bladesToProvisionNum) {
        this.bladesToProvisionNum = bladesToProvisionNum;
    }

    /**
     * Getter method for property <tt>lunsToProvisionNum</tt>.
     * 
     * @return property value of lunsToProvisionNum
     */
    public Integer getLunsToProvisionNum() {
        return lunsToProvisionNum;
    }

    /**
     * Setter method for property <tt>lunsToProvisionNum</tt>.
     * 
     * @param lunsToProvisionNum
     *            value to be assigned to property lunsToProvisionNum
     */
    public void setLunsToProvisionNum(Integer lunsToProvisionNum) {
        this.lunsToProvisionNum = lunsToProvisionNum;
    }

    /**
     * Getter method for property <tt>servicesToProvisionNum</tt>.
     * 
     * @return property value of servicesToProvisionNum
     */
    public Integer getServicesToProvisionNum() {
        return servicesToProvisionNum;
    }

    /**
     * Setter method for property <tt>servicesToProvisionNum</tt>.
     * 
     * @param servicesToProvisionNum
     *            value to be assigned to property servicesToProvisionNum
     */
    public void setServicesToProvisionNum(Integer servicesToProvisionNum) {
        this.servicesToProvisionNum = servicesToProvisionNum;
    }

    /**
     * Getter method for property <tt>dataSourcesNum</tt>.
     * 
     * @return property value of dataSourcesNum
     */
    public Integer getDataSourcesNum() {
        return dataSourcesNum;
    }

    /**
     * Setter method for property <tt>dataSourcesNum</tt>.
     * 
     * @param dataSourcesNum
     *            value to be assigned to property dataSourcesNum
     */
    public void setDataSourcesNum(Integer dataSourcesNum) {
        this.dataSourcesNum = dataSourcesNum;
    }

    /**
     * Getter method for property <tt>snmpAlertsNum</tt>.
     * 
     * @return property value of snmpAlertsNum
     */
    public Integer getSnmpAlertsNum() {
        return snmpAlertsNum;
    }

    /**
     * Setter method for property <tt>snmpAlertsNum</tt>.
     * 
     * @param snmpAlertsNum
     *            value to be assigned to property snmpAlertsNum
     */
    public void setSnmpAlertsNum(Integer snmpAlertsNum) {
        this.snmpAlertsNum = snmpAlertsNum;
    }

    /**
     * Getter method for property <tt>uimOperationsServersNum</tt>.
     * 
     * @return property value of uimOperationsServersNum
     */
    public Integer getUimOperationsServersNum() {
        return uimOperationsServersNum;
    }

    /**
     * Setter method for property <tt>uimOperationsServersNum</tt>.
     * 
     * @param uimOperationsServersNum
     *            value to be assigned to property uimOperationsServersNum
     */
    public void setUimOperationsServersNum(Integer uimOperationsServersNum) {
        this.uimOperationsServersNum = uimOperationsServersNum;
    }

    /**
     * Getter method for property <tt>uimOperationsUsersNum</tt>.
     * 
     * @return property value of uimOperationsUsersNum
     */
    public Integer getUimOperationsUsersNum() {
        return uimOperationsUsersNum;
    }

    /**
     * Setter method for property <tt>uimOperationsUsersNum</tt>.
     * 
     * @param uimOperationsUsersNum
     *            value to be assigned to property uimOperationsUsersNum
     */
    public void setUimOperationsUsersNum(Integer uimOperationsUsersNum) {
        this.uimOperationsUsersNum = uimOperationsUsersNum;
    }

    /**
     * Getter method for property <tt>performElasticProvisioning</tt>.
     * 
     * @return property value of performElasticProvisioning
     */
    public Boolean getPerformElasticProvisioning() {
        return performElasticProvisioning;
    }

    /**
     * Setter method for property <tt>performElasticProvisioning</tt>.
     * 
     * @param performElasticProvisioning
     *            value to be assigned to property performElasticProvisioning
     */
    public void setPerformElasticProvisioning(Boolean performElasticProvisioning) {
        this.performElasticProvisioning = performElasticProvisioning;
    }

    /**
     * Getter method for property <tt>servicesRequiringElasticOperationsNum</tt>.
     * 
     * @return property value of servicesRequiringElasticOperationsNum
     */
    public Integer getServicesRequiringElasticOperationsNum() {
        return servicesRequiringElasticOperationsNum;
    }

    /**
     * Setter method for property <tt>servicesRequiringElasticOperationsNum</tt>.
     * 
     * @param servicesRequiringElasticOperationsNum
     *            value to be assigned to property servicesRequiringElasticOperationsNum
     */
    public void setServicesRequiringElasticOperationsNum(Integer servicesRequiringElasticOperationsNum) {
        this.servicesRequiringElasticOperationsNum = servicesRequiringElasticOperationsNum;
    }

    /**
     * Getter method for property <tt>bladesImpactedNum</tt>.
     * 
     * @return property value of bladesImpactedNum
     */
    public Integer getBladesImpactedNum() {
        return bladesImpactedNum;
    }

    /**
     * Setter method for property <tt>bladesImpactedNum</tt>.
     * 
     * @param bladesImpactedNum
     *            value to be assigned to property bladesImpactedNum
     */
    public void setBladesImpactedNum(Integer bladesImpactedNum) {
        this.bladesImpactedNum = bladesImpactedNum;
    }

    /**
     * Getter method for property <tt>migrateServices</tt>.
     * 
     * @return property value of migrateServices
     */
    public Boolean getMigrateServices() {
        return migrateServices;
    }

    /**
     * Setter method for property <tt>migrateServices</tt>.
     * 
     * @param migrateServices
     *            value to be assigned to property migrateServices
     */
    public void setMigrateServices(Boolean migrateServices) {
        this.migrateServices = migrateServices;
    }

    /**
     * Getter method for property <tt>nonUIMConvergedHardwareSystemsNum</tt>.
     * 
     * @return property value of nonUIMConvergedHardwareSystemsNum
     */
    public Integer getNonUIMConvergedHardwareSystemsNum() {
        return nonUIMConvergedHardwareSystemsNum;
    }

    /**
     * Setter method for property <tt>nonUIMConvergedHardwareSystemsNum</tt>.
     * 
     * @param nonUIMConvergedHardwareSystemsNum
     *            value to be assigned to property nonUIMConvergedHardwareSystemsNum
     */
    public void setNonUIMConvergedHardwareSystemsNum(Integer nonUIMConvergedHardwareSystemsNum) {
        this.nonUIMConvergedHardwareSystemsNum = nonUIMConvergedHardwareSystemsNum;
    }

    /**
     * Getter method for property <tt>servicesAdoptedMigratedNum</tt>.
     * 
     * @return property value of servicesAdoptedMigratedNum
     */
    public Integer getServicesAdoptedMigratedNum() {
        return servicesAdoptedMigratedNum;
    }

    /**
     * Setter method for property <tt>servicesAdoptedMigratedNum</tt>.
     * 
     * @param servicesAdoptedMigratedNum
     *            value to be assigned to property servicesAdoptedMigratedNum
     */
    public void setServicesAdoptedMigratedNum(Integer servicesAdoptedMigratedNum) {
        this.servicesAdoptedMigratedNum = servicesAdoptedMigratedNum;
    }

    /**
     * Getter method for property <tt>bladesAdoptedMigratedNum</tt>.
     * 
     * @return property value of bladesAdoptedMigratedNum
     */
    public Integer getBladesAdoptedMigratedNum() {
        return bladesAdoptedMigratedNum;
    }

    /**
     * Setter method for property <tt>bladesAdoptedMigratedNum</tt>.
     * 
     * @param bladesAdoptedMigratedNum
     *            value to be assigned to property bladesAdoptedMigratedNum
     */
    public void setBladesAdoptedMigratedNum(Integer bladesAdoptedMigratedNum) {
        this.bladesAdoptedMigratedNum = bladesAdoptedMigratedNum;
    }

    /**
     * Getter method for property <tt>customerKnown</tt>.
     * 
     * @return property value of customerKnown
     */
    public Boolean getCustomerKnown() {
        return customerKnown;
    }

    /**
     * Setter method for property <tt>customerKnown</tt>.
     * 
     * @param customerKnown
     *            value to be assigned to property customerKnown
     */
    public void setCustomerKnown(Boolean customerKnown) {
        this.customerKnown = customerKnown;
    }

    /**
     * Getter method for property <tt>remediateHours</tt>.
     * 
     * @return property value of remediateHours
     */
    public BigDecimal getRemediateHours() {
        return remediateHours;
    }

    /**
     * Setter method for property <tt>remediateHours</tt>.
     * 
     * @param remediateHours
     *            value to be assigned to property remediateHours
     */
    public void setRemediateHours(BigDecimal remediateHours) {
        this.remediateHours = remediateHours;
    }

    /**
     * Getter method for property <tt>saKnowledgeTransferHours</tt>.
     * 
     * @return property value of saKnowledgeTransferHours
     */
    public BigDecimal getSaKnowledgeTransferHours() {
        return saKnowledgeTransferHours;
    }

    /**
     * Setter method for property <tt>saKnowledgeTransferHours</tt>.
     * 
     * @param saKnowledgeTransferHours
     *            value to be assigned to property saKnowledgeTransferHours
     */
    public void setSaKnowledgeTransferHours(BigDecimal saKnowledgeTransferHours) {
        this.saKnowledgeTransferHours = saKnowledgeTransferHours;
    }

    /**
     * Getter method for property <tt>isKnowledgeTransferHours</tt>.
     * 
     * @return property value of isKnowledgeTransferHours
     */
    public BigDecimal getIsKnowledgeTransferHours() {
        return isKnowledgeTransferHours;
    }

    /**
     * Setter method for property <tt>isKnowledgeTransferHours</tt>.
     * 
     * @param isKnowledgeTransferHours
     *            value to be assigned to property isKnowledgeTransferHours
     */
    public void setIsKnowledgeTransferHours(BigDecimal isKnowledgeTransferHours) {
        this.isKnowledgeTransferHours = isKnowledgeTransferHours;
    }

}

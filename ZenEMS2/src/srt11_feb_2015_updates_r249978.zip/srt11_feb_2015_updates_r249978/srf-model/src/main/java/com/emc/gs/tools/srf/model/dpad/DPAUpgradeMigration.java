/*
 * This code is copyright (c) 2014 EMC Corporation
 */
package com.emc.gs.tools.srf.model.dpad;

import com.emc.gs.tools.srf.model.IdentifiableEntity;

/**
 * <p>
 * This is DPAUpgradeMigration entity class.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safety.
 * </p>
 * 
 * @author TCSASSEMBLER
 * @version 1.0
 * @since SRT Phase 3-5 - BRS Tabs Part 2 Assembly
 */
public class DPAUpgradeMigration extends IdentifiableEntity {

    /**
     * Select Current Data Protection Advisor Version for Upgrade / Migration.
     */
    private DPAUpgradeMigrationVersion upgradeMigrationVersion;

    /**
     * Represents whether "Manual Migrations" option is selected.
     */
    private boolean manualMigrations;

    /**
     * Represents whether "Customization Migration" option is selected.
     */
    private boolean customizationMigration;

    /**
     * Estimated Data Protection Advisor Migration Volumes in GB.
     */
    private Integer estimatedMigrationVolumes;

    /**
     * # of Data Protection Advisor Agents to Reconfigure.
     */
    private Integer reconfigureAgentsNum;

    /**
     * <p>
     * The default constructor.
     * </p>
     */
    public DPAUpgradeMigration() {
    }

    /**
     * Getter method for property <tt>upgradeMigrationVersion</tt>.
     * 
     * @return property value of upgradeMigrationVersion
     */
    public DPAUpgradeMigrationVersion getUpgradeMigrationVersion() {
        return upgradeMigrationVersion;
    }

    /**
     * Setter method for property <tt>upgradeMigrationVersion</tt>.
     * 
     * @param upgradeMigrationVersion
     *            value to be assigned to property upgradeMigrationVersion
     */
    public void setUpgradeMigrationVersion(DPAUpgradeMigrationVersion upgradeMigrationVersion) {
        this.upgradeMigrationVersion = upgradeMigrationVersion;
    }

    /**
     * Getter method for property <tt>manualMigrations</tt>.
     * 
     * @return property value of manualMigrations
     */
    public boolean isManualMigrations() {
        return manualMigrations;
    }

    /**
     * Setter method for property <tt>manualMigrations</tt>.
     * 
     * @param manualMigrations
     *            value to be assigned to property manualMigrations
     */
    public void setManualMigrations(boolean manualMigrations) {
        this.manualMigrations = manualMigrations;
    }

    /**
     * Getter method for property <tt>customizationMigration</tt>.
     * 
     * @return property value of customizationMigration
     */
    public boolean isCustomizationMigration() {
        return customizationMigration;
    }

    /**
     * Setter method for property <tt>customizationMigration</tt>.
     * 
     * @param customizationMigration
     *            value to be assigned to property customizationMigration
     */
    public void setCustomizationMigration(boolean customizationMigration) {
        this.customizationMigration = customizationMigration;
    }

    /**
     * Getter method for property <tt>estimatedMigrationVolumes</tt>.
     * 
     * @return property value of estimatedMigrationVolumes
     */
    public Integer getEstimatedMigrationVolumes() {
        return estimatedMigrationVolumes;
    }

    /**
     * Setter method for property <tt>estimatedMigrationVolumes</tt>.
     * 
     * @param estimatedMigrationVolumes
     *            value to be assigned to property estimatedMigrationVolumes
     */
    public void setEstimatedMigrationVolumes(Integer estimatedMigrationVolumes) {
        this.estimatedMigrationVolumes = estimatedMigrationVolumes;
    }

    /**
     * Getter method for property <tt>reconfigureAgentsNum</tt>.
     * 
     * @return property value of reconfigureAgentsNum
     */
    public Integer getReconfigureAgentsNum() {
        return reconfigureAgentsNum;
    }

    /**
     * Setter method for property <tt>reconfigureAgentsNum</tt>.
     * 
     * @param reconfigureAgentsNum
     *            value to be assigned to property reconfigureAgentsNum
     */
    public void setReconfigureAgentsNum(Integer reconfigureAgentsNum) {
        this.reconfigureAgentsNum = reconfigureAgentsNum;
    }

}

/*
 * This code is copyright (c) 2014 EMC Corporation
 */
package com.emc.gs.tools.srf.model.dpad;

import java.math.BigDecimal;

import com.emc.gs.tools.srf.model.IdentifiableEntity;

/**
 * <p>
 * This is DataDomain entity class.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safety.
 * </p>
 *
 * <p>
 * Version 1.1 (SRT 4 OCT2014 Updates Part 1 Assembly) Change notes:
 *   <ol>
 *     <li>Removed <code>enableRetentionLocking</code> property.</li>
 *   </ol>
 * </p>
 *
 * <p>
 * Version 1.2 Change notes:
 *   <ol>
 *     <li>Added {@link #designImplementationIdentical} property.</li>
 *     <li>Added {@link #designImplContent} property.</li>
 *   </ol>
 * </p>
 * 
 * @author isv
 * @version 1.2
 * @since SRT Phase 3-5 - BRS Tabs Part 2 Assembly
 */
public class DataDomain extends IdentifiableEntity {

    /**
     * # of Hours of Knowledge Transfer.
     */
    private BigDecimal knowledgeTransferHours;

    /**
     * Represents whether "Implement Data Domain" service is selected.
     */
    private boolean implementService;

    /**
     * Represents whether "Upgrade Data Domain" service is selected.
     */
    private boolean upgradeService;

    /**
     * Represents whether "Implement Data Domain Virtual Tape Library" service is selected.
     */
    private boolean implementVTLService;

    /**
     * Represents whether "Data Staging and Replication" service is selected.
     */
    private boolean dataStagingService;

    /**
     * Represents whether "Install Data Domain Expansion Shelf" service is selected.
     */
    private boolean expansionShelfService;

    /**
     * Represents whether "Data Domain Integration" service is selected.
     */
    private boolean integrationService;

    /**
     * Represents whether "Health Check for Data Domain" service is selected.
     */
    private boolean healthCheckService;

    /**
     * Represents whether "Data Migration for Data Domain" service is selected.
     */
    private boolean migrationService;

    /**
     * Represents whether "Data Domain Pre-Racked" service is selected.
     */
    private boolean preRackedService;

    /**
     * Represents whether "Data Domain Boost" service is selected.
     */
    private boolean boostService;

    /**
     * Represents whether "Data Domain Extended Retention Conversion" service is selected.
     */
    private boolean extendedRetentionConversionService;

    /**
     * Represents whether "Data Domain Management Center Configuration" service is selected.
     */
    private boolean managementCenterConfigService;

    /**
     * Represents whether "SAP Hana Studio Integration with Data Domain" service is selected.
     */
    private boolean sapHanaService;

    /**
     * Represents whether "Design" activity type is selected.
     */
    private boolean designActivity;

    /**
     * Represents whether "Implementation" activity type is selected.
     */
    private boolean implementationActivity;

    /**
     * <p>A <code>boolean</code> providing the value for designImplementationIdentical property.</p>
     * 
     * @since 1.2
     */
    private boolean designImplementationIdentical;

    /**
     * <p>A <code>DataDomainDesignImplContent</code> providing the value for designImplContent property.</p>
     *
     * @since 1.2
     */
    private DataDomainDesignImplContent designImplContent;

    /**
     * Data Domain Design.
     */
    private DataDomainDesign design;

    /**
     * Data Domain Implementation.
     */
    private DataDomainImplementation implementation;

    /**
     * Data Domain upgrade.
     */
    private DataDomainUpgrade upgrade;

    /**
     * Data Domain Implementation For Virtual Tape Library.
     */
    private DataDomainVTL vtl;

    /**
     * Installation For Data Domain Expansion Shelf.
     */
    private DataDomainExpansionShelf expansionShelf;

    /**
     * Data Staging and Replication.
     */
    private DataDomainDataStaging dataStaging;

    /**
     * Data Domain Integration.
     */
    private DataDomainIntegration integration;

    /**
     * Data Domain Health Check.
     */
    private DataDomainHealthCheck healthCheck;

    /**
     * Data Domain Migration.
     */
    private DataDomainMigration migration;

    /**
     * Data Domain Pre-Rack.
     */
    private DataDomainPreRack preRack;

    /**
     * Data Domain Boost.
     */
    private DataDomainBoost boost;

    /**
     * Data Domain Extended Retention Conversion.
     */
    private DataDomainExtendedRetentionConversion extendedRetentionConversion;

    /**
     * Data Domain Management Center Configuration.
     */
    private DataDomainManagementCenterConfig managementCenterConfig;

    /**
     * Data Domain SAP Hana Studio Integration.
     */
    private DataDomainSapHana sapHana;

    /**
     * <p>
     * The default constructor.
     * </p>
     */
    public DataDomain() {
    }

    /**
     * Getter method for property <tt>knowledgeTransferHours</tt>.
     * 
     * @return property value of knowledgeTransferHours
     */
    public BigDecimal getKnowledgeTransferHours() {
        return knowledgeTransferHours;
    }

    /**
     * Setter method for property <tt>knowledgeTransferHours</tt>.
     * 
     * @param knowledgeTransferHours
     *            value to be assigned to property knowledgeTransferHours
     */
    public void setKnowledgeTransferHours(BigDecimal knowledgeTransferHours) {
        this.knowledgeTransferHours = knowledgeTransferHours;
    }

    /**
     * Getter method for property <tt>implementService</tt>.
     * 
     * @return property value of implementService
     */
    public boolean isImplementService() {
        return implementService;
    }

    /**
     * Setter method for property <tt>implementService</tt>.
     * 
     * @param implementService
     *            value to be assigned to property implementService
     */
    public void setImplementService(boolean implementService) {
        this.implementService = implementService;
    }

    /**
     * Getter method for property <tt>upgradeService</tt>.
     * 
     * @return property value of upgradeService
     */
    public boolean isUpgradeService() {
        return upgradeService;
    }

    /**
     * Setter method for property <tt>upgradeService</tt>.
     * 
     * @param upgradeService
     *            value to be assigned to property upgradeService
     */
    public void setUpgradeService(boolean upgradeService) {
        this.upgradeService = upgradeService;
    }

    /**
     * Getter method for property <tt>implementVTLService</tt>.
     * 
     * @return property value of implementVTLService
     */
    public boolean isImplementVTLService() {
        return implementVTLService;
    }

    /**
     * Setter method for property <tt>implementVTLService</tt>.
     * 
     * @param implementVTLService
     *            value to be assigned to property implementVTLService
     */
    public void setImplementVTLService(boolean implementVTLService) {
        this.implementVTLService = implementVTLService;
    }

    /**
     * Getter method for property <tt>dataStagingService</tt>.
     * 
     * @return property value of dataStagingService
     */
    public boolean isDataStagingService() {
        return dataStagingService;
    }

    /**
     * Setter method for property <tt>dataStagingService</tt>.
     * 
     * @param dataStagingService
     *            value to be assigned to property dataStagingService
     */
    public void setDataStagingService(boolean dataStagingService) {
        this.dataStagingService = dataStagingService;
    }

    /**
     * Getter method for property <tt>expansionShelfService</tt>.
     * 
     * @return property value of expansionShelfService
     */
    public boolean isExpansionShelfService() {
        return expansionShelfService;
    }

    /**
     * Setter method for property <tt>expansionShelfService</tt>.
     * 
     * @param expansionShelfService
     *            value to be assigned to property expansionShelfService
     */
    public void setExpansionShelfService(boolean expansionShelfService) {
        this.expansionShelfService = expansionShelfService;
    }

    /**
     * Getter method for property <tt>integrationService</tt>.
     * 
     * @return property value of integrationService
     */
    public boolean isIntegrationService() {
        return integrationService;
    }

    /**
     * Setter method for property <tt>integrationService</tt>.
     * 
     * @param integrationService
     *            value to be assigned to property integrationService
     */
    public void setIntegrationService(boolean integrationService) {
        this.integrationService = integrationService;
    }

    /**
     * Getter method for property <tt>healthCheckService</tt>.
     * 
     * @return property value of healthCheckService
     */
    public boolean isHealthCheckService() {
        return healthCheckService;
    }

    /**
     * Setter method for property <tt>healthCheckService</tt>.
     * 
     * @param healthCheckService
     *            value to be assigned to property healthCheckService
     */
    public void setHealthCheckService(boolean healthCheckService) {
        this.healthCheckService = healthCheckService;
    }

    /**
     * Getter method for property <tt>migrationService</tt>.
     * 
     * @return property value of migrationService
     */
    public boolean isMigrationService() {
        return migrationService;
    }

    /**
     * Setter method for property <tt>migrationService</tt>.
     * 
     * @param migrationService
     *            value to be assigned to property migrationService
     */
    public void setMigrationService(boolean migrationService) {
        this.migrationService = migrationService;
    }

    /**
     * Getter method for property <tt>preRackedService</tt>.
     * 
     * @return property value of preRackedService
     */
    public boolean isPreRackedService() {
        return preRackedService;
    }

    /**
     * Setter method for property <tt>preRackedService</tt>.
     * 
     * @param preRackedService
     *            value to be assigned to property preRackedService
     */
    public void setPreRackedService(boolean preRackedService) {
        this.preRackedService = preRackedService;
    }

    /**
     * Getter method for property <tt>boostService</tt>.
     * 
     * @return property value of boostService
     */
    public boolean isBoostService() {
        return boostService;
    }

    /**
     * Setter method for property <tt>boostService</tt>.
     * 
     * @param boostService
     *            value to be assigned to property boostService
     */
    public void setBoostService(boolean boostService) {
        this.boostService = boostService;
    }

    /**
     * Getter method for property <tt>extendedRetentionConversionService</tt>.
     * 
     * @return property value of extendedRetentionConversionService
     */
    public boolean isExtendedRetentionConversionService() {
        return extendedRetentionConversionService;
    }

    /**
     * Setter method for property <tt>extendedRetentionConversionService</tt>.
     * 
     * @param extendedRetentionConversionService
     *            value to be assigned to property extendedRetentionConversionService
     */
    public void setExtendedRetentionConversionService(boolean extendedRetentionConversionService) {
        this.extendedRetentionConversionService = extendedRetentionConversionService;
    }

    /**
     * Getter method for property <tt>managementCenterConfigService</tt>.
     * 
     * @return property value of managementCenterConfigService
     */
    public boolean isManagementCenterConfigService() {
        return managementCenterConfigService;
    }

    /**
     * Setter method for property <tt>managementCenterConfigService</tt>.
     * 
     * @param managementCenterConfigService
     *            value to be assigned to property managementCenterConfigService
     */
    public void setManagementCenterConfigService(boolean managementCenterConfigService) {
        this.managementCenterConfigService = managementCenterConfigService;
    }

    /**
     * Getter method for property <tt>sapHanaService</tt>.
     * 
     * @return property value of sapHanaService
     */
    public boolean isSapHanaService() {
        return sapHanaService;
    }

    /**
     * Setter method for property <tt>sapHanaService</tt>.
     * 
     * @param sapHanaService
     *            value to be assigned to property sapHanaService
     */
    public void setSapHanaService(boolean sapHanaService) {
        this.sapHanaService = sapHanaService;
    }

    /**
     * Getter method for property <tt>designActivity</tt>.
     * 
     * @return property value of designActivity
     */
    public boolean isDesignActivity() {
        return designActivity;
    }

    /**
     * Setter method for property <tt>designActivity</tt>.
     * 
     * @param designActivity
     *            value to be assigned to property designActivity
     */
    public void setDesignActivity(boolean designActivity) {
        this.designActivity = designActivity;
    }

    /**
     * Getter method for property <tt>implementationActivity</tt>.
     * 
     * @return property value of implementationActivity
     */
    public boolean isImplementationActivity() {
        return implementationActivity;
    }

    /**
     * Setter method for property <tt>implementationActivity</tt>.
     * 
     * @param implementationActivity
     *            value to be assigned to property implementationActivity
     */
    public void setImplementationActivity(boolean implementationActivity) {
        this.implementationActivity = implementationActivity;
    }

    /**
     * Getter method for property <tt>design</tt>.
     * 
     * @return property value of design
     */
    public DataDomainDesign getDesign() {
        return design;
    }

    /**
     * Setter method for property <tt>design</tt>.
     * 
     * @param design
     *            value to be assigned to property design
     */
    public void setDesign(DataDomainDesign design) {
        this.design = design;
    }

    /**
     * Getter method for property <tt>implementation</tt>.
     * 
     * @return property value of implementation
     */
    public DataDomainImplementation getImplementation() {
        return implementation;
    }

    /**
     * Setter method for property <tt>implementation</tt>.
     * 
     * @param implementation
     *            value to be assigned to property implementation
     */
    public void setImplementation(DataDomainImplementation implementation) {
        this.implementation = implementation;
    }

    /**
     * Getter method for property <tt>upgrade</tt>.
     * 
     * @return property value of upgrade
     */
    public DataDomainUpgrade getUpgrade() {
        return upgrade;
    }

    /**
     * Setter method for property <tt>upgrade</tt>.
     * 
     * @param upgrade
     *            value to be assigned to property upgrade
     */
    public void setUpgrade(DataDomainUpgrade upgrade) {
        this.upgrade = upgrade;
    }

    /**
     * Getter method for property <tt>vtl</tt>.
     * 
     * @return property value of vtl
     */
    public DataDomainVTL getVtl() {
        return vtl;
    }

    /**
     * Setter method for property <tt>vtl</tt>.
     * 
     * @param vtl
     *            value to be assigned to property vtl
     */
    public void setVtl(DataDomainVTL vtl) {
        this.vtl = vtl;
    }

    /**
     * Getter method for property <tt>expansionShelf</tt>.
     * 
     * @return property value of expansionShelf
     */
    public DataDomainExpansionShelf getExpansionShelf() {
        return expansionShelf;
    }

    /**
     * Setter method for property <tt>expansionShelf</tt>.
     * 
     * @param expansionShelf
     *            value to be assigned to property expansionShelf
     */
    public void setExpansionShelf(DataDomainExpansionShelf expansionShelf) {
        this.expansionShelf = expansionShelf;
    }

    /**
     * Getter method for property <tt>dataStaging</tt>.
     * 
     * @return property value of dataStaging
     */
    public DataDomainDataStaging getDataStaging() {
        return dataStaging;
    }

    /**
     * Setter method for property <tt>dataStaging</tt>.
     * 
     * @param dataStaging
     *            value to be assigned to property dataStaging
     */
    public void setDataStaging(DataDomainDataStaging dataStaging) {
        this.dataStaging = dataStaging;
    }

    /**
     * Getter method for property <tt>integration</tt>.
     * 
     * @return property value of integration
     */
    public DataDomainIntegration getIntegration() {
        return integration;
    }

    /**
     * Setter method for property <tt>integration</tt>.
     * 
     * @param integration
     *            value to be assigned to property integration
     */
    public void setIntegration(DataDomainIntegration integration) {
        this.integration = integration;
    }

    /**
     * Getter method for property <tt>healthCheck</tt>.
     * 
     * @return property value of healthCheck
     */
    public DataDomainHealthCheck getHealthCheck() {
        return healthCheck;
    }

    /**
     * Setter method for property <tt>healthCheck</tt>.
     * 
     * @param healthCheck
     *            value to be assigned to property healthCheck
     */
    public void setHealthCheck(DataDomainHealthCheck healthCheck) {
        this.healthCheck = healthCheck;
    }

    /**
     * Getter method for property <tt>migration</tt>.
     * 
     * @return property value of migration
     */
    public DataDomainMigration getMigration() {
        return migration;
    }

    /**
     * Setter method for property <tt>migration</tt>.
     * 
     * @param migration
     *            value to be assigned to property migration
     */
    public void setMigration(DataDomainMigration migration) {
        this.migration = migration;
    }

    /**
     * Getter method for property <tt>preRack</tt>.
     * 
     * @return property value of preRack
     */
    public DataDomainPreRack getPreRack() {
        return preRack;
    }

    /**
     * Setter method for property <tt>preRack</tt>.
     * 
     * @param preRack
     *            value to be assigned to property preRack
     */
    public void setPreRack(DataDomainPreRack preRack) {
        this.preRack = preRack;
    }

    /**
     * Getter method for property <tt>boost</tt>.
     * 
     * @return property value of boost
     */
    public DataDomainBoost getBoost() {
        return boost;
    }

    /**
     * Setter method for property <tt>boost</tt>.
     * 
     * @param boost
     *            value to be assigned to property boost
     */
    public void setBoost(DataDomainBoost boost) {
        this.boost = boost;
    }

    /**
     * Getter method for property <tt>extendedRetentionConversion</tt>.
     * 
     * @return property value of extendedRetentionConversion
     */
    public DataDomainExtendedRetentionConversion getExtendedRetentionConversion() {
        return extendedRetentionConversion;
    }

    /**
     * Setter method for property <tt>extendedRetentionConversion</tt>.
     * 
     * @param extendedRetentionConversion
     *            value to be assigned to property extendedRetentionConversion
     */
    public void setExtendedRetentionConversion(DataDomainExtendedRetentionConversion extendedRetentionConversion) {
        this.extendedRetentionConversion = extendedRetentionConversion;
    }

    /**
     * Getter method for property <tt>managementCenterConfig</tt>.
     * 
     * @return property value of managementCenterConfig
     */
    public DataDomainManagementCenterConfig getManagementCenterConfig() {
        return managementCenterConfig;
    }

    /**
     * Setter method for property <tt>managementCenterConfig</tt>.
     * 
     * @param managementCenterConfig
     *            value to be assigned to property managementCenterConfig
     */
    public void setManagementCenterConfig(DataDomainManagementCenterConfig managementCenterConfig) {
        this.managementCenterConfig = managementCenterConfig;
    }

    /**
     * Getter method for property <tt>sapHana</tt>.
     * 
     * @return property value of sapHana
     */
    public DataDomainSapHana getSapHana() {
        return sapHana;
    }

    /**
     * Setter method for property <tt>sapHana</tt>.
     * 
     * @param sapHana
     *            value to be assigned to property sapHana
     */
    public void setSapHana(DataDomainSapHana sapHana) {
        this.sapHana = sapHana;
    }

    /**
     * <p>Gets the designImplementationIdentical property.</p>
     *
     * @return a <code>boolean</code> providing the value for designImplementationIdentical property.
     * @since 1.2
     */
    public boolean getDesignImplementationIdentical() {
        return this.designImplementationIdentical;
    }

    /**
     * <p>Sets the designImplementationIdentical property.</p>
     *
     * @param designImplementationIdentical a <code>boolean</code> providing the value for designImplementationIdentical
     * property.
     * @since 1.2
     */
    public void setDesignImplementationIdentical(boolean designImplementationIdentical) {
        this.designImplementationIdentical = designImplementationIdentical;
    }

    /**
     * <p>Gets the designImplContent property.</p>
     *
     * @return a <code>DataDomainDesignImplContent</code> providing the value for designImplContent property.
     * @since 1.2
     */
    public DataDomainDesignImplContent getDesignImplContent() {
        return this.designImplContent;
    }

    /**
     * <p>Sets the designImplContent property.</p>
     *
     * @param designImplContent a <code>DataDomainDesignImplContent</code> providing the value for designImplContent
     * property.
     * @since 1.2
     */
    public void setDesignImplContent(DataDomainDesignImplContent designImplContent) {
        this.designImplContent = designImplContent;
    }

}

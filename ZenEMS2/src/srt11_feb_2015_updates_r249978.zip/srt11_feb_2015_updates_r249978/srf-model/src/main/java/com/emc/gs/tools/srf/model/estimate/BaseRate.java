/*
 * This code is copyright (c) 2014 EMC Corporation.
 */
package com.emc.gs.tools.srf.model.estimate;

import java.math.BigDecimal;

/**
 * <p>
 * This is BaseRate entity class.
 * </p>
 * <p>
 * The lookup key.
 * <p/>
 * For standard bill rate the format is : [Company code]|[Competency code]|[Role code]|[Material code]. E.g
 * "US10|1002|PS0002|PS-RES-EAA".
 * <p/>
 * For hourly standard cost rate the format is : [Cost center code]|[Role code]. E.g "US1080018|FPP001".
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safety.
 * </p>
 * 
 * @author TCSASSEMBLER
 * @version 1.0
 * @since SRT Phase 4 - ET Assembly 1
 */
public abstract class BaseRate {

    /**
     * The lookup key.
     */
    private String lookupKey;

    /**
     * The rate.
     */
    private BigDecimal rate;

    /**
     * Empty constructor.
     */
    protected BaseRate() {
    }

    /**
     * Getter method for property <tt>lookupKey</tt>.
     * 
     * @return property value of lookupKey
     */
    public String getLookupKey() {
        return lookupKey;
    }

    /**
     * Setter method for property <tt>lookupKey</tt>.
     * 
     * @param lookupKey
     *            value to be assigned to property lookupKey
     */
    public void setLookupKey(String lookupKey) {
        this.lookupKey = lookupKey;
    }

    /**
     * Getter method for property <tt>rate</tt>.
     * 
     * @return property value of rate
     */
    public BigDecimal getRate() {
        return rate;
    }

    /**
     * Setter method for property <tt>rate</tt>.
     * 
     * @param rate
     *            value to be assigned to property rate
     */
    public void setRate(BigDecimal rate) {
        this.rate = rate;
    }

}

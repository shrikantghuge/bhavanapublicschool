/*
 * This code is copyright (c) 2014 EMC Corporation.
 */
package com.emc.gs.tools.srf.model.bc;


/**
 * <p>
 * This is base array information for SrdfSourceArrayInformation and SrdfTargetArrayInformation entity.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safety.
 * </p>
 * 
 * <p>
 * <strong>Changes V1.1:</strong>
 * <ul>
 * <li>Removed existingOptionEnabled, microcodeFamily, currentSrdfMode, newSrdfMode fields.</li>
 * </ul>
 * </p>
 *
 * @author faeton, TCSASSEMBLER, MonicaMuranyi
 * @version 1.1
 * @since SRT Release Assembly - BC Tab
 */
public abstract class SrdfBaseArrayInformation {

    /**
     * <p>
     * The symmetrixModel.
     * </p>
     */
    private SymmetrixModel symmetrixModel;

    /**
     * <p>
     * The srdfInstalledStatus.
     * </p>
     */
    private Boolean srdfInstalledStatus;
    
    /**
     * Empty constructor.
     */
    public SrdfBaseArrayInformation() {
    }

    /**
     * Getter method for property <tt>symmetrixModel</tt>.
     * @return property value of symmetrixModel
     */
    public SymmetrixModel getSymmetrixModel() {
        return symmetrixModel;
    }

    /**
     * Getter method for property <tt>srdfInstalledStatus</tt>.
     * @return property value of srdfInstalledStatus
     */
    public Boolean getSrdfInstalledStatus() {
        return srdfInstalledStatus;
    }

    /**
     * Setter method for property <tt>symmetrixModel</tt>.
     * @param symmetrixModel value to be assigned to property symmetrixModel
     */
    public void setSymmetrixModel(SymmetrixModel symmetrixModel) {
        this.symmetrixModel = symmetrixModel;
    }

    /**
     * Setter method for property <tt>srdfInstalledStatus</tt>.
     * @param srdfInstalledStatus value to be assigned to property srdfInstalledStatus
     */
    public void setSrdfInstalledStatus(Boolean srdfInstalledStatus) {
        this.srdfInstalledStatus = srdfInstalledStatus;
    }
    
    /**
     * The toString method.
     *
     * @return the string for this entity
     */
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(", symmetrixModel:").append(symmetrixModel);
        sb.append(", srdfInstalledStatus:").append(srdfInstalledStatus);
        return sb.toString();
    }
}

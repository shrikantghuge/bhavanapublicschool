/*
 * This code is copyright (c) 2014 EMC Corporation
 */
package com.emc.gs.tools.srf.model.dpad;

import com.emc.gs.tools.srf.model.IdentifiableEntity;

/**
 * <p>
 * This is AvamarPlugins entity class.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safety.
 * </p>
 * 
 * @author TCSASSEMBLER
 * @version 1.0
 * @since SRT Phase 3-5 - BRS Tabs Part 1 Assembly
 */
public class AvamarPlugins extends IdentifiableEntity {

    /**
     * Represents whether Microsoft Exchange is selected.
     */
    private boolean exchange;

    /**
     * Represents whether Microsoft SQL Server is selected.
     */
    private boolean sqlServer;

    /**
     * Represents whether Oracle is selected.
     */
    private boolean oracle;

    /**
     * Represents whether DB2 is selected.
     */
    private boolean db2;

    /**
     * Represents whether Microsoft Sharepoint is selected.
     */
    private boolean sharepoint;

    /**
     * Represents whether Lotus Domino is selected.
     */
    private boolean lotusDomino;

    /**
     * # of Avamar Application Plug-ins for Microsoft Exchange.
     */
    private Integer exchangePluginsNum;

    /**
     * # of Avamar Application Plug-ins for Microsoft SQL Server.
     */
    private Integer sqlServerPluginsNum;

    /**
     * # of Avamar Application Plug-ins for Oracle.
     */
    private Integer oraclePluginsNum;

    /**
     * # of Avamar Application Plug-ins for DB2.
     */
    private Integer db2PluginsNum;

    /**
     * # of Avamar Application Plug-ins for Microsoft Sharepoint.
     */
    private Integer sharepointPluginsNum;

    /**
     * # of Avamar Application Plug-ins for Lotus Domino.
     */
    private Integer lotusDominoPluginsNum;

    /**
     * <p>
     * The default constructor.
     * </p>
     */
    public AvamarPlugins() {
    }

    /**
     * Getter method for property <tt>exchange</tt>.
     * 
     * @return property value of exchange
     */
    public boolean isExchange() {
        return exchange;
    }

    /**
     * Setter method for property <tt>exchange</tt>.
     * 
     * @param exchange
     *            value to be assigned to property exchange
     */
    public void setExchange(boolean exchange) {
        this.exchange = exchange;
    }

    /**
     * Getter method for property <tt>sqlServer</tt>.
     * 
     * @return property value of sqlServer
     */
    public boolean isSqlServer() {
        return sqlServer;
    }

    /**
     * Setter method for property <tt>sqlServer</tt>.
     * 
     * @param sqlServer
     *            value to be assigned to property sqlServer
     */
    public void setSqlServer(boolean sqlServer) {
        this.sqlServer = sqlServer;
    }

    /**
     * Getter method for property <tt>oracle</tt>.
     * 
     * @return property value of oracle
     */
    public boolean isOracle() {
        return oracle;
    }

    /**
     * Setter method for property <tt>oracle</tt>.
     * 
     * @param oracle
     *            value to be assigned to property oracle
     */
    public void setOracle(boolean oracle) {
        this.oracle = oracle;
    }

    /**
     * Getter method for property <tt>db2</tt>.
     * 
     * @return property value of db2
     */
    public boolean isDb2() {
        return db2;
    }

    /**
     * Setter method for property <tt>db2</tt>.
     * 
     * @param db2
     *            value to be assigned to property db2
     */
    public void setDb2(boolean db2) {
        this.db2 = db2;
    }

    /**
     * Getter method for property <tt>sharepoint</tt>.
     * 
     * @return property value of sharepoint
     */
    public boolean isSharepoint() {
        return sharepoint;
    }

    /**
     * Setter method for property <tt>sharepoint</tt>.
     * 
     * @param sharepoint
     *            value to be assigned to property sharepoint
     */
    public void setSharepoint(boolean sharepoint) {
        this.sharepoint = sharepoint;
    }

    /**
     * Getter method for property <tt>lotusDomino</tt>.
     * 
     * @return property value of lotusDomino
     */
    public boolean isLotusDomino() {
        return lotusDomino;
    }

    /**
     * Setter method for property <tt>lotusDomino</tt>.
     * 
     * @param lotusDomino
     *            value to be assigned to property lotusDomino
     */
    public void setLotusDomino(boolean lotusDomino) {
        this.lotusDomino = lotusDomino;
    }

    /**
     * Getter method for property <tt>exchangePluginsNum</tt>.
     * 
     * @return property value of exchangePluginsNum
     */
    public Integer getExchangePluginsNum() {
        return exchangePluginsNum;
    }

    /**
     * Setter method for property <tt>exchangePluginsNum</tt>.
     * 
     * @param exchangePluginsNum
     *            value to be assigned to property exchangePluginsNum
     */
    public void setExchangePluginsNum(Integer exchangePluginsNum) {
        this.exchangePluginsNum = exchangePluginsNum;
    }

    /**
     * Getter method for property <tt>sqlServerPluginsNum</tt>.
     * 
     * @return property value of sqlServerPluginsNum
     */
    public Integer getSqlServerPluginsNum() {
        return sqlServerPluginsNum;
    }

    /**
     * Setter method for property <tt>sqlServerPluginsNum</tt>.
     * 
     * @param sqlServerPluginsNum
     *            value to be assigned to property sqlServerPluginsNum
     */
    public void setSqlServerPluginsNum(Integer sqlServerPluginsNum) {
        this.sqlServerPluginsNum = sqlServerPluginsNum;
    }

    /**
     * Getter method for property <tt>oraclePluginsNum</tt>.
     * 
     * @return property value of oraclePluginsNum
     */
    public Integer getOraclePluginsNum() {
        return oraclePluginsNum;
    }

    /**
     * Setter method for property <tt>oraclePluginsNum</tt>.
     * 
     * @param oraclePluginsNum
     *            value to be assigned to property oraclePluginsNum
     */
    public void setOraclePluginsNum(Integer oraclePluginsNum) {
        this.oraclePluginsNum = oraclePluginsNum;
    }

    /**
     * Getter method for property <tt>db2PluginsNum</tt>.
     * 
     * @return property value of db2PluginsNum
     */
    public Integer getDb2PluginsNum() {
        return db2PluginsNum;
    }

    /**
     * Setter method for property <tt>db2PluginsNum</tt>.
     * 
     * @param db2PluginsNum
     *            value to be assigned to property db2PluginsNum
     */
    public void setDb2PluginsNum(Integer db2PluginsNum) {
        this.db2PluginsNum = db2PluginsNum;
    }

    /**
     * Getter method for property <tt>sharepointPluginsNum</tt>.
     * 
     * @return property value of sharepointPluginsNum
     */
    public Integer getSharepointPluginsNum() {
        return sharepointPluginsNum;
    }

    /**
     * Setter method for property <tt>sharepointPluginsNum</tt>.
     * 
     * @param sharepointPluginsNum
     *            value to be assigned to property sharepointPluginsNum
     */
    public void setSharepointPluginsNum(Integer sharepointPluginsNum) {
        this.sharepointPluginsNum = sharepointPluginsNum;
    }

    /**
     * Getter method for property <tt>lotusDominoPluginsNum</tt>.
     * 
     * @return property value of lotusDominoPluginsNum
     */
    public Integer getLotusDominoPluginsNum() {
        return lotusDominoPluginsNum;
    }

    /**
     * Setter method for property <tt>lotusDominoPluginsNum</tt>.
     * 
     * @param lotusDominoPluginsNum
     *            value to be assigned to property lotusDominoPluginsNum
     */
    public void setLotusDominoPluginsNum(Integer lotusDominoPluginsNum) {
        this.lotusDominoPluginsNum = lotusDominoPluginsNum;
    }

}

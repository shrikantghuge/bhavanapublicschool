/*
 * This code is copyright (c) 2014 EMC Corporation
 */
package com.emc.gs.tools.srf.model.dpad;


/**
 * <p>
 * This is AvamarDesign entity class.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safety.
 * </p>
 * 
 * @author TCSASSEMBLER
 * @version 1.0
 * @since SRT Phase 3-5 - BRS Tabs Part 1 Assembly
 */
public class AvamarDesign extends AvamarDesignImplBase {

    /**
     * # of Avamar NDMP Accelerator Nodes.
     */
    private Integer ndmpNodesNum;

    /**
     * # of NDMP Targets for Backup.
     */
    private Integer ndmpTargetsNum;

    /**
     * # of Avamar Datastore Expansion Nodes.
     */
    private Integer expansionNodesNum;

    /**
     * <p>
     * The default constructor.
     * </p>
     */
    public AvamarDesign() {
    }

    /**
     * Getter method for property <tt>ndmpNodesNum</tt>.
     * 
     * @return property value of ndmpNodesNum
     */
    public Integer getNdmpNodesNum() {
        return ndmpNodesNum;
    }

    /**
     * Setter method for property <tt>ndmpNodesNum</tt>.
     * 
     * @param ndmpNodesNum
     *            value to be assigned to property ndmpNodesNum
     */
    public void setNdmpNodesNum(Integer ndmpNodesNum) {
        this.ndmpNodesNum = ndmpNodesNum;
    }

    /**
     * Getter method for property <tt>ndmpTargetsNum</tt>.
     * 
     * @return property value of ndmpTargetsNum
     */
    public Integer getNdmpTargetsNum() {
        return ndmpTargetsNum;
    }

    /**
     * Setter method for property <tt>ndmpTargetsNum</tt>.
     * 
     * @param ndmpTargetsNum
     *            value to be assigned to property ndmpTargetsNum
     */
    public void setNdmpTargetsNum(Integer ndmpTargetsNum) {
        this.ndmpTargetsNum = ndmpTargetsNum;
    }

    /**
     * Getter method for property <tt>expansionNodesNum</tt>.
     * 
     * @return property value of expansionNodesNum
     */
    public Integer getExpansionNodesNum() {
        return expansionNodesNum;
    }

    /**
     * Setter method for property <tt>expansionNodesNum</tt>.
     * 
     * @param expansionNodesNum
     *            value to be assigned to property expansionNodesNum
     */
    public void setExpansionNodesNum(Integer expansionNodesNum) {
        this.expansionNodesNum = expansionNodesNum;
    }
}

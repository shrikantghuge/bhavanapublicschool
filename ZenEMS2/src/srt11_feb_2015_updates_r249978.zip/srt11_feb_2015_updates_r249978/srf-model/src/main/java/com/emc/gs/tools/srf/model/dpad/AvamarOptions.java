/*
 * This code is copyright (c) 2014 EMC Corporation
 */
package com.emc.gs.tools.srf.model.dpad;

import com.emc.gs.tools.srf.model.IdentifiableEntity;

/**
 * <p>
 * This is AvamarOptions entity class.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safety.
 * </p>
 * 
 * @author TCSASSEMBLER
 * @version 1.0
 * @since SRT Phase 3-5 - BRS Tabs Part 1 Assembly
 */
public class AvamarOptions extends IdentifiableEntity {

    /**
     * Represents whether "Configure Avamar Clients" option is selected.
     */
    private boolean configureClients;

    /**
     * Represents whether "Configure Avamar NDMP" option is selected.
     */
    private boolean configureNDMP;

    /**
     * Represents whether "Configure Avamar AvF" option is selected.
     */
    private boolean configureAVF;

    /**
     * Represents whether "Configure Advanced Network Options" option is selected.
     */
    private boolean configureAdvancedNetwork;

    /**
     * Represents whether "Configure Avamar Download Server" option is selected.
     */
    private boolean configureDownloadServer;

    /**
     * Represents whether "Configure Avamar Replication" option is selected.
     */
    private boolean configureReplication;

    /**
     * Represents whether "VMware Integration" option is selected.
     */
    private boolean vmwareIntegeration;

    /**
     * Represents whether "Data Domain Integration" option is selected.
     */
    private boolean dataDomainIntegration;

    /**
     * Represents whether "Configure Avamar for vCloud Director Plug-in" option is selected.
     */
    private boolean configureVCloudDirector;

    /**
     * <p>
     * The default constructor.
     * </p>
     */
    public AvamarOptions() {
    }

    /**
     * Getter method for property <tt>configureClients</tt>.
     * 
     * @return property value of configureClients
     */
    public boolean isConfigureClients() {
        return configureClients;
    }

    /**
     * Setter method for property <tt>configureClients</tt>.
     * 
     * @param configureClients
     *            value to be assigned to property configureClients
     */
    public void setConfigureClients(boolean configureClients) {
        this.configureClients = configureClients;
    }

    /**
     * Getter method for property <tt>configureNDMP</tt>.
     * 
     * @return property value of configureNDMP
     */
    public boolean isConfigureNDMP() {
        return configureNDMP;
    }

    /**
     * Setter method for property <tt>configureNDMP</tt>.
     * 
     * @param configureNDMP
     *            value to be assigned to property configureNDMP
     */
    public void setConfigureNDMP(boolean configureNDMP) {
        this.configureNDMP = configureNDMP;
    }

    /**
     * Getter method for property <tt>configureAVF</tt>.
     * 
     * @return property value of configureAVF
     */
    public boolean isConfigureAVF() {
        return configureAVF;
    }

    /**
     * Setter method for property <tt>configureAVF</tt>.
     * 
     * @param configureAVF
     *            value to be assigned to property configureAVF
     */
    public void setConfigureAVF(boolean configureAVF) {
        this.configureAVF = configureAVF;
    }

    /**
     * Getter method for property <tt>configureAdvancedNetwork</tt>.
     * 
     * @return property value of configureAdvancedNetwork
     */
    public boolean isConfigureAdvancedNetwork() {
        return configureAdvancedNetwork;
    }

    /**
     * Setter method for property <tt>configureAdvancedNetwork</tt>.
     * 
     * @param configureAdvancedNetwork
     *            value to be assigned to property configureAdvancedNetwork
     */
    public void setConfigureAdvancedNetwork(boolean configureAdvancedNetwork) {
        this.configureAdvancedNetwork = configureAdvancedNetwork;
    }

    /**
     * Getter method for property <tt>configureDownloadServer</tt>.
     * 
     * @return property value of configureDownloadServer
     */
    public boolean isConfigureDownloadServer() {
        return configureDownloadServer;
    }

    /**
     * Setter method for property <tt>configureDownloadServer</tt>.
     * 
     * @param configureDownloadServer
     *            value to be assigned to property configureDownloadServer
     */
    public void setConfigureDownloadServer(boolean configureDownloadServer) {
        this.configureDownloadServer = configureDownloadServer;
    }

    /**
     * Getter method for property <tt>configureReplication</tt>.
     * 
     * @return property value of configureReplication
     */
    public boolean isConfigureReplication() {
        return configureReplication;
    }

    /**
     * Setter method for property <tt>configureReplication</tt>.
     * 
     * @param configureReplication
     *            value to be assigned to property configureReplication
     */
    public void setConfigureReplication(boolean configureReplication) {
        this.configureReplication = configureReplication;
    }

    /**
     * Getter method for property <tt>vmwareIntegeration</tt>.
     * 
     * @return property value of vmwareIntegeration
     */
    public boolean isVmwareIntegeration() {
        return vmwareIntegeration;
    }

    /**
     * Setter method for property <tt>vmwareIntegeration</tt>.
     * 
     * @param vmwareIntegeration
     *            value to be assigned to property vmwareIntegeration
     */
    public void setVmwareIntegeration(boolean vmwareIntegeration) {
        this.vmwareIntegeration = vmwareIntegeration;
    }

    /**
     * Getter method for property <tt>dataDomainIntegration</tt>.
     * 
     * @return property value of dataDomainIntegration
     */
    public boolean isDataDomainIntegration() {
        return dataDomainIntegration;
    }

    /**
     * Setter method for property <tt>dataDomainIntegration</tt>.
     * 
     * @param dataDomainIntegration
     *            value to be assigned to property dataDomainIntegration
     */
    public void setDataDomainIntegration(boolean dataDomainIntegration) {
        this.dataDomainIntegration = dataDomainIntegration;
    }

    /**
     * Getter method for property <tt>configureVCloudDirector</tt>.
     * 
     * @return property value of configureVCloudDirector
     */
    public boolean isConfigureVCloudDirector() {
        return configureVCloudDirector;
    }

    /**
     * Setter method for property <tt>configureVCloudDirector</tt>.
     * 
     * @param configureVCloudDirector
     *            value to be assigned to property configureVCloudDirector
     */
    public void setConfigureVCloudDirector(boolean configureVCloudDirector) {
        this.configureVCloudDirector = configureVCloudDirector;
    }

}

/*
 * This code is copyright (c) 2014 EMC Corporation.
 */
package com.emc.gs.tools.srf.model.bc;


/**
 * <p>
 * This is source array information for MirrorViewInformation entity.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safety.
 * </p>
 * 
 * <p>
 * <strong>Changes V1.1:</strong>
 * <ul>
 * <li>Removed bcvR2ClonesNumber, targetName fields.</li>
 * </ul>
 * </p>
 *
 * @author faeton, TCSASSEMBLER, MonicaMuranyi
 * @version 1.1
 * @since SRT Release Assembly - BC Tab
 */
public class MirrorViewSourceArrayInformation extends MirrorViewBaseArrayInformation {

    /**
     * <p>
     * The replicateSize.
     * </p>
     */
    private Integer replicateSize;

    /**
     * <p>
     * The uniOptionEnabled.
     * </p>
     */
    private Boolean uniOptionEnabled;

    /**
     * <p>
     * The mvConnectionType.
     * </p>
     */
    private MvConnectionType mvConnectionType;

    /**
     * Empty constructor.
     */
    public MirrorViewSourceArrayInformation() {
    }

    /**
     * Getter method for property <tt>replicateSize</tt>.
     * @return property value of replicateSize
     */
    public Integer getReplicateSize() {
        return replicateSize;
    }

    /**
     * Getter method for property <tt>uniOptionEnabled</tt>.
     * @return property value of uniOptionEnabled
     */
    public Boolean getUniOptionEnabled() {
        return uniOptionEnabled;
    }

    /**
     * Getter method for property <tt>mvConnectionType</tt>.
     * @return property value of mvConnectionType
     */
    public MvConnectionType getMvConnectionType() {
        return mvConnectionType;
    }

    /**
     * Setter method for property <tt>replicateSize</tt>.
     * @param replicateSize value to be assigned to property replicateSize
     */
    public void setReplicateSize(Integer replicateSize) {
        this.replicateSize = replicateSize;
    }

    /**
     * Setter method for property <tt>uniOptionEnabled</tt>.
     * @param uniOptionEnabled value to be assigned to property uniOptionEnabled
     */
    public void setUniOptionEnabled(Boolean uniOptionEnabled) {
        this.uniOptionEnabled = uniOptionEnabled;
    }

    /**
     * Setter method for property <tt>mvConnectionType</tt>.
     * @param mvConnectionType value to be assigned to property mvConnectionType
     */
    public void setMvConnectionType(MvConnectionType mvConnectionType) {
        this.mvConnectionType = mvConnectionType;
    }

    /**
     * The toString method.
     *
     * @return the string for this entity
     */
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("{").append(super.toString());
        sb.append(", replicateSize:").append(replicateSize);
        sb.append(", uniOptionEnabled:").append(uniOptionEnabled);
        sb.append(", mvConnectionType:").append(mvConnectionType).append("}");
        return sb.toString();
    }

}

/*
 * This code is copyright (c) 2013 - 2015 EMC Corporation.
 */
package com.emc.gs.tools.srf.model;

/**
 * <p>
 * This is RequestStatus enum class.
 * </p>
 * <p>
 * Changes in version 1.1 (SRT 1.1 FEB 2015 Updates - Template Folder Assembly):
 * <ul>
 * <li>Added TEMPLATE status.</li>
 * </ul>
 * </p>
 * <p>
 * <strong>Thread safety</strong>: It's immutable and thread safe.
 * </p>
 * 
 * <p>
 * <strong>Changes V1.2:</strong>
 * <strong>SRT 1.1 Approval Process Assembly</strong>
 * <ul>
 * <li>Added new PENDING status.</li>
 * </ul>
 * </p>
 * 
 * @author faeton, stevenfrog, duxiaoyang, MonicaMuranyi
 * @version 1.2
 * @since 1.0
 */
public enum RequestStatus {
    /**
     * <p>
     * The DRAFT.
     * </p>
     */
    DRAFT,

    /**
     * <p>
     * The SUBMITTED.
     * </p>
     */
    SUBMITTED,
    
    /**
     * <p>
     * The PENDING.
     * </p>
     * @since 1.2
     */
    PENDING,

    /**
     * <p>
     * The GLOBAL TEMPLATE FOLDER.
     * </p>
     */
    TEMPLATE
}

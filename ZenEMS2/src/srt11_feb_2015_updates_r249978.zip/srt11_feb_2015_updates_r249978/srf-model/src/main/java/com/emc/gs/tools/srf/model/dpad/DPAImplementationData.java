/*
 * This code is copyright (c) 2014 EMC Corporation
 */
package com.emc.gs.tools.srf.model.dpad;

/**
 * <p>
 * This is DPAImplementationData entity class.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safety.
 * </p>
 * 
 * @author TCSASSEMBLER
 * @version 1.0
 * @since SRT Phase 3-5 - BRS Tabs Part 2 Assembly
 */
public class DPAImplementationData {

    /**
     * Install Data Protection Advisor on External Database (Oracle, MS SQL, etc.).
     */
    private Boolean installOnExternalDatabase;

    /**
     * Include Data Protection Advisor EDL Monitoring.
     */
    private Boolean includeEDLMonitoring;

    /**
     * # of Data Protection Advisor Collection Nodes.
     */
    private Integer collectionNodesNum;

    /**
     * # of Data Protection Collector Nodes to Configure.
     */
    private Integer collectorNodesNum;

    /**
     * # of EMC Disk Libraries.
     */
    private Integer emcDiskLibrariesNum;

    /**
     * <p>
     * The default constructor.
     * </p>
     */
    public DPAImplementationData() {
    }

    /**
     * Getter method for property <tt>installOnExternalDatabase</tt>.
     * 
     * @return property value of installOnExternalDatabase
     */
    public Boolean getInstallOnExternalDatabase() {
        return installOnExternalDatabase;
    }

    /**
     * Setter method for property <tt>installOnExternalDatabase</tt>.
     * 
     * @param installOnExternalDatabase
     *            value to be assigned to property installOnExternalDatabase
     */
    public void setInstallOnExternalDatabase(Boolean installOnExternalDatabase) {
        this.installOnExternalDatabase = installOnExternalDatabase;
    }

    /**
     * Getter method for property <tt>includeEDLMonitoring</tt>.
     * 
     * @return property value of includeEDLMonitoring
     */
    public Boolean getIncludeEDLMonitoring() {
        return includeEDLMonitoring;
    }

    /**
     * Setter method for property <tt>includeEDLMonitoring</tt>.
     * 
     * @param includeEDLMonitoring
     *            value to be assigned to property includeEDLMonitoring
     */
    public void setIncludeEDLMonitoring(Boolean includeEDLMonitoring) {
        this.includeEDLMonitoring = includeEDLMonitoring;
    }

    /**
     * Getter method for property <tt>collectionNodesNum</tt>.
     * 
     * @return property value of collectionNodesNum
     */
    public Integer getCollectionNodesNum() {
        return collectionNodesNum;
    }

    /**
     * Setter method for property <tt>collectionNodesNum</tt>.
     * 
     * @param collectionNodesNum
     *            value to be assigned to property collectionNodesNum
     */
    public void setCollectionNodesNum(Integer collectionNodesNum) {
        this.collectionNodesNum = collectionNodesNum;
    }

    /**
     * Getter method for property <tt>collectorNodesNum</tt>.
     * 
     * @return property value of collectorNodesNum
     */
    public Integer getCollectorNodesNum() {
        return collectorNodesNum;
    }

    /**
     * Setter method for property <tt>collectorNodesNum</tt>.
     * 
     * @param collectorNodesNum
     *            value to be assigned to property collectorNodesNum
     */
    public void setCollectorNodesNum(Integer collectorNodesNum) {
        this.collectorNodesNum = collectorNodesNum;
    }

    /**
     * Getter method for property <tt>emcDiskLibrariesNum</tt>.
     * 
     * @return property value of emcDiskLibrariesNum
     */
    public Integer getEmcDiskLibrariesNum() {
        return emcDiskLibrariesNum;
    }

    /**
     * Setter method for property <tt>emcDiskLibrariesNum</tt>.
     * 
     * @param emcDiskLibrariesNum
     *            value to be assigned to property emcDiskLibrariesNum
     */
    public void setEmcDiskLibrariesNum(Integer emcDiskLibrariesNum) {
        this.emcDiskLibrariesNum = emcDiskLibrariesNum;
    }

}

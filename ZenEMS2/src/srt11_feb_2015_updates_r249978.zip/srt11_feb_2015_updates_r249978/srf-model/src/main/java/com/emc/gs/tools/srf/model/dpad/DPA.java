/*
 * This code is copyright (c) 2014 EMC Corporation
 */
package com.emc.gs.tools.srf.model.dpad;

import java.math.BigDecimal;

import com.emc.gs.tools.srf.model.IdentifiableEntity;

/**
 * <p>
 * This is DPA entity class.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safety.
 * </p>
 *
 * <p>
 * Version 1.1 (SRT 4 OCT2014 Updates Part 1 Assembly) Change notes:
 *   <ol>
 *     <li>Removed <code>enableRetentionLocking</code> property.</li>
 *   </ol>
 * </p>
 * 
 * @author isv
 * @version 1.1
 * @since SRT Phase 3-5 - BRS Tabs Part 2 Assembly
 */
public class DPA extends IdentifiableEntity {

    /**
     * # of Hours of Knowledge Transfer.
     */
    private BigDecimal knowledgeTransferHours;

    /**
     * Represents whether "Implement Data Protection Advisor" service is selected.
     */
    private boolean implementService;

    /**
     * Represents whether "Operational Assurance for Data Protection Advisor" service is selected.
     */
    private boolean operationalAssuranceService;

    /**
     * Represents whether "Customization for Data Protection Advisor" service is selected.
     */
    private boolean customizationService;

    /**
     * Represents whether "Upgrade and Migration for Data Protection Advisor" service is selected.
     */
    private boolean upgradeMigrationService;

    /**
     * Represents whether "Health Check for Data Protection Advisor" service is selected.
     */
    private boolean healthCheckService;

    /**
     * Represents whether "Design" activity type is selected.
     */
    private boolean designActivity;

    /**
     * Represents whether "Implementation" activity type is selected.
     */
    private boolean implementationActivity;

    /**
     * Data Protection Advisor Design.
     */
    private DPADesign design;

    /**
     * Data Protection Advisor Implementation.
     */
    private DPAImplementation implementation;

    /**
     * Data Protection Advisor Operational Assurance.
     */
    private DPAOperationalAssurance operationalAssurance;

    /**
     * Data Protection Advisor Customization.
     */
    private DPACustomization customization;

    /**
     * Data Protection Advisor Upgrade And Migration.
     */
    private DPAUpgradeMigration upgradeMigration;

    /**
     * Data Protection Advisor Health Check.
     */
    private DPAHealthCheck healthCheck;

    /**
     * <p>
     * The default constructor.
     * </p>
     */
    public DPA() {
    }

    /**
     * Getter method for property <tt>knowledgeTransferHours</tt>.
     * 
     * @return property value of knowledgeTransferHours
     */
    public BigDecimal getKnowledgeTransferHours() {
        return knowledgeTransferHours;
    }

    /**
     * Setter method for property <tt>knowledgeTransferHours</tt>.
     * 
     * @param knowledgeTransferHours
     *            value to be assigned to property knowledgeTransferHours
     */
    public void setKnowledgeTransferHours(BigDecimal knowledgeTransferHours) {
        this.knowledgeTransferHours = knowledgeTransferHours;
    }

    /**
     * Getter method for property <tt>implementService</tt>.
     * 
     * @return property value of implementService
     */
    public boolean isImplementService() {
        return implementService;
    }

    /**
     * Setter method for property <tt>implementService</tt>.
     * 
     * @param implementService
     *            value to be assigned to property implementService
     */
    public void setImplementService(boolean implementService) {
        this.implementService = implementService;
    }

    /**
     * Getter method for property <tt>operationalAssuranceService</tt>.
     * 
     * @return property value of operationalAssuranceService
     */
    public boolean isOperationalAssuranceService() {
        return operationalAssuranceService;
    }

    /**
     * Setter method for property <tt>operationalAssuranceService</tt>.
     * 
     * @param operationalAssuranceService
     *            value to be assigned to property operationalAssuranceService
     */
    public void setOperationalAssuranceService(boolean operationalAssuranceService) {
        this.operationalAssuranceService = operationalAssuranceService;
    }

    /**
     * Getter method for property <tt>customizationService</tt>.
     * 
     * @return property value of customizationService
     */
    public boolean isCustomizationService() {
        return customizationService;
    }

    /**
     * Setter method for property <tt>customizationService</tt>.
     * 
     * @param customizationService
     *            value to be assigned to property customizationService
     */
    public void setCustomizationService(boolean customizationService) {
        this.customizationService = customizationService;
    }

    /**
     * Getter method for property <tt>upgradeMigrationService</tt>.
     * 
     * @return property value of upgradeMigrationService
     */
    public boolean isUpgradeMigrationService() {
        return upgradeMigrationService;
    }

    /**
     * Setter method for property <tt>upgradeMigrationService</tt>.
     * 
     * @param upgradeMigrationService
     *            value to be assigned to property upgradeMigrationService
     */
    public void setUpgradeMigrationService(boolean upgradeMigrationService) {
        this.upgradeMigrationService = upgradeMigrationService;
    }

    /**
     * Getter method for property <tt>healthCheckService</tt>.
     * 
     * @return property value of healthCheckService
     */
    public boolean isHealthCheckService() {
        return healthCheckService;
    }

    /**
     * Setter method for property <tt>healthCheckService</tt>.
     * 
     * @param healthCheckService
     *            value to be assigned to property healthCheckService
     */
    public void setHealthCheckService(boolean healthCheckService) {
        this.healthCheckService = healthCheckService;
    }

    /**
     * Getter method for property <tt>designActivity</tt>.
     * 
     * @return property value of designActivity
     */
    public boolean isDesignActivity() {
        return designActivity;
    }

    /**
     * Setter method for property <tt>designActivity</tt>.
     * 
     * @param designActivity
     *            value to be assigned to property designActivity
     */
    public void setDesignActivity(boolean designActivity) {
        this.designActivity = designActivity;
    }

    /**
     * Getter method for property <tt>implementationActivity</tt>.
     * 
     * @return property value of implementationActivity
     */
    public boolean isImplementationActivity() {
        return implementationActivity;
    }

    /**
     * Setter method for property <tt>implementationActivity</tt>.
     * 
     * @param implementationActivity
     *            value to be assigned to property implementationActivity
     */
    public void setImplementationActivity(boolean implementationActivity) {
        this.implementationActivity = implementationActivity;
    }

    /**
     * Getter method for property <tt>design</tt>.
     * 
     * @return property value of design
     */
    public DPADesign getDesign() {
        return design;
    }

    /**
     * Setter method for property <tt>design</tt>.
     * 
     * @param design
     *            value to be assigned to property design
     */
    public void setDesign(DPADesign design) {
        this.design = design;
    }

    /**
     * Getter method for property <tt>implementation</tt>.
     * 
     * @return property value of implementation
     */
    public DPAImplementation getImplementation() {
        return implementation;
    }

    /**
     * Setter method for property <tt>implementation</tt>.
     * 
     * @param implementation
     *            value to be assigned to property implementation
     */
    public void setImplementation(DPAImplementation implementation) {
        this.implementation = implementation;
    }

    /**
     * Getter method for property <tt>operationalAssurance</tt>.
     * 
     * @return property value of operationalAssurance
     */
    public DPAOperationalAssurance getOperationalAssurance() {
        return operationalAssurance;
    }

    /**
     * Setter method for property <tt>operationalAssurance</tt>.
     * 
     * @param operationalAssurance
     *            value to be assigned to property operationalAssurance
     */
    public void setOperationalAssurance(DPAOperationalAssurance operationalAssurance) {
        this.operationalAssurance = operationalAssurance;
    }

    /**
     * Getter method for property <tt>customization</tt>.
     * 
     * @return property value of customization
     */
    public DPACustomization getCustomization() {
        return customization;
    }

    /**
     * Setter method for property <tt>customization</tt>.
     * 
     * @param customization
     *            value to be assigned to property customization
     */
    public void setCustomization(DPACustomization customization) {
        this.customization = customization;
    }

    /**
     * Getter method for property <tt>upgradeMigration</tt>.
     * 
     * @return property value of upgradeMigration
     */
    public DPAUpgradeMigration getUpgradeMigration() {
        return upgradeMigration;
    }

    /**
     * Setter method for property <tt>upgradeMigration</tt>.
     * 
     * @param upgradeMigration
     *            value to be assigned to property upgradeMigration
     */
    public void setUpgradeMigration(DPAUpgradeMigration upgradeMigration) {
        this.upgradeMigration = upgradeMigration;
    }

    /**
     * Getter method for property <tt>healthCheck</tt>.
     * 
     * @return property value of healthCheck
     */
    public DPAHealthCheck getHealthCheck() {
        return healthCheck;
    }

    /**
     * Setter method for property <tt>healthCheck</tt>.
     * 
     * @param healthCheck
     *            value to be assigned to property healthCheck
     */
    public void setHealthCheck(DPAHealthCheck healthCheck) {
        this.healthCheck = healthCheck;
    }

}

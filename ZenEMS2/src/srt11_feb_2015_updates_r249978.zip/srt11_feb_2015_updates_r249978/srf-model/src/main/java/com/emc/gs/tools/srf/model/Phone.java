/*
 * Copyright (C) 2014 TopCoder Inc., All Rights Reserved.
 */
package com.emc.gs.tools.srf.model;

/**
 * <p>
 * This is Phone class.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safety.
 * </p>
 * @author TCSASSEMBLER
 * @version 1.0
 * @since SRT Phase 2 Release Assembly
 */
public class Phone {

    /**
     * The country code.
     */
    private String countryCode;

    /**
     * The phone number.
     */
    private String phoneNumber;

    /**
     * Empty constructor.
     */
    public Phone() {
    }

    /**
     * Constructor with country code and phone number.
     * @param countryCode
     *            country code
     * @param phoneNumber
     *            phone number
     */
    public Phone(String countryCode, String phoneNumber) {
        this.countryCode = countryCode;
        this.phoneNumber = phoneNumber;
    }

    /**
     * Getter method for property <tt>countryCode</tt>.
     * @return property value of countryCode
     */
    public String getCountryCode() {
        return countryCode;
    }

    /**
     * Setter method for property <tt>countryCode</tt>.
     * @param countryCode
     *            value to be assigned to property countryCode
     */
    public void setCountryCode(String countryCode) {
        this.countryCode = countryCode;
    }

    /**
     * Getter method for property <tt>phoneNumber</tt>.
     * @return property value of phoneNumber
     */
    public String getPhoneNumber() {
        return phoneNumber;
    }

    /**
     * Setter method for property <tt>phoneNumber</tt>.
     * @param phoneNumber
     *            value to be assigned to property phoneNumber
     */
    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    /**
     * The toString method.
     * @return the string of this entity
     */
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        if (countryCode != null && !countryCode.isEmpty()) {
            sb.append(countryCode);
            sb.append(" ");
        }
        sb.append(phoneNumber == null ? "" : phoneNumber);
        return sb.toString();
    }
}

/*
 * This code is copyright (c) 2013 - 2014 EMC Corporation.
 */
package com.emc.gs.tools.srf.model;


/**
 * <p>
 * This is Division entity class.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safety.
 * </p>
 *
 * <p>
 * Version 1.1 Change notes:
 *   <ol>
 *     <li>Added {@link #strictProfileSearch} property.</li>
 *     <li>Added {@link #theater} property.</li>
 *   </ol>
 * </p>
 *
 * @author faeton, stevenfrog, isv
 * @version 1.1
 */
public class Division extends IdentifiableEntity {
    /**
     * <p>
     * The divisionName.
     * </p>
     */
    private String divisionName;

    /**
     * <p>
     * The shortName.
     * </p>
     */
    private String shortName;

    /**
     * <p>
     * The email address where the request should be mailed to when submit.
     * </p>
     */
    private String emailAddress;

    /**
     * <p>A <code>Boolean</code> providing the value for strictProfileSearch property.</p>
     * 
     * @since 1.1
     */
    private Boolean strictProfileSearch;

    /**
     * <p>A <code>Geography</code> providing the value for theater property.</p>
     * 
     * @since 1.1
     */
    private Geography theater;

    /**
     * <p>
     * The default constructor.
     * </p>
     */
    public Division() {
        // Empty
    }

    /**
     * <p>
     * Retrieves the divisionName field.
     * </p>
     *
     * @return the divisionName
     */
    public String getDivisionName() {
        return divisionName;
    }

    /**
     * <p>
     * Sets the value to divisionName field.
     * </p>
     *
     * @param divisionName
     *            the divisionName to set
     */
    public void setDivisionName(String divisionName) {
        this.divisionName = divisionName;
    }

    /**
     * Getter method for property <tt>shortName</tt>.
     * @return property value of shortName
     */
    public String getShortName() {
        return shortName;
    }

    /**
     * Setter method for property <tt>shortName</tt>.
     * @param shortName value to be assigned to property shortName
     */
    public void setShortName(String shortName) {
        this.shortName = shortName;
    }

    /**
     * Getter method for property <tt>emailAddress</tt>.
     * @return property value of emailAddress
     */
    public String getEmailAddress() {
        return emailAddress;
    }

    /**
     * Setter method for property <tt>emailAddress</tt>.
     * @param emailAddress value to be assigned to property emailAddress
     */
    public void setEmailAddress(String emailAddress) {
        this.emailAddress = emailAddress;
    }

    /**
     * <p>Gets the strictProfileSearch property.</p>
     *
     * @return a <code>Boolean</code> providing the value for strictProfileSearch property.
     * @since 1.1
     */
    public Boolean getStrictProfileSearch() {
        return this.strictProfileSearch;
    }

    /**
     * <p>Sets the strictProfileSearch property.</p>
     *
     * @param strictProfileSearch a <code>Boolean</code> providing the value for strictProfileSearch property.
     * @since 1.1
     */
    public void setStrictProfileSearch(Boolean strictProfileSearch) {
        this.strictProfileSearch = strictProfileSearch;
    }

    /**
     * <p>Gets the theater property.</p>
     *
     * @return a <code>Geography</code> providing the value for theater property.
     * @since 1.1
     */
    public Geography getTheater() {
        return this.theater;
    }

    /**
     * <p>Sets the theater property.</p>
     *
     * @param theater a <code>Geography</code> providing the value for theater property.
     * @since 1.1
     */
    public void setTheater(Geography theater) {
        this.theater = theater;
    }

    /**
     * The toString method.
     *
     * @return the string of this entity
     */
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("{").append(super.toString());
        sb.append("emailAddress:").append(emailAddress);
        sb.append(", shortName:").append(shortName);
        sb.append(", divisionName:").append(divisionName);
        sb.append(", strictProfileSearch:").append(strictProfileSearch);
        sb.append(", theater:").append(theater);
        sb.append("}");
        return sb.toString();
    }

}

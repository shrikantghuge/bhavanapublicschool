/*
 * This code is copyright (c) 2014 EMC Corporation.
 */
package com.emc.gs.tools.srf.model;

import com.emc.gs.tools.srf.model.engagement.DeliveryCountry;

/**
 * <p>
 * This is Region entity class.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safety.
 * </p>
 * 
 * @author MonicaMuranyi
 * @since SRT 1.1 DEC 2014 Updates Assembly
 * @version 1.0
 */
public class Region extends LookupCodeEntity {

    /**
     * The country attribute.
     */
    private DeliveryCountry country;
    
    /**
     * <p>
     * The default constructor.
     * </p>
     */
    public Region() {
        // Empty
    }

    /**
     * <p>
     * Retrieves the country field.
     * </p>
     *
     * @return the country
     */
    public DeliveryCountry getCountry() {
        return country;
    }

    /**
     * <p>
     * Sets the value to country field.
     * </p>
     *
     * @param country the country to set
     */
    public void setCountry(DeliveryCountry country) {
        this.country = country;
    }
}

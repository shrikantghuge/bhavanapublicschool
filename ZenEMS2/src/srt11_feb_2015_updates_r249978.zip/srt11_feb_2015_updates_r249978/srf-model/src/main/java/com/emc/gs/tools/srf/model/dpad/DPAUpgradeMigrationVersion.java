/*
 * This code is copyright (c) 2014 EMC Corporation
 */
package com.emc.gs.tools.srf.model.dpad;

/**
 * The Data Protection Advisor Version for Upgrade / Migration enum.
 * <p>
 * <strong>Thread safety</strong>: Enum is thread safety.
 * </p>
 *
 * @author TCSASSEMBLER
 * @version 1.0
 * @since SRT Phase 3-5 - BRS Tabs Part 2 Assembly
 */
public enum DPAUpgradeMigrationVersion {

    /**
     * Data Protection Advisor 5.5 or Later.
     */
    LATER_55("Data Protection Advisor 5.5 or Later"),

    /**
     * Prior Data Protection Advisor 5.5 Version.
     */
    PRIOR_55("Prior Data Protection Advisor 5.5 Version");

    /**
     * The description.
     */
    private final String description;

    /**
     * <p>
     * The constructor with description.
     * </p>
     * 
     * @param description
     *            the description
     */
    private DPAUpgradeMigrationVersion(String description) {
        this.description = description;
    }

    /**
     * Override the toString method.
     * 
     * @return the description
     */
    @Override
    public String toString() {
        return description;
    }

}

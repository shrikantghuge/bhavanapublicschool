/*
 * This code is copyright (c) 2015 EMC Corporation.
 */
package com.emc.gs.tools.srf.model;

/**
 * <p>This is DataCenterLocationsAnalysisNumber entity class.</p>
 *
 * <p><strong>Thread safety</strong>: This class is mutable, it is not thread safety.</p>
 *
 * @author isv
 */
public class DataCenterLocationsAnalysisNumber extends LookupEntity {

    /**
     * <p>Constructs new <code>DataCenterLocationsAnalysisNumber</code> instance. This implementation does nothing.</p>
     */
    public DataCenterLocationsAnalysisNumber() {
    }

}

/*
 * This code is copyright (c) 2013 - 2014 EMC Corporation.
 */
package com.emc.gs.tools.srf.model.bc;

import com.emc.gs.tools.srf.model.LookupEntity;

/**
 * <p>
 * This is MvConnectionType entity class.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safety.
 * </p>
 *
 * @author faeton, stevenfrog
 * @version 1.0
 */
public class MvConnectionType extends LookupEntity {
    /**
     * <p>
     * The default constructor.
     * </p>
     */
    public MvConnectionType() {
        // Empty
    }
}

/*
 * This code is copyright (c) 2014 EMC Corporation
 */
package com.emc.gs.tools.srf.model.dpad;

import java.math.BigDecimal;

import com.emc.gs.tools.srf.model.IdentifiableEntity;

/**
 * <p>
 * This is EDL entity class.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safety.
 * </p>
 * 
 * @author TCSASSEMBLER
 * @version 1.0
 * @since SRT Phase 3-5 - BRS Tabs Part 1 Assembly
 */
public class EDL extends IdentifiableEntity {

    /**
     * # of Hours of Knowledge Transfer.
     */
    private BigDecimal knowledgeTransferHours;

    /**
     * Represents whether "Design" activity Type is selected.
     */
    private boolean design;

    /**
     * Represents whether "Implementation" activity Type is selected.
     */
    private boolean implementation;

    /**
     * EMC DISK LIBRARY DESIGN AND IMPLEMENTATION.
     */
    private EDLDesignImpl designImpl;

    /**
     * <p>
     * The default constructor.
     * </p>
     */
    public EDL() {
    }

    /**
     * Getter method for property <tt>knowledgeTransferHours</tt>.
     * 
     * @return property value of knowledgeTransferHours
     */
    public BigDecimal getKnowledgeTransferHours() {
        return knowledgeTransferHours;
    }

    /**
     * Setter method for property <tt>knowledgeTransferHours</tt>.
     * 
     * @param knowledgeTransferHours
     *            value to be assigned to property knowledgeTransferHours
     */
    public void setKnowledgeTransferHours(BigDecimal knowledgeTransferHours) {
        this.knowledgeTransferHours = knowledgeTransferHours;
    }

    /**
     * Getter method for property <tt>design</tt>.
     * 
     * @return property value of design
     */
    public boolean isDesign() {
        return design;
    }

    /**
     * Setter method for property <tt>design</tt>.
     * 
     * @param design
     *            value to be assigned to property design
     */
    public void setDesign(boolean design) {
        this.design = design;
    }

    /**
     * Getter method for property <tt>implementation</tt>.
     * 
     * @return property value of implementation
     */
    public boolean isImplementation() {
        return implementation;
    }

    /**
     * Setter method for property <tt>implementation</tt>.
     * 
     * @param implementation
     *            value to be assigned to property implementation
     */
    public void setImplementation(boolean implementation) {
        this.implementation = implementation;
    }

    /**
     * Getter method for property <tt>designImpl</tt>.
     * 
     * @return property value of designImpl
     */
    public EDLDesignImpl getDesignImpl() {
        return designImpl;
    }

    /**
     * Setter method for property <tt>designImpl</tt>.
     * 
     * @param designImpl
     *            value to be assigned to property designImpl
     */
    public void setDesignImpl(EDLDesignImpl designImpl) {
        this.designImpl = designImpl;
    }

}

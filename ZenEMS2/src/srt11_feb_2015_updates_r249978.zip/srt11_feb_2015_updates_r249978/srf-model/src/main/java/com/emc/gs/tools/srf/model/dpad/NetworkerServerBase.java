/*
 * This code is copyright (c) 2014 EMC Corporation
 */
package com.emc.gs.tools.srf.model.dpad;

import com.emc.gs.tools.srf.model.IdentifiableEntity;

/**
 * <p>
 * This is NetworkerServerBase entity class.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safety.
 * </p>
 * 
 * @author TCSASSEMBLER
 * @version 1.0
 * @since SRT Phase 3-5 - BRS Tabs Part 3 Assembly
 */
public abstract class NetworkerServerBase extends IdentifiableEntity {

    /**
     * Select the Networker Implementation Environment.
     */
    private NetworkerImplEnv implEnv;

    /**
     * # of Networker Servers.
     */
    private Integer serversNum;

    /**
     * <p>
     * The default constructor.
     * </p>
     */
    protected NetworkerServerBase() {
    }

    /**
     * Getter method for property <tt>implEnv</tt>.
     * 
     * @return property value of implEnv
     */
    public NetworkerImplEnv getImplEnv() {
        return implEnv;
    }

    /**
     * Setter method for property <tt>implEnv</tt>.
     * 
     * @param implEnv
     *            value to be assigned to property implEnv
     */
    public void setImplEnv(NetworkerImplEnv implEnv) {
        this.implEnv = implEnv;
    }

    /**
     * Getter method for property <tt>serversNum</tt>.
     * 
     * @return property value of serversNum
     */
    public Integer getServersNum() {
        return serversNum;
    }

    /**
     * Setter method for property <tt>serversNum</tt>.
     * 
     * @param serversNum
     *            value to be assigned to property serversNum
     */
    public void setServersNum(Integer serversNum) {
        this.serversNum = serversNum;
    }

}

/*
 * This code is copyright (c) 2015 EMC Corporation.
 */
package com.emc.gs.tools.srf.model;

/**
 * <p>This is AssessmentData entity class.</p>
 *
 * <p><strong>Thread safety</strong>: This class is mutable, it is not thread safety.</p>
 *
 * @author isv
 */
public class AssessmentData extends IdentifiableEntity {

    /**
     * <p>A <code>NetworkingServiceTemplateType</code> providing the value for networkingServiceTemplateType
     * property.</p>
     */
    private NetworkingServiceTemplateType networkingServiceTemplateType;

    /**
     * <p>A <code>LANInfrastructureComplexityType</code> providing the value for customerLANInfrastructureComplexityType
     * property.</p>
     */
    private LANInfrastructureComplexityType customerLANInfrastructureComplexityType;

    /**
     * <p>A <code>DataCenterLocationsAnalysisNumber</code> providing the value for numberOfDataCenterLocations 
     * property.</p>
     */
    private DataCenterLocationsAnalysisNumber numberOfDataCenterLocations;

    /**
     * <p>A <code>Boolean</code> providing the value for resultsViewableByProjectSponsor property.</p>
     */
    private Boolean resultsViewableByProjectSponsor;

    /**
     * <p>Constructs new <code>AssessmentData</code> instance. This implementation does nothing.</p>
     */
    public AssessmentData() {
    }

    /**
     * <p>Gets the resultsViewableByProjectSponsor property.</p>
     *
     * @return a <code>Boolean</code> providing the value for resultsViewableByProjectSponsor property.
     */
    public Boolean getResultsViewableByProjectSponsor() {
        return this.resultsViewableByProjectSponsor;
    }

    /**
     * <p>Sets the resultsViewableByProjectSponsor property.</p>
     *
     * @param resultsViewableByProjectSponsor a <code>Boolean</code> providing the value for
     * resultsViewableByProjectSponsor property.
     */
    public void setResultsViewableByProjectSponsor(Boolean resultsViewableByProjectSponsor) {
        this.resultsViewableByProjectSponsor = resultsViewableByProjectSponsor;
    }

    /**
     * <p>Gets the numberOfDataCenterLocations property.</p>
     *
     * @return a <code>DataCenterLocationsAnalysisNumber</code> providing the value for numberOfDataCenterLocations 
     * property.
     */
    public DataCenterLocationsAnalysisNumber getNumberOfDataCenterLocations() {
        return this.numberOfDataCenterLocations;
    }

    /**
     * <p>Sets the numberOfDataCenterLocations property.</p>
     *
     * @param numberOfDataCenterLocations a <code>DataCenterLocationsAnalysisNumber</code> providing the value for
     * numberOfDataCenterLocations property.
     */
    public void setNumberOfDataCenterLocations(DataCenterLocationsAnalysisNumber numberOfDataCenterLocations) {
        this.numberOfDataCenterLocations = numberOfDataCenterLocations;
    }

    /**
     * <p>Gets the customerLANInfrastructureComplexityType property.</p>
     *
     * @return a <code>LANInfrastructureComplexityType</code> providing the value for 
     * customerLANInfrastructureComplexityType
     * property.
     */
    public LANInfrastructureComplexityType getCustomerLANInfrastructureComplexityType() {
        return this.customerLANInfrastructureComplexityType;
    }

    /**
     * <p>Sets the customerLANInfrastructureComplexityType property.</p>
     *
     * @param customerLANInfrastructureComplexityType a <code>LANInfrastructureComplexityType</code> providing the value
     * for customerLANInfrastructureComplexityType property.
     */
    public void setCustomerLANInfrastructureComplexityType(
        LANInfrastructureComplexityType customerLANInfrastructureComplexityType) {
        this.customerLANInfrastructureComplexityType = customerLANInfrastructureComplexityType;
    }

    /**
     * <p>Gets the networkingServiceTemplateType property.</p>
     *
     * @return a <code>NetworkingServiceTemplateType</code> providing the value for networkingServiceTemplateType
     * property.
     */
    public NetworkingServiceTemplateType getNetworkingServiceTemplateType() {
        return this.networkingServiceTemplateType;
    }

    /**
     * <p>Sets the networkingServiceTemplateType property.</p>
     *
     * @param networkingServiceTemplateType a <code>NetworkingServiceTemplateType</code> providing the value for
     * networkingServiceTemplateType property.
     */
    public void setNetworkingServiceTemplateType(NetworkingServiceTemplateType networkingServiceTemplateType) {
        this.networkingServiceTemplateType = networkingServiceTemplateType;
    }

}

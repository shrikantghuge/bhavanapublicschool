/*
 * This code is copyright (c) 2014 EMC Corporation.
 */
package com.emc.gs.tools.srf.model.engagement;

import com.emc.gs.tools.srf.model.DeliveryGeography;
import com.emc.gs.tools.srf.model.LookupCodeEntity;
import com.emc.gs.tools.srf.model.estimate.DealCurrency;

/**
 * <p>
 * This is DeliveryCountry entity class.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread
 * safety.
 * </p>
 * 
 * <p>
 * <strong>Changes V1.1:</strong>
 * <strong>SRT 1.1 DEC 2014 Updates Assembly</strong>
 * <ul>
 * <li>Added dealCurrency, geography, and callingCode fields.</li>
 * </ul>
 * </p>
 * 
 * @author TCSASSEMBLER, MonicaMuranyi
 * @version 1.1
 * @since SRT Phase 4 - ET Assembly 1
 */
public class DeliveryCountry extends LookupCodeEntity {

    /**
     * The deal currency.
     */
    private DealCurrency dealCurrency;

    /**
     * The geography.
     */
    private DeliveryGeography geography;

    /**
     * The callingCode.
     */
    private String callingCode;

    /**
     * Empty constructor.
     */
    public DeliveryCountry() {
    }

    /**
     * Getter method for property <tt>dealCurrency</tt>.
     * 
     * @return property value of dealCurrency
     */
    public DealCurrency getDealCurrency() {
        return dealCurrency;
    }

    /**
     * Setter method for property <tt>dealCurrency</tt>.
     * 
     * @param dealCurrency
     *            value to be assigned to property dealCurrency
     */
    public void setDealCurrency(DealCurrency dealCurrency) {
        this.dealCurrency = dealCurrency;
    }

    /**
     * Getter method for property <tt>geography</tt>.
     *
     * @return the geography
     */
    public DeliveryGeography getGeography() {
        return geography;
    }

    /**
     * Setter method for property <tt>geography</tt>.
     *
     * @param geography
     *            the geography to set
     */
    public void setGeography(DeliveryGeography geography) {
        this.geography = geography;
    }

    /**
     * Getter method for property <tt>callingCode</tt>.
     * 
     * @return the callingCode
     */
    public String getCallingCode() {
        return callingCode;
    }

    /**
     * Setter method for property <tt>callingCode</tt>.
     *
     * @param callingCode
     *            the callingCode to set
     */
    public void setCallingCode(String callingCode) {
        this.callingCode = callingCode;
    }
}

/*
 * This code is copyright (c) 2014 EMC Corporation
 */
package com.emc.gs.tools.srf.model.dpad;

/**
 * <p>
 * This is NetworkerAdvancedBackupTechImpl entity class.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safety.
 * </p>
 * 
 * @author TCSASSEMBLER
 * @version 1.0
 * @since SRT Phase 3-5 - BRS Tabs Part 3 Assembly
 */
public class NetworkerAdvancedBackupTechImpl extends NetworkerAdvancedBackupTechBase {

    /**
     * # of Networker SNMP Modules.
     */
    private Integer snmpModulesNum;

    /**
     * # of external Networker VMWare Protection Appliances.
     */
    private Integer externalVmwareProtectionAppliancesNum;

    /**
     * # of Virtual Machine Clients to be Backed Up using VMWare VADP.
     */
    private Integer virtualMachineClientsNum;

    /**
     * # of EMC Disk Arrays to be backed up with Networker Snapshot Management.
     */
    private Integer emcDiskArraysNum;

    /**
     * <p>
     * The default constructor.
     * </p>
     */
    public NetworkerAdvancedBackupTechImpl() {
    }

    /**
     * Getter method for property <tt>snmpModulesNum</tt>.
     * 
     * @return property value of snmpModulesNum
     */
    public Integer getSnmpModulesNum() {
        return snmpModulesNum;
    }

    /**
     * Setter method for property <tt>snmpModulesNum</tt>.
     * 
     * @param snmpModulesNum
     *            value to be assigned to property snmpModulesNum
     */
    public void setSnmpModulesNum(Integer snmpModulesNum) {
        this.snmpModulesNum = snmpModulesNum;
    }

    /**
     * Getter method for property <tt>externalVmwareProtectionAppliancesNum</tt>.
     * 
     * @return property value of externalVmwareProtectionAppliancesNum
     */
    public Integer getExternalVmwareProtectionAppliancesNum() {
        return externalVmwareProtectionAppliancesNum;
    }

    /**
     * Setter method for property <tt>externalVmwareProtectionAppliancesNum</tt>.
     * 
     * @param externalVmwareProtectionAppliancesNum
     *            value to be assigned to property externalVmwareProtectionAppliancesNum
     */
    public void setExternalVmwareProtectionAppliancesNum(Integer externalVmwareProtectionAppliancesNum) {
        this.externalVmwareProtectionAppliancesNum = externalVmwareProtectionAppliancesNum;
    }

    /**
     * Getter method for property <tt>virtualMachineClientsNum</tt>.
     * 
     * @return property value of virtualMachineClientsNum
     */
    public Integer getVirtualMachineClientsNum() {
        return virtualMachineClientsNum;
    }

    /**
     * Setter method for property <tt>virtualMachineClientsNum</tt>.
     * 
     * @param virtualMachineClientsNum
     *            value to be assigned to property virtualMachineClientsNum
     */
    public void setVirtualMachineClientsNum(Integer virtualMachineClientsNum) {
        this.virtualMachineClientsNum = virtualMachineClientsNum;
    }

    /**
     * Getter method for property <tt>emcDiskArraysNum</tt>.
     * 
     * @return property value of emcDiskArraysNum
     */
    public Integer getEmcDiskArraysNum() {
        return emcDiskArraysNum;
    }

    /**
     * Setter method for property <tt>emcDiskArraysNum</tt>.
     * 
     * @param emcDiskArraysNum
     *            value to be assigned to property emcDiskArraysNum
     */
    public void setEmcDiskArraysNum(Integer emcDiskArraysNum) {
        this.emcDiskArraysNum = emcDiskArraysNum;
    }

}

/*
 * This code is copyright (c) 2014 EMC Corporation.
 */
package com.emc.gs.tools.srf.model.dpad;

import com.emc.gs.tools.srf.model.IdentifiableEntity;

/**
 * <p>This is AvamarADMEConfiguration entity class.</p>
 *
 * <p><strong>Thread safety</strong>: This class is mutable, it is not thread safety.</p>
 *
 * @author isv
 */
public class AvamarADMEConfiguration extends IdentifiableEntity {

    /**
     * <p>A <code>Boolean</code> providing the value for includeCloudExtendedRetentionPathConfig property.</p>
     */
    private Boolean includeCloudExtendedRetentionPathConfig;

    /**
     * <p>A <code>Integer</code> providing the value for numberOfReplicationPairs property.</p>
     */
    private Integer numberOfReplicationPairs;

    /**
     * <p>A <code>Integer</code> providing the value for numberOfStagingServers property.</p>
     */
    private Integer numberOfStagingServers;

    /**
     * <p>A <code>Integer</code> providing the value for numberOfCloudExtendedRetentionPaths property.</p>
     */
    private Integer numberOfCloudExtendedRetentionPaths;

    /**
     * <p>Constructs new <code>AvamarADMEConfiguration</code> instance. This implementation does nothing.</p>
     */
    public AvamarADMEConfiguration() {
    }

    /**
     * <p>Gets the numberOfCloudExtendedRetentionPaths property.</p>
     *
     * @return a <code>Integer</code> providing the value for numberOfCloudExtendedRetentionPaths property.
     */
    public Integer getNumberOfCloudExtendedRetentionPaths() {
        return this.numberOfCloudExtendedRetentionPaths;
    }

    /**
     * <p>Sets the numberOfCloudExtendedRetentionPaths property.</p>
     *
     * @param numberOfCloudExtendedRetentionPaths a <code>Integer</code> providing the value for
     * numberOfCloudExtendedRetentionPaths property.
     */
    public void setNumberOfCloudExtendedRetentionPaths(Integer numberOfCloudExtendedRetentionPaths) {
        this.numberOfCloudExtendedRetentionPaths = numberOfCloudExtendedRetentionPaths;
    }

    /**
     * <p>Gets the numberOfStagingServers property.</p>
     *
     * @return a <code>Integer</code> providing the value for numberOfStagingServers property.
     */
    public Integer getNumberOfStagingServers() {
        return this.numberOfStagingServers;
    }

    /**
     * <p>Sets the numberOfStagingServers property.</p>
     *
     * @param numberOfStagingServers a <code>Integer</code> providing the value for numberOfStagingServers property.
     */
    public void setNumberOfStagingServers(Integer numberOfStagingServers) {
        this.numberOfStagingServers = numberOfStagingServers;
    }

    /**
     * <p>Gets the numberOfReplicationPairs property.</p>
     *
     * @return a <code>Integer</code> providing the value for numberOfReplicationPairs property.
     */
    public Integer getNumberOfReplicationPairs() {
        return this.numberOfReplicationPairs;
    }

    /**
     * <p>Sets the numberOfReplicationPairs property.</p>
     *
     * @param numberOfReplicationPairs a <code>Integer</code> providing the value for numberOfReplicationPairs
     * property.
     */
    public void setNumberOfReplicationPairs(Integer numberOfReplicationPairs) {
        this.numberOfReplicationPairs = numberOfReplicationPairs;
    }

    /**
     * <p>Gets the includeCloudExtendedRetentionPathConfig property.</p>
     *
     * @return a <code>Boolean</code> providing the value for includeCloudExtendedRetentionPathConfig property.
     */
    public Boolean getIncludeCloudExtendedRetentionPathConfig() {
        return this.includeCloudExtendedRetentionPathConfig;
    }

    /**
     * <p>Sets the includeCloudExtendedRetentionPathConfig property.</p>
     *
     * @param includeCloudExtendedRetentionPathConfig a <code>Boolean</code> providing the value for
     * includeCloudExtendedRetentionPathConfig property.
     */
    public void setIncludeCloudExtendedRetentionPathConfig(Boolean includeCloudExtendedRetentionPathConfig) {
        this.includeCloudExtendedRetentionPathConfig = includeCloudExtendedRetentionPathConfig;
    }

}

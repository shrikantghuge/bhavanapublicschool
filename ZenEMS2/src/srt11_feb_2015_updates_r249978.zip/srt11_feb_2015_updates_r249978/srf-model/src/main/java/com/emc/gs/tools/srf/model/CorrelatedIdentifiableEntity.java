/*
 * Copyright (C) 2014 TopCoder Inc., All Rights Reserved.
 */
package com.emc.gs.tools.srf.model;

/**
 * <p>
 * This is the CorrelatedIdentifiableEntity entity class.
 * </p>
 *
 * <p>
 * Correlated entities are tied to user, and have corresponding correlated entity
 * in cloud/local app.
 * </p>
 *
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safe.
 * </p>
 * 
 * @author TCSASSEMBLER
 * @version 1.0
 * @since SRT Phase 4 - ET Assembly 2
 */
public abstract class CorrelatedIdentifiableEntity extends IdentifiableEntity {

    /**
     * <p>
     * The correlated entity Id.
     * </p>
     * <p>
     * On cloud app, it represents the entity id in local app; On local app, it represents the entity id in cloud app.
     * </p>
     */
    private long correlatedId;

    /**
     * <p>
     * The unique user identifier to tie this record to a user.
     * </p>
     * <p>
     * The user identifier is same at both cloud/local sides for given entity.
     * </p>
     */
    private String userIdentifier;

    /**
     * Empty constructor.
     */
    protected CorrelatedIdentifiableEntity() {
    }

    /**
     * Getter method for property <tt>correlatedId</tt>.
     * 
     * @return property value of correlatedId
     */
    public long getCorrelatedId() {
        return correlatedId;
    }

    /**
     * Setter method for property <tt>correlatedId</tt>.
     * 
     * @param correlatedId
     *            value to be assigned to property correlatedId
     */
    public void setCorrelatedId(long correlatedId) {
        this.correlatedId = correlatedId;
    }

    /**
     * Getter method for property <tt>userIdentifier</tt>.
     * 
     * @return property value of userIdentifier
     */
    public String getUserIdentifier() {
        return userIdentifier;
    }

    /**
     * Setter method for property <tt>userIdentifier</tt>.
     * 
     * @param userIdentifier
     *            value to be assigned to property userIdentifier
     */
    public void setUserIdentifier(String userIdentifier) {
        this.userIdentifier = userIdentifier;
    }

}

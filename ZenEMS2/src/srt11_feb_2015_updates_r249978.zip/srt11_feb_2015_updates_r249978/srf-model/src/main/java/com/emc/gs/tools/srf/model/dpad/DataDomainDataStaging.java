/*
 * This code is copyright (c) 2014 EMC Corporation
 */
package com.emc.gs.tools.srf.model.dpad;

import com.emc.gs.tools.srf.model.IdentifiableEntity;

/**
 * <p>
 * This is DataDomainDataStaging entity class.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safety.
 * </p>
 * 
 * @author TCSASSEMBLER
 * @version 1.0
 * @since SRT Phase 3-5 - BRS Tabs Part 2 Assembly
 */
public class DataDomainDataStaging extends IdentifiableEntity {

    /**
     * Data Staging and Relocation Environment Type.
     */
    private DataDomainDataStagingType dataStagingType;

    /**
     * <p>
     * The default constructor.
     * </p>
     */
    public DataDomainDataStaging() {
    }

    /**
     * Getter method for property <tt>dataStagingType</tt>.
     * 
     * @return property value of dataStagingType
     */
    public DataDomainDataStagingType getDataStagingType() {
        return dataStagingType;
    }

    /**
     * Setter method for property <tt>dataStagingType</tt>.
     * 
     * @param dataStagingType
     *            value to be assigned to property dataStagingType
     */
    public void setDataStagingType(DataDomainDataStagingType dataStagingType) {
        this.dataStagingType = dataStagingType;
    }

}

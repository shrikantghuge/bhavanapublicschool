/*
 * This code is copyright (c) 2014 EMC Corporation.
 */
package com.emc.gs.tools.srf.model;

/**
 * <p>
 * This is the SynchronizedOperationLog entity class. It represents the
 * operation log from other side which has been synchronized.
 * </p>
 *
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safe.
 * </p>
 * 
 * @author TCSASSEMBLER
 * @version 1.0
 * @since SRT Phase 4 - ET Assembly 2
 */
public class SynchronizedOperationLog extends BaseOperationLog {

}

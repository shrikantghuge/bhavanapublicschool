/*
 * This code is copyright (c) 2013 - 2014 EMC Corporation.
 */
package com.emc.gs.tools.srf.model.bc;

import java.util.ArrayList;
import java.util.List;

import com.emc.gs.tools.srf.model.IdentifiableEntity;
import com.emc.gs.tools.srf.model.unified.NasIpReplicationInformation;

/**
 * <p>
 * This is BcRequestData entity class.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safety.
 * </p>
 * <p>
 * <strong>Changes V1.1:</strong> <strong>SRT Bug Fixes - F121, F153, F154, F162</strong>
 * <ul>
 * <li>Remove knowledgeTransferDays field (the value will be calculated from the sub-sections).</li>
 * </ul>
 * </p>
 * <p>
 * <strong>Changes V1.2:</strong>
 * <strong>SRT Phase 3-1 - CTA Rainfinity and MSS Tabs Update Assembly</strong>
 * <ul>
 * <li>Add generalComment field.</li>
 * </ul>
 * </p>
 *
 * <p>
 * <strong>Changes V1.3:</strong>
 * <strong>SRT Phase 3-5 - BRS Tabs Part 1 Assembly</strong>
 * <ul>
 * <li>Remove recoverPoint field.</li>
 * </ul>
 * </p>
 * 
 * @author faeton, stevenfrog, MonicaMuranyi, TCSASSEMBLER
 * @version 1.3
 */
public class BcRequestData extends IdentifiableEntity {

    /**
     * General comment.
     */
    private String generalComment;

    /**
     * <p>
     * The servicesScope.
     * </p>
     */
    private BCServicesScope servicesScope;

    /**
     * <p>
     * The srdfInformation.
     * </p>
     */
    private SrdfInformation srdfInformation;

    /**
     * <p>
     * The timeFinderInformation.
     * </p>
     */
    private TimeFinderInformation timeFinderInformation;

    /**
     * <p>
     * The mirrorViewInformation.
     * </p>
     */
    private MirrorViewInformation mirrorViewInformation;

    /**
     * <p>
     * The snapViewInformation.
     * </p>
     */
    private SnapViewInformation snapViewInformation;

    /**
     * <p>
     * The replicationManagerInformation.
     * </p>
     */
    private ReplicationManagerInformation replicationManagerInformation;

    /**
     * <p>
     * The nasIpReplicationInformation.
     * </p>
     */
    private List<NasIpReplicationInformation> nasIpReplicationInformation = new ArrayList<NasIpReplicationInformation>();
    /**
     * <p>
     * The nasIpReplicationKnowledgeTransferHours.
     * </p>
     */
    private String nasIpReplicationKnowledgeTransferHours;

    /**
     * <p>
     * The default constructor.
     * </p>
     */
    public BcRequestData() {
        // Empty
    }

    /**
     * Getter method for property <tt>generalComment</tt>.
     * 
     * @return property value of generalComment
     */
    public String getGeneralComment() {
        return generalComment;
    }

    /**
     * Setter method for property <tt>generalComment</tt>.
     * 
     * @param generalComment
     *            value to be assigned to property generalComment
     */
    public void setGeneralComment(String generalComment) {
        this.generalComment = generalComment;
    }

    /**
     * <p>
     * Retrieves the servicesScope field.
     * </p>
     * 
     * @return the servicesScope
     */
    public BCServicesScope getServicesScope() {
        return servicesScope;
    }

    /**
     * <p>
     * Sets the value to servicesScope field.
     * </p>
     * 
     * @param servicesScope
     *            the servicesScope to set
     */
    public void setServicesScope(BCServicesScope servicesScope) {
        this.servicesScope = servicesScope;
    }

    /**
     * <p>
     * Retrieves the srdfInformation field.
     * </p>
     * 
     * @return the srdfInformation
     */
    public SrdfInformation getSrdfInformation() {
        return srdfInformation;
    }

    /**
     * <p>
     * Sets the value to srdfInformation field.
     * </p>
     * 
     * @param srdfInformation
     *            the srdfInformation to set
     */
    public void setSrdfInformation(SrdfInformation srdfInformation) {
        this.srdfInformation = srdfInformation;
    }

    /**
     * <p>
     * Retrieves the timeFinderInformation field.
     * </p>
     * 
     * @return the timeFinderInformation
     */
    public TimeFinderInformation getTimeFinderInformation() {
        return timeFinderInformation;
    }

    /**
     * <p>
     * Sets the value to timeFinderInformation field.
     * </p>
     * 
     * @param timeFinderInformation
     *            the timeFinderInformation to set
     */
    public void setTimeFinderInformation(TimeFinderInformation timeFinderInformation) {
        this.timeFinderInformation = timeFinderInformation;
    }

    /**
     * <p>
     * Retrieves the mirrorViewInformation field.
     * </p>
     * 
     * @return the mirrorViewInformation
     */
    public MirrorViewInformation getMirrorViewInformation() {
        return mirrorViewInformation;
    }

    /**
     * <p>
     * Sets the value to mirrorViewInformation field.
     * </p>
     * 
     * @param mirrorViewInformation
     *            the mirrorViewInformation to set
     */
    public void setMirrorViewInformation(MirrorViewInformation mirrorViewInformation) {
        this.mirrorViewInformation = mirrorViewInformation;
    }

    /**
     * <p>
     * Retrieves the snapViewInformation field.
     * </p>
     * 
     * @return the snapViewInformation
     */
    public SnapViewInformation getSnapViewInformation() {
        return snapViewInformation;
    }

    /**
     * <p>
     * Sets the value to snapViewInformation field.
     * </p>
     * 
     * @param snapViewInformation
     *            the snapViewInformation to set
     */
    public void setSnapViewInformation(SnapViewInformation snapViewInformation) {
        this.snapViewInformation = snapViewInformation;
    }

    /**
     * <p>
     * Retrieves the replicationManagerInformation field.
     * </p>
     * 
     * @return the replicationManagerInformation
     */
    public ReplicationManagerInformation getReplicationManagerInformation() {
        return replicationManagerInformation;
    }

    /**
     * <p>
     * Sets the value to replicationManagerInformation field.
     * </p>
     * 
     * @param replicationManagerInformation
     *            the replicationManagerInformation to set
     */
    public void setReplicationManagerInformation(ReplicationManagerInformation replicationManagerInformation) {
        this.replicationManagerInformation = replicationManagerInformation;
    }

    /**
     * <p>
     * Retrieves the nasIpReplicationInformation field.
     * </p>
     * 
     * @return the value of nasIpReplicationInformation
     */
    public List<NasIpReplicationInformation> getNasIpReplicationInformation() {
        return nasIpReplicationInformation;
    }

    /**
     * <p>
     * Sets the value to nasIpReplicationInformation field.
     * </p>
     * 
     * @param nasIpReplicationInformation
     *            the value of nasIpReplicationInformation to set
     */
    public void setNasIpReplicationInformation(List<NasIpReplicationInformation> nasIpReplicationInformation) {
        this.nasIpReplicationInformation = nasIpReplicationInformation;
    }

    /**
     * <p>
     * Retrieves the nasIpReplicationKnowledgeTransferHours field.
     * </p>
     * 
     * @return the nasIpReplicationKnowledgeTransferHours
     */
    public String getNasIpReplicationKnowledgeTransferHours() {
        return nasIpReplicationKnowledgeTransferHours;
    }

    /**
     * <p>
     * Sets the value to nasIpReplicationKnowledgeTransferHours field.
     * </p>
     * 
     * @param nasIpReplicationKnowledgeTransferHours
     *            the nasIpReplicationKnowledgeTransferHours to set
     */
    public void setNasIpReplicationKnowledgeTransferHours(String nasIpReplicationKnowledgeTransferHours) {
        this.nasIpReplicationKnowledgeTransferHours = nasIpReplicationKnowledgeTransferHours;
    }

    /**
     * The toString method.
     * 
     * @return the string for this entity
     */
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("{").append(super.toString());
        sb.append(", nasIpReplicationKnowledgeTransferHours:").append(nasIpReplicationKnowledgeTransferHours)
                .append("}");
        return sb.toString();
    }

}

/*
 * This code is copyright (c) 2013 - 2014 EMC Corporation.
 */
package com.emc.gs.tools.srf.model;


/**
 * <p>
 * This is SalesDistrict entity class.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safety.
 * </p>
 *
 * <p>
 * <strong>Changes:</strong>
 * <strong>SRT Release Assembly - Base</strong>
 * <ul>
 * <li>Release_assembly_tasks.xls Row#9: Added new properties</li>
 * </ul>
 * </p>
 *
 * <p>
 * Version 1.2 Change notes:
 *   <ol>
 *     <li>Added {@link #emailAddress} property.</li>
 *   </ol>
 * </p>
 *
 * @author faeton, stevenfrog, TCSASSEMBLER
 * @version 1.2
 */
public class SalesDistrict extends IdentifiableEntity {
    /**
     * <p>
     * The districtName.
     * </p>
     */
    private String districtName;

    /**
     * <p>
     * The areaName.
     * </p>
     */
    private String areaName;

    /**
     * <p>
     * The marketName.
     * </p>
	 * @since 1.1
     */
    private String marketName;

    /**
     * <p>
     * The division.
     * </p>
     */
    private Division division;

    /**
     * <p>
     * The defaultPdm.
     * </p>
	 * @since 1.1
     */
    private PdmName defaultPdm;

    /**
     * <p>A <code>String</code> providing the value for emailAddress property.</p>
     * 
     * @since 1.2
     */
    private String emailAddress;

    /**
     * <p>
     * The default constructor.
     * </p>
     */
    public SalesDistrict() {
        // Empty
    }

    /**
     * <p>
     * Retrieves the districtName field.
     * </p>
     *
     * @return the districtName
     */
    public String getDistrictName() {
        return districtName;
    }

    /**
     * <p>
     * Sets the value to districtName field.
     * </p>
     *
     * @param districtName
     *            the districtName to set
     */
    public void setDistrictName(String districtName) {
        this.districtName = districtName;
    }

    /**
     * <p>
     * Retrieves the areaName field.
     * </p>
     *
     * @return the areaName
     */
    public String getAreaName() {
        return areaName;
    }

    /**
     * <p>
     * Sets the value to areaName field.
     * </p>
     *
     * @param areaName
     *            the areaName to set
     */
    public void setAreaName(String areaName) {
        this.areaName = areaName;
    }

    /**
     * <p>
     * Retrieves the marketName field.
     * </p>
     *
     * @return the marketName
     */
    public String getMarketName() {
        return marketName;
    }

    /**
     * <p>
     * Sets the value to marketName field.
     * </p>
     *
     * @param marketName
     *            the marketName to set
     */
    public void setMarketName(String marketName) {
        this.marketName = marketName;
    }

    /**
     * <p>
     * Retrieves the division field.
     * </p>
     *
     * @return the division
     */
    public Division getDivision() {
        return division;
    }

    /**
     * <p>
     * Sets the value to division field.
     * </p>
     *
     * @param division
     *            the division to set
     */
    public void setDivision(Division division) {
        this.division = division;
    }

    /**
     * <p>
     * Retrieves the defaultPdm field.
     * </p>
     *
     * @return the defaultPdm
     */
	public PdmName getDefaultPdm() {
		return defaultPdm;
	}

    /**
     * <p>
     * Sets the value to defaultPdm field.
     * </p>
     *
     * @param defaultPdm
     *            the defaultPdm to set
     */
	public void setDefaultPdm(PdmName defaultPdm) {
		this.defaultPdm = defaultPdm;
	}

    /**
     * <p>Gets the emailAddress property.</p>
     *
     * @return a <code>String</code> providing the value for emailAddress property.
     * @since 1.2
     */
    public String getEmailAddress() {
        return this.emailAddress;
    }

    /**
     * <p>Sets the emailAddress property.</p>
     *
     * @param emailAddress a <code>String</code> providing the value for emailAddress property.
     * @since 1.2
     */
    public void setEmailAddress(String emailAddress) {
        this.emailAddress = emailAddress;
    }

    /**
     * The toString method.
     *
     * @return the string of this entity
     */
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("{").append(super.toString());
        sb.append(", districtName:").append(districtName);
        sb.append(", areaName:").append(areaName);
        sb.append(", marketName:").append(marketName);
        sb.append(", defaultPdm:").append(defaultPdm);
        sb.append(", division:").append(division);
        sb.append(", emailAddress:").append(emailAddress);
        sb.append("}");
        return sb.toString();
    }
}

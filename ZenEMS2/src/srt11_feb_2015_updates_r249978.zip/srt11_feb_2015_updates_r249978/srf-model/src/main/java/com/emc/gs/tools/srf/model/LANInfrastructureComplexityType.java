/*
 * This code is copyright (c) 2015 EMC Corporation.
 */
package com.emc.gs.tools.srf.model;

/**
 * <p>This is LANInfrastructureComplexityType entity class.</p>
 *
 * <p><strong>Thread safety</strong>: This class is mutable, it is not thread safety.</p>
 *
 * @author isv
 */
public class LANInfrastructureComplexityType extends LookupEntity {

    /**
     * <p>Constructs new <code>LANInfrastructureComplexityType</code> instance. This implementation does nothing.</p>
     */
    public LANInfrastructureComplexityType() {
    }

}

/*
 * This code is copyright (c) 2014 EMC Corporation
 */
package com.emc.gs.tools.srf.model.dpad;

/**
 * <p>
 * This is DPAImplementation entity class.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safety.
 * </p>
 * 
 * @author TCSASSEMBLER
 * @version 1.0
 * @since SRT Phase 3-5 - BRS Tabs Part 2 Assembly
 */
public class DPAImplementation extends DPABase {

    /**
     * Upgrade from Data Protection Advisor 5.0 Environment.
     */
    private Boolean upgradeFromV5Environment;

    /**
     * Include Data Protection Advisor Recoverability Analysis.
     */
    private Boolean includeRecoverabilityAnalysis;

    /**
     * The implementation data associated with "Upgrade from Data Protection Advisor 5.0 Environment".
     */
    private DPAImplementationData upgradeData;

    /**
     * The implementation data associated with "Include Data Protection Advisor Custom Report Development".
     */
    private DPAImplementationData customReportDevelopmentData;

    /**
     * The implementation data associated with "Include Data Protection Advisor Interface Customization".
     */
    private DPAImplementationData interfaceCustomizationData;

    /**
     * The implementation data associated with "Include Data Protection Advisor Recoverability Analysis".
     */
    private DPAImplementationData recoverabilityAnalysisData;

    /**
     * # of Recoverability Agents.
     */
    private Integer recoverabilityAgentsNum;

    /**
     * The implementation data associated with "Include Data Protection Advisor Analysis Jobs".
     */
    private DPAImplementationData analysisJobsData;

    /**
     * # of Data Protection Advisor Analysis Jobs (Estimated).
     */
    private Integer analysisJobsNum;

    /**
     * <p>
     * The default constructor.
     * </p>
     */
    public DPAImplementation() {
    }

    /**
     * Getter method for property <tt>upgradeFromV5Environment</tt>.
     * 
     * @return property value of upgradeFromV5Environment
     */
    public Boolean getUpgradeFromV5Environment() {
        return upgradeFromV5Environment;
    }

    /**
     * Setter method for property <tt>upgradeFromV5Environment</tt>.
     * 
     * @param upgradeFromV5Environment
     *            value to be assigned to property upgradeFromV5Environment
     */
    public void setUpgradeFromV5Environment(Boolean upgradeFromV5Environment) {
        this.upgradeFromV5Environment = upgradeFromV5Environment;
    }

    /**
     * Getter method for property <tt>includeRecoverabilityAnalysis</tt>.
     * 
     * @return property value of includeRecoverabilityAnalysis
     */
    public Boolean getIncludeRecoverabilityAnalysis() {
        return includeRecoverabilityAnalysis;
    }

    /**
     * Setter method for property <tt>includeRecoverabilityAnalysis</tt>.
     * 
     * @param includeRecoverabilityAnalysis
     *            value to be assigned to property includeRecoverabilityAnalysis
     */
    public void setIncludeRecoverabilityAnalysis(Boolean includeRecoverabilityAnalysis) {
        this.includeRecoverabilityAnalysis = includeRecoverabilityAnalysis;
    }

    /**
     * Getter method for property <tt>upgradeData</tt>.
     * 
     * @return property value of upgradeData
     */
    public DPAImplementationData getUpgradeData() {
        return upgradeData;
    }

    /**
     * Setter method for property <tt>upgradeData</tt>.
     * 
     * @param upgradeData
     *            value to be assigned to property upgradeData
     */
    public void setUpgradeData(DPAImplementationData upgradeData) {
        this.upgradeData = upgradeData;
    }

    /**
     * Getter method for property <tt>customReportDevelopmentData</tt>.
     * 
     * @return property value of customReportDevelopmentData
     */
    public DPAImplementationData getCustomReportDevelopmentData() {
        return customReportDevelopmentData;
    }

    /**
     * Setter method for property <tt>customReportDevelopmentData</tt>.
     * 
     * @param customReportDevelopmentData
     *            value to be assigned to property customReportDevelopmentData
     */
    public void setCustomReportDevelopmentData(DPAImplementationData customReportDevelopmentData) {
        this.customReportDevelopmentData = customReportDevelopmentData;
    }

    /**
     * Getter method for property <tt>interfaceCustomizationData</tt>.
     * 
     * @return property value of interfaceCustomizationData
     */
    public DPAImplementationData getInterfaceCustomizationData() {
        return interfaceCustomizationData;
    }

    /**
     * Setter method for property <tt>interfaceCustomizationData</tt>.
     * 
     * @param interfaceCustomizationData
     *            value to be assigned to property interfaceCustomizationData
     */
    public void setInterfaceCustomizationData(DPAImplementationData interfaceCustomizationData) {
        this.interfaceCustomizationData = interfaceCustomizationData;
    }

    /**
     * Getter method for property <tt>recoverabilityAnalysisData</tt>.
     * 
     * @return property value of recoverabilityAnalysisData
     */
    public DPAImplementationData getRecoverabilityAnalysisData() {
        return recoverabilityAnalysisData;
    }

    /**
     * Setter method for property <tt>recoverabilityAnalysisData</tt>.
     * 
     * @param recoverabilityAnalysisData
     *            value to be assigned to property recoverabilityAnalysisData
     */
    public void setRecoverabilityAnalysisData(DPAImplementationData recoverabilityAnalysisData) {
        this.recoverabilityAnalysisData = recoverabilityAnalysisData;
    }

    /**
     * Getter method for property <tt>recoverabilityAgentsNum</tt>.
     * 
     * @return property value of recoverabilityAgentsNum
     */
    public Integer getRecoverabilityAgentsNum() {
        return recoverabilityAgentsNum;
    }

    /**
     * Setter method for property <tt>recoverabilityAgentsNum</tt>.
     * 
     * @param recoverabilityAgentsNum
     *            value to be assigned to property recoverabilityAgentsNum
     */
    public void setRecoverabilityAgentsNum(Integer recoverabilityAgentsNum) {
        this.recoverabilityAgentsNum = recoverabilityAgentsNum;
    }

    /**
     * Getter method for property <tt>analysisJobsData</tt>.
     * 
     * @return property value of analysisJobsData
     */
    public DPAImplementationData getAnalysisJobsData() {
        return analysisJobsData;
    }

    /**
     * Setter method for property <tt>analysisJobsData</tt>.
     * 
     * @param analysisJobsData
     *            value to be assigned to property analysisJobsData
     */
    public void setAnalysisJobsData(DPAImplementationData analysisJobsData) {
        this.analysisJobsData = analysisJobsData;
    }

    /**
     * Getter method for property <tt>analysisJobsNum</tt>.
     * 
     * @return property value of analysisJobsNum
     */
    public Integer getAnalysisJobsNum() {
        return analysisJobsNum;
    }

    /**
     * Setter method for property <tt>analysisJobsNum</tt>.
     * 
     * @param analysisJobsNum
     *            value to be assigned to property analysisJobsNum
     */
    public void setAnalysisJobsNum(Integer analysisJobsNum) {
        this.analysisJobsNum = analysisJobsNum;
    }

}

/*
 * This code is copyright (c) 2014 EMC Corporation.
 */
package com.emc.gs.tools.srf.model.bc;


/**
 * <p>
 * This is target array information for SrdfInformation entity.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safety.
 * </p>
 * 
 * <p>
 * <strong>Changes V1.1:</strong>
 * <ul>
 * <li>Removed targetTfR2Device, tfBackup, timefinder, bcvClonesNumber fields.</li>
 * </ul>
 * </p>
 * 
 * <p>
 * <strong>Changes V1.2:</strong>
 * <strong>https://apps.topcoder.com/bugs/browse/SRT-35</strong>
 * <ul>
 * <li>Added sourceName, includeBandwidthAnalysis, includeNetworkAssessement, 
 * nrOfVMAXArrays, nrOfHostsNeeded, nrOfDeviceCompositeGroups fields.</li>
 * </ul>
 * </p>
 *
 * <p>
 * Version 1.3 (SRT 4 OCT2014 Updates Part 1 Assembly) Change notes:
 *   <ol>
 *     <li>Removed <code>nrOfVMAXArrays</code> property.</li>
 *   </ol>
 * </p>
 *
 * @author faeton, MonicaMuranyi, isv
 * @version 1.3
 * @since SRT Release Assembly - BC Tab
 */
public class SrdfTargetArrayInformation extends SrdfBaseArrayInformation {
    
    /**
     * <p>
     * The sourceName.
     * </p>
     */
    private String sourceName;
    
    /**
     * <p>
     * The includeBandwidthAnalysis.
     * </p>
     */
    private Boolean includeBandwidthAnalysis;
    
    /**
     * <p>
     * The includeNetworkAssessement.
     * </p>
     */
    private Boolean includeNetworkAssessement;
    
    /**
     * <p>
     * The nrOfHostsNeeded.
     * </p>
     */
    private Integer nrOfHostsNeeded;
    
    /**
     * <p>
     * The nrOfDeviceCompositeGroups.
     * </p>
     */
    private Integer nrOfDeviceCompositeGroups;

    /**
     * Empty constructor.
     */
    public SrdfTargetArrayInformation() {
    }
    
    /**
     * Getter method for property <tt>sourceName</tt>.
     * @return property value of sourceName
     */
    public String getSourceName() {
        return sourceName;
    }

    /**
     * Setter method for property <tt>sourceName</tt>.
     * @param sourceName value to be assigned to property sourceName
     */
    public void setSourceName(String sourceName) {
        this.sourceName = sourceName;
    }
    
    /**
     * Getter method for property <tt>srdfInstalledStatus</tt>.
     * @return property value of srdfInstalledStatus
     */
    public Boolean getIncludeBandwidthAnalysis() {
        return includeBandwidthAnalysis;
    }

    /**
     * Setter method for property <tt>srdfInstalledStatus</tt>.
     * @param srdfInstalledStatus value to be assigned to property srdfInstalledStatus
     */
    public void setIncludeBandwidthAnalysis(Boolean includeBandwidthAnalysis) {
        this.includeBandwidthAnalysis = includeBandwidthAnalysis;
    }

    /**
     * Getter method for property <tt>srdfInstalledStatus</tt>.
     * @return property value of srdfInstalledStatus
     */
    public Boolean getIncludeNetworkAssessement() {
        return includeNetworkAssessement;
    }

    /**
     * Setter method for property <tt>srdfInstalledStatus</tt>.
     * @param srdfInstalledStatus value to be assigned to property srdfInstalledStatus
     */
    public void setIncludeNetworkAssessement(Boolean includeNetworkAssessement) {
        this.includeNetworkAssessement = includeNetworkAssessement;
    }

    /**
     * Getter method for property <tt>srdfInstalledStatus</tt>.
     * @return property value of srdfInstalledStatus
     */
    public Integer getNrOfHostsNeeded() {
        return nrOfHostsNeeded;
    }

    /**
     * Setter method for property <tt>srdfInstalledStatus</tt>.
     * @param srdfInstalledStatus value to be assigned to property srdfInstalledStatus
     */
    public void setNrOfHostsNeeded(Integer nrOfHostsNeeded) {
        this.nrOfHostsNeeded = nrOfHostsNeeded;
    }

    /**
     * Getter method for property <tt>srdfInstalledStatus</tt>.
     * @return property value of srdfInstalledStatus
     */
    public Integer getNrOfDeviceCompositeGroups() {
        return nrOfDeviceCompositeGroups;
    }

    /**
     * Setter method for property <tt>srdfInstalledStatus</tt>.
     * @param srdfInstalledStatus value to be assigned to property srdfInstalledStatus
     */
    public void setNrOfDeviceCompositeGroups(Integer nrOfDeviceCompositeGroups) {
        this.nrOfDeviceCompositeGroups = nrOfDeviceCompositeGroups;
    }
    
    /**
     * The toString method.
     *
     * @return the string for this entity
     */
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(", sourceName:").append(sourceName);
        sb.append(", includeBandwidthAnalysis:").append(includeBandwidthAnalysis);
        sb.append(", includeNetworkAssessement:").append(includeNetworkAssessement);
        sb.append(", nrOfHostsNeeded:").append(nrOfHostsNeeded);
        sb.append(", nrOfDeviceCompositeGroups:").append(nrOfDeviceCompositeGroups);
        return sb.toString();
    }

}
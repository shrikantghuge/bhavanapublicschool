/*
 * This code is copyright (c) 2014 EMC Corporation.
 */
package com.emc.gs.tools.srf.model;

import com.emc.gs.tools.srf.model.CorrelatedIdentifiableEntity;
import com.emc.gs.tools.srf.model.OperationLog;

/**
 * <p>
 * This is the EntityOperationLog DTO class. It encapsulates the operation log
 * and the related entity.
 * </p>
 *
 * <p>
 * <strong>Thread safety</strong>: This class is mutable and not thread safe.
 * </p>
 *
 * @author TCSASSEMBLER
 * @version 1.0
 * @since SRT Phase 4 - ET Assembly 2
 */
public class EntityOperationLog<T extends CorrelatedIdentifiableEntity> {

    /**
     * The operation log. Will not be null in practice.
     */
    private OperationLog operationLog;

    /**
     * The related entity. For DELETE operation this field is null.
     */
    private T entity;

    /**
     * Empty constructor.
     */
    public EntityOperationLog() {
    }

    /**
     * Getter method for property <tt>operationLog</tt>.
     *
     * @return property value of operationLog
     */
    public OperationLog getOperationLog() {
        return operationLog;
    }

    /**
     * Setter method for property <tt>operationLog</tt>.
     *
     * @param operationLog
     *            value to be assigned to property operationLog
     */
    public void setOperationLog(OperationLog operationLog) {
        this.operationLog = operationLog;
    }

    /**
     * Getter method for property <tt>entity</tt>.
     *
     * @return property value of entity
     */
    public T getEntity() {
        return entity;
    }

    /**
     * Setter method for property <tt>entity</tt>.
     *
     * @param entity
     *            value to be assigned to property entity
     */
    public void setEntity(T entity) {
        this.entity = entity;
    }
}

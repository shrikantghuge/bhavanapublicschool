/*
 * This code is copyright (c) 2014 EMC Corporation
 */
package com.emc.gs.tools.srf.model.dpad;

/**
 * <p>
 * This is NetworkerDesign entity class.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safety.
 * </p>
 * 
 * @author TCSASSEMBLER
 * @version 1.0
 * @since SRT Phase 3-5 - BRS Tabs Part 3 Assembly
 */
public class NetworkerDesign extends NetworkerDesignImplBase {

    /**
     * The networker server data.
     */
    private NetworkerServerDesign server;

    /**
     * The networker advanced backup technology data.
     */
    private NetworkerAdvancedBackupTechDesign advancedBackupTech;

    /**
     * The networker file system client backups data.
     */
    private NetworkerFileSystemClientBackupsDesign fileSystemClientBackups;

    /**
     * The networker application backups data.
     */
    private NetworkerApplicationBackupsDesign applicationBackups;

    /**
     * <p>
     * The default constructor.
     * </p>
     */
    public NetworkerDesign() {
    }

    /**
     * Getter method for property <tt>server</tt>.
     * 
     * @return property value of server
     */
    public NetworkerServerDesign getServer() {
        return server;
    }

    /**
     * Setter method for property <tt>server</tt>.
     * 
     * @param server
     *            value to be assigned to property server
     */
    public void setServer(NetworkerServerDesign server) {
        this.server = server;
    }

    /**
     * Getter method for property <tt>advancedBackupTech</tt>.
     * 
     * @return property value of advancedBackupTech
     */
    public NetworkerAdvancedBackupTechDesign getAdvancedBackupTech() {
        return advancedBackupTech;
    }

    /**
     * Setter method for property <tt>advancedBackupTech</tt>.
     * 
     * @param advancedBackupTech
     *            value to be assigned to property advancedBackupTech
     */
    public void setAdvancedBackupTech(NetworkerAdvancedBackupTechDesign advancedBackupTech) {
        this.advancedBackupTech = advancedBackupTech;
    }

    /**
     * Getter method for property <tt>fileSystemClientBackups</tt>.
     * 
     * @return property value of fileSystemClientBackups
     */
    public NetworkerFileSystemClientBackupsDesign getFileSystemClientBackups() {
        return fileSystemClientBackups;
    }

    /**
     * Setter method for property <tt>fileSystemClientBackups</tt>.
     * 
     * @param fileSystemClientBackups
     *            value to be assigned to property fileSystemClientBackups
     */
    public void setFileSystemClientBackups(NetworkerFileSystemClientBackupsDesign fileSystemClientBackups) {
        this.fileSystemClientBackups = fileSystemClientBackups;
    }

    /**
     * Getter method for property <tt>applicationBackups</tt>.
     * 
     * @return property value of applicationBackups
     */
    public NetworkerApplicationBackupsDesign getApplicationBackups() {
        return applicationBackups;
    }

    /**
     * Setter method for property <tt>applicationBackups</tt>.
     * 
     * @param applicationBackups
     *            value to be assigned to property applicationBackups
     */
    public void setApplicationBackups(NetworkerApplicationBackupsDesign applicationBackups) {
        this.applicationBackups = applicationBackups;
    }

}

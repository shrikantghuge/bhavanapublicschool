/*
 * This code is copyright (c) 2014 EMC Corporation
 */
package com.emc.gs.tools.srf.model.dpad;

import com.emc.gs.tools.srf.model.LookupEntity;

/**
 * <p> This is NetworkerDatazoneSize entity class.</p>
 * 
 * <p><strong>Thread safety</strong>: This class is mutable, it is not thread safe.</p>
 *
 * @author isv
 * @version 1.0
 * @since SRT 4 OCT2014 Updates Part 1 Assembly
 */
public class NetworkerDatazoneSize extends LookupEntity {

    /**
     * <p>Constructs new <code>NetworkerDatazoneSize</code> instance. This implementation does nothing.</p>
     */
    public NetworkerDatazoneSize() {
    }
}

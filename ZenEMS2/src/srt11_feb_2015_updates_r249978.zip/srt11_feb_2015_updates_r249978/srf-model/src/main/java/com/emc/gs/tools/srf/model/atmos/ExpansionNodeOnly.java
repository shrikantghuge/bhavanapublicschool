/*
 * This code is copyright (c) 2014 EMC Corporation
 */
package com.emc.gs.tools.srf.model.atmos;

import com.emc.gs.tools.srf.model.IdentifiableEntity;

/**
 * <p>
 * This is ExpansionNodeOnly entity class.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safety.
 * </p>
 * 
 * @author TCSASSEMBLER
 * @version 1.0
 * @since SRT Phase 3-1 - Atmos Centera and Vblock Tabs Assembly
 */
public class ExpansionNodeOnly extends IdentifiableEntity {

    /**
     * Number of Atmos FLEX kits to be installed.
     */
    private Integer flexKitsNum;

    /**
     * <p>
     * The default constructor.
     * </p>
     */
    public ExpansionNodeOnly() {
    }

    /**
     * Getter method for property <tt>flexKitsNum</tt>.
     * 
     * @return property value of flexKitsNum
     */
    public Integer getFlexKitsNum() {
        return flexKitsNum;
    }

    /**
     * Setter method for property <tt>flexKitsNum</tt>.
     * 
     * @param flexKitsNum
     *            value to be assigned to property flexKitsNum
     */
    public void setFlexKitsNum(Integer flexKitsNum) {
        this.flexKitsNum = flexKitsNum;
    }

}

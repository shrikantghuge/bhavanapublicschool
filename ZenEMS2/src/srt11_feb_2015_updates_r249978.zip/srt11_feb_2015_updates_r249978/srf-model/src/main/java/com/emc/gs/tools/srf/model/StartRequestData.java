/*
 * This code is copyright (c) 2013 - 2014 EMC Corporation.
 */
package com.emc.gs.tools.srf.model;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * <p>
 * This is StartRequestData entity class.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safety.
 * </p>
 *
 * <p>
 * <strong>Changes:</strong>
 * <strong>SRT Release Assembly - Base</strong>
 * <ul>
 * <li>Release_assembly_tasks.xls Row#2: Removed programDeliveryManagerName</li>
 * <li>Release_assembly_tasks.xls Row#3: Added travelRequirements</li>
 * <li>Release_assembly_tasks.xls Row#7: Renamed CustomerContractData to RequestContractData</li>
 * </ul>
 * </p>
 * 
 * <p>
 * <strong>Changes V1.2:</strong>
 * <strong>SRT Bug Fixes</strong>
 * <ul>
 * <li>Removed customerBudget and soldLevel1 fields.</li>
 * </ul>
 * </p>
 * 
 * <p>
 * <strong>Changes V1.3:</strong>
 * <strong>Commercial / Mid-Market Division Special Handling Logic</strong>
 * <ul>
 * <li>Added selectedGeography and selectedState fields.</li>
 * </ul>
 * </p>
 * 
 * <p>
 * <strong>Changes V1.4:</strong>
 * <ul>
 * <li>Removed solutionOptions field.</li>
 * </ul>
 * </p>
 *
 * <p>
 * <strong>Changes V1.5:</strong>
 * <strong>SRT Phase 2 Release Assembly</strong>
 * <ul>
 * <li>Change seCsdPhone field to Phone type</li>
 * </ul>
 * </p>
 *
 * <p>
 * Version 1.6 (SRT Phase 4 - ET Release Assembly) Change notes:
 *   <ol>
 *     <li>Replaced <code>expensesIncluded</code> property with {@link #expenseType} property.</li>
 *     <li>Added {@link #oraclePartyID} property.</li>
 *   </ol>
 * </p>
 *
 * <p>
 * Version 1.7 Change notes:
 *   <ol>
 *     <li>Removed <code>existingSfdcNumber</code> property.</li>
 *   </ol>
 * </p>
 *
 * <p>
 * Version 1.8 Change notes:
 *   <ol>
 *     <li>Changed the type of {@link #remoteAccess} property to <code>Boolean</code>.</li>
 *   </ol>
 * </p>
 *
 * @author faeton, stevenfrog, MonicaMuranyi, isv
 * @version 1.8
 */
public class StartRequestData extends IdentifiableEntity {
    /**
     * <p>
     * The coreOptions.
     * </p>
     */
    private CoreOptions coreOptions;

    /**
     * <p>
     * The dpadOptions.
     * </p>
     */
    private DPADOptions dpadOptions;

    /**
     * <p>
     * The asdOptions.
     * </p>
     */
    private ASDOptions asdOptions;

    /**
     * <p>
     * The affinityOptions.
     * </p>
     */
    private AffinityOptions affinityOptions;

    /**
     * <p>
     * The consultingOptions.
     * </p>
     */
    private ConsultingOptions consultingOptions;

    /**
     * <p>
     * The otherRequestOptions.
     * </p>
     */
    private OtherRequestOptions otherRequestOptions;

    /**
     * <p>
     * The selectedDivision.
     * </p>
     */
    private Division selectedDivision;

    /**
     * <p>
     * The selectedDistrict.
     * </p>
     */
    private SalesDistrict selectedDistrict;

    /**
     * <p>
     * The selectedPdmName.
     * </p>
     */
    private PdmName selectedPdmName;

    /**
     * <p>
     * The selectedPdmName.
     * </p>
     */
    private String pdmName;

    /**
     * <p>
     * The selectedGeography.
     * </p>
     */
    private Geography selectedGeography;
    
    /**
     * <p>
     * The selectedState.
     * </p>
     */
    private GeoState selectedState;

    /**
     * <p>
     * The customerName.
     * </p>
     */
    private String customerName;

    /**
     * <p>
     * The projectName.
     * </p>
     */
    private String projectName;

    /**
     * <p>
     * The projectType.
     * </p>
     */
    private ProjectType projectType;

    /**
     * <p>
     * The workCity.
     * </p>
     */
    private String workCity;

    /**
     * <p>
     * The dxQuoteNumber.
     * </p>
     */
    private String dxQuoteNumber;

    /**
     * <p>
     * The seCsdName.
     * </p>
     */
    private String seCsdName;

    /**
     * <p>
     * The pmName.
     * </p>
     */
    private String pmName;

    /**
     * <p>
     * The sfdcNumber.
     * </p>
     */
    private String sfdcNumber;

    /**
     * <p>
     * The seCsdPhone.
     * </p>
     */
    private Phone seCsdPhone;

    /**
     * <p>
     * The meetingStatus.
     * </p>
     */
    private MeetingStatus meetingStatus;

    /**
     * <p>
     * The seManagerName.
     * </p>
     */
    private String seManagerName;

    /**
     * <p>
     * The riskLevel.
     * </p>
     */
    private RiskLevel riskLevel;

    /**
     * <p>
     * The sowLanguage.
     * </p>
     */
    private SowLanguage sowLanguage;

    /**
     * <p>
     * The phoneCallRequest.
     * </p>
     */
    private boolean phoneCallRequest;

    /**
     * <p>
     * The resellerSold.
     * </p>
     */
    private boolean resellerSold;

    /**
     * <p>
     * The requestedReturnDate.
     * </p>
     */
    private Date requestedReturnDate;

    /**
     * <p>
     * The returnEquipment.
     * </p>
     */
    private boolean returnEquipment;

    /**
     * <p>A <code>ExpenseType</code> providing the value for expenseType property.</p>
     *
     * @since 1.6
     */
    private ExpenseType expenseType;

    /**
     * <p>A <code>Integer</code> providing the value for oraclePartyID property.</p>
     *
     * @since 1.6
     */
    private Integer oraclePartyID;

    /**
     * <p>
     * The remoteAccess.
     * </p>
     */
    private Boolean remoteAccess;

    /**
     * <p>
     * The clearanceLevel.
     * </p>
     */
    private ClearanceLevel clearanceLevel;

    /**
     * <p>
     * The attachments.
     * </p>
     */
    private List<Attachment> attachments = new ArrayList<Attachment>();

    /**
     * <p>
     * The requestContractData.
     * </p>
     */
    private RequestContractData requestContractData;

    /**
     * <p>
     * The serviceRequestScope.
     * </p>
     */
    private String serviceRequestScope;

    /**
     * <p>
     * The travelRequirements.
     * </p>
     */
    private String travelRequirements;

    /**
     * <p>
     * The default constructor.
     * </p>
     */
    public StartRequestData() {
        // Empty
    }

    /**
     * Getter method for property <tt>coreOptions</tt>.
     * @return property value of coreOptions
     */
    public CoreOptions getCoreOptions() {
        return coreOptions;
    }

    /**
     * Setter method for property <tt>coreOptions</tt>.
     * @param coreOptions value to be assigned to property coreOptions
     */
    public void setCoreOptions(CoreOptions coreOptions) {
        this.coreOptions = coreOptions;
    }

    /**
     * Getter method for property <tt>dpadOptions</tt>.
     * @return property value of dpadOptions
     */
    public DPADOptions getDpadOptions() {
        return dpadOptions;
    }

    /**
     * Setter method for property <tt>dpadOptions</tt>.
     * @param dpadOptions value to be assigned to property dpadOptions
     */
    public void setDpadOptions(DPADOptions dpadOptions) {
        this.dpadOptions = dpadOptions;
    }

    /**
     * Getter method for property <tt>asdOptions</tt>.
     * @return property value of asdOptions
     */
    public ASDOptions getAsdOptions() {
        return asdOptions;
    }

    /**
     * Setter method for property <tt>asdOptions</tt>.
     * @param asdOptions value to be assigned to property asdOptions
     */
    public void setAsdOptions(ASDOptions asdOptions) {
        this.asdOptions = asdOptions;
    }

    /**
     * Getter method for property <tt>affinityOptions</tt>.
     * @return property value of affinityOptions
     */
    public AffinityOptions getAffinityOptions() {
        return affinityOptions;
    }

    /**
     * Setter method for property <tt>affinityOptions</tt>.
     * @param affinityOptions value to be assigned to property affinityOptions
     */
    public void setAffinityOptions(AffinityOptions affinityOptions) {
        this.affinityOptions = affinityOptions;
    }

    /**
     * Getter method for property <tt>consultingOptions</tt>.
     * @return property value of consultingOptions
     */
    public ConsultingOptions getConsultingOptions() {
        return consultingOptions;
    }

    /**
     * Setter method for property <tt>consultingOptions</tt>.
     * @param consultingOptions value to be assigned to property consultingOptions
     */
    public void setConsultingOptions(ConsultingOptions consultingOptions) {
        this.consultingOptions = consultingOptions;
    }

    /**
     * <p>
     * Retrieves the otherRequestOptions field.
     * </p>
     *
     * @return the otherRequestOptions
     */
    public OtherRequestOptions getOtherRequestOptions() {
        return otherRequestOptions;
    }

    /**
     * <p>
     * Sets the value to otherRequestOptions field.
     * </p>
     *
     * @param otherRequestOptions
     *            the otherRequestOptions to set
     */
    public void setOtherRequestOptions(OtherRequestOptions otherRequestOptions) {
        this.otherRequestOptions = otherRequestOptions;
    }

    /**
     * <p>
     * Retrieves the selectedDivision field.
     * </p>
     *
     * @return the selectedDivision
     */
    public Division getSelectedDivision() {
        return selectedDivision;
    }

    /**
     * <p>
     * Sets the value to selectedDivision field.
     * </p>
     *
     * @param selectedDivision
     *            the selectedDivision to set
     */
    public void setSelectedDivision(Division selectedDivision) {
        this.selectedDivision = selectedDivision;
    }

    /**
     * <p>
     * Retrieves the selectedDistrict field.
     * </p>
     *
     * @return the selectedDistrict
     */
    public SalesDistrict getSelectedDistrict() {
        return selectedDistrict;
    }

    /**
     * <p>
     * Sets the value to selectedDistrict field.
     * </p>
     *
     * @param selectedDistrict
     *            the selectedDistrict to set
     */
    public void setSelectedDistrict(SalesDistrict selectedDistrict) {
        this.selectedDistrict = selectedDistrict;
    }

    /**
     * <p>
     * Retrieves the selectedPdmName field.
     * </p>
     *
     * @return the selectedPdmName
     */
    public PdmName getSelectedPdmName() {
        return selectedPdmName;
    }

    /**
     * <p>
     * Sets the value to selectedPdmName field.
     * </p>
     *
     * @param selectedPdmName
     *            the selectedPdmName to set
     */
    public void setSelectedPdmName(PdmName selectedPdmName) {
        this.selectedPdmName = selectedPdmName;
    }

    /**
     * Getter method for property <tt>pdmName</tt>.
     * @return property value of pdmName
     */
    public String getPdmName() {
        return pdmName;
    }

    /**
     * Setter method for property <tt>pdmName</tt>.
     * @param pdmName value to be assigned to property pdmName
     */
    public void setPdmName(String pdmName) {
        this.pdmName = pdmName;
    }

    /**
     * <p>
     * Retrieves the selectedGeography field.
     * </p>
     *
     * @return the selectedGeography
     */
    public Geography getSelectedGeography() {
        return selectedGeography;
    }

    /**
     * <p>
     * Sets the value to selectedGeography field.
     * </p>
     *
     * @param selectedGeography
     *            the selectedGeography to set
     */
    public void setSelectedGeography(Geography selectedGeography) {
        this.selectedGeography = selectedGeography;
    }
    
    /**
     * <p>
     * Retrieves the selectedState field.
     * </p>
     *
     * @return the selectedState
     */
    public GeoState getSelectedState() {
        return selectedState;
    }

    /**
     * <p>
     * Sets the value to selectedState field.
     * </p>
     *
     * @param selectedState
     *            the selectedState to set
     */
    public void setSelectedState(GeoState selectedState) {
        this.selectedState = selectedState;
    }

    /**
     * <p>
     * Retrieves the customerName field.
     * </p>
     *
     * @return the customerName
     */
    public String getCustomerName() {
        return customerName;
    }

    /**
     * <p>
     * Sets the value to customerName field.
     * </p>
     *
     * @param customerName
     *            the customerName to set
     */
    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    /**
     * <p>
     * Retrieves the projectName field.
     * </p>
     *
     * @return the projectName
     */
    public String getProjectName() {
        return projectName;
    }

    /**
     * <p>
     * Sets the value to projectName field.
     * </p>
     *
     * @param projectName
     *            the projectName to set
     */
    public void setProjectName(String projectName) {
        this.projectName = projectName;
    }

    /**
     * <p>
     * Retrieves the projectType field.
     * </p>
     *
     * @return the projectType
     */
    public ProjectType getProjectType() {
        return projectType;
    }

    /**
     * <p>
     * Sets the value to projectType field.
     * </p>
     *
     * @param projectType
     *            the projectType to set
     */
    public void setProjectType(ProjectType projectType) {
        this.projectType = projectType;
    }

    /**
     * <p>
     * Retrieves the workCity field.
     * </p>
     *
     * @return the workCity
     */
    public String getWorkCity() {
        return workCity;
    }

    /**
     * <p>
     * Sets the value to workCity field.
     * </p>
     *
     * @param workCity
     *            the workCity to set
     */
    public void setWorkCity(String workCity) {
        this.workCity = workCity;
    }

    /**
     * <p>
     * Retrieves the dxQuoteNumber field.
     * </p>
     *
     * @return the dxQuoteNumber
     */
    public String getDxQuoteNumber() {
        return dxQuoteNumber;
    }

    /**
     * <p>
     * Sets the value to dxQuoteNumber field.
     * </p>
     *
     * @param dxQuoteNumber
     *            the dxQuoteNumber to set
     */
    public void setDxQuoteNumber(String dxQuoteNumber) {
        this.dxQuoteNumber = dxQuoteNumber;
    }

    /**
     * <p>
     * Retrieves the seCsdName field.
     * </p>
     *
     * @return the seCsdName
     */
    public String getSeCsdName() {
        return seCsdName;
    }

    /**
     * <p>
     * Sets the value to seCsdName field.
     * </p>
     *
     * @param seCsdName
     *            the seCsdName to set
     */
    public void setSeCsdName(String seCsdName) {
        this.seCsdName = seCsdName;
    }

    /**
     * <p>
     * Retrieves the pmName field.
     * </p>
     *
     * @return the pmName
     */
    public String getPmName() {
        return pmName;
    }

    /**
     * <p>
     * Sets the value to pmName field.
     * </p>
     *
     * @param pmName
     *            the pmName to set
     */
    public void setPmName(String pmName) {
        this.pmName = pmName;
    }

    /**
     * <p>
     * Retrieves the sfdcNumber field.
     * </p>
     *
     * @return the sfdcNumber
     */
    public String getSfdcNumber() {
        return sfdcNumber;
    }

    /**
     * <p>
     * Sets the value to sfdcNumber field.
     * </p>
     *
     * @param sfdcNumber
     *            the sfdcNumber to set
     */
    public void setSfdcNumber(String sfdcNumber) {
        this.sfdcNumber = sfdcNumber;
    }

    /**
     * <p>
     * Retrieves the seCsdPhone field.
     * </p>
     *
     * @return the seCsdPhone
     */
    public Phone getSeCsdPhone() {
        return seCsdPhone;
    }

    /**
     * <p>
     * Sets the value to seCsdPhone field.
     * </p>
     *
     * @param seCsdPhone
     *            the seCsdPhone to set
     */
    public void setSeCsdPhone(Phone seCsdPhone) {
        this.seCsdPhone = seCsdPhone;
    }

    /**
     * <p>
     * Retrieves the meetingStatus field.
     * </p>
     *
     * @return the meetingStatus
     */
    public MeetingStatus getMeetingStatus() {
        return meetingStatus;
    }

    /**
     * <p>
     * Sets the value to meetingStatus field.
     * </p>
     *
     * @param meetingStatus
     *            the meetingStatus to set
     */
    public void setMeetingStatus(MeetingStatus meetingStatus) {
        this.meetingStatus = meetingStatus;
    }

    /**
     * <p>
     * Retrieves the seManagerName field.
     * </p>
     *
     * @return the seManagerName
     */
    public String getSeManagerName() {
        return seManagerName;
    }

    /**
     * <p>
     * Sets the value to seManagerName field.
     * </p>
     *
     * @param seManagerName
     *            the seManagerName to set
     */
    public void setSeManagerName(String seManagerName) {
        this.seManagerName = seManagerName;
    }

    /**
     * <p>
     * Retrieves the riskLevel field.
     * </p>
     *
     * @return the riskLevel
     */
    public RiskLevel getRiskLevel() {
        return riskLevel;
    }

    /**
     * <p>
     * Sets the value to riskLevel field.
     * </p>
     *
     * @param riskLevel
     *            the riskLevel to set
     */
    public void setRiskLevel(RiskLevel riskLevel) {
        this.riskLevel = riskLevel;
    }

    /**
     * <p>
     * Retrieves the sowLanguage field.
     * </p>
     *
     * @return the sowLanguage
     */
    public SowLanguage getSowLanguage() {
        return sowLanguage;
    }

    /**
     * <p>
     * Sets the value to sowLanguage field.
     * </p>
     *
     * @param sowLanguage
     *            the sowLanguage to set
     */
    public void setSowLanguage(SowLanguage sowLanguage) {
        this.sowLanguage = sowLanguage;
    }

    /**
     * <p>
     * Retrieves the phoneCallRequest field.
     * </p>
     *
     * @return the phoneCallRequest
     */
    public boolean isPhoneCallRequest() {
        return phoneCallRequest;
    }

    /**
     * <p>
     * Sets the value to phoneCallRequest field.
     * </p>
     *
     * @param phoneCallRequest
     *            the phoneCallRequest to set
     */
    public void setPhoneCallRequest(boolean phoneCallRequest) {
        this.phoneCallRequest = phoneCallRequest;
    }

    /**
     * <p>
     * Retrieves the resellerSold field.
     * </p>
     *
     * @return the resellerSold
     */
    public boolean isResellerSold() {
        return resellerSold;
    }

    /**
     * <p>
     * Sets the value to resellerSold field.
     * </p>
     *
     * @param resellerSold
     *            the resellerSold to set
     */
    public void setResellerSold(boolean resellerSold) {
        this.resellerSold = resellerSold;
    }

    /**
     * <p>
     * Retrieves the requestedReturnDate field.
     * </p>
     *
     * @return the requestedReturnDate
     */
    public Date getRequestedReturnDate() {
        return requestedReturnDate;
    }

    /**
     * <p>
     * Sets the value to requestedReturnDate field.
     * </p>
     *
     * @param requestedReturnDate
     *            the requestedReturnDate to set
     */
    public void setRequestedReturnDate(Date requestedReturnDate) {
        this.requestedReturnDate = requestedReturnDate;
    }

    /**
     * <p>
     * Retrieves the returnEquipment field.
     * </p>
     *
     * @return the returnEquipment
     */
    public boolean isReturnEquipment() {
        return returnEquipment;
    }

    /**
     * <p>
     * Sets the value to returnEquipment field.
     * </p>
     *
     * @param returnEquipment
     *            the returnEquipment to set
     */
    public void setReturnEquipment(boolean returnEquipment) {
        this.returnEquipment = returnEquipment;
    }

    /**
     * <p>
     * Retrieves the remoteAccess field.
     * </p>
     *
     * @return the remoteAccess
     */
    public Boolean isRemoteAccess() {
        return remoteAccess;
    }

    /**
     * <p> Retrieves the remoteAccess field. </p>
     *
     * @return the remoteAccess
     */
    public Boolean getRemoteAccess() {
        return remoteAccess;
    }

    /**
     * <p>
     * Sets the value to remoteAccess field.
     * </p>
     *
     * @param remoteAccess
     *            the remoteAccess to set
     */
    public void setRemoteAccess(Boolean remoteAccess) {
        this.remoteAccess = remoteAccess;
    }

    /**
     * <p>
     * Retrieves the clearanceLevel field.
     * </p>
     *
     * @return the clearanceLevel
     */
    public ClearanceLevel getClearanceLevel() {
        return clearanceLevel;
    }

    /**
     * <p>
     * Sets the value to clearanceLevel field.
     * </p>
     *
     * @param clearanceLevel
     *            the clearanceLevel to set
     */
    public void setClearanceLevel(ClearanceLevel clearanceLevel) {
        this.clearanceLevel = clearanceLevel;
    }

    /**
     * <p>
     * Retrieves the attachments field.
     * </p>
     *
     * @return the attachments
     */
    public List<Attachment> getAttachments() {
        return attachments;
    }

    /**
     * <p>
     * Sets the value to attachments field.
     * </p>
     *
     * @param attachments
     *            the attachments to set
     */
    public void setAttachments(List<Attachment> attachments) {
        this.attachments = attachments;
    }

    /**
     * <p>
     * Retrieves the requestContractData field.
     * </p>
     *
     * @return the requestContractData
     */
    public RequestContractData getRequestContractData() {
        return requestContractData;
    }

    /**
     * <p>
     * Sets the value to requestContractData field.
     * </p>
     *
     * @param requestContractData
     *            the requestContractData to set
     */
    public void setRequestContractData(RequestContractData requestContractData) {
        this.requestContractData = requestContractData;
    }

    /**
     * <p>
     * Retrieves the serviceRequestScope field.
     * </p>
     *
     * @return the value of serviceRequestScope
     */
    public String getServiceRequestScope() {
        return serviceRequestScope;
    }

    /**
     * <p>
     * Sets the value to serviceRequestScope field.
     * </p>
     *
     * @param serviceRequestScope the value of serviceRequestScope to set
     */
    public void setServiceRequestScope(String serviceRequestScope) {
        this.serviceRequestScope = serviceRequestScope;
    }

    /**
     * <p>
     * Retrieves the travelRequirements field.
     * </p>
     *
     * @return the value of travelRequirements
     */
    public String getTravelRequirements() {
        return travelRequirements;
    }

    /**
     * <p>
     * Sets the value to travelRequirements field.
     * </p>
     *
     * @param travelRequirements the value of travelRequirements to set
     */
    public void setTravelRequirements(String travelRequirements) {
        this.travelRequirements = travelRequirements;
    }

    /**
     * <p>Gets the expenseType property.</p>
     *
     * @return a <code>ExpenseType</code> providing the value for expenseType property.
     * @since 1.6
     */
    public ExpenseType getExpenseType() {
        return this.expenseType;
    }

    /**
     * <p>Sets the expenseType property.</p>
     *
     * @param expenseType a <code>ExpenseType</code> providing the value for expenseType proeprty.
     * @since 1.6
     */
    public void setExpenseType(ExpenseType expenseType) {
        this.expenseType = expenseType;
    }

    /**
     * <p>Gets the oraclePartyID property.</p>
     *
     * @return a <code>Integer</code> providing the value for oraclePartyID property.
     * @since 1.6
     */
    public Integer getOraclePartyID() {
        return this.oraclePartyID;
    }

    /**
     * <p>Sets the oraclePartyID property.</p>
     *
     * @param oraclePartyID a <code>Integer</code> providing the value for oraclePartyID proeprty.
     * @since 1.6
     */
    public void setOraclePartyID(Integer oraclePartyID) {
        this.oraclePartyID = oraclePartyID;
    }

    /**
     * The toString method.
     *
     * @return the string for this entity
     */
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("{").append(super.toString());
        sb.append(", customerName:").append(customerName);
        sb.append(", projectName:").append(projectName);
        sb.append(", workCity:").append(workCity);
        sb.append(", dxQuoteNumber:").append(dxQuoteNumber);
        sb.append(", seCsdName:").append(seCsdName);
        sb.append(", pmName:").append(pmName);
        sb.append(", sfdcNumber:").append(sfdcNumber);
        sb.append(", seCsdPhone:").append(seCsdPhone);
        sb.append(", seManagerName:").append(seManagerName);
        sb.append(", phoneCallRequest:").append(phoneCallRequest);
        sb.append(", resellerSold:").append(resellerSold);
        sb.append(", requestedReturnDate:").append(requestedReturnDate);
        sb.append(", returnEquipment:").append(returnEquipment);
        sb.append(", expenseType:").append(expenseType);
        sb.append(", oraclePartyID:").append(oraclePartyID);
        sb.append(", remoteAccess:").append(remoteAccess);
        sb.append(", requestContractData:").append(requestContractData);
        sb.append(", serviceRequestScope:").append(serviceRequestScope);
        sb.append(", travelRequirements:").append(travelRequirements).append("}");
        return sb.toString();
    }
}

/*
 * This code is copyright (c) 2014 EMC Corporation
 */
package com.emc.gs.tools.srf.model.dpad;

/**
 * The Data Domain management center configuration type enum.
 * <p>
 * <strong>Thread safety</strong>: Enum is thread safety.
 * </p>
 * 
 * @author TCSASSEMBLER
 * @version 1.0
 * @since SRT Phase 3-5 - BRS Tabs Part 2 Assembly
 */
public enum DataDomainManagementCenterConfigType {

    /**
     * Small Configuration - 1 to 25 Data Domain.
     */
    SMALL_CONFIG("Small Configuration - 1 to 25 Data Domain"),

    /**
     * Medium Configuration - 1 to 50 Data Domain.
     */
    MEDIUM_CONFIG("Medium Configuration - 1 to 50 Data Domain"),

    /**
     * Large Configuration - 1 to 75 Data Domain.
     */
    LARGE_CONFIG("Large Configuration - 1 to 75 Data Domain");

    /**
     * The description.
     */
    private final String description;

    /**
     * <p>
     * The constructor with description.
     * </p>
     * 
     * @param description
     *            the description
     */
    private DataDomainManagementCenterConfigType(String description) {
        this.description = description;
    }

    /**
     * Override the toString method.
     * 
     * @return the description
     */
    @Override
    public String toString() {
        return description;
    }
}

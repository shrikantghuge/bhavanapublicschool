/*
 * This code is copyright (c) 2013 - 2014 EMC Corporation.
 */
package com.emc.gs.tools.srf.model;

/**
 * <p>
 * This is SortOrder enum class.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: It's immutable and thread safe.
 * </p>
 *
 * @author faeton, stevenfrog
 * @version 1.0
 */
public enum SortOrder {
    /**
     * <p>
     * The ASC.
     * </p>
     */
    ASC,

    /**
     * <p>
     * The DESC.
     * </p>
     */
    DESC
}

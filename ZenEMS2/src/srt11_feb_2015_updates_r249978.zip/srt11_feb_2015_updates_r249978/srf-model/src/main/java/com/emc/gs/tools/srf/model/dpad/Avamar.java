/*
 * This code is copyright (c) 2014 EMC Corporation
 */
package com.emc.gs.tools.srf.model.dpad;

import java.math.BigDecimal;

import com.emc.gs.tools.srf.model.IdentifiableEntity;

/**
 * <p>
 * This is Avamar entity class.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safety.
 * </p>
 *
 * <p>
 * Version 1.1 Change notes:
 *   <ol>
 *     <li>Added {@link #admeService} property.</li>
 *     <li>Added {@link #admeConfiguration} property.</li>
 *   </ol>
 * </p>
 * 
 * @author TCSASSEMBLER
 * @version 1.1
 * @since SRT Phase 3-5 - BRS Tabs Part 1 Assembly
 */
public class Avamar extends IdentifiableEntity {

    /**
     * # of Hours of Knowledge Transfer.
     */
    private BigDecimal knowledgeTransferHours;

    /**
     * Represents whether "Avamar Design & Implementation" service is selected.
     */
    private boolean designImplService;

    /**
     * Represents whether "Avamar Tape Out Design & Implementation" service is selected.
     */
    private boolean tapeOutDesignImplService;

    /**
     * Represents whether "Operational Assurance for Avamar" service is selected.
     */
    private boolean operationalAssuranceService;

    /**
     * Represents whether "Health Check for Avamar" service is selected.
     */
    private boolean healthCheckService;

    /**
     * Represents whether "Migration for Avamar" service is selected.
     */
    private boolean migrationService;

    /**
     * Represents whether "Intergration - Avamar Desktop-Laptop Pilot and Workshop" service is selected.
     */
    private boolean integrationService;

    /**
     * Represents whether "Implementation for Avamar for vCloud Director Plug-in" service is selected.
     */
    private boolean vcloudDirectorService;

    /**
     * Avamar Server Type.
     */
    private AvamarServerType serverType;

    /**
     * Represents whether "Design" deliver option is selected.
     */
    private boolean designDeliverOption;

    /**
     * Represents whether "Implementation" deliver option is selected.
     */
    private boolean implementationDeliverOption;

    /**
     * <p>A <code>boolean</code> providing the value for admeService property.</p>
     * 
     * @since 1.1
     */
    private boolean admeService;

    /**
     * Avamar Design data.
     */
    private AvamarDesign design;

    /**
     * Avamar Implementation data.
     */
    private AvamarImplementation implementation;

    /**
     * Avamar Tape Out Design data.
     */
    private AvamarTapeOutDesign tapeOutDesign;

    /**
     * Avamar Tape Out Implementation data.
     */
    private AvamarTapeOutImplementation tapeOutImplementation;

    /**
     * Avamar Operational Assurance data.
     */
    private AvamarOperationalAssurance operationalAssurance;

    /**
     * Avamar Health Check data.
     */
    private AvamarHealthCheck healthCheck;

    /**
     * Avamar Migration data.
     */
    private AvamarMigration migration;

    /**
     * Avamar Integration data.
     */
    private AvamarIntegration integration;

    /**
     * <p>A <code>AvamarADMEConfiguration</code> providing the value for admeConfiguration property.</p>
     * 
     * @since 1.1
     */
    private AvamarADMEConfiguration admeConfiguration;

    /**
     * <p>
     * The default constructor.
     * </p>
     */
    public Avamar() {
    }

    /**
     * Getter method for property <tt>knowledgeTransferHours</tt>.
     * 
     * @return property value of knowledgeTransferHours
     */
    public BigDecimal getKnowledgeTransferHours() {
        return knowledgeTransferHours;
    }

    /**
     * Setter method for property <tt>knowledgeTransferHours</tt>.
     * 
     * @param knowledgeTransferHours
     *            value to be assigned to property knowledgeTransferHours
     */
    public void setKnowledgeTransferHours(BigDecimal knowledgeTransferHours) {
        this.knowledgeTransferHours = knowledgeTransferHours;
    }

    /**
     * Getter method for property <tt>designImplService</tt>.
     * 
     * @return property value of designImplService
     */
    public boolean isDesignImplService() {
        return designImplService;
    }

    /**
     * Setter method for property <tt>designImplService</tt>.
     * 
     * @param designImplService
     *            value to be assigned to property designImplService
     */
    public void setDesignImplService(boolean designImplService) {
        this.designImplService = designImplService;
    }

    /**
     * Getter method for property <tt>tapeOutDesignImplService</tt>.
     * 
     * @return property value of tapeOutDesignImplService
     */
    public boolean isTapeOutDesignImplService() {
        return tapeOutDesignImplService;
    }

    /**
     * Setter method for property <tt>tapeOutDesignImplService</tt>.
     * 
     * @param tapeOutDesignImplService
     *            value to be assigned to property tapeOutDesignImplService
     */
    public void setTapeOutDesignImplService(boolean tapeOutDesignImplService) {
        this.tapeOutDesignImplService = tapeOutDesignImplService;
    }

    /**
     * Getter method for property <tt>operationalAssuranceService</tt>.
     * 
     * @return property value of operationalAssuranceService
     */
    public boolean isOperationalAssuranceService() {
        return operationalAssuranceService;
    }

    /**
     * Setter method for property <tt>operationalAssuranceService</tt>.
     * 
     * @param operationalAssuranceService
     *            value to be assigned to property operationalAssuranceService
     */
    public void setOperationalAssuranceService(boolean operationalAssuranceService) {
        this.operationalAssuranceService = operationalAssuranceService;
    }

    /**
     * Getter method for property <tt>healthCheckService</tt>.
     * 
     * @return property value of healthCheckService
     */
    public boolean isHealthCheckService() {
        return healthCheckService;
    }

    /**
     * Setter method for property <tt>healthCheckService</tt>.
     * 
     * @param healthCheckService
     *            value to be assigned to property healthCheckService
     */
    public void setHealthCheckService(boolean healthCheckService) {
        this.healthCheckService = healthCheckService;
    }

    /**
     * Getter method for property <tt>migrationService</tt>.
     * 
     * @return property value of migrationService
     */
    public boolean isMigrationService() {
        return migrationService;
    }

    /**
     * Setter method for property <tt>migrationService</tt>.
     * 
     * @param migrationService
     *            value to be assigned to property migrationService
     */
    public void setMigrationService(boolean migrationService) {
        this.migrationService = migrationService;
    }

    /**
     * Getter method for property <tt>integrationService</tt>.
     * 
     * @return property value of integrationService
     */
    public boolean isIntegrationService() {
        return integrationService;
    }

    /**
     * Setter method for property <tt>integrationService</tt>.
     * 
     * @param integrationService
     *            value to be assigned to property integrationService
     */
    public void setIntegrationService(boolean integrationService) {
        this.integrationService = integrationService;
    }

    /**
     * Getter method for property <tt>vcloudDirectorService</tt>.
     * 
     * @return property value of vcloudDirectorService
     */
    public boolean isVcloudDirectorService() {
        return vcloudDirectorService;
    }

    /**
     * Setter method for property <tt>vcloudDirectorService</tt>.
     * 
     * @param vcloudDirectorService
     *            value to be assigned to property vcloudDirectorService
     */
    public void setVcloudDirectorService(boolean vcloudDirectorService) {
        this.vcloudDirectorService = vcloudDirectorService;
    }

    /**
     * Getter method for property <tt>serverType</tt>.
     * 
     * @return property value of serverType
     */
    public AvamarServerType getServerType() {
        return serverType;
    }

    /**
     * Setter method for property <tt>serverType</tt>.
     * 
     * @param serverType
     *            value to be assigned to property serverType
     */
    public void setServerType(AvamarServerType serverType) {
        this.serverType = serverType;
    }

    /**
     * Getter method for property <tt>designDeliverOption</tt>.
     * 
     * @return property value of designDeliverOption
     */
    public boolean isDesignDeliverOption() {
        return designDeliverOption;
    }

    /**
     * Setter method for property <tt>designDeliverOption</tt>.
     * 
     * @param designDeliverOption
     *            value to be assigned to property designDeliverOption
     */
    public void setDesignDeliverOption(boolean designDeliverOption) {
        this.designDeliverOption = designDeliverOption;
    }

    /**
     * Getter method for property <tt>implementationDeliverOption</tt>.
     * 
     * @return property value of implementationDeliverOption
     */
    public boolean isImplementationDeliverOption() {
        return implementationDeliverOption;
    }

    /**
     * Setter method for property <tt>implementationDeliverOption</tt>.
     * 
     * @param implementationDeliverOption
     *            value to be assigned to property implementationDeliverOption
     */
    public void setImplementationDeliverOption(boolean implementationDeliverOption) {
        this.implementationDeliverOption = implementationDeliverOption;
    }

    /**
     * Getter method for property <tt>design</tt>.
     * 
     * @return property value of design
     */
    public AvamarDesign getDesign() {
        return design;
    }

    /**
     * Setter method for property <tt>design</tt>.
     * 
     * @param design
     *            value to be assigned to property design
     */
    public void setDesign(AvamarDesign design) {
        this.design = design;
    }

    /**
     * Getter method for property <tt>implementation</tt>.
     * 
     * @return property value of implementation
     */
    public AvamarImplementation getImplementation() {
        return implementation;
    }

    /**
     * Setter method for property <tt>implementation</tt>.
     * 
     * @param implementation
     *            value to be assigned to property implementation
     */
    public void setImplementation(AvamarImplementation implementation) {
        this.implementation = implementation;
    }

    /**
     * Getter method for property <tt>tapeOutDesign</tt>.
     * 
     * @return property value of tapeOutDesign
     */
    public AvamarTapeOutDesign getTapeOutDesign() {
        return tapeOutDesign;
    }

    /**
     * Setter method for property <tt>tapeOutDesign</tt>.
     * 
     * @param tapeOutDesign
     *            value to be assigned to property tapeOutDesign
     */
    public void setTapeOutDesign(AvamarTapeOutDesign tapeOutDesign) {
        this.tapeOutDesign = tapeOutDesign;
    }

    /**
     * Getter method for property <tt>tapeOutImplementation</tt>.
     * 
     * @return property value of tapeOutImplementation
     */
    public AvamarTapeOutImplementation getTapeOutImplementation() {
        return tapeOutImplementation;
    }

    /**
     * Setter method for property <tt>tapeOutImplementation</tt>.
     * 
     * @param tapeOutImplementation
     *            value to be assigned to property tapeOutImplementation
     */
    public void setTapeOutImplementation(AvamarTapeOutImplementation tapeOutImplementation) {
        this.tapeOutImplementation = tapeOutImplementation;
    }

    /**
     * Getter method for property <tt>operationalAssurance</tt>.
     * 
     * @return property value of operationalAssurance
     */
    public AvamarOperationalAssurance getOperationalAssurance() {
        return operationalAssurance;
    }

    /**
     * Setter method for property <tt>operationalAssurance</tt>.
     * 
     * @param operationalAssurance
     *            value to be assigned to property operationalAssurance
     */
    public void setOperationalAssurance(AvamarOperationalAssurance operationalAssurance) {
        this.operationalAssurance = operationalAssurance;
    }

    /**
     * Getter method for property <tt>healthCheck</tt>.
     * 
     * @return property value of healthCheck
     */
    public AvamarHealthCheck getHealthCheck() {
        return healthCheck;
    }

    /**
     * Setter method for property <tt>healthCheck</tt>.
     * 
     * @param healthCheck
     *            value to be assigned to property healthCheck
     */
    public void setHealthCheck(AvamarHealthCheck healthCheck) {
        this.healthCheck = healthCheck;
    }

    /**
     * Getter method for property <tt>migration</tt>.
     * 
     * @return property value of migration
     */
    public AvamarMigration getMigration() {
        return migration;
    }

    /**
     * Setter method for property <tt>migration</tt>.
     * 
     * @param migration
     *            value to be assigned to property migration
     */
    public void setMigration(AvamarMigration migration) {
        this.migration = migration;
    }

    /**
     * Getter method for property <tt>integration</tt>.
     * 
     * @return property value of integration
     */
    public AvamarIntegration getIntegration() {
        return integration;
    }

    /**
     * Setter method for property <tt>integration</tt>.
     * 
     * @param integration
     *            value to be assigned to property integration
     */
    public void setIntegration(AvamarIntegration integration) {
        this.integration = integration;
    }

    /**
     * <p>Gets the admeService property.</p>
     *
     * @return a <code>boolean</code> providing the value for admeService property.
     * @since 1.1
     */
    public boolean getAdmeService() {
        return this.admeService;
    }

    /**
     * <p>Sets the admeService property.</p>
     *
     * @param admeService a <code>boolean</code> providing the value for admeService property.
     * @since 1.1
     */
    public void setAdmeService(boolean admeService) {
        this.admeService = admeService;
    }

    /**
     * <p>Gets the admeConfiguration property.</p>
     *
     * @return a <code>AvamarADMEConfiguration</code> providing the value for admeConfiguration property.
     * @since 1.1
     */
    public AvamarADMEConfiguration getAdmeConfiguration() {
        return this.admeConfiguration;
    }

    /**
     * <p>Sets the admeConfiguration property.</p>
     *
     * @param admeConfiguration a <code>AvamarADMEConfiguration</code> providing the value for admeConfiguration
     * property.
     * @since 1.1
     */
    public void setAdmeConfiguration(AvamarADMEConfiguration admeConfiguration) {
        this.admeConfiguration = admeConfiguration;
    }

}

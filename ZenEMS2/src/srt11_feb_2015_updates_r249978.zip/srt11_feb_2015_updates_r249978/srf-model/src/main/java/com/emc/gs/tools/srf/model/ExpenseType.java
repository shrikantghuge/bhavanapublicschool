/*
 * This code is copyright (c) 2014 EMC Corporation.
 */
package com.emc.gs.tools.srf.model;

/**
 * <p>This is ExpenseType entity class.</p>
 *
 * <p><strong>Thread safety</strong>: This class is mutable, it is not thread safety.</p>
 *
 * @author TCSASSEMBLER
 * @version 1.0 (SRT Phase 4 - ET Release Assembly)
 */
public class ExpenseType extends LookupEntity {

    /**
     * <p>Constructs new <code>ExpenseType</code> instance. This implementation does nothing.</p>
     */
    public ExpenseType() {
    }
}

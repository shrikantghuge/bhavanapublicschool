/*
 * This code is copyright (c) 2014 EMC Corporation
 */
package com.emc.gs.tools.srf.model.dpad;

/**
 * <p>
 * This is DataDomainIntegration entity class.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safety.
 * </p>
 * 
 * @author TCSASSEMBLER
 * @version 1.0
 * @since SRT Phase 3-5 - BRS Tabs Part 2 Assembly
 */
public class DataDomainIntegration extends DataDomainBoostBase {

    /**
     * Data Domain Integration Type.
     */
    private DataDomainIntegrationType integrationType;

    /**
     * Represents whether "IBM Tivoli Storage Manager" backup application is selected.
     */
    private boolean ibmTivoliStorageManager;

    /**
     * Represents whether "Networker" backup application is selected.
     */
    private boolean networker;

    /**
     * Represents whether "NetBackup" backup application is selected.
     */
    private boolean netBackup;

    /**
     * Represents whether "RMAN" backup application is selected.
     */
    private boolean rman;

    /**
     * # of Interviews to be conducted.
     */
    private Integer conductedInterviewsNum;

    /**
     * # of IBM TSM Instances.
     */
    private Integer ibmTSMInstancesNum;

    /**
     * # of Networker DataZones.
     */
    private Integer networkerDataZonesNum;

    /**
     * # of Symantec NetBackup Domains.
     */
    private Integer symantecNetBackupDomainsNum;

    /**
     * # of Oracle Data Servers for RMAN.
     */
    private Integer oracleDataServersNum;

    /**
     * # of SAP Hana Databases Targeted for Backup.
     */
    private Integer sapHanaDatabasesNum;

    /**
     * <p>
     * The default constructor.
     * </p>
     */
    public DataDomainIntegration() {
    }

    /**
     * Getter method for property <tt>integrationType</tt>.
     * 
     * @return property value of integrationType
     */
    public DataDomainIntegrationType getIntegrationType() {
        return integrationType;
    }

    /**
     * Setter method for property <tt>integrationType</tt>.
     * 
     * @param integrationType
     *            value to be assigned to property integrationType
     */
    public void setIntegrationType(DataDomainIntegrationType integrationType) {
        this.integrationType = integrationType;
    }

    /**
     * Getter method for property <tt>ibmTivoliStorageManager</tt>.
     * 
     * @return property value of ibmTivoliStorageManager
     */
    public boolean isIbmTivoliStorageManager() {
        return ibmTivoliStorageManager;
    }

    /**
     * Setter method for property <tt>ibmTivoliStorageManager</tt>.
     * 
     * @param ibmTivoliStorageManager
     *            value to be assigned to property ibmTivoliStorageManager
     */
    public void setIbmTivoliStorageManager(boolean ibmTivoliStorageManager) {
        this.ibmTivoliStorageManager = ibmTivoliStorageManager;
    }

    /**
     * Getter method for property <tt>networker</tt>.
     * 
     * @return property value of networker
     */
    public boolean isNetworker() {
        return networker;
    }

    /**
     * Setter method for property <tt>networker</tt>.
     * 
     * @param networker
     *            value to be assigned to property networker
     */
    public void setNetworker(boolean networker) {
        this.networker = networker;
    }

    /**
     * Getter method for property <tt>netBackup</tt>.
     * 
     * @return property value of netBackup
     */
    public boolean isNetBackup() {
        return netBackup;
    }

    /**
     * Setter method for property <tt>netBackup</tt>.
     * 
     * @param netBackup
     *            value to be assigned to property netBackup
     */
    public void setNetBackup(boolean netBackup) {
        this.netBackup = netBackup;
    }

    /**
     * Getter method for property <tt>rman</tt>.
     * 
     * @return property value of rman
     */
    public boolean isRman() {
        return rman;
    }

    /**
     * Setter method for property <tt>rman</tt>.
     * 
     * @param rman
     *            value to be assigned to property rman
     */
    public void setRman(boolean rman) {
        this.rman = rman;
    }

    /**
     * Getter method for property <tt>conductedInterviewsNum</tt>.
     * 
     * @return property value of conductedInterviewsNum
     */
    public Integer getConductedInterviewsNum() {
        return conductedInterviewsNum;
    }

    /**
     * Setter method for property <tt>conductedInterviewsNum</tt>.
     * 
     * @param conductedInterviewsNum
     *            value to be assigned to property conductedInterviewsNum
     */
    public void setConductedInterviewsNum(Integer conductedInterviewsNum) {
        this.conductedInterviewsNum = conductedInterviewsNum;
    }

    /**
     * Getter method for property <tt>ibmTSMInstancesNum</tt>.
     * 
     * @return property value of ibmTSMInstancesNum
     */
    public Integer getIbmTSMInstancesNum() {
        return ibmTSMInstancesNum;
    }

    /**
     * Setter method for property <tt>ibmTSMInstancesNum</tt>.
     * 
     * @param ibmTSMInstancesNum
     *            value to be assigned to property ibmTSMInstancesNum
     */
    public void setIbmTSMInstancesNum(Integer ibmTSMInstancesNum) {
        this.ibmTSMInstancesNum = ibmTSMInstancesNum;
    }

    /**
     * Getter method for property <tt>networkerDataZonesNum</tt>.
     * 
     * @return property value of networkerDataZonesNum
     */
    public Integer getNetworkerDataZonesNum() {
        return networkerDataZonesNum;
    }

    /**
     * Setter method for property <tt>networkerDataZonesNum</tt>.
     * 
     * @param networkerDataZonesNum
     *            value to be assigned to property networkerDataZonesNum
     */
    public void setNetworkerDataZonesNum(Integer networkerDataZonesNum) {
        this.networkerDataZonesNum = networkerDataZonesNum;
    }

    /**
     * Getter method for property <tt>symantecNetBackupDomainsNum</tt>.
     * 
     * @return property value of symantecNetBackupDomainsNum
     */
    public Integer getSymantecNetBackupDomainsNum() {
        return symantecNetBackupDomainsNum;
    }

    /**
     * Setter method for property <tt>symantecNetBackupDomainsNum</tt>.
     * 
     * @param symantecNetBackupDomainsNum
     *            value to be assigned to property symantecNetBackupDomainsNum
     */
    public void setSymantecNetBackupDomainsNum(Integer symantecNetBackupDomainsNum) {
        this.symantecNetBackupDomainsNum = symantecNetBackupDomainsNum;
    }

    /**
     * Getter method for property <tt>oracleDataServersNum</tt>.
     * 
     * @return property value of oracleDataServersNum
     */
    public Integer getOracleDataServersNum() {
        return oracleDataServersNum;
    }

    /**
     * Setter method for property <tt>oracleDataServersNum</tt>.
     * 
     * @param oracleDataServersNum
     *            value to be assigned to property oracleDataServersNum
     */
    public void setOracleDataServersNum(Integer oracleDataServersNum) {
        this.oracleDataServersNum = oracleDataServersNum;
    }

    /**
     * Getter method for property <tt>sapHanaDatabasesNum</tt>.
     * 
     * @return property value of sapHanaDatabasesNum
     */
    public Integer getSapHanaDatabasesNum() {
        return sapHanaDatabasesNum;
    }

    /**
     * Setter method for property <tt>sapHanaDatabasesNum</tt>.
     * 
     * @param sapHanaDatabasesNum
     *            value to be assigned to property sapHanaDatabasesNum
     */
    public void setSapHanaDatabasesNum(Integer sapHanaDatabasesNum) {
        this.sapHanaDatabasesNum = sapHanaDatabasesNum;
    }

}

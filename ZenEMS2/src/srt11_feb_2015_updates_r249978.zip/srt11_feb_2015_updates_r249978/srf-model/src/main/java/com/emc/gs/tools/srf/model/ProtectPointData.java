/*
 * This code is copyright (c) 2014 EMC Corporation.
 */
package com.emc.gs.tools.srf.model;

/**
 * <p>This is ProtectPointData entity class.</p>
 *
 * <p><strong>Thread safety</strong>: This class is mutable, it is not thread safety.</p>
 *
 * @author isv
 */
public class ProtectPointData extends IdentifiableEntity {

    /**
     * <p>A <code>Integer</code> providing the value for numberOfDataDomainAppliancesForBackups property.</p>
     */
    private Integer numberOfDataDomainAppliancesForBackups;

    /**
     * <p>A <code>Integer</code> providing the value for numberOfStorageArraysForBackups property.</p>
     */
    private Integer numberOfStorageArraysForBackups;

    /**
     * <p>A <code>Integer</code> providing the value for numberOfApplicationHosts property.</p>
     */
    private Integer numberOfApplicationHosts;

    /**
     * <p>A <code>Integer</code> providing the value for numberOfBackupConfigFiles property.</p>
     */
    private Integer numberOfBackupConfigFiles;

    /**
     * <p>A <code>Integer</code> providing the value for numberOfDatabaseInstancesToBackup property.</p>
     */
    private Integer numberOfDatabaseInstancesToBackup;

    /**
     * <p>A <code>RecoveryLevelType</code> providing the value for recoveryLevelType property.</p>
     */
    private RecoveryLevelType recoveryLevelType;

    /**
     * <p>A <code>Integer</code> providing the value for numberOfDatabaseInstancesForObjectLevelRecovery property .</p>
     */
    private Integer numberOfDatabaseInstancesForObjectLevelRecovery;

    /**
     * <p>A <code>Integer</code> providing the value for numberOfDatabaseInstancesForFullLUNRecovery property.</p>
     */
    private Integer numberOfDatabaseInstancesForFullLUNRecovery;

    /**
     * <p>Constructs new <code>ProtectPointData</code> instance. This implementation does nothing.</p>
     */
    public ProtectPointData() {
    }

    /**
     * <p>Gets the numberOfDatabaseInstancesForFullLUNRecovery property.</p>
     *
     * @return a <code>Integer</code> providing the value for numberOfDatabaseInstancesForFullLUNRecovery property.
     */
    public Integer getNumberOfDatabaseInstancesForFullLUNRecovery() {
        return this.numberOfDatabaseInstancesForFullLUNRecovery;
    }

    /**
     * <p>Sets the numberOfDatabaseInstancesForFullLUNRecovery property.</p>
     *
     * @param numberOfDatabaseInstancesForFullLUNRecovery a <code>Integer</code> providing the value for
     * numberOfDatabaseInstancesForFullLUNRecovery property.
     */
    public void setNumberOfDatabaseInstancesForFullLUNRecovery(Integer numberOfDatabaseInstancesForFullLUNRecovery) {
        this.numberOfDatabaseInstancesForFullLUNRecovery = numberOfDatabaseInstancesForFullLUNRecovery;
    }

    /**
     * <p>Gets the numberOfDatabaseInstancesForObjectLevelRecovery property.</p>
     *
     * @return a <code>Integer</code> providing the value for numberOfDatabaseInstancesForObjectLevelRecovery property.
     */
    public Integer getNumberOfDatabaseInstancesForObjectLevelRecovery() {
        return this.numberOfDatabaseInstancesForObjectLevelRecovery;
    }

    /**
     * <p>Sets the numberOfDatabaseInstancesForObjectLevelRecovery property.</p>
     *
     * @param numberOfDatabaseInstancesForObjectLevelRecovery a <code>Integer</code> providing the value for
     * numberOfDatabaseInstancesForObjectLevelRecovery property.
     */
    public void setNumberOfDatabaseInstancesForObjectLevelRecovery(
        Integer numberOfDatabaseInstancesForObjectLevelRecovery) {
        this.numberOfDatabaseInstancesForObjectLevelRecovery = numberOfDatabaseInstancesForObjectLevelRecovery;
    }

    /**
     * <p>Gets the recoveryLevelType property.</p>
     *
     * @return a <code>RecoveryLevelType</code> providing the value for recoveryLevelType property.
     */
    public RecoveryLevelType getRecoveryLevelType() {
        return this.recoveryLevelType;
    }

    /**
     * <p>Sets the recoveryLevelType property.</p>
     *
     * @param recoveryLevelType a <code>RecoveryLevelType</code> providing the value for recoveryLevelType property.
     */
    public void setRecoveryLevelType(RecoveryLevelType recoveryLevelType) {
        this.recoveryLevelType = recoveryLevelType;
    }

    /**
     * <p>Gets the numberOfDatabaseInstancesToBackup property.</p>
     *
     * @return a <code>Integer</code> providing the value for numberOfDatabaseInstancesToBackup property.
     */
    public Integer getNumberOfDatabaseInstancesToBackup() {
        return this.numberOfDatabaseInstancesToBackup;
    }

    /**
     * <p>Sets the numberOfDatabaseInstancesToBackup property.</p>
     *
     * @param numberOfDatabaseInstancesToBackup a <code>Integer</code> providing the value for
     * numberOfDatabaseInstancesToBackup property.
     */
    public void setNumberOfDatabaseInstancesToBackup(Integer numberOfDatabaseInstancesToBackup) {
        this.numberOfDatabaseInstancesToBackup = numberOfDatabaseInstancesToBackup;
    }

    /**
     * <p>Gets the numberOfBackupConfigFiles property.</p>
     *
     * @return a <code>Integer</code> providing the value for numberOfBackupConfigFiles property.
     */
    public Integer getNumberOfBackupConfigFiles() {
        return this.numberOfBackupConfigFiles;
    }

    /**
     * <p>Sets the numberOfBackupConfigFiles property.</p>
     *
     * @param numberOfBackupConfigFiles a <code>Integer</code> providing the value for numberOfBackupConfigFiles
     * property.
     */
    public void setNumberOfBackupConfigFiles(Integer numberOfBackupConfigFiles) {
        this.numberOfBackupConfigFiles = numberOfBackupConfigFiles;
    }

    /**
     * <p>Gets the numberOfApplicationHosts property.</p>
     *
     * @return a <code>Integer</code> providing the value for numberOfApplicationHosts property.
     */
    public Integer getNumberOfApplicationHosts() {
        return this.numberOfApplicationHosts;
    }

    /**
     * <p>Sets the numberOfApplicationHosts property.</p>
     *
     * @param numberOfApplicationHosts a <code>Integer</code> providing the value for numberOfApplicationHosts
     * property.
     */
    public void setNumberOfApplicationHosts(Integer numberOfApplicationHosts) {
        this.numberOfApplicationHosts = numberOfApplicationHosts;
    }

    /**
     * <p>Gets the numberOfStorageArraysForBackups property.</p>
     *
     * @return a <code>Integer</code> providing the value for numberOfStorageArraysForBackups property.
     */
    public Integer getNumberOfStorageArraysForBackups() {
        return this.numberOfStorageArraysForBackups;
    }

    /**
     * <p>Sets the numberOfStorageArraysForBackups property.</p>
     *
     * @param numberOfStorageArraysForBackups a <code>Integer</code> providing the value for
     * numberOfStorageArraysForBackups property.
     */
    public void setNumberOfStorageArraysForBackups(Integer numberOfStorageArraysForBackups) {
        this.numberOfStorageArraysForBackups = numberOfStorageArraysForBackups;
    }

    /**
     * <p>Gets the numberOfDataDomainAppliancesForBackups property.</p>
     *
     * @return a <code>Integer</code> providing the value for numberOfDataDomainAppliancesForBackups property.
     */
    public Integer getNumberOfDataDomainAppliancesForBackups() {
        return this.numberOfDataDomainAppliancesForBackups;
    }

    /**
     * <p>Sets the numberOfDataDomainAppliancesForBackups property.</p>
     *
     * @param numberOfDataDomainAppliancesForBackups a <code>Integer</code> providing the value for
     * numberOfDataDomainAppliancesForBackups property.
     */
    public void setNumberOfDataDomainAppliancesForBackups(Integer numberOfDataDomainAppliancesForBackups) {
        this.numberOfDataDomainAppliancesForBackups = numberOfDataDomainAppliancesForBackups;
    }

}

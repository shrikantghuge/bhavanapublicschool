/*
 * This code is copyright (c) 2014 EMC Corporation.
 */
package com.emc.gs.tools.srf.model;

/**
 * <p>
 * This is LookupCodeEntity entity class.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safety.
 * </p>
 * 
 * @author TCSASSEMBLER
 * @version 1.0
 * @since SRT Phase 4 - ET Assembly 1
 */
public abstract class LookupCodeEntity extends LookupEntity {

    /**
     * The code.
     */
    private String code;

    /**
     * Empty constructor.
     */
    public LookupCodeEntity() {
    }

    /**
     * Getter method for property <tt>code</tt>.
     * 
     * @return property value of code
     */
    public String getCode() {
        return code;
    }

    /**
     * Setter method for property <tt>code</tt>.
     * 
     * @param code
     *            value to be assigned to property code
     */
    public void setCode(String code) {
        this.code = code;
    }

}

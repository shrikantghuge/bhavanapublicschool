/*
 * This code is copyright (c) 2014 EMC Corporation.
 */
package com.emc.gs.tools.srf.model.change;

import java.util.List;

import com.emc.gs.tools.srf.model.IdentifiableEntity;

/**
 * <p>
 * This is ChangeRequestData entity class. It maps directly to the fields described in Detailed Tab Documentation -
 * Change Request.docx
 * </p>
 * 
 * v1.1 - added general comments field
 * @author TCSASSEMBLER
 * @version 1.1
 * @since SRT Phase 3-2 - Move Request and Change Request Tabs Assembly
 */
public class ChangeRequestData extends IdentifiableEntity {

    /**
     * General comments.
     * @since 1.1
     */
    private String generalComments;

    /**
     * # of Months.
     */
    private Integer numberOfMonths;

    /**
     * Hours By Month.
     */
    private List<HoursByMonth> rows;

    /**
     * Empty constructor.
     */
    public ChangeRequestData() {
    }

    /**
     * Gets the value of the field <code>numberOfMonths</code>.
     * 
     * @return the numberOfMonths
     */
    public Integer getNumberOfMonths() {
        return numberOfMonths;
    }

    /**
     * Sets the value of the field <code>numberOfMonths</code>.
     * 
     * @param numberOfMonths the numberOfMonths to set
     */
    public void setNumberOfMonths(Integer numberOfMonths) {
        this.numberOfMonths = numberOfMonths;
    }

    /**
     * Gets the value of the field <code>rows</code>.
     * 
     * @return the rows
     */
    public List<HoursByMonth> getRows() {
        return rows;
    }

    /**
     * Sets the value of the field <code>rows</code>.
     * 
     * @param rows the rows to set
     */
    public void setRows(List<HoursByMonth> rows) {
        this.rows = rows;
    }

    /**
     * Gets the value of the field <code>generalComments</code>.
     * @return the generalComments
     * @since 1.1
     */
    public String getGeneralComments() {
        return generalComments;
    }

    /**
     * Sets the value of the field <code>generalComments</code>.
     * @param generalComments the generalComments to set
     * @since 1.1
     */
    public void setGeneralComments(String generalComments) {
        this.generalComments = generalComments;
    }

    /**
     * Generates a string representation of this entity.
     * 
     * @return the properties of this object.
     */
    @Override
    public String toString() {
        return "ChangeRequestData [generalComments=" + generalComments + ",numberOfMonths=" + numberOfMonths + ", rows=" + rows + ", getId()=" + getId() + "]";
    }
}

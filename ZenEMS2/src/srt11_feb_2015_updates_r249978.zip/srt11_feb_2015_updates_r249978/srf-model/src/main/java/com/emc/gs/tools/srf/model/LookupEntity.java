/*
 * This code is copyright (c) 2013 - 2014 EMC Corporation.
 */
package com.emc.gs.tools.srf.model;

/**
 * <p>
 * This is Lookup entity class.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it's not thread safety.
 * </p>
 *
 * @author faeton, stevenfrog
 * @version 1.0
 */
public abstract class LookupEntity extends IdentifiableEntity {
    /**
     * The name.
     */
    private String name;

    /**
     * The constructor.
     */
    protected LookupEntity() {
        // Empty
    }

    /**
     * <p>
     * Retrieves the name field.
     * </p>
     *
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * <p>
     * Sets the value to name field.
     * </p>
     *
     * @param name
     *            the name to set
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * The toString method.
     *
     * @return the string of this entity
     */
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("{").append(super.toString());
        sb.append(", name:").append(name).append("}");
        return sb.toString();
    }

}

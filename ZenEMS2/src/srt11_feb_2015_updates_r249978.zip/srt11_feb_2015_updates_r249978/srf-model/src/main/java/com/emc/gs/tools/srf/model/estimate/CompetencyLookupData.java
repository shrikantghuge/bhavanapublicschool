/*
 * This code is copyright (c) 2014 EMC Corporation.
 */
package com.emc.gs.tools.srf.model.estimate;

import java.util.Map;

import com.emc.gs.tools.srf.model.LookupCodeEntity;

/**
 * <p>
 * This is CompetencyLookupData entity class.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safety.
 * </p>
 * 
 * @author TCSASSEMBLER
 * @version 1.0
 * @since SRT Phase 4 - ET Assembly 1
 */
public class CompetencyLookupData extends LookupCodeEntity {

    /**
     * The BOE roles of this competency.
     */
    private Map<Long, BOERole> roles;

    /**
     * Empty constructor.
     */
    public CompetencyLookupData() {
    }

    /**
     * Getter method for property <tt>roles</tt>.
     * 
     * @return property value of roles
     */
    public Map<Long, BOERole> getRoles() {
        return roles;
    }

    /**
     * Setter method for property <tt>roles</tt>.
     * 
     * @param roles
     *            value to be assigned to property roles
     */
    public void setRoles(Map<Long, BOERole> roles) {
        this.roles = roles;
    }

}

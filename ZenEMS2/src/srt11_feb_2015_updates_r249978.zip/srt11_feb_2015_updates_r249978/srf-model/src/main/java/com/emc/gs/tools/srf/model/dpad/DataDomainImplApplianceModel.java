/*
 * This code is copyright (c) 2014 EMC Corporation
 */
package com.emc.gs.tools.srf.model.dpad;

/**
 * <p>
 * This is DataDomainImplApplianceModel entity class.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safety.
 * </p>
 *
 * <p>
 * Version 1.1 Change notes:
 *   <ol>
 *     <li>Removed <code>virtualTapeLibraryAppliances</code> property.</li>
 *   </ol>
 * </p>
 * 
 * @author TCSASSEMBLER
 * @version 1.1
 * @since SRT Phase 3-5 - BRS Tabs Part 2 Assembly
 */
public class DataDomainImplApplianceModel extends DataDomainApplianceModelBase {

    /**
     * # of Expansion Shelves.
     */
    private Integer expansionShelvesNum;

    /**
     * Include IP Replication.
     */
    private Boolean includeIPReplication;

    /**
     * Device Type.
     */
    private DataDomainDeviceType deviceType;

    /**
     * Virtual Tape Library Appliances.
     */
    private Boolean virtualTapeLibraryAppliances;

    /**
     * DB Boost.
     */
    private Boolean dbBoost;

    /**
     * # of VTL's to create.
     */
    private Integer edlVirtualTapeLibrariesNum;

    /**
     * # of DD Boost Servers.
     */
    private Integer ddBoostServersNum;

    /**
     * <p>
     * The default constructor.
     * </p>
     */
    public DataDomainImplApplianceModel() {
    }

    /**
     * Getter method for property <tt>expansionShelvesNum</tt>.
     * 
     * @return property value of expansionShelvesNum
     */
    public Integer getExpansionShelvesNum() {
        return expansionShelvesNum;
    }

    /**
     * Setter method for property <tt>expansionShelvesNum</tt>.
     * 
     * @param expansionShelvesNum
     *            value to be assigned to property expansionShelvesNum
     */
    public void setExpansionShelvesNum(Integer expansionShelvesNum) {
        this.expansionShelvesNum = expansionShelvesNum;
    }

    /**
     * Getter method for property <tt>includeIPReplication</tt>.
     * 
     * @return property value of includeIPReplication
     */
    public Boolean getIncludeIPReplication() {
        return includeIPReplication;
    }

    /**
     * Setter method for property <tt>includeIPReplication</tt>.
     * 
     * @param includeIPReplication
     *            value to be assigned to property includeIPReplication
     */
    public void setIncludeIPReplication(Boolean includeIPReplication) {
        this.includeIPReplication = includeIPReplication;
    }

    /**
     * Getter method for property <tt>deviceType</tt>.
     * 
     * @return property value of deviceType
     */
    public DataDomainDeviceType getDeviceType() {
        return deviceType;
    }

    /**
     * Setter method for property <tt>deviceType</tt>.
     * 
     * @param deviceType
     *            value to be assigned to property deviceType
     */
    public void setDeviceType(DataDomainDeviceType deviceType) {
        this.deviceType = deviceType;
    }

    /**
     * Getter method for property <tt>edlVirtualTapeLibrariesNum</tt>.
     * 
     * @return property value of edlVirtualTapeLibrariesNum
     */
    public Integer getEdlVirtualTapeLibrariesNum() {
        return edlVirtualTapeLibrariesNum;
    }

    /**
     * Setter method for property <tt>edlVirtualTapeLibrariesNum</tt>.
     * 
     * @param edlVirtualTapeLibrariesNum
     *            value to be assigned to property edlVirtualTapeLibrariesNum
     */
    public void setEdlVirtualTapeLibrariesNum(Integer edlVirtualTapeLibrariesNum) {
        this.edlVirtualTapeLibrariesNum = edlVirtualTapeLibrariesNum;
    }

    /**
     * Getter method for property <tt>dbBoost</tt>.
     * 
     * @return property value of dbBoost
     */
    public Boolean getDbBoost() {
        return dbBoost;
    }

    /**
     * Setter method for property <tt>dbBoost</tt>.
     * 
     * @param dbBoost
     *            value to be assigned to property dbBoost
     */
    public void setDbBoost(Boolean dbBoost) {
        this.dbBoost = dbBoost;
    }

    /**
     * Getter method for property <tt>ddBoostServersNum</tt>.
     * 
     * @return property value of ddBoostServersNum
     */
    public Integer getDdBoostServersNum() {
        return ddBoostServersNum;
    }

    /**
     * Setter method for property <tt>ddBoostServersNum</tt>.
     * 
     * @param ddBoostServersNum
     *            value to be assigned to property ddBoostServersNum
     */
    public void setDdBoostServersNum(Integer ddBoostServersNum) {
        this.ddBoostServersNum = ddBoostServersNum;
    }
}

/*
 * This code is copyright (c) 2014 EMC Corporation
 */
package com.emc.gs.tools.srf.model.dpad;

import java.math.BigDecimal;

import com.emc.gs.tools.srf.model.IdentifiableEntity;

/**
 * <p>
 * This is AvamarNDMP entity class.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safety.
 * </p>
 * 
 * @author TCSASSEMBLER
 * @version 1.0
 * @since SRT Phase 3-5 - BRS Tabs Part 1 Assembly
 */
public class AvamarNDMP extends IdentifiableEntity {

    /**
     * Represents whether NDMP type "EMC Celerra" is selected.
     */
    private boolean emcCelerra;

    /**
     * Represents whether NDMP type "Network Appliance" is selected.
     */
    private boolean networkAppliance;

    /**
     * Represents whether NDMP type "EMC Isilon" is selected.
     */
    private boolean emcIsilon;

    /**
     * Represents whether NDMP type "EMC VNX/VNXe" is selected.
     */
    private boolean emcVnx;

    /**
     * # of Avamar NDMP Accelerator Nodes.
     */
    private Integer ndmpNodesNum;

    /**
     * Include Avamar NDMP Multistream support?
     */
    private Boolean includeMultistreamSupport;

    /**
     * # of Streams per NDMP Node.
     */
    private Integer streamsPerNodeNum;

    /**
     * # of Celerra NDMP Targets for NDMP.
     */
    private Integer celerraTargetsNum;

    /**
     * # of NetApp Filer NDMP Targets.
     */
    private Integer netAppFilerTargetsNum;

    /**
     * # of Isilon NDMP targets.
     */
    private Integer isilonTargetsNum;

    /**
     * # of VNX/VNXe NDMP targets.
     */
    private Integer vnxTargetsNum;

    /**
     * # of hours for NDMP Data Set and Policy Creation(Default 4 Hrs).
     */
    private BigDecimal dataSetCreationHours;

    /**
     * <p>
     * The default constructor.
     * </p>
     */
    public AvamarNDMP() {
    }

    /**
     * Getter method for property <tt>emcCelerra</tt>.
     * 
     * @return property value of emcCelerra
     */
    public boolean isEmcCelerra() {
        return emcCelerra;
    }

    /**
     * Setter method for property <tt>emcCelerra</tt>.
     * 
     * @param emcCelerra
     *            value to be assigned to property emcCelerra
     */
    public void setEmcCelerra(boolean emcCelerra) {
        this.emcCelerra = emcCelerra;
    }

    /**
     * Getter method for property <tt>networkAppliance</tt>.
     * 
     * @return property value of networkAppliance
     */
    public boolean isNetworkAppliance() {
        return networkAppliance;
    }

    /**
     * Setter method for property <tt>networkAppliance</tt>.
     * 
     * @param networkAppliance
     *            value to be assigned to property networkAppliance
     */
    public void setNetworkAppliance(boolean networkAppliance) {
        this.networkAppliance = networkAppliance;
    }

    /**
     * Getter method for property <tt>emcIsilon</tt>.
     * 
     * @return property value of emcIsilon
     */
    public boolean isEmcIsilon() {
        return emcIsilon;
    }

    /**
     * Setter method for property <tt>emcIsilon</tt>.
     * 
     * @param emcIsilon
     *            value to be assigned to property emcIsilon
     */
    public void setEmcIsilon(boolean emcIsilon) {
        this.emcIsilon = emcIsilon;
    }

    /**
     * Getter method for property <tt>emcVnx</tt>.
     * 
     * @return property value of emcVnx
     */
    public boolean isEmcVnx() {
        return emcVnx;
    }

    /**
     * Setter method for property <tt>emcVnx</tt>.
     * 
     * @param emcVnx
     *            value to be assigned to property emcVnx
     */
    public void setEmcVnx(boolean emcVnx) {
        this.emcVnx = emcVnx;
    }

    /**
     * Getter method for property <tt>ndmpNodesNum</tt>.
     * 
     * @return property value of ndmpNodesNum
     */
    public Integer getNdmpNodesNum() {
        return ndmpNodesNum;
    }

    /**
     * Setter method for property <tt>ndmpNodesNum</tt>.
     * 
     * @param ndmpNodesNum
     *            value to be assigned to property ndmpNodesNum
     */
    public void setNdmpNodesNum(Integer ndmpNodesNum) {
        this.ndmpNodesNum = ndmpNodesNum;
    }

    /**
     * Getter method for property <tt>includeMultistreamSupport</tt>.
     * 
     * @return property value of includeMultistreamSupport
     */
    public Boolean getIncludeMultistreamSupport() {
        return includeMultistreamSupport;
    }

    /**
     * Setter method for property <tt>includeMultistreamSupport</tt>.
     * 
     * @param includeMultistreamSupport
     *            value to be assigned to property includeMultistreamSupport
     */
    public void setIncludeMultistreamSupport(Boolean includeMultistreamSupport) {
        this.includeMultistreamSupport = includeMultistreamSupport;
    }

    /**
     * Getter method for property <tt>streamsPerNodeNum</tt>.
     * 
     * @return property value of streamsPerNodeNum
     */
    public Integer getStreamsPerNodeNum() {
        return streamsPerNodeNum;
    }

    /**
     * Setter method for property <tt>streamsPerNodeNum</tt>.
     * 
     * @param streamsPerNodeNum
     *            value to be assigned to property streamsPerNodeNum
     */
    public void setStreamsPerNodeNum(Integer streamsPerNodeNum) {
        this.streamsPerNodeNum = streamsPerNodeNum;
    }

    /**
     * Getter method for property <tt>celerraTargetsNum</tt>.
     * 
     * @return property value of celerraTargetsNum
     */
    public Integer getCelerraTargetsNum() {
        return celerraTargetsNum;
    }

    /**
     * Setter method for property <tt>celerraTargetsNum</tt>.
     * 
     * @param celerraTargetsNum
     *            value to be assigned to property celerraTargetsNum
     */
    public void setCelerraTargetsNum(Integer celerraTargetsNum) {
        this.celerraTargetsNum = celerraTargetsNum;
    }

    /**
     * Getter method for property <tt>netAppFilerTargetsNum</tt>.
     * 
     * @return property value of netAppFilerTargetsNum
     */
    public Integer getNetAppFilerTargetsNum() {
        return netAppFilerTargetsNum;
    }

    /**
     * Setter method for property <tt>netAppFilerTargetsNum</tt>.
     * 
     * @param netAppFilerTargetsNum
     *            value to be assigned to property netAppFilerTargetsNum
     */
    public void setNetAppFilerTargetsNum(Integer netAppFilerTargetsNum) {
        this.netAppFilerTargetsNum = netAppFilerTargetsNum;
    }

    /**
     * Getter method for property <tt>isilonTargetsNum</tt>.
     * 
     * @return property value of isilonTargetsNum
     */
    public Integer getIsilonTargetsNum() {
        return isilonTargetsNum;
    }

    /**
     * Setter method for property <tt>isilonTargetsNum</tt>.
     * 
     * @param isilonTargetsNum
     *            value to be assigned to property isilonTargetsNum
     */
    public void setIsilonTargetsNum(Integer isilonTargetsNum) {
        this.isilonTargetsNum = isilonTargetsNum;
    }

    /**
     * Getter method for property <tt>vnxTargetsNum</tt>.
     * 
     * @return property value of vnxTargetsNum
     */
    public Integer getVnxTargetsNum() {
        return vnxTargetsNum;
    }

    /**
     * Setter method for property <tt>vnxTargetsNum</tt>.
     * 
     * @param vnxTargetsNum
     *            value to be assigned to property vnxTargetsNum
     */
    public void setVnxTargetsNum(Integer vnxTargetsNum) {
        this.vnxTargetsNum = vnxTargetsNum;
    }

    /**
     * Getter method for property <tt>dataSetCreationHours</tt>.
     * 
     * @return property value of dataSetCreationHours
     */
    public BigDecimal getDataSetCreationHours() {
        return dataSetCreationHours;
    }

    /**
     * Setter method for property <tt>dataSetCreationHours</tt>.
     * 
     * @param dataSetCreationHours
     *            value to be assigned to property dataSetCreationHours
     */
    public void setDataSetCreationHours(BigDecimal dataSetCreationHours) {
        this.dataSetCreationHours = dataSetCreationHours;
    }

}

/*
 * This code is copyright (c) 2013 - 2014 EMC Corporation.
 */
package com.emc.gs.tools.srf.model;

import java.io.Serializable;
import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * <p>
 * This represents a list of attachments
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safety.
 * </p>
 *
 * <p>
 * <strong>Changes V1.1:</strong>
 * <strong>SRT Phase 4 - ET Assembly 3</strong>
 * <ul>
 * <li>Moved @XmlElement(name="Attachments") to the "list" field so that the deserialization works as well.</li>
 * <li>Changed the "list" field from protected to private.</li>
 * </ul>
 * </p>
 *
 * @author MonicaMuranyi, TCSASSEMBLER
 * @version 1.1
 */
@XmlRootElement(name="AttachmentList")
public class AttachmentList implements Serializable{
    /**
     * Generated Serial Version UID
     */
    private static final long serialVersionUID = 5197791049917921409L;
    
    /**
     * The list of attachments
     */
    @XmlElement(name="Attachments")
    private List<Attachment> list;

    /**
     * Creates instance of the class.
     */
    public AttachmentList(){
        // Empty
    }

    /**
     * Sets the list of attachments
     * @param list the list of attachments
     */
    public AttachmentList(List<Attachment> list){
        this.list = list;
    }

    /**
     * Retrieves the list of attachments
     * @return the list of attachments
     */
    public List<Attachment> getList(){
        return list;
    }
}
/*
 * This code is copyright (c) 2014 EMC Corporation
 */
package com.emc.gs.tools.srf.model.dpad;

import com.emc.gs.tools.srf.model.IdentifiableEntity;

/**
 * <p>
 * This is NetworkerFileSystemClientBackupsBase entity class.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safety.
 * </p>
 * 
 * @author TCSASSEMBLER
 * @version 1.0
 * @since SRT Phase 3-5 - BRS Tabs Part 3 Assembly
 */
public abstract class NetworkerFileSystemClientBackupsBase extends IdentifiableEntity {

    /**
     * # of Networker Clients (Windows / Unix / Linux).
     */
    private Integer clientsNum;

    /**
     * # of Networker Cluster Client Connections.
     */
    private Integer clusterClientConnectionsNum;

    /**
     * <p>
     * The default constructor.
     * </p>
     */
    protected NetworkerFileSystemClientBackupsBase() {
    }

    /**
     * Getter method for property <tt>clientsNum</tt>.
     * 
     * @return property value of clientsNum
     */
    public Integer getClientsNum() {
        return clientsNum;
    }

    /**
     * Setter method for property <tt>clientsNum</tt>.
     * 
     * @param clientsNum
     *            value to be assigned to property clientsNum
     */
    public void setClientsNum(Integer clientsNum) {
        this.clientsNum = clientsNum;
    }

    /**
     * Getter method for property <tt>clusterClientConnectionsNum</tt>.
     * 
     * @return property value of clusterClientConnectionsNum
     */
    public Integer getClusterClientConnectionsNum() {
        return clusterClientConnectionsNum;
    }

    /**
     * Setter method for property <tt>clusterClientConnectionsNum</tt>.
     * 
     * @param clusterClientConnectionsNum
     *            value to be assigned to property clusterClientConnectionsNum
     */
    public void setClusterClientConnectionsNum(Integer clusterClientConnectionsNum) {
        this.clusterClientConnectionsNum = clusterClientConnectionsNum;
    }

}

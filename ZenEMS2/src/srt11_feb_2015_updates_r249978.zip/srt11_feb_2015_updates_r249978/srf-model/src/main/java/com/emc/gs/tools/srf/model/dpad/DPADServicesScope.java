/*
 * This code is copyright (c) 2014 EMC Corporation
 */
package com.emc.gs.tools.srf.model.dpad;

import com.emc.gs.tools.srf.model.IdentifiableEntity;

/**
 * <p>
 * This is DPADServicesScope entity class.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safety.
 * </p>
 *
 * <p>
 * Version 1.1 (SRT Phase 3 Pilot - Mozy and Xtrem and Vipr Tabs Assembly) Change notes:
 *   <ol>
 *     <li>Added {@link #mozy} property.</li>
 *   </ol>
 * </p>
 *
 * <p>
 * Version 1.2 Change notes:
 *   <ol>
 *     <li>Removed <code>vplex</code> property.</li>
 *   </ol>
 * </p>
 * 
 * @author TCSASSEMBLER
 * @version 1.2
 * @since SRT Phase 3-5 - BRS Tabs Part 1 Assembly
 */
public class DPADServicesScope extends IdentifiableEntity {

    /**
     * Represents whether Avamar service is in scope.
     */
    private boolean avamar;

    /**
     * Represents whether Data Domain service is in scope.
     */
    private boolean dataDomain;

    /**
     * Represents whether Data Protection Advisor service is in scope.
     */
    private boolean dpa;

    /**
     * Represents whether EMC Disk Library service is in scope..
     */
    private boolean edl;

    /**
     * Represents whether Networker service is in scope..
     */
    private boolean networker;

    /**
     * Represents whether DLM service is in scope..
     */
    private boolean dlm;

    /**
     * Represents whether RecoverPoint service is in scope..
     */
    private boolean recoverPoint;

    /**
     * <p>A <code>boolean</code> providing the flag indicating if Mozy service is in scope.</p>
     * 
     * @since 1.1
     */
    private boolean mozy;

    /**
     * <p>
     * The default constructor.
     * </p>
     */
    public DPADServicesScope() {
    }

    /**
     * Getter method for property <tt>avamar</tt>.
     * 
     * @return property value of avamar
     */
    public boolean isAvamar() {
        return avamar;
    }

    /**
     * Setter method for property <tt>avamar</tt>.
     * 
     * @param avamar
     *            value to be assigned to property avamar
     */
    public void setAvamar(boolean avamar) {
        this.avamar = avamar;
    }

    /**
     * Getter method for property <tt>dataDomain</tt>.
     * 
     * @return property value of dataDomain
     */
    public boolean isDataDomain() {
        return dataDomain;
    }

    /**
     * Setter method for property <tt>dataDomain</tt>.
     * 
     * @param dataDomain
     *            value to be assigned to property dataDomain
     */
    public void setDataDomain(boolean dataDomain) {
        this.dataDomain = dataDomain;
    }

    /**
     * Getter method for property <tt>dpa</tt>.
     * 
     * @return property value of dpa
     */
    public boolean isDpa() {
        return dpa;
    }

    /**
     * Setter method for property <tt>dpa</tt>.
     * 
     * @param dpa
     *            value to be assigned to property dpa
     */
    public void setDpa(boolean dpa) {
        this.dpa = dpa;
    }

    /**
     * Getter method for property <tt>edl</tt>.
     * 
     * @return property value of edl
     */
    public boolean isEdl() {
        return edl;
    }

    /**
     * Setter method for property <tt>edl</tt>.
     * 
     * @param edl
     *            value to be assigned to property edl
     */
    public void setEdl(boolean edl) {
        this.edl = edl;
    }

    /**
     * Getter method for property <tt>networker</tt>.
     * 
     * @return property value of networker
     */
    public boolean isNetworker() {
        return networker;
    }

    /**
     * Setter method for property <tt>networker</tt>.
     * 
     * @param networker
     *            value to be assigned to property networker
     */
    public void setNetworker(boolean networker) {
        this.networker = networker;
    }

    /**
     * Getter method for property <tt>dlm</tt>.
     * 
     * @return property value of dlm
     */
    public boolean isDlm() {
        return dlm;
    }

    /**
     * Setter method for property <tt>dlm</tt>.
     * 
     * @param dlm
     *            value to be assigned to property dlm
     */
    public void setDlm(boolean dlm) {
        this.dlm = dlm;
    }

    /**
     * Getter method for property <tt>recoverPoint</tt>.
     * 
     * @return property value of recoverPoint
     */
    public boolean isRecoverPoint() {
        return recoverPoint;
    }

    /**
     * Setter method for property <tt>recoverPoint</tt>.
     * 
     * @param recoverPoint
     *            value to be assigned to property recoverPoint
     */
    public void setRecoverPoint(boolean recoverPoint) {
        this.recoverPoint = recoverPoint;
    }

    /**
     * <p>Gets the flag indicating if Mozy service is in scope.</p>
     *
     * @return a <code>boolean</code> providing the flag indicating if Mozy service is in scope.
     * @since 1.1
     */
    public boolean isMozy() {
        return this.mozy;
    }

    /**
     * <p>Sets the flag indicating if Mozy service is in scope.</p>
     *
     * @param mozy a <code>boolean</code> providing the flag indicating if Mozy service is in scope.
     * @since 1.1
     */
    public void setMozy(boolean mozy) {
        this.mozy = mozy;
    }

}

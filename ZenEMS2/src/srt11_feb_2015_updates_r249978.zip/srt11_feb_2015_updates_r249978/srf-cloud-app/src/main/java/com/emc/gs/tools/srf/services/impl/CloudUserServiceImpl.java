/*
 * This code is copyright (c) 2014 EMC Corporation.
 */
package com.emc.gs.tools.srf.services.impl;

import java.util.List;

import javax.persistence.PersistenceException;
import javax.persistence.TypedQuery;

import com.emc.gs.tools.srf.model.User;
import com.emc.gs.tools.srf.services.ServiceRequestToolException;
import com.emc.gs.tools.srf.services.UserService;

/**
 * <p>
 * This class is the cloud side implementation of the UserService.
 * </p>
 *
 * <p>
 * <strong>Thread safety</strong>: This class is effectively thread safe after configuration, the configuration is done
 * in a thread safe manner.
 * </p>
 *
 * <p>
 * <strong>Changes V1.1:</strong>
 * <strong>SRT Phase 4 - ET Assembly 2</strong>
 * <ul>
 * <li>Encapsulate the authentication logic in authenticate() method.</li>
 * </ul>
 * </p>
 * 
 * @author zsudraco, TCSASSEMBLER
 * @version 1.1
 */
public class CloudUserServiceImpl extends BaseUserService implements UserService {

    /**
     * Empty constructor.
     */
    public CloudUserServiceImpl() {
    }

    /**
     * Gets matched user.
     * 
     * @param user
     *            the user to be authenticated
     * @return the matched user
     * @throws ServiceRequestToolException
     *             if any error occurred during the operation
     */
    @Override
    protected User getMatchedUser(User user) throws ServiceRequestToolException {
        try {
            TypedQuery<User> query = getEntityManager()
                    .createQuery("from User where userIdentifier = :userIdentifier", User.class)
                    .setParameter("userIdentifier", user.getUserIdentifier()).setMaxResults(1);
            List<User> users = query.getResultList();
            return users != null && users.size() > 0 ? users.get(0) : null;
        } catch (IllegalStateException e) {
            throw new ServiceRequestToolException(
                    "The entity manager has been closed.", e);
        } catch (PersistenceException e) {
            throw new ServiceRequestToolException(
                    "An error has occurred while accessing the persistence.", e);
        }
    }
}

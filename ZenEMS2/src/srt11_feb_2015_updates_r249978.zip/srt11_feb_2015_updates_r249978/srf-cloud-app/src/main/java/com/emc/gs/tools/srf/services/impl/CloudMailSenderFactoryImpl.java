/*
 * This code is copyright (c) 2014 EMC Corporation.
 */
package com.emc.gs.tools.srf.services.impl;

import org.apache.log4j.Logger;
import org.springframework.mail.javamail.JavaMailSender;

import com.emc.gs.tools.srf.model.Profile;
import com.emc.gs.tools.srf.services.MailSenderFactory;

/**
 * <p>
 * This class is the cloud side implementation of the MailSenderFactory.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is effectively thread safe after configuration, the
 * configuration is done in a thread safe manner.
 * </p>
 * 
 * @author TCSASSEMBLER
 * @version 1.0
 * @since SRT Phase 4 - ET Assembly 2
 */
public class CloudMailSenderFactoryImpl extends BaseLoggerService implements MailSenderFactory {

    /**
     * <p>
     * Represents the class name.
     * </p>
     */
    private static final String CLASSNAME = CloudMailSenderFactoryImpl.class.getName();

    /**
     * Represents the mail sender. It is modified by setter. It is injected by Spring. It
     * can not be null after injected.
     */
    private JavaMailSender mailSender;

    /**
     * Empty constructor.
     */
    public CloudMailSenderFactoryImpl() {
    }

    /**
     * Creates a mail sender.
     * 
     * @param profile
     *            The user profile, not used
     * @return mail sender
     */
    public JavaMailSender createJavaMailSender(Profile profile) {
        final String signature = CLASSNAME + "#createJavaMailSender(Profile profile)";
        Logger logger = getLogger();

        // Log entry
        Helper.logEntrance(logger, signature, new String[] {"profile"}, new Object[] {profile});

        // Log exit
        Helper.logExit(logger, signature, new Object[]{mailSender});
        return mailSender;
    }

    /**
     * Setter method for property <tt>mailSender</tt>.
     * 
     * @param mailSender
     *            value to be assigned to property mailSender
     */
    public void setMailSender(JavaMailSender mailSender) {
        this.mailSender = mailSender;
    }
}

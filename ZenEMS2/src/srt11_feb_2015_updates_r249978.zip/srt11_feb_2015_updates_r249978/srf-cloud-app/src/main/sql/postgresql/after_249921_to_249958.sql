ALTER TABLE Avamar ADD COLUMN adme_service BOOLEAN;

CREATE SEQUENCE SAvamarADMEConfiguration INCREMENT BY 1 START WITH 1000;
CREATE TABLE AvamarADMEConfiguration (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SAvamarADMEConfiguration'),
    include_cloud_path_config BOOLEAN,
    replication_pairs_num INT,
    staging_servers_num INT,
    cloud_paths_num INT
);

ALTER TABLE Avamar ADD COLUMN adme_id BIGINT;
ALTER TABLE Avamar ADD FOREIGN KEY (adme_id) REFERENCES AvamarADMEConfiguration(id);

ALTER TABLE OtherRequestOptions ADD COLUMN assessment BOOLEAN;

CREATE SEQUENCE SNetworkServiceTemplateType INCREMENT BY 1 START WITH 1000;
CREATE TABLE NetworkServiceTemplateType (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SNetworkServiceTemplateType'),
    name VARCHAR(256) NOT NULL
);

CREATE SEQUENCE SLANInfraComplexityType INCREMENT BY 1 START WITH 1000;
CREATE TABLE LANInfraComplexityType (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SLANInfraComplexityType'),
    name VARCHAR(256) NOT NULL
);


CREATE SEQUENCE SDCLocationsAnalysisNumber INCREMENT BY 1 START WITH 1000;
CREATE TABLE DCLocationsAnalysisNumber (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SDCLocationsAnalysisNumber'),
    name VARCHAR(256) NOT NULL
);

INSERT INTO NetworkServiceTemplateType VALUES(1, 'EMC Assessment for IP Network Replication');
INSERT INTO NetworkServiceTemplateType VALUES(2, 'FCoE Infrastructure Assessment');

INSERT INTO LANInfraComplexityType VALUES(1, 'Low');
INSERT INTO LANInfraComplexityType VALUES(2, 'Medium');
INSERT INTO LANInfraComplexityType VALUES(3, 'High');

INSERT INTO DCLocationsAnalysisNumber VALUES(1, '1');
INSERT INTO DCLocationsAnalysisNumber VALUES(2, '2');
INSERT INTO DCLocationsAnalysisNumber VALUES(3, '3');
INSERT INTO DCLocationsAnalysisNumber VALUES(4, '4');
INSERT INTO DCLocationsAnalysisNumber VALUES(5, '5');

CREATE SEQUENCE SAssessmentData INCREMENT BY 1 START WITH 1000;
CREATE TABLE AssessmentData (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SAssessmentData'),
    service_template_type_id BIGINT,
    lan_complexity_type_id BIGINT,
    dc_locations_number_id BIGINT,
    results_viewable BOOLEAN,
    FOREIGN KEY (service_template_type_id) REFERENCES NetworkServiceTemplateType (id),
    FOREIGN KEY (lan_complexity_type_id) REFERENCES LANInfraComplexityType (id),
    FOREIGN KEY (dc_locations_number_id) REFERENCES DCLocationsAnalysisNumber (id)
);

ALTER TABLE Request ADD COLUMN assessment_id BIGINT;
ALTER TABLE Request ADD FOREIGN KEY (assessment_id) REFERENCES AssessmentData (id);

CREATE SEQUENCE SRecoveryLevelType INCREMENT BY 1 START WITH 1000;
CREATE TABLE RecoveryLevelType (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SRecoveryLevelType'),
    name VARCHAR(256) NOT NULL
);

CREATE SEQUENCE SProtectPointData INCREMENT BY 1 START WITH 1000;
CREATE TABLE ProtectPointData (
    id BIGINT NOT NULL PRIMARY KEY DEFAULT nextval('SProtectPointData'),
    data_domain_appls_backup_num INT,
    storage_arrays_backup_num INT,
    application_hosts_num INT,
    backup_config_files_num INT,
    db_instances_backup_num INT,
    recovery_level_type_id BIGINT,
    obj_level_recovery_num INT,
    full_lun_recovery_num INT,
    FOREIGN KEY (recovery_level_type_id) REFERENCES RecoveryLevelType (id)
);

ALTER TABLE Request ADD COLUMN protectpoint_id BIGINT;
ALTER TABLE Request ADD FOREIGN KEY (protectpoint_id) REFERENCES ProtectPointData (id);

INSERT INTO RecoveryLevelType VALUES(1, 'Object Level Recovery');
INSERT INTO RecoveryLevelType VALUES(2, 'Full LUN Recovery');

ALTER TABLE OtherRequestOptions ADD COLUMN protect_point BOOLEAN;

ALTER TABLE DataDomainBoostBackupServer ADD COLUMN ddbda BOOLEAN;
ALTER TABLE DataDomainBoostBackupServer ADD COLUMN ddbma BOOLEAN;

ALTER TABLE DataDomainDesignImplContent ADD db2_servers_num INT;
ALTER TABLE DataDomainDesignImplContent ADD sap_hana_db_servers_num INT;
ALTER TABLE DataDomainDesignImplContent ADD sap_hana_oracle_servers_num INT;
ALTER TABLE DataDomainDesignImplContent ADD ms_sql_servers_num INT;

ALTER TABLE DataDomainDesign ADD db2_servers_num INT;
ALTER TABLE DataDomainDesign ADD sap_hana_db_servers_num INT;
ALTER TABLE DataDomainDesign ADD sap_hana_oracle_servers_num INT;
ALTER TABLE DataDomainDesign ADD ms_sql_servers_num INT;

ALTER TABLE DataDomainImplementation ADD db2_servers_num INT;
ALTER TABLE DataDomainImplementation ADD sap_hana_db_servers_num INT;
ALTER TABLE DataDomainImplementation ADD sap_hana_oracle_servers_num INT;
ALTER TABLE DataDomainImplementation ADD ms_sql_servers_num INT;

ALTER TABLE DataDomainPreRack ADD db2_servers_num INT;
ALTER TABLE DataDomainPreRack ADD sap_hana_db_servers_num INT;
ALTER TABLE DataDomainPreRack ADD sap_hana_oracle_servers_num INT;
ALTER TABLE DataDomainPreRack ADD ms_sql_servers_num INT;

ALTER TABLE DataDomainImplApplianceModel DROP COLUMN virtual_tape_library_app;

ALTER TABLE SourceOneRequestData ADD COLUMN brs_sme_comment VARCHAR(250);

ALTER TABLE SanTanInformation ADD COLUMN virtual_sans_num INT;
ALTER TABLE SanTanInformation ADD COLUMN fcoe_uplinks_num INT;

ALTER TABLE Profile ADD COLUMN se_csd_name VARCHAR(256);
ALTER TABLE Profile ADD COLUMN se_csd_phone_country_code VARCHAR(256);
ALTER TABLE Profile ADD COLUMN se_csd_phone_number VARCHAR(256);
ALTER TABLE Profile ADD COLUMN se_manager_name VARCHAR(256);

INSERT INTO Region VALUES(1849, '0', 'Capital Federal', 56)/
INSERT INTO Region VALUES(1850, '1', 'Buenos Aires', 56)/
INSERT INTO Region VALUES(1851, '10', 'San Juan', 56)/
INSERT INTO Region VALUES(1852, '11', 'San Luis', 56)/
INSERT INTO Region VALUES(1853, '12', 'Santa Fé', 56)/
INSERT INTO Region VALUES(1854, '13', 'Santiago del Estero', 56)/
INSERT INTO Region VALUES(1855, '14', 'Tucumán', 56)/
INSERT INTO Region VALUES(1856, '16', 'Chaco', 56)/
INSERT INTO Region VALUES(1857, '17', 'Chubut', 56)/
INSERT INTO Region VALUES(1858, '18', 'Formosa', 56)/
INSERT INTO Region VALUES(1859, '19', 'Misiones', 56)/
INSERT INTO Region VALUES(1860, '2', 'Catamarca', 56)/
INSERT INTO Region VALUES(1861, '20', 'Neuquen', 56)/
INSERT INTO Region VALUES(1862, '21', 'La Pampa', 56)/
INSERT INTO Region VALUES(1863, '22', 'Rio Negro', 56)/
INSERT INTO Region VALUES(1864, '23', 'Santa Cruz', 56)/
INSERT INTO Region VALUES(1865, '24', 'Tierra de Fuego', 56)/
INSERT INTO Region VALUES(1866, '3', 'Córdoba', 56)/
INSERT INTO Region VALUES(1867, '4', 'Corrientes', 56)/
INSERT INTO Region VALUES(1868, '5', 'Entre Rios', 56)/
INSERT INTO Region VALUES(1869, '6', 'Jujuy', 56)/
INSERT INTO Region VALUES(1870, '7', 'Mendoza', 56)/
INSERT INTO Region VALUES(1871, '8', 'La Rioja', 56)/
INSERT INTO Region VALUES(1872, '9', 'Salta', 56)/

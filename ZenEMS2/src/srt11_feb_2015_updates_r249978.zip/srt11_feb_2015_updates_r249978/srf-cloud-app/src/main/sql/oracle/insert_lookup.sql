insert into DataDomainDeviceType values(1, 'CIFS')/
insert into DataDomainDeviceType values(2, 'NFS')/
insert into DataDomainDeviceType values(3, 'Virtual Tape Library')/
insert into DataDomainDeviceType values(4, 'DB Boost')/

insert into DataDomainUpgradeType values(1, 'Code Upgrade for DD')/
insert into DataDomainUpgradeType values(2, 'System Controller Upgrade for DD')/

insert into DataDomainDataStagingType values(1, 'None')/
insert into DataDomainDataStagingType values(2, 'New-New')/
insert into DataDomainDataStagingType values(3, 'Existing-New')/
insert into DataDomainDataStagingType values(4, 'Existing-Existing(re-purposed)')/

insert into DataDomainIntegrationType values(1, 'DD Integration Workshop')/
insert into DataDomainIntegrationType values(2, 'DD Integration with RMAN Scripting')/
insert into DataDomainIntegrationType values(3, 'DD Integration with SAP Hana Studio')/

insert into DataDomainMigrationType values(1, 'Data Domain to Data Domain')/
insert into DataDomainMigrationType values(2, 'Centera to Data Domain using DixkXtender')/

insert into DataDomainPreRackType values(1, 'Installation for Pre-Racked Shelf Expansion')/
insert into DataDomainPreRackType values(2, 'Implementation for a Data Domain Pre-Racked System')/

insert into DataDomainBoostType values(1, 'DD Boost with NBU')/
insert into DataDomainBoostType values(2, 'DD Boost with RMAN')/

insert into DataDomainMaxBackupWindowTime values(1, '2 Hrs')/
insert into DataDomainMaxBackupWindowTime values(2, '4 Hrs')/
insert into DataDomainMaxBackupWindowTime values(3, '8 Hrs')/

insert into AvamarServerType values(1, 'Avamar Single Node')/
insert into AvamarServerType values(2, 'Avamar Multi-Node')/
insert into AvamarServerType values(3, 'Avamar Capacity Expansion')/
insert into AvamarServerType values(4, 'Avamar Virtual Edition')/

insert into VplexDataMobilityType values(1, 'None')/
insert into VplexDataMobilityType values(2, 'Extent')/
insert into VplexDataMobilityType values(3, 'Device')/
insert into VplexDataMobilityType values(4, 'Both')/

insert into XtremeDataMobilityType values(1, 'Device Migration')/
insert into XtremeDataMobilityType values(2, 'Extent Migration')/
insert into XtremeDataMobilityType values(3, 'Both')/

insert into CenteraArrayActionType values(1, 'Do Not Move')/
insert into CenteraArrayActionType values(2, 'Hardware Repurpose')/
insert into CenteraArrayActionType values(3, 'Relocate')/
insert into CenteraArrayActionType values(4, 'Return to EMC')/

insert into CenteraEditionType values(1, 'Basic')/
insert into CenteraEditionType values(2, 'Compliance Edition')/
insert into CenteraEditionType values(3, 'Compliance Edition Plus')/

insert into CenteraGenerationType values(1, 'Gen4LP (2TB)')/
insert into CenteraGenerationType values(2, 'Gen4LP (1TB)')/
insert into CenteraGenerationType values(3, 'Gen4 (750GB)')/
insert into CenteraGenerationType values(4, 'Gen4 (500GB)')/
insert into CenteraGenerationType values(5, 'Gen4 (320GB)')/
insert into CenteraGenerationType values(6, 'Gen3')/
insert into CenteraGenerationType values(7, 'Gen2')/
insert into CenteraGenerationType values(8, 'Gen1')/
insert into CenteraGenerationType values(9, 'Other')/

insert into CenteraHealthCheckType values(1, 'No')/
insert into CenteraHealthCheckType values(2, 'Basic')/
insert into CenteraHealthCheckType values(3, 'Deep Dive')/
insert into CenteraHealthCheckType values(4, 'Custom')/

insert into CenteraReplicationType values(1, 'No')/
insert into CenteraReplicationType values(2, 'Existing')/
insert into CenteraReplicationType values(3, 'Adding')/
insert into CenteraReplicationType values(4, 'Both')/

insert into CenteraProtectionSchemeType values(1, 'Mirrored')/
insert into CenteraProtectionSchemeType values(2, 'Parity')/

insert into CenteraShippingArranger values(1, 'Customer')/
insert into CenteraShippingArranger values(2, 'EMC')/

insert into CUAHardwareType values(1, 'Dell server')/
insert into CUAHardwareType values(2, 'Gen3 node')/
insert into CUAHardwareType values(3, 'Gen4 node')/

insert into UIMType values(1, 'UIM/P')/
insert into UIMType values(2, 'UIM/O')/
insert into UIMType values(3, 'Both')/

insert into UnifiedHealthCheckType values(1, 'File')/
insert into UnifiedHealthCheckType values(2, 'Block')/

insert into WeekDay values(1, 'Sunday')/
insert into WeekDay values(2, 'Monday')/
insert into WeekDay values(3, 'Tuesday')/
insert into WeekDay values(4, 'Wednesday')/
insert into WeekDay values(5, 'Thursday')/
insert into WeekDay values(6, 'Friday')/
insert into WeekDay values(7, 'Saturday')/

insert into ResidencyPaymentType values(1, 'Fixed')/
insert into ResidencyPaymentType values(2, 'T&M')/
insert into ResidencyPaymentType values(3, 'Event Based')/

insert into CTAApplianceType values(1, 'FMA')/
insert into CTAApplianceType values(2, 'FMA/VE')/
insert into CTAApplianceType values(3, 'FVA')/

insert into CTASourceFileServerType values(1, 'Celerra')/
insert into CTASourceFileServerType values(2, 'VNX')/
insert into CTASourceFileServerType values(3, 'Network Appliance')/

insert into DurationMonths values(1, '12')/
insert into DurationMonths values(2, '24')/
insert into DurationMonths values(3, '36')/
insert into DurationMonths values(4, '48')/
insert into DurationMonths values(5, '60')/

insert into MSSService values(1, 'Erasure - InFrame')/
insert into MSSService values(2, 'Erasure - Appliance')/
insert into MSSService values(3, 'Retention')/

insert into MSSPlatform values(1, 'Symmetrix')/
insert into MSSPlatform values(2, 'VNX')/
insert into MSSPlatform values(3, 'CLARiiON')/
insert into MSSPlatform values(4, 'Celerra')/
insert into MSSPlatform values(5, 'CLARiiON AX')/
insert into MSSPlatform values(6, 'Centera')/
insert into MSSPlatform values(7, 'DataDomain')/
insert into MSSPlatform values(8, 'Avamar')/
insert into MSSPlatform values(9, 'ATMOS')/
insert into MSSPlatform values(10, 'GREENPLUM')/

insert into SitesInvolved values(1, '1')/
insert into SitesInvolved values(2, '2')/
insert into SitesInvolved values(3, '3')/
insert into SitesInvolved values(4, '4')/
insert into SitesInvolved values(5, 'More Than 4')/

insert into FlashStorageLayoutServices values(1, 'None')/
insert into FlashStorageLayoutServices values(2, 'Basic')/
insert into FlashStorageLayoutServices values(3, 'Advanced')/

insert into Geography values(1, 'North America')/
insert into Geography values(2, 'Latin America')/
insert into Geography values(3, 'EMEA')/
insert into Geography values(4, 'APJ')/
insert into Geography values(5, 'RSA')/
insert into Geography values(6, 'ECD')/

insert into ScriptingLevelOption values(1, 'Robust')/
insert into ScriptingLevelOption values(2, 'Base')/
insert into ScriptingLevelOption values(3, 'None')/

INSERT INTO ServicesAgreementType VALUES(2, 'Consulting and Training Services Agreement (CTSA)')/
INSERT INTO ServicesAgreementType VALUES(3, 'Consulting Services Agreement (CSA)')/
INSERT INTO ServicesAgreementType VALUES(4, 'Professional Services Agreement (PSA)')/
INSERT INTO ServicesAgreementType VALUES(5, 'Master Services Agreement (MSA)')/
INSERT INTO ServicesAgreementType VALUES(6, 'Master Software License (MSL)')/
INSERT INTO ServicesAgreementType VALUES(7, 'Equipment & Services Agreement (ESA)')/
INSERT INTO ServicesAgreementType VALUES(8, 'Value Added Reseller Agreement (VARA)')/
INSERT INTO ServicesAgreementType VALUES(9, 'Unknown / Unsure')/

INSERT INTO SowType VALUES(1, 'EMC to Customer')/
INSERT INTO SowType VALUES(2, 'EMC to Reseller')/
INSERT INTO SowType VALUES(3, 'SOW to Distributor')/

INSERT INTO ProjectType VALUES(1, 'Standard Delivery', 'Z4')/
INSERT INTO ProjectType VALUES(2, 'Concession Delivery', 'Z6')/
INSERT INTO ProjectType VALUES(3, 'Proof of Concept', 'Z7')/
INSERT INTO ProjectType VALUES(4, 'Start At Risk', 'Z5')/

INSERT INTO environmentdevicetype VALUES(1, 'Switches')/
INSERT INTO environmentdevicetype VALUES(2, 'Directors')/

INSERT INTO VnxClariionInstallType VALUES(1, 'Basic')/
INSERT INTO VnxClariionInstallType VALUES(2, 'Standard')/
INSERT INTO VnxClariionInstallType VALUES(3, 'Complex')/

INSERT INTO SrdfConnectionType VALUES(1, 'FC')/
INSERT INTO SrdfConnectionType VALUES(2, 'FC to FCIP')/
INSERT INTO SrdfConnectionType VALUES(3, 'GigE')/
INSERT INTO SrdfConnectionType VALUES(4, 'FICON')/
INSERT INTO SrdfConnectionType VALUES(5, 'ESCON')/

INSERT INTO psaagreementtype VALUES(1, 'psaagreementtype1')/
INSERT INTO psaagreementtype VALUES(2, 'psaagreementtype2')/
INSERT INTO psaagreementtype VALUES(3, 'psaagreementtype3')/

INSERT INTO environmentarraytype VALUES(1, 'CX')/
INSERT INTO environmentarraytype VALUES(2, 'CX3')/
INSERT INTO environmentarraytype VALUES(3, 'CX4')/
INSERT INTO environmentarraytype VALUES(4, 'NS / NSX')/
INSERT INTO environmentarraytype VALUES(5, 'VNX')/
INSERT INTO environmentarraytype VALUES(6, 'DMX')/
INSERT INTO environmentarraytype VALUES(7, 'DMX3')/
INSERT INTO environmentarraytype VALUES(8, 'DMX4')/
INSERT INTO environmentarraytype VALUES(9, 'VMAX')/
INSERT INTO environmentarraytype VALUES(10, 'Symm 3/4/5')/
INSERT INTO environmentarraytype VALUES(11, 'Hitachi')/
INSERT INTO environmentarraytype VALUES(12, 'HP')/
INSERT INTO environmentarraytype VALUES(13, 'IBM')/
INSERT INTO environmentarraytype VALUES(14, 'STK')/
INSERT INTO environmentarraytype VALUES(15, 'VPLEX')/
INSERT INTO environmentarraytype VALUES(16, 'Other')/
INSERT INTO environmentarraytype VALUES(17, 'XtremIO')/

INSERT INTO SrdfStaticDynamicType VALUES(1, 'Static')/
INSERT INTO SrdfStaticDynamicType VALUES(2, 'Dynamic')/

INSERT INTO VnxInstallProtocolSubType VALUES(1, 'CIFS')/
INSERT INTO VnxInstallProtocolSubType VALUES(2, 'NFS')/
INSERT INTO VnxInstallProtocolSubType VALUES(3, 'BOTH')/

INSERT INTO RequestType VALUES(1, 'BOE only')/
INSERT INTO RequestType VALUES(2, 'BOE and SOW/TPD')/
INSERT INTO RequestType VALUES(3, 'SOW/TPD Only')/

INSERT INTO sourcevnxtype VALUES(1, 'VNX')/
INSERT INTO sourcevnxtype VALUES(2, 'Symmetrix')/
INSERT INTO sourcevnxtype VALUES(3, 'Gateway')/

INSERT INTO CelerraSetupType VALUES(1, 'New')/
INSERT INTO CelerraSetupType VALUES(2, 'Upgrade')/
INSERT INTO CelerraSetupType VALUES(3, 'Both')/

INSERT INTO CelerraArrayType VALUES(1, 'VNX')/
INSERT INTO CelerraArrayType VALUES(2, 'Symmetrix')/
INSERT INTO CelerraArrayType VALUES(3, 'Both')/

INSERT INTO AreaSizingType VALUES(1, 'Standard')/
INSERT INTO AreaSizingType VALUES(2, 'Custom')/

INSERT INTO TargetCelerraType VALUES(1, '2 Targets')/
INSERT INTO TargetCelerraType VALUES(2, '3 Targets')/
INSERT INTO TargetCelerraType VALUES(3, 'Celerra 1')/
INSERT INTO TargetCelerraType VALUES(4, 'Celerra 2')/
INSERT INTO TargetCelerraType VALUES(5, 'Celerra 3')/
INSERT INTO TargetCelerraType VALUES(6, 'Celerra 4')/
INSERT INTO TargetCelerraType VALUES(7, 'Celerra 5')/
INSERT INTO TargetCelerraType VALUES(8, 'Celerra 6')/
INSERT INTO TargetCelerraType VALUES(9, 'Celerra 7')/
INSERT INTO TargetCelerraType VALUES(10, 'Celerra 8')/
INSERT INTO TargetCelerraType VALUES(11, 'Celerra 9')/
INSERT INTO TargetCelerraType VALUES(12, 'Celerra 10')/

INSERT INTO ConfigChangeType VALUES(1, 'No change')/
INSERT INTO ConfigChangeType VALUES(2, 'BIN change')/
INSERT INTO ConfigChangeType VALUES(3, 'CLI change')/

INSERT INTO UnifiedConversionType VALUES(1, 'File to Unified')/
INSERT INTO UnifiedConversionType VALUES(2, 'Block to Unified')/
INSERT INTO UnifiedConversionType VALUES(3, 'DIP SP')/
INSERT INTO UnifiedConversionType VALUES(4, 'DIP DPE to SPE')/

INSERT INTO VnxInstallProtocolType VALUES(1, 'File Only (CIFS/NFS)')/
INSERT INTO VnxInstallProtocolType VALUES(2, 'Block Only (FC/ISCSI)')/
INSERT INTO VnxInstallProtocolType VALUES(3, 'BOTH')/

INSERT INTO TestAcceptancePlanType VALUES(1, 'Standard')/
INSERT INTO TestAcceptancePlanType VALUES(2, 'Custom')/
INSERT INTO TestAcceptancePlanType VALUES(3, 'None')/

INSERT INTO MvConnectionType VALUES(1, 'FC')/
INSERT INTO MvConnectionType VALUES(2, 'FC to FCIP')/
INSERT INTO MvConnectionType VALUES(3, 'iSCSI')/

INSERT INTO GatewayStorageType VALUES(1, 'VNX')/
INSERT INTO GatewayStorageType VALUES(2, 'Symmetrix')/
INSERT INTO GatewayStorageType VALUES(3, 'Both')/

INSERT INTO KnowledgeTransferLevel VALUES(1, 'Standard')/
INSERT INTO KnowledgeTransferLevel VALUES(2, 'Custom')/
INSERT INTO KnowledgeTransferLevel VALUES(3, 'None')/

INSERT INTO DocumentationLevel VALUES(1, 'Project Summary')/
INSERT INTO DocumentationLevel VALUES(2, 'Configuration Guide')/
INSERT INTO DocumentationLevel VALUES(3, 'Operation Guide')/

INSERT INTO scriptinglevel VALUES(1, 'No Scripting by EMC')/
INSERT INTO scriptinglevel VALUES(2, 'Modify existing scripts')/
INSERT INTO scriptinglevel VALUES(3, 'Custom scripts')/

INSERT INTO ClearanceLevel VALUES(1, 'None')/
INSERT INTO ClearanceLevel VALUES(2, 'US Citizen')/
INSERT INTO ClearanceLevel VALUES(3, 'Secret')/
INSERT INTO ClearanceLevel VALUES(4, 'TS or equivalent')/

INSERT INTO RiskLevel VALUES(1, 'Low', 'Z001')/
INSERT INTO RiskLevel VALUES(2, 'Medium', 'Z002')/
INSERT INTO RiskLevel VALUES(3, 'High', 'Z003')/
INSERT INTO RiskLevel VALUES(4, 'Very High', 'Z004')/

INSERT INTO NetworkLinkStatus VALUES(1, 'New')/
INSERT INTO NetworkLinkStatus VALUES(2, 'Existing')/

INSERT INTO meetingstatus VALUES(1, '1x per week - 1 hour each')/
INSERT INTO meetingstatus VALUES(2, '1x per week - 2 hours each')/
INSERT INTO meetingstatus VALUES(3, '2x per week')/
INSERT INTO meetingstatus VALUES(4, '3x per week')/
INSERT INTO meetingstatus VALUES(5, 'Daily')/
INSERT INTO meetingstatus VALUES(6, 'None Required')/

INSERT INTO PushPullOption VALUES(1, 'Push')/
INSERT INTO PushPullOption VALUES(2, 'Pull')/
INSERT INTO PushPullOption VALUES(3, 'Both')/

INSERT INTO RackAndStackOption VALUES(1, 'No')/
INSERT INTO RackAndStackOption VALUES(2, 'Customer Rack')/
INSERT INTO RackAndStackOption VALUES(3, 'EMC Rack')/

INSERT INTO BcvCloneOption VALUES(1, 'Standard')/
INSERT INTO BcvCloneOption VALUES(2, 'Custom')/

INSERT INTO PostSalesCompletionQualifier VALUES(1, 'TC Submits')/
INSERT INTO PostSalesCompletionQualifier VALUES(2, 'BC Submits')/

INSERT INTO MvMode VALUES(1, 'MV /Sync')/
INSERT INTO MvMode VALUES(2, 'MV /Async')/

INSERT INTO ArrayModel VALUES(1, 'CX')/
INSERT INTO ArrayModel VALUES(2, 'VNX')/

INSERT INTO IOInterfaceModule VALUES(1, 'FC')/
INSERT INTO IOInterfaceModule VALUES(2, 'Gbe')/
INSERT INTO IOInterfaceModule VALUES(3, 'iSCSI')/
INSERT INTO IOInterfaceModule VALUES(4, 'Fcoe')/

INSERT INTO emcmigrationinvolvement VALUES(1, 'No Involvement')/
INSERT INTO emcmigrationinvolvement VALUES(2, 'Onsite Support')/
INSERT INTO emcmigrationinvolvement VALUES(3, 'All Migration Tasks')/

INSERT INTO SymmetrixModel VALUES(1, 'DMX')/
INSERT INTO SymmetrixModel VALUES(2, 'VMAX')/

INSERT INTO MigrationTestNumber VALUES(1, '0')/
INSERT INTO MigrationTestNumber VALUES(2, '1')/
INSERT INTO MigrationTestNumber VALUES(3, '2')/
INSERT INTO MigrationTestNumber VALUES(4, '3')/
INSERT INTO MigrationTestNumber VALUES(5, '4')/
INSERT INTO MigrationTestNumber VALUES(6, '5')/
INSERT INTO MigrationTestNumber VALUES(7, '6')/
INSERT INTO MigrationTestNumber VALUES(8, '7')/


INSERT INTO HostSoftwareInstaller VALUES(1, 'Customer')/
INSERT INTO HostSoftwareInstaller VALUES(2, 'EMC')/

INSERT INTO CelerraVnxModel VALUES(1, 'N/A')/
INSERT INTO CelerraVnxModel VALUES(2, 'Src VNX')/
INSERT INTO CelerraVnxModel VALUES(3, 'Tgt VNX')/
INSERT INTO CelerraVnxModel VALUES(4, 'Src Isilon')/
INSERT INTO CelerraVnxModel VALUES(5, 'Tgt Isilon')/
INSERT INTO CelerraVnxModel VALUES(6, 'Src NetApp')/
INSERT INTO CelerraVnxModel VALUES(7, 'Tgt NetApp')/
INSERT INTO CelerraVnxModel VALUES(8, 'Src Windows')/
INSERT INTO CelerraVnxModel VALUES(9, 'Tgt Windows')/
INSERT INTO CelerraVnxModel VALUES(10, 'Src Unix')/
INSERT INTO CelerraVnxModel VALUES(11, 'Tgt Unix')/

INSERT INTO MigrationMethod VALUES(1, 'Replicator')/
INSERT INTO MigrationMethod VALUES(2, 'Host Based')/
INSERT INTO MigrationMethod VALUES(3, 'VDM')/
INSERT INTO MigrationMethod VALUES(4, 'SmartPool')/
INSERT INTO MigrationMethod VALUES(5, 'SyncIQ')/

INSERT INTO CelerraModel VALUES(1, 'VNX 5200')/
INSERT INTO CelerraModel VALUES(2, 'VNX 5400')/
INSERT INTO CelerraModel VALUES(3, 'VNX 5600')/
INSERT INTO CelerraModel VALUES(4, 'VNX 5800')/
INSERT INTO CelerraModel VALUES(5, 'VNX 7600')/
INSERT INTO CelerraModel VALUES(6, 'VNX 8000')/
INSERT INTO CelerraModel VALUES(7, 'VNX-CA')/
INSERT INTO CelerraModel VALUES(8, 'VNXe 3150')/
INSERT INTO CelerraModel VALUES(9, 'VNXe 3300')/
INSERT INTO CelerraModel VALUES(10, 'VNX VG2')/
INSERT INTO CelerraModel VALUES(11, 'VNX VG8')/

INSERT INTO VNXProtocol VALUES(1, 'CIFS')/
INSERT INTO VNXProtocol VALUES(2, 'NFS')/
INSERT INTO VNXProtocol VALUES(3, 'BOTH')/

INSERT INTO environmentgatherer VALUES(1, 'Customer')/
INSERT INTO environmentgatherer VALUES(2, 'EMC')/
INSERT INTO environmentgatherer VALUES(3, 'ECA')/

INSERT INTO SrdfMode VALUES(1, 'SRDF/S')/
INSERT INTO SrdfMode VALUES(2, 'SRDF/AR')/
INSERT INTO SrdfMode VALUES(3, 'SRDF/A')/
INSERT INTO SrdfMode VALUES(4, 'SRDF/EDP')/
INSERT INTO SrdfMode VALUES(5, 'SRDF/S')/

INSERT INTO migrationworker VALUES(1, 'Customer')/
INSERT INTO migrationworker VALUES(2, 'EMC')/

INSERT INTO sanimplementator VALUES(1, 'Customer')/
INSERT INTO sanimplementator VALUES(2, 'EMC')/

INSERT INTO volumesizechange VALUES(1, 'Larger')/
INSERT INTO volumesizechange VALUES(2, 'No')/

INSERT INTO RepManagerImplementation VALUES(1, 'Addition')/
INSERT INTO RepManagerImplementation VALUES(2, 'New')/
INSERT INTO RepManagerImplementation VALUES(3, 'Upgrade')/

INSERT INTO RepManagerProductSpecificPrep VALUES(1, 'VMWare')/
INSERT INTO RepManagerProductSpecificPrep VALUES(2, 'Hyper-V')/
INSERT INTO RepManagerProductSpecificPrep VALUES(3, 'IBM VIO')/

INSERT INTO SowLanguage VALUES(1, 'US English')/
INSERT INTO SowLanguage VALUES(2, 'CA French')/
INSERT INTO SowLanguage VALUES(3, 'BR Portuguese')/
INSERT INTO SowLanguage VALUES(4, 'Spanish')/
INSERT INTO SowLanguage VALUES(5, 'Chinese (Simplified)')/
INSERT INTO SowLanguage VALUES(6, 'French')/
INSERT INTO SowLanguage VALUES(7, 'German')/
INSERT INTO SowLanguage VALUES(8, 'Italian')/
INSERT INTO SowLanguage VALUES(9, 'Japanese')/
INSERT INTO SowLanguage VALUES(10, 'Korean')/
INSERT INTO SowLanguage VALUES(11, 'UK English')/

INSERT INTO TargetCelerra VALUES(1, 'File 1')/
INSERT INTO TargetCelerra VALUES(2, 'File 2')/
INSERT INTO TargetCelerra VALUES(3, 'File 3')/
INSERT INTO TargetCelerra VALUES(4, 'File 4')/
INSERT INTO TargetCelerra VALUES(5, 'File 5')/
INSERT INTO TargetCelerra VALUES(6, 'File 6')/
INSERT INTO TargetCelerra VALUES(7, 'File 7')/
INSERT INTO TargetCelerra VALUES(8, 'File 8')/
INSERT INTO TargetCelerra VALUES(9, 'File 9')/
INSERT INTO TargetCelerra VALUES(10, 'File 10')/

INSERT INTO SynchronousMode VALUES(1, 'Synch')/
INSERT INTO SynchronousMode VALUES(2, 'Asynch')/

INSERT INTO ReplicationFailoverLevel VALUES(1, 'None')/
INSERT INTO ReplicationFailoverLevel VALUES(2, 'Full DR')/
INSERT INTO ReplicationFailoverLevel VALUES(3, 'Functional')/

INSERT INTO Division values(1, 'LATAM - Brazil', 'ASQCBrazilRequests@emc.com', 'Brazil', 0, 2)/
INSERT INTO Division values(2, 'NA - Central', 'ASQCCentralRequests@emc.com', 'Central', 0, 1)/
INSERT INTO Division values(3, 'NA - Mid-Market', 'ASQC.SoCO.Requests@emc.com', '', 0, 1)/
INSERT INTO Division values(4, 'NA - Federal', 'ASQCFederalRequests@emc.com', 'Federal', 0, 1)/
INSERT INTO Division values(5, 'LATAM - Mexico', 'ASQCMexicoRequests@emc.com', 'Mexico', 0, 2)/
INSERT INTO Division values(6, 'NA - MASE', 'ASQCMASERequests@emc.com', 'MASE', 0, 1)/
INSERT INTO Division values(7, 'NA - NE/Canada', 'ASQCNECanadaRequests@emc.com', 'NECan', 0, 1)/
INSERT INTO Division values(8, 'NA - NY NJ', 'ASQCNYNJRequests@emc.com', 'NYNJ', 0, 1)/
INSERT INTO Division values(9, 'NA - West', 'ASQCWestRequests@emc.com', 'West', 0, 1)/
INSERT INTO Division values(10, 'LATAM - Soco', 'ASQC.SoCO.Requests@emc.com', 'SoCo', 0, 2)/
INSERT INTO Division values(11, 'LATAM - NoLa', 'ASQC.NoLa.Requests@emc.com', 'NoLa', 0, 2)/
INSERT INTO Division values(12, 'EMEA - TEAM', 'SQCTEAM@emc.com', 'TEAM', 0, 3)/
INSERT INTO Division values(13, 'EMEA - UKI', 'SQCUK@emc.com', 'UKI', 0, 3)/
INSERT INTO Division values(14, 'EMEA - France', 'SQCFrance@emc.com', 'France', 0, 3)/
INSERT INTO Division values(15, 'EMEA - Germany', 'SQCGermany@emc.com', 'Germany', 0, 3)/
INSERT INTO Division values(16, 'EMEA - East', 'SQCEAST@emc.com', 'East', 0, 3)/
INSERT INTO Division values(17, 'EMEA - West', '', 'West-EMEA', 0, 3)/
INSERT INTO Division values(18, 'EMEA - ANZ', '', 'ANZ', 0, 3)/
INSERT INTO Division values(19, 'APJ - China', '', 'China', 0, 4)/
INSERT INTO Division values(20, 'APJ - India', '', 'India', 0, 4)/
INSERT INTO Division values(21, 'APJ - Japan', '', 'Japan', 0, 4)/
INSERT INTO Division values(22, 'APJ - Korea', '', 'Korea', 0, 4)/
INSERT INTO Division values(23, 'APJ - SE Asia', '', 'South East Asia', 0, 4)/
INSERT INTO Division values(24, 'RSA', '', 'RSA', 1, 5)/
INSERT INTO Division values(25, 'ECD', '', 'ECD', 1, 6)/
INSERT INTO Division values(26, 'MS', '', 'MS', 1, 5)/

INSERT INTO pdmname VALUES(1, 'Eduardo Morales', 'Program Delivery Manager', 'Av Rio Negro, 161', '8 Andar', 'Barueri', 'Sao Paulo', '06455-020', '55-11-2078-1522', '55-11-2078-1699', '55-11-99901-4398', 'eduardo.morales@emc.com', 1)/
INSERT INTO pdmname VALUES(2, 'Geographic PDM', '', '', '', '', '', '', '', '', '', '', 1)/
INSERT INTO pdmname VALUES(3, 'Akin Desai', 'Program Delivery Manager', '2201 Dupont Drive', '', 'Irvine', 'California', '92612', '(909) 859-9518', '(949) 833-0690', '(909) 859-9518', 'akin.desai@emc.com', 2)/
INSERT INTO pdmname VALUES(4, 'Jason Cronister', 'Program Delivery Manager', '10400 Viking Drive', 'Suite 400', 'Eden Prairie', 'Minnesota', '55344', '(952) 562-7354', '(952) 828-9509', '(612) 308-1578', 'jason.cronister@emc.com', 2)/
INSERT INTO pdmname VALUES(5, 'Chris O''Neal', 'Program Delivery Manager', '600 Emerson Road', 'Suite 400', 'Creve Coeur', 'Missouri', '63141', '(314) 989-3803', '(314) 469-6169', '(636) 288-2550', 'christopher.oneal@emc.com', 2)/
INSERT INTO pdmname VALUES(7, 'Dawn Paul', 'Program Delivery Manager', '10400 Viking Drive', 'Suite 400', 'Eden Prairie', 'Minnesota', '55344', '(952) 562-7374', '(952) 828-9509', '(612) 860-8154', 'dawn.paul@emc.com', 2)/
INSERT INTO pdmname VALUES(8, 'Edie Mikalauskas', 'Program Delivery Manager', '36555 Corporate Drive', '2nd Floor', 'Farmington Hills', 'Michigan', '48331', '(248) 957-5834', 'None', 'None', 'edie.mikalauskas@emc.com', 2)/
INSERT INTO pdmname VALUES(12, 'Ron Tremmel', 'Program Delivery Manager', '4225 Naperville Road', 'Suite 500', 'Lisle', 'Illinois', '60532', '(414) 319-7637', '(414) 319-7690', '(414) 704-7620', 'ron.tremmel@emc.com', 2)/
INSERT INTO pdmname VALUES(14, 'Shiju Vadakot', 'Program Delivery Manager', '300 Four Falls Corporate Center', 'Suite 700', 'Conshohocken', 'Pennsylvania', '19428', '(610) 234-2578', '(215) 754-4277', '(215) 570-6881', 'shiju.vadakot@emc.com', 2)/
INSERT INTO pdmname VALUES(18, 'Creighton Anderson', 'Program Delivery Manager', '8444 West Park Drive', 'Suite 800', 'McLean', 'Virginia', '20136', '703 970 5202', '', '703 517 3034', 'creighton.anderson@emc.com', 4)/
INSERT INTO pdmname VALUES(21, 'Dwight Davison', 'Program Delivery Manager', '8444 West Park Drive', 'Suite 800', 'McLean', 'Virginia', '20136', '703 970 5349', '703 842 8248', '703 282 0335', 'dwight.davison@emc.com', 4)/
INSERT INTO pdmname VALUES(23, 'Luis Alvarez Cuesta', 'Program Delivery Manager', 'Torre Mayor, Paseo de la Reforma # 505', 'Piso 39 - Col. Cuauhtemoc', 'Mexico City', 'Distrito Federal', '6500', '52-55-5080-3700', '52-55-5080-3841', '52-55-3888-1316', 'Luis.AlvarezCuesta@emc.com', 5)/
INSERT INTO pdmname VALUES(26, 'Dan Elliott', 'Program Delivery Manager', '7900 Triad Center Drive', '', 'Greensboro', 'North Carolina', '27409', 'None', 'None', '(336) 210-0691', 'dan.elliott@emc.com', 6)/
INSERT INTO pdmname VALUES(27, 'David Kopca', 'Program Delivery Manager', '14786 Preston Road', '', 'Dallas', 'Texas', '75255', 'None', 'None', '(972) 892-7835', 'david.kopca@emc.com', 6)/
INSERT INTO pdmname VALUES(29, 'Dena Bowman', 'Program Delivery Manager', '14785 Preston Road', '', 'Dallas', 'Texas', '75254', 'None', 'None', '(972) 759-6943', 'dena.bowman@emc.com', 6)/
INSERT INTO pdmname VALUES(31, 'Jason Hargrove', 'Program Delivery Manager', '8295 Tournament Drive', 'Suite 350', 'Memphis', 'Tennessee', '38125', 'None', 'None', '(901) 748-7331', 'jason.hargrove@emc.com', 6)/
INSERT INTO pdmname VALUES(32, 'Jeff Brinkman', 'Program Delivery Manager', '2850 Premiere Parkway', '', 'Duluth', 'Georgia', '30097', 'None', 'None', '(770) 814-3290', 'jeff.brinkman@emc.com', 6)/
INSERT INTO pdmname VALUES(33, 'Pete Zipay', 'Program Delivery Manager', '485 N. Keller Road', 'Suite 501', 'Maitland', 'Florida', '32751', 'None', 'None', '(407) 838-2832', 'peter.zipay@emc.com', 6)/
INSERT INTO pdmname VALUES(37, 'Tony Ferguson', 'Program Delivery Manager', '8820 Columbia 100 Parkway', '', 'Columbia', 'Maryland', '21045', 'None', 'None', '(443) 367-5322', 'tony.ferguson@emc.com', 6)/
INSERT INTO pdmname VALUES(38, 'John Root', 'Program Delivery Manager', '9 Townsend West', '', 'Nashua', 'New Hampshire', '03063', '(716) 200-2570', '', '', 'john.root@emc.com', 7)/
INSERT INTO pdmname VALUES(43, 'Dennis Scheil', 'Program Delivery Manager', '184 Liberty Corner Rd', '4th Flr', 'Warren', 'New Jersey', '07059', '(908) 286-7691', 'None', '(917) 209-9850', 'dennis.scheil@emc.com', 8)/
INSERT INTO pdmname VALUES(45, 'Jeff Kells', 'Program Delivery Manager', '184 Liberty Corner Rd', '4th Flr', 'Warren', 'New Jersey', '07059', '(908) 286-7761', 'None', '(732) 299-6982', 'jeffrey.kells@emc.com', 8)/
INSERT INTO pdmname VALUES(46, 'Rick Weigand', 'Program Delivery Manager', 'One Huntington', 'Quadrangle', 'Melville', 'New York', '11747', '(716) 835-3755', 'None', '(516) 428-1735', 'rick.weigand@emc.com', 8)/
INSERT INTO pdmname VALUES(48, 'Akin Desai', 'Program Delivery Manager', '2201 Dupont Drive', '', 'Irvine', 'California', '92612', '(909) 859-9518', '(949) 833-0690', '(909) 859-9518', 'akin.desai@emc.com', 9)/
INSERT INTO pdmname VALUES(49, 'Brandon Smith', 'Program Delivery Manager', '2201 Dupont Drive', 'Suite 500', 'Irvine', 'California', '92612', '(949) 797-3304', '(949) 833-0690', '(949) 202-7052', 'brandon.smith@emc.com', 9)/
INSERT INTO pdmname VALUES(53, 'Justin Holtzinger', 'Program Delivery Manager', '6801 Koll Center Parkway', '', 'Pleasanton', 'California', '94566', '', '(925) 407-8279', '(925) 831-2000', 'justin.holtzinger@emc.com', 9)/
INSERT INTO pdmname VALUES(54, 'Nathan Mondragon', 'Program Delivery Manager', '8000 South Chester St', 'Suite 600', 'Englewood', 'Colorado', '80112', '(303) 390-7016', '(303) 200-8133', '(720) 413-9267', 'nathan.mondragon@emc.com', 9)/
INSERT INTO pdmname VALUES(55, 'Tony Thomas', 'Program Delivery Manager', '6801 Koll Center Parkway', '', 'Pleasanton', 'California', '94566', '(925) 600-5615', '(925) 304-7437', '(925) 207-5202', 'tony.thomas@emc.com', 9)/
INSERT INTO pdmname VALUES(59, 'Mohamed El-Zomor', 'Program Delivery Manager', '11351 King Fahd Road', 'EMC computer systems', 'Riyadh', 'Saudi Arabia', '', '+96(0)6112794515', '', '+96(0)6540212375', 'mohamed.elzomor@emc.com', 12)/
INSERT INTO pdmname VALUES(60, 'Mahmood Shaker', 'Program Delivery Manager', '5th Floor-Internet City', 'Alpha Building', 'Dubai', 'United Arab Emirates', '', '+97(0)144240462', '', '+97(0)1526408821', 'Mahmood.Shaker@emc.com', 12)/
INSERT INTO pdmname VALUES(67, 'Suzanne Seif', 'Program Delivery Manager', '5th Floor-Internet City', 'Alpha Building', 'Dubai', 'United Arab Emirates', '', '+97(0)144240457', '', '+97(0)1501457342', 'suzanne.seif@emc.com', 12)/
INSERT INTO pdmname VALUES(71, 'Shakeel Shaik', 'Program Delivery Manager', '3021 William Nicol Drive', 'Bryanston', 'Johannesburg,', 'South Africa', '', '+27(0)115810117', '', '+27829034587', 'Shakeel.Shaik@emc.com', 12)/
INSERT INTO pdmname VALUES(73, 'Wendy Burns', 'Program Delivery Manager', '1st Floor The Royals', '353 Altrincham Road', 'Manchester', 'UK', '', '+44(0)1619465932', '', '+44(0)7802241300', 'wendy.burns@emc.com', 13)/
INSERT INTO pdmname VALUES(74, 'Michael Hutchinson', 'Program Delivery Manager', 'EMC Tower', 'Great West Road', 'Brentford', 'Ireland', '', '+44(0)7730052623', '', '+44(0)7730052623', 'michael.hutchinson@emc.com', 13)/
INSERT INTO pdmname VALUES(76, 'Jean Philippe Bianic', 'Sr Mgr, Professional Services', 'River Ouest', '80 Quai Voltaire', 'Bezons', 'FR', '', '+33(0) 1 39969058', '', '+33(0) 6 17221974', 'jean-philippe.bianic@emc.com', 14)/
INSERT INTO pdmname VALUES(79, 'Eric Avril', 'Mgr, Professional Services', 'River Ouest', '80 Quai Voltaire', 'Bezons', 'FR', '', '+33(0)139969026', '', '+33 (0)6 21 20 48 44', 'eric.avril@emc.com', 14)/
INSERT INTO pdmname VALUES(82, 'Manfred Oberpaul', 'Program Delivery Manager', 'Osterfeldstrasse 84', '', 'Munich', 'Germany', '', '+49(0)8993091243', '', '+49(0)1608818056', 'manfred.oberpaul@emc.com', 15)/
INSERT INTO pdmname VALUES(83, 'Raphael Mela', 'Program Delivery Manager', 'Am Kronberger Hang 2a', '', 'Schwalbach', 'Germany', '', '+49(0)61964728374', '', '+49(0)1734453428', 'raphael.mela@emc.com', 15)/
INSERT INTO pdmname VALUES(84, 'Chaled Rashwan', 'Program Delivery Manager', 'Osterbeekstr. 90B', '', 'Hamburg', 'Germany', '', '+49(0)4027131626', '', '+4915164962843', 'Chaled.Rashwan@emc.com', 15)/
INSERT INTO pdmname VALUES(86, 'Patrick Arn', 'GPSd Lead Switzerland / Manager Professional Services', 'Hardturmstrasse 181', '', 'CH8005 Zürich', 'Switzerland', '', '+41(0)434446749', '', '+41(0)792405046', 'patrick.arn@emc.com', 17)/
INSERT INTO pdmname VALUES(87, 'Koen Segers', 'Global Professional Services Delivery Lead BeLux', 'Imperiastraat 18', 'B1930', 'Zaventem', 'Belgium', '', '+32(0)27230100', '', '+32(0)479682361', 'koen.segers@emc.com', 17)/
INSERT INTO pdmname VALUES(89, 'Ole Wulff', 'Sr Mgr, Professional Services', 'Linde Allé 9', '', 'Nærum', 'Denmark', '', '+45(0)45560316', '', '+45(0)24248160', 'ole.wulff@emc.com', 17)/
INSERT INTO pdmname VALUES(90, 'Teemu Silvennoinen', 'Team Lead, Prof Services', 'Lauttasaarenmaki 4', '', 'Helsinki', 'Finland', '', '+35(0)8201202200', '', '+35(0)8407700913', 'teemu.silvennoinen@emc.com', 17)/
INSERT INTO pdmname VALUES(91, 'Eirik Storeng', 'Team Lead, Prof Services', 'Grenseveien 107', '', 'Oslo', 'Norway', '', '+47(0)23207727', '', '+47(0)40004555', 'Eirik.Storeng@emc.com', 17)/
INSERT INTO pdmname VALUES(92, 'Robert Forsberg', 'Sr Mgr, Professional Services', 'Telegrafgatan 4', '', 'Solna', 'Sweden', '', '+46(0)855512011', '', '+46(0)761009330', 'robert.forsberg@emc.com', 17)/
INSERT INTO pdmname VALUES(93, 'Hans Kolff', 'Sr Mgr, Professional Services', 'Edisonbaan 14B', '', 'Nieuwegein', 'Netherlands', '', '+31(0)306305060', '', '+31(0)627033006', 'hans.kolff@emc.com', 17)/
INSERT INTO pdmname VALUES(94, 'Carmen Garcia', 'Sr Mgr, Professional Services', 'Ribera del Loira 8', '', 'Madrid', 'Spain', '', '+34(0)914103898', '', '+34(0)616952188', 'carmen.garcia@emc.com', 17)/
INSERT INTO pdmname VALUES(95, 'Sofia Lima', 'Sr Mgr, Professional Services', 'Rua Doutor Antonio Loureiro Borges 5', '', 'Alges', 'Portugal', '', '+35(0)21214129624', '', '+35(0)1935546585', 'sofia.lima@emc.com', 17)/
INSERT INTO pdmname VALUES(96, 'Andrea Franchi', 'Program Delivery Manager', 'Via Spadolini, 5', 'Edificio A', 'Milano', 'Italy', '', '+39(0)240908059', '', '+39(0)3486430570', 'andrea.franchi@emc.com', 17)/
INSERT INTO pdmname VALUES(97, 'Vaibhav Sabharwal', 'Program Delivery Manager', '300 Conshohocken State Rd', 'Suite 700', 'Conshohocken', 'PA', '19428', '', '', '(704) 780 4089', 'Vaibhav.Sabharwal@emc.com', 6)/
INSERT INTO pdmname VALUES(98, 'Bob Martin', 'Program Delivery Manager', '14755 Preston Road', 'Suite 200', 'Dallas', 'Texas', '75154', 'None', 'None', '(972) 439-2633', 'robert.martin@emc.com', 6)/
INSERT INTO pdmname VALUES(99, 'Robin Aurilio', 'Sr Mgr, Professional Services', '300 Conshohocken State Road', 'Suite 700', 'Conshohocken', 'Pennsylvania', '19428', '(610)276-3031', 'None', '(917)539-6099', 'robin.aurilio@emc.com', 6)/
INSERT INTO pdmname VALUES(100, 'Diego Faria', 'Delivery Manager', 'Av Rio Negro, 161', '8 Andar', 'Barueri', 'Sao Paulo', '06455-020', '55-11-2078-1563', '55-11-2078-1699', '55-11-97661-7605', 'diego.faria@emc.com', 1)/
INSERT INTO pdmname VALUES(101, 'Ben Elliott', 'Program Delivery Manager', '36555 Corporate Drive', '2nd Floor', 'Farmington Hills', 'Michigan', '48331', '(248) 957-5834', 'None', '(734)-904-2828', 'ben.elliott@emc.com', 2)/
INSERT INTO pdmname VALUES(102, 'Brandon Smith', 'Program Delivery Manager', '2201 Dupont Drive', 'Suite 500', 'Irvine', 'California', '92612', '(949) 797-3304', '(949) 833-0690', '(949) 202-7052', 'brandon.smith@emc.com', 2)/
INSERT INTO pdmname VALUES(103, 'Calvin Williams', 'Program Delivery Manager', '4225 Naperville Road', 'Suite 500', 'Lisle', 'Illinois', '60532', '', '(866) 569-2727', '(262) 496-0716', 'calvin.williams@emc.com', 2)/
INSERT INTO pdmname VALUES(104, 'Christina Stichweh', 'Program Delivery Manager', '9200 Worthington Rd.', 'Suite 200', 'Columbus', 'OH', '43085', '(614) 797-5673', '', '(614) 572-7145', 'christina.stichweh@emc.com', 2)/
INSERT INTO pdmname VALUES(105, 'Nathan Mondragon', 'Program Delivery Manager', '8000 South Chester St', 'Suite 600', 'Englewood', 'Colorado', '80112', '(303) 390-7016', '(303) 200-8133', '(720) 413-9267', 'nathan.mondragon@emc.com', 2)/
INSERT INTO pdmname VALUES(106, 'Geoff Wise', 'Program Delivery Manager', '8888 Keystone Crossing', 'Suite 700', 'Indianapolis', 'Indiana', '46240', '(317) 690-2617', '', '', 'geoff.wise@emc.com', 2)/
INSERT INTO pdmname VALUES(107, 'Pramod Kumar C K', 'Program Delivery Manager', 'Bagmane Developers Pvt ltd', 'SEZ, , Marathahalli Ring Road, Dodanekundi Vilage', 'Bangalore', 'Karnataka', '560037', '1.800-782-4362 Extn-785 4124', '1-949-258-5502', '91-9611984499', 'pramod.kumar2@emc.com', 2)/
INSERT INTO pdmname VALUES(108, 'Mike O''Neill', 'Program Delivery Manager', '120 Adelaide Street West', '', 'Toronto', 'Ontario (Canada)', 'M5H 1T1', '(902) 222-1402', '', '', 'mike.oneill@emc.com', 7)/
INSERT INTO pdmname VALUES(109, 'Rosie Robinson', 'Program Delivery Manager', '555 Burrard Street', '', 'Vancouver', 'British Columbia (Canada)', 'V7X 1B1', '(416) 434-2247', '', '', 'rosie.robinson@emc.com', 7)/
INSERT INTO pdmname VALUES(110, 'Mark Harrington', 'Program Delivery Manager', '95 Wells Ave', '', 'Newton', 'Massachusetts', '02459', '(508) 864-7474', '', '', 'mark.harrington@emc.com', 7)/
INSERT INTO pdmname VALUES(111, 'Glenn Steinhandler', 'Program Delivery Manager', '184 Liberty Corner Rd', '4th Flr', 'Warren', 'New Jersey', '07059', '(908) 286-7676', 'None', '(732) 453-4055', 'gabriel.dupas@emc.com', 8)/
INSERT INTO pdmname VALUES(112, 'Joe Farrugia', 'Program Delivery Manager', '184 Liberty Corner Rd', '4th Flr', 'Warren', 'New Jersey', '07059', '(908) 286-3896', 'None', '(973)868-7372', 'joseph.farrugia@emc.com', 8)/
INSERT INTO pdmname VALUES(113, 'Robert Zutterman', 'Program Delivery Manager', '184 Liberty Corner Rd', '4th Flr', 'Warren', 'New Jersey', '07059', '', '', '', '', 8)/
INSERT INTO pdmname VALUES(114, 'Sabareesan Balasubramaniam', 'Program Delivery Manager', 'Bagmane Tech Park', '', 'Bangalore', 'India', '', '1-800-782-4362 x7854274', '', '303-954-4343', 'Sabareesan.balasubramaniam@emc.com', 9)/
INSERT INTO pdmname VALUES(115, 'Dave Hunt', 'Program Delivery Manager', '250 Montgomery Street', 'Suite 400', 'San Francisco', 'California', '94104', '(916) 221-2268', '', '', 'dave.hunt@emc.com', 9)/
INSERT INTO pdmname VALUES(116, 'Mark Hutchings', 'Program Delivery Manager', '15500 SE 30th Place', 'Suite 200', 'Bellevue', 'Washington', '98007', '(425) 748-3220', '', '(206) 437-3085', 'mark.hutchings@emc.com', 9)/
INSERT INTO pdmname VALUES(117, 'Jossh Gladness', 'Program Delivery Manager', '2201 Dupont Drive', 'Suite 500', 'Irvine', 'California', '92612', '(949) 797-2295', '(949) 833-0690', '(949) 373-6464', 'josh.norige@emc.com', 9)/
INSERT INTO pdmname VALUES(118, 'Kathy Dugas', 'Program Delivery Manager', '4250 N. Drinkwater Blvd', 'Suite 200', 'Scottsdale', 'Arizona', '85260', '(480) 874-7946', '(480) 425-1247', '(480) 299-6485', 'kathy.dugas@emc.com', 9)/
INSERT INTO pdmname VALUES(119, 'Amber Parnell', 'Program Delivery Manager', '8444 West Park Drive', 'Suite 800', 'McLean', 'Virginia', '20136', '703 970 5586', '', '703 624 9205', 'amber.parnell@emc.com', 4)/
INSERT INTO pdmname VALUES(120, 'Figini Juan', 'Program Delivery Manager', 'Av. Providencia 1760, Piso 15', '', 'Santiago de Chile', 'Santiago', '1001', '56 2 23733104', '', '56 9 61708752', 'juan.figini@emc.com', 10)/
INSERT INTO pdmname VALUES(121, 'Marisol Sanchez - Colombia', 'Program Delivery Manager', 'Calle 116 # 7-15 Int. 2, Of: 402.', '', 'Bogotá', 'Colombia.', '110111', '(212)206-6939', '', '(416)637-3409', 'Marisol.SanchezFont@emc.com', 11)/
INSERT INTO pdmname VALUES(122, 'Marisol Sanchez - Venezuela', 'Program Delivery Manager', 'Av, principal la castellana, torre la castellana piso 12 ofic 12-a', '', 'Caracas-Venezuela.', 'Altamira-miranda', '', '(212)206-6939', '', '(416)637-3409', 'Marisol.SanchezFont@emc.com', 11)/
INSERT INTO pdmname VALUES(123, 'Marisol Sanchez - Puerto Rico', 'Program Delivery Manager', 'Santander Tower 11th Floor B7 Tabonuco St. Guaynabo, PR', '', 'San Juan', 'Puerto Rico', '968', '(212)206-6939', '', '(416)637-3409', 'Marisol.SanchezFont@emc.com', 11)/
INSERT INTO pdmname VALUES(124, 'Ioannis Diamantis', 'GPSd Lead Greece, Cyprus, Malta', '44 Zalokosta & Kifisias Avenue', '15233, Chalandri', 'Athens', 'Greece', '', '+30(0)2106146926', '', '+30(0)6974262319', 'ioannis.diamantis@emc.com', 17)/
INSERT INTO pdmname VALUES(125, 'Itzhak Hanan', 'GPSd Lead Israel', '94 Em Hamoshavot', '1st & 2nd Floor, Park Azorim', 'Tel Aviv', 'Israel', '', '+972(0)37685404', '', '+972(0)546757173', 'itzhak.hanan@emc.com', 17)/
INSERT INTO pdmname VALUES(126, 'Wojciech Pliszka', 'Mgr Prof. Services', 'Choldna Street 512', '6th FloorWarsaw trade Tower', 'Warsaw', 'Poland', '', '+48224553002', '', '+48 605 324706', 'wojciech.pliszka@emc.com', 16)/
INSERT INTO pdmname VALUES(127, 'Andrei Korinets', 'Mgr Prof. Services', '3 Begovaya StreetFloor 30, Bldg 1', '', 'Moscow', 'Russian Federation', '', '+7 495 78 56622', '', '+7 9175662103', 'andrei.korinets@emc.com', 16)/
INSERT INTO pdmname VALUES(130, 'Umut Kurtdede', 'Program Delivery Manager', '5th Floor', '34330 Is Kuleleri Kule-2', 'Istanbul', 'Turkey', '', '+90(0)2123174464', '', '+905309619344', 'Umut.Kurtdede@emc.com', 16)/
INSERT INTO pdmname VALUES(131, 'Bharath Cadambi', '', '', '', '', '', '', '', '', '', '', 7)/
INSERT INTO pdmname VALUES(132, 'TBD', 'TBD', 'TBD', 'TBD', 'TBD', 'TBD', '', 'TBD', '', 'TBD', 'MS@emc.com', 26)/
INSERT INTO pdmname VALUES(133, 'TBD', 'TBD', 'TBD', 'TBD', 'TBD', 'TBD', '', 'TBD', '', 'TBD', 'TBD@emc.com', 23)/
INSERT INTO pdmname VALUES(134, 'TBD', 'TBD', 'TBD', 'TBD', 'TBD', 'TBD', '', 'TBD', '', 'TBD', 'TBD@emc.com', 21)/
INSERT INTO pdmname VALUES(135, 'TBD', 'TBD', 'TBD', 'TBD', 'TBD', 'TBD', '', 'TBD', '', 'TBD', 'TBD@emc.com', 22)/
INSERT INTO pdmname VALUES(136, 'TBD', 'TBD', 'TBD', 'TBD', 'TBD', 'TBD', '', 'TBD', '', 'TBD', 'TBD@emc.com', 20)/
INSERT INTO pdmname VALUES(137, 'RSA', 'RSA', 'RSA', 'RSA', 'RSA', 'RSA', '', 'RSA', '', 'RSA', 'RSA@emc.com', 24)/
INSERT INTO pdmname VALUES(138, 'TBD', 'TBD', 'TBD', 'TBD', 'TBD', 'TBD', '', 'TBD', '', 'TBD', 'TBD@emc.com', 19)/
INSERT INTO pdmname VALUES(139, 'TBD', 'TBD', 'TBD', 'TBD', 'TBD', 'TBD', '', 'TBD', '', 'TBD', 'TBD@emc.com', 18)/
INSERT INTO pdmname VALUES(140, 'ECD', 'ECD', 'ECD', 'ECD', 'ECD', 'ECD', '', 'ECD', '', 'ECD', 'ECD@emc.com', 25)/
INSERT INTO pdmname VALUES(141, 'None', 'Program Delivery Manager', 'none', 'none', 'None', 'None', 'None', 'None', 'None', 'None', 'None', 5)/
INSERT INTO pdmname VALUES(142, 'None', 'Program Delivery Manager', 'none', 'none', 'None', 'None', 'None', 'None', 'None', 'None', 'None', 8)/
INSERT INTO pdmname VALUES(143, 'Carol Cade', 'Program Delivery Manager', '4225 Naperville Road', 'Suite 500', 'Lisle', 'Illinois', '60532', '1-630-300-9052', 'None', 'None', 'Carol.Cade@emc.com', 7)/
INSERT INTO pdmname VALUES(144, 'Carol Cade', 'Program Delivery Manager', '4225 Naperville Road', 'Suite 500', 'Lisle', 'Illinois', '60532', '1-630-300-9052', 'None', 'None', 'Carol.Cade@emc.com', 1)/
INSERT INTO pdmname VALUES(145, 'None', 'Program Delivery Manager', 'none', 'none', 'None', 'None', 'None', 'None', 'None', 'None', 'None', 2)/
INSERT INTO pdmname VALUES(146, 'Carol Cade', 'Program Delivery Manager', '4225 Naperville Road', 'Suite 500', 'Lisle', 'Illinois', '60532', '1-630-300-9052', 'None', 'None', 'Carol.Cade@emc.com', 9)/
INSERT INTO pdmname VALUES(147, 'Carol Cade', 'Program Delivery Manager', '4225 Naperville Road', 'Suite 500', 'Lisle', 'Illinois', '60532', '1-630-300-9052', 'None', 'None', 'Carol.Cade@emc.com', 11)/
INSERT INTO pdmname VALUES(148, 'Carol Cade', 'Program Delivery Manager', '4225 Naperville Road', 'Suite 500', 'Lisle', 'Illinois', '60532', '1-630-300-9052', 'None', 'None', 'Carol.Cade@emc.com', 4)/
INSERT INTO pdmname VALUES(149, 'Carol Cade', 'Program Delivery Manager', '4225 Naperville Road', 'Suite 500', 'Lisle', 'Illinois', '60532', '1-630-300-9052', 'None', 'None', 'Carol.Cade@emc.com', 5)/
INSERT INTO pdmname VALUES(150, 'Carol Cade', 'Program Delivery Manager', '4225 Naperville Road', 'Suite 500', 'Lisle', 'Illinois', '60532', '1-630-300-9052', 'None', 'None', 'Carol.Cade@emc.com', 2)/
INSERT INTO pdmname VALUES(151, 'None', 'Program Delivery Manager', 'none', 'none', 'None', 'None', 'None', 'None', 'None', 'None', 'None', 9)/
INSERT INTO pdmname VALUES(152, 'Carol Cade', 'Program Delivery Manager', '4225 Naperville Road', 'Suite 500', 'Lisle', 'Illinois', '60532', '1-630-300-9052', 'None', 'None', 'Carol.Cade@emc.com', 8)/
INSERT INTO pdmname VALUES(153, 'None', 'Program Delivery Manager', 'none', 'none', 'None', 'None', 'None', 'None', 'None', 'None', 'None', 1)/
INSERT INTO pdmname VALUES(154, 'Carol Cade', 'Program Delivery Manager', '4225 Naperville Road', 'Suite 500', 'Lisle', 'Illinois', '60532', '1-630-300-9052', 'None', 'None', 'Carol.Cade@emc.com', 6)/
INSERT INTO pdmname VALUES(155, 'None', 'Program Delivery Manager', 'none', 'none', 'None', 'None', 'None', 'None', 'None', 'None', 'None', 7)/
INSERT INTO pdmname VALUES(156, 'None', 'Program Delivery Manager', 'none', 'none', 'None', 'None', 'None', 'None', 'None', 'None', 'None', 6)/
INSERT INTO pdmname VALUES(157, 'Carol Cade', 'Program Delivery Manager', '4225 Naperville Road', 'Suite 500', 'Lisle', 'Illinois', '60532', '1-630-300-9052', 'None', 'None', 'Carol.Cade@emc.com', 10)/
INSERT INTO pdmname VALUES(158, 'None', 'Program Delivery Manager', 'none', 'none', 'None', 'None', 'None', 'None', 'None', 'None', 'None', 4)/


INSERT INTO GeoState VALUES(1, 1, 6, 98, 'Alabama')/
INSERT INTO GeoState VALUES(2, 1, 9, 48, 'Alaska')/
INSERT INTO GeoState VALUES(51, 1, 7, 38, 'Alberta')/
INSERT INTO GeoState VALUES(89, 1, 9, 48, 'American Samoa')/
INSERT INTO GeoState VALUES(3, 1, 6, 98, 'Arkansas')/
INSERT INTO GeoState VALUES(4, 1, 9, 48, 'Arizona')/
INSERT INTO GeoState VALUES(52, 1, 7, 38, 'British Columbia')/
INSERT INTO GeoState VALUES(5, 1, 9, 48, 'California')/
INSERT INTO GeoState VALUES(6, 1, 9, 48, 'Colorado')/
INSERT INTO GeoState VALUES(7, 1, 7, 38, 'Connecticut')/
INSERT INTO GeoState VALUES(8, 1, 6, 98, 'Delaware')/
INSERT INTO GeoState VALUES(90, 1, 6, 98, 'District of Columbia')/
INSERT INTO GeoState VALUES(9, 1, 6, 98, 'Florida')/
INSERT INTO GeoState VALUES(10, 1, 6, 98, 'Georgia')/
INSERT INTO GeoState VALUES(91, 1, 9, 48, 'Guam')/
INSERT INTO GeoState VALUES(11, 1, 9, 48, 'Hawaii')/
INSERT INTO GeoState VALUES(12, 1, 9, 48, 'Idaho')/
INSERT INTO GeoState VALUES(13, 1, 2, 7, 'Illinois')/
INSERT INTO GeoState VALUES(14, 1, 2, 7, 'Indiana')/
INSERT INTO GeoState VALUES(15, 1, 2, 3, 'Iowa')/
INSERT INTO GeoState VALUES(16, 1, 2, 3, 'Kansas')/
INSERT INTO GeoState VALUES(17, 1, 2, 7, 'Kentucky')/
INSERT INTO GeoState VALUES(18, 1, 6, 98, 'Louisiana')/
INSERT INTO GeoState VALUES(19, 1, 7, 38, 'Maine')/
INSERT INTO GeoState VALUES(53, 1, 7, 38, 'Manitoba')/
INSERT INTO GeoState VALUES(20, 1, 6, 98, 'Maryland')/
INSERT INTO GeoState VALUES(21, 1, 7, 38, 'Massachusetts')/
INSERT INTO GeoState VALUES(22, 1, 2, 7, 'Michigan')/
INSERT INTO GeoState VALUES(23, 1, 2, 7, 'Minnesota')/
INSERT INTO GeoState VALUES(24, 1, 6, 98, 'Mississippi')/
INSERT INTO GeoState VALUES(25, 1, 2, 3, 'Missouri')/
INSERT INTO GeoState VALUES(26, 1, 9, 48, 'Montana')/
INSERT INTO GeoState VALUES(27, 1, 8, 14, 'New York')/
INSERT INTO GeoState VALUES(28, 1, 9, 48, 'New Mexico')/
INSERT INTO GeoState VALUES(29, 1, 7, 38, 'New Hampshire')/
INSERT INTO GeoState VALUES(30, 1, 8, 14, 'New Jersey')/
INSERT INTO GeoState VALUES(31, 1, 6, 98, 'North Carolina')/
INSERT INTO GeoState VALUES(32, 1, 2, 3, 'Nebraska')/
INSERT INTO GeoState VALUES(33, 1, 9, 48, 'Nevada')/
INSERT INTO GeoState VALUES(34, 1, 2, 7, 'North Dakota')/
INSERT INTO GeoState VALUES(92, 1, 9, 48, 'Northern Marianas Islands')/
INSERT INTO GeoState VALUES(35, 1, 2, 7, 'Ohio')/
INSERT INTO GeoState VALUES(36, 1, 6, 98, 'Oklahoma')/
INSERT INTO GeoState VALUES(37, 1, 9, 48, 'Oregon')/
INSERT INTO GeoState VALUES(38, 1, 6, 98, 'Pennsylvania (East)')/
INSERT INTO GeoState VALUES(93, 1, 2, 7, 'Pennsylvania (West)')/
INSERT INTO GeoState VALUES(39, 1, 6, 98, 'Rhode Island')/
INSERT INTO GeoState VALUES(40, 1, 6, 98, 'South Carolina')/
INSERT INTO GeoState VALUES(41, 1, 2, 7, 'South Dakota')/
INSERT INTO GeoState VALUES(42, 1, 6, 98, 'Tennessee')/
INSERT INTO GeoState VALUES(43, 1, 6, 98, 'Texas')/
INSERT INTO GeoState VALUES(44, 1, 9, 48, 'Utah')/
INSERT INTO GeoState VALUES(45, 1, 7, 38, 'Vermont')/
INSERT INTO GeoState VALUES(46, 1, 6, 98, 'Virginia')/
INSERT INTO GeoState VALUES(47, 1, 2, 14, 'West Virginia')/
INSERT INTO GeoState VALUES(48, 1, 9, 48, 'Wyoming')/
INSERT INTO GeoState VALUES(49, 1, 2, 7, 'Wisconsin')/
INSERT INTO GeoState VALUES(50, 1, 9, 3, 'Washington')/
INSERT INTO GeoState VALUES(54, 1, 7, 38, 'New Brunswick')/
INSERT INTO GeoState VALUES(55, 1, 7, 38, 'Newfoundland and Labrador')/
INSERT INTO GeoState VALUES(56, 1, 7, 38, 'Northwest Territories')/
INSERT INTO GeoState VALUES(57, 1, 7, 38, 'Nova Scotia')/
INSERT INTO GeoState VALUES(58, 1, 7, 38, 'Nunavut')/
INSERT INTO GeoState VALUES(59, 1, 7, 38, 'Ontario')/
INSERT INTO GeoState VALUES(60, 1, 7, 38, 'Prince Edward Island')/
INSERT INTO GeoState VALUES(61, 1, 7, 38, 'Quebec')/
INSERT INTO GeoState VALUES(62, 1, 7, 38, 'Saskatchewan')/
INSERT INTO GeoState VALUES(63, 1, 7, 38, 'Yukon Territory')/
INSERT INTO GeoState VALUES(94, 1, 5, 23, 'Puerto Rico')/
INSERT INTO GeoState VALUES(95, 1, 5, 23, 'Virgin Islands')/

INSERT INTO GeoState VALUES(64, 2, 1, 2, 'Argentina')/
INSERT INTO GeoState VALUES(65, 2, 5, 23, 'Bermuda')/
INSERT INTO GeoState VALUES(66, 2, 1, 2, 'Bolivia')/
INSERT INTO GeoState VALUES(67, 2, 1, 2, 'Brazil')/
INSERT INTO GeoState VALUES(68, 2, 1, 2, 'Chile')/
INSERT INTO GeoState VALUES(69, 2, 5, 23, 'Colombia')/
INSERT INTO GeoState VALUES(70, 2, 5, 23, 'Costa Rica')/
INSERT INTO GeoState VALUES(71, 2, 5, 23, 'Cuba')/
INSERT INTO GeoState VALUES(72, 2, 5, 23, 'Dominican Republic')/
INSERT INTO GeoState VALUES(73, 2, 5, 23, 'Ecuador')/
INSERT INTO GeoState VALUES(74, 2, 5, 23, 'El Salvador')/
INSERT INTO GeoState VALUES(75, 2, 5, 23, 'French Guiana')/
INSERT INTO GeoState VALUES(76, 2, 5, 23, 'Guatemala')/
INSERT INTO GeoState VALUES(77, 2, 5, 23, 'Guyana')/
INSERT INTO GeoState VALUES(78, 2, 5, 23, 'Honduras')/
INSERT INTO GeoState VALUES(79, 2, 5, 23, 'Jamaica')/
INSERT INTO GeoState VALUES(80, 2, 5, 23, 'Mexico')/
INSERT INTO GeoState VALUES(81, 2, 5, 23, 'Nicaragua')/
INSERT INTO GeoState VALUES(82, 2, 5, 23, 'Panama')/
INSERT INTO GeoState VALUES(83, 2, 1, 2, 'Paraguay')/
INSERT INTO GeoState VALUES(84, 2, 1, 2, 'Peru')/
INSERT INTO GeoState VALUES(85, 2, 5, 23, 'Puerto Rico')/
INSERT INTO GeoState VALUES(86, 2, 5, 23, 'Suriname')/
INSERT INTO GeoState VALUES(87, 2, 1, 2, 'Uruguay')/
INSERT INTO GeoState VALUES(88, 2, 5, 23, 'Venezuela')/

INSERT INTO SalesDistrict VALUES(1, 'TME', 'Enterprise', 'Enterprise', 1, 1, NULL)/
INSERT INTO SalesDistrict VALUES(2, 'Finance', 'Enterprise', 'Enterprise', 1, 1, NULL)/
INSERT INTO SalesDistrict VALUES(5, 'Commercial South', 'Geo South', 'MidMarket/SMB', 1, 1, NULL)/
INSERT INTO SalesDistrict VALUES(6, 'Commercial North', 'Geo North', 'MidMarket/SMB', 1, 1, NULL)/
INSERT INTO SalesDistrict VALUES(8, 'Enterprise - Chicago 1', 'Chicago', 'Enterprise', 2, 103, NULL)/
INSERT INTO SalesDistrict VALUES(9, 'Enterprise - Chicago 2', 'Chicago', 'Enterprise', 2, 12, NULL)/
INSERT INTO SalesDistrict VALUES(10, 'Enterprise - Chicago 4', 'Chicago', 'Enterprise', 2, 12, NULL)/
INSERT INTO SalesDistrict VALUES(11, 'Enterprise - Cincinnati 1', 'Ohio', 'Enterprise', 2, 106, NULL)/
INSERT INTO SalesDistrict VALUES(12, 'Enterprise - Cleveland', 'Ohio', 'Enterprise', 2, 104, NULL)/
INSERT INTO SalesDistrict VALUES(13, 'Enterprise - Detroit 3', 'IN/MI', 'Enterprise', 2, 101, NULL)/
INSERT INTO SalesDistrict VALUES(14, 'Enterprise - GM', 'IN/MI', 'Enterprise', 2, 101, NULL)/
INSERT INTO SalesDistrict VALUES(15, 'Enterprise - GM SMS', 'IN/MI', 'Enterprise', 2, 8, NULL)/
INSERT INTO SalesDistrict VALUES(16, 'Enterprise - Indianapolis', 'IN/MI', 'Enterprise', 2, 106, NULL)/
INSERT INTO SalesDistrict VALUES(17, 'Enterprise - Iowa', 'MO/MN', 'Enterprise', 2, 5, NULL)/
INSERT INTO SalesDistrict VALUES(18, 'Enterprise - Minneapolis 2', 'MO/MN', 'Enterprise', 2, 4, NULL)/
INSERT INTO SalesDistrict VALUES(19, 'Enterprise - Minneapolis 3', 'MO/MN', 'Enterprise', 2, 4, NULL)/
INSERT INTO SalesDistrict VALUES(20, 'Enterprise - Pittsburgh', 'Ohio', 'Enterprise', 2, 104, NULL)/
INSERT INTO SalesDistrict VALUES(21, 'Enterprise - Sprint', 'MO/MN', 'Enterprise', 2, 5, NULL)/
INSERT INTO SalesDistrict VALUES(22, 'Enterprise - St Louis', 'MO/MN', 'Enterprise', 2, 5, NULL)/
INSERT INTO SalesDistrict VALUES(23, 'Enterprise - Wisconsin 2', 'Chicago', 'Enterprise', 2, 12, NULL)/
INSERT INTO SalesDistrict VALUES(24, 'MidMarket - Chicago 1', 'Midwest', 'MidMarket', 2, 103, NULL)/
INSERT INTO SalesDistrict VALUES(25, 'MidMarket - Chicago 2', 'Midwest', 'MidMarket', 2, 103, NULL)/
INSERT INTO SalesDistrict VALUES(26, 'MidMarket - Chicago 3', 'Midwest', 'MidMarket', 2, 103, NULL)/
INSERT INTO SalesDistrict VALUES(27, 'MidMarket - Cincinnati', 'Ohio Valley', 'MidMarket', 2, 106, NULL)/
INSERT INTO SalesDistrict VALUES(28, 'MidMarket - Denver', 'Mountain Plains', 'MidMarket', 2, 105, NULL)/
INSERT INTO SalesDistrict VALUES(29, 'MidMarket - Michigan', 'Ohio Valley', 'MidMarket', 2, 101, NULL)/
INSERT INTO SalesDistrict VALUES(30, 'MidMarket - Minnesota', 'Midwest', 'MidMarket', 2, 4, NULL)/
INSERT INTO SalesDistrict VALUES(31, 'MidMarket - Mountain Plains 1', 'Mountain Plains', 'MidMarket', 2, 4, NULL)/
INSERT INTO SalesDistrict VALUES(32, 'MidMarket - Mountain Plains 2', 'Mountain Plains', 'MidMarket', 2, 4, NULL)/
INSERT INTO SalesDistrict VALUES(33, 'MidMarket - Ohio Valley Health Care', 'Ohio Valley', 'MidMarket', 2, 106, NULL)/
INSERT INTO SalesDistrict VALUES(34, 'MidMarket - Oklahoma', 'Mountain Plains', 'MidMarket', 2, 4, NULL)/
INSERT INTO SalesDistrict VALUES(35, 'MidMarket - Pittsburgh', 'Ohio Valley', 'MidMarket', 2, 104, NULL)/
INSERT INTO SalesDistrict VALUES(36, 'MidMarket - St. Louis', 'Ohio Valley', 'MidMarket', 2, 5, NULL)/
INSERT INTO SalesDistrict VALUES(37, 'MidMarket - Wisconsin', 'Midwest', 'MidMarket', 2, 12, NULL)/
INSERT INTO SalesDistrict VALUES(38, 'SMB - MI - Ohio Valley District 1', 'Ohio Valley', 'SMB', 2, 101, NULL)/
INSERT INTO SalesDistrict VALUES(39, 'SMB - MI - Ohio Valley District 2', 'Ohio Valley', 'SMB', 2, 101, NULL)/
INSERT INTO SalesDistrict VALUES(40, 'SMB - Midwest District 1', 'Midwest', 'SMB', 2, 103, NULL)/
INSERT INTO SalesDistrict VALUES(41, 'SMB - Midwest District 2', 'Midwest', 'SMB', 2, 103, NULL)/
INSERT INTO SalesDistrict VALUES(42, 'SMB - Midwest District 3', 'Midwest', 'SMB', 2, 103, NULL)/
INSERT INTO SalesDistrict VALUES(43, 'SMB - Midwest District 4', 'Midwest', 'SMB', 2, 12, NULL)/
INSERT INTO SalesDistrict VALUES(44, 'SMB - Midwest District 5', 'Midwest', 'SMB', 2, 12, NULL)/
INSERT INTO SalesDistrict VALUES(45, 'SMB - OH - Ohio Valley District 4', 'Ohio Valley', 'SMB', 2, 104, NULL)/
INSERT INTO SalesDistrict VALUES(46, 'SMB - Ohio Valley District 5', 'Ohio Valley', 'SMB', 2, 104, NULL)/
INSERT INTO SalesDistrict VALUES(47, 'SMB - Ohio Valley District 6', 'Ohio Valley', 'SMB', 2, 106, NULL)/
INSERT INTO SalesDistrict VALUES(48, 'SMB - Ohio Valley District 7', 'Ohio Valley', 'SMB', 2, 106, NULL)/
INSERT INTO SalesDistrict VALUES(49, 'SMB - South District 4', 'Mountain Plains', 'SMB', 2, 14, NULL)/
INSERT INTO SalesDistrict VALUES(50, 'SMB - South District 5', 'Mountain Plains', 'SMB', 2, 14, NULL)/
INSERT INTO SalesDistrict VALUES(51, 'SMB - South District 6', 'Mountain Plains', 'SMB', 2, 14, NULL)/
INSERT INTO SalesDistrict VALUES(52, 'SMB - South District 7', 'Mountain Plains', 'SMB', 2, 14, NULL)/
INSERT INTO SalesDistrict VALUES(53, 'SMB - Southern Cal District 6', 'Mountain Plains', 'SMB', 2, 102, NULL)/
INSERT INTO SalesDistrict VALUES(54, 'GEO MidMarket/SMB', 'GEO', 'GEO', 2, null, NULL)/
INSERT INTO SalesDistrict VALUES(55, 'Airforce', 'DOD', 'Enterprise', 4, 21, NULL)/
INSERT INTO SalesDistrict VALUES(56, 'Navy', 'DOD', 'Enterprise', 4, 21, NULL)/
INSERT INTO SalesDistrict VALUES(57, 'Army', 'DOD', 'Enterprise', 4, 21, NULL)/
INSERT INTO SalesDistrict VALUES(59, 'Civilian 2', 'Civilian', 'Enterprise', 4, 119, NULL)/
INSERT INTO SalesDistrict VALUES(60, 'Civilian 3', 'Civilian', 'Enterprise', 4, 119, NULL)/
INSERT INTO SalesDistrict VALUES(63, 'COCOM', 'DOD', 'Enterprise', 4, 21, NULL)/
INSERT INTO SalesDistrict VALUES(65, 'Intel', 'DOD', 'Enterprise', 4, 21, NULL)/
INSERT INTO SalesDistrict VALUES(68, 'TME', 'Enterprise', 'Enterprise', 5, 23, NULL)/
INSERT INTO SalesDistrict VALUES(69, 'Finance', 'Enterprise', 'Enterprise', 5, 23, NULL)/
INSERT INTO SalesDistrict VALUES(70, 'Government', 'Enterprise', 'Enterprise', 5, 23, NULL)/
INSERT INTO SalesDistrict VALUES(75, 'Enterprise - AT&T', 'AT&T', 'Enterprise', 6, 32, NULL)/
INSERT INTO SalesDistrict VALUES(76, 'Enterprise - Atlanta 7', 'Southeast', 'Enterprise', 6, 32, NULL)/
INSERT INTO SalesDistrict VALUES(77, 'Enterprise - Austin', 'TOLA', 'Enterprise', 6, 98, NULL)/
INSERT INTO SalesDistrict VALUES(78, 'Enterprise - Baltimore', 'MidAtlantic', 'Enterprise', 6, 37, NULL)/
INSERT INTO SalesDistrict VALUES(80, 'Enterprise - Blue Bell', 'MidAtlantic', 'Enterprise', 6, 99, NULL)/
INSERT INTO SalesDistrict VALUES(81, 'Enterprise - Dallas 1', 'TOLA', 'Enterprise', 6, 29, NULL)/
INSERT INTO SalesDistrict VALUES(82, 'Enterprise - Dallas 2', 'TOLA', 'Enterprise', 6, 29, NULL)/
INSERT INTO SalesDistrict VALUES(83, 'Enterprise - Florida Enterprise Sales', 'Southeast', 'Enterprise', 6, 33, NULL)/
INSERT INTO SalesDistrict VALUES(84, 'Enterprise - Georgia/Alabama', 'Southeast', 'Enterprise', 6, 32, NULL)/
INSERT INTO SalesDistrict VALUES(85, 'Enterprise - HealthCare District', 'MidAtlantic', 'Enterprise', 6, 26, NULL)/
INSERT INTO SalesDistrict VALUES(86, 'Enterprise - Houston', 'TOLA', 'Enterprise', 6, 98, NULL)/
INSERT INTO SalesDistrict VALUES(87, 'Enterprise - Memphis District', 'Southeast', 'Enterprise', 6, 31, NULL)/
INSERT INTO SalesDistrict VALUES(88, 'Enterprise - North Carolina 2', 'Southeast', 'Enterprise', 6, 26, NULL)/
INSERT INTO SalesDistrict VALUES(89, 'Enterprise - Philly 2', 'MidAtlantic', 'Enterprise', 6, 99, NULL)/
INSERT INTO SalesDistrict VALUES(90, 'Enterprise - Richmond 1/Raleigh', 'MidAtlantic', 'Enterprise', 6, 26, NULL)/
INSERT INTO SalesDistrict VALUES(91, 'Enterprise - Tampa', 'Southeast', 'Enterprise', 6, 33, NULL)/
INSERT INTO SalesDistrict VALUES(92, 'Enterprise - Tennessee/Carolina (includes Alabama)', 'Southeast', 'Enterprise', 6, 31, NULL)/
INSERT INTO SalesDistrict VALUES(93, 'Enterprise - TOLA District #5', 'TOLA', 'Enterprise', 6, 27, NULL)/
INSERT INTO SalesDistrict VALUES(94, 'Enterprise - Vienna 7', 'MidAtlantic', 'Enterprise', 6, 37, NULL)/
INSERT INTO SalesDistrict VALUES(95, 'GEO MidMarket/SMB', 'GEO', 'GEO', 6, 97, NULL)/
INSERT INTO SalesDistrict VALUES(96, 'Boston 1', 'Boston', 'Enterprise', 7, 110, NULL)/
INSERT INTO SalesDistrict VALUES(97, 'Boston 2', 'Boston', 'Enterprise', 7, 110, NULL)/
INSERT INTO SalesDistrict VALUES(98, 'Boston 3', 'Boston', 'Enterprise', 7, 110, NULL)/
INSERT INTO SalesDistrict VALUES(99, 'Boston 4', 'Boston', 'Enterprise', 7, 110, NULL)/
INSERT INTO SalesDistrict VALUES(102, 'Buffalo Comm', 'Commercial East', 'Commercial', 7, 38, NULL)/
INSERT INTO SalesDistrict VALUES(103, 'Calgary', 'Canada', 'Enterprise', 7, 109, NULL)/
INSERT INTO SalesDistrict VALUES(104, 'Comm Boston District', 'Commercial East', 'Commercial', 7, 110, NULL)/
INSERT INTO SalesDistrict VALUES(105, 'Comm Connecticut District', 'Commercial East', 'Commercial', 7, 38, NULL)/
INSERT INTO SalesDistrict VALUES(106, 'Comm East', 'Commercial East', 'Commercial', 7, 110, NULL)/
INSERT INTO SalesDistrict VALUES(107, 'Comm New England District', 'Commercial East', 'Commercial', 7, 110, NULL)/
INSERT INTO SalesDistrict VALUES(108, 'Comm Newton District', 'Commercial East', 'Commercial', 7, 110, NULL)/
INSERT INTO SalesDistrict VALUES(109, 'Comm Upstate NY District', 'Commercial East', 'Commercial', 7, 38, NULL)/
INSERT INTO SalesDistrict VALUES(110, 'Commercial East - House', 'Commercial East', 'Commercial', 7, 110, NULL)/
INSERT INTO SalesDistrict VALUES(111, 'GE', 'Global Account', 'Global', 7, 38, NULL)/
INSERT INTO SalesDistrict VALUES(112, 'Montreal', 'Canada', 'Enterprise', 7, 108, NULL)/
INSERT INTO SalesDistrict VALUES(113, 'Ottawa', 'Canada', 'Enterprise', 7, 108, NULL)/
INSERT INTO SalesDistrict VALUES(114, 'Rochester 1', 'CT/Upstate NY', 'Enterprise', 7, 38, NULL)/
INSERT INTO SalesDistrict VALUES(115, 'Rocky Hill 1', 'CT/Upstate NY', 'Enterprise', 7, 38, NULL)/
INSERT INTO SalesDistrict VALUES(116, 'Rocky Hill 2', 'CT/Upstate NY', 'Enterprise', 7, 38, NULL)/
INSERT INTO SalesDistrict VALUES(128, 'Toronto 4', 'Canada', 'Enterprise', 7, 109, NULL)/
INSERT INTO SalesDistrict VALUES(129, 'Toronto Commercial', 'Canada', 'Commercial', 7, 108, NULL)/
INSERT INTO SalesDistrict VALUES(130, 'Vancouver', 'Canada', 'Enterprise', 7, 109, NULL)/
INSERT INTO SalesDistrict VALUES(132, 'Enterprise - Bourke', 'Scotto', 'Enterprise', 8, 46, NULL)/
INSERT INTO SalesDistrict VALUES(133, 'Enterprise - Citibank', 'McLaughlin', 'Enterprise', 8, 111, NULL)/
INSERT INTO SalesDistrict VALUES(134, 'Enterprise - JPMC', 'Giordano', 'Enterprise', 8, 111, NULL)/
INSERT INTO SalesDistrict VALUES(136, 'Enterprise - Lubrano Districts', 'Lubrano', 'Enterprise', 8, 43, NULL)/
INSERT INTO SalesDistrict VALUES(137, 'Enterprise - Modica', 'Scotto', 'Enterprise', 8, 46, NULL)/
INSERT INTO SalesDistrict VALUES(140, 'Enterprise - Verizon', 'Global', 'Enterprise', 8, 111, NULL)/
INSERT INTO SalesDistrict VALUES(141, 'GEO MidMarket/SMB', 'Trizzino', 'GEO', 8, 112, NULL)/
INSERT INTO SalesDistrict VALUES(142, 'Enterprise - AMEX West', 'Mountain', 'Enterprise', 9, 118, NULL)/
INSERT INTO SalesDistrict VALUES(143, 'Enterprise - Cisco_Vertical_Globals', 'Nor Cal', 'Enterprise', 9, 48, NULL)/
INSERT INTO SalesDistrict VALUES(144, 'Enterprise - Denver 3', 'Mountain', 'Enterprise', 9, 54, NULL)/
INSERT INTO SalesDistrict VALUES(145, 'Enterprise - El Segundo', 'So Cal', 'Enterprise', 9, 117, NULL)/
INSERT INTO SalesDistrict VALUES(146, 'Enterprise - El Segundo 2', 'So Cal', 'Enterprise', 9, 49, NULL)/
INSERT INTO SalesDistrict VALUES(147, 'Enterprise - Irvine 1', 'So Cal', 'Enterprise', 9, 117, NULL)/
INSERT INTO SalesDistrict VALUES(148, 'Enterprise - Phoenix', 'Mountain', 'Enterprise', 9, 118, NULL)/
INSERT INTO SalesDistrict VALUES(149, 'Enterprise - Sacramento 1', 'Nor Cal', 'Enterprise', 9, 115, NULL)/
INSERT INTO SalesDistrict VALUES(150, 'Enterprise - San Francisco 4', 'Nor Cal', 'Enterprise', 9, 48, NULL)/
INSERT INTO SalesDistrict VALUES(151, 'Enterprise - San Francisco 6', 'Nor Cal', 'Enterprise', 9, 48, NULL)/
INSERT INTO SalesDistrict VALUES(152, 'Enterprise - Seattle 2', 'Mountain', 'Enterprise', 9, 116, NULL)/
INSERT INTO SalesDistrict VALUES(153, 'Enterprise - Seattle 3', 'Mountain', 'Enterprise', 9, 116, NULL)/
INSERT INTO SalesDistrict VALUES(154, 'Enterprise - TME_SLG-SLED RM', 'Mountain', 'Enterprise', 9, 54, NULL)/
INSERT INTO SalesDistrict VALUES(155, 'Enterprise - Wachovia', 'Nor Cal', 'Enterprise', 9, 115, NULL)/
INSERT INTO SalesDistrict VALUES(157, 'MidMarket - Dublin', 'NW Comm', 'MidMarket', 9, 115, NULL)/
INSERT INTO SalesDistrict VALUES(158, 'MidMarket - El Segundo', 'SW Comm', 'MidMarket', 9, 49, NULL)/
INSERT INTO SalesDistrict VALUES(159, 'MidMarket - Orange County', 'SW Comm', 'MidMarket', 9, 49, NULL)/
INSERT INTO SalesDistrict VALUES(160, 'MidMarket - San Diego / Hawaii', 'SW Comm', 'MidMarket', 9, 49, NULL)/
INSERT INTO SalesDistrict VALUES(161, 'MidMarket - San Francisco', 'NW Comm', 'MidMarket', 9, 115, NULL)/
INSERT INTO SalesDistrict VALUES(162, 'MidMarket - Seattle', 'NW Comm', 'MidMarket', 9, 115, NULL)/
INSERT INTO SalesDistrict VALUES(163, 'MidMarket - South San Fran', 'NW Comm', 'MidMarket', 9, 115, NULL)/
INSERT INTO SalesDistrict VALUES(164, 'SMB - Northern Cal', 'Geo West', 'SMB', 9, 115, NULL)/
INSERT INTO SalesDistrict VALUES(165, 'SMB - Other', 'Geo West', 'SMB', 9, null, NULL)/
INSERT INTO SalesDistrict VALUES(166, 'SMB - South', 'Geo West', 'SMB', 9, 118, NULL)/
INSERT INTO SalesDistrict VALUES(167, 'SMB - Southern Cal', 'Geo West', 'SMB', 9, 49, NULL)/
INSERT INTO SalesDistrict VALUES(168, 'SMB - Southern Cal / South / Northern Cal', 'Geo West', 'SMB', 9, 49, NULL)/
INSERT INTO SalesDistrict VALUES(169, 'GEO MidMarket/SMB', 'GEO', 'GEO', 9, 114, NULL)/
INSERT INTO SalesDistrict VALUES(170, 'East Enterprise', 'Enterprise', 'Enterprise', 10, 120, NULL)/
INSERT INTO SalesDistrict VALUES(171, 'East Government', 'Government', 'Government', 10, 120, NULL)/
INSERT INTO SalesDistrict VALUES(172, 'East Mid Tier', 'Mid Tier / Mid Market', 'Mid Tier / Mid Market', 10, 120, NULL)/
INSERT INTO SalesDistrict VALUES(173, 'East Low Commercial', 'Low Commercial', 'Low Commercial', 10, 120, NULL)/
INSERT INTO SalesDistrict VALUES(174, 'Central Enterprise', 'Enterprise', 'Enterprise', 10, 120, NULL)/
INSERT INTO SalesDistrict VALUES(175, 'Central Government', 'Government', 'Government', 10, 120, NULL)/
INSERT INTO SalesDistrict VALUES(176, 'Central Mid Tier', 'Mid Tier / Mid Market', 'Mid Tier / Mid Market', 10, 120, NULL)/
INSERT INTO SalesDistrict VALUES(177, 'Central Low Commercial', 'Low Commercial', 'Low Commercial', 10, 120, NULL)/
INSERT INTO SalesDistrict VALUES(178, 'West Enterprise', 'Enterprise', 'Enterprise', 10, 120, NULL)/
INSERT INTO SalesDistrict VALUES(179, 'West Government', 'Government', 'Government', 10, 120, NULL)/
INSERT INTO SalesDistrict VALUES(180, 'West Mid Tier', 'Mid Tier / Mid Market', 'Mid Tier / Mid Market', 10, 120, NULL)/
INSERT INTO SalesDistrict VALUES(181, 'West Low Commercial', 'Low Commercial', 'Low Commercial', 10, 120, NULL)/
INSERT INTO SalesDistrict VALUES(182, 'Colombia-Ecuador', 'Colombia', '', 11, 121, NULL)/
INSERT INTO SalesDistrict VALUES(183, 'Venezuela', 'Venezuela', '', 11, 122, NULL)/
INSERT INTO SalesDistrict VALUES(184, 'CCA', 'Puerto Rico', '', 11, 123, NULL)/
INSERT INTO SalesDistrict VALUES(185, 'Saudi Arabia', 'SEL', '', 12, 59, NULL)/
INSERT INTO SalesDistrict VALUES(186, 'Egypt', 'SEL', '', 12, 59, NULL)/
INSERT INTO SalesDistrict VALUES(187, 'Libya', 'SEL', '', 12, 59, NULL)/
INSERT INTO SalesDistrict VALUES(188, 'Bahrain', 'GULF', '', 12, 60, NULL)/
INSERT INTO SalesDistrict VALUES(189, 'Kuwait', 'GULF', '', 12, 60, NULL)/
INSERT INTO SalesDistrict VALUES(190, 'Oman', 'GULF', '', 12, 60, NULL)/
INSERT INTO SalesDistrict VALUES(191, 'Pakistan', 'GULF', '', 12, 60, NULL)/
INSERT INTO SalesDistrict VALUES(192, 'Qatar', 'GULF', '', 12, 60, NULL)/
INSERT INTO SalesDistrict VALUES(193, 'UAE', 'GULF', '', 12, 60, NULL)/
INSERT INTO SalesDistrict VALUES(194, 'Yemen', 'GULF', '', 12, 60, NULL)/
INSERT INTO SalesDistrict VALUES(195, 'Iraq', 'LEMA', '', 12, 67, NULL)/
INSERT INTO SalesDistrict VALUES(196, 'Jordan', 'LEMA', '', 12, 67, NULL)/
INSERT INTO SalesDistrict VALUES(197, 'Lebanon', 'LEMA', '', 12, 67, NULL)/
INSERT INTO SalesDistrict VALUES(198, 'Palestine', 'LEMA', '', 12, 67, NULL)/
INSERT INTO SalesDistrict VALUES(199, 'South Africa', 'South Africa', '', 12, 71, NULL)/
INSERT INTO SalesDistrict VALUES(200, 'NWCA', 'NWCA', '', 12, 67, NULL)/
INSERT INTO SalesDistrict VALUES(202, 'Enterprise South', 'United Kingdom', '', 13, 73, NULL)/
INSERT INTO SalesDistrict VALUES(203, 'Enterprise North', 'United Kingdom', '', 13, 73, NULL)/
INSERT INTO SalesDistrict VALUES(204, 'Mid Markets', 'United Kingdom', '', 13, 73, NULL)/
INSERT INTO SalesDistrict VALUES(205, 'Global Alliances', 'United Kingdom', '', 13, 73, NULL)/
INSERT INTO SalesDistrict VALUES(206, 'Public Sector', 'United Kingdom', '', 13, 74, NULL)/
INSERT INTO SalesDistrict VALUES(207, 'Service Provider', 'United Kingdom', '', 13, 74, NULL)/
INSERT INTO SalesDistrict VALUES(209, 'Mid Market', 'Ireland', '', 13, 74, 'SQCIreland@emc.com')/
INSERT INTO SalesDistrict VALUES(210, 'France', 'France', '', 14, 76, NULL)/
INSERT INTO SalesDistrict VALUES(211, 'South', 'Germany', '', 15, 82, NULL)/
INSERT INTO SalesDistrict VALUES(212, 'Central', 'Germany', '', 15, 83, NULL)/
INSERT INTO SalesDistrict VALUES(213, 'North', 'Germany', '', 15, 84, NULL)/
INSERT INTO SalesDistrict VALUES(215, 'Switzerland', 'West', '', 17, 86, 'SQCSwitzerland@emc.com')/
INSERT INTO SalesDistrict VALUES(216, 'Belgium', 'West', '', 17, 87, 'SQCBeLux@emc.com')/
INSERT INTO SalesDistrict VALUES(217, 'Luxembourg', 'West', '', 17, 87, 'SQCNordics@emc.com')/
INSERT INTO SalesDistrict VALUES(218, 'Denmark', 'West', '', 17, 89, 'SQCNordics@emc.com')/
INSERT INTO SalesDistrict VALUES(219, 'Finland', 'West', '', 17, 90, 'SQCNordics@emc.com')/
INSERT INTO SalesDistrict VALUES(220, 'Norway', 'West', '', 17, 91, 'SQCNordics@emc.com')/
INSERT INTO SalesDistrict VALUES(221, 'Sweden', 'West', '', 17, 92, 'SQCNordics@emc.com')/
INSERT INTO SalesDistrict VALUES(222, 'The Netherlands', 'West', '', 17, 93, 'SQCNetherlands@emc.com')/
INSERT INTO SalesDistrict VALUES(223, 'Spain', 'West', '', 17, 94, 'SQCIBERIA@emc.com')/
INSERT INTO SalesDistrict VALUES(224, 'Portugal', 'West', '', 17, 95, 'SQCIBERIA@emc.com')/
INSERT INTO SalesDistrict VALUES(225, 'Italy', 'West', '', 17, 96, 'SQCItaly@emc.com')/
INSERT INTO SalesDistrict VALUES(226, 'Greece', 'West', '', 17, 124, 'SQCGreece@emc.com')/
INSERT INTO SalesDistrict VALUES(227, 'Israel', 'West', '', 17, 125, 'SQCIsrael@emc.com')/
INSERT INTO SalesDistrict VALUES(228, 'Poland', 'East', '', 16, 126, NULL)/
INSERT INTO SalesDistrict VALUES(229, 'Russia', 'East', '', 16, 127, NULL)/
INSERT INTO SalesDistrict VALUES(230, 'Austria', 'East', '', 16, 126, NULL)/
INSERT INTO SalesDistrict VALUES(231, 'RoEE', 'East', '', 16, 126, NULL)/
INSERT INTO SalesDistrict VALUES(232, 'Turkey', 'East', '', 16, 130, NULL)/
INSERT INTO SalesDistrict VALUES(233, 'MIDMARKET SELECT HOUSTON DISTRICT', 'South', 'MidMarket', 6, 98, NULL)/
INSERT INTO SalesDistrict VALUES(234, 'MIDMARKET SELECT CHARLOTTE DISTRICT', 'Carolinas', 'MidMarket', 6, 26, NULL)/
INSERT INTO SalesDistrict VALUES(235, 'MIDMARKET SELECT GREENSBORO DISTRICT', 'Carolinas', 'MidMarket', 6, 26, NULL)/
INSERT INTO SalesDistrict VALUES(236, 'MIDMARKET SELECT RICHMOND DISTRICT', 'Carolinas', 'MidMarket', 6, 26, NULL)/
INSERT INTO SalesDistrict VALUES(237, 'MIDMARKET SELECT DALLAS DISTRICT', 'South', 'MidMarket', 6, 27, NULL)/
INSERT INTO SalesDistrict VALUES(238, 'MIDMARKET SELECT HEALTHCARE SOUTH DISTRICT', 'South', 'MidMarket', 6, 27, NULL)/
INSERT INTO SalesDistrict VALUES(239, 'MIDMARKET SELECT LAM DISTRICT', 'South Central', 'MidMarket', 6, 27, NULL)/
INSERT INTO SalesDistrict VALUES(240, 'MIDMARKET SELECT LAM HEALTHCARE DISTRICT', 'South Central', 'MidMarket', 6, 27, NULL)/
INSERT INTO SalesDistrict VALUES(241, 'MIDMARKET SELECT TN-KY DISTRICT', 'South Central', 'MidMarket', 6, 27, NULL)/
INSERT INTO SalesDistrict VALUES(242, 'MIDMARKET SELECT TN-KY HEALTHCARE DISTRICT', 'South Central', 'MidMarket', 6, 27, NULL)/
INSERT INTO SalesDistrict VALUES(243, 'MIDMARKET SELECT AUSTIN DISTRICT', 'South', 'MidMarket', 6, 29, NULL)/
INSERT INTO SalesDistrict VALUES(244, 'MIDMARKET SELECT METRO ATLANTA DISTRICT', 'Southeast', 'MidMarket', 6, 32, NULL)/
INSERT INTO SalesDistrict VALUES(245, 'MIDMARKET SELECT ATLANTA HEALTH DISTRICT', 'Southeast', 'MidMarket', 6, 33, NULL)/
INSERT INTO SalesDistrict VALUES(246, 'MIDMARKET SELECT FLORIDA 1 DISTRICT', 'Southeast', 'MidMarket', 6, 33, NULL)/
INSERT INTO SalesDistrict VALUES(247, 'MIDMARKET SELECT FLORIDA 2 DISTRICT', 'Southeast', 'MidMarket', 6, 33, NULL)/
INSERT INTO SalesDistrict VALUES(248, 'MIDMARKET SELECT PHILADELPHIA EAST DISTRICT', 'Mid-Atlantic', 'MidMarket', 6, 99, NULL)/
INSERT INTO SalesDistrict VALUES(249, 'MIDMARKET SELECT PHILADELPHIA WEST DISTRICT', 'Mid-Atlantic', 'MidMarket', 6, 99, NULL)/
INSERT INTO SalesDistrict VALUES(250, 'MIDMARKET SELECT BALTIMORE DISTRICT', 'Mid-Atlantic', 'MidMarket', 6, 37, NULL)/
INSERT INTO SalesDistrict VALUES(251, 'MIDMARKET SELECT MCLEAN DISTRICT', 'Carolinas', 'MidMarket', 6, 37, NULL)/
INSERT INTO SalesDistrict VALUES(252, 'Federal', 'Enterprise', 'Enterprise', 1, 1, NULL)/
INSERT INTO SalesDistrict VALUES(253, 'Oil & Gas', 'Enterprise', 'Enterprise', 1, 1, NULL)/
INSERT INTO SalesDistrict VALUES(254, 'Enterprise', 'Enterprise', 'Enterprise', 1, 1, NULL)/
INSERT INTO SalesDistrict VALUES(255, 'Commercial', 'Geo SP', 'MidMarket/SMB', 1, 1, NULL)/
INSERT INTO SalesDistrict VALUES(256, 'MidMarket - Arkansas', 'Arkansas', 'MidMarket', 2, 4, NULL)/
INSERT INTO SalesDistrict VALUES(257, 'High Growth & Educational', 'Mexico City', 'MidMarket', 5, 23, NULL)/
INSERT INTO SalesDistrict VALUES(258, 'Monterrey', 'Geo North', 'MidMarket', 5, 23, NULL)/
INSERT INTO SalesDistrict VALUES(260, 'MM-E Large ACCT NE District', 'Commercial East', 'MM', 7, 110, NULL)/
INSERT INTO SalesDistrict VALUES(261, 'MM-E Territory NE North District', 'Commercial East', 'MM', 7, 131, NULL)/
INSERT INTO SalesDistrict VALUES(262, 'MM-E Territory NE South District', 'Commercial East', 'MM', 7, 131, NULL)/
INSERT INTO SalesDistrict VALUES(263, 'Toronto Financial', 'Canada', 'Enterprise', 7, 108, NULL)/
INSERT INTO SalesDistrict VALUES(264, 'MIDMARKET SELECT BOSTON DISTRICT', 'Northeast', 'MidMarket', 7, 110, NULL)/
INSERT INTO SalesDistrict VALUES(265, 'MIDMARKET SELECT NEW ENGLAND DISTRICT', 'Northeast', 'MidMarket', 7, 110, NULL)/
INSERT INTO SalesDistrict VALUES(266, 'MIDMARKET SELECT NEWTON DISTRICT', 'Northeast', 'MidMarket', 7, 110, NULL)/
INSERT INTO SalesDistrict VALUES(267, 'MIDMARKET SELECT CONNECTICUT DISTRICT', 'Northeast', 'MidMarket', 7, 38, NULL)/
INSERT INTO SalesDistrict VALUES(268, 'MIDMARKET SELECT UPSTATE NY DISTRICT', 'Northeast', 'MidMarket', 7, 38, NULL)/
INSERT INTO SalesDistrict VALUES(269, 'Enterprise - Bank of America', 'BOA', 'Enterprise', 8, 113, NULL)/
INSERT INTO SalesDistrict VALUES(273, 'Enterprise - Hillock', 'Scotto', 'Enterprise', 8, 46, NULL)/
INSERT INTO SalesDistrict VALUES(275, 'Enterprise - Polaski - Burgess District', 'Polaski', 'Enterprise', 8, 113, NULL)/
INSERT INTO SalesDistrict VALUES(276, 'Enterprise - Polaski - Other Districts', 'Polaski', 'Enterprise', 8, 45, NULL)/
INSERT INTO SalesDistrict VALUES(277, 'Enterprise - Lilienfeld', 'Scotto', 'Enterprise', 8, 111, NULL)/
INSERT INTO SalesDistrict VALUES(279, 'MIDMARKET SELECT NJ 1 DISTRICT', 'Trizzino', 'GEO', 8, 112, NULL)/
INSERT INTO SalesDistrict VALUES(280, 'MIDMARKET SELECT NJ 2 DISTRICT', 'Trizzino', 'GEO', 8, 112, NULL)/
INSERT INTO SalesDistrict VALUES(281, 'MIDMARKET SELECT NYC 1 DISTRICT', 'Trizzino', 'GEO', 8, 112, NULL)/
INSERT INTO SalesDistrict VALUES(282, 'MIDMARKET SELECT NYC 2 DISTRICT', 'Trizzino', 'GEO', 8, 112, NULL)/
INSERT INTO SalesDistrict VALUES(283, 'NJ HEALTHCARE/LEGAL DISTRICT', 'Scotto', 'Enterprise', 8, 112, NULL)/
INSERT INTO SalesDistrict VALUES(284, 'Enterprise - Las Vegas', 'Mountain', 'Enterprise', 9, 118, NULL)/
INSERT INTO SalesDistrict VALUES(285, 'Enterprise - New Mexico', 'Mountain', 'Enterprise', 9, 54, NULL)/
INSERT INTO SalesDistrict VALUES(286, 'Enterprise - Santa Clara 1', 'Nor Cal', 'Enterprise', 9, 48, NULL)/
INSERT INTO SalesDistrict VALUES(287, 'MidMarket - AZ', 'SW Comm', 'MidMarket', 9, 118, NULL)/
INSERT INTO SalesDistrict VALUES(288, 'MidMarket - NM', 'SW Comm', 'MidMarket', 9, 54, NULL)/
INSERT INTO SalesDistrict VALUES(289, 'MidMarket - N. NV', 'SW Comm', 'MidMarket', 9, 115, NULL)/
INSERT INTO SalesDistrict VALUES(290, 'MidMarket - S. NV', 'SW Comm', 'MidMarket', 9, 118, NULL)/
INSERT INTO SalesDistrict VALUES(318, 'Strategic Programs', 'Civilian', 'Enterprise', 4, 18, NULL)/
INSERT INTO SalesDistrict VALUES(319, 'DHS / State Dept', 'Civilian', 'Enterprise', 4, 119, NULL)/
INSERT INTO SalesDistrict VALUES(320, 'BRS - South', 'Germany', '', 15, 82, NULL)/
INSERT INTO SalesDistrict VALUES(321, 'BRS - Central', 'Germany', '', 15, 83, NULL)/
INSERT INTO SalesDistrict VALUES(322, 'BRS - North', 'Germany', '', 15, 84, NULL)/
INSERT INTO SalesDistrict VALUES(323, 'France - BRS', 'France', '', 14, 79, NULL)/
INSERT INTO SalesDistrict VALUES(324, 'MS', 'MS', 'MS', 26, 132, NULL)/
INSERT INTO SalesDistrict VALUES(325, 'TBD', 'NotListed', '', 22, 135, NULL)/
INSERT INTO SalesDistrict VALUES(326, 'TBD', 'NotListed', '', 19, 138, NULL)/
INSERT INTO SalesDistrict VALUES(327, 'AUS', 'ANZ', '', 18, 139, NULL)/
INSERT INTO SalesDistrict VALUES(328, 'Greater China', 'Greater China', '', 19, 138, NULL)/
INSERT INTO SalesDistrict VALUES(329, 'India', 'India', '', 20, 136, NULL)/
INSERT INTO SalesDistrict VALUES(330, 'TBD', 'NotListed', '', 18, 139, NULL)/
INSERT INTO SalesDistrict VALUES(331, 'ECD', 'ECD', 'ECD', 25, 140, NULL)/
INSERT INTO SalesDistrict VALUES(332, 'Korea', 'Korea', '', 22, 135, NULL)/
INSERT INTO SalesDistrict VALUES(333, 'TBD', 'NotListed', '', 21, 134, NULL)/
INSERT INTO SalesDistrict VALUES(334, 'NZL', 'ANZ', '', 18, 139, NULL)/
INSERT INTO SalesDistrict VALUES(335, 'Japan', 'Japan', '', 21, 134, NULL)/
INSERT INTO SalesDistrict VALUES(336, 'Singapore', 'Singapore', '', 23, 133, NULL)/
INSERT INTO SalesDistrict VALUES(337, 'TBD', 'NotListed', '', 23, 133, NULL)/
INSERT INTO SalesDistrict VALUES(338, 'Malaysia', 'Malaysia', '', 23, 133, NULL)/
INSERT INTO SalesDistrict VALUES(339, 'TBD', 'NotListed', '', 20, 136, NULL)/
INSERT INTO SalesDistrict VALUES(340, 'Hong Kong', 'Hong Kong', '', 19, 138, NULL)/
INSERT INTO SalesDistrict VALUES(341, 'RSA', 'RSA', 'RSA', 24, 137, NULL)/
INSERT INTO SalesDistrict VALUES(342, 'Ireland', 'Ireland', '', 13, 74, 'SQCIreland@emc.com')/

INSERT INTO Collector VALUES(1, 'SNMP / ICMP')/
INSERT INTO Collector VALUES(2, 'SQL')/
INSERT INTO Collector VALUES(3, 'SSH / Telnet')/
INSERT INTO Collector VALUES(4, 'JMS')/
INSERT INTO Collector VALUES(5, 'WMI / PowerShell')/
INSERT INTO Collector VALUES(6, 'JMX')/
INSERT INTO Collector VALUES(7, 'CSV / Text')/
INSERT INTO Collector VALUES(8, 'XML / SOAP')/

INSERT INTO DCSolutionPack VALUES(1, 'Cisco USC Manager')/
INSERT INTO DCSolutionPack VALUES(2, 'VMWare vSphere')/
INSERT INTO DCSolutionPack VALUES(3, 'vBlock')/

INSERT INTO EMCSolutionPack VALUES(1, 'EMC ITOps IP/ACM')/
INSERT INTO EMCSolutionPack VALUES(2, 'EMC SMARTS Events')/
INSERT INTO EMCSolutionPack VALUES(3, 'Microsoft SCOM')/
INSERT INTO EMCSolutionPack VALUES(4, 'Alcatel 5620 SAM')/
INSERT INTO EMCSolutionPack VALUES(5, 'Ascom TEMS Mon. Master')/
INSERT INTO EMCSolutionPack VALUES(6, 'EXFO BrixWorx')/
INSERT INTO EMCSolutionPack VALUES(7, 'Accedian NIDs')/
INSERT INTO EMCSolutionPack VALUES(8, 'Huawei iManager')/
INSERT INTO EMCSolutionPack VALUES(9, 'IBM Tivoli Netcool')/
INSERT INTO EMCSolutionPack VALUES(10, 'HP Openview')/

INSERT INTO MobileSolutionPack VALUES(1, 'Mobile / Wireless')/
INSERT INTO MobileSolutionPack VALUES(2, 'Nokia NetAct')/
INSERT INTO MobileSolutionPack VALUES(3, 'Ericsson OSS-RC')/

INSERT INTO NetworkReportPack VALUES(1, 'Cisco Class-Based QoS')/
INSERT INTO NetworkReportPack VALUES(2, 'Cisco IP-SLA')/
INSERT INTO NetworkReportPack VALUES(3, 'BGP')/
INSERT INTO NetworkReportPack VALUES(4, 'Juniper QoS')/
INSERT INTO NetworkReportPack VALUES(5, 'Junioer RPM')/
INSERT INTO NetworkReportPack VALUES(6, 'Cisco NBAR')/
INSERT INTO NetworkReportPack VALUES(7, '3Com NQA')/
INSERT INTO NetworkReportPack VALUES(8, 'Wimax')/
INSERT INTO NetworkReportPack VALUES(9, 'Cisco CAR')/
INSERT INTO NetworkReportPack VALUES(10, 'MPLS')/
INSERT INTO NetworkReportPack VALUES(11, 'ATM / Frame Relay')/
INSERT INTO NetworkReportPack VALUES(12, 'NSN GGSN')/
INSERT INTO NetworkReportPack VALUES(13, 'Cable DOCSIS')/
INSERT INTO NetworkReportPack VALUES(14, 'DSLAM')/

INSERT INTO ServerReportPack VALUES(1, 'SUN Ldoms')/
INSERT INTO ServerReportPack VALUES(2, 'Microsoft SQL Server')/
INSERT INTO ServerReportPack VALUES(3, 'SMARTS Server Mgr')/
INSERT INTO ServerReportPack VALUES(4, 'Apache Web Server')/
INSERT INTO ServerReportPack VALUES(5, 'HP Compaq')/
INSERT INTO ServerReportPack VALUES(6, 'MySQL Database')/
INSERT INTO ServerReportPack VALUES(7, 'RIM BlackBerry Server')/
INSERT INTO ServerReportPack VALUES(8, 'IBM DB2')/
INSERT INTO ServerReportPack VALUES(9, 'Citrix XenApp')/
INSERT INTO ServerReportPack VALUES(10, 'Oracle')/
INSERT INTO ServerReportPack VALUES(11, 'UPS')/

INSERT INTO SmartsDomainType VALUES(1, 'SAM')/
INSERT INTO SmartsDomainType VALUES(2, 'IP')/
INSERT INTO SmartsDomainType VALUES(3, 'NPM')/
INSERT INTO SmartsDomainType VALUES(4, 'ESM')/
INSERT INTO SmartsDomainType VALUES(5, 'ACM')/
INSERT INTO SmartsDomainType VALUES(6, 'MPLS')/
INSERT INTO SmartsDomainType VALUES(7, 'MCAST')/
INSERT INTO SmartsDomainType VALUES(8, 'OTM')/

INSERT INTO StorageReportPack VALUES(1, 'Fiber-Channel Fabrics')/
INSERT INTO StorageReportPack VALUES(2, 'EMC CLARiiON')/
INSERT INTO StorageReportPack VALUES(3, 'EMC Symmetrix')/
INSERT INTO StorageReportPack VALUES(4, 'IBM DS Series')/
INSERT INTO StorageReportPack VALUES(5, 'IBM SVC')/
INSERT INTO StorageReportPack VALUES(6, 'HP EVA')/
INSERT INTO StorageReportPack VALUES(7, 'NetApp Filers')/

INSERT INTO VOIPSolutionPack VALUES(1, 'Cisco VoIP')/
INSERT INTO VOIPSolutionPack VALUES(2, 'Nortel VoIP')/
INSERT INTO VOIPSolutionPack VALUES(3, 'Broadsoft VoIP')/
INSERT INTO VOIPSolutionPack VALUES(4, 'Avaya VoIP')/
INSERT INTO VOIPSolutionPack VALUES(5, 'NSN VoIP')/

INSERT INTO VPNReportPack VALUES(1, 'Barracuda Firewall')/
INSERT INTO VPNReportPack VALUES(2, 'Checkpoint')/
INSERT INTO VPNReportPack VALUES(3, 'Juniper Firewall')/
INSERT INTO VPNReportPack VALUES(4, 'Cisco Firewall')/

INSERT INTO WANAccelerator VALUES(1, 'F5 BIG-IP')/
INSERT INTO WANAccelerator VALUES(2, 'Radware Load Balancer')/
INSERT INTO WANAccelerator VALUES(3, 'Cisco ACE')/
INSERT INTO WANAccelerator VALUES(4, 'Citrix Netscaler')/
INSERT INTO WANAccelerator VALUES(5, 'BlueCoat SG Series')/
INSERT INTO WANAccelerator VALUES(6, 'BlueCoat Packetshaper')/
INSERT INTO WANAccelerator VALUES(7, 'Juniper WXC')/
INSERT INTO WANAccelerator VALUES(8, 'Riverbed Steelhead')/
INSERT INTO WANAccelerator VALUES(9, 'WAAS')/

INSERT INTO WiFiReportPack VALUES(1, 'Cisco Wifi')/
INSERT INTO WiFiReportPack VALUES(2, 'Aruba Wifi')/
INSERT INTO WiFiReportPack VALUES(3, 'Motorola WiFi')/
INSERT INTO WiFiReportPack VALUES(4, 'Nomadix WiFi')/


insert into HostBasedMigrationTool values(1, 'Host-based LVM')/
insert into HostBasedMigrationTool values(2, 'Open Migrator LM')/
insert into HostBasedMigrationTool values(3, 'PowerPath Migration Enabler (PPME)')/

insert into XtremeHostBasedMigrationTool values(1, 'Host-based LVM')/
insert into XtremeHostBasedMigrationTool values(2, 'Open Migrator LM')/
insert into XtremeHostBasedMigrationTool values(3, 'PowerPath (PPME)')/

INSERT INTO ContractStructure VALUES(1, 'Fixed Fee')/
INSERT INTO ContractStructure VALUES(2, 'Time & Materials')/
INSERT INTO ContractStructure VALUES(3, 'Event Based')/

INSERT INTO DealQuestionSection VALUES(1, 'TIME & MATERIALS')/
INSERT INTO DealQuestionSection VALUES(2, 'FIXED FEE')/
INSERT INTO DealQuestionSection VALUES(3, 'VSD QUESTIONS')/
INSERT INTO DealQuestionSection VALUES(4, 'GENERAL QUESTIONS')/

INSERT INTO DealQuestion VALUES(1, 'If Time & Materials, are fees capped?', 1, 'If yes, explain', 1)/

INSERT INTO DealQuestion VALUES(2, 'If Fixed Fee, is contingency included?  % in comments', 1, 'List contingency %', 2)/
INSERT INTO DealQuestion VALUES(3, 'If Fixed Fee, are deliverables achievable w/in budget?', 0, 'If no, explain', 2)/

INSERT INTO DealQuestion VALUES(4, 'Has the VSD been involved in estimating work effort?', 1, 'If yes, list name of person', 3)/
INSERT INTO DealQuestion VALUES(5, 'Is the VSD content % in line with targets? Refer to VSD Tab', 0, 'If no, explain', 3)/
INSERT INTO DealQuestion VALUES(6, 'Has VSD successfully delivered this solution previously?', 0, 'If no, explain', 3)/

INSERT INTO DealQuestion VALUES(7, 'If client has a desired completion date, is it achievable?', 0, 'If no, explain', 4)/
INSERT INTO DealQuestion VALUES(8, 'Are client requirements clearly documented?', 0, 'If no, explain', 4)/
INSERT INTO DealQuestion VALUES(9, 'Has SP had adequate time with client to scope work?', 0, 'If no, explain', 4)/
INSERT INTO DealQuestion VALUES(10, 'Does this project deviate from standard offerings?', 1, 'If yes, explain', 4)/
INSERT INTO DealQuestion VALUES(11, 'Are new technologies in play?', 1, 'If yes, explain', 4)/
INSERT INTO DealQuestion VALUES(12, 'Are there any 3rd parties between us and sponsor?', 1, 'If yes, explain', 4)/
INSERT INTO DealQuestion VALUES(13, 'Are 3rd party roles & responsibilities clear?', 0, 'If no, explain', 4)/
INSERT INTO DealQuestion VALUES(14, 'Is our ability to perform dependent upon 3rd parties?', 1, 'If yes, explain', 4)/
INSERT INTO DealQuestion VALUES(15, 'Is this a new sponsor for us? Add concerns in comments.', 1, 'If yes, explain', 4)/
INSERT INTO DealQuestion VALUES(16, 'Do we have full time project manager in scope?', 0, 'If no, explain', 4)/
INSERT INTO DealQuestion VALUES(17, 'Does the PM have billable hours for project startup tasks?', 0, 'If no, explain', 4)/
INSERT INTO DealQuestion VALUES(18, 'Are we following EQ oversight guidelines/cadence?', 0, 'If no, explain', 4)/
INSERT INTO DealQuestion VALUES(19, 'Are the estimated hours in line with practice guidelines?', 0, 'If no, explain', 4)/
INSERT INTO DealQuestion VALUES(20, 'Is this is a bucket of hours without committed scope/start?', 1, 'If yes, explain', 4)/
INSERT INTO DealQuestion VALUES(21, 'Are there any client relationship issues?', 1, 'If yes, explain', 4)/
INSERT INTO DealQuestion VALUES(22, 'Are EMC resources available in the proposed time line?', 0, 'If no, explain', 4)/
INSERT INTO DealQuestion VALUES(23, 'Is delivery dependant on specific named EMC resources?', 1, 'If yes, explain', 4)/
INSERT INTO DealQuestion VALUES(24, 'Are we likely to be dependent on subs for any key roles?', 1, 'If yes, explain', 4)/
INSERT INTO DealQuestion VALUES(25, 'Is this tied to a product sale, or likely to drive one?', 1, 'If yes, explain', 4)/
INSERT INTO DealQuestion VALUES(26, 'Are the MCF completion criteria clear and in EMC''s favor?', 0, 'If no, explain', 4)/

INSERT INTO DealCurrency VALUES(1, 'AED', 0.272257011)/
INSERT INTO DealCurrency VALUES(2, 'ARS', 0.124979691)/
INSERT INTO DealCurrency VALUES(3, 'AUD', 0.88999644)/
INSERT INTO DealCurrency VALUES(4, 'BGN', 0.709018718)/
INSERT INTO DealCurrency VALUES(5, 'BHD', 2.652519894)/
INSERT INTO DealCurrency VALUES(6, 'BRL', 0.447968463)/
INSERT INTO DealCurrency VALUES(7, 'CAD', 0.912242292)/
INSERT INTO DealCurrency VALUES(8, 'CHF', 1.130454443)/
INSERT INTO DealCurrency VALUES(9, 'CLP', 0.001770382)/
INSERT INTO DealCurrency VALUES(10, 'CNY', 0.159757169)/
INSERT INTO DealCurrency VALUES(11, 'COP', 0.000516758)/
INSERT INTO DealCurrency VALUES(12, 'CZK', 0.050514235)/
INSERT INTO DealCurrency VALUES(13, 'DKK', 0.184420183)/
INSERT INTO DealCurrency VALUES(14, 'DZD', 0.01272582)/
INSERT INTO DealCurrency VALUES(15, 'EGP', 0.142651317)/
INSERT INTO DealCurrency VALUES(16, 'EUR', 1.35499519)/
INSERT INTO DealCurrency VALUES(17, 'GBP', 1.605007624)/
INSERT INTO DealCurrency VALUES(18, 'GHS', 0.353719359)/
INSERT INTO DealCurrency VALUES(19, 'HKD', 0.128985657)/
INSERT INTO DealCurrency VALUES(20, 'HRK', 0.182312082)/
INSERT INTO DealCurrency VALUES(21, 'HUF', 0.00451712)/
INSERT INTO DealCurrency VALUES(22, 'IDR', 0.000086490)/
INSERT INTO DealCurrency VALUES(23, 'ILS', 0.288517023)/
INSERT INTO DealCurrency VALUES(24, 'INR', 0.016574128)/
INSERT INTO DealCurrency VALUES(25, 'JOD', 1.410437236)/
INSERT INTO DealCurrency VALUES(26, 'JPY', 0.00952381)/
INSERT INTO DealCurrency VALUES(27, 'KES', 0.01150748)/
INSERT INTO DealCurrency VALUES(28, 'KRW', 0.000967848)/
INSERT INTO DealCurrency VALUES(29, 'KWD', 3.554797199)/
INSERT INTO DealCurrency VALUES(30, 'KZT', 0.005492393)/
INSERT INTO DealCurrency VALUES(31, 'LKR', 0.007654623)/
INSERT INTO DealCurrency VALUES(32, 'LTL', 0.401606426)/
INSERT INTO DealCurrency VALUES(33, 'MAD', 0.123160293)/
INSERT INTO DealCurrency VALUES(34, 'MKD', 0.022497694)/
INSERT INTO DealCurrency VALUES(35, 'MXN', 0.076313159)/
INSERT INTO DealCurrency VALUES(36, 'MYR', 0.306231817)/
INSERT INTO DealCurrency VALUES(37, 'NGN', 0.006221227)/
INSERT INTO DealCurrency VALUES(38, 'NOK', 0.166992302)/
INSERT INTO DealCurrency VALUES(39, 'NZD', 0.820001476)/
INSERT INTO DealCurrency VALUES(40, 'PEN', 0.35618878)/
INSERT INTO DealCurrency VALUES(41, 'PHP', 0.022436617)/
INSERT INTO DealCurrency VALUES(42, 'PKR', 0.010145589)/
INSERT INTO DealCurrency VALUES(43, 'PLN', 0.330534805)/
INSERT INTO DealCurrency VALUES(44, 'QAR', 0.274725275)/
INSERT INTO DealCurrency VALUES(45, 'RUB', 0.028012538)/
INSERT INTO DealCurrency VALUES(46, 'SAR', 0.266638225)/
INSERT INTO DealCurrency VALUES(47, 'SEK', 0.154495033)/
INSERT INTO DealCurrency VALUES(48, 'SGD', 0.797638989)/
INSERT INTO DealCurrency VALUES(49, 'THB', 0.03108979)/
INSERT INTO DealCurrency VALUES(50, 'TRL', 0.000471854)/
INSERT INTO DealCurrency VALUES(51, 'TRY', 0.471853914)/
INSERT INTO DealCurrency VALUES(52, 'TWD', 0.033079722)/
INSERT INTO DealCurrency VALUES(53, 'UAH', 0.086206897)/
INSERT INTO DealCurrency VALUES(54, 'USD', 1)/
INSERT INTO DealCurrency VALUES(55, 'VEB', 0.00015873)/
INSERT INTO DealCurrency VALUES(56, 'VEF', 0.158730159)/
INSERT INTO DealCurrency VALUES(57, 'VND', 0.000047432)/
INSERT INTO DealCurrency VALUES(58, 'ZAR', 0.095035353)/

-- Currencies with dummy values for now
INSERT INTO DealCurrency VALUES(59, 'AMD', 1)/
INSERT INTO DealCurrency VALUES(60, 'BBD', 1)/
INSERT INTO DealCurrency VALUES(61, 'BMD', 1)/
INSERT INTO DealCurrency VALUES(62, 'ECS', 1)/
INSERT INTO DealCurrency VALUES(63, 'SVC', 1)/
INSERT INTO DealCurrency VALUES(64, 'EEK', 1)/
INSERT INTO DealCurrency VALUES(65, 'GHC', 1)/
INSERT INTO DealCurrency VALUES(66, 'QTQ', 1)/
INSERT INTO DealCurrency VALUES(67, 'ISK', 1)/
INSERT INTO DealCurrency VALUES(68, 'JMD', 1)/
INSERT INTO DealCurrency VALUES(69, 'LBP', 1)/
INSERT INTO DealCurrency VALUES(70, 'N/A', 1)/
INSERT INTO DealCurrency VALUES(71, 'ROL', 1)/
INSERT INTO DealCurrency VALUES(72, 'RWF', 1)/
INSERT INTO DealCurrency VALUES(73, 'N/A', 1)/
INSERT INTO DealCurrency VALUES(74, 'SKK', 1)/
INSERT INTO DealCurrency VALUES(75, 'ZWD', 1)/

INSERT INTO DeliveryGeography values(1, 'Americas', '01')/
INSERT INTO DeliveryGeography values(2, 'EMEA', '02')/
INSERT INTO DeliveryGeography values(3, 'APJ', '03')/

INSERT INTO DeliveryCountry VALUES(1, 'DZ', 'Algeria', 2, 14, '+213')/
INSERT INTO DeliveryCountry VALUES(2, 'AU', 'Australia', 3, 3, '+61')/
INSERT INTO DeliveryCountry VALUES(3, 'AT', 'Austria', 2, 16, '+43')/
INSERT INTO DeliveryCountry VALUES(4, 'BE', 'Belgium', 2, 16, '+32')/
INSERT INTO DeliveryCountry VALUES(5, 'BR', 'Brazil', 1, 6, '+55')/
INSERT INTO DeliveryCountry VALUES(6, 'CA', 'Canada', 1, 7, '+1')/
INSERT INTO DeliveryCountry VALUES(7, 'CL', 'Chile', 1, 9, '+56')/
INSERT INTO DeliveryCountry VALUES(8, 'CN', 'China', 3, 10, '+86')/
INSERT INTO DeliveryCountry VALUES(9, 'CO', 'Columbia', 1, 11, '+57')/
INSERT INTO DeliveryCountry VALUES(10, 'CZ', 'Czech Republic', 1, 12, '+420')/
INSERT INTO DeliveryCountry VALUES(11, 'DK', 'Denmark', 2, 13, '+45')/
INSERT INTO DeliveryCountry VALUES(12, 'EG', 'Egypt', 2, 15, '+20')/
INSERT INTO DeliveryCountry VALUES(13, 'FI', 'Finland', 2, 16, '+358')/
INSERT INTO DeliveryCountry VALUES(14, 'FR', 'France', 2, 16, '+33')/
INSERT INTO DeliveryCountry VALUES(15, 'DE', 'Germany', 2, 16, '+49')/
INSERT INTO DeliveryCountry VALUES(16, 'GR', 'Greece', 2, 16, '+30')/
INSERT INTO DeliveryCountry VALUES(17, 'NL', 'Holland (Netherlands)', 2, 16, '+31')/
INSERT INTO DeliveryCountry VALUES(18, 'HK', 'Hong Kong', 3, 19, '+852')/
INSERT INTO DeliveryCountry VALUES(19, 'HU', 'Hungary', 2, 21, '+36')/
INSERT INTO DeliveryCountry VALUES(20, 'IN', 'India', 3, 24, '+91')/
INSERT INTO DeliveryCountry VALUES(21, 'ID', 'Indonesia', 2, 22, '+62')/
INSERT INTO DeliveryCountry VALUES(22, 'IE', 'Ireland', 2, 54, '+353')/
INSERT INTO DeliveryCountry VALUES(23, 'IL', 'Israel', 2, 54, '+972')/
INSERT INTO DeliveryCountry VALUES(24, 'IT', 'Italy', 2, 16, '+39')/
INSERT INTO DeliveryCountry VALUES(25, 'JP', 'Japan', 3, 26, '+81')/
INSERT INTO DeliveryCountry VALUES(26, 'KE', 'Kenya', 2, 27, '+254')/
INSERT INTO DeliveryCountry VALUES(27, 'LU', 'Luxembourg', 2, 16, '+352')/
INSERT INTO DeliveryCountry VALUES(28, 'MY', 'Malaysia', 3, 36, '+60')/
INSERT INTO DeliveryCountry VALUES(29, 'MX', 'Mexico', 1, 35, '+52')/
INSERT INTO DeliveryCountry VALUES(30, 'MA', 'Morocco', 2, 33, '+212')/
INSERT INTO DeliveryCountry VALUES(31, 'NZ', 'New Zealand', 3, 39, '+64')/
INSERT INTO DeliveryCountry VALUES(32, 'NG', 'Nigeria', 2, 37, '+234')/
INSERT INTO DeliveryCountry VALUES(33, 'NO', 'Norway', 2, 38, '+47')/
INSERT INTO DeliveryCountry VALUES(34, 'PE', 'Peru', 1, 40, '+51')/
INSERT INTO DeliveryCountry VALUES(35, 'PH', 'Philippines', 3, 41, '+63')/
INSERT INTO DeliveryCountry VALUES(36, 'PL', 'Poland', 2, 43, '+48')/
INSERT INTO DeliveryCountry VALUES(37, 'PT', 'Portugal', 2, 16, '+351')/
INSERT INTO DeliveryCountry VALUES(38, 'PR', 'Puerto Rico', 1, 54, '+1 787, +1 939')/
INSERT INTO DeliveryCountry VALUES(39, 'QA', 'Qatari', 2, 44, '+974')/
INSERT INTO DeliveryCountry VALUES(40, 'RU', 'Russia', 3, 45, '+7')/
INSERT INTO DeliveryCountry VALUES(41, 'SA', 'Saudi Arabia', 2, 46, '+966')/
INSERT INTO DeliveryCountry VALUES(42, 'SG', 'Singapore', 3, 48, '+65')/
INSERT INTO DeliveryCountry VALUES(43, 'ZA', 'South Africa', 2, 58, '+27')/
INSERT INTO DeliveryCountry VALUES(44, 'KR', 'South Korea', 3, 28, '+82')/
INSERT INTO DeliveryCountry VALUES(45, 'ES', 'Spain', 2, 16, '+34')/
INSERT INTO DeliveryCountry VALUES(46, 'SE', 'Sweden', 2, 47, '+46')/
INSERT INTO DeliveryCountry VALUES(47, 'CH', 'Switzerland', 2, 8, '+41')/
INSERT INTO DeliveryCountry VALUES(48, 'TW', 'Taiwan', 3, 52, '+886')/
INSERT INTO DeliveryCountry VALUES(49, 'TH', 'Thailand', 3, 49, '+66')/
INSERT INTO DeliveryCountry VALUES(50, 'TR', 'Turkey', 2, 51, '+90')/
INSERT INTO DeliveryCountry VALUES(51, 'AE', 'United Arab Emirates', 2, 1, '+971')/
INSERT INTO DeliveryCountry VALUES(52, 'GB', 'United Kingdom (Great Britain)', 2, 17, '+44')/
INSERT INTO DeliveryCountry VALUES(53, 'US', 'United States', 1, 54, '+1')/
INSERT INTO DeliveryCountry VALUES(54, 'VE', 'Venezuela', 1, 55, '+58')/
INSERT INTO DeliveryCountry VALUES(55, 'VN', 'Vietnam', 3, 57, '+84')/

INSERT INTO DeliveryCountry VALUES(56, 'AR', 'Argentina', 1, 2, '+54')/
INSERT INTO DeliveryCountry VALUES(57, 'AM', 'Armenia', 2, 59, '+374')/
INSERT INTO DeliveryCountry VALUES(58, 'BH', 'Bahrain', 2, 5, '+973')/
INSERT INTO DeliveryCountry VALUES(59, 'BB', 'Barbados', 1, 60, '+1 246')/
INSERT INTO DeliveryCountry VALUES(60, 'BM', 'Bermuda', 1, 61, '+1 441')/
INSERT INTO DeliveryCountry VALUES(61, 'BG', 'Bulgaria', 2, 4, '+359')/
INSERT INTO DeliveryCountry VALUES(62, 'HR', 'Croatia', 2, 20, '+385')/
INSERT INTO DeliveryCountry VALUES(63, 'EC', 'Ecuador', 1, 62, '+593')/
INSERT INTO DeliveryCountry VALUES(64, 'SV', 'El Salvador', 1, 63, '+503')/
INSERT INTO DeliveryCountry VALUES(65, 'EE', 'Estonia', 2, 64, '+593')/
INSERT INTO DeliveryCountry VALUES(66, 'GH', 'Ghana', 2, 65, '+233')/
INSERT INTO DeliveryCountry VALUES(67, 'GT', 'Guatemala', 1, 66, '+590')/
INSERT INTO DeliveryCountry VALUES(68, 'IS', 'Iceland', 2, 67, '+354')/
INSERT INTO DeliveryCountry VALUES(69, 'JM', 'Jamaica', 1, 68, '+1 876')/
INSERT INTO DeliveryCountry VALUES(70, 'JO', 'Jordan', 2, 25, '+962')/
INSERT INTO DeliveryCountry VALUES(71, 'KZ', 'Kazakhstan', 2, 30, '+7')/
INSERT INTO DeliveryCountry VALUES(72, 'LB', 'Lebanon', 2, 69, '+961')/
INSERT INTO DeliveryCountry VALUES(73, 'MT', 'Malta', 2, 16, '+356')/
INSERT INTO DeliveryCountry VALUES(74, 'PK', 'Pakistan', 2, 42, '+92')/
INSERT INTO DeliveryCountry VALUES(75, 'PS', 'Palestine', 2, 70, '+970')/
INSERT INTO DeliveryCountry VALUES(76, 'RO', 'Romania', 2, 71, '+40')/
INSERT INTO DeliveryCountry VALUES(77, 'RW', 'Rwanda', 2, 72, '+250')/
INSERT INTO DeliveryCountry VALUES(78, 'RS', 'Serbia', 2, 73, '+381')/
INSERT INTO DeliveryCountry VALUES(79, 'SK', 'Slovakia', 2, 74, '+421')/
INSERT INTO DeliveryCountry VALUES(80, 'SI', 'Slovenia', 2, 16, '+386')/
INSERT INTO DeliveryCountry VALUES(81, 'UA', 'Ukraine', 2, 53, '+380')/
INSERT INTO DeliveryCountry VALUES(82, 'ZW', 'Zimbabwe', 2, 75, '+263')/

INSERT INTO Region VALUES(1,'AJ','Adschman',51)/
INSERT INTO Region VALUES(2,'AZ','Abu Dhabi',51)/
INSERT INTO Region VALUES(3,'DU','Dubai',51)/
INSERT INTO Region VALUES(4,'FU','Fudschaira',51)/
INSERT INTO Region VALUES(5,'RK','Ra’s al-Chaima',51)/
INSERT INTO Region VALUES(6,'SH','Schardscha',51)/
INSERT INTO Region VALUES(7,'UQ','Umm al-Qaiwain',51)/
INSERT INTO Region VALUES(8,'0','Capital Federal',1)/
INSERT INTO Region VALUES(9,'1','Buenos Aires',1)/
INSERT INTO Region VALUES(10,'10','San Juan',1)/
INSERT INTO Region VALUES(11,'11','San Luis',1)/
INSERT INTO Region VALUES(12,'12','Santa Fé',1)/
INSERT INTO Region VALUES(13,'13','Santiago del Estero',1)/
INSERT INTO Region VALUES(14,'14','Tucumán',1)/
INSERT INTO Region VALUES(15,'16','Chaco',1)/
INSERT INTO Region VALUES(16,'17','Chubut',1)/
INSERT INTO Region VALUES(17,'18','Formosa',1)/
INSERT INTO Region VALUES(18,'19','Misiones',1)/
INSERT INTO Region VALUES(19,'2','Catamarca',1)/
INSERT INTO Region VALUES(20,'20','Neuquen',1)/
INSERT INTO Region VALUES(21,'21','La Pampa',1)/
INSERT INTO Region VALUES(22,'22','Rio Negro',1)/
INSERT INTO Region VALUES(23,'23','Santa Cruz',1)/
INSERT INTO Region VALUES(24,'24','Tierra de Fuego',1)/
INSERT INTO Region VALUES(25,'3','Córdoba',1)/
INSERT INTO Region VALUES(26,'4','Corrientes',1)/
INSERT INTO Region VALUES(27,'5','Entre Rios',1)/
INSERT INTO Region VALUES(28,'6','Jujuy',1)/
INSERT INTO Region VALUES(29,'7','Mendoza',1)/
INSERT INTO Region VALUES(30,'8','La Rioja',1)/
INSERT INTO Region VALUES(31,'9','Salta',1)/
INSERT INTO Region VALUES(32,'B','Burgenland',3)/
INSERT INTO Region VALUES(33,'K','Carinthia',3)/
INSERT INTO Region VALUES(34,'NOE','Lower Austria',3)/
INSERT INTO Region VALUES(35,'OOE','Upper Austria',3)/
INSERT INTO Region VALUES(36,'S','Salzburg',3)/
INSERT INTO Region VALUES(37,'ST','Styria',3)/
INSERT INTO Region VALUES(38,'T','Tyrol',3)/
INSERT INTO Region VALUES(39,'V','Vorarlberg',3)/
INSERT INTO Region VALUES(40,'W','Vienna',3)/
INSERT INTO Region VALUES(41,'ACT','Aust Capital Terr',2)/
INSERT INTO Region VALUES(42,'NSW','New South Wales',2)/
INSERT INTO Region VALUES(43,'NT','Northern Territory',2)/
INSERT INTO Region VALUES(44,'QLD','Queensland',2)/
INSERT INTO Region VALUES(45,'SA','South Australia',2)/
INSERT INTO Region VALUES(46,'TAS','Tasmania',2)/
INSERT INTO Region VALUES(47,'VIC','Victoria',2)/
INSERT INTO Region VALUES(48,'WA','Western Australia',2)/
INSERT INTO Region VALUES(49,'1','Antwerp',4)/
INSERT INTO Region VALUES(50,'10','Brabant Wallon',4)/
INSERT INTO Region VALUES(51,'11','Brussels-Capitale',4)/
INSERT INTO Region VALUES(52,'2','Vlaams-Brabant',4)/
INSERT INTO Region VALUES(53,'3','Hainaut',4)/
INSERT INTO Region VALUES(54,'4','Liege',4)/
INSERT INTO Region VALUES(55,'5','Limburg',4)/
INSERT INTO Region VALUES(56,'6','Luxemburg',4)/
INSERT INTO Region VALUES(57,'7','Namur',4)/
INSERT INTO Region VALUES(58,'8','Oost-Vlaanderen',4)/
INSERT INTO Region VALUES(59,'9','West-Vlaanderen',4)/
INSERT INTO Region VALUES(60,'1','Burgas',61)/
INSERT INTO Region VALUES(61,'2','Grad Sofiya',61)/
INSERT INTO Region VALUES(62,'3','Khaskovo',61)/
INSERT INTO Region VALUES(63,'4','Lovech',61)/
INSERT INTO Region VALUES(64,'5','Montana',61)/
INSERT INTO Region VALUES(65,'6','Plovdiv',61)/
INSERT INTO Region VALUES(66,'7','Ruse',61)/
INSERT INTO Region VALUES(67,'8','Sofiya',61)/
INSERT INTO Region VALUES(68,'9','Varna',61)/
INSERT INTO Region VALUES(69,'AC','Acre',5)/
INSERT INTO Region VALUES(70,'AL','Alagoas',5)/
INSERT INTO Region VALUES(71,'AM','Amazon',5)/
INSERT INTO Region VALUES(72,'AP','Amapa',5)/
INSERT INTO Region VALUES(73,'BA','Bahia',5)/
INSERT INTO Region VALUES(74,'CE','Ceara',5)/
INSERT INTO Region VALUES(75,'DF','Brasilia',5)/
INSERT INTO Region VALUES(76,'ES','Espirito Santo',5)/
INSERT INTO Region VALUES(77,'GO','Goias',5)/
INSERT INTO Region VALUES(78,'MA','Maranhao',5)/
INSERT INTO Region VALUES(79,'MG','Minas Gerais',5)/
INSERT INTO Region VALUES(80,'MS','Mato Grosso do Sul',5)/
INSERT INTO Region VALUES(81,'MT','Mato Grosso',5)/
INSERT INTO Region VALUES(82,'PA','Para',5)/
INSERT INTO Region VALUES(83,'PB','Paraiba',5)/
INSERT INTO Region VALUES(84,'PE','Pernambuco',5)/
INSERT INTO Region VALUES(85,'PI','Piaui',5)/
INSERT INTO Region VALUES(86,'PR','Parana',5)/
INSERT INTO Region VALUES(87,'RJ','Rio de Janeiro',5)/
INSERT INTO Region VALUES(88,'RN','Rio Grande do Norte',5)/
INSERT INTO Region VALUES(89,'RO','Rondonia',5)/
INSERT INTO Region VALUES(90,'RR','Roraima',5)/
INSERT INTO Region VALUES(91,'RS','Rio Grande do Sul',5)/
INSERT INTO Region VALUES(92,'SC','Santa Catarina',5)/
INSERT INTO Region VALUES(93,'SE','Sergipe',5)/
INSERT INTO Region VALUES(94,'SP','Sao Paulo',5)/
INSERT INTO Region VALUES(95,'TO','Tocantins',5)/
INSERT INTO Region VALUES(96,'AB','Alberta',6)/
INSERT INTO Region VALUES(97,'BC','British Columbia',6)/
INSERT INTO Region VALUES(98,'MB','Manitoba',6)/
INSERT INTO Region VALUES(99,'ML','Newfoundland',6)/
INSERT INTO Region VALUES(100,'NB','New Brunswick',6)/
INSERT INTO Region VALUES(101,'NL','New Foundland/Labr.',6)/
INSERT INTO Region VALUES(102,'NS','Nova Scotia',6)/
INSERT INTO Region VALUES(103,'NT','Northwest Terr.',6)/
INSERT INTO Region VALUES(104,'NU','Nunavut',6)/
INSERT INTO Region VALUES(105,'ON','Ontario',6)/
INSERT INTO Region VALUES(106,'PE','Prince Edward Island',6)/
INSERT INTO Region VALUES(107,'QC','Quebec',6)/
INSERT INTO Region VALUES(108,'SK','Saskatchewan',6)/
INSERT INTO Region VALUES(109,'YT','Yukon Territory',6)/
INSERT INTO Region VALUES(110,'AG','Aargau',47)/
INSERT INTO Region VALUES(111,'AI','Inner-Rhoden',47)/
INSERT INTO Region VALUES(112,'AR','Ausser-Rhoden',47)/
INSERT INTO Region VALUES(113,'BE','Bern',47)/
INSERT INTO Region VALUES(114,'BL','Basel Land',47)/
INSERT INTO Region VALUES(115,'BS','Basel Stadt',47)/
INSERT INTO Region VALUES(116,'FR','Fribourg',47)/
INSERT INTO Region VALUES(117,'GE','Geneva',47)/
INSERT INTO Region VALUES(118,'GL','Glarus',47)/
INSERT INTO Region VALUES(119,'GR','Graubuenden',47)/
INSERT INTO Region VALUES(120,'JU','Jura',47)/
INSERT INTO Region VALUES(121,'LU','Lucerne',47)/
INSERT INTO Region VALUES(122,'NE','Neuchatel',47)/
INSERT INTO Region VALUES(123,'NW','Nidwalden',47)/
INSERT INTO Region VALUES(124,'OW','Obwalden',47)/
INSERT INTO Region VALUES(125,'SG','St. Gallen',47)/
INSERT INTO Region VALUES(126,'SH','Schaffhausen',47)/
INSERT INTO Region VALUES(127,'SO','Solothurn',47)/
INSERT INTO Region VALUES(128,'SZ','Schwyz',47)/
INSERT INTO Region VALUES(129,'TG','Thurgau',47)/
INSERT INTO Region VALUES(130,'TI','Ticino',47)/
INSERT INTO Region VALUES(131,'UR','Uri',47)/
INSERT INTO Region VALUES(132,'VD','Vaud',47)/
INSERT INTO Region VALUES(133,'VS','Valais',47)/
INSERT INTO Region VALUES(134,'ZG','Zug',47)/
INSERT INTO Region VALUES(135,'ZH','Zurich',47)/
INSERT INTO Region VALUES(136,'1','I - Iquique',7)/
INSERT INTO Region VALUES(137,'10','X - Puerto Montt',7)/
INSERT INTO Region VALUES(138,'11','XI - Coyhaique',7)/
INSERT INTO Region VALUES(139,'12','XII - Punta Arenas',7)/
INSERT INTO Region VALUES(140,'13','RM - Santiago',7)/
INSERT INTO Region VALUES(141,'2','II - Antofagasta',7)/
INSERT INTO Region VALUES(142,'3','III - Copiapo',7)/
INSERT INTO Region VALUES(143,'4','IV - La Serena',7)/
INSERT INTO Region VALUES(144,'5','V - Valparaiso',7)/
INSERT INTO Region VALUES(145,'6','VI - Rancagua',7)/
INSERT INTO Region VALUES(146,'7','VII - Talca',7)/
INSERT INTO Region VALUES(147,'8','VIII - Concepcion',7)/
INSERT INTO Region VALUES(148,'9','IX - Temuco',7)/
INSERT INTO Region VALUES(149,'10','Beijing',8)/
INSERT INTO Region VALUES(150,'100','Jiangsu',8)/
INSERT INTO Region VALUES(151,'110','Anhui',8)/
INSERT INTO Region VALUES(152,'120','Shandong',8)/
INSERT INTO Region VALUES(153,'130','Zhejiang',8)/
INSERT INTO Region VALUES(154,'140','Jiangxi',8)/
INSERT INTO Region VALUES(155,'150','Fujian',8)/
INSERT INTO Region VALUES(156,'160','Hunan',8)/
INSERT INTO Region VALUES(157,'170','Hubei',8)/
INSERT INTO Region VALUES(158,'180','Henan',8)/
INSERT INTO Region VALUES(159,'190','Guangdong',8)/
INSERT INTO Region VALUES(160,'20','Shanghai',8)/
INSERT INTO Region VALUES(161,'200','Hainan',8)/
INSERT INTO Region VALUES(162,'210','Guangxi',8)/
INSERT INTO Region VALUES(163,'220','Guizhou',8)/
INSERT INTO Region VALUES(164,'230','Sichuan',8)/
INSERT INTO Region VALUES(165,'240','Yunnan',8)/
INSERT INTO Region VALUES(166,'250','Shaanxi',8)/
INSERT INTO Region VALUES(167,'260','Gansu',8)/
INSERT INTO Region VALUES(168,'270','Ningxia',8)/
INSERT INTO Region VALUES(169,'280','Qinghai',8)/
INSERT INTO Region VALUES(170,'290','Xinjiang',8)/
INSERT INTO Region VALUES(171,'30','Tianjin',8)/
INSERT INTO Region VALUES(172,'300','Xizang',8)/
INSERT INTO Region VALUES(173,'320','Chong Qing',8)/
INSERT INTO Region VALUES(174,'40','Nei Mongol',8)/
INSERT INTO Region VALUES(175,'50','Shanxi',8)/
INSERT INTO Region VALUES(176,'60','Hebei',8)/
INSERT INTO Region VALUES(177,'70','Liaoning',8)/
INSERT INTO Region VALUES(178,'80','Jilin',8)/
INSERT INTO Region VALUES(179,'90','Heilongjiang',8)/
INSERT INTO Region VALUES(180,'11','BOGOTA',9)/
INSERT INTO Region VALUES(181,'13','BOLIVAR',9)/
INSERT INTO Region VALUES(182,'15','BOYACA',9)/
INSERT INTO Region VALUES(183,'17','CALDAS',9)/
INSERT INTO Region VALUES(184,'18','CAQUETA',9)/
INSERT INTO Region VALUES(185,'19','CAUCA',9)/
INSERT INTO Region VALUES(186,'20','CESAR',9)/
INSERT INTO Region VALUES(187,'23','CORDOBA',9)/
INSERT INTO Region VALUES(188,'25','CUNDINAMARCA',9)/
INSERT INTO Region VALUES(189,'27','CHOCO',9)/
INSERT INTO Region VALUES(190,'41','HUILA',9)/
INSERT INTO Region VALUES(191,'44','LA GUAJIRA',9)/
INSERT INTO Region VALUES(192,'47','MAGDALENA',9)/
INSERT INTO Region VALUES(193,'5','ANTIOQUIA',9)/
INSERT INTO Region VALUES(194,'50','META',9)/
INSERT INTO Region VALUES(195,'52','NARINO',9)/
INSERT INTO Region VALUES(196,'54','NORTE SANTANDER',9)/
INSERT INTO Region VALUES(197,'63','QUINDIO',9)/
INSERT INTO Region VALUES(198,'66','RISARALDA',9)/
INSERT INTO Region VALUES(199,'68','SANTANDER',9)/
INSERT INTO Region VALUES(200,'70','SUCRE',9)/
INSERT INTO Region VALUES(201,'73','TOLIMA',9)/
INSERT INTO Region VALUES(202,'76','VALLE',9)/
INSERT INTO Region VALUES(203,'8','ATLANTICO',9)/
INSERT INTO Region VALUES(204,'81','ARAUCA',9)/
INSERT INTO Region VALUES(205,'85','CASANARE',9)/
INSERT INTO Region VALUES(206,'86','PUTUMAYO',9)/
INSERT INTO Region VALUES(207,'88','SAN ANDRES',9)/
INSERT INTO Region VALUES(208,'91','AMAZONAS',9)/
INSERT INTO Region VALUES(209,'94','GUAINIA',9)/
INSERT INTO Region VALUES(210,'95','GUAVIARE',9)/
INSERT INTO Region VALUES(211,'97','VAUPES',9)/
INSERT INTO Region VALUES(212,'99','VICHADA',9)/
INSERT INTO Region VALUES(213,'11','Praha',10)/
INSERT INTO Region VALUES(214,'21','Stredocesky',10)/
INSERT INTO Region VALUES(215,'31','Jihocesky',10)/
INSERT INTO Region VALUES(216,'32','Plzensky',10)/
INSERT INTO Region VALUES(217,'41','Karlovarsky',10)/
INSERT INTO Region VALUES(218,'42','Ustecky',10)/
INSERT INTO Region VALUES(219,'51','Liberecky',10)/
INSERT INTO Region VALUES(220,'52','Kralovehradecky',10)/
INSERT INTO Region VALUES(221,'53','Pardubicky',10)/
INSERT INTO Region VALUES(222,'61','Vysocina',10)/
INSERT INTO Region VALUES(223,'62','Jihomoravsky',10)/
INSERT INTO Region VALUES(224,'71','Olomoucky',10)/
INSERT INTO Region VALUES(225,'72','Zlinsky',10)/
INSERT INTO Region VALUES(226,'81','Moravskoslezsky',10)/
INSERT INTO Region VALUES(227,'1','Schleswig-Holstein',15)/
INSERT INTO Region VALUES(228,'10','Saarland',15)/
INSERT INTO Region VALUES(229,'11','Berlin',15)/
INSERT INTO Region VALUES(230,'12','Brandenburg',15)/
INSERT INTO Region VALUES(231,'13','Mecklenburg-Vorpomm.',15)/
INSERT INTO Region VALUES(232,'14','Saxony',15)/
INSERT INTO Region VALUES(233,'15','Saxony-Anhalt',15)/
INSERT INTO Region VALUES(234,'16','Thuringia',15)/
INSERT INTO Region VALUES(235,'2','Hamburg',15)/
INSERT INTO Region VALUES(236,'3','Lower Saxony',15)/
INSERT INTO Region VALUES(237,'4','Bremen',15)/
INSERT INTO Region VALUES(238,'5','Nrth Rhine Westfalia',15)/
INSERT INTO Region VALUES(239,'6','Hessen',15)/
INSERT INTO Region VALUES(240,'7','Rhineland Palatinate',15)/
INSERT INTO Region VALUES(241,'8','Baden-Wurttemberg',15)/
INSERT INTO Region VALUES(242,'9','Bavaria',15)/
INSERT INTO Region VALUES(243,'99','-',15)/
INSERT INTO Region VALUES(244,'1','Danish Capital Reg.',11)/
INSERT INTO Region VALUES(245,'2','Central Jutland',11)/
INSERT INTO Region VALUES(246,'3','North Jutland',11)/
INSERT INTO Region VALUES(247,'4','Zealand',11)/
INSERT INTO Region VALUES(248,'5','South Denmark',11)/
INSERT INTO Region VALUES(249,'1','Alava',45)/
INSERT INTO Region VALUES(250,'10','Caceres',45)/
INSERT INTO Region VALUES(251,'11','Cadiz',45)/
INSERT INTO Region VALUES(252,'12','Castellon',45)/
INSERT INTO Region VALUES(253,'13','Ciudad Real',45)/
INSERT INTO Region VALUES(254,'14','Cordoba',45)/
INSERT INTO Region VALUES(255,'15','La Coruna',45)/
INSERT INTO Region VALUES(256,'16','Cuenca',45)/
INSERT INTO Region VALUES(257,'17','Gerona',45)/
INSERT INTO Region VALUES(258,'18','Granada',45)/
INSERT INTO Region VALUES(259,'19','Guadalajara',45)/
INSERT INTO Region VALUES(260,'2','Albacete',45)/
INSERT INTO Region VALUES(261,'20','Guipuzcoa',45)/
INSERT INTO Region VALUES(262,'21','Huelva',45)/
INSERT INTO Region VALUES(263,'22','Huesca',45)/
INSERT INTO Region VALUES(264,'23','Jaen',45)/
INSERT INTO Region VALUES(265,'24','Leon',45)/
INSERT INTO Region VALUES(266,'25','Lerida',45)/
INSERT INTO Region VALUES(267,'26','La Rioja',45)/
INSERT INTO Region VALUES(268,'27','Lugo',45)/
INSERT INTO Region VALUES(269,'28','Madrid',45)/
INSERT INTO Region VALUES(270,'29','Malaga',45)/
INSERT INTO Region VALUES(271,'3','Alicante',45)/
INSERT INTO Region VALUES(272,'30','Murcia',45)/
INSERT INTO Region VALUES(273,'31','Navarra',45)/
INSERT INTO Region VALUES(274,'32','Orense',45)/
INSERT INTO Region VALUES(275,'33','Asturias',45)/
INSERT INTO Region VALUES(276,'34','Palencia',45)/
INSERT INTO Region VALUES(277,'35','Las Palmas',45)/
INSERT INTO Region VALUES(278,'36','Pontevedra',45)/
INSERT INTO Region VALUES(279,'37','Salamanca',45)/
INSERT INTO Region VALUES(280,'38','Sta. Cruz Tenerife',45)/
INSERT INTO Region VALUES(281,'39','Cantabria',45)/
INSERT INTO Region VALUES(282,'4','Almeria',45)/
INSERT INTO Region VALUES(283,'40','Segovia',45)/
INSERT INTO Region VALUES(284,'41','Sevilla',45)/
INSERT INTO Region VALUES(285,'42','Soria',45)/
INSERT INTO Region VALUES(286,'43','Tarragona',45)/
INSERT INTO Region VALUES(287,'44','Teruel',45)/
INSERT INTO Region VALUES(288,'45','Toledo',45)/
INSERT INTO Region VALUES(289,'46','Valencia',45)/
INSERT INTO Region VALUES(290,'47','Valladolid',45)/
INSERT INTO Region VALUES(291,'48','Vizcaya',45)/
INSERT INTO Region VALUES(292,'49','Zamora',45)/
INSERT INTO Region VALUES(293,'5','Avila',45)/
INSERT INTO Region VALUES(294,'50','Zaragoza',45)/
INSERT INTO Region VALUES(295,'51','Ceuta',45)/
INSERT INTO Region VALUES(296,'52','Melilla',45)/
INSERT INTO Region VALUES(297,'6','Badajoz',45)/
INSERT INTO Region VALUES(298,'7','Illes Balears',45)/
INSERT INTO Region VALUES(299,'8','Barcelona',45)/
INSERT INTO Region VALUES(300,'9','Burgos',45)/
INSERT INTO Region VALUES(301,'1','Ahvenanmaa',13)/
INSERT INTO Region VALUES(302,'2','Southern Finnland',13)/
INSERT INTO Region VALUES(303,'3','Eastern Finnland',13)/
INSERT INTO Region VALUES(304,'4','Lappi',13)/
INSERT INTO Region VALUES(305,'5','Western Finnland',13)/
INSERT INTO Region VALUES(306,'6','Oulu',13)/
INSERT INTO Region VALUES(307,'1','Ain',14)/
INSERT INTO Region VALUES(308,'10','Aube',14)/
INSERT INTO Region VALUES(309,'11','Aude',14)/
INSERT INTO Region VALUES(310,'12','Aveyron',14)/
INSERT INTO Region VALUES(311,'13','Bouches-du-Rhone',14)/
INSERT INTO Region VALUES(312,'14','Calvados',14)/
INSERT INTO Region VALUES(313,'15','Cantal',14)/
INSERT INTO Region VALUES(314,'16','Charente',14)/
INSERT INTO Region VALUES(315,'17','Charente-Maritime',14)/
INSERT INTO Region VALUES(316,'18','Cher',14)/
INSERT INTO Region VALUES(317,'19','Correze',14)/
INSERT INTO Region VALUES(318,'2','Aisne',14)/
INSERT INTO Region VALUES(319,'21','Cote-dOr',14)/
INSERT INTO Region VALUES(320,'22','Cotes-dArmor',14)/
INSERT INTO Region VALUES(321,'23','Creuse',14)/
INSERT INTO Region VALUES(322,'24','Dordogne',14)/
INSERT INTO Region VALUES(323,'25','Doubs',14)/
INSERT INTO Region VALUES(324,'26','Drome',14)/
INSERT INTO Region VALUES(325,'27','Eure',14)/
INSERT INTO Region VALUES(326,'28','Eure-et-Loir',14)/
INSERT INTO Region VALUES(327,'29','Finistere',14)/
INSERT INTO Region VALUES(328,'2A','Corse-du-Sud',14)/
INSERT INTO Region VALUES(329,'2B','Corse-du-Nord',14)/
INSERT INTO Region VALUES(330,'3','Allier',14)/
INSERT INTO Region VALUES(331,'30','Gard',14)/
INSERT INTO Region VALUES(332,'31','Garonne (Haute)',14)/
INSERT INTO Region VALUES(333,'32','Gers',14)/
INSERT INTO Region VALUES(334,'33','Gironde',14)/
INSERT INTO Region VALUES(335,'34','Herault',14)/
INSERT INTO Region VALUES(336,'35','Ille-et-Vilaine',14)/
INSERT INTO Region VALUES(337,'36','Indre',14)/
INSERT INTO Region VALUES(338,'37','Indre-et-Loire',14)/
INSERT INTO Region VALUES(339,'38','Isere',14)/
INSERT INTO Region VALUES(340,'39','Jura',14)/
INSERT INTO Region VALUES(341,'4','Alpes (Hte-Provence)',14)/
INSERT INTO Region VALUES(342,'40','Landes',14)/
INSERT INTO Region VALUES(343,'41','Loir-et-Cher',14)/
INSERT INTO Region VALUES(344,'42','Loire',14)/
INSERT INTO Region VALUES(345,'43','Loire (Haute)',14)/
INSERT INTO Region VALUES(346,'44','Loire-Atlantique',14)/
INSERT INTO Region VALUES(347,'45','Loiret',14)/
INSERT INTO Region VALUES(348,'46','Lot',14)/
INSERT INTO Region VALUES(349,'47','Lot-et-Garonne',14)/
INSERT INTO Region VALUES(350,'48','Lozere',14)/
INSERT INTO Region VALUES(351,'49','Maine-et-Loire',14)/
INSERT INTO Region VALUES(352,'5','Alpes (Hautes)',14)/
INSERT INTO Region VALUES(353,'50','Manche',14)/
INSERT INTO Region VALUES(354,'51','Marne',14)/
INSERT INTO Region VALUES(355,'52','Marne (Haute)',14)/
INSERT INTO Region VALUES(356,'53','Mayenne',14)/
INSERT INTO Region VALUES(357,'54','Meurthe-et-Moselle',14)/
INSERT INTO Region VALUES(358,'55','Meuse',14)/
INSERT INTO Region VALUES(359,'56','Morbihan',14)/
INSERT INTO Region VALUES(360,'57','Moselle',14)/
INSERT INTO Region VALUES(361,'58','Nievre',14)/
INSERT INTO Region VALUES(362,'59','Nord',14)/
INSERT INTO Region VALUES(363,'6','Alpes-Maritimes',14)/
INSERT INTO Region VALUES(364,'60','Oise',14)/
INSERT INTO Region VALUES(365,'61','Orne',14)/
INSERT INTO Region VALUES(366,'62','Pas-de-Calais',14)/
INSERT INTO Region VALUES(367,'63','Puy-de-Dome',14)/
INSERT INTO Region VALUES(368,'64','Pyrenees-Atlantiques',14)/
INSERT INTO Region VALUES(369,'65','Pyrenees (Hautes)',14)/
INSERT INTO Region VALUES(370,'66','Pyrenees-Orientales',14)/
INSERT INTO Region VALUES(371,'67','Bas-Rhin',14)/
INSERT INTO Region VALUES(372,'68','Haut-Rhin',14)/
INSERT INTO Region VALUES(373,'69','Rhone',14)/
INSERT INTO Region VALUES(374,'7','Ardeche',14)/
INSERT INTO Region VALUES(375,'70','Saone (Haute)',14)/
INSERT INTO Region VALUES(376,'71','Saone-et-Loire',14)/
INSERT INTO Region VALUES(377,'72','Sarthe',14)/
INSERT INTO Region VALUES(378,'73','Savoie',14)/
INSERT INTO Region VALUES(379,'74','Savoie (Haute)',14)/
INSERT INTO Region VALUES(380,'75','Paris',14)/
INSERT INTO Region VALUES(381,'76','Seine-Maritime',14)/
INSERT INTO Region VALUES(382,'77','Seine-et-Marne',14)/
INSERT INTO Region VALUES(383,'78','Yvelines',14)/
INSERT INTO Region VALUES(384,'79','Sevres (Deux)',14)/
INSERT INTO Region VALUES(385,'8','Ardennes',14)/
INSERT INTO Region VALUES(386,'80','Somme',14)/
INSERT INTO Region VALUES(387,'81','Tarn',14)/
INSERT INTO Region VALUES(388,'82','Tarn-et-Garonne',14)/
INSERT INTO Region VALUES(389,'83','Var',14)/
INSERT INTO Region VALUES(390,'84','Vaucluse',14)/
INSERT INTO Region VALUES(391,'85','Vendee',14)/
INSERT INTO Region VALUES(392,'86','Vienne',14)/
INSERT INTO Region VALUES(393,'87','Vienne (Haute)',14)/
INSERT INTO Region VALUES(394,'88','Vosges',14)/
INSERT INTO Region VALUES(395,'89','Yonne',14)/
INSERT INTO Region VALUES(396,'9','Ariege',14)/
INSERT INTO Region VALUES(397,'90','Territ.-de-Belfort',14)/
INSERT INTO Region VALUES(398,'91','Essonne',14)/
INSERT INTO Region VALUES(399,'92','Hauts-de-Seine',14)/
INSERT INTO Region VALUES(400,'93','Seine-Saint-Denis',14)/
INSERT INTO Region VALUES(401,'94','Val-de-Marne',14)/
INSERT INTO Region VALUES(402,'95','Val-dOise',14)/
INSERT INTO Region VALUES(403,'97','D.O.M.-T.O.M.',14)/
INSERT INTO Region VALUES(404,'971','Guadeloupe',14)/
INSERT INTO Region VALUES(405,'972','Martinique',14)/
INSERT INTO Region VALUES(406,'973','Guyane',14)/
INSERT INTO Region VALUES(407,'974','Reunion',14)/
INSERT INTO Region VALUES(408,'975','Saint-Pierre-et-Miq.',14)/
INSERT INTO Region VALUES(409,'976','Wallis-et-Futuna',14)/
INSERT INTO Region VALUES(410,'99','Hors-France',14)/
INSERT INTO Region VALUES(411,'AB','Aberdeenshire',52)/
INSERT INTO Region VALUES(412,'AG','Argyllshire',52)/
INSERT INTO Region VALUES(413,'AL','Anglesey',52)/
INSERT INTO Region VALUES(414,'AM','Armagh',52)/
INSERT INTO Region VALUES(415,'AN','Angus/Forfarshire',52)/
INSERT INTO Region VALUES(416,'AT','Antrim',52)/
INSERT INTO Region VALUES(417,'AY','Ayrshire',52)/
INSERT INTO Region VALUES(418,'BE','Bedfordshire',52)/
INSERT INTO Region VALUES(419,'BF','Banffshire',52)/
INSERT INTO Region VALUES(420,'BK','Berkshire',52)/
INSERT INTO Region VALUES(421,'BR','Brecknockshire',52)/
INSERT INTO Region VALUES(422,'BS','Bath&NthEstSomerset',52)/
INSERT INTO Region VALUES(423,'BT','Buteshire',52)/
INSERT INTO Region VALUES(424,'BU','Buckinghamshire',52)/
INSERT INTO Region VALUES(425,'BW','Berwickshire',52)/
INSERT INTO Region VALUES(426,'CA','Cambridgeshire',52)/
INSERT INTO Region VALUES(427,'CB','Carmarthenshire',52)/
INSERT INTO Region VALUES(428,'CD','Cardiganshire',52)/
INSERT INTO Region VALUES(429,'CF','Caernarfonshire',52)/
INSERT INTO Region VALUES(430,'CH','Cheshire',52)/
INSERT INTO Region VALUES(431,'CM','Cromartyshire',52)/
INSERT INTO Region VALUES(432,'CN','Clackmannanshire',52)/
INSERT INTO Region VALUES(433,'CO','Cornwall',52)/
INSERT INTO Region VALUES(434,'CT','Caithness',52)/
INSERT INTO Region VALUES(435,'CU','Cumberland',52)/
INSERT INTO Region VALUES(436,'DB','Derbyshire',52)/
INSERT INTO Region VALUES(437,'DD','Denbighshire',52)/
INSERT INTO Region VALUES(438,'DF','Dumfriesshire',52)/
INSERT INTO Region VALUES(439,'DN','Down',52)/
INSERT INTO Region VALUES(440,'DO','Dorset',52)/
INSERT INTO Region VALUES(441,'DT','Dunbartonshire',52)/
INSERT INTO Region VALUES(442,'DU','Durham',52)/
INSERT INTO Region VALUES(443,'DV','Devon',52)/
INSERT INTO Region VALUES(444,'EL','East Lothian',52)/
INSERT INTO Region VALUES(445,'ES','Essex',52)/
INSERT INTO Region VALUES(446,'FI','Fife',52)/
INSERT INTO Region VALUES(447,'FL','Flintshire',52)/
INSERT INTO Region VALUES(448,'FM','Fermanagh',52)/
INSERT INTO Region VALUES(449,'GL','Gloucestershire',52)/
INSERT INTO Region VALUES(450,'GM','Glamorgan',52)/
INSERT INTO Region VALUES(451,'HA','Hampshire',52)/
INSERT INTO Region VALUES(452,'HT','Hertfordshire',52)/
INSERT INTO Region VALUES(453,'HU','Huntingdonshire',52)/
INSERT INTO Region VALUES(454,'HW','Hereford and Worcs.',52)/
INSERT INTO Region VALUES(455,'IA','Isle of Islay',52)/
INSERT INTO Region VALUES(456,'IL','Isle of Lewis',52)/
INSERT INTO Region VALUES(457,'IM','Isle of Man',52)/
INSERT INTO Region VALUES(458,'IN','Invernesshire',52)/
INSERT INTO Region VALUES(459,'IS','Isle of Skye',52)/
INSERT INTO Region VALUES(460,'IW','Isle of Wight',52)/
INSERT INTO Region VALUES(461,'IY','Isle of Scilly',52)/
INSERT INTO Region VALUES(462,'JE','Jersey',52)/
INSERT INTO Region VALUES(463,'KE','Kent',52)/
INSERT INTO Region VALUES(464,'KI','Kincardineshire',52)/
INSERT INTO Region VALUES(465,'KK','Kirkcudbrightshire',52)/
INSERT INTO Region VALUES(466,'KN','Kinross-shire',52)/
INSERT INTO Region VALUES(467,'LA','Lancashire',52)/
INSERT INTO Region VALUES(468,'LD','Londonderry',52)/
INSERT INTO Region VALUES(469,'LE','Leicestershire',52)/
INSERT INTO Region VALUES(470,'LI','Lincolnshire',52)/
INSERT INTO Region VALUES(471,'LN','Lanarkshire',52)/
INSERT INTO Region VALUES(472,'MD','Midlothian',52)/
INSERT INTO Region VALUES(473,'ME','Merioneth',52)/
INSERT INTO Region VALUES(474,'MG','Mid Glamorgan',52)/
INSERT INTO Region VALUES(475,'MM','Monmouthshire',52)/
INSERT INTO Region VALUES(476,'MR','Morayshire',52)/
INSERT INTO Region VALUES(477,'MT','Montgomeryshire',52)/
INSERT INTO Region VALUES(478,'MX','Middlesex',52)/
INSERT INTO Region VALUES(479,'NH','Northamptonshire',52)/
INSERT INTO Region VALUES(480,'NK','Norfolk',52)/
INSERT INTO Region VALUES(481,'NR','Nairnshire',52)/
INSERT INTO Region VALUES(482,'NT','Nottinghamshire',52)/
INSERT INTO Region VALUES(483,'NU','Northumberland',52)/
INSERT INTO Region VALUES(484,'OR','Orkney',52)/
INSERT INTO Region VALUES(485,'OX','Oxfordshire',52)/
INSERT INTO Region VALUES(486,'PE','Peeblesshire',52)/
INSERT INTO Region VALUES(487,'PM','Pembrokeshire',52)/
INSERT INTO Region VALUES(488,'PR','Perthshire',52)/
INSERT INTO Region VALUES(489,'RA','Radnorshire',52)/
INSERT INTO Region VALUES(490,'RE','Renfrewshire',52)/
INSERT INTO Region VALUES(491,'RO','Ross-shire',52)/
INSERT INTO Region VALUES(492,'RU','Rutland',52)/
INSERT INTO Region VALUES(493,'RX','Roxburghshire',52)/
INSERT INTO Region VALUES(494,'SE','East Sussex',52)/
INSERT INTO Region VALUES(495,'SF','Selkirkshire',52)/
INSERT INTO Region VALUES(496,'SG','South Glamorgan',52)/
INSERT INTO Region VALUES(497,'SH','Shropshire',52)/
INSERT INTO Region VALUES(498,'SK','Suffolk',52)/
INSERT INTO Region VALUES(499,'SL','Shetland',52)/
INSERT INTO Region VALUES(500,'SO','Somerset',52)/
INSERT INTO Region VALUES(501,'ST','Staffordshire',52)/
INSERT INTO Region VALUES(502,'SU','Sutherland',52)/
INSERT INTO Region VALUES(503,'SV','Stirlingshire',52)/
INSERT INTO Region VALUES(504,'SW','West Sussex',52)/
INSERT INTO Region VALUES(505,'SX','Sussex',52)/
INSERT INTO Region VALUES(506,'SY','Surrey',52)/
INSERT INTO Region VALUES(507,'TY','Tyrone',52)/
INSERT INTO Region VALUES(508,'WA','Warwickshire',52)/
INSERT INTO Region VALUES(509,'WC','Worcestershire',52)/
INSERT INTO Region VALUES(510,'WE','Westmorland',52)/
INSERT INTO Region VALUES(511,'WG','West Glamorgan',52)/
INSERT INTO Region VALUES(512,'WI','Wiltshire',52)/
INSERT INTO Region VALUES(513,'WK','West Lothian',52)/
INSERT INTO Region VALUES(514,'WT','Wigtownshire',52)/
INSERT INTO Region VALUES(515,'YN','North Yorkshire',52)/
INSERT INTO Region VALUES(516,'YO','Yorkshire',52)/
INSERT INTO Region VALUES(517,'YS','South Yorkshire',52)/
INSERT INTO Region VALUES(518,'YW','West Yorkshire',52)/
INSERT INTO Region VALUES(519,'1','Aitolia kai Akarnan.',16)/
INSERT INTO Region VALUES(520,'10','Evros',16)/
INSERT INTO Region VALUES(521,'11','Evvoia',16)/
INSERT INTO Region VALUES(522,'12','Florina',16)/
INSERT INTO Region VALUES(523,'13','Fokis',16)/
INSERT INTO Region VALUES(524,'14','Fthiotis',16)/
INSERT INTO Region VALUES(525,'15','Grevena',16)/
INSERT INTO Region VALUES(526,'16','Ilia',16)/
INSERT INTO Region VALUES(527,'17','Imathia',16)/
INSERT INTO Region VALUES(528,'18','Ioannina',16)/
INSERT INTO Region VALUES(529,'19','Iraklion',16)/
INSERT INTO Region VALUES(530,'2','Akhaia',16)/
INSERT INTO Region VALUES(531,'20','Kardhitsa',16)/
INSERT INTO Region VALUES(532,'21','Kastoria',16)/
INSERT INTO Region VALUES(533,'22','Kavala',16)/
INSERT INTO Region VALUES(534,'23','Kefallinia',16)/
INSERT INTO Region VALUES(535,'24','Kerkira',16)/
INSERT INTO Region VALUES(536,'25','Khalkidhiki',16)/
INSERT INTO Region VALUES(537,'26','Khania',16)/
INSERT INTO Region VALUES(538,'27','Khios',16)/
INSERT INTO Region VALUES(539,'28','Kikladhes',16)/
INSERT INTO Region VALUES(540,'29','Kilkis',16)/
INSERT INTO Region VALUES(541,'3','Argolis',16)/
INSERT INTO Region VALUES(542,'30','Korinthia',16)/
INSERT INTO Region VALUES(543,'31','Kozani',16)/
INSERT INTO Region VALUES(544,'32','Lakonia',16)/
INSERT INTO Region VALUES(545,'33','Larisa',16)/
INSERT INTO Region VALUES(546,'34','Lasithi',16)/
INSERT INTO Region VALUES(547,'35','Lesvos',16)/
INSERT INTO Region VALUES(548,'36','Levkas',16)/
INSERT INTO Region VALUES(549,'37','Magnisia',16)/
INSERT INTO Region VALUES(550,'38','Messinia',16)/
INSERT INTO Region VALUES(551,'39','Pella',16)/
INSERT INTO Region VALUES(552,'4','Arkadhia',16)/
INSERT INTO Region VALUES(553,'40','Pieria',16)/
INSERT INTO Region VALUES(554,'41','Piraievs',16)/
INSERT INTO Region VALUES(555,'42','Preveza',16)/
INSERT INTO Region VALUES(556,'43','Rethimni',16)/
INSERT INTO Region VALUES(557,'44','Rodhopi',16)/
INSERT INTO Region VALUES(558,'45','Samos',16)/
INSERT INTO Region VALUES(559,'46','Serrai',16)/
INSERT INTO Region VALUES(560,'47','Thesprotia',16)/
INSERT INTO Region VALUES(561,'48','Thessaloniki',16)/
INSERT INTO Region VALUES(562,'49','Trikala',16)/
INSERT INTO Region VALUES(563,'5','Arta',16)/
INSERT INTO Region VALUES(564,'50','Voiotia',16)/
INSERT INTO Region VALUES(565,'51','Xanthi',16)/
INSERT INTO Region VALUES(566,'52','Zakinthos',16)/
INSERT INTO Region VALUES(567,'6','Attiki',16)/
INSERT INTO Region VALUES(568,'7','Dhodhekanisos',16)/
INSERT INTO Region VALUES(569,'8','Dhrama',16)/
INSERT INTO Region VALUES(570,'9','Evritania',16)/
INSERT INTO Region VALUES(571,'HK','Hong Kong Island',18)/
INSERT INTO Region VALUES(572,'KLN','Kowloon',18)/
INSERT INTO Region VALUES(573,'NT','New Territories',18)/
INSERT INTO Region VALUES(574,'A00','Zagrebacka',62)/
INSERT INTO Region VALUES(575,'B00','Krapinsko-zagorska',62)/
INSERT INTO Region VALUES(576,'C00','Sisacko-moslavacka',62)/
INSERT INTO Region VALUES(577,'D00','Karlovacka',62)/
INSERT INTO Region VALUES(578,'E00','Varazdinska',62)/
INSERT INTO Region VALUES(579,'F00','Koprivnicko-krizevac',62)/
INSERT INTO Region VALUES(580,'G00','Bjelovarsko-bilogors',62)/
INSERT INTO Region VALUES(581,'H00','Rijecko-goranska',62)/
INSERT INTO Region VALUES(582,'I00','Licko-senjska',62)/
INSERT INTO Region VALUES(583,'J00','Viroviticko-podravac',62)/
INSERT INTO Region VALUES(584,'K00','Pozesko-slavonska',62)/
INSERT INTO Region VALUES(585,'L00','Slavonskobrodska',62)/
INSERT INTO Region VALUES(586,'M00','Zadarska',62)/
INSERT INTO Region VALUES(587,'N00','Osjecko-baranjska',62)/
INSERT INTO Region VALUES(588,'O00','Sibensko-kninska',62)/
INSERT INTO Region VALUES(589,'P00','Vukovarsko-srijemska',62)/
INSERT INTO Region VALUES(590,'R00','Splitsko-dalmatinska',62)/
INSERT INTO Region VALUES(591,'S00','Istarska',62)/
INSERT INTO Region VALUES(592,'T00','Dubrovacko-neretvans',62)/
INSERT INTO Region VALUES(593,'U00','Medjimurska',62)/
INSERT INTO Region VALUES(594,'V00','Zagreb',62)/
INSERT INTO Region VALUES(595,'1','Bacs-Kiskun',19)/
INSERT INTO Region VALUES(596,'10','Eger',19)/
INSERT INTO Region VALUES(597,'11','Fejer',19)/
INSERT INTO Region VALUES(598,'12','Gyor',19)/
INSERT INTO Region VALUES(599,'13','Gyor-Moson-Sopron',19)/
INSERT INTO Region VALUES(600,'14','Hajdu-Bihar',19)/
INSERT INTO Region VALUES(601,'15','Heves',19)/
INSERT INTO Region VALUES(602,'16','Hodmezovasarhely',19)/
INSERT INTO Region VALUES(603,'17','Jasz-Nagykun-Szolnok',19)/
INSERT INTO Region VALUES(604,'18','Kaposvar',19)/
INSERT INTO Region VALUES(605,'19','Kecskemet',19)/
INSERT INTO Region VALUES(606,'2','Baranya',19)/
INSERT INTO Region VALUES(607,'20','Komarom-Esztergom',19)/
INSERT INTO Region VALUES(608,'21','Miskolc',19)/
INSERT INTO Region VALUES(609,'22','Nagykanizsa',19)/
INSERT INTO Region VALUES(610,'23','Nograd',19)/
INSERT INTO Region VALUES(611,'24','Nyiregyhaza',19)/
INSERT INTO Region VALUES(612,'25','Pecs',19)/
INSERT INTO Region VALUES(613,'26','Pest',19)/
INSERT INTO Region VALUES(614,'27','Somogy',19)/
INSERT INTO Region VALUES(615,'28','Sopron',19)/
INSERT INTO Region VALUES(616,'29','Szabolcs-Szat.-Bereg',19)/
INSERT INTO Region VALUES(617,'3','Bekes',19)/
INSERT INTO Region VALUES(618,'30','Szeged',19)/
INSERT INTO Region VALUES(619,'31','Szekesfehervar',19)/
INSERT INTO Region VALUES(620,'32','Szolnok',19)/
INSERT INTO Region VALUES(621,'33','Szombathely',19)/
INSERT INTO Region VALUES(622,'34','Tatabanya',19)/
INSERT INTO Region VALUES(623,'35','Tolna',19)/
INSERT INTO Region VALUES(624,'36','Vas',19)/
INSERT INTO Region VALUES(625,'37','Veszprem',19)/
INSERT INTO Region VALUES(626,'38','Zala',19)/
INSERT INTO Region VALUES(627,'39','Zalaegerszeg',19)/
INSERT INTO Region VALUES(628,'4','Bekescsaba',19)/
INSERT INTO Region VALUES(629,'5','Borsod-Abauj-Zemplen',19)/
INSERT INTO Region VALUES(630,'6','Budapest',19)/
INSERT INTO Region VALUES(631,'7','Csongrad',19)/
INSERT INTO Region VALUES(632,'8','Debrecen',19)/
INSERT INTO Region VALUES(633,'9','Dunaujvaros',19)/
INSERT INTO Region VALUES(634,'1','DKI Jakarta Jakarta',21)/
INSERT INTO Region VALUES(635,'10','Jambi Jambi',21)/
INSERT INTO Region VALUES(636,'11','Sumatera Selatan Sou',21)/
INSERT INTO Region VALUES(637,'12','Bengkulu Bengkulu',21)/
INSERT INTO Region VALUES(638,'13','Lampung Lampung',21)/
INSERT INTO Region VALUES(639,'14','Kalimantan Selatan S',21)/
INSERT INTO Region VALUES(640,'15','Kalimantan Barat Wes',21)/
INSERT INTO Region VALUES(641,'16','Kalimantan Tengah Ce',21)/
INSERT INTO Region VALUES(642,'17','Kalimantan Timur Eas',21)/
INSERT INTO Region VALUES(643,'18','Sulawesi Selatan Sou',21)/
INSERT INTO Region VALUES(644,'19','Sulawesi Tenggara So',21)/
INSERT INTO Region VALUES(645,'2','Jawa Barat West Java',21)/
INSERT INTO Region VALUES(646,'20','Sulawesi Tengah Cent',21)/
INSERT INTO Region VALUES(647,'21','Sulawesi Utara North',21)/
INSERT INTO Region VALUES(648,'22','Bali Bali',21)/
INSERT INTO Region VALUES(649,'23','Nusa Tenggara Barat',21)/
INSERT INTO Region VALUES(650,'24','Nusa Tenggara Timur',21)/
INSERT INTO Region VALUES(651,'25','Maluku Maluku',21)/
INSERT INTO Region VALUES(652,'26','Irian Jaya Irian Jay',21)/
INSERT INTO Region VALUES(653,'27','Timor Timur East Tim',21)/
INSERT INTO Region VALUES(654,'3','Jawa Tengah Central',21)/
INSERT INTO Region VALUES(655,'4','Jawa Timur East Java',21)/
INSERT INTO Region VALUES(656,'5','DI Yogyakarta Yogyak',21)/
INSERT INTO Region VALUES(657,'6','DI Aceh Aceh',21)/
INSERT INTO Region VALUES(658,'7','Sumatera Utara North',21)/
INSERT INTO Region VALUES(659,'8','Sumatera Barat West',21)/
INSERT INTO Region VALUES(660,'9','Riau Riau',21)/
INSERT INTO Region VALUES(661,'CK','Cork',22)/
INSERT INTO Region VALUES(662,'CL','Clare',22)/
INSERT INTO Region VALUES(663,'CV','Cavan',22)/
INSERT INTO Region VALUES(664,'CW','Carlow',22)/
INSERT INTO Region VALUES(665,'DB','Dublin',22)/
INSERT INTO Region VALUES(666,'DG','Donegal',22)/
INSERT INTO Region VALUES(667,'GW','Galway',22)/
INSERT INTO Region VALUES(668,'KD','Kildare',22)/
INSERT INTO Region VALUES(669,'KK','Kilkenny',22)/
INSERT INTO Region VALUES(670,'KY','Kerry',22)/
INSERT INTO Region VALUES(671,'LF','Longford',22)/
INSERT INTO Region VALUES(672,'LI','Limerick',22)/
INSERT INTO Region VALUES(673,'LM','Leitrim',22)/
INSERT INTO Region VALUES(674,'LS','Laois',22)/
INSERT INTO Region VALUES(675,'LT','Louth',22)/
INSERT INTO Region VALUES(676,'MH','Monaghan',22)/
INSERT INTO Region VALUES(677,'MT','Meath',22)/
INSERT INTO Region VALUES(678,'MY','Mayo',22)/
INSERT INTO Region VALUES(679,'OF','Offaly',22)/
INSERT INTO Region VALUES(680,'RC','Rosscommon',22)/
INSERT INTO Region VALUES(681,'SG','Sligo',22)/
INSERT INTO Region VALUES(682,'TP','Tipperary',22)/
INSERT INTO Region VALUES(683,'WF','Waterford',22)/
INSERT INTO Region VALUES(684,'WK','Wicklow',22)/
INSERT INTO Region VALUES(685,'WM','Westmeath',22)/
INSERT INTO Region VALUES(686,'WX','Wexford',22)/
INSERT INTO Region VALUES(687,'1','Central',23)/
INSERT INTO Region VALUES(688,'2','Haifa',23)/
INSERT INTO Region VALUES(689,'3','Jerusalem',23)/
INSERT INTO Region VALUES(690,'4','Northern',23)/
INSERT INTO Region VALUES(691,'5','Southern',23)/
INSERT INTO Region VALUES(692,'6','Tel Aviv',23)/
INSERT INTO Region VALUES(693,'1','Andra Pradesh',20)/
INSERT INTO Region VALUES(694,'10','Karnataka',20)/
INSERT INTO Region VALUES(695,'11','Kerala',20)/
INSERT INTO Region VALUES(696,'12','Madhya Pradesh',20)/
INSERT INTO Region VALUES(697,'13','Maharashtra',20)/
INSERT INTO Region VALUES(698,'14','Manipur',20)/
INSERT INTO Region VALUES(699,'15','Megalaya',20)/
INSERT INTO Region VALUES(700,'16','Mizoram',20)/
INSERT INTO Region VALUES(701,'17','Nagaland',20)/
INSERT INTO Region VALUES(702,'18','Orissa',20)/
INSERT INTO Region VALUES(703,'19','Punjab',20)/
INSERT INTO Region VALUES(704,'2','Arunachal Pradesh',20)/
INSERT INTO Region VALUES(705,'20','Rajasthan',20)/
INSERT INTO Region VALUES(706,'21','Sikkim',20)/
INSERT INTO Region VALUES(707,'22','Tamil Nadu',20)/
INSERT INTO Region VALUES(708,'23','Tripura',20)/
INSERT INTO Region VALUES(709,'24','Uttar Pradesh',20)/
INSERT INTO Region VALUES(710,'25','West Bengal',20)/
INSERT INTO Region VALUES(711,'26','Andaman and Nico.In.',20)/
INSERT INTO Region VALUES(712,'27','Chandigarh',20)/
INSERT INTO Region VALUES(713,'28','Dadra and Nagar Hav.',20)/
INSERT INTO Region VALUES(714,'29','Daman and Diu',20)/
INSERT INTO Region VALUES(715,'3','Assam',20)/
INSERT INTO Region VALUES(716,'30','Delhi',20)/
INSERT INTO Region VALUES(717,'31','Lakshadweep',20)/
INSERT INTO Region VALUES(718,'32','Pondicherry',20)/
INSERT INTO Region VALUES(719,'33','Chhaattisgarh',20)/
INSERT INTO Region VALUES(720,'34','Jharkhand',20)/
INSERT INTO Region VALUES(721,'35','Uttaranchal',20)/
INSERT INTO Region VALUES(722,'4','Bihar',20)/
INSERT INTO Region VALUES(723,'5','Goa',20)/
INSERT INTO Region VALUES(724,'6','Gujarat',20)/
INSERT INTO Region VALUES(725,'7','Haryana',20)/
INSERT INTO Region VALUES(726,'8','Himachal Pradesh',20)/
INSERT INTO Region VALUES(727,'9','Jammu and Kashmir',20)/
INSERT INTO Region VALUES(728,'AG','Agriento',24)/
INSERT INTO Region VALUES(729,'AL','Alessandria',24)/
INSERT INTO Region VALUES(730,'AN','Ancona',24)/
INSERT INTO Region VALUES(731,'AO','Aosta',24)/
INSERT INTO Region VALUES(732,'AP','Ascoli Piceno',24)/
INSERT INTO Region VALUES(733,'AQ','LAquila',24)/
INSERT INTO Region VALUES(734,'AR','Arezzo',24)/
INSERT INTO Region VALUES(735,'AT','Asti',24)/
INSERT INTO Region VALUES(736,'AV','Avellino',24)/
INSERT INTO Region VALUES(737,'BA','Bari',24)/
INSERT INTO Region VALUES(738,'BG','Bergamo',24)/
INSERT INTO Region VALUES(739,'BI','Biella',24)/
INSERT INTO Region VALUES(740,'BL','Belluno',24)/
INSERT INTO Region VALUES(741,'BN','Benevento',24)/
INSERT INTO Region VALUES(742,'BO','Bologna',24)/
INSERT INTO Region VALUES(743,'BR','Brindisi',24)/
INSERT INTO Region VALUES(744,'BS','Brescia',24)/
INSERT INTO Region VALUES(745,'BZ','Bolzano',24)/
INSERT INTO Region VALUES(746,'CA','Cagliari',24)/
INSERT INTO Region VALUES(747,'CB','Campobasso',24)/
INSERT INTO Region VALUES(748,'CE','Caserta',24)/
INSERT INTO Region VALUES(749,'CH','Chieti',24)/
INSERT INTO Region VALUES(750,'CI','Carbonia-Iglesias',24)/
INSERT INTO Region VALUES(751,'CL','Caltanisetta',24)/
INSERT INTO Region VALUES(752,'CN','Cuneo',24)/
INSERT INTO Region VALUES(753,'CO','Como',24)/
INSERT INTO Region VALUES(754,'CR','Cremona',24)/
INSERT INTO Region VALUES(755,'CS','Cosenza',24)/
INSERT INTO Region VALUES(756,'CT','Catania',24)/
INSERT INTO Region VALUES(757,'CZ','Catanzaro',24)/
INSERT INTO Region VALUES(758,'EE','Stati Esteri',24)/
INSERT INTO Region VALUES(759,'EN','Enna',24)/
INSERT INTO Region VALUES(760,'FC','Forli/Cesana',24)/
INSERT INTO Region VALUES(761,'FE','Ferrara',24)/
INSERT INTO Region VALUES(762,'FG','Foggia',24)/
INSERT INTO Region VALUES(763,'FI','Florence',24)/
INSERT INTO Region VALUES(764,'FO','Forlì',24)/
INSERT INTO Region VALUES(765,'FR','Frosinone',24)/
INSERT INTO Region VALUES(766,'FU','Fiume',24)/
INSERT INTO Region VALUES(767,'GE','Genova',24)/
INSERT INTO Region VALUES(768,'GO','Gorizia',24)/
INSERT INTO Region VALUES(769,'GR','Grosseto',24)/
INSERT INTO Region VALUES(770,'IM','Imperia',24)/
INSERT INTO Region VALUES(771,'IS','Isernia',24)/
INSERT INTO Region VALUES(772,'KR','Crotone',24)/
INSERT INTO Region VALUES(773,'LC','Lecco',24)/
INSERT INTO Region VALUES(774,'LE','Lecce',24)/
INSERT INTO Region VALUES(775,'LI','Livorno',24)/
INSERT INTO Region VALUES(776,'LO','Lodi',24)/
INSERT INTO Region VALUES(777,'LT','Latina',24)/
INSERT INTO Region VALUES(778,'LU','Lucca',24)/
INSERT INTO Region VALUES(779,'MB','Monza e Brianza',24)/
INSERT INTO Region VALUES(780,'MC','Macerata',24)/
INSERT INTO Region VALUES(781,'MD','Medio Campidano',24)/
INSERT INTO Region VALUES(782,'ME','Messina',24)/
INSERT INTO Region VALUES(783,'MI','Milan',24)/
INSERT INTO Region VALUES(784,'MN','Mantova',24)/
INSERT INTO Region VALUES(785,'MO','Modena',24)/
INSERT INTO Region VALUES(786,'MS','Massa Carrara',24)/
INSERT INTO Region VALUES(787,'MT','Matera',24)/
INSERT INTO Region VALUES(788,'NA','Naples',24)/
INSERT INTO Region VALUES(789,'NO','Novara',24)/
INSERT INTO Region VALUES(790,'NU','Nuoro',24)/
INSERT INTO Region VALUES(791,'OG','Ogliastra',24)/
INSERT INTO Region VALUES(792,'OR','Oristano',24)/
INSERT INTO Region VALUES(793,'OT','Olbia-Tempio',24)/
INSERT INTO Region VALUES(794,'PA','Palermo',24)/
INSERT INTO Region VALUES(795,'PC','Piacenza',24)/
INSERT INTO Region VALUES(796,'PD','Padova',24)/
INSERT INTO Region VALUES(797,'PE','Pescara',24)/
INSERT INTO Region VALUES(798,'PG','Perugia',24)/
INSERT INTO Region VALUES(799,'PI','Pisa',24)/
INSERT INTO Region VALUES(800,'PL','Pola',24)/
INSERT INTO Region VALUES(801,'PN','Pordenone',24)/
INSERT INTO Region VALUES(802,'PO','Prato',24)/
INSERT INTO Region VALUES(803,'PR','Parma',24)/
INSERT INTO Region VALUES(804,'PS','Pesaro',24)/
INSERT INTO Region VALUES(805,'PT','Pistoia',24)/
INSERT INTO Region VALUES(806,'PU','Pesaro-Urbino',24)/
INSERT INTO Region VALUES(807,'PV','Pavia',24)/
INSERT INTO Region VALUES(808,'PZ','Potenza',24)/
INSERT INTO Region VALUES(809,'RA','Ravenna',24)/
INSERT INTO Region VALUES(810,'RC','Reggio Calabria',24)/
INSERT INTO Region VALUES(811,'RE','Reggio Emilia',24)/
INSERT INTO Region VALUES(812,'RG','Ragusa',24)/
INSERT INTO Region VALUES(813,'RI','Rieti',24)/
INSERT INTO Region VALUES(814,'RM','Rome',24)/
INSERT INTO Region VALUES(815,'RN','Rimini',24)/
INSERT INTO Region VALUES(816,'RO','Rovigo',24)/
INSERT INTO Region VALUES(817,'RV','Rovigo',24)/
INSERT INTO Region VALUES(818,'SA','Salerno',24)/
INSERT INTO Region VALUES(819,'SI','Siena',24)/
INSERT INTO Region VALUES(820,'SO','Sondrio',24)/
INSERT INTO Region VALUES(821,'SP','La Spezia',24)/
INSERT INTO Region VALUES(822,'SR','Siracusa',24)/
INSERT INTO Region VALUES(823,'SS','Sassari',24)/
INSERT INTO Region VALUES(824,'SV','Savona',24)/
INSERT INTO Region VALUES(825,'TA','Taranto',24)/
INSERT INTO Region VALUES(826,'TE','Teramo',24)/
INSERT INTO Region VALUES(827,'TN','Trento',24)/
INSERT INTO Region VALUES(828,'TO','Turin',24)/
INSERT INTO Region VALUES(829,'TP','Trapani',24)/
INSERT INTO Region VALUES(830,'TR','Terni',24)/
INSERT INTO Region VALUES(831,'TS','Trieste',24)/
INSERT INTO Region VALUES(832,'TV','Treviso',24)/
INSERT INTO Region VALUES(833,'UD','Udine',24)/
INSERT INTO Region VALUES(834,'VA','Varese',24)/
INSERT INTO Region VALUES(835,'VB','Verbania',24)/
INSERT INTO Region VALUES(836,'VC','Vercelli',24)/
INSERT INTO Region VALUES(837,'VE','Venice',24)/
INSERT INTO Region VALUES(838,'VI','Vicenza',24)/
INSERT INTO Region VALUES(839,'VR','Verona',24)/
INSERT INTO Region VALUES(840,'VS','Medio Campidano',24)/
INSERT INTO Region VALUES(841,'VT','Viterbo',24)/
INSERT INTO Region VALUES(842,'VV','Vibo Valentia',24)/
INSERT INTO Region VALUES(843,'ZA','Zara',24)/
INSERT INTO Region VALUES(844,'1','Kingston',69)/
INSERT INTO Region VALUES(845,'10','Westmoreland',69)/
INSERT INTO Region VALUES(846,'11','Saint Elizabeth',69)/
INSERT INTO Region VALUES(847,'12','Manchester',69)/
INSERT INTO Region VALUES(848,'13','Clarendon',69)/
INSERT INTO Region VALUES(849,'14','Saint Catherine',69)/
INSERT INTO Region VALUES(850,'2','Saint Andrew',69)/
INSERT INTO Region VALUES(851,'3','Saint Thomea',69)/
INSERT INTO Region VALUES(852,'4','Portland',69)/
INSERT INTO Region VALUES(853,'5','Saint Mary',69)/
INSERT INTO Region VALUES(854,'6','Saint Ann',69)/
INSERT INTO Region VALUES(855,'7','Trelawny',69)/
INSERT INTO Region VALUES(856,'8','Saint James',69)/
INSERT INTO Region VALUES(857,'9','Hanover',69)/
INSERT INTO Region VALUES(858,'1','Hokkaido',25)/
INSERT INTO Region VALUES(859,'10','Gunma',25)/
INSERT INTO Region VALUES(860,'11','Saitama',25)/
INSERT INTO Region VALUES(861,'12','Chiba',25)/
INSERT INTO Region VALUES(862,'13','Tokyo',25)/
INSERT INTO Region VALUES(863,'14','Kanagawa',25)/
INSERT INTO Region VALUES(864,'15','Niigata',25)/
INSERT INTO Region VALUES(865,'16','Toyama',25)/
INSERT INTO Region VALUES(866,'17','Ishikawa',25)/
INSERT INTO Region VALUES(867,'18','Fukui',25)/
INSERT INTO Region VALUES(868,'19','Yamanashi',25)/
INSERT INTO Region VALUES(869,'2','Aomori',25)/
INSERT INTO Region VALUES(870,'20','Nagano',25)/
INSERT INTO Region VALUES(871,'21','Gifu',25)/
INSERT INTO Region VALUES(872,'22','Shizuoka',25)/
INSERT INTO Region VALUES(873,'23','Aichi',25)/
INSERT INTO Region VALUES(874,'24','Mie',25)/
INSERT INTO Region VALUES(875,'25','Shiga',25)/
INSERT INTO Region VALUES(876,'26','Kyoto',25)/
INSERT INTO Region VALUES(877,'27','Osaka',25)/
INSERT INTO Region VALUES(878,'28','Hyogo',25)/
INSERT INTO Region VALUES(879,'29','Nara',25)/
INSERT INTO Region VALUES(880,'3','Iwate',25)/
INSERT INTO Region VALUES(881,'30','Wakayama',25)/
INSERT INTO Region VALUES(882,'31','Tottori',25)/
INSERT INTO Region VALUES(883,'32','Shimane',25)/
INSERT INTO Region VALUES(884,'33','Okayama',25)/
INSERT INTO Region VALUES(885,'34','Hiroshima',25)/
INSERT INTO Region VALUES(886,'35','Yamaguchi',25)/
INSERT INTO Region VALUES(887,'36','Tokushima',25)/
INSERT INTO Region VALUES(888,'37','Kagawa',25)/
INSERT INTO Region VALUES(889,'38','Ehime',25)/
INSERT INTO Region VALUES(890,'39','Kochi',25)/
INSERT INTO Region VALUES(891,'4','Miyagi',25)/
INSERT INTO Region VALUES(892,'40','Fukuoka',25)/
INSERT INTO Region VALUES(893,'41','Saga',25)/
INSERT INTO Region VALUES(894,'42','Nagasaki',25)/
INSERT INTO Region VALUES(895,'43','Kumamoto',25)/
INSERT INTO Region VALUES(896,'44','Oita',25)/
INSERT INTO Region VALUES(897,'45','Miyazaki',25)/
INSERT INTO Region VALUES(898,'46','Kagoshima',25)/
INSERT INTO Region VALUES(899,'47','Okinawa',25)/
INSERT INTO Region VALUES(900,'5','Akita',25)/
INSERT INTO Region VALUES(901,'6','Yamagata',25)/
INSERT INTO Region VALUES(902,'7','Fukushima',25)/
INSERT INTO Region VALUES(903,'8','Ibaraki',25)/
INSERT INTO Region VALUES(904,'9','Tochigi',25)/
INSERT INTO Region VALUES(905,'1','Cheju-do',44)/
INSERT INTO Region VALUES(906,'10','Kyongsang-bukto',44)/
INSERT INTO Region VALUES(907,'11','Kyongsang-namdo',44)/
INSERT INTO Region VALUES(908,'12','Pusan-jikhalsi',44)/
INSERT INTO Region VALUES(909,'13','Soul-t''ukpyolsi',44)/
INSERT INTO Region VALUES(910,'14','Taegu-jikhalsi',44)/
INSERT INTO Region VALUES(911,'15','Taejon-jikhalsi',44)/
INSERT INTO Region VALUES(912,'2','Cholla-bukto',44)/
INSERT INTO Region VALUES(913,'3','Cholla-namdo',44)/
INSERT INTO Region VALUES(914,'4','Ch''ungch''ong-bukto',44)/
INSERT INTO Region VALUES(915,'5','Ch''ungch''ong-namdo',44)/
INSERT INTO Region VALUES(916,'6','Inch''on-jikhalsi',44)/
INSERT INTO Region VALUES(917,'7','Kangwon-do',44)/
INSERT INTO Region VALUES(918,'8','Kwangju-jikhalsi',44)/
INSERT INTO Region VALUES(919,'9','Kyonggi-do',44)/
INSERT INTO Region VALUES(920,'0','Almatynskaia',71)/
INSERT INTO Region VALUES(921,'1','Kostanaiskaia',71)/
INSERT INTO Region VALUES(922,'10','Vostochno-Kazakhstan',71)/
INSERT INTO Region VALUES(923,'11','Gambilskaia',71)/
INSERT INTO Region VALUES(924,'12','Kyzilordinskaia',71)/
INSERT INTO Region VALUES(925,'2','Severo-Kazakhstansk',71)/
INSERT INTO Region VALUES(926,'3','Pavlodarskaia',71)/
INSERT INTO Region VALUES(927,'4','Akmolinskaia',71)/
INSERT INTO Region VALUES(928,'5','Aktubinskaia',71)/
INSERT INTO Region VALUES(929,'6','Atyrauskaia',71)/
INSERT INTO Region VALUES(930,'7','Zapadno-Kazakhst',71)/
INSERT INTO Region VALUES(931,'8','Mangystayskaia',71)/
INSERT INTO Region VALUES(932,'9','Karagandinskaia',71)/
INSERT INTO Region VALUES(933,'AGS','Aguascalientes',29)/
INSERT INTO Region VALUES(934,'BC','Baja California',29)/
INSERT INTO Region VALUES(935,'BCS','Baja California S',29)/
INSERT INTO Region VALUES(936,'CHI','Chihuahua',29)/
INSERT INTO Region VALUES(937,'CHS','Chiapas',29)/
INSERT INTO Region VALUES(938,'CMP','Campeche',29)/
INSERT INTO Region VALUES(939,'COA','Coahuila',29)/
INSERT INTO Region VALUES(940,'COL','Colima',29)/
INSERT INTO Region VALUES(941,'DF','Distrito Federal',29)/
INSERT INTO Region VALUES(942,'DGO','Durango',29)/
INSERT INTO Region VALUES(943,'GRO','Guerrero',29)/
INSERT INTO Region VALUES(944,'GTO','Guanajuato',29)/
INSERT INTO Region VALUES(945,'HGO','Hidalgo',29)/
INSERT INTO Region VALUES(946,'JAL','Jalisco',29)/
INSERT INTO Region VALUES(947,'MCH','Michoacan',29)/
INSERT INTO Region VALUES(948,'MEX','Estado de Mexico',29)/
INSERT INTO Region VALUES(949,'MOR','Morelos',29)/
INSERT INTO Region VALUES(950,'NAY','Nayarit',29)/
INSERT INTO Region VALUES(951,'NL','Nuevo Leon',29)/
INSERT INTO Region VALUES(952,'OAX','Oaxaca',29)/
INSERT INTO Region VALUES(953,'PUE','Puebla',29)/
INSERT INTO Region VALUES(954,'QR','Quintana Roo',29)/
INSERT INTO Region VALUES(955,'QRO','Queretaro',29)/
INSERT INTO Region VALUES(956,'SIN','Sinaloa',29)/
INSERT INTO Region VALUES(957,'SLP','San Luis Potosi',29)/
INSERT INTO Region VALUES(958,'SON','Sonora',29)/
INSERT INTO Region VALUES(959,'TAB','Tabasco',29)/
INSERT INTO Region VALUES(960,'TLX','Tlaxcala',29)/
INSERT INTO Region VALUES(961,'TMS','Tamaulipas',29)/
INSERT INTO Region VALUES(962,'VER','Veracruz',29)/
INSERT INTO Region VALUES(963,'YUC','Yucatan',29)/
INSERT INTO Region VALUES(964,'ZAC','Zacatecas',29)/
INSERT INTO Region VALUES(965,'JOH','Johor',28)/
INSERT INTO Region VALUES(966,'KED','Kedah',28)/
INSERT INTO Region VALUES(967,'KEL','Kelantan',28)/
INSERT INTO Region VALUES(968,'KUL','Kuala Lumpur',28)/
INSERT INTO Region VALUES(969,'LAB','Labuan',28)/
INSERT INTO Region VALUES(970,'MEL','Melaka',28)/
INSERT INTO Region VALUES(971,'PAH','Pahang',28)/
INSERT INTO Region VALUES(972,'PEL','Perlis',28)/
INSERT INTO Region VALUES(973,'PER','Perak',28)/
INSERT INTO Region VALUES(974,'PIN','Pulau Pinang',28)/
INSERT INTO Region VALUES(975,'PSK','Wil. Persekutuan',28)/
INSERT INTO Region VALUES(976,'SAB','Sabah',28)/
INSERT INTO Region VALUES(977,'SAR','Sarawak',28)/
INSERT INTO Region VALUES(978,'SEL','Selangor',28)/
INSERT INTO Region VALUES(979,'SER','Negeri Sembilan',28)/
INSERT INTO Region VALUES(980,'TRE','Trengganu',28)/
INSERT INTO Region VALUES(981,'1','Drenthe',17)/
INSERT INTO Region VALUES(982,'10','Utrecht',17)/
INSERT INTO Region VALUES(983,'11','Zeeland',17)/
INSERT INTO Region VALUES(984,'12','Zuid-Holland',17)/
INSERT INTO Region VALUES(985,'2','Flevoland',17)/
INSERT INTO Region VALUES(986,'3','Friesland',17)/
INSERT INTO Region VALUES(987,'4','Gelderland',17)/
INSERT INTO Region VALUES(988,'5','Groningen',17)/
INSERT INTO Region VALUES(989,'6','Limburg',17)/
INSERT INTO Region VALUES(990,'7','Noord-Brabant',17)/
INSERT INTO Region VALUES(991,'8','Noord-Holland',17)/
INSERT INTO Region VALUES(992,'9','Overijssel',17)/
INSERT INTO Region VALUES(993,'1','Ostfold County',33)/
INSERT INTO Region VALUES(994,'10','Vest-Agder County',33)/
INSERT INTO Region VALUES(995,'11','Rogaland County',33)/
INSERT INTO Region VALUES(996,'12','Hordaland County',33)/
INSERT INTO Region VALUES(997,'14','Sogn og Fjordane C.',33)/
INSERT INTO Region VALUES(998,'15','More og Romsdal C.',33)/
INSERT INTO Region VALUES(999,'16','Sor-Trondelag County',33)/
INSERT INTO Region VALUES(1000,'17','Nord-Trondelag Cnty',33)/
INSERT INTO Region VALUES(1001,'18','Nordland County',33)/
INSERT INTO Region VALUES(1002,'19','Troms County',33)/
INSERT INTO Region VALUES(1003,'2','Akershus County',33)/
INSERT INTO Region VALUES(1004,'20','Finnmark County',33)/
INSERT INTO Region VALUES(1005,'3','Oslo',33)/
INSERT INTO Region VALUES(1006,'4','Hedmark County',33)/
INSERT INTO Region VALUES(1007,'5','Oppland County',33)/
INSERT INTO Region VALUES(1008,'6','Buskerud County',33)/
INSERT INTO Region VALUES(1009,'7','Vestfold County',33)/
INSERT INTO Region VALUES(1010,'8','Telemark County',33)/
INSERT INTO Region VALUES(1011,'9','Aust-Agder County',33)/
INSERT INTO Region VALUES(1012,'AKL','Auckland',31)/
INSERT INTO Region VALUES(1013,'BOP','Bay of Plenty',31)/
INSERT INTO Region VALUES(1014,'CAN','Canterbury',31)/
INSERT INTO Region VALUES(1015,'GIS','Gisborne',31)/
INSERT INTO Region VALUES(1016,'HAB','Hawke''s Bay',31)/
INSERT INTO Region VALUES(1017,'MAN','Manawatu-Wanganui',31)/
INSERT INTO Region VALUES(1018,'MBH','Marlborough',31)/
INSERT INTO Region VALUES(1019,'NSN','Nelson',31)/
INSERT INTO Region VALUES(1020,'NTL','Northland',31)/
INSERT INTO Region VALUES(1021,'OTA','Otago',31)/
INSERT INTO Region VALUES(1022,'STL','Southland',31)/
INSERT INTO Region VALUES(1023,'TAR','Taranaki',31)/
INSERT INTO Region VALUES(1024,'TAS','Tasman',31)/
INSERT INTO Region VALUES(1025,'WAI','Waikato',31)/
INSERT INTO Region VALUES(1026,'WEC','West Coast',31)/
INSERT INTO Region VALUES(1027,'WLG','Wellington',31)/
INSERT INTO Region VALUES(1028,'1','Tumbes',34)/
INSERT INTO Region VALUES(1029,'10','Tacna',34)/
INSERT INTO Region VALUES(1030,'11','Amazon',34)/
INSERT INTO Region VALUES(1031,'12','Cajamarca',34)/
INSERT INTO Region VALUES(1032,'13','San Martin',34)/
INSERT INTO Region VALUES(1033,'14','Huanuco',34)/
INSERT INTO Region VALUES(1034,'15','Pasco',34)/
INSERT INTO Region VALUES(1035,'16','Junin',34)/
INSERT INTO Region VALUES(1036,'17','Huancavelica',34)/
INSERT INTO Region VALUES(1037,'18','Ayacucho',34)/
INSERT INTO Region VALUES(1038,'19','Apurimac',34)/
INSERT INTO Region VALUES(1039,'2','Piura',34)/
INSERT INTO Region VALUES(1040,'20','Cuzco',34)/
INSERT INTO Region VALUES(1041,'21','Puno',34)/
INSERT INTO Region VALUES(1042,'22','Loreto',34)/
INSERT INTO Region VALUES(1043,'23','Ucayali',34)/
INSERT INTO Region VALUES(1044,'24','Madre de Dios',34)/
INSERT INTO Region VALUES(1045,'3','Lambayeque',34)/
INSERT INTO Region VALUES(1046,'4','La Libertad',34)/
INSERT INTO Region VALUES(1047,'5','Ancash',34)/
INSERT INTO Region VALUES(1048,'6','Lima y Callao',34)/
INSERT INTO Region VALUES(1049,'7','Ica',34)/
INSERT INTO Region VALUES(1050,'8','Arequipa',34)/
INSERT INTO Region VALUES(1051,'9','Moquegua',34)/
INSERT INTO Region VALUES(1052,'1','Ilocos',35)/
INSERT INTO Region VALUES(1053,'10','Northern Mindanao',35)/
INSERT INTO Region VALUES(1054,'11','Central Mindanao',35)/
INSERT INTO Region VALUES(1055,'12','South Mindanao',35)/
INSERT INTO Region VALUES(1056,'2','Cagayan Valley',35)/
INSERT INTO Region VALUES(1057,'3','Central Luzon',35)/
INSERT INTO Region VALUES(1058,'4','South Luzon',35)/
INSERT INTO Region VALUES(1059,'5','Bicol',35)/
INSERT INTO Region VALUES(1060,'6','West Visayas',35)/
INSERT INTO Region VALUES(1061,'7','Central Visayas',35)/
INSERT INTO Region VALUES(1062,'8','Eastern Visayas',35)/
INSERT INTO Region VALUES(1063,'9','Western Mindanao',35)/
INSERT INTO Region VALUES(1064,'DSL','Dolnoslaskie',36)/
INSERT INTO Region VALUES(1065,'K-P','Kujawsko-Pomorskie',36)/
INSERT INTO Region VALUES(1066,'LBL','Lubelskie',36)/
INSERT INTO Region VALUES(1067,'LBS','Lubuskie',36)/
INSERT INTO Region VALUES(1068,'LDZ','Lodzkie',36)/
INSERT INTO Region VALUES(1069,'MAL','Malopolskie',36)/
INSERT INTO Region VALUES(1070,'MAZ','Mazowieckie',36)/
INSERT INTO Region VALUES(1071,'OPO','Opolskie',36)/
INSERT INTO Region VALUES(1072,'PDK','Podkarpackie',36)/
INSERT INTO Region VALUES(1073,'PDL','Podlaskie',36)/
INSERT INTO Region VALUES(1074,'POM','Pomorskie',36)/
INSERT INTO Region VALUES(1075,'SLS','Slaskie',36)/
INSERT INTO Region VALUES(1076,'SWK','Swietokrzyskie',36)/
INSERT INTO Region VALUES(1077,'WLK','Wielkopolskie',36)/
INSERT INTO Region VALUES(1078,'W-M','Warminsko-mazurskie',36)/
INSERT INTO Region VALUES(1079,'Z-P','Zachodnio-Pomorskie',36)/
INSERT INTO Region VALUES(1080,'1','Aveiro',37)/
INSERT INTO Region VALUES(1081,'10','Leiria',37)/
INSERT INTO Region VALUES(1082,'11','Lisboa',37)/
INSERT INTO Region VALUES(1083,'12','Portalegre',37)/
INSERT INTO Region VALUES(1084,'13','Porto',37)/
INSERT INTO Region VALUES(1085,'14','Santarem',37)/
INSERT INTO Region VALUES(1086,'15','Setubal',37)/
INSERT INTO Region VALUES(1087,'16','Viana Do Castelo',37)/
INSERT INTO Region VALUES(1088,'17','Vila Real',37)/
INSERT INTO Region VALUES(1089,'18','Viseu',37)/
INSERT INTO Region VALUES(1090,'19','Azores',37)/
INSERT INTO Region VALUES(1091,'2','Beja',37)/
INSERT INTO Region VALUES(1092,'20','Madiera',37)/
INSERT INTO Region VALUES(1093,'3','Braga',37)/
INSERT INTO Region VALUES(1094,'4','Braganca',37)/
INSERT INTO Region VALUES(1095,'5','Castelo Branco',37)/
INSERT INTO Region VALUES(1096,'6','Coimbra',37)/
INSERT INTO Region VALUES(1097,'7','Evora',37)/
INSERT INTO Region VALUES(1098,'8','Faro',37)/
INSERT INTO Region VALUES(1099,'9','Guarda',76)/
INSERT INTO Region VALUES(1100,'1','Alba',76)/
INSERT INTO Region VALUES(1101,'10','Bucuresti',76)/
INSERT INTO Region VALUES(1102,'11','Buzau',76)/
INSERT INTO Region VALUES(1103,'12','Calarasi',76)/
INSERT INTO Region VALUES(1104,'13','Caras-Severin',76)/
INSERT INTO Region VALUES(1105,'14','Cluj',76)/
INSERT INTO Region VALUES(1106,'15','Constanta',76)/
INSERT INTO Region VALUES(1107,'16','Covasna',76)/
INSERT INTO Region VALUES(1108,'17','Dimbovita',76)/
INSERT INTO Region VALUES(1109,'18','Dolj',76)/
INSERT INTO Region VALUES(1110,'19','Galati',76)/
INSERT INTO Region VALUES(1111,'2','Arad',76)/
INSERT INTO Region VALUES(1112,'20','Gorj',76)/
INSERT INTO Region VALUES(1113,'21','Giurgiu',76)/
INSERT INTO Region VALUES(1114,'22','Harghita',76)/
INSERT INTO Region VALUES(1115,'23','Hunedoara',76)/
INSERT INTO Region VALUES(1116,'24','Ialomita',76)/
INSERT INTO Region VALUES(1117,'25','Iasi',76)/
INSERT INTO Region VALUES(1118,'26','Maramures',76)/
INSERT INTO Region VALUES(1119,'27','Mehedinti',76)/
INSERT INTO Region VALUES(1120,'28','Mures',76)/
INSERT INTO Region VALUES(1121,'29','Neamt',76)/
INSERT INTO Region VALUES(1122,'3','Arges',76)/
INSERT INTO Region VALUES(1123,'30','Olt',76)/
INSERT INTO Region VALUES(1124,'31','Prahova',76)/
INSERT INTO Region VALUES(1125,'32','Salaj',76)/
INSERT INTO Region VALUES(1126,'33','Satu Mare',76)/
INSERT INTO Region VALUES(1127,'34','Sibiu',76)/
INSERT INTO Region VALUES(1128,'35','Suceava',76)/
INSERT INTO Region VALUES(1129,'36','Teleorman',76)/
INSERT INTO Region VALUES(1130,'37','Timis',76)/
INSERT INTO Region VALUES(1131,'38','Tulcea',76)/
INSERT INTO Region VALUES(1132,'39','Vaslui',76)/
INSERT INTO Region VALUES(1133,'4','Bacau',76)/
INSERT INTO Region VALUES(1134,'40','Vilcea',76)/
INSERT INTO Region VALUES(1135,'41','Vrancea',76)/
INSERT INTO Region VALUES(1136,'5','Bihor',76)/
INSERT INTO Region VALUES(1137,'6','Bistrita-Nasaud',76)/
INSERT INTO Region VALUES(1138,'7','Botosani',76)/
INSERT INTO Region VALUES(1139,'8','Braila',76)/
INSERT INTO Region VALUES(1140,'9','Brasov',76)/
INSERT INTO Region VALUES(1141,'1','Аlеksаndrоvаc',78)/
INSERT INTO Region VALUES(1142,'10','Bаrајеvо',78)/
INSERT INTO Region VALUES(1143,'100','Grad Uzicе',78)/
INSERT INTO Region VALUES(1144,'101','Tоpоlа',78)/
INSERT INTO Region VALUES(1145,'102','Trgоvistе',78)/
INSERT INTO Region VALUES(1146,'103','Trstеnik',78)/
INSERT INTO Region VALUES(1147,'104','Tutin',78)/
INSERT INTO Region VALUES(1148,'105','Ub',78)/
INSERT INTO Region VALUES(1149,'107','Vаljеvо',78)/
INSERT INTO Region VALUES(1150,'108','Vаrvаrin',78)/
INSERT INTO Region VALUES(1151,'109','Vеlikа Plаnа',78)/
INSERT INTO Region VALUES(1152,'11','Cukаricа',78)/
INSERT INTO Region VALUES(1153,'110','Vеlikо Grаdistе',78)/
INSERT INTO Region VALUES(1154,'111','Vlаdicin Hаn',78)/
INSERT INTO Region VALUES(1155,'112','Vlаdimirci',78)/
INSERT INTO Region VALUES(1156,'113','Vlаsоtincе',78)/
INSERT INTO Region VALUES(1157,'114','Grad Vrаnjе',78)/
INSERT INTO Region VALUES(1158,'115','Vrnjаckа Bаnjа',78)/
INSERT INTO Region VALUES(1159,'116','Grad Zајеcаr',78)/
INSERT INTO Region VALUES(1160,'117','Zаbаri',78)/
INSERT INTO Region VALUES(1161,'118','Zаgubicа',78)/
INSERT INTO Region VALUES(1162,'119','Zitоrаdjа',78)/
INSERT INTO Region VALUES(1163,'12','Grоckа',78)/
INSERT INTO Region VALUES(1164,'120','Rаkоvicа',78)/
INSERT INTO Region VALUES(1165,'122','Niskа Bаnjа',78)/
INSERT INTO Region VALUES(1166,'123','Strаgаri',78)/
INSERT INTO Region VALUES(1167,'124','Surcin',78)/
INSERT INTO Region VALUES(1168,'125','Pantelej',78)/
INSERT INTO Region VALUES(1169,'126','Nis Crveni krst',78)/
INSERT INTO Region VALUES(1170,'127','Nis Palilula',78)/
INSERT INTO Region VALUES(1171,'128','Medijana',78)/
INSERT INTO Region VALUES(1172,'129','Kostolac',78)/
INSERT INTO Region VALUES(1173,'13','Nоvi Bеоgrаd',78)/
INSERT INTO Region VALUES(1174,'14','Оbrеnоvаc',78)/
INSERT INTO Region VALUES(1175,'15','Pаlilulа',78)/
INSERT INTO Region VALUES(1176,'16','Sаvski Vеnаc',78)/
INSERT INTO Region VALUES(1177,'17','Sоpоt',78)/
INSERT INTO Region VALUES(1178,'18','Stаri Grаd',78)/
INSERT INTO Region VALUES(1179,'19','Vоzdоvаc',78)/
INSERT INTO Region VALUES(1180,'2','Аlеksinаc',78)/
INSERT INTO Region VALUES(1181,'20','Vrаcаr',78)/
INSERT INTO Region VALUES(1182,'201','Аdа',78)/
INSERT INTO Region VALUES(1183,'202','Аlibunаr',78)/
INSERT INTO Region VALUES(1184,'203','Аpаtin',78)/
INSERT INTO Region VALUES(1185,'204','Bаc',78)/
INSERT INTO Region VALUES(1186,'205','Bаckа Pаlаnkа',78)/
INSERT INTO Region VALUES(1187,'206','Bаckа Tоpоlа',78)/
INSERT INTO Region VALUES(1188,'207','Bаcki Pеtrоvаc',78)/
INSERT INTO Region VALUES(1189,'208','Bеcеј',78)/
INSERT INTO Region VALUES(1190,'209','Bеlа Crkvа',78)/
INSERT INTO Region VALUES(1191,'21','Zemun',78)/
INSERT INTO Region VALUES(1192,'210','Bеоcin',78)/
INSERT INTO Region VALUES(1193,'211','Cоkа',78)/
INSERT INTO Region VALUES(1194,'212','Indjiја',78)/
INSERT INTO Region VALUES(1195,'213','Irig',78)/
INSERT INTO Region VALUES(1196,'214','Kаnjizа',78)/
INSERT INTO Region VALUES(1197,'215','Kikindа',78)/
INSERT INTO Region VALUES(1198,'216','Kоvаcicа',78)/
INSERT INTO Region VALUES(1199,'217','Kоvin',78)/
INSERT INTO Region VALUES(1200,'218','Kulа',78)/
INSERT INTO Region VALUES(1201,'219','Mаli Idjos',78)/
INSERT INTO Region VALUES(1202,'22','Zvеzdаrа',78)/
INSERT INTO Region VALUES(1203,'220','Nоvа Crnjа',78)/
INSERT INTO Region VALUES(1204,'221','Nоvi Bеcеј',78)/
INSERT INTO Region VALUES(1205,'222','Nоvi knеzеvаc',78)/
INSERT INTO Region VALUES(1206,'223','Novi Sad',78)/
INSERT INTO Region VALUES(1207,'224','Odzaci',78)/
INSERT INTO Region VALUES(1208,'225','Opovo',78)/
INSERT INTO Region VALUES(1209,'226','Grad Pančevo',78)/
INSERT INTO Region VALUES(1210,'227','Pecinci',78)/
INSERT INTO Region VALUES(1211,'228','Plandiste',78)/
INSERT INTO Region VALUES(1212,'229','Ruma',78)/
INSERT INTO Region VALUES(1213,'23','Blаcе',78)/
INSERT INTO Region VALUES(1214,'230','Secanj',78)/
INSERT INTO Region VALUES(1215,'231','Senta',78)/
INSERT INTO Region VALUES(1216,'232','Grad Sombor',78)/
INSERT INTO Region VALUES(1217,'233','Srbobran',78)/
INSERT INTO Region VALUES(1218,'234','Grad Sremska Mitrovi',78)/
INSERT INTO Region VALUES(1219,'235','Stara Pazova',78)/
INSERT INTO Region VALUES(1220,'236','Grad Subotica',78)/
INSERT INTO Region VALUES(1221,'237','Sid',78)/
INSERT INTO Region VALUES(1222,'238','Temerin',78)/
INSERT INTO Region VALUES(1223,'239','Titеl',78)/
INSERT INTO Region VALUES(1224,'24','Bоgаtic',78)/
INSERT INTO Region VALUES(1225,'240','Vrbаs',78)/
INSERT INTO Region VALUES(1226,'241','Vrsаc',78)/
INSERT INTO Region VALUES(1227,'242','Grad Zrenjanin',78)/
INSERT INTO Region VALUES(1228,'243','Zаbаlj',78)/
INSERT INTO Region VALUES(1229,'244','Zitistе',78)/
INSERT INTO Region VALUES(1230,'247','Pеtrоvаrаdin',78)/
INSERT INTO Region VALUES(1231,'25','Bојnik',78)/
INSERT INTO Region VALUES(1232,'250','Srеmski kаrlоvci',78)/
INSERT INTO Region VALUES(1233,'26','Bоljеvаc',78)/
INSERT INTO Region VALUES(1234,'27','Bоr',78)/
INSERT INTO Region VALUES(1235,'28','Bоsilеgrаd',78)/
INSERT INTO Region VALUES(1236,'29','Brus',78)/
INSERT INTO Region VALUES(1237,'3','Аrаndjеlоvаc',78)/
INSERT INTO Region VALUES(1238,'30','Buјаnоvаc',78)/
INSERT INTO Region VALUES(1239,'301','Dеcаni',78)/
INSERT INTO Region VALUES(1240,'303','Djаkоvicа',78)/
INSERT INTO Region VALUES(1241,'304','Glоgоvаc',78)/
INSERT INTO Region VALUES(1242,'305','Gnjilаnе',78)/
INSERT INTO Region VALUES(1243,'306','Istоk',78)/
INSERT INTO Region VALUES(1244,'307','Kаcаnik',78)/
INSERT INTO Region VALUES(1245,'308','Klinа',78)/
INSERT INTO Region VALUES(1246,'309','Kоsоvskа Kаmеnicа',78)/
INSERT INTO Region VALUES(1247,'31','Crnа Trаvа',78)/
INSERT INTO Region VALUES(1248,'310','Kоsоvskа Mitrоvicа',78)/
INSERT INTO Region VALUES(1249,'311','Lеpоsаvic',78)/
INSERT INTO Region VALUES(1250,'312','Lipljаn',78)/
INSERT INTO Region VALUES(1251,'313','Оrаhоvаc',78)/
INSERT INTO Region VALUES(1252,'314','Pеc',78)/
INSERT INTO Region VALUES(1253,'315','Pоduјеvо',78)/
INSERT INTO Region VALUES(1254,'316','Pristinа',78)/
INSERT INTO Region VALUES(1255,'317','Prizrеn',78)/
INSERT INTO Region VALUES(1256,'318','Srbicа',78)/
INSERT INTO Region VALUES(1257,'319','Suvа Rеkа',78)/
INSERT INTO Region VALUES(1258,'32','Cicеvаc',78)/
INSERT INTO Region VALUES(1259,'320','Urоsеvаc',78)/
INSERT INTO Region VALUES(1260,'321','Gnjilane',78)/
INSERT INTO Region VALUES(1261,'322','Vucitrn',78)/
INSERT INTO Region VALUES(1262,'324','Zubin Pоtоk',78)/
INSERT INTO Region VALUES(1263,'325','Stimljе',78)/
INSERT INTO Region VALUES(1264,'326','Strpcе',78)/
INSERT INTO Region VALUES(1265,'327','Оbilic',78)/
INSERT INTO Region VALUES(1266,'328','Kоsоvо Pоljе',78)/
INSERT INTO Region VALUES(1267,'329','Nоvо Brdо',78)/
INSERT INTO Region VALUES(1268,'33','Cupriја',78)/
INSERT INTO Region VALUES(1269,'330','Zvеcаn',78)/
INSERT INTO Region VALUES(1270,'331','Gora (sediste Dragas',78)/
INSERT INTO Region VALUES(1271,'34','Grad Cаcаk',78)/
INSERT INTO Region VALUES(1272,'35','Cајеtinа',78)/
INSERT INTO Region VALUES(1273,'36','Dеspоtоvаc',78)/
INSERT INTO Region VALUES(1274,'37','Dimitrоvgrаd',78)/
INSERT INTO Region VALUES(1275,'38','Dоljеvаc',78)/
INSERT INTO Region VALUES(1276,'39','Gаdzin Hаn',78)/
INSERT INTO Region VALUES(1277,'4','Аriljе',78)/
INSERT INTO Region VALUES(1278,'40','Gоlubаc',78)/
INSERT INTO Region VALUES(1279,'41','Gоrnji Milаnоvаc',78)/
INSERT INTO Region VALUES(1280,'42','Ivаnjicа',78)/
INSERT INTO Region VALUES(1281,'43','Klаdоvо',78)/
INSERT INTO Region VALUES(1282,'44','Knic',78)/
INSERT INTO Region VALUES(1283,'45','Knjаzеvаc',78)/
INSERT INTO Region VALUES(1284,'46','Kоcеljеvа',78)/
INSERT INTO Region VALUES(1285,'48','Kоsјеric',78)/
INSERT INTO Region VALUES(1286,'49','Krаguјеvаc',78)/
INSERT INTO Region VALUES(1287,'50','Krаljеvо',78)/
INSERT INTO Region VALUES(1288,'501','Grаd Bеоgrаd',78)/
INSERT INTO Region VALUES(1289,'51','Krupаnj',78)/
INSERT INTO Region VALUES(1290,'511','Grаd Nоvi Sаd',78)/
INSERT INTO Region VALUES(1291,'52','Grad Krusеvаc',78)/
INSERT INTO Region VALUES(1292,'521','Grаd Nis',78)/
INSERT INTO Region VALUES(1293,'53','Kučеvо',78)/
INSERT INTO Region VALUES(1294,'531','Grаd Krаguјеvаc',78)/
INSERT INTO Region VALUES(1295,'54','Kuršumliја',78)/
INSERT INTO Region VALUES(1296,'541','Grаd Pristinа',78)/
INSERT INTO Region VALUES(1297,'55','Lајkоvаc',78)/
INSERT INTO Region VALUES(1298,'56','Lаzаrеvаc',78)/
INSERT INTO Region VALUES(1299,'57','Lеbаnе',78)/
INSERT INTO Region VALUES(1300,'58','Grad Lеskоvаc',78)/
INSERT INTO Region VALUES(1301,'581','Аp Vојvоdinа',78)/
INSERT INTO Region VALUES(1302,'59','Grad Lоznicа',78)/
INSERT INTO Region VALUES(1303,'591','Аp kоsоvо i Mеtоhiја',78)/
INSERT INTO Region VALUES(1304,'6','Bаbusnicа',78)/
INSERT INTO Region VALUES(1305,'60','Lucаni',78)/
INSERT INTO Region VALUES(1306,'601','Rеpublikа Srbiја',78)/
INSERT INTO Region VALUES(1307,'78','Ljig',78)/
INSERT INTO Region VALUES(1308,'62','Ljubоviја',78)/
INSERT INTO Region VALUES(1309,'63','Mајdаnpеk',78)/
INSERT INTO Region VALUES(1310,'65','Mаli Zvоrnik',78)/
INSERT INTO Region VALUES(1311,'66','Mаlо Crnicе',78)/
INSERT INTO Region VALUES(1312,'67','Mеdvеdjа',78)/
INSERT INTO Region VALUES(1313,'68','Mеrоsinа',78)/
INSERT INTO Region VALUES(1314,'69','Miоnicа',78)/
INSERT INTO Region VALUES(1315,'7','Bајinа Bаstа',78)/
INSERT INTO Region VALUES(1316,'70','Mlаdеnоvаc',78)/
INSERT INTO Region VALUES(1317,'72','Nеgоtin',78)/
INSERT INTO Region VALUES(1318,'74','Nоvа Vаrоs',78)/
INSERT INTO Region VALUES(1319,'75','Grad Nоvi Pаzаr',78)/
INSERT INTO Region VALUES(1320,'76','Оsеčinа',78)/
INSERT INTO Region VALUES(1321,'77','Pаrаcin',78)/
INSERT INTO Region VALUES(1322,'78','Pеtrоvаc nа Mlаvi',78)/
INSERT INTO Region VALUES(1323,'79','Pirоt',78)/
INSERT INTO Region VALUES(1324,'8','Bаtоcinа',78)/
INSERT INTO Region VALUES(1325,'80','Grad Pоzаrеvаc',78)/
INSERT INTO Region VALUES(1326,'81','Pоzеgа',78)/
INSERT INTO Region VALUES(1327,'82','Prеsеvо',78)/
INSERT INTO Region VALUES(1328,'83','Pribој',78)/
INSERT INTO Region VALUES(1329,'84','Priјеpоljе',78)/
INSERT INTO Region VALUES(1330,'85','Prоkupljе',78)/
INSERT INTO Region VALUES(1331,'86','Rаcа',78)/
INSERT INTO Region VALUES(1332,'87','Rаskа',78)/
INSERT INTO Region VALUES(1333,'88','Rаzаnj',78)/
INSERT INTO Region VALUES(1334,'89','Rеkоvаc',78)/
INSERT INTO Region VALUES(1335,'9','Bеlа Pаlаnkа',78)/
INSERT INTO Region VALUES(1336,'91','Sјеnicа',78)/
INSERT INTO Region VALUES(1337,'92','Grad Smеdеrеvо',78)/
INSERT INTO Region VALUES(1338,'93','Smеdеrеvskа Pаlаnkа',78)/
INSERT INTO Region VALUES(1339,'94','Sоkоbаnjа',78)/
INSERT INTO Region VALUES(1340,'95','Surdulicа',78)/
INSERT INTO Region VALUES(1341,'96','Grad Јаgоdinа',78)/
INSERT INTO Region VALUES(1342,'97','Svilајnаc',78)/
INSERT INTO Region VALUES(1343,'98','Svrljig',78)/
INSERT INTO Region VALUES(1344,'99','Grad Sаbаc',78)/
INSERT INTO Region VALUES(1345,'1','Adigeja Republic',40)/
INSERT INTO Region VALUES(1346,'10','Karelian Republic',40)/
INSERT INTO Region VALUES(1347,'11','Komi Republic',40)/
INSERT INTO Region VALUES(1348,'12','Marijskaya Republic',40)/
INSERT INTO Region VALUES(1349,'13','Mordovian Republic',40)/
INSERT INTO Region VALUES(1350,'14','Yakutiya-Saha Rrepub',40)/
INSERT INTO Region VALUES(1351,'15','North-Osetiya Republ',40)/
INSERT INTO Region VALUES(1352,'16','Tatarstan Republic',40)/
INSERT INTO Region VALUES(1353,'17','Tuva Republic',40)/
INSERT INTO Region VALUES(1354,'18','The Udmurt Republic',40)/
INSERT INTO Region VALUES(1355,'19','Chakassky Republic',40)/
INSERT INTO Region VALUES(1356,'2','Highlands-Altay Rep.',40)/
INSERT INTO Region VALUES(1357,'20','Chechenskaya Republ.',40)/
INSERT INTO Region VALUES(1358,'21','Chuvash Republic',40)/
INSERT INTO Region VALUES(1359,'22','Altay Territory',40)/
INSERT INTO Region VALUES(1360,'23','Krasnodar Territory',40)/
INSERT INTO Region VALUES(1361,'24','Krasnoyarsk Territor',40)/
INSERT INTO Region VALUES(1362,'25','Primorye Territory',40)/
INSERT INTO Region VALUES(1363,'26','Stavropol Territory',40)/
INSERT INTO Region VALUES(1364,'27','Khabarovsk Territory',40)/
INSERT INTO Region VALUES(1365,'28','The Amur Area',40)/
INSERT INTO Region VALUES(1366,'29','The Arkhangelsk Area',40)/
INSERT INTO Region VALUES(1367,'3','Republ.of Bashkortos',40)/
INSERT INTO Region VALUES(1368,'30','The Astrakhan Area',40)/
INSERT INTO Region VALUES(1369,'31','The Belgorod Area',40)/
INSERT INTO Region VALUES(1370,'32','The Bryansk Area',40)/
INSERT INTO Region VALUES(1371,'33','The Vladimir Area',40)/
INSERT INTO Region VALUES(1372,'34','The Volgograd Area',40)/
INSERT INTO Region VALUES(1373,'35','The Vologda Area',40)/
INSERT INTO Region VALUES(1374,'36','The Voronezh Area',40)/
INSERT INTO Region VALUES(1375,'37','The Ivanovo Area',40)/
INSERT INTO Region VALUES(1376,'38','The Irkutsk Area',40)/
INSERT INTO Region VALUES(1377,'39','The Kaliningrad Area',40)/
INSERT INTO Region VALUES(1378,'4','Buryat Republic',40)/
INSERT INTO Region VALUES(1379,'40','The Kaluga Area',40)/
INSERT INTO Region VALUES(1380,'41','The Kamchatka Area',40)/
INSERT INTO Region VALUES(1381,'42','The Kemerovo Area',40)/
INSERT INTO Region VALUES(1382,'43','The Kirov Area',40)/
INSERT INTO Region VALUES(1383,'44','The Kostroma Area',40)/
INSERT INTO Region VALUES(1384,'45','The Kurgan Area',40)/
INSERT INTO Region VALUES(1385,'46','The Kursk Area',40)/
INSERT INTO Region VALUES(1386,'47','The Leningrad Area',40)/
INSERT INTO Region VALUES(1387,'48','The Lipetsk Area',40)/
INSERT INTO Region VALUES(1388,'49','The Magadan Area',40)/
INSERT INTO Region VALUES(1389,'5','Dagestan Republic',40)/
INSERT INTO Region VALUES(1390,'50','The Moscow Area',40)/
INSERT INTO Region VALUES(1391,'51','The Murmansk Area',40)/
INSERT INTO Region VALUES(1392,'52','The Nizhniy Novgorod',40)/
INSERT INTO Region VALUES(1393,'53','The Novgorod Area',40)/
INSERT INTO Region VALUES(1394,'54','The Novosibirsk Area',40)/
INSERT INTO Region VALUES(1395,'55','The Omsk Area',40)/
INSERT INTO Region VALUES(1396,'56','The Orenburg Area',40)/
INSERT INTO Region VALUES(1397,'57','The Oryol Area',40)/
INSERT INTO Region VALUES(1398,'58','The Penza Area',40)/
INSERT INTO Region VALUES(1399,'59','The Perm Area',40)/
INSERT INTO Region VALUES(1400,'6','Ingushetija Republic',40)/
INSERT INTO Region VALUES(1401,'60','The Pskov Area',40)/
INSERT INTO Region VALUES(1402,'61','The Rostov Area',40)/
INSERT INTO Region VALUES(1403,'62','The Ryazan Area',40)/
INSERT INTO Region VALUES(1404,'63','The Samara Area',40)/
INSERT INTO Region VALUES(1405,'64','The Saratov Area',40)/
INSERT INTO Region VALUES(1406,'65','The Sakhalin Area',40)/
INSERT INTO Region VALUES(1407,'66','The Sverdlovsk Area',40)/
INSERT INTO Region VALUES(1408,'67','The Smolensk Area',40)/
INSERT INTO Region VALUES(1409,'68','The Tambov Area',40)/
INSERT INTO Region VALUES(1410,'69','The Tver Area',40)/
INSERT INTO Region VALUES(1411,'7','Kabardino-Balkar.Rep',40)/
INSERT INTO Region VALUES(1412,'70','The Tomsk Area',40)/
INSERT INTO Region VALUES(1413,'71','The Tula Area',40)/
INSERT INTO Region VALUES(1414,'72','The Tyumen Area',40)/
INSERT INTO Region VALUES(1415,'73','The Ulyanovsk Area',40)/
INSERT INTO Region VALUES(1416,'74','The Chelyabinsk Area',40)/
INSERT INTO Region VALUES(1417,'75','The Chita Area',40)/
INSERT INTO Region VALUES(1418,'76','The Yaroslavl Area',40)/
INSERT INTO Region VALUES(1419,'77','c.Moscow',40)/
INSERT INTO Region VALUES(1420,'78','c.St-Peterburg',40)/
INSERT INTO Region VALUES(1421,'79','The Jewish Auton.are',40)/
INSERT INTO Region VALUES(1422,'8','Kalmyk Republic',40)/
INSERT INTO Region VALUES(1423,'80','Aginsk Buryat Aut.di',40)/
INSERT INTO Region VALUES(1424,'81','Komy Permjats.Aut.di',40)/
INSERT INTO Region VALUES(1425,'82','Korjacs Auton.distri',40)/
INSERT INTO Region VALUES(1426,'83','Nenekchky Auton.dist',40)/
INSERT INTO Region VALUES(1427,'84','The Taymir Auton.dis',40)/
INSERT INTO Region VALUES(1428,'85','Ust-Ordinsky Buryat',40)/
INSERT INTO Region VALUES(1429,'86','Chanti-Mansyjsky Aut',40)/
INSERT INTO Region VALUES(1430,'87','Chukotka Auton. dist',40)/
INSERT INTO Region VALUES(1431,'88','Evensky Auton.distri',40)/
INSERT INTO Region VALUES(1432,'89','Jamalo-Nenekchky Aut',40)/
INSERT INTO Region VALUES(1433,'9','Karach.-Cherkessk Re',40)/
INSERT INTO Region VALUES(1434,'1','Riad',41)/
INSERT INTO Region VALUES(1435,'10','Nadschran',41)/
INSERT INTO Region VALUES(1436,'11','Baha',41)/
INSERT INTO Region VALUES(1437,'12','Dschauf',41)/
INSERT INTO Region VALUES(1438,'14','Asir',41)/
INSERT INTO Region VALUES(1439,'2','Mekka',41)/
INSERT INTO Region VALUES(1440,'3','Medina',41)/
INSERT INTO Region VALUES(1441,'4','asch-Scharqiyya',41)/
INSERT INTO Region VALUES(1442,'5','Qasim',41)/
INSERT INTO Region VALUES(1443,'6','Hail',41)/
INSERT INTO Region VALUES(1444,'7','Tabuk',41)/
INSERT INTO Region VALUES(1445,'8','al-Hudud asch-schama',41)/
INSERT INTO Region VALUES(1446,'9','Dschaizan',41)/
INSERT INTO Region VALUES(1447,'1','Blekinge County',46)/
INSERT INTO Region VALUES(1448,'10','Norrbotten County',46)/
INSERT INTO Region VALUES(1449,'11','Skaane County',46)/
INSERT INTO Region VALUES(1450,'12','Stockholm County',46)/
INSERT INTO Region VALUES(1451,'13','Soedermanland County',46)/
INSERT INTO Region VALUES(1452,'14','Uppsala County',46)/
INSERT INTO Region VALUES(1453,'15','Vaermland County',46)/
INSERT INTO Region VALUES(1454,'16','Vaesterbotten County',46)/
INSERT INTO Region VALUES(1455,'17','Vaesternorrland Cnty',46)/
INSERT INTO Region VALUES(1456,'18','Vaestmanland County',46)/
INSERT INTO Region VALUES(1457,'19','Vaestra Goetaland C.',46)/
INSERT INTO Region VALUES(1458,'2','Dalarnas County',46)/
INSERT INTO Region VALUES(1459,'20','Oerebro County',46)/
INSERT INTO Region VALUES(1460,'21','Oestergoetland Cnty',46)/
INSERT INTO Region VALUES(1461,'3','Gotland County',46)/
INSERT INTO Region VALUES(1462,'4','Gaevleborg County',46)/
INSERT INTO Region VALUES(1463,'5','Halland County',46)/
INSERT INTO Region VALUES(1464,'6','Jaemtland County',46)/
INSERT INTO Region VALUES(1465,'7','Joenkoeping County',46)/
INSERT INTO Region VALUES(1466,'8','Kalmar County',46)/
INSERT INTO Region VALUES(1467,'9','Kronoberg County',42)/
INSERT INTO Region VALUES(1469,'1','Ajdovscina',80)/
INSERT INTO Region VALUES(1470,'10','Idrija',80)/
INSERT INTO Region VALUES(1471,'11','Ilirska Bistrica',80)/
INSERT INTO Region VALUES(1472,'12','Izola',80)/
INSERT INTO Region VALUES(1473,'13','Jesenice',80)/
INSERT INTO Region VALUES(1474,'14','Kamnik',80)/
INSERT INTO Region VALUES(1475,'15','Kocevje',80)/
INSERT INTO Region VALUES(1476,'16','Koper',80)/
INSERT INTO Region VALUES(1477,'17','Kranj',80)/
INSERT INTO Region VALUES(1478,'18','Krsko',80)/
INSERT INTO Region VALUES(1479,'19','Lenart',80)/
INSERT INTO Region VALUES(1480,'2','Brezice',80)/
INSERT INTO Region VALUES(1481,'20','Lendava',80)/
INSERT INTO Region VALUES(1482,'21','Litija',80)/
INSERT INTO Region VALUES(1483,'22','Ljubljana-Bezigrad',80)/
INSERT INTO Region VALUES(1484,'23','Ljubljana-Center',80)/
INSERT INTO Region VALUES(1485,'24','Ljubljana-Moste-Polj',80)/
INSERT INTO Region VALUES(1486,'25','Ljubljana-Siska',80)/
INSERT INTO Region VALUES(1487,'26','Ljubljana-Vic-Rudnik',80)/
INSERT INTO Region VALUES(1488,'27','Ljutomer',80)/
INSERT INTO Region VALUES(1489,'28','Logatec',80)/
INSERT INTO Region VALUES(1490,'29','Maribor',80)/
INSERT INTO Region VALUES(1491,'3','Celje',80)/
INSERT INTO Region VALUES(1492,'30','Metlika',80)/
INSERT INTO Region VALUES(1493,'31','Mozirje',80)/
INSERT INTO Region VALUES(1494,'32','Murska Sobota',80)/
INSERT INTO Region VALUES(1495,'33','Nova Gorica',80)/
INSERT INTO Region VALUES(1496,'34','Novo Mesto',80)/
INSERT INTO Region VALUES(1497,'35','Ormoz',80)/
INSERT INTO Region VALUES(1498,'36','Pesnica',80)/
INSERT INTO Region VALUES(1499,'37','Piran',80)/
INSERT INTO Region VALUES(1500,'38','Postojna',80)/
INSERT INTO Region VALUES(1501,'39','Ptuj',80)/
INSERT INTO Region VALUES(1502,'4','Cerknica',80)/
INSERT INTO Region VALUES(1503,'40','Radlje Ob Dravi',80)/
INSERT INTO Region VALUES(1504,'41','Radovljica',80)/
INSERT INTO Region VALUES(1505,'42','Ravne Na Koroskem',80)/
INSERT INTO Region VALUES(1506,'43','Ribnica',80)/
INSERT INTO Region VALUES(1507,'44','Ruse',80)/
INSERT INTO Region VALUES(1508,'45','Sentjur Pri Celju',80)/
INSERT INTO Region VALUES(1509,'46','Sevnica',80)/
INSERT INTO Region VALUES(1510,'47','Sezana',80)/
INSERT INTO Region VALUES(1511,'48','Skofja Loka',80)/
INSERT INTO Region VALUES(1512,'49','Slovenj Gradec',80)/
INSERT INTO Region VALUES(1513,'5','Crnomelj',80)/
INSERT INTO Region VALUES(1514,'50','Slovenska Bistrica',80)/
INSERT INTO Region VALUES(1515,'51','Slovenske Konjice',80)/
INSERT INTO Region VALUES(1516,'52','Smarje Pri Jelsah',80)/
INSERT INTO Region VALUES(1517,'53','Tolmin',80)/
INSERT INTO Region VALUES(1518,'54','Trbovlje',80)/
INSERT INTO Region VALUES(1519,'55','Trebnje',80)/
INSERT INTO Region VALUES(1520,'56','Trzic',80)/
INSERT INTO Region VALUES(1521,'57','Velenje',80)/
INSERT INTO Region VALUES(1522,'58','Vrhnika',80)/
INSERT INTO Region VALUES(1523,'59','Zagorje Ob Savi',80)/
INSERT INTO Region VALUES(1524,'6','Dravograd',80)/
INSERT INTO Region VALUES(1525,'60','Zalec',80)/
INSERT INTO Region VALUES(1526,'7','Gornja Radgona',80)/
INSERT INTO Region VALUES(1527,'8','Grosuplje',80)/
INSERT INTO Region VALUES(1528,'9','Hrastnik Lasko',80)/
INSERT INTO Region VALUES(1529,'1','Bratislava',79)/
INSERT INTO Region VALUES(1530,'2','Zapadoslovensky',79)/
INSERT INTO Region VALUES(1531,'3','Stredoslovensky',79)/
INSERT INTO Region VALUES(1532,'4','Vychodoslovensky',79)/
INSERT INTO Region VALUES(1533,'1','Amnat Charoen',49)/
INSERT INTO Region VALUES(1534,'10','Chon Buri',49)/
INSERT INTO Region VALUES(1535,'11','Chumphon',49)/
INSERT INTO Region VALUES(1536,'12','Kalasin',49)/
INSERT INTO Region VALUES(1537,'13','Kamphaeng Phet',49)/
INSERT INTO Region VALUES(1538,'14','Kanchanaburi',49)/
INSERT INTO Region VALUES(1539,'15','Khon Kaen',49)/
INSERT INTO Region VALUES(1540,'16','Krabi',49)/
INSERT INTO Region VALUES(1541,'17','Krung Thep',49)/
INSERT INTO Region VALUES(1542,'18','Mahanakhon',49)/
INSERT INTO Region VALUES(1543,'19','Lampang',49)/
INSERT INTO Region VALUES(1544,'2','Ang Thong',49)/
INSERT INTO Region VALUES(1545,'20','Lamphun',49)/
INSERT INTO Region VALUES(1546,'21','Loei',49)/
INSERT INTO Region VALUES(1547,'22','Lop Buri',49)/
INSERT INTO Region VALUES(1548,'23','Mae Hong Son',49)/
INSERT INTO Region VALUES(1549,'24','Maha Sarakham',49)/
INSERT INTO Region VALUES(1550,'25','Mukdahan',49)/
INSERT INTO Region VALUES(1551,'26','Nakhon Nayok',49)/
INSERT INTO Region VALUES(1552,'27','Nakhon Pathom',49)/
INSERT INTO Region VALUES(1553,'28','Nakhon Phanom',49)/
INSERT INTO Region VALUES(1554,'29','Nakhon Ratchasima',49)/
INSERT INTO Region VALUES(1555,'3','Buriram',49)/
INSERT INTO Region VALUES(1556,'30','Nakhon Sawan',49)/
INSERT INTO Region VALUES(1557,'31','Nakhon Si Thammarat',49)/
INSERT INTO Region VALUES(1558,'32','Nan',49)/
INSERT INTO Region VALUES(1559,'33','Narathiwat',49)/
INSERT INTO Region VALUES(1560,'34','Nong Bua Lamphu',49)/
INSERT INTO Region VALUES(1561,'35','Nong Khai',49)/
INSERT INTO Region VALUES(1562,'36','Nonthaburi',49)/
INSERT INTO Region VALUES(1563,'37','Pathum Thani',49)/
INSERT INTO Region VALUES(1564,'38','Pattani',49)/
INSERT INTO Region VALUES(1565,'39','Phangnga',49)/
INSERT INTO Region VALUES(1566,'4','Chachoengsao',49)/
INSERT INTO Region VALUES(1567,'40','Phatthalung',49)/
INSERT INTO Region VALUES(1568,'41','Phayao',49)/
INSERT INTO Region VALUES(1569,'42','Phetchabun',49)/
INSERT INTO Region VALUES(1570,'43','Phetchaburi',49)/
INSERT INTO Region VALUES(1571,'44','Phichit',49)/
INSERT INTO Region VALUES(1572,'45','Phitsanulok',49)/
INSERT INTO Region VALUES(1573,'46','Phra Nakhon Si Ayut.',49)/
INSERT INTO Region VALUES(1574,'47','Phrae',49)/
INSERT INTO Region VALUES(1575,'48','Phuket',49)/
INSERT INTO Region VALUES(1576,'49','Prachin Buri',49)/
INSERT INTO Region VALUES(1577,'5','Chai Nat',49)/
INSERT INTO Region VALUES(1578,'6','Chaiyaphum',49)/
INSERT INTO Region VALUES(1579,'7','Chanthaburi',49)/
INSERT INTO Region VALUES(1580,'8','Chiang Mai',49)/
INSERT INTO Region VALUES(1581,'9','Chiang Rai',49)/
INSERT INTO Region VALUES(1582,'1','Adana',50)/
INSERT INTO Region VALUES(1583,'10','Balikesir',50)/
INSERT INTO Region VALUES(1584,'11','Bilecik',50)/
INSERT INTO Region VALUES(1585,'12','Bingöl',50)/
INSERT INTO Region VALUES(1586,'13','Bitlis',50)/
INSERT INTO Region VALUES(1587,'14','Bolu',50)/
INSERT INTO Region VALUES(1588,'15','Burdur',50)/
INSERT INTO Region VALUES(1589,'16','Bursa',50)/
INSERT INTO Region VALUES(1590,'17','Canakkale',50)/
INSERT INTO Region VALUES(1591,'18','Cankiri',50)/
INSERT INTO Region VALUES(1592,'19','Corum',50)/
INSERT INTO Region VALUES(1593,'2','Adiyaman',50)/
INSERT INTO Region VALUES(1594,'20','Denizli',50)/
INSERT INTO Region VALUES(1595,'21','Diyarbakir',50)/
INSERT INTO Region VALUES(1596,'22','Edirne',50)/
INSERT INTO Region VALUES(1597,'23','Elazig',50)/
INSERT INTO Region VALUES(1598,'24','Erzincan',50)/
INSERT INTO Region VALUES(1599,'25','Erzurum',50)/
INSERT INTO Region VALUES(1600,'26','Eskisehir',50)/
INSERT INTO Region VALUES(1601,'27','Gaziantep',50)/
INSERT INTO Region VALUES(1602,'28','Giresun',50)/
INSERT INTO Region VALUES(1603,'29','Guemueshane',50)/
INSERT INTO Region VALUES(1604,'3','Afyon',50)/
INSERT INTO Region VALUES(1605,'30','Hakkari',50)/
INSERT INTO Region VALUES(1606,'31','Hatay',50)/
INSERT INTO Region VALUES(1607,'32','Isparta',50)/
INSERT INTO Region VALUES(1608,'33','Icel',50)/
INSERT INTO Region VALUES(1609,'34','Istanbul',50)/
INSERT INTO Region VALUES(1610,'35','Izmir',50)/
INSERT INTO Region VALUES(1611,'36','Kars',50)/
INSERT INTO Region VALUES(1612,'37','Kastamonu',50)/
INSERT INTO Region VALUES(1613,'38','Kayseri',50)/
INSERT INTO Region VALUES(1614,'39','Kirklareli',50)/
INSERT INTO Region VALUES(1615,'4','Agri',50)/
INSERT INTO Region VALUES(1616,'40','Kirshehir',50)/
INSERT INTO Region VALUES(1617,'41','Kocaeli',50)/
INSERT INTO Region VALUES(1618,'42','Konya',50)/
INSERT INTO Region VALUES(1619,'43','Kuetahya',50)/
INSERT INTO Region VALUES(1620,'44','Malatya',50)/
INSERT INTO Region VALUES(1621,'45','Manisa',50)/
INSERT INTO Region VALUES(1622,'46','K.Marash',50)/
INSERT INTO Region VALUES(1623,'47','Mardin',50)/
INSERT INTO Region VALUES(1624,'48','Mugla',50)/
INSERT INTO Region VALUES(1625,'49','Mush',50)/
INSERT INTO Region VALUES(1626,'5','Amasya',50)/
INSERT INTO Region VALUES(1627,'50','Nevshehir',50)/
INSERT INTO Region VALUES(1628,'51','Nigde',50)/
INSERT INTO Region VALUES(1629,'52','Ordu',50)/
INSERT INTO Region VALUES(1630,'53','Rize',50)/
INSERT INTO Region VALUES(1631,'54','Sakarya',50)/
INSERT INTO Region VALUES(1632,'55','Samsun',50)/
INSERT INTO Region VALUES(1633,'56','Siirt',50)/
INSERT INTO Region VALUES(1634,'57','Sinop',50)/
INSERT INTO Region VALUES(1635,'58','Sivas',50)/
INSERT INTO Region VALUES(1636,'59','Tekirdag',50)/
INSERT INTO Region VALUES(1637,'6','Ankara',50)/
INSERT INTO Region VALUES(1638,'60','Tokat',50)/
INSERT INTO Region VALUES(1639,'61','Trabzon',50)/
INSERT INTO Region VALUES(1640,'62','Tunceli',50)/
INSERT INTO Region VALUES(1641,'63','Shanliurfa',50)/
INSERT INTO Region VALUES(1642,'64','Ushak',50)/
INSERT INTO Region VALUES(1643,'65','Van',50)/
INSERT INTO Region VALUES(1644,'66','Yozgat',50)/
INSERT INTO Region VALUES(1645,'67','Zonguldak',50)/
INSERT INTO Region VALUES(1646,'68','Aksaray',50)/
INSERT INTO Region VALUES(1647,'69','Bayburt',50)/
INSERT INTO Region VALUES(1648,'7','Antalya',50)/
INSERT INTO Region VALUES(1649,'70','Karaman',50)/
INSERT INTO Region VALUES(1650,'71','Kirikkale',50)/
INSERT INTO Region VALUES(1651,'72','Batman',50)/
INSERT INTO Region VALUES(1652,'73','Shirnak',50)/
INSERT INTO Region VALUES(1653,'74','Bartin',50)/
INSERT INTO Region VALUES(1654,'75','Ardahan',50)/
INSERT INTO Region VALUES(1655,'76','Igdir',50)/
INSERT INTO Region VALUES(1656,'77','Yalova',50)/
INSERT INTO Region VALUES(1657,'78','Karabük',50)/
INSERT INTO Region VALUES(1658,'79','Kilis',50)/
INSERT INTO Region VALUES(1659,'8','Artvin',50)/
INSERT INTO Region VALUES(1660,'80','Osmaniye',50)/
INSERT INTO Region VALUES(1661,'81','Düzce',50)/
INSERT INTO Region VALUES(1662,'9','Aydin',50)/
INSERT INTO Region VALUES(1663,'FJN','Fu-chien',48)/
INSERT INTO Region VALUES(1664,'KSH','Kao-hsiung',48)/
INSERT INTO Region VALUES(1665,'TPE','T''ai-pei',48)/
INSERT INTO Region VALUES(1666,'TWN','Taiwan',48)/
INSERT INTO Region VALUES(1667,'CHG','Chernigivska',81)/
INSERT INTO Region VALUES(1668,'CHR','Cherkaska',81)/
INSERT INTO Region VALUES(1669,'CHV','Chernovitska',81)/
INSERT INTO Region VALUES(1670,'DNP','Dnipropetrovska',81)/
INSERT INTO Region VALUES(1671,'DON','Donetska',81)/
INSERT INTO Region VALUES(1672,'HAR','Harkivska',81)/
INSERT INTO Region VALUES(1673,'HML','Hmelnitska',81)/
INSERT INTO Region VALUES(1674,'HRS','Hersonska',81)/
INSERT INTO Region VALUES(1675,'IVF','Ivano-Frankivska',81)/
INSERT INTO Region VALUES(1676,'KIE','Kievska',81)/
INSERT INTO Region VALUES(1677,'KIR','Kirovogradska',81)/
INSERT INTO Region VALUES(1678,'KRM','Respublika Krim',81)/
INSERT INTO Region VALUES(1679,'LUG','Luganska',81)/
INSERT INTO Region VALUES(1680,'L''V','Lvivsbka',81)/
INSERT INTO Region VALUES(1681,'M_K','m.Kiev',81)/
INSERT INTO Region VALUES(1682,'M_S','m.Sevastopil',81)/
INSERT INTO Region VALUES(1683,'MIK','Mikolaivska',81)/
INSERT INTO Region VALUES(1684,'ODS','Odeska',81)/
INSERT INTO Region VALUES(1685,'POL','Poltavska',81)/
INSERT INTO Region VALUES(1686,'RIV','Rivnenska',81)/
INSERT INTO Region VALUES(1687,'SUM','Sumska',81)/
INSERT INTO Region VALUES(1688,'TER','Ternopilska',81)/
INSERT INTO Region VALUES(1689,'VIN','Vinnitska',81)/
INSERT INTO Region VALUES(1690,'VOL','Volinska',81)/
INSERT INTO Region VALUES(1691,'ZAK','Zakarpatska',81)/
INSERT INTO Region VALUES(1692,'ZAP','Zaporizka',81)/
INSERT INTO Region VALUES(1693,'ZHI','Zhitomirska',81)/
INSERT INTO Region VALUES(1694,'AK','Alaska',53)/
INSERT INTO Region VALUES(1695,'AL','Alabama',53)/
INSERT INTO Region VALUES(1696,'AR','Arkansas',53)/
INSERT INTO Region VALUES(1697,'AS','American Samoa',53)/
INSERT INTO Region VALUES(1698,'AZ','Arizona',53)/
INSERT INTO Region VALUES(1699,'CA','California',53)/
INSERT INTO Region VALUES(1700,'CO','Colorado',53)/
INSERT INTO Region VALUES(1701,'CT','Connecticut',53)/
INSERT INTO Region VALUES(1702,'DC','District of Columbia',53)/
INSERT INTO Region VALUES(1703,'DE','Delaware',53)/
INSERT INTO Region VALUES(1704,'FL','Florida',53)/
INSERT INTO Region VALUES(1705,'GA','Georgia',53)/
INSERT INTO Region VALUES(1706,'GU','Guam',53)/
INSERT INTO Region VALUES(1707,'HI','Hawaii',53)/
INSERT INTO Region VALUES(1708,'IA','Iowa',53)/
INSERT INTO Region VALUES(1709,'ID','Idaho',53)/
INSERT INTO Region VALUES(1710,'IL','Illinois',53)/
INSERT INTO Region VALUES(1711,'IN','Indiana',53)/
INSERT INTO Region VALUES(1712,'KS','Kansas',53)/
INSERT INTO Region VALUES(1713,'KY','Kentucky',53)/
INSERT INTO Region VALUES(1714,'LA','Louisiana',53)/
INSERT INTO Region VALUES(1715,'MA','Massachusetts',53)/
INSERT INTO Region VALUES(1716,'MD','Maryland',53)/
INSERT INTO Region VALUES(1717,'ME','Maine',53)/
INSERT INTO Region VALUES(1718,'MI','Michigan',53)/
INSERT INTO Region VALUES(1719,'MN','Minnesota',53)/
INSERT INTO Region VALUES(1720,'MO','Missouri',53)/
INSERT INTO Region VALUES(1721,'MP','Northern Mariana Isl',53)/
INSERT INTO Region VALUES(1722,'MS','Mississippi',53)/
INSERT INTO Region VALUES(1723,'MT','Montana',53)/
INSERT INTO Region VALUES(1724,'NC','North Carolina',53)/
INSERT INTO Region VALUES(1725,'ND','North Dakota',53)/
INSERT INTO Region VALUES(1726,'NE','Nebraska',53)/
INSERT INTO Region VALUES(1727,'NH','New Hampshire',53)/
INSERT INTO Region VALUES(1728,'NJ','New Jersey',53)/
INSERT INTO Region VALUES(1729,'NM','New Mexico',53)/
INSERT INTO Region VALUES(1730,'NV','Nevada',53)/
INSERT INTO Region VALUES(1731,'NY','New York',53)/
INSERT INTO Region VALUES(1732,'OH','Ohio',53)/
INSERT INTO Region VALUES(1733,'OK','Oklahoma',53)/
INSERT INTO Region VALUES(1734,'OR','Oregon',53)/
INSERT INTO Region VALUES(1735,'PA','Pennsylvania',53)/
INSERT INTO Region VALUES(1736,'PR','Puerto Rico',53)/
INSERT INTO Region VALUES(1737,'RI','Rhode Island',53)/
INSERT INTO Region VALUES(1738,'SC','South Carolina',53)/
INSERT INTO Region VALUES(1739,'SD','South Dakota',53)/
INSERT INTO Region VALUES(1740,'TN','Tennessee',53)/
INSERT INTO Region VALUES(1741,'TX','Texas',53)/
INSERT INTO Region VALUES(1742,'UT','Utah',53)/
INSERT INTO Region VALUES(1743,'VA','Virginia',53)/
INSERT INTO Region VALUES(1744,'VI','Virgin Islands',53)/
INSERT INTO Region VALUES(1745,'VT','Vermont',53)/
INSERT INTO Region VALUES(1746,'WA','Washington',53)/
INSERT INTO Region VALUES(1747,'WI','Wisconsin',53)/
INSERT INTO Region VALUES(1748,'WV','West Virginia',53)/
INSERT INTO Region VALUES(1749,'WY','Wyoming',53)/
INSERT INTO Region VALUES(1750,'AMA','Amazon',54)/
INSERT INTO Region VALUES(1751,'ANZ','Anzoategui',54)/
INSERT INTO Region VALUES(1752,'APU','Apure',54)/
INSERT INTO Region VALUES(1753,'ARA','Aragua',54)/
INSERT INTO Region VALUES(1754,'BAR','Barinas',54)/
INSERT INTO Region VALUES(1755,'BOL','Bolivar',54)/
INSERT INTO Region VALUES(1756,'CAR','Carabobo',54)/
INSERT INTO Region VALUES(1757,'COJ','Cojedes',54)/
INSERT INTO Region VALUES(1758,'DA','Delta Amacuro',54)/
INSERT INTO Region VALUES(1759,'DF','Distrito Federal',54)/
INSERT INTO Region VALUES(1760,'FAL','Falcon',54)/
INSERT INTO Region VALUES(1761,'GUA','Guarico',54)/
INSERT INTO Region VALUES(1762,'LAR','Lara',54)/
INSERT INTO Region VALUES(1763,'MER','Merida',54)/
INSERT INTO Region VALUES(1764,'MIR','Miranda',54)/
INSERT INTO Region VALUES(1765,'MON','Monagas',54)/
INSERT INTO Region VALUES(1766,'NE','Nueva Esparta',54)/
INSERT INTO Region VALUES(1767,'POR','Portuguesa',54)/
INSERT INTO Region VALUES(1768,'SUC','Sucre',54)/
INSERT INTO Region VALUES(1769,'TAC','Tachira',54)/
INSERT INTO Region VALUES(1770,'TRU','Trujillo',54)/
INSERT INTO Region VALUES(1771,'VAR','Vargas',54)/
INSERT INTO Region VALUES(1772,'YAR','Yaracuy',54)/
INSERT INTO Region VALUES(1773,'ZUL','Zulia',54)/
INSERT INTO Region VALUES(1774,'1','Lai Chau',55)/
INSERT INTO Region VALUES(1775,'13','Quang Ninh',55)/
INSERT INTO Region VALUES(1776,'14','Hoa Binh',55)/
INSERT INTO Region VALUES(1777,'15','Ha Tay',55)/
INSERT INTO Region VALUES(1778,'18','Ninh Binh',55)/
INSERT INTO Region VALUES(1779,'2','Lao Cai',55)/
INSERT INTO Region VALUES(1780,'20','Thai Binh',55)/
INSERT INTO Region VALUES(1781,'21','Thanh Hoa',55)/
INSERT INTO Region VALUES(1782,'22','Nghe An',55)/
INSERT INTO Region VALUES(1783,'23','Ha Tinh',55)/
INSERT INTO Region VALUES(1784,'24','Quang Binh',55)/
INSERT INTO Region VALUES(1785,'25','Quang Tri',55)/
INSERT INTO Region VALUES(1786,'26','Thua Thien-Hue',55)/
INSERT INTO Region VALUES(1787,'27','Quang Nam',55)/
INSERT INTO Region VALUES(1788,'28','Kon Tum',55)/
INSERT INTO Region VALUES(1789,'29','Quang Ngai',55)/
INSERT INTO Region VALUES(1790,'3','Ha Giang',55)/
INSERT INTO Region VALUES(1791,'30','Gia Lai',55)/
INSERT INTO Region VALUES(1792,'31','Binh Dinh',55)/
INSERT INTO Region VALUES(1793,'32','Phu Yen',55)/
INSERT INTO Region VALUES(1794,'33','Dac Lac',55)/
INSERT INTO Region VALUES(1795,'34','Khanh Hoa',55)/
INSERT INTO Region VALUES(1796,'35','Lam Dong',55)/
INSERT INTO Region VALUES(1797,'36','Ninh Thuan',55)/
INSERT INTO Region VALUES(1798,'37','Tay Ninh',55)/
INSERT INTO Region VALUES(1799,'39','Dong Nai',55)/
INSERT INTO Region VALUES(1800,'4','Cao Bang',55)/
INSERT INTO Region VALUES(1801,'40','Binh Thuan',55)/
INSERT INTO Region VALUES(1802,'41','Long An',55)/
INSERT INTO Region VALUES(1803,'43','Ba Ria-Vung Tau',55)/
INSERT INTO Region VALUES(1804,'44','An Giang',55)/
INSERT INTO Region VALUES(1805,'45','Dong Thap',55)/
INSERT INTO Region VALUES(1806,'46','Tien Giang',55)/
INSERT INTO Region VALUES(1807,'47','Kien Giang',55)/
INSERT INTO Region VALUES(1808,'48','Cần Thơ',55)/
INSERT INTO Region VALUES(1809,'49','Vinh Long',55)/
INSERT INTO Region VALUES(1810,'5','Son La',55)/
INSERT INTO Region VALUES(1811,'50','Ben Tre',55)/
INSERT INTO Region VALUES(1812,'51','Tra Vinh',55)/
INSERT INTO Region VALUES(1813,'52','Soc Trang',55)/
INSERT INTO Region VALUES(1814,'53','Bac Cạn',55)/
INSERT INTO Region VALUES(1815,'54','Bac Giang',55)/
INSERT INTO Region VALUES(1816,'55','Bac Lieu',55)/
INSERT INTO Region VALUES(1817,'56','Bac Ninh',55)/
INSERT INTO Region VALUES(1818,'57','Binh Duong',55)/
INSERT INTO Region VALUES(1819,'58','Binh Phuoc',55)/
INSERT INTO Region VALUES(1820,'59','Ca Mau',55)/
INSERT INTO Region VALUES(1821,'6','Yen Bai',55)/
INSERT INTO Region VALUES(1822,'60','Thanh Pho Da Nang',55)/
INSERT INTO Region VALUES(1823,'61','Hai Duong',55)/
INSERT INTO Region VALUES(1824,'62','Thanh Pho Hai Phong',55)/
INSERT INTO Region VALUES(1825,'63','Ha Nam',55)/
INSERT INTO Region VALUES(1826,'64',' thu do',55)/
INSERT INTO Region VALUES(1827,'65','Thanh Pho Ho Chi Min',55)/
INSERT INTO Region VALUES(1828,'66','Hung Yen',55)/
INSERT INTO Region VALUES(1829,'67','Nam Dinh',55)/
INSERT INTO Region VALUES(1830,'68','Phu Tho',55)/
INSERT INTO Region VALUES(1831,'69','Thai Nguyen',55)/
INSERT INTO Region VALUES(1832,'7','Tuyen Quang',55)/
INSERT INTO Region VALUES(1833,'70','Vinh Phuc',55)/
INSERT INTO Region VALUES(1834,'71','Dien Bien',55)/
INSERT INTO Region VALUES(1835,'72','Dak Nong',55)/
INSERT INTO Region VALUES(1836,'73','Hau Giang',55)/
INSERT INTO Region VALUES(1837,'9','Lang Son',55)/
INSERT INTO Region VALUES(1838,'EC','Eastern Cape',43)/
INSERT INTO Region VALUES(1839,'FS','Freestate',43)/
INSERT INTO Region VALUES(1840,'GP','Gauteng',43)/
INSERT INTO Region VALUES(1841,'KZN','Kwazulu/Natal',43)/
INSERT INTO Region VALUES(1842,'LP','Limpopo',43)/
INSERT INTO Region VALUES(1843,'MP','Mpumalanga',43)/
INSERT INTO Region VALUES(1844,'NC','Northern Cape',43)/
INSERT INTO Region VALUES(1845,'NP','Northern Province',43)/
INSERT INTO Region VALUES(1846,'NW','North-West',43)/
INSERT INTO Region VALUES(1847,'WC','Western Cape',43)/
INSERT INTO Region VALUES(1848,'ZN','KwaZulu-Natal',43)/
INSERT INTO Region VALUES(1849, '0', 'Capital Federal', 56)/
INSERT INTO Region VALUES(1850, '1', 'Buenos Aires', 56)/
INSERT INTO Region VALUES(1851, '10', 'San Juan', 56)/
INSERT INTO Region VALUES(1852, '11', 'San Luis', 56)/
INSERT INTO Region VALUES(1853, '12', 'Santa Fé', 56)/
INSERT INTO Region VALUES(1854, '13', 'Santiago del Estero', 56)/
INSERT INTO Region VALUES(1855, '14', 'Tucumán', 56)/
INSERT INTO Region VALUES(1856, '16', 'Chaco', 56)/
INSERT INTO Region VALUES(1857, '17', 'Chubut', 56)/
INSERT INTO Region VALUES(1858, '18', 'Formosa', 56)/
INSERT INTO Region VALUES(1859, '19', 'Misiones', 56)/
INSERT INTO Region VALUES(1860, '2', 'Catamarca', 56)/
INSERT INTO Region VALUES(1861, '20', 'Neuquen', 56)/
INSERT INTO Region VALUES(1862, '21', 'La Pampa', 56)/
INSERT INTO Region VALUES(1863, '22', 'Rio Negro', 56)/
INSERT INTO Region VALUES(1864, '23', 'Santa Cruz', 56)/
INSERT INTO Region VALUES(1865, '24', 'Tierra de Fuego', 56)/
INSERT INTO Region VALUES(1866, '3', 'Córdoba', 56)/
INSERT INTO Region VALUES(1867, '4', 'Corrientes', 56)/
INSERT INTO Region VALUES(1868, '5', 'Entre Rios', 56)/
INSERT INTO Region VALUES(1869, '6', 'Jujuy', 56)/
INSERT INTO Region VALUES(1870, '7', 'Mendoza', 56)/
INSERT INTO Region VALUES(1871, '8', 'La Rioja', 56)/
INSERT INTO Region VALUES(1872, '9', 'Salta', 56)/

INSERT INTO BillingType VALUES(1, 'Time and Materials', '02')/
INSERT INTO BillingType VALUES(2, 'Fixed Price', '01')/
INSERT INTO BillingType VALUES(3, 'Event Based', '03')/

INSERT INTO ScreenerInterviewer VALUES(1, 'Screener')/
INSERT INTO ScreenerInterviewer VALUES(2, 'Interviewer')/

INSERT INTO ResourceType VALUES(1, 'Employee', '02')/
INSERT INTO ResourceType VALUES(2, 'Contractor', '01')/
INSERT INTO ResourceType VALUES(3, 'VSD', '03')/

INSERT INTO DeliverAction VALUES(1, 'Submit LOE', 'LOEMD', 'LOE is used when you want to send Resource Managers an Early Demand request for resources associated with an opportunity.   For opportunities that have more than one material number on them - excluding expenses - a separate demand request needs to be delivered.  The rule is one demand, one BU, one Material Number.  Only one of these file codes can be initiated per project.')/
INSERT INTO DeliverAction VALUES(2, 'Submit Quote BOE', 'BOEQT', 'Quote BOE is used to create a quote in DXP for sales to incorporate pricing into a proposal or SOW.  If the negotiations between the Client and the EMC team change any of the scope or BOE particulars, a subsequent Quote BOE must be submitted.  These (Quote BOE) file codes can be sent multiple times to reflect the changes to the project for pricing purposes.')/
INSERT INTO DeliverAction VALUES(3, 'Submit Final BOE', 'BOEFN', 'The Final BOE is used when an SOW has been presented to the customer and is likely to be signed.  A Final BOE can be approved in DxP and used to price an engagement.  An unlimited number of Final BOE‚Äôs can be submitted to DxP in support of the sales process and changes in scope.')/
INSERT INTO DeliverAction VALUES(4, 'Submit SAR', 'BOEAR', 'SAR is used when the signing of the SOW has been moved out due to circumstances beyond the client''s control and the project needs to start prior to the signature being obtained.  A Quote BOE is a prerequisite for this type of request.  If the SOW is signed, a Final BOE SAR MUST be sent to complete the process once a SAR file has been sent and a SAR project has been established.  Only one of these file codes can be initiated per project.')/
INSERT INTO DeliverAction VALUES(5, 'Submit Change Request', 'BOECR', 'A request that refers to extending, reducing, or incrementing existing contract is a project change request and will require a BOE (Estimating Tool / EDGE) to increase or decrease the price of the contract and that will automatically update the Sales Order.  In this case, the Project WBS will be manually updated.  It is critical that the WBS number be put on the CR BOE so the funding can be associated to the appropriate project in SD and PS.  See local instructions to determine what is a CR and what is not.')/
INSERT INTO DeliverAction VALUES(6, 'Submit Cancel', 'BOECN', 'Cancel is used to close an Early Demand opportunity or Quote BOE.  You cannot use a Cancel order on SAR/PD or POC order a Final SAR BOE must be submitted.  Cancel orders will notify the Resource Manager that the need for the request no longer exists and the resources should be removed from the request. For Quote BOE cancellation orders, the information will be archived from the BAPI.  Only one of these file codes will be initiated per opportunity.')/
INSERT INTO DeliverAction VALUES(7, 'Submit Final BOE SAR', 'BOESR', 'Final BOE SAR - If a SAR is initiated and work begins, a Final BOE SAR must be submitted.   If the contract is not signed then this BOE must reflect the work effort that was consumed during the SAR and must carry the end date of the SAR project.   This activity type will be treated as if it were a Final BOE in DXP and allowed to pass the Submitted to Quote edit.')/
INSERT INTO DeliverAction VALUES(8, 'Submit MS/RSA Final BOE', 'RMFBO', 'This activity code is for MS and RSA projects only its main purpose is to create a project in SAP.  For RSA it will also link the project funding from SD to the individual WBS elements then build a current and booked budget.  For MS no funding will be provided but a current and booked budget will be built.')/
INSERT INTO DeliverAction VALUES(9, 'Submit MS/RSA SAR', 'RMSSR', 'This activity code is for MS and RSA.  This will permit the creation of a project prior to the completion of a sale.  This activity will build a project, and send demand to MRS for staffing.   Once the project is created individuals can charge time and expenses to the project.')/
INSERT INTO DeliverAction VALUES(10, 'Submit MS/RSA Final BOE SAR', 'RMSRB', 'This activity performs the linking of funding for RSA files along with building the booked version.  For MS it creates the booked version, however it does not link funding.  Prior to issuing a Final BOE SAR, a SAR project must first be completed')/
INSERT INTO DeliverAction VALUES(11, 'Submit MS/RSA Change Request', 'RMSCR', 'A request that refers to extending, reducing, or incrementing existing contract is a project change request and will require a BOE (Estimating Tool / EDGE) to increase or decrease the price of the contract and that will automatically update the Sales Order.  In this case, the Project WBS will be manually updated.  It is critical that the WBS number be put on the CR BOE so the funding can be associated to the appropriate project in SD and PS.   See local instructions to determine what is a CR and what is not')/

INSERT INTO ProjectRegulatoryType VALUES(1, 'Commercial', '01')/
INSERT INTO ProjectRegulatoryType VALUES(2, 'Federal', '02')/
INSERT INTO ProjectRegulatoryType VALUES(3, 'Internal Delivery', '03')/
INSERT INTO ProjectRegulatoryType VALUES(4, 'Public Sector', '04')/

INSERT INTO ExpenseType VALUES(1, 'Expenses Included')/
INSERT INTO ExpenseType VALUES(2, 'Billed Separately')/
INSERT INTO ExpenseType VALUES(3, 'None')/

INSERT INTO NetworkerDatazoneSize VALUES(1, 'Small')/
INSERT INTO NetworkerDatazoneSize VALUES(2, 'Medium')/
INSERT INTO NetworkerDatazoneSize VALUES(3, 'Large')/

INSERT INTO MeditechBackupType VALUES(1, 'ISB')/
INSERT INTO MeditechBackupType VALUES(2, 'IDR')/
INSERT INTO MeditechBackupType VALUES(3, 'IDR/ISB')/

INSERT INTO IntelligentFabricMigrationMet VALUES (1, 'Dual Splitter Assignment Existing VMAX')/
INSERT INTO IntelligentFabricMigrationMet VALUES (2, 'Splitter Re-assignment Existing Array')/
INSERT INTO IntelligentFabricMigrationMet VALUES (3, 'VPLEX Encapsulation Existing Array')/
INSERT INTO IntelligentFabricMigrationMet VALUES (4, 'VPLEX Encapsulation New Array')/
INSERT INTO IntelligentFabricMigrationMet VALUES (5, 'Host Based Mirroring New Array')/
INSERT INTO IntelligentFabricMigrationMet VALUES (6, 'Array Based Migration New Array')/

INSERT INTO RecoverPointOption VALUES (1, 'RecoverPoint/CL')/
INSERT INTO RecoverPointOption VALUES (2, 'RecoverPoint/SE')/
INSERT INTO RecoverPointOption VALUES (3, 'RecoverPoint/EX')/

INSERT INTO RecoverPointSplitterType VALUES (1, 'VNX Splitter')/
INSERT INTO RecoverPointSplitterType VALUES (2, 'CLARiiON Splitter')/
INSERT INTO RecoverPointSplitterType VALUES (3, 'VMAX Family Splitter')/
INSERT INTO RecoverPointSplitterType VALUES (4, 'VMAX 10k Splitter')/
INSERT INTO RecoverPointSplitterType VALUES (5, 'VPLEX Splitter')/
INSERT INTO RecoverPointSplitterType VALUES (6, 'Host Based Splitter')/
INSERT INTO RecoverPointSplitterType VALUES (7, 'CISCO - SANtap')/
INSERT INTO RecoverPointSplitterType VALUES (8, 'Brocade - FAP')/

INSERT INTO MultipleTheatersLangsInvOpt VALUES (1, 'No', 0)/
INSERT INTO MultipleTheatersLangsInvOpt VALUES (2, '1 Theater, 2 Languages', 5)/
INSERT INTO MultipleTheatersLangsInvOpt VALUES (3, '2 Theaters, 1 Language', 10)/
INSERT INTO MultipleTheatersLangsInvOpt VALUES (4, '2 Theaters, 2 Languages', 10)/
INSERT INTO MultipleTheatersLangsInvOpt VALUES (5, '3+ Theaters or Languages', 15)/

INSERT INTO MultipleWorkgroupsDiscOpt VALUES (1, 'No', 0)/
INSERT INTO MultipleWorkgroupsDiscOpt VALUES (2, 'Yes, 2', 5)/
INSERT INTO MultipleWorkgroupsDiscOpt VALUES (3, 'Yes, more than 2', 20)/

INSERT INTO EMCClientOption VALUES (1, 'Existing, current project extension', 0)/
INSERT INTO EMCClientOption VALUES (2, 'Existing, new project', 5)/
INSERT INTO EMCClientOption VALUES (3, 'New', 10)/

INSERT INTO EMCClientRelationshipOption VALUES (1, 'Positive', 0)/
INSERT INTO EMCClientRelationshipOption VALUES (2, 'Neutral', 10)/
INSERT INTO EMCClientRelationshipOption VALUES (3, 'Negative', 20)/

INSERT INTO ProcessStaffMaturityOption VALUES (1, 'Well Defined, Internal Resources', 0)/
INSERT INTO ProcessStaffMaturityOption VALUES (2, 'Undefined, Internal Resources', 10)/
INSERT INTO ProcessStaffMaturityOption VALUES (3, 'Well Defined, Partner Resources', 10)/
INSERT INTO ProcessStaffMaturityOption VALUES (4, 'Undefined, Partner Resources', 20)/
INSERT INTO ProcessStaffMaturityOption VALUES (5, 'Unknown', 10)/

INSERT INTO ClientEnvDocumentationOption VALUES (1, 'Extensive Documentation', 0)/
INSERT INTO ClientEnvDocumentationOption VALUES (2, 'Limited Documentation', 10)/
INSERT INTO ClientEnvDocumentationOption VALUES (3, 'No Documentation', 20)/

INSERT INTO ProjectScopeUnderstandOption VALUES (1, 'Scope clearly documented', 0)/
INSERT INTO ProjectScopeUnderstandOption VALUES (2, 'Minor ambiguity in scope', 5)/
INSERT INTO ProjectScopeUnderstandOption VALUES (3, 'Scope partially defined', 10)/
INSERT INTO ProjectScopeUnderstandOption VALUES (4, 'Significant ambiguity', 20)/

INSERT INTO ProjectImpactOption VALUES (1, 'Normal strategic impact', 0)/
INSERT INTO ProjectImpactOption VALUES (2, 'Moderate strategic impact', 5)/
INSERT INTO ProjectImpactOption VALUES (3, 'High strategic impact', 10)/
INSERT INTO ProjectImpactOption VALUES (4, 'Business critical', 20)/

INSERT INTO ProjectSponsorInvOption VALUES (1, 'Highly involved', 0)/
INSERT INTO ProjectSponsorInvOption VALUES (2, 'Moderately involved', 5)/
INSERT INTO ProjectSponsorInvOption VALUES (3, 'Limited involvement', 10)/
INSERT INTO ProjectSponsorInvOption VALUES (4, 'Point of escalation only', 20)/
INSERT INTO ProjectSponsorInvOption VALUES (5, 'Not involved', 30)/

INSERT INTO OfferingMaturityOption VALUES (1, 'Fully Mature', 0)/
INSERT INTO OfferingMaturityOption VALUES (2, 'Maturing Offering', 5)/
INSERT INTO OfferingMaturityOption VALUES (3, 'New Offering', 10)/
INSERT INTO OfferingMaturityOption VALUES (4, 'New Offering and New Technology', 15)/
INSERT INTO OfferingMaturityOption VALUES (5, 'Unknown', 20)/

INSERT INTO ProjectComplexityLevelOption VALUES (1, 'Simple', 0)/
INSERT INTO ProjectComplexityLevelOption VALUES (2, 'Average', 5)/
INSERT INTO ProjectComplexityLevelOption VALUES (3, 'Difficult', 10)/
INSERT INTO ProjectComplexityLevelOption VALUES (4, 'Very Difficult', 20)/

INSERT INTO ExternalFactorsOption VALUES (1, 'No external factors', 0)/
INSERT INTO ExternalFactorsOption VALUES (2, 'Factors known and scheduled', 5)/
INSERT INTO ExternalFactorsOption VALUES (3, 'Factors unknown or unscheduled', 10)/

INSERT INTO EMCStaffAvailabilityOption VALUES (1, 'Experienced resources available', 0)/
INSERT INTO EMCStaffAvailabilityOption VALUES (2, 'Experienced resources unavailable', 5)/
INSERT INTO EMCStaffAvailabilityOption VALUES (3, 'Need to hire', 10)/
INSERT INTO EMCStaffAvailabilityOption VALUES (4, 'Unknown', 10)/

INSERT INTO PartnerStaffAvailOption VALUES (1, 'Not partner eligible', 0)/
INSERT INTO PartnerStaffAvailOption VALUES (2, 'Trusted partner available', 5)/
INSERT INTO PartnerStaffAvailOption VALUES (3, 'New partner available', 10)/
INSERT INTO PartnerStaffAvailOption VALUES (4, 'Unknown', 10)/

INSERT INTO RiskLevelOption VALUES (1, 'No', 0)/
INSERT INTO RiskLevelOption VALUES (2, 'Add low level risk', 5)/
INSERT INTO RiskLevelOption VALUES (3, 'Add medium level risk', 10)/
INSERT INTO RiskLevelOption VALUES (4, 'Add high level risk', 20)/

INSERT INTO EMCFederatedCompaniesInvOpt VALUES (1, 'No', 0)/
INSERT INTO EMCFederatedCompaniesInvOpt VALUES (2, 'Yes', 10)/

INSERT INTO ThirdPartyInvolvementOption VALUES (1, 'No', 0)/
INSERT INTO ThirdPartyInvolvementOption VALUES (2, 'Yes', 10)/

INSERT INTO TMBillingUsageOption VALUES (1, 'Yes', 0)/
INSERT INTO TMBillingUsageOption VALUES (2, 'No', 20)/

INSERT INTO EMCAccountabilityOption VALUES (1, 'No', 0)/
INSERT INTO EMCAccountabilityOption VALUES (2, 'Yes', 10)/

INSERT INTO ProgramMgmtUseCaseOption VALUES (1, 'No Program Management support needed')/
INSERT INTO ProgramMgmtUseCaseOption VALUES (2, 'Complex Engagement')/
INSERT INTO ProgramMgmtUseCaseOption VALUES (3, 'Portfolio Aligned Project/Program Management Services')/


INSERT INTO DiscountFloorType VALUES (1, 'None', 'green-text')/
INSERT INTO DiscountFloorType VALUES (2, '1 - CSD', 'green-text')/
INSERT INTO DiscountFloorType VALUES (3, '2- MCSD', 'green-text')/
INSERT INTO DiscountFloorType VALUES (4, '3 - Division GSL', 'yellow-text')/
INSERT INTO DiscountFloorType VALUES (5, '4 - Theater GSL', 'yellow-text')/
INSERT INTO DiscountFloorType VALUES (6, '5 - Global GSL', 'red-text')/

INSERT INTO DiscountFloorGroup VALUES (1, 'Discount Floor 1 (EMC)')/
INSERT INTO DiscountFloorGroup VALUES (2, 'Discount Floor 2 (ECD)')/
INSERT INTO DiscountFloorGroup VALUES (3, 'Discount Floor 3 (RSA)')/
INSERT INTO DiscountFloorGroup VALUES (4, 'Discount Floor 4 (MS)')/

INSERT INTO DiscountFloor VALUES (1, 1, 1, -99.99)/
INSERT INTO DiscountFloor VALUES (2, 1, 2, 5.00)/
INSERT INTO DiscountFloor VALUES (3, 1, 3, 15.00)/
INSERT INTO DiscountFloor VALUES (4, 1, 4, 20.00)/
INSERT INTO DiscountFloor VALUES (5, 1, 5, 25.00)/
INSERT INTO DiscountFloor VALUES (6, 1, 6, 35.00)/

INSERT INTO DiscountFloor VALUES (7, 2, 1, -99.99)/
INSERT INTO DiscountFloor VALUES (8, 2, 2, 5.00)/
INSERT INTO DiscountFloor VALUES (9, 2, 3, 15.00)/
INSERT INTO DiscountFloor VALUES (10, 2, 4, 20.00)/
INSERT INTO DiscountFloor VALUES (11, 2, 5, 25.00)/
INSERT INTO DiscountFloor VALUES (12, 2, 6, 35.00)/

INSERT INTO DiscountFloor VALUES (13, 3, 1, -99.99)/
INSERT INTO DiscountFloor VALUES (14, 3, 2, 5.00)/
INSERT INTO DiscountFloor VALUES (15, 3, 3, 15.00)/
INSERT INTO DiscountFloor VALUES (16, 3, 4, 20.00)/
INSERT INTO DiscountFloor VALUES (17, 3, 5, 25.00)/
INSERT INTO DiscountFloor VALUES (18, 3, 6, 35.00)/

INSERT INTO DiscountFloor VALUES (19, 4, 1, -99.99)/
INSERT INTO DiscountFloor VALUES (20, 4, 2, 5.00)/
INSERT INTO DiscountFloor VALUES (21, 4, 3, 15.00)/
INSERT INTO DiscountFloor VALUES (22, 4, 4, 20.00)/
INSERT INTO DiscountFloor VALUES (23, 4, 5, 25.00)/
INSERT INTO DiscountFloor VALUES (24, 4, 6, 35.00)/

INSERT INTO NetworkServiceTemplateType VALUES(1, 'EMC Assessment for IP Network Replication')/
INSERT INTO NetworkServiceTemplateType VALUES(2, 'FCoE Infrastructure Assessment')/

INSERT INTO LANInfraComplexityType VALUES(1, 'Low')/
INSERT INTO LANInfraComplexityType VALUES(2, 'Medium')/
INSERT INTO LANInfraComplexityType VALUES(3, 'High')/

INSERT INTO DCLocationsAnalysisNumber VALUES(1, '1')/
INSERT INTO DCLocationsAnalysisNumber VALUES(2, '2')/
INSERT INTO DCLocationsAnalysisNumber VALUES(3, '3')/
INSERT INTO DCLocationsAnalysisNumber VALUES(4, '4')/
INSERT INTO DCLocationsAnalysisNumber VALUES(5, '5')/

INSERT INTO RecoveryLevelType VALUES(1, 'Object Level Recovery')/
INSERT INTO RecoveryLevelType VALUES(2, 'Full LUN Recovery')/

CREATE SEQUENCE SIPEDUData
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE
/
CREATE TABLE IPEDUData (
  id NUMBER NOT NULL PRIMARY KEY,
  estimates_data_id  NUMBER,
  data_type   VARCHAR2(3),
  material_id NUMBER,
  competency_id NUMBER,
  hosts_number INT,
  amount DECIMAL(20, 2),
  FOREIGN KEY (estimates_data_id) REFERENCES EstimatesData (id),
  FOREIGN KEY (material_id) REFERENCES MaterialCode (id),
  FOREIGN KEY (competency_id) REFERENCES Competency (id)
)/

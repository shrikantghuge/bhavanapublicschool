INSERT INTO pdmname VALUES(131, 'Bharath Cadambi', '', '', '', '', '', '', '', '', '', '', 7);

UPDATE pdmname SET pdm_name = 'Mahmood Shaker' WHERE id = 60;
UPDATE pdmname SET pdm_name = 'Suzanne Seif' WHERE id = 67;
UPDATE pdmname SET pdm_name = 'Michael Hutchinson' WHERE id = 74;
UPDATE pdmname SET pdm_name = 'Koen Segers' WHERE id = 87;
UPDATE pdmname SET pdm_name = 'Wojciech Pliszka' WHERE id = 126;

UPDATE salesdistrict SET default_pdm_id = 131 WHERE id IN (261,262);
UPDATE salesdistrict SET default_pdm_id = 60 WHERE default_pdm_id IN (61,62,63,64,65,66);
UPDATE salesdistrict SET default_pdm_id = 67 WHERE default_pdm_id IN (68,69,70);
UPDATE salesdistrict SET default_pdm_id = 74 WHERE default_pdm_id IN (75);
UPDATE salesdistrict SET default_pdm_id = 87 WHERE default_pdm_id IN (88);
UPDATE salesdistrict SET default_pdm_id = 126 WHERE default_pdm_id IN (128,129);

DELETE FROM pdmname WHERE id IN (61,62,63,64,65,66,68,69,70,75,88,128,129);

INSERT INTO SalesDistrict VALUES(320, 'BRS - South', 'Germany', '', 15, 82);
INSERT INTO SalesDistrict VALUES(321, 'BRS - Central', 'Germany', '', 15, 83);
INSERT INTO SalesDistrict VALUES(322, 'BRS - North', 'Germany', '', 15, 84);

INSERT INTO SalesDistrict VALUES(323, 'France - BRS', 'France', '', 14, 79);

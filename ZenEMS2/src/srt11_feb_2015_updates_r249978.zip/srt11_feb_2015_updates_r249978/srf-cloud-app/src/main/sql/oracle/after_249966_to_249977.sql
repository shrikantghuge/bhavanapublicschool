CREATE SEQUENCE SIsilonNetAppNodeBaseMigration
    INCREMENT BY 1 START WITH 1000 NOMAXVALUE NOCYCLE
/
CREATE TABLE IsilonNetAppNodeBaseMigration (
    id NUMBER NOT NULL PRIMARY KEY,
    source_system_type VARCHAR(256),
    capacity_nodes_num_1 INT,
    capacity_nodes_num_2 INT,
    capacity_nodes_num_3 INT,
    capacity_nodes_num_4 INT,
    capacity_nodes_num_5 INT,
    multi_protocol_data NUMBER(1),
    wide_links NUMBER(1),
    historical_sids NUMBER(1),
    local_users_groups NUMBER(1),
    archived_data NUMBER(1),
    cutovers_num INT
)
/

ALTER TABLE IsilonMigration ADD net_app_node_migration NUMBER(1) DEFAULT 0/
ALTER TABLE IsilonMigration ADD net_app_node_id NUMBER/
ALTER TABLE IsilonMigration ADD FOREIGN KEY (net_app_node_id) REFERENCES IsilonNetAppNodeBaseMigration (id)/

ALTER TABLE EstimatesData ADD sow_number VARCHAR(256);
ALTER TABLE EstimatesData ADD contract_number VARCHAR(256);

INSERT INTO SowLanguage VALUES (5, 'Chinese (Simplified)');
INSERT INTO SowLanguage VALUES (6, 'French');
INSERT INTO SowLanguage VALUES (7, 'German');
INSERT INTO SowLanguage VALUES (8, 'Italian');
INSERT INTO SowLanguage VALUES (9, 'Japanese');
INSERT INTO SowLanguage VALUES (10, 'Korean');
INSERT INTO SowLanguage VALUES (11, 'UK English');

INSERT INTO Geography VALUES (3, 'EMEA');
INSERT INTO Geography VALUES (4, 'APJ');

CREATE TABLE DiscountFloorType (
  id   BIGINT AUTO_INCREMENT NOT NULL PRIMARY KEY,
  name VARCHAR(256)          NOT NULL,
  code VARCHAR(256)          NOT NULL
);

CREATE TABLE DiscountFloorGroup (
  id   BIGINT AUTO_INCREMENT NOT NULL PRIMARY KEY,
  name VARCHAR(256)          NOT NULL
);

CREATE TABLE DiscountFloor (
  id        BIGINT AUTO_INCREMENT NOT NULL PRIMARY KEY,
  group_id  BIGINT,
  type_id   BIGINT,
  threshold DECIMAL(10, 2),
  FOREIGN KEY (group_id) REFERENCES DiscountFloorGroup (id),
  FOREIGN KEY (type_id) REFERENCES DiscountFloorType (id)
);


INSERT INTO DiscountFloorType VALUES (1, 'None', 'green-text');
INSERT INTO DiscountFloorType VALUES (2, '1 - CSD', 'green-text');
INSERT INTO DiscountFloorType VALUES (3, '2- MCSD', 'green-text');
INSERT INTO DiscountFloorType VALUES (4, '3 - Division GSL', 'yellow-text');
INSERT INTO DiscountFloorType VALUES (5, '4 - Theater GSL', 'yellow-text');
INSERT INTO DiscountFloorType VALUES (6, '5 - Global GSL', 'red-text');

INSERT INTO DiscountFloorGroup VALUES (1, 'Discount Floor 1 (EMC)');
INSERT INTO DiscountFloorGroup VALUES (2, 'Discount Floor 2 (ECD)');
INSERT INTO DiscountFloorGroup VALUES (3, 'Discount Floor 3 (RSA)');
INSERT INTO DiscountFloorGroup VALUES (4, 'Discount Floor 4 (MS)');

INSERT INTO DiscountFloor VALUES (1, 1, 1, -99.99);
INSERT INTO DiscountFloor VALUES (2, 1, 2, 5.00);
INSERT INTO DiscountFloor VALUES (3, 1, 3, 15.00);
INSERT INTO DiscountFloor VALUES (4, 1, 4, 20.00);
INSERT INTO DiscountFloor VALUES (5, 1, 5, 25.00);
INSERT INTO DiscountFloor VALUES (6, 1, 6, 35.00);

INSERT INTO DiscountFloor VALUES (7, 2, 1, -99.99);
INSERT INTO DiscountFloor VALUES (8, 2, 2, 5.00);
INSERT INTO DiscountFloor VALUES (9, 2, 3, 15.00);
INSERT INTO DiscountFloor VALUES (10, 2, 4, 20.00);
INSERT INTO DiscountFloor VALUES (11, 2, 5, 25.00);
INSERT INTO DiscountFloor VALUES (12, 2, 6, 35.00);

INSERT INTO DiscountFloor VALUES (13, 3, 1, -99.99);
INSERT INTO DiscountFloor VALUES (14, 3, 2, 5.00);
INSERT INTO DiscountFloor VALUES (15, 3, 3, 15.00);
INSERT INTO DiscountFloor VALUES (16, 3, 4, 20.00);
INSERT INTO DiscountFloor VALUES (17, 3, 5, 25.00);
INSERT INTO DiscountFloor VALUES (18, 3, 6, 35.00);

INSERT INTO DiscountFloor VALUES (19, 4, 1, -99.99);
INSERT INTO DiscountFloor VALUES (20, 4, 2, 5.00);
INSERT INTO DiscountFloor VALUES (21, 4, 3, 15.00);
INSERT INTO DiscountFloor VALUES (22, 4, 4, 20.00);
INSERT INTO DiscountFloor VALUES (23, 4, 5, 25.00);
INSERT INTO DiscountFloor VALUES (24, 4, 6, 35.00);

ALTER TABLE MaterialCode ADD discount_group_id BIGINT NOT NULL DEFAULT 1;
UPDATE MaterialCode SET discount_group_id = lob_id;

-- Routing data updates
UPDATE division SET division_name = 'LATAM - Brazil' WHERE id = 1;
UPDATE division SET division_name = 'LATAM - Mexico' WHERE id = 5;
UPDATE division SET division_name = 'MASE' WHERE id = 6;
UPDATE division SET division_name = 'NE/Canada' WHERE id = 7;
UPDATE division SET division_name = 'NY NJ' WHERE id = 8;
UPDATE division SET division_name = 'LATAM - Soco' WHERE id = 10;
UPDATE division SET division_name = 'LATAM - NoLa' WHERE id = 11;
UPDATE division SET division_name = 'APJ' WHERE id = 12;
INSERT INTO Division values(17, 'West-EMEA', '', 'West-EMEA');

UPDATE pdmname SET division_id = 17 WHERE id BETWEEN 86 AND 96;

-- New PDM names from SRT-112
INSERT INTO pdmname VALUES(97, 'Vaibhav Sabharwal', 'Program Delivery Manager', '300 Conshohocken State Rd', 'Suite 700', 'Conshohocken', 'PA', '19428', '', '', '(704) 780 4089', 'Vaibhav.Sabharwal@emc.com', 6);
INSERT INTO pdmname VALUES(98, 'Bob Martin', 'Program Delivery Manager', '14755 Preston Road', 'Suite 200', 'Dallas', 'Texas', '75154', 'None', 'None', '(972) 439-2633', 'robert.martin@emc.com', 6);
INSERT INTO pdmname VALUES(99, 'Robin Aurilio', 'Sr Mgr, Professional Services', '300 Conshohocken State Road', 'Suite 700', 'Conshohocken', 'Pennsylvania', '19428', '(610)276-3031', 'None', '(917)539-6099', 'robin.aurilio@emc.com', 6);
INSERT INTO pdmname VALUES(100, 'Diego Faria', 'Delivery Manager', 'Av Rio Negro, 161', '8 Andar', 'Barueri', 'Sao Paulo', '06455-020', '55-11-2078-1563', '55-11-2078-1699', '55-11-97661-7605', 'diego.faria@emc.com', 1);
INSERT INTO pdmname VALUES(101, 'Ben Elliott', 'Program Delivery Manager', '36555 Corporate Drive', '2nd Floor', 'Farmington Hills', 'Michigan', '48331', '(248) 957-5834', 'None', '(734)-904-2828', 'ben.elliott@emc.com', 2);
INSERT INTO pdmname VALUES(102, 'Brandon Smith', 'Program Delivery Manager', '2201 Dupont Drive', 'Suite 500', 'Irvine', 'California', '92612', '(949) 797-3304', '(949) 833-0690', '(949) 202-7052', 'brandon.smith@emc.com', 2);
INSERT INTO pdmname VALUES(103, 'Calvin Williams', 'Program Delivery Manager', '4225 Naperville Road', 'Suite 500', 'Lisle', 'Illinois', '60532', '', '(866) 569-2727', '(262) 496-0716', 'calvin.williams@emc.com', 2);
INSERT INTO pdmname VALUES(104, 'Christina Stichweh', 'Program Delivery Manager', '9200 Worthington Rd.', 'Suite 200', 'Columbus', 'OH', '43085', '(614) 797-5673', '', '(614) 572-7145', 'christina.stichweh@emc.com', 2);
INSERT INTO pdmname VALUES(105, 'Nathan Mondragon', 'Program Delivery Manager', '8000 South Chester St', 'Suite 600', 'Englewood', 'Colorado', '80112', '(303) 390-7016', '(303) 200-8133', '(720) 413-9267', 'nathan.mondragon@emc.com', 2);
INSERT INTO pdmname VALUES(106, 'Geoff Wise', 'Program Delivery Manager', '8888 Keystone Crossing', 'Suite 700', 'Indianapolis', 'Indiana', '46240', '(317) 690-2617', '', '', 'geoff.wise@emc.com', 2);
INSERT INTO pdmname VALUES(107, 'Pramod Kumar C K', 'Program Delivery Manager', 'Bagmane Developers Pvt ltd', 'SEZ, , Marathahalli Ring Road, Dodanekundi Vilage', 'Bangalore', 'Karnataka', '560037', '1.800-782-4362 Extn-785 4124', '1-949-258-5502', '91-9611984499', 'pramod.kumar2@emc.com', 2);
INSERT INTO pdmname VALUES(108, 'Mike O''Neill', 'Program Delivery Manager', '120 Adelaide Street West', '', 'Toronto', 'Ontario (Canada)', 'M5H 1T1', '(902) 222-1402', '', '', 'mike.oneill@emc.com', 7);
INSERT INTO pdmname VALUES(109, 'Rosie Robinson', 'Program Delivery Manager', '555 Burrard Street', '', 'Vancouver', 'British Columbia (Canada)', 'V7X 1B1', '(416) 434-2247', '', '', 'rosie.robinson@emc.com', 7);
INSERT INTO pdmname VALUES(110, 'Mark Harrington', 'Program Delivery Manager', '95 Wells Ave', '', 'Newton', 'Massachusetts', '02459', '(508) 864-7474', '', '', 'mark.harrington@emc.com', 7);
INSERT INTO pdmname VALUES(111, 'Glenn Steinhandler', 'Program Delivery Manager', '184 Liberty Corner Rd', '4th Flr', 'Warren', 'New Jersey', '07059', '(908) 286-7676', 'None', '(732) 453-4055', 'gabriel.dupas@emc.com', 8);
INSERT INTO pdmname VALUES(112, 'Joe Farrugia', 'Program Delivery Manager', '184 Liberty Corner Rd', '4th Flr', 'Warren', 'New Jersey', '07059', '(908) 286-3896', 'None', '(973)868-7372', 'joseph.farrugia@emc.com', 8);
INSERT INTO pdmname VALUES(113, 'Robert Zutterman', 'Program Delivery Manager', '184 Liberty Corner Rd', '4th Flr', 'Warren', 'New Jersey', '07059', '', '', '', '', 8);
INSERT INTO pdmname VALUES(114, 'Sabareesan Balasubramaniam', 'Program Delivery Manager', 'Bagmane Tech Park', '', 'Bangalore', 'India', '', '1-800-782-4362 x7854274', '', '303-954-4343', 'Sabareesan.balasubramaniam@emc.com', 9);
INSERT INTO pdmname VALUES(115, 'Dave Hunt', 'Program Delivery Manager', '250 Montgomery Street', 'Suite 400', 'San Francisco', 'California', '94104', '(916) 221-2268', '', '', 'dave.hunt@emc.com', 9);
INSERT INTO pdmname VALUES(116, 'Mark Hutchings', 'Program Delivery Manager', '15500 SE 30th Place', 'Suite 200', 'Bellevue', 'Washington', '98007', '(425) 748-3220', '', '(206) 437-3085', 'mark.hutchings@emc.com', 9);
INSERT INTO pdmname VALUES(117, 'Jossh Gladness', 'Program Delivery Manager', '2201 Dupont Drive', 'Suite 500', 'Irvine', 'California', '92612', '(949) 797-2295', '(949) 833-0690', '(949) 373-6464', 'josh.norige@emc.com', 9);
INSERT INTO pdmname VALUES(118, 'Kathy Dugas', 'Program Delivery Manager', '4250 N. Drinkwater Blvd', 'Suite 200', 'Scottsdale', 'Arizona', '85260', '(480) 874-7946', '(480) 425-1247', '(480) 299-6485', 'kathy.dugas@emc.com', 9);
INSERT INTO pdmname VALUES(119, 'Amber Parnell', 'Program Delivery Manager', '8444 West Park Drive', 'Suite 800', 'McLean', 'Virginia', '20136', '703 970 5586', '', '703 624 9205', 'amber.parnell@emc.com', 4);
INSERT INTO pdmname VALUES(120, 'Figini Juan', 'Program Delivery Manager', 'Av. Providencia 1760, Piso 15', '', 'Santiago de Chile', 'Santiago', '1001', '56 2 23733104', '', '56 9 61708752', 'juan.figini@emc.com', 10);
INSERT INTO pdmname VALUES(121, 'Marisol Sanchez - Colombia', 'Program Delivery Manager', 'Calle 116 # 7-15 Int. 2, Of: 402.', '', 'Bogota', 'Colombia.', '110111', '(212)206-6939', '', '(416)637-3409', 'Marisol.SanchezFont@emc.com', 11);
INSERT INTO pdmname VALUES(122, 'Marisol Sanchez - Venezuela', 'Program Delivery Manager', 'Av, principal la castellana, torre la castellana piso 12 ofic 12-a', '', 'Caracas-Venezuela.', 'Altamira-miranda', '', '(212)206-6939', '', '(416)637-3409', 'Marisol.SanchezFont@emc.com', 11);
INSERT INTO pdmname VALUES(123, 'Marisol Sanchez - Puerto Rico', 'Program Delivery Manager', 'Santander Tower 11th Floor B7 Tabonuco St. Guaynabo, PR', '', 'San Juan', 'Puerto Rico', '968', '(212)206-6939', '', '(416)637-3409', 'Marisol.SanchezFont@emc.com', 11);
INSERT INTO pdmname VALUES(124, 'Ioannis Diamantis', 'GPSd Lead Greece, Cyprus, Malta', '44 Zalokosta & Kifisias Avenue', '15233, Chalandri', 'Athens', 'Greece', '', '+30(0)2106146926', '', '+30(0)6974262319', 'ioannis.diamantis@emc.com', 17);
INSERT INTO pdmname VALUES(125, 'Itzhak Hanan', 'GPSd Lead Israel', '94 Em Hamoshavot', '1st & 2nd Floor, Park Azorim', 'Tel Aviv', 'Israel', '', '+972(0)37685404', '', '+972(0)546757173', 'itzhak.hanan@emc.com', 17);
INSERT INTO pdmname VALUES(126, 'Wojciech Pliszka', 'Mgr Prof. Services', 'Choldna Street 512', '6th FloorWarsaw trade Tower', 'Warsaw', 'Poland', '', '+48224553002', '', '+48 605 324704', 'wojciech.pliszka@emc.com', 16);
INSERT INTO pdmname VALUES(127, 'Andrei Korinets', 'Mgr Prof. Services', '3 Begovaya StreetFloor 30, Bldg 1', '', 'Moscow', 'Russian Federation', '', '+7 495 78 56622', '', '+7 9175662103', 'andrei.korinets@emc.com', 16);
INSERT INTO pdmname VALUES(128, 'Wojciech Pliszka', 'Mgr Prof. Services', 'Choldna Street 512', '6th FloorWarsaw trade Tower', 'Warsaw', 'Poland', '', '+48224553002', '', '+48 605 324706', 'wojciech.pliszka@emc.com', 16);
INSERT INTO pdmname VALUES(129, 'Wojciech Pliszka', 'Mgr Prof. Services', 'Choldna Street 512', '6th FloorWarsaw trade Tower', 'Warsaw', 'Poland', '', '+48224553002', '', '+48 605 324707', 'wojciech.pliszka@emc.com', 16);
INSERT INTO pdmname VALUES(130, 'Umut Kurtdede', 'Program Delivery Manager', '5th Floor', '34330 Is Kuleleri Kule-2', 'Istanbul', 'Turkey', '', '+90(0)2123174464', '', '+905309619344', 'Umut.Kurtdede@emc.com', 16);

UPDATE SalesDistrict SET default_pdm_id = 103 WHERE id = 8;
UPDATE SalesDistrict SET default_pdm_id = 12 WHERE id = 9;
UPDATE SalesDistrict SET default_pdm_id = 106 WHERE id = 11;
UPDATE SalesDistrict SET default_pdm_id = 104 WHERE id = 12;
UPDATE SalesDistrict SET default_pdm_id = 101 WHERE id = 13;
UPDATE SalesDistrict SET default_pdm_id = 101 WHERE id = 14;
UPDATE SalesDistrict SET default_pdm_id = 106 WHERE id = 16;
UPDATE SalesDistrict SET default_pdm_id = 5 WHERE id = 17;
UPDATE SalesDistrict SET default_pdm_id = 104 WHERE id = 20;
UPDATE SalesDistrict SET default_pdm_id = 5 WHERE id = 21;
UPDATE SalesDistrict SET default_pdm_id = 103 WHERE id = 24;
UPDATE SalesDistrict SET default_pdm_id = 103 WHERE id = 25;
UPDATE SalesDistrict SET default_pdm_id = 103 WHERE id = 26;
UPDATE SalesDistrict SET default_pdm_id = 106 WHERE id = 27;
UPDATE SalesDistrict SET default_pdm_id = 105 WHERE id = 28;
UPDATE SalesDistrict SET default_pdm_id = 101 WHERE id = 29;
UPDATE SalesDistrict SET default_pdm_id = 4 WHERE id = 31;
UPDATE SalesDistrict SET default_pdm_id = 4 WHERE id = 32;
UPDATE SalesDistrict SET default_pdm_id = 106 WHERE id = 33;
UPDATE SalesDistrict SET default_pdm_id = 4 WHERE id = 34;
UPDATE SalesDistrict SET default_pdm_id = 105 WHERE id = 35;
UPDATE SalesDistrict SET default_pdm_id = 101 WHERE id = 38;
UPDATE SalesDistrict SET default_pdm_id = 101 WHERE id = 39;
UPDATE SalesDistrict SET default_pdm_id = 103 WHERE id = 40;
UPDATE SalesDistrict SET default_pdm_id = 103 WHERE id = 41;
UPDATE SalesDistrict SET default_pdm_id = 103 WHERE id = 42;
UPDATE SalesDistrict SET default_pdm_id = 12 WHERE id = 44;
UPDATE SalesDistrict SET default_pdm_id = 104 WHERE id = 45;
UPDATE SalesDistrict SET default_pdm_id = 104 WHERE id = 46;
UPDATE SalesDistrict SET default_pdm_id = 106 WHERE id = 47;
UPDATE SalesDistrict SET default_pdm_id = 106 WHERE id = 48;
UPDATE SalesDistrict SET default_pdm_id = 14 WHERE id = 49;
UPDATE SalesDistrict SET default_pdm_id = 14 WHERE id = 50;
UPDATE SalesDistrict SET default_pdm_id = 14 WHERE id = 51;
UPDATE SalesDistrict SET default_pdm_id = 14 WHERE id = 52;
UPDATE SalesDistrict SET default_pdm_id = 102 WHERE id = 53;
UPDATE SalesDistrict SET default_pdm_id = 21 WHERE id = 55;
UPDATE SalesDistrict SET default_pdm_id = 21 WHERE id = 56;
UPDATE SalesDistrict SET default_pdm_id = 21 WHERE id = 57;
UPDATE SalesDistrict SET default_pdm_id = 119 WHERE id = 59;
UPDATE SalesDistrict SET default_pdm_id = 119 WHERE id = 60;
UPDATE SalesDistrict SET default_pdm_id = 21 WHERE id = 63;
UPDATE SalesDistrict SET default_pdm_id = 98 WHERE id = 77;
UPDATE SalesDistrict SET default_pdm_id = 99 WHERE id = 80;
UPDATE SalesDistrict SET default_pdm_id = 98 WHERE id = 86;
UPDATE SalesDistrict SET default_pdm_id = 99 WHERE id = 89;
UPDATE SalesDistrict SET default_pdm_id = 97 WHERE id = 95;
UPDATE SalesDistrict SET default_pdm_id = 110 WHERE id = 96;
UPDATE SalesDistrict SET default_pdm_id = 110 WHERE id = 97;
UPDATE SalesDistrict SET default_pdm_id = 110 WHERE id = 98;
UPDATE SalesDistrict SET default_pdm_id = 110 WHERE id = 99;
UPDATE SalesDistrict SET default_pdm_id = 38 WHERE id = 102;
UPDATE SalesDistrict SET default_pdm_id = 109 WHERE id = 103;
UPDATE SalesDistrict SET default_pdm_id = 110 WHERE id = 104;
UPDATE SalesDistrict SET default_pdm_id = 38 WHERE id = 105;
UPDATE SalesDistrict SET default_pdm_id = 110 WHERE id = 106;
UPDATE SalesDistrict SET default_pdm_id = 110 WHERE id = 107;
UPDATE SalesDistrict SET default_pdm_id = 110 WHERE id = 108;
UPDATE SalesDistrict SET default_pdm_id = 38 WHERE id = 109;
UPDATE SalesDistrict SET default_pdm_id = 110 WHERE id = 110;
UPDATE SalesDistrict SET default_pdm_id = 108 WHERE id = 112;
UPDATE SalesDistrict SET default_pdm_id = 108 WHERE id = 113;
UPDATE SalesDistrict SET default_pdm_id = 109 WHERE id = 128;
UPDATE SalesDistrict SET default_pdm_id = 108 WHERE id = 129;
UPDATE SalesDistrict SET default_pdm_id = 109 WHERE id = 130;
UPDATE SalesDistrict SET area_name = 'Scotto' WHERE id = 132;
UPDATE SalesDistrict SET default_pdm_id = 111, area_name = 'McLaughlin' WHERE id = 133;
UPDATE SalesDistrict SET default_pdm_id = 111, area_name = 'Giordano' WHERE id = 134;
UPDATE SalesDistrict SET area_name = 'Scotto' WHERE id = 137;
UPDATE SalesDistrict SET default_pdm_id = 111 WHERE id = 140;
UPDATE SalesDistrict SET default_pdm_id = 112, area_name = 'Trizzino' WHERE id = 141;
UPDATE SalesDistrict SET default_pdm_id = 118 WHERE id = 142;
UPDATE SalesDistrict SET default_pdm_id = 48 WHERE id = 143;
UPDATE SalesDistrict SET default_pdm_id = 117 WHERE id = 145;
UPDATE SalesDistrict SET default_pdm_id = 117 WHERE id = 147;
UPDATE SalesDistrict SET default_pdm_id = 118 WHERE id = 148;
UPDATE SalesDistrict SET default_pdm_id = 115 WHERE id = 149;
UPDATE SalesDistrict SET default_pdm_id = 48 WHERE id = 150;
UPDATE SalesDistrict SET default_pdm_id = 48 WHERE id = 151;
UPDATE SalesDistrict SET default_pdm_id = 116 WHERE id = 152;
UPDATE SalesDistrict SET default_pdm_id = 116 WHERE id = 153;
UPDATE SalesDistrict SET default_pdm_id = 115 WHERE id = 155;
UPDATE SalesDistrict SET default_pdm_id = 115 WHERE id = 157;
UPDATE SalesDistrict SET default_pdm_id = 49 WHERE id = 160;
UPDATE SalesDistrict SET default_pdm_id = 115 WHERE id = 161;
UPDATE SalesDistrict SET default_pdm_id = 115 WHERE id = 162;
UPDATE SalesDistrict SET default_pdm_id = 115 WHERE id = 163;
UPDATE SalesDistrict SET default_pdm_id = 115 WHERE id = 164;
UPDATE SalesDistrict SET default_pdm_id = 118 WHERE id = 166;
UPDATE SalesDistrict SET default_pdm_id = 49 WHERE id = 167;
UPDATE SalesDistrict SET default_pdm_id = 49 WHERE id = 168;
UPDATE SalesDistrict SET default_pdm_id = 114 WHERE id = 169;
UPDATE SalesDistrict SET default_pdm_id = 120 WHERE id = 170;
UPDATE SalesDistrict SET default_pdm_id = 120 WHERE id = 171;
UPDATE SalesDistrict SET default_pdm_id = 120 WHERE id = 172;
UPDATE SalesDistrict SET default_pdm_id = 120 WHERE id = 173;
UPDATE SalesDistrict SET default_pdm_id = 120 WHERE id = 174;
UPDATE SalesDistrict SET default_pdm_id = 120 WHERE id = 175;
UPDATE SalesDistrict SET default_pdm_id = 120 WHERE id = 176;
UPDATE SalesDistrict SET default_pdm_id = 120 WHERE id = 177;
UPDATE SalesDistrict SET default_pdm_id = 120 WHERE id = 178;
UPDATE SalesDistrict SET default_pdm_id = 120 WHERE id = 179;
UPDATE SalesDistrict SET default_pdm_id = 120 WHERE id = 180;
UPDATE SalesDistrict SET default_pdm_id = 120 WHERE id = 181;
UPDATE SalesDistrict SET default_pdm_id = 121 WHERE id = 182;
UPDATE SalesDistrict SET default_pdm_id = 122 WHERE id = 183;
UPDATE SalesDistrict SET default_pdm_id = 123 WHERE id = 184;
UPDATE SalesDistrict SET market_name = '' WHERE id BETWEEN 185 AND 209;
UPDATE SalesDistrict SET division_id = 17, area_name = 'West', market_name = '' WHERE id BETWEEN 215 AND 227;
UPDATE SalesDistrict SET default_pdm_id = 124 WHERE id = 226;
UPDATE SalesDistrict SET default_pdm_id = 125 WHERE id = 227;
UPDATE SalesDistrict SET area_name = 'East', market_name = '' WHERE id BETWEEN 228 AND 232;
UPDATE SalesDistrict SET default_pdm_id = 126 WHERE id = 228;
UPDATE SalesDistrict SET default_pdm_id = 127 WHERE id = 229;
UPDATE SalesDistrict SET default_pdm_id = 128 WHERE id = 230;
UPDATE SalesDistrict SET default_pdm_id = 129 WHERE id = 231;
UPDATE SalesDistrict SET default_pdm_id = 130 WHERE id = 232;

-- From SRT-112
INSERT INTO SalesDistrict VALUES (233, 'MIDMARKET SELECT HOUSTON DISTRICT', 'South', 'MidMarket', 6, 98);
INSERT INTO SalesDistrict VALUES (234, 'MIDMARKET SELECT CHARLOTTE DISTRICT', 'Carolinas', 'MidMarket', 6, 26);
INSERT INTO SalesDistrict VALUES (235, 'MIDMARKET SELECT GREENSBORO DISTRICT', 'Carolinas', 'MidMarket', 6, 26);
INSERT INTO SalesDistrict VALUES (236, 'MIDMARKET SELECT RICHMOND DISTRICT', 'Carolinas', 'MidMarket', 6, 26);
INSERT INTO SalesDistrict VALUES (237, 'MIDMARKET SELECT DALLAS DISTRICT', 'South', 'MidMarket', 6, 27);
INSERT INTO SalesDistrict VALUES (238, 'MIDMARKET SELECT HEALTHCARE SOUTH DISTRICT', 'South', 'MidMarket', 6, 27);
INSERT INTO SalesDistrict VALUES (239, 'MIDMARKET SELECT LAM DISTRICT', 'South Central', 'MidMarket', 6, 27);
INSERT INTO SalesDistrict VALUES (240, 'MIDMARKET SELECT LAM HEALTHCARE DISTRICT', 'South Central', 'MidMarket', 6, 27);
INSERT INTO SalesDistrict VALUES (241, 'MIDMARKET SELECT TN-KY DISTRICT', 'South Central', 'MidMarket', 6, 27);
INSERT INTO SalesDistrict VALUES (242, 'MIDMARKET SELECT TN-KY HEALTHCARE DISTRICT', 'South Central', 'MidMarket', 6, 27);
INSERT INTO SalesDistrict VALUES (243, 'MIDMARKET SELECT AUSTIN DISTRICT', 'South', 'MidMarket', 6, 29);
INSERT INTO SalesDistrict VALUES (244, 'MIDMARKET SELECT METRO ATLANTA DISTRICT', 'Southeast', 'MidMarket', 6, 32);
INSERT INTO SalesDistrict VALUES (245, 'MIDMARKET SELECT ATLANTA HEALTH DISTRICT', 'Southeast', 'MidMarket', 6, 33);
INSERT INTO SalesDistrict VALUES (246, 'MIDMARKET SELECT FLORIDA 1 DISTRICT', 'Southeast', 'MidMarket', 6, 33);
INSERT INTO SalesDistrict VALUES (247, 'MIDMARKET SELECT FLORIDA 2 DISTRICT', 'Southeast', 'MidMarket', 6, 33);
INSERT INTO SalesDistrict VALUES (248, 'MIDMARKET SELECT PHILADELPHIA EAST DISTRICT', 'Mid-Atlantic', 'MidMarket', 6, 99);
INSERT INTO SalesDistrict VALUES (249, 'MIDMARKET SELECT PHILADELPHIA WEST DISTRICT', 'Mid-Atlantic', 'MidMarket', 6, 99);
INSERT INTO SalesDistrict VALUES (250, 'MIDMARKET SELECT BALTIMORE DISTRICT', 'Mid-Atlantic', 'MidMarket', 6, 37);
INSERT INTO SalesDistrict VALUES (251, 'MIDMARKET SELECT MCLEAN DISTRICT', 'Carolinas', 'MidMarket', 6, 37);
INSERT INTO SalesDistrict VALUES (252, 'Federal', 'Enterprise', 'Enterprise', 1, 1);
INSERT INTO SalesDistrict VALUES (253, 'Oil & Gas', 'Enterprise', 'Enterprise', 1, 1);
INSERT INTO SalesDistrict VALUES (254, 'Enterprise', 'Enterprise', 'Enterprise', 1, 1);
INSERT INTO SalesDistrict VALUES (255, 'Commercial', 'Geo SP', 'MidMarket/SMB', 1, 1);
INSERT INTO SalesDistrict VALUES (256, 'MidMarket - Arkansas', 'Arkansas', 'MidMarket', 2, 4);
INSERT INTO SalesDistrict VALUES (257, 'High Growth & Educational', 'Mexico City', 'MidMarket', 5, 23);
INSERT INTO SalesDistrict VALUES (258, 'Monterrey', 'Geo North', 'MidMarket', 5, 23);
INSERT INTO SalesDistrict VALUES (260, 'MM-E Large ACCT NE District', 'Commercial East', 'MM', 7, 110);
INSERT INTO SalesDistrict VALUES (261, 'MM-E Territory NE North District', 'Commercial East', 'MM', 7, NULL);
INSERT INTO SalesDistrict VALUES (262, 'MM-E Territory NE South District', 'Commercial East', 'MM', 7, NULL);
INSERT INTO SalesDistrict VALUES (263, 'Toronto Financial', 'Canada', 'Enterprise', 7, 108);
INSERT INTO SalesDistrict VALUES (264, 'MIDMARKET SELECT BOSTON DISTRICT', 'Northeast', 'MidMarket', 7, 110);
INSERT INTO SalesDistrict VALUES (265, 'MIDMARKET SELECT NEW ENGLAND DISTRICT', 'Northeast', 'MidMarket', 7, 110);
INSERT INTO SalesDistrict VALUES (266, 'MIDMARKET SELECT NEWTON DISTRICT', 'Northeast', 'MidMarket', 7, 110);
INSERT INTO SalesDistrict VALUES (267, 'MIDMARKET SELECT CONNECTICUT DISTRICT', 'Northeast', 'MidMarket', 7, 38);
INSERT INTO SalesDistrict VALUES (268, 'MIDMARKET SELECT UPSTATE NY DISTRICT', 'Northeast', 'MidMarket', 7, 38);
INSERT INTO SalesDistrict VALUES (269, 'Enterprise - Bank of America', 'BOA', 'Enterprise', 8, 113);
INSERT INTO SalesDistrict VALUES (273, 'Enterprise - Hillock', 'Scotto', 'Enterprise', 8, 46);
INSERT INTO SalesDistrict VALUES (275, 'Enterprise - Polaski - Burgess District', 'Polaski', 'Enterprise', 8, 113);
INSERT INTO SalesDistrict VALUES (276, 'Enterprise - Polaski - Other Districts', 'Polaski', 'Enterprise', 8, 45);
INSERT INTO SalesDistrict VALUES (277, 'Enterprise - Lilienfeld', 'Scotto', 'Enterprise', 8, 111);
INSERT INTO SalesDistrict VALUES (279, 'MIDMARKET SELECT NJ 1 DISTRICT', 'Trizzino', 'GEO', 8, 112);
INSERT INTO SalesDistrict VALUES (280, 'MIDMARKET SELECT NJ 2 DISTRICT', 'Trizzino', 'GEO', 8, 112);
INSERT INTO SalesDistrict VALUES (281, 'MIDMARKET SELECT NYC 1 DISTRICT', 'Trizzino', 'GEO', 8, 112);
INSERT INTO SalesDistrict VALUES (282, 'MIDMARKET SELECT NYC 2 DISTRICT', 'Trizzino', 'GEO', 8, 112);
INSERT INTO SalesDistrict VALUES (283, 'NJ HEALTHCARE/LEGAL DISTRICT', 'Scotto', 'Enterprise', 8, 112);
INSERT INTO SalesDistrict VALUES (284, 'Enterprise - Las Vegas', 'Mountain', 'Enterprise', 9, 118);
INSERT INTO SalesDistrict VALUES (285, 'Enterprise - New Mexico', 'Mountain', 'Enterprise', 9, 54);
INSERT INTO SalesDistrict VALUES (286, 'Enterprise - Santa Clara 1', 'Nor Cal', 'Enterprise', 9, 48);
INSERT INTO SalesDistrict VALUES (287, 'MidMarket - AZ', 'SW Comm', 'MidMarket', 9, 118);
INSERT INTO SalesDistrict VALUES (288, 'MidMarket - NM', 'SW Comm', 'MidMarket', 9, 54);
INSERT INTO SalesDistrict VALUES (289, 'MidMarket - N. NV', 'SW Comm', 'MidMarket', 9, 115);
INSERT INTO SalesDistrict VALUES (290, 'MidMarket - S. NV', 'SW Comm', 'MidMarket', 9, 118);
INSERT INTO SalesDistrict VALUES (318, 'Strategic Programs', 'Civilian', 'Enterprise', 4, 18);
INSERT INTO SalesDistrict VALUES (319, 'DHS / State Dept', 'Civilian', 'Enterprise', 4, 119);


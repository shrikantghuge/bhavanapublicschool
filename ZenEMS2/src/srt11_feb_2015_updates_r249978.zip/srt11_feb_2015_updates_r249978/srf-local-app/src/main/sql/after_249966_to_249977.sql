CREATE TABLE IsilonNetAppNodeBaseMigration (
  id BIGINT AUTO_INCREMENT NOT NULL PRIMARY KEY,
  source_system_type VARCHAR(256),
  capacity_nodes_num_1 INT,
  capacity_nodes_num_2 INT,
  capacity_nodes_num_3 INT,
  capacity_nodes_num_4 INT,
  capacity_nodes_num_5 INT,
  multi_protocol_data BOOLEAN,
  wide_links BOOLEAN,
  historical_sids BOOLEAN,
  local_users_groups BOOLEAN,
  archived_data BOOLEAN,
  cutovers_num INT
);

ALTER TABLE IsilonMigration ADD net_app_node_migration BOOLEAN DEFAULT false;
ALTER TABLE IsilonMigration ADD net_app_node_id BIGINT;
ALTER TABLE IsilonMigration ADD FOREIGN KEY (net_app_node_id) REFERENCES IsilonNetAppNodeBaseMigration (id);

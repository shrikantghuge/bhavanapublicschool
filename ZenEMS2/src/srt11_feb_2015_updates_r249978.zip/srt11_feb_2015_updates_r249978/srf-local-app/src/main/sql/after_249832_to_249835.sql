ALTER TABLE StartRequestData ALTER COLUMN service_request_scope CLOB;

CREATE TABLE ContractStructure (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    name VARCHAR(256) NOT NULL
);

CREATE TABLE DealQuestionSection (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    name VARCHAR(256) NOT NULL
);

CREATE TABLE DealQuestion (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    name VARCHAR(256) NOT NULL,
    comment_condition BOOLEAN NOT NULL,
    comment_place_holder VARCHAR(256) NOT NULL,
    section_id bigint NOT NULL,
    FOREIGN KEY (section_id) REFERENCES DealQuestionSection (id)
);

CREATE TABLE DealGovernanceData (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    opportunity_name VARCHAR(140),
    primary_delivery_org VARCHAR(140),
    other_practices VARCHAR(140),
    estimated_start_date DATE,
    brief_description VARCHAR(140),
    contract_structure_id bigint,
    approver_notes VARCHAR(140),
    FOREIGN KEY (contract_structure_id) REFERENCES ContractStructure (id)
);

CREATE TABLE DealGovernanceData_dealAnswers (
    deal_governance_data_id bigint,
    question_id bigint,
    yes_no BOOLEAN,
    comment VARCHAR(140),
    FOREIGN KEY (deal_governance_data_id) REFERENCES DealGovernanceData (id),
    FOREIGN KEY (question_id) REFERENCES DealQuestion (id)
);

CREATE TABLE Geography (
    id bigint auto_increment NOT NULL PRIMARY KEY, 
    name VARCHAR(256)
);

CREATE TABLE DealCurrency (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    name VARCHAR(3),
    exchange_rate DECIMAL(20,10) NOT NULL
);

CREATE TABLE DeliveryGeography (
    id bigint auto_increment NOT NULL PRIMARY KEY, 
    name VARCHAR(256),
    code VARCHAR(10) NOT NULL
);

CREATE TABLE DeliveryCountry (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    code VARCHAR(2) NOT NULL,
    name VARCHAR(256) NOT NULL,
    delivery_geography_id bigint,
    delivery_currency_id bigint,
    calling_code VARCHAR(256),
    FOREIGN KEY (delivery_geography_id) REFERENCES DeliveryGeography (id),
    FOREIGN KEY (delivery_currency_id) REFERENCES DealCurrency (id)
);

CREATE TABLE Region (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    code VARCHAR(256) NOT NULL,
    name VARCHAR(256),
    region_country_id bigint,
    FOREIGN KEY (region_country_id) REFERENCES DeliveryCountry (id)
);

CREATE TABLE ScreenerInterviewer (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    name VARCHAR(256) NOT NULL
);

CREATE TABLE ResourceType (
  id   BIGINT AUTO_INCREMENT NOT NULL PRIMARY KEY,
  name VARCHAR(256)          NOT NULL,
  code VARCHAR(2) NOT NULL
);

CREATE TABLE BillingType (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    name VARCHAR(256) NOT NULL,
    code VARCHAR(10) NOT NULL
);

CREATE TABLE LOB (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    name VARCHAR(256) NOT NULL,
    code VARCHAR(10) NOT NULL
);

CREATE TABLE BOERole (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    code VARCHAR(256) NOT NULL,
    name VARCHAR(256) NOT NULL
);

CREATE TABLE DiscountFloorType (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    name VARCHAR(256) NOT NULL,
    code VARCHAR(256) NOT NULL
);

CREATE TABLE DiscountFloorGroup (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    name VARCHAR(256) NOT NULL
);

CREATE TABLE DiscountFloor (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    group_id BIGINT,
    type_id BIGINT,
    threshold DECIMAL(10,2),
    FOREIGN KEY (group_id) REFERENCES DiscountFloorGroup (id),
    FOREIGN KEY (type_id) REFERENCES DiscountFloorType (id)
);

CREATE TABLE MaterialCode (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    code VARCHAR(256) NOT NULL,
    name VARCHAR(256) NOT NULL,
    expense_model VARCHAR(256) NOT NULL,
    lob_id bigint NOT NULL,
    discount_group_id BIGINT NOT NULL,
    FOREIGN KEY (lob_id) REFERENCES LOB (id),
    FOREIGN KEY (discount_group_id) REFERENCES DiscountFloorGroup (id)
);

CREATE TABLE Competency (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    code VARCHAR(256) NOT NULL,
    name VARCHAR(256) NOT NULL,
    lob_id bigint NOT NULL,
    FOREIGN KEY (lob_id) REFERENCES LOB (id)
);

CREATE TABLE MaterialCode_Competency (
    material_id bigint NOT NULL,
    competency_id bigint NOT NULL,
    PRIMARY KEY (material_id, competency_id),
    FOREIGN KEY (material_id) REFERENCES MaterialCode (id),
    FOREIGN KEY (competency_id) REFERENCES Competency (id)
);

CREATE TABLE Competency_BOERole (
    competency_id bigint NOT NULL,
    role_id bigint NOT NULL,
    PRIMARY KEY (competency_id, role_id),
    FOREIGN KEY (role_id) REFERENCES BOERole (id),
    FOREIGN KEY (competency_id) REFERENCES Competency (id)
);

CREATE TABLE LOBCountry (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    lob_id bigint NOT NULL,
    country_code VARCHAR(2) NULL,
    company_code VARCHAR(256) NOT NULL,
    cost_center_code VARCHAR(256) NOT NULL,
    FOREIGN KEY (lob_id) REFERENCES LOB (id)
);

CREATE TABLE HourlyStdCostRate (
    lookup_key VARCHAR(100) NOT NULL PRIMARY KEY,
    rate DECIMAL(20,2)
);

CREATE TABLE StandardBillRate (
    lookup_key VARCHAR(100) NOT NULL PRIMARY KEY,
    rate DECIMAL(20,2)
);

CREATE TABLE DeliverAction (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    name VARCHAR(256) NOT NULL,
    code VARCHAR(10) NOT NULL,
    description VARCHAR(1024) NOT NULL
);

CREATE TABLE LOBResource (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    competency_id bigint,
    role_id bigint,
    start_date DATE,
    weeks INT,
    end_date DATE,
    contingency_percent DECIMAL(20, 2),
    bill_rate_override DECIMAL(20, 2),
    long_role_description VARCHAR(256),
    skills VARCHAR(140),
    additional_comments VARCHAR(140),
    potential_candidate VARCHAR(140),
    tech_screeners VARCHAR(140),
    utilization_target DECIMAL(20,2),
    resource_type_id BIGINT,
    citizenship_required BOOLEAN,
    security_clearance_required BOOLEAN,
    remote_work_allowed BOOLEAN,
    work_location VARCHAR(140),
    days_week_on_site INT,
    screener_interviewer_id bigint,
    project_pdm VARCHAR(140),
    project_pm VARCHAR(140),
    project_rm VARCHAR(140),
    notes VARCHAR(140),
    FOREIGN KEY (role_id) REFERENCES BOERole (id),
    FOREIGN KEY (competency_id) REFERENCES Competency (id),
    FOREIGN KEY (screener_interviewer_id) REFERENCES ScreenerInterviewer (id),
    FOREIGN KEY (resource_type_id) REFERENCES ResourceType (id)
);

CREATE TABLE LOBResource_monthHours (
    lob_resource_id bigint,
    month INT,
    hours INT,
    FOREIGN KEY (lob_resource_id) REFERENCES LOBResource (id)
);

CREATE TABLE LOBResources (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    lob_id bigint,
    material_id bigint,
    competency_id bigint,
    billing_type_id bigint,
    months_num INT,
    expense_amount DECIMAL(20, 2),
    discount_percent DECIMAL(20, 2),
    discount_amount DECIMAL(20, 2),
    wbs_number VARCHAR(140),
    sales_order_item_number VARCHAR(140),
    expense_wbs_number VARCHAR(140),
    expense_sales_order_item_number VARCHAR(140),
    FOREIGN KEY (lob_id) REFERENCES LOB (id),
    FOREIGN KEY (material_id) REFERENCES MaterialCode (id),
    FOREIGN KEY (competency_id) REFERENCES Competency (id),
    FOREIGN KEY (billing_type_id) REFERENCES BillingType (id)
);

CREATE TABLE LOB_resources (
    lob_resources_id bigint NOT NULL,
    lob_resource_id bigint NOT NULL,
    FOREIGN KEY (lob_resources_id) REFERENCES LOBResources (id),
    FOREIGN KEY (lob_resource_id) REFERENCES LOBResource (id)
);

CREATE TABLE EstimatesData (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    deal_currency_id bigint,
    estimated_percent DECIMAL(20, 2),
    expense_amount DECIMAL(20, 2),
    capped_percent DECIMAL(20, 2),
    client_pricing_override DECIMAL(20, 2),
    deliver_description VARCHAR(512),
    deliver_action_id bigint,
    contingency_percent DECIMAL(20, 2),
    sow_number VARCHAR(256),
    contract_number VARCHAR(256),
    FOREIGN KEY (deal_currency_id) REFERENCES DealCurrency (id),
    FOREIGN KEY (deliver_action_id) REFERENCES DeliverAction (id)
);

CREATE TABLE IPEDUData (
  id        BIGINT AUTO_INCREMENT NOT NULL PRIMARY KEY,
  estimates_data_id  BIGINT,
  data_type   VARCHAR(3),
  material_id BIGINT,
  competency_id BIGINT,
  amount DECIMAL(20, 2),
  FOREIGN KEY (estimates_data_id) REFERENCES EstimatesData (id),
  FOREIGN KEY (material_id) REFERENCES MaterialCode (id),
  FOREIGN KEY (competency_id) REFERENCES Competency (id)
);

CREATE TABLE EstimatesData_resources (
    estimates_data_id bigint NOT NULL,
    lob_resources_id bigint NOT NULL,
    FOREIGN KEY (estimates_data_id) REFERENCES EstimatesData (id),
    FOREIGN KEY (lob_resources_id) REFERENCES LOBResources (id)
);

CREATE TABLE EngagementTypeData (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    product_lead BOOLEAN,
    service_lead BOOLEAN,
    emc BOOLEAN,
    ecd BOOLEAN,
    rsa BOOLEAN,
    ms BOOLEAN,
    delivery_country_id bigint,
    FOREIGN KEY (delivery_country_id) REFERENCES DeliveryCountry (id)
);

CREATE TABLE DataDomainDeviceType (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    name VARCHAR(256)
);
CREATE TABLE DataDomainUpgradeType (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    name VARCHAR(256)
);
CREATE TABLE DataDomainDataStagingType (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    name VARCHAR(256)
);
CREATE TABLE DataDomainIntegrationType (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    name VARCHAR(256)
);
CREATE TABLE DataDomainMigrationType (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    name VARCHAR(256)
);
CREATE TABLE DataDomainPreRackType (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    name VARCHAR(256)
);
CREATE TABLE DataDomainBoostType (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    name VARCHAR(256)
);
CREATE TABLE DataDomainMaxBackupWindowTime (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    name VARCHAR(256)
);

CREATE TABLE AvamarServerType (
    id bigint auto_increment NOT NULL PRIMARY KEY, 
    name VARCHAR(256) NOT NULL
);
CREATE TABLE VplexDataMobilityType (
    id bigint auto_increment NOT NULL PRIMARY KEY, 
    name VARCHAR(256) NOT NULL
);
CREATE TABLE RecoverPointSplitterType (
    id bigint auto_increment NOT NULL PRIMARY KEY, 
    name VARCHAR(256)
);

CREATE TABLE IntelligentFabricMigrationMethod (
  id   BIGINT AUTO_INCREMENT NOT NULL PRIMARY KEY,
  name VARCHAR(256)          NOT NULL
);

CREATE TABLE RecoverPointOption (
  id   BIGINT AUTO_INCREMENT NOT NULL PRIMARY KEY,
  name VARCHAR(256)          NOT NULL
);

CREATE TABLE CenteraArrayActionType (
    id bigint auto_increment NOT NULL PRIMARY KEY, 
    name VARCHAR(256)
);
CREATE TABLE CenteraEditionType (
    id bigint auto_increment NOT NULL PRIMARY KEY, 
    name VARCHAR(256)
);
CREATE TABLE CenteraGenerationType (
    id bigint auto_increment NOT NULL PRIMARY KEY, 
    name VARCHAR(256)
);
CREATE TABLE CenteraHealthCheckType (
    id bigint auto_increment NOT NULL PRIMARY KEY, 
    name VARCHAR(256)
);
CREATE TABLE CenteraReplicationType (
    id bigint auto_increment NOT NULL PRIMARY KEY, 
    name VARCHAR(256)
);
CREATE TABLE CenteraProtectionSchemeType (
    id bigint auto_increment NOT NULL PRIMARY KEY, 
    name VARCHAR(256)
);
CREATE TABLE CenteraShippingArranger (
    id bigint auto_increment NOT NULL PRIMARY KEY, 
    name VARCHAR(256)
);
CREATE TABLE CUAHardwareType (
    id bigint auto_increment NOT NULL PRIMARY KEY, 
    name VARCHAR(256)
);
CREATE TABLE UIMType (
    id bigint auto_increment NOT NULL PRIMARY KEY, 
    name VARCHAR(256)
);
CREATE TABLE UnifiedHealthCheckType (
    id bigint auto_increment NOT NULL PRIMARY KEY, 
    name VARCHAR(256)
);
CREATE TABLE WeekDay (
    id bigint auto_increment NOT NULL PRIMARY KEY, 
    name VARCHAR(256)
);
CREATE TABLE ResidencyPaymentType (
    id bigint auto_increment NOT NULL PRIMARY KEY, 
    name VARCHAR(256)
);
CREATE TABLE CTASourceFileServerType (
    id bigint auto_increment NOT NULL PRIMARY KEY, 
    name VARCHAR(256)
);
CREATE TABLE CTAApplianceType (
    id bigint auto_increment NOT NULL PRIMARY KEY, 
    name VARCHAR(256)
);
CREATE TABLE DurationMonths (
    id bigint auto_increment NOT NULL PRIMARY KEY, 
    name VARCHAR(256)
);
CREATE TABLE MSSService (
    id bigint auto_increment NOT NULL PRIMARY KEY, 
    name VARCHAR(256)
);
CREATE TABLE MSSPlatform (
    id bigint auto_increment NOT NULL PRIMARY KEY, 
    name VARCHAR(256)
);
CREATE TABLE SitesInvolved (
    id bigint auto_increment NOT NULL PRIMARY KEY, 
    name VARCHAR(256)
);

CREATE TABLE FlashStorageLayoutServices (
    id bigint auto_increment NOT NULL PRIMARY KEY, 
    name VARCHAR(256)
);

CREATE TABLE ScriptingLevelOption (
    id bigint auto_increment NOT NULL PRIMARY KEY, 
    name VARCHAR(256)
);

CREATE TABLE Division (
    id bigint auto_increment NOT NULL PRIMARY KEY, 
    division_name VARCHAR(256),
    email_address VARCHAR(256),
    short_name VARCHAR(256),
    strict_profile_search BOOLEAN,
    geography_id BIGINT,
    FOREIGN KEY (geography_id) REFERENCES Geography (id)
);

CREATE TABLE PdmName (
    id bigint auto_increment NOT NULL PRIMARY KEY, 
    pdm_name VARCHAR(256),
    title VARCHAR(256),
    address1 VARCHAR(256),
    address2 VARCHAR(256),
    city VARCHAR(256),
    state VARCHAR(256),
    postalCode VARCHAR(256),
    officeNumber VARCHAR(256),
    faxNumber VARCHAR(256),
    mobileNumber VARCHAR(256),
    emailAddress VARCHAR(256),
    division_id bigint,
    FOREIGN KEY (division_id) REFERENCES Division (id)
);

CREATE TABLE GeoState (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    geography_id bigint,
    default_division_id bigint,
    default_pdm_name_id bigint,
    name VARCHAR(256),
    FOREIGN KEY (geography_id) REFERENCES Geography (id),
    FOREIGN KEY (default_division_id) REFERENCES Division (id),
    FOREIGN KEY (default_pdm_name_id) REFERENCES PdmName (id)
);

CREATE TABLE SalesDistrict (
    id bigint auto_increment NOT NULL PRIMARY KEY, 
    district_name VARCHAR(256),
    area_name VARCHAR(256),
    market_name VARCHAR(256),
    division_id bigint,
    default_pdm_id bigint,
    email_address VARCHAR(256),
    FOREIGN KEY (division_id) REFERENCES Division (id),
    FOREIGN KEY (default_pdm_id) REFERENCES PdmName (id)
);

CREATE TABLE Profile (
    id bigint auto_increment NOT NULL PRIMARY KEY, 
    first_name VARCHAR(256),
    last_name VARCHAR(256),
    job_title VARCHAR(256),
    country_code VARCHAR(256),
    office_phone_country_code VARCHAR(256),
    office_phone_number VARCHAR(256),
    mobile_phone_country_code VARCHAR(256),
    mobile_phone_number VARCHAR(256),
    fax_country_code VARCHAR(256),
    fax_number VARCHAR(256),
    email VARCHAR(256),
    division_id bigint,
    sales_district_id bigint,
    default_profile BOOLEAN,
    user_identifier VARCHAR(128),
    correlated_id bigint,
    template_permission BOOLEAN NOT NULL DEFAULT FALSE,
    approver BOOLEAN NOT NULL DEFAULT FALSE,
    se_csd_name VARCHAR(256),
    se_csd_phone_country_code VARCHAR(256),
    se_csd_phone_number VARCHAR(256),
    se_manager_name VARCHAR(256),
    FOREIGN KEY (division_id) REFERENCES Division (id),
    FOREIGN KEY (sales_district_id) REFERENCES SalesDistrict (id)
);

CREATE TABLE ServicesAgreementType (
    id bigint auto_increment NOT NULL PRIMARY KEY, 
    name VARCHAR(256) NOT NULL
);

CREATE TABLE SowType (
    id bigint auto_increment NOT NULL PRIMARY KEY, 
    name VARCHAR(256) NOT NULL
);

CREATE TABLE CustomerWorkSite (
    id bigint auto_increment NOT NULL PRIMARY KEY, 
    site_name VARCHAR(256),
    delivery_city VARCHAR(256),
    cws_delivery_country_type_id bigint,
    cws_delivery_region_type_id bigint,
    FOREIGN KEY (cws_delivery_country_type_id) REFERENCES DeliveryCountry (id),
    FOREIGN KEY (cws_delivery_region_type_id) REFERENCES Region (id)
    
);

CREATE TABLE Customer (
    id bigint auto_increment NOT NULL PRIMARY KEY, 
    contact_name VARCHAR(256),
    formal_name VARCHAR(256),
    address1 VARCHAR(256),
    address2 VARCHAR(256),
    city VARCHAR(256),
    zip VARCHAR(256),
    title VARCHAR(256),
    office_phone_country_code VARCHAR(256),
    office_phone_number VARCHAR(256),
    mobile_phone_country_code VARCHAR(256),
    mobile_phone_number VARCHAR(256),
    fax_country_code VARCHAR(256),
    fax_number VARCHAR(256),
    email VARCHAR(256),
    services_agreement_number VARCHAR(256),
    services_agreement_date TIMESTAMP,
    partner_information VARCHAR(256),
    geo_state_id bigint,
	country_id bigint,
    services_agreement_type_id bigint,
    template BOOLEAN,
    user_identifier VARCHAR(128),
    correlated_id bigint,
    FOREIGN KEY (geo_state_id) REFERENCES Region (id),
	FOREIGN KEY (country_id) REFERENCES DeliveryCountry (id),
    FOREIGN KEY (services_agreement_type_id) REFERENCES ServicesAgreementType (id)
);

CREATE TABLE Customer_CustomerWorkSite (
    id bigint auto_increment NOT NULL PRIMARY KEY, 
    customer_id bigint,
    customer_work_site_id bigint,
    FOREIGN KEY (customer_id) REFERENCES Customer (id),
    FOREIGN KEY (customer_work_site_id) REFERENCES CustomerWorkSite (id)
);

CREATE TABLE ProjectType (
    id bigint auto_increment NOT NULL PRIMARY KEY, 
    name VARCHAR(256) NOT NULL, 
    code VARCHAR(10) NOT NULL
);

CREATE TABLE ProjectRegulatoryType (
    id bigint auto_increment NOT NULL PRIMARY KEY, 
    name VARCHAR(256) NOT NULL, 
    code VARCHAR(10) NOT NULL 
);

CREATE TABLE ExpenseType (
    id bigint auto_increment NOT NULL PRIMARY KEY, 
    name VARCHAR(256) NOT NULL 
);

CREATE TABLE NetworkerDatazoneSize (
  id BIGINT AUTO_INCREMENT NOT NULL PRIMARY KEY,
  name VARCHAR(256) NOT NULL
);

CREATE TABLE MeditechBackupType (
  id   BIGINT AUTO_INCREMENT NOT NULL PRIMARY KEY,
  name VARCHAR(256)          NOT NULL
);

CREATE TABLE EnvironmentDeviceType (
    id bigint auto_increment NOT NULL PRIMARY KEY, 
    name VARCHAR(256) NOT NULL
);

CREATE TABLE VnxClariionInstallType (
    id bigint auto_increment NOT NULL PRIMARY KEY, 
    name VARCHAR(256) NOT NULL
);

CREATE TABLE SrdfConnectionType (
    id bigint auto_increment NOT NULL PRIMARY KEY, 
    name VARCHAR(256) NOT NULL
);

CREATE TABLE PsaAgreementType (
    id bigint auto_increment NOT NULL PRIMARY KEY, 
    name VARCHAR(256) NOT NULL
);

CREATE TABLE EnvironmentArrayType (
    id bigint auto_increment NOT NULL PRIMARY KEY, 
    name VARCHAR(256) NOT NULL
);

CREATE TABLE SrdfStaticDynamicType (
    id bigint auto_increment NOT NULL PRIMARY KEY, 
    name VARCHAR(256) NOT NULL
);

CREATE TABLE VnxInstallProtocolSubType (
    id bigint auto_increment NOT NULL PRIMARY KEY, 
    name VARCHAR(256) NOT NULL
);

CREATE TABLE RequestType (
    id bigint auto_increment NOT NULL PRIMARY KEY, 
    name VARCHAR(256) NOT NULL
);

CREATE TABLE SourceVnxType (
    id bigint auto_increment NOT NULL PRIMARY KEY, 
    name VARCHAR(256) NOT NULL
);

CREATE TABLE AreaSizingType (
    id bigint auto_increment NOT NULL PRIMARY KEY, 
    name VARCHAR(256) NOT NULL,
);

CREATE TABLE CelerraSetupType (
    id bigint auto_increment NOT NULL PRIMARY KEY, 
    name VARCHAR(256) NOT NULL
);

CREATE TABLE CelerraArrayType (
    id bigint auto_increment NOT NULL PRIMARY KEY, 
    name VARCHAR(256) NOT NULL
);

CREATE TABLE TargetCelerraType (
    id bigint auto_increment NOT NULL PRIMARY KEY, 
    name VARCHAR(256) NOT NULL
);

CREATE TABLE ConfigChangeType (
    id bigint auto_increment NOT NULL PRIMARY KEY, 
    name VARCHAR(256) NOT NULL,
);

CREATE TABLE UnifiedConversionType (
    id bigint auto_increment NOT NULL PRIMARY KEY, 
    name VARCHAR(256) NOT NULL,
);

CREATE TABLE VnxInstallProtocolType (
    id bigint auto_increment NOT NULL PRIMARY KEY, 
    name VARCHAR(256) NOT NULL
);

CREATE TABLE TestAcceptancePlanType (
    id bigint auto_increment NOT NULL PRIMARY KEY, 
    name VARCHAR(256) NOT NULL
);

CREATE TABLE MvConnectionType (
    id bigint auto_increment NOT NULL PRIMARY KEY, 
    name VARCHAR(256) NOT NULL
);

CREATE TABLE GatewayStorageType (
    id bigint auto_increment NOT NULL PRIMARY KEY, 
    name VARCHAR(256) NOT NULL
);

CREATE TABLE KnowledgeTransferLevel (
    id bigint auto_increment NOT NULL PRIMARY KEY, 
    name VARCHAR(256) NOT NULL
);


CREATE TABLE DocumentationLevel (
    id bigint auto_increment NOT NULL PRIMARY KEY, 
    name VARCHAR(256) NOT NULL
);

CREATE TABLE ScriptingLevel (
    id bigint auto_increment NOT NULL PRIMARY KEY, 
    name VARCHAR(256) NOT NULL
);

CREATE TABLE ClearanceLevel (
    id bigint auto_increment NOT NULL PRIMARY KEY, 
    name VARCHAR(256) NOT NULL
);

CREATE TABLE RiskLevel (
    id bigint auto_increment NOT NULL PRIMARY KEY, 
    name VARCHAR(256) NOT NULL, 
    code VARCHAR(10) NOT NULL
);

CREATE TABLE NetworkLinkStatus (
    id bigint auto_increment NOT NULL PRIMARY KEY, 
    name VARCHAR(256) NOT NULL
);

CREATE TABLE MeetingStatus (
    id bigint auto_increment NOT NULL PRIMARY KEY, 
    name VARCHAR(256) NOT NULL
);

CREATE TABLE PushPullOption (
    id bigint auto_increment NOT NULL PRIMARY KEY, 
    name VARCHAR(256) NOT NULL
);

CREATE TABLE RackAndStackOption (
    id bigint auto_increment NOT NULL PRIMARY KEY, 
    name VARCHAR(256) NOT NULL
);

CREATE TABLE BcvCloneOption (
    id bigint auto_increment NOT NULL PRIMARY KEY, 
    name VARCHAR(256) NOT NULL
);

CREATE TABLE PostSalesCompletionQualifier (
    id bigint auto_increment NOT NULL PRIMARY KEY, 
    name VARCHAR(256) NOT NULL
);

CREATE TABLE MvMode (
    id bigint auto_increment NOT NULL PRIMARY KEY, 
    name VARCHAR(256) NOT NULL
);

CREATE TABLE ArrayModel (
    id bigint auto_increment NOT NULL PRIMARY KEY, 
    name VARCHAR(256) NOT NULL
);

CREATE TABLE IOInterfaceModule (
    id bigint auto_increment NOT NULL PRIMARY KEY, 
    name VARCHAR(256) NOT NULL
);

CREATE TABLE EmcMigrationInvolvement (
    id bigint auto_increment NOT NULL PRIMARY KEY, 
    name VARCHAR(256) NOT NULL
);

CREATE TABLE SymmetrixModel (
    id bigint auto_increment NOT NULL PRIMARY KEY, 
    name VARCHAR(256) NOT NULL
);

CREATE TABLE MigrationTestNumber (
    id bigint auto_increment NOT NULL PRIMARY KEY, 
    name VARCHAR(256) NOT NULL
);

CREATE TABLE HostSoftwareInstaller (
    id bigint auto_increment NOT NULL PRIMARY KEY, 
    name VARCHAR(256) NOT NULL
);

CREATE TABLE CelerraVnxModel (
    id bigint auto_increment NOT NULL PRIMARY KEY, 
    name VARCHAR(256) NOT NULL
);

CREATE TABLE MigrationMethod (
    id bigint auto_increment NOT NULL PRIMARY KEY, 
    name VARCHAR(256) NOT NULL
);

CREATE TABLE CelerraModel (
    id bigint auto_increment NOT NULL PRIMARY KEY, 
    name VARCHAR(256) NOT NULL
);

CREATE TABLE VNXProtocol (
    id bigint auto_increment NOT NULL PRIMARY KEY, 
    name VARCHAR(256) NOT NULL
);

CREATE TABLE EnvironmentGatherer (
    id bigint auto_increment NOT NULL PRIMARY KEY, 
    name VARCHAR(256) NOT NULL
);

CREATE TABLE SrdfMode (
    id bigint auto_increment NOT NULL PRIMARY KEY, 
    name VARCHAR(256) NOT NULL
);

CREATE TABLE MigrationWorker (
    id bigint auto_increment NOT NULL PRIMARY KEY, 
    name VARCHAR(256) NOT NULL
);

CREATE TABLE SanImplementator (
    id bigint auto_increment NOT NULL PRIMARY KEY, 
    name VARCHAR(256) NOT NULL
);

CREATE TABLE VolumeSizeChange (
    id bigint auto_increment NOT NULL PRIMARY KEY, 
    name VARCHAR(256) NOT NULL
);

CREATE TABLE ReplicationManagerImplementation (
    id bigint auto_increment NOT NULL PRIMARY KEY, 
    name VARCHAR(256) NOT NULL
);

CREATE TABLE ReplicationManagerProductSpecificPreparation (
    id bigint auto_increment NOT NULL PRIMARY KEY, 
    name VARCHAR(256) NOT NULL
);

CREATE TABLE SowLanguage (
    id bigint auto_increment NOT NULL PRIMARY KEY, 
    name VARCHAR(256) NOT NULL
);

CREATE TABLE TargetCelerra (
    id bigint auto_increment NOT NULL PRIMARY KEY, 
    name VARCHAR(256) NOT NULL
);

CREATE TABLE SynchronousMode (
    id bigint auto_increment NOT NULL PRIMARY KEY, 
    name VARCHAR(256) NOT NULL
);

CREATE TABLE ReplicationFailoverLevel (
    id bigint auto_increment NOT NULL PRIMARY KEY, 
    name VARCHAR(256) NOT NULL
);

CREATE TABLE ReplicationManagerInformation (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    knowledge_transfer_hours float,
    time_finder_managed BOOLEAN,
    open_replicator_managed BOOLEAN,
    snap_view_managed BOOLEAN,
    recover_point_managed BOOLEAN,
    san_copy_managed BOOLEAN,
    celerra_managed BOOLEAN,
    snap_sure_managed BOOLEAN,
    replication_installed BOOLEAN,
    replication_manager_implementation_id bigint,
    replication_manager_product_specific_preparation_id bigint,
    replicated_storage_size INT,
    nr_of_replicas INT,
    nr_of_replicated_apps INT,
    nr_of_replication_jobs INT,
    config_change_type_id bigint,
    manager_servers_number INT,
    clustered_rm_server_option BOOLEAN,
    include_app_integration BOOLEAN,
    custom_scripting_required BOOLEAN,
    FOREIGN KEY (replication_manager_implementation_id) REFERENCES ReplicationManagerImplementation (id),
    FOREIGN KEY (replication_manager_product_specific_preparation_id) REFERENCES ReplicationManagerProductSpecificPreparation (id),
    FOREIGN KEY (config_change_type_id) REFERENCES ConfigChangeType (id)
);

CREATE TABLE ReplicationManagerInformation_SourceHostNumber (
    replication_manager_information_int bigint,
    map_key VARCHAR(256),
    map_value INT,
    FOREIGN KEY (replication_manager_information_int) REFERENCES ReplicationManagerInformation (id)
);

CREATE TABLE ReplicationManagerInformation_TargetHostNumber (
    replication_manager_information_int bigint,
    map_key VARCHAR(256),
    map_value INT,
    FOREIGN KEY (replication_manager_information_int) REFERENCES ReplicationManagerInformation (id)
);

CREATE TABLE TimeFinderInformation (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    knowledge_transfer_hours float,
    bcv_to_implement BOOLEAN,
    clone_to_implement BOOLEAN,
    snap_to_implement BOOLEAN,
    vp_snap_to_implement BOOLEAN,
    config_change_type_id bigint,
    replicated_storage_size INT,
    nr_of_clone_copies INT,
    nr_of_bcv_copies INT,
    nr_of_snaps_copies INT,
    nr_of_vp_snaps_copies INT,
    nr_of_solution_enabler_hosts INT,
    nr_of_clone_pairs INT,
    scripting_level_id bigint,
    area_sizing_type_id bigint,
    FOREIGN KEY (config_change_type_id) REFERENCES ConfigChangeType (id),
    FOREIGN KEY (scripting_level_id) REFERENCES ScriptingLevel (id),
    FOREIGN KEY (area_sizing_type_id) REFERENCES AreaSizingType (id)
);

CREATE TABLE TimeFinderInformation_hostNumbers (
    time_finder_information_int bigint,
    map_key VARCHAR(256),
    map_value INT,
    FOREIGN KEY (time_finder_information_int) REFERENCES TimeFinderInformation (id)
);

CREATE TABLE SnapViewInformation (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    knowledge_transfer_hours float,
    replicated_storage_size INT,
    snap_view_functionality_required BOOLEAN,
    snap_shot_view_functionality_required BOOLEAN,
    nr_of_vnx_arrays INT,
    nr_of_vnx_snapshots_copies INT,
    nr_of_snap_view_clones_copies INT,
    scripting_level_id bigint,
    nr_of_snap_view_consistent_sessions INT,
    nr_of_snap_view_persistent_sessions INT,
    FOREIGN KEY (scripting_level_id) REFERENCES ScriptingLevel (id)
);

CREATE TABLE SnapViewInformation_hostNumbers (
    snap_view_information_int bigint,
    map_key VARCHAR(256),
    map_value INT,
    FOREIGN KEY (snap_view_information_int) REFERENCES SnapViewInformation (id)
);

CREATE TABLE BCServicesScope (
    id bigint auto_increment NOT NULL PRIMARY KEY, 
    srdf BOOLEAN,
    time_finder BOOLEAN,
    mirrow_view BOOLEAN,
    snap_view BOOLEAN,
    replication_services BOOLEAN
);

CREATE TABLE OpenReplicator (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    knowledge_transfer_hours float,
    post_sales_completion_qualifier_id bigint,
    FOREIGN KEY (post_sales_completion_qualifier_id) REFERENCES PostSalesCompletionQualifier (id)
);

CREATE TABLE SrdfInformation (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    knowledge_transfer_hours float,
    srdfS_functionality_required BOOLEAN,
    srdfA_functionality_required BOOLEAN,
    cascading_srdf_functionality_required BOOLEAN,
    srdf_star_functionality_required BOOLEAN,
    concurrent_srdf_functionality_required BOOLEAN,
    network_link_status_id bigint,
    srdf_static_dynamic_type_id bigint,
    bc_practive_scripting_level2_id bigint,
    emc_map_points_option BOOLEAN,
    srdf_ce BOOLEAN,
    num_symm_directors_fa2ra_conversion INT,
    num_symm_ra_directors_compression INT,
    num_symm_gigabit_ethernet_directors INT,
    FOREIGN KEY (network_link_status_id) REFERENCES NetworkLinkStatus (id),
    FOREIGN KEY (srdf_static_dynamic_type_id) REFERENCES SrdfStaticDynamicType (id),
    FOREIGN KEY (bc_practive_scripting_level2_id) REFERENCES ScriptingLevel (id)
);

CREATE TABLE SrdfInformation_sourceArray (
    srdf_information_id bigint NOT NULL,
    symmetrix_model_id bigint,
    srdf_installed_status BOOLEAN,
    replicate_size INT,
    nr_of_symm_rdf_devices INT,
    nr_of_symm_devices_rdf_sites INT,
    uni_option_enabled BOOLEAN,
    nr_of_rdf_pairs INT,
    nr_of_rdf_groups INT,
    srdf_connection_type_id bigint,
    FOREIGN KEY (symmetrix_model_id) REFERENCES SymmetrixModel (id),
    FOREIGN KEY (srdf_connection_type_id) REFERENCES SrdfConnectionType (id),
    FOREIGN KEY (srdf_information_id) REFERENCES SrdfInformation (id)
);

CREATE TABLE SrdfInformation_targetArray (
    srdf_information_id bigint NOT NULL,
    symmetrix_model_id bigint,
    srdf_installed_status BOOLEAN,
    time_finder INT,
    bcv_clones_number INT,
    tf_backup BOOLEAN,
    source_name VARCHAR(256),
    include_bandwidth_analysis BOOLEAN,
    include_network_assessement BOOLEAN,
    nr_of_hosts_needed INT,
    nr_of_device_composite_groups INT,
    FOREIGN KEY (symmetrix_model_id) REFERENCES SymmetrixModel (id),
    FOREIGN KEY (srdf_information_id) REFERENCES SrdfInformation (id)
);

CREATE TABLE SrdfInformation_hostNumbers (
    srdf_information_id bigint,
    map_key VARCHAR(256),
    map_value INT,
    FOREIGN KEY (srdf_information_id) REFERENCES SrdfInformation (id)
);

CREATE TABLE MirrorViewInformation (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    knowledge_transfer_hours float, 
    mirror_viewS_functionality_required BOOLEAN,
    mirror_viewA_functionality_required BOOLEAN,
    mirror_viewCE_functionality_required BOOLEAN,
    network_link_status_id bigint,
    mirrow_view_scripting_level_id bigint,
    custom_scripting_details VARCHAR(256),
    nr_of_consistency_groups INT,
    nr_of_remote_mirrors INT,
    nr_of_secondary_images_created INT,
    FOREIGN KEY (network_link_status_id) REFERENCES NetworkLinkStatus (id),
    FOREIGN KEY (mirrow_view_scripting_level_id) REFERENCES ScriptingLevel (id)
);

CREATE TABLE MirrorViewInformation_sourceArray (
    mirror_view_information_id bigint NOT NULL,
    array_model_id bigint,
    existing_option_enabled BOOLEAN,
    mirrow_view_installed_status BOOLEAN,
    replicate_size INT,
    uni_option_enabled BOOLEAN,
    mv_connection_type_id bigint,
    FOREIGN KEY (array_model_id) REFERENCES ArrayModel (id),
    FOREIGN KEY (mv_connection_type_id) REFERENCES MvConnectionType (id),
    FOREIGN KEY (mirror_view_information_id) REFERENCES MirrorViewInformation (id)
);

CREATE TABLE MirrorViewInformation_targetArray (
    mirror_view_information_id bigint NOT NULL,
    array_model_id bigint,
    new_mv_mode_id bigint,
    existing_option_enabled BOOLEAN,
    mirrow_view_installed_status BOOLEAN,
    FOREIGN KEY (array_model_id) REFERENCES ArrayModel (id),
    FOREIGN KEY (new_mv_mode_id) REFERENCES MvMode (id),
    FOREIGN KEY (mirror_view_information_id) REFERENCES MirrorViewInformation (id)
);

CREATE TABLE MirrorViewInformation_hostNumbers (
    mirror_view_information_id bigint,
    map_key VARCHAR(256),
    map_value INT,
    FOREIGN KEY (mirror_view_information_id) REFERENCES MirrorViewInformation (id)
);

CREATE TABLE BcRequestData (
    id bigint auto_increment NOT NULL PRIMARY KEY, 
    general_comment VARCHAR(256),
    knowledge_transfer_days float,
    services_scope_id bigint,
    srdf_information_id bigint,
    time_finder_information_id bigint,
    mirror_view_information_id bigint,
    snap_view_information_id bigint,
    replication_manager_information_id bigint,
	nas_ip_replication_knowledge_transfer_days float,
    FOREIGN KEY (services_scope_id) REFERENCES BCServicesScope (id),
    FOREIGN KEY (srdf_information_id) REFERENCES SrdfInformation (id),
    FOREIGN KEY (time_finder_information_id) REFERENCES TimeFinderInformation (id),
    FOREIGN KEY (mirror_view_information_id) REFERENCES MirrorViewInformation (id),
    FOREIGN KEY (snap_view_information_id) REFERENCES SnapViewInformation (id),
    FOREIGN KEY (replication_manager_information_id) REFERENCES ReplicationManagerInformation (id)
);

CREATE TABLE CifsFeature (
    id bigint auto_increment NOT NULL PRIMARY KEY, 
    gpo_required BOOLEAN,
    local_users_groups_required BOOLEAN,
    dfs_roots_servers_required BOOLEAN,
    wide_links_required BOOLEAN,
    file_extension_required BOOLEAN,
    extended_user_mappings_required BOOLEAN
);

CREATE TABLE NasFeature (
    id bigint auto_increment NOT NULL PRIMARY KEY, 
    advanced_file_system_features BOOLEAN,
    advanced_networking_features BOOLEAN,
    advanced_storage_features BOOLEAN,
    backup BOOLEAN,
    vee BOOLEAN,
    vnx_file_mover BOOLEAN,
    ftp BOOLEAN,
    vnx_data_deduplication BOOLEAN,
    iscsi BOOLEAN,
    vnx_mpfs BOOLEAN,
    vnx_quotas BOOLEAN,
    vnx_replicator BOOLEAN,
    vnx_iscsi_replicator BOOLEAN,
    vnx_administrative_security BOOLEAN,
    vnx_snap_sure BOOLEAN
);

CREATE TABLE UnifiedServicesScope (
    id bigint auto_increment NOT NULL PRIMARY KEY, 
    celerra_implementation BOOLEAN,
    nas_health_check BOOLEAN,
    file_nas_migration BOOLEAN,
    mpfs BOOLEAN,
    nas_srdf_replication BOOLEAN,
    mdl_dlm BOOLEAN,
    nas_ip_replication BOOLEAN
);

CREATE TABLE NasMigrationInformation (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    location VARCHAR(256),
	average_file_size INT,
	cifs_data_size INT,
	cifs_file_system_number INT,
	cifs_local_group_option BOOLEAN,
	nfs_data_size_number INT,
	nfs_file_system_number INT,
	bimodal_data_size_number INT,
	bimodal_file_system_number INT,
	certified_data_migration_option BOOLEAN,
	migration_window_length INT,
	migration_windows_customer_number INT,
	celerra_vnx_model_id bigint,
	target_celerra_id bigint,
	migration_method_id bigint,
    FOREIGN KEY (celerra_vnx_model_id) REFERENCES CelerraVnxModel (id),
    FOREIGN KEY (target_celerra_id) REFERENCES TargetCelerra (id),
    FOREIGN KEY (migration_method_id) REFERENCES MigrationMethod (id)
);

CREATE TABLE CelerraDetailInformation (
    id bigint auto_increment NOT NULL PRIMARY KEY, 
    celerra_model_id bigint,
    vnx_protocol_id bigint,
    celerra_location VARCHAR(256),
    new_celerra_option BOOLEAN,
    disk_array_enclosures_included BOOLEAN,
    rack_and_stack_option_id bigint,
    gateway_storage_type_id bigint,
    new_symmetrix_storage_option BOOLEAN,
    dual_control_stations_used BOOLEAN,
    datamovers_number INT,
    file_fast_vp_configured BOOLEAN,
    usable_storage_size INT,
    file_system_number INT,
    nfs_configured BOOLEAN,
    cifs_configured BOOLEAN,
    multi_protocol_celerra_configured BOOLEAN,
    nas_features_id bigint,
    cifs_features_included BOOLEAN,
    ldap_required BOOLEAN,
    nfsv4_configured BOOLEAN,
    include_nfs_over_fc BOOLEAN,
    include_nfs_over_iscsi BOOLEAN,
    ip_replication_configured BOOLEAN,
    deinstall_celera BOOLEAN,
    cava_server_number INT,
    mpfs_required BOOLEAN,
    mpfs_host_quantity INT,
    mpfs_file_systems_quantity INT,
    mpfsi_required BOOLEAN,
    mpfsi_host_quantity INT,
    mpfsi_file_systems_quantity INT,
    file_servers_number INT,
    file_systems_number INT,
    cifs_file_servers_number INT,
    cifs_file_shares_number INT,
    nfs_file_systems_conf_number INT,
    nfs_file_systems_export_number INT,
    io_interface_module_id bigint,
    FOREIGN KEY (celerra_model_id) REFERENCES CelerraModel (id),
    FOREIGN KEY (vnx_protocol_id) REFERENCES CelerraModel (id),
    FOREIGN KEY (rack_and_stack_option_id) REFERENCES RackAndStackOption (id),
    FOREIGN KEY (gateway_storage_type_id) REFERENCES GatewayStorageType (id),
    FOREIGN KEY (nas_features_id) REFERENCES NasFeature (id),
    FOREIGN KEY (io_interface_module_id) REFERENCES IOInterfaceModule (id)
);

CREATE TABLE NasIpReplicationInformation (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    new_file_system_replication_number INT,
    replicated_data_size INT,
    vnx_array VARCHAR(256),
    include_local_replication BOOLEAN,
    include_remote_replication BOOLEAN,
    nr_of_cifs_file_systems INT,
    tb_of_cifs_file_systems INT,
    nr_of_nfs_file_systems INT,
    tb_of_nfs_file_systems INT,
    celerra_device_type VARCHAR(256)
);

CREATE TABLE UnifiedRequestData (
    id bigint auto_increment NOT NULL PRIMARY KEY, 
    general_comment VARCHAR(256),
    celerra_detail_knowledge_transfer_days float,
    nas_migration_knowledge_transfer_days float,
    nas_srdf_replication_knowledge_transfer_days float,
    mdl_dlm_knowledge_transfer_days float,
    include_unified_home_dirs BOOLEAN,
    include_unified_virtual_dm BOOLEAN,
    services_scope_id bigint,
    FOREIGN KEY (services_scope_id) REFERENCES UnifiedServicesScope (id)
);

CREATE TABLE UnifiedRequestData_celerraDetailInformation (
    unified_request_data_id bigint NOT NULL,
    celerra_detail_information_id bigint NOT NULL,
    FOREIGN KEY (unified_request_data_id) REFERENCES UnifiedRequestData (id),
    FOREIGN KEY (celerra_detail_information_id) REFERENCES CelerraDetailInformation (id)
);

CREATE TABLE UnifiedRequestData_nasMigrationInformation (
    unified_request_data_id bigint NOT NULL,
    nas_migration_information_id bigint NOT NULL,
    FOREIGN KEY (unified_request_data_id) REFERENCES UnifiedRequestData (id),
    FOREIGN KEY (nas_migration_information_id) REFERENCES NasMigrationInformation (id)
);

CREATE TABLE BcRequestData_nasIpReplicationInformation (
    bc_request_data_id bigint NOT NULL,
    nas_ip_replication_information_id bigint NOT NULL,
    FOREIGN KEY (bc_request_data_id) REFERENCES BcRequestData (id),
    FOREIGN KEY (nas_ip_replication_information_id) REFERENCES NasIpReplicationInformation (id)
);

CREATE TABLE SanTanInformation (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    knowledge_transfer_hours float, 
    san_migration_in_scope_option BOOLEAN,
    total_ports_to_migrate INT,
    san_directors_number INT,
    san_switches_number INT,
    blades_number INT,
    fcoe_switches_number INT,
    fcoe_vlan_number INT,
    fcoe_channel_number INT,
    san_extension_devices_number INT,
    nas_to_cx_units_number INT,
    nas_to_symmetrix_units_number INT,
    nas_to_cx_hosts_number INT,
    nas_to_symmetrix_hosts_number INT,
    verify_major_outage_connectivity_hosts_number INT,
    deinstalled_san_directors_number INT,
    deinstalled_san_switches_number INT,
    deinstalled_san_extension_devices_number INT,
    virtual_sans_num INT,
    fcoe_uplinks_num INT
);

CREATE TABLE DataMigrationInformation (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    knowledge_transfer_hours float,
    migration_worker_id bigint,
    migrate_luns_to_symmetrix_option BOOLEAN,
    migrate_luns_to_clariion_option BOOLEAN,
    symmetrix_volume_size_change_id bigint,
    clariion_volume_size_change_id bigint,
    emc_migration_involvement_id bigint,
    weekend_maintenance_hours INT,
    migration_cutover_hosts_number INT,
    migration_cutover_tests_number INT,
    migration_cutover_events_number INT,
    script_adjustment_option BOOLEAN,
    weekend_migrations_number INT,
    include_eca BOOLEAN,
    include_storage_data_erasure BOOLEAN,
    remove_relocate_emc_storage BOOLEAN,
    proposed_migration_tools VARCHAR(256),
    FOREIGN KEY (migration_worker_id) REFERENCES MigrationWorker (id),
    FOREIGN KEY (symmetrix_volume_size_change_id) REFERENCES VolumeSizeChange (id),
    FOREIGN KEY (clariion_volume_size_change_id) REFERENCES VolumeSizeChange (id),
    FOREIGN KEY (emc_migration_involvement_id) REFERENCES EmcMigrationInvolvement (id)
);

CREATE TABLE DataMigrationInformationn_array (
    data_migration_information_id bigint,
    array_type_id bigint,
    location VARCHAR(256),
    number_non_esx_hosts INT,
    number_esx_hosts INT,
    number_virtual_machines INT,
    swing_box BOOLEAN,
    array_type VARCHAR(256),
    capacity DOUBLE,
    FOREIGN KEY (array_type_id) REFERENCES EnvironmentArrayType (id),
    FOREIGN KEY (data_migration_information_id) REFERENCES DataMigrationInformation (id)
);

CREATE TABLE EnvironmentDetailsInformation (
    id bigint auto_increment NOT NULL PRIMARY KEY, 
    environment_gatherer_id bigint,
    dca_appliances_number1 INT,
    host_software_installer_id bigint,
    san_implementator_id bigint,
    existing_san_fabrics_number INT,
    FOREIGN KEY (environment_gatherer_id) REFERENCES EnvironmentGatherer (id),
    FOREIGN KEY (host_software_installer_id) REFERENCES HostSoftwareInstaller (id),
    FOREIGN KEY (san_implementator_id) REFERENCES SanImplementator (id)
);

CREATE TABLE EnvironmentDetailsInformation_existingArrayTypes (
    id bigint auto_increment NOT NULL PRIMARY KEY, 
    environment_details_information_id bigint,
    environment_array_type_id bigint,
    FOREIGN KEY (environment_details_information_id) REFERENCES EnvironmentDetailsInformation (id),
    FOREIGN KEY (environment_array_type_id) REFERENCES EnvironmentArrayType (id)
);

CREATE TABLE EnvironmentDetailsInformation_existingStorageLocations (
    id bigint auto_increment NOT NULL PRIMARY KEY, 
    environment_details_information_id bigint,
    value VARCHAR(256),
    FOREIGN KEY (environment_details_information_id) REFERENCES EnvironmentDetailsInformation (id)
);

CREATE TABLE EnvironmentDetailsInformation_usableCapacities (
    id bigint auto_increment NOT NULL PRIMARY KEY, 
    environment_details_information_id bigint,
    value DOUBLE,
    FOREIGN KEY (environment_details_information_id) REFERENCES EnvironmentDetailsInformation (id)
);

CREATE TABLE EnvironmentDetailsInformation_numberOfAttachedHosts (
    id bigint auto_increment NOT NULL PRIMARY KEY, 
    environment_details_information_id bigint,
    value INT,
    FOREIGN KEY (environment_details_information_id) REFERENCES EnvironmentDetailsInformation (id)
);

CREATE TABLE EnvironmentDetailsInformation_environmentDeviceTypes (
    id bigint auto_increment NOT NULL PRIMARY KEY, 
    environment_details_information_id bigint,
    environment_device_type_id bigint,
    FOREIGN KEY (environment_details_information_id) REFERENCES EnvironmentDetailsInformation (id),
    FOREIGN KEY (environment_device_type_id) REFERENCES EnvironmentDeviceType (id)
);

CREATE TABLE EnvironmentDetailsInformation_existingSanLocations (
    id bigint auto_increment NOT NULL PRIMARY KEY, 
    environment_details_information_id bigint,
    value VARCHAR(256),
    FOREIGN KEY (environment_details_information_id) REFERENCES EnvironmentDetailsInformation (id)
);

CREATE TABLE EnvironmentDetailsInformation_manufacturers (
    id bigint auto_increment NOT NULL PRIMARY KEY, 
    environment_details_information_id bigint,
    value VARCHAR(256),
    FOREIGN KEY (environment_details_information_id) REFERENCES EnvironmentDetailsInformation (id)
);

CREATE TABLE EnvironmentDetailsInformation_deviceQuantities (
    id bigint auto_increment NOT NULL PRIMARY KEY, 
    environment_details_information_id bigint,
    value DOUBLE,
    FOREIGN KEY (environment_details_information_id) REFERENCES EnvironmentDetailsInformation (id)
);

CREATE TABLE EnvironmentDetailsInformation_hostInfo (
    id bigint auto_increment NOT NULL PRIMARY KEY, 
    environment_details_information_id bigint,
    platform VARCHAR(256),
    host_number INT,
    new_host_number INT,
    number_of_clusters INT,
    number_boot_from_san INT,
    array_host_attached_to VARCHAR(256),
    FOREIGN KEY (environment_details_information_id) REFERENCES EnvironmentDetailsInformation (id)
);

CREATE TABLE SymmetrixMF (
  id                                         BIGINT AUTO_INCREMENT NOT NULL PRIMARY KEY,
  knowledge_transfer_hours                   FLOAT,
  vmax_arrays_number                         INT,
  dmx_arrays_number                          INT,
  vmax_arrays_upgrade_number                 INT,
  dmx_arrays_upgrade_number                  INT,
  srdf_arrays_number                         INT,
  srdfA_arrays_number                        INT,
  virtual_provisioning_arrays_number         INT,
  thin_devices_host_number                   INT,
  lun_to_dmx_host_number                     INT,
  auto_provisioing_to_dmx_host_number        INT,
  advanced_fast_arrays_number                INT,
  deinstall_open_systems_vmax_number         INT,
  vmax_arrays_num                            INT,
  vmax_groups_num                            INT,
  vmax_combinations_num                      INT,
  vmax_tiers_num                             INT,
  vmax_policies_num                          INT,
  vmax_performance_windows_num               INT,
  vmax_dm_windows_num                        INT,
  vmax_additional_hours_create_dev_tests_num INT,
  vmax_additional_hours_execute_dev_tests_num INT,
  vp_storage_groups_num                      INT,
  vp_disk_combinations_num                   INT,
  tdev_num                                   INT,
  tdat_num                                   INT,
  vp_thin_pools_num                          INT,
  fast_vp_performance_time_windows_num       INT,
  fast_vp_move_time_windows_num              INT,
  fast_vp_tiers_num                          INT,
  fast_vp_policies_num                       INT,
  engagement_adding_fast_vp                  BOOLEAN
);

CREATE TABLE SymmetrixOS (
  id                                         BIGINT AUTO_INCREMENT NOT NULL PRIMARY KEY,
  knowledge_transfer_hours                   FLOAT,
  vmax_arrays_number                         INT,
  dmx_arrays_number                          INT,
  vmax_arrays_upgrade_number                 INT,
  dmx_arrays_upgrade_number                  INT,
  srdf_arrays_number                         INT,
  srdfA_arrays_number                        INT,
  virtual_provisioning_arrays_number         INT,
  thin_devices_host_number                   INT,
  lun_to_dmx_host_number                     INT,
  auto_provisioing_to_dmx_host_number        INT,
  advanced_fast_arrays_number                INT,
  deinstall_open_systems_vmax_number         INT,
  vmax_arrays_num                            INT,
  vmax_groups_num                            INT,
  vmax_combinations_num                      INT,
  vmax_tiers_num                             INT,
  vmax_policies_num                          INT,
  vmax_performance_windows_num               INT,
  vmax_dm_windows_num                        INT,
  vmax_additional_hours_create_dev_tests_num INT,
  vmax_additional_hours_execute_dev_tests_num INT,
  vp_storage_groups_num                      INT,
  vp_disk_combinations_num                   INT,
  tdev_num                                   INT,
  tdat_num                                   INT,
  vp_thin_pools_num                          INT,
  fast_vp_performance_time_windows_num       INT,
  fast_vp_move_time_windows_num              INT,
  fast_vp_tiers_num                          INT,
  fast_vp_policies_num                       INT,
  engagement_adding_fast_vp                  BOOLEAN
);

CREATE TABLE VnxClariionInformation (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    knowledge_transfer_hours float,
    virtual_provisioning_arrays_number INT,
	vnx_arrays_number INT,
    unisphere_domains_number INT,
    fast_cache_setup_number INT,
    certified_disk_erasure_arrays_number INT,
    deinstall_cx_ns_vnx_number INT,
    vnx_clariion_install_type_id bigint,
    unified_conversions_required BOOLEAN,
    unified_conversion_type_id bigint,
    health_check_required BOOLEAN,
    sap_hana_required BOOLEAN,
    vnx_install_protocol_type_id bigint,
    vnx_install_protocol_sub_type_id bigint,
    vnx_monitoring_reporting_required BOOLEAN,
    fc_storage_connectivity_required BOOLEAN,
    fcoe_storage_connectivity_required BOOLEAN,
    iscsi_san_extension_storage_connectivity_required BOOLEAN,
    vsan_lsan_storage_connectivity_required BOOLEAN,
    fc_routing_storage_connectivity_required BOOLEAN,
    virtual_infrastructure_enablement_included BOOLEAN,
    watch4_net_included BOOLEAN,
    unified_local_protection BOOLEAN,
    unified_remote_protection BOOLEAN,
    unified_application_protection BOOLEAN,
    unified_fast_deployment BOOLEAN,
    unified_security_compliance BOOLEAN,
    unified_management_suite BOOLEAN,
    data_protection_advisor BOOLEAN,
    fast_lun_migrator BOOLEAN,
    mirror_view BOOLEAN,
    qos_manager BOOLEAN,
    replication_manager BOOLEAN,
    recover_point BOOLEAN,
    san_copy BOOLEAN,
    snap_view_vnx_snap_shots BOOLEAN,
    virtual_provisioning BOOLEAN,
    unisphere_analyzer BOOLEAN,
    unisphere_remote BOOLEAN,
    storage_analytics BOOLEAN,
    unified_file_oe_required BOOLEAN,
    dial_home_activities BOOLEAN,
    flash_storage_layout_services_id bigint,
    vnx_file_servers_number INT,
    total_storage_amount DOUBLE,
    active_data_movers_number INT,
    control_stations_number INT,
    file_systems_number INT,
    avg_file_system_size VARCHAR(256),
    storage_pools_number INT,
    storage_groups_number INT,
    thin_luns_number INT,
    iscsi BOOLEAN,
    iscsi_required BOOLEAN,
    iscsi_host_quantity INT,
    ivnx_scsi_host_quantity INT,
    idart_scsi_host_quantity INT,
    FOREIGN KEY (vnx_clariion_install_type_id) REFERENCES VnxClariionInstallType (id),
    FOREIGN KEY (unified_conversion_type_id) REFERENCES UnifiedConversionType (id),
    FOREIGN KEY (vnx_install_protocol_type_id) REFERENCES VnxInstallProtocolType (id),
    FOREIGN KEY (vnx_install_protocol_sub_type_id) REFERENCES VnxInstallProtocolSubType (id),
    FOREIGN KEY (flash_storage_layout_services_id) REFERENCES FlashStorageLayoutServices (id)
);

CREATE TABLE Vplex (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    knowledge_transfer_hours DECIMAL(20, 2),
    sites_number INT,
    engine_number INT,
    directors_number INT,
    existing_c4_upgraded_number INT,
    virtual_volumes_number INT,
    mirrors_number INT,
    metro_clusters_number INT,
    geo_clusters_number INT,
    hosts_number INT,
    arrays_number INT,
    storage_ports_number INT,
    storage_volumes_number INT,
    witness_server_number INT,
    data_mobility_type_id bigint,
    data_mobility_jobs_number INT,
    encapsulated_hosts_number INT,
    emc_installed_option BOOLEAN,
    recoverpoint_installed_option BOOLEAN,
    FOREIGN KEY (data_mobility_type_id) REFERENCES VplexDataMobilityType (id)
);


CREATE TABLE InfrastructureRequestData (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    general_comment VARCHAR(256),
    symmetrix_mf_service_enabled BOOLEAN,
    symmetrix_os_service_enabled BOOLEAN,
    data_migration_service_enabled BOOLEAN,
    vnx_clariion_service_enabled BOOLEAN,
    cx_replication_service_enabled BOOLEAN,
    san_assessment_service_enabled BOOLEAN,
    array_health_check_service_enabled BOOLEAN,
    san_health_check_service_enabled BOOLEAN,
    vplex_service_enabled BOOLEAN,
    environment_details_information_id bigint,
    vnx_clariion_information_id bigint,
    data_migration_information_id bigint,
    open_replicator_id bigint,
    symmetrix_mf_id bigint,
    symmetrix_os_id bigint,
    vplex_id bigint,
    FOREIGN KEY (environment_details_information_id) REFERENCES EnvironmentDetailsInformation (id),
    FOREIGN KEY (vnx_clariion_information_id) REFERENCES VnxClariionInformation (id),
    FOREIGN KEY (data_migration_information_id) REFERENCES DataMigrationInformation (id),
    FOREIGN KEY (symmetrix_mf_id) REFERENCES SymmetrixMF (id),
    FOREIGN KEY (symmetrix_os_id) REFERENCES SymmetrixOS (id),
    FOREIGN KEY (vplex_id) REFERENCES Vplex (id)
);

CREATE TABLE StringServiceData (
    id bigint auto_increment NOT NULL PRIMARY KEY, 
    service_name VARCHAR(256),
    description VARCHAR(256),
    value VARCHAR(256)
);

CREATE TABLE BooleanServiceData (
    id bigint auto_increment NOT NULL PRIMARY KEY, 
    service_name VARCHAR(256),
    description VARCHAR(256),
    enabled BOOLEAN
);

CREATE TABLE MainframeServicesScope (
    id bigint auto_increment NOT NULL PRIMARY KEY, 
    data_analytics_healthcheck BOOLEAN,
    ezsm_ecc_info_mover BOOLEAN,
    dmx_vmax_data_migration BOOLEAN,
    dmx_vmax_hardware_implementation BOOLEAN,
    dmx_vmax_srdf BOOLEAN,
    dmx_vmax_time_finder BOOLEAN,
    dmx_vmax_autoswap_gddr BOOLEAN,
    dlm_data_migration BOOLEAN,
    dlm_healthcheck BOOLEAN,
    dlm_custom_requirements BOOLEAN,
    dlm_implement_upgrade BOOLEAN,
    dlm_reconfigure_add_move BOOLEAN,
    dlm_scripting BOOLEAN,
    dlm_services BOOLEAN,
    dlm_implementation BOOLEAN
);

CREATE TABLE MainframeRequestData (
    id bigint auto_increment NOT NULL PRIMARY KEY, 
    general_comment VARCHAR(256),
    services_scope_id bigint,
    FOREIGN KEY (services_scope_id) REFERENCES MainframeServicesScope (id)
);

CREATE TABLE MainframeRequestData_booleanServiceData (
    mainframe_request_data_id bigint,
    boolean_service_data_id bigint,
    FOREIGN KEY (mainframe_request_data_id) REFERENCES MainframeRequestData (id),
    FOREIGN KEY (boolean_service_data_id) REFERENCES BooleanServiceData (id)
);

CREATE TABLE MainframeRequestData_stringServiceData (
    mainframe_request_data_id bigint,
    string_service_data_id bigint,
    FOREIGN KEY (mainframe_request_data_id) REFERENCES MainframeRequestData (id),
    FOREIGN KEY (string_service_data_id) REFERENCES StringServiceData (id)
);

CREATE TABLE MSSFcAtaDrives (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    fc_ata_73gb VARCHAR(256),
    fc_ata_146gb VARCHAR(256),
    fc_ata_300gb VARCHAR(256),
    fc_ata_400gb VARCHAR(256),
    fc_ata_450gb VARCHAR(256),
    fc_ata_500gb VARCHAR(256),
    fc_ata_600gb VARCHAR(256),
    fc_ata_750gb VARCHAR(256),
    fc_ata_1tb VARCHAR(256),
    fc_ata_2tb VARCHAR(256),
    fc_ata_3tb_4g VARCHAR(256),
    fc_ata_other VARCHAR(256)
);

CREATE TABLE MSSFlashDrives (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    flash_73gb VARCHAR(256),
    flash_100gb VARCHAR(256),
    flash_146gb VARCHAR(256),
    flash_200gb VARCHAR(256),
    flash_400gb VARCHAR(256),
    flash_other VARCHAR(256)
);

CREATE TABLE MSSVnxSasDrives (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    vnx_sas_300gb VARCHAR(256),
    vnx_sas_25_inch_300gb VARCHAR(256),
    vnx_sas_600gb VARCHAR(256),
    vnx_sas_25_inch_600gb VARCHAR(256),
    vnx_sas_25_inch_900gb VARCHAR(256),
    vnx_sas_35_inch_900gb VARCHAR(256),
    vnx_sas_1tb VARCHAR(256),
    vnx_sas_2tb VARCHAR(256),
    vnx_sas_3tb VARCHAR(256),
    vnx_sas_100gb_flash VARCHAR(256),
    vnx_sas_200gb_flash VARCHAR(256),
    vnx_sas_other VARCHAR(256)
);

CREATE TABLE MSSClariionAx4Drives (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    clariion_ax4_sataii_500gb VARCHAR(256),
    clariion_ax4_sataii_750gb VARCHAR(256),
    clariion_ax4_sataii_1000gb VARCHAR(256),
    clariion_ax4_sas_146gb_15k VARCHAR(256),
    clariion_ax4_sas_300gb_15k VARCHAR(256),
    clariion_ax4_sas_400gb_15k VARCHAR(256),
    clariion_ax4_sas_450gb_10k VARCHAR(256),
    clariion_ax4_sas_600gb_10k VARCHAR(256),
    clariion_ax4_other VARCHAR(256)
);

CREATE TABLE MSSCenteraNodes (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    gen1_nodes_640gb VARCHAR(256),
    gen2_nodes_1tb VARCHAR(256),
    gen3_nodes_128tb VARCHAR(256),
    gen4_nodes_750gb VARCHAR(256),
    gen4_nodes_128tb VARCHAR(256),
    gen4_nodes_2tb VARCHAR(256),
    gen4_lp_nodes_1tb VARCHAR(256),
    gen4_lp_nodes_2tb VARCHAR(256),
    centera_nodes_other VARCHAR(256)
);

CREATE TABLE MSSAvamarNodes (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    storage_nodes_1tb VARCHAR(256),
    storage_nodes_2tb VARCHAR(256),
    storage_nodes_33tb VARCHAR(256),
    utility_nodes_gen1 VARCHAR(256),
    utility_nodes_gen2_gen3 VARCHAR(256),
    utility_nodes_gen4 VARCHAR(256),
    accelerator_nodes_gen1 VARCHAR(256),
    small_accelerator_nodes_gen2 VARCHAR(256),
    large_accelerator_nodes_gen2 VARCHAR(256),
    accelerator_nodes_gen3_gen4 VARCHAR(256),
    storage_nodes_13tb_gen4 VARCHAR(256),
    storage_nodes_26tb_gen4 VARCHAR(256),
    storage_nodes_39tb_gen4 VARCHAR(256),
    storage_nodes_78tb_gen4 VARCHAR(256),
    avamar_nodes_other VARCHAR(256)
);

CREATE TABLE MSSDataDomain (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    model_type VARCHAR(256),
    serial_number VARCHAR(256),
    num_retention_drives INT
);

CREATE TABLE MSSAtmos (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    atmos_25_inch_250gb VARCHAR(256),
    atmos_1tb VARCHAR(256),
    atmos_2tb VARCHAR(256),
    atmos_3tb VARCHAR(256),
    atmos_other VARCHAR(256)
);

CREATE TABLE MSSGreenplum (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    greenplum_25_inch_600gb_10k VARCHAR(256),
    greenplum_35_inch_600gb_15k VARCHAR(256),
    greenplum_35_inch_2tb VARCHAR(256)
);

CREATE TABLE MSSArray (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    location VARCHAR(256),
    service_id bigint,
    platform_id bigint,
    fc_ata_drives_id bigint,
    flash_drives_id bigint,
    vnx_sas_drives_id bigint,
    clariion_ax4_drives_id bigint,
    centera_nodes_id bigint,
    avamar_nodes_id bigint,
    data_domain_id bigint,
    atmos_id bigint,
    greenplum_id bigint,
    FOREIGN KEY (service_id) REFERENCES MSSService (id),
    FOREIGN KEY (platform_id) REFERENCES MSSPlatform (id),
    FOREIGN KEY (fc_ata_drives_id) REFERENCES MSSFcAtaDrives (id),
    FOREIGN KEY (flash_drives_id) REFERENCES MSSFlashDrives (id),
    FOREIGN KEY (vnx_sas_drives_id) REFERENCES MSSVnxSasDrives (id),
    FOREIGN KEY (clariion_ax4_drives_id) REFERENCES MSSClariionAx4Drives (id),
    FOREIGN KEY (centera_nodes_id) REFERENCES MSSCenteraNodes (id),
    FOREIGN KEY (avamar_nodes_id) REFERENCES MSSAvamarNodes (id),
    FOREIGN KEY (atmos_id) REFERENCES MSSAtmos (id),
    FOREIGN KEY (data_domain_id) REFERENCES MSSDataDomain (id),
    FOREIGN KEY (greenplum_id) REFERENCES MSSGreenplum (id)
);

CREATE TABLE MSSRequestData (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    service_scope_description VARCHAR(256),
    general_comment VARCHAR(256),
    duration_months_id bigint,
    FOREIGN KEY (duration_months_id) REFERENCES DurationMonths (id)
);

CREATE TABLE MSS_array (
    mss_request_data_id bigint NOT NULL,
    mss_array_id bigint NOT NULL,
    FOREIGN KEY (mss_request_data_id) REFERENCES MSSRequestData (id),
    FOREIGN KEY (mss_array_id) REFERENCES MSSArray (id)
);

CREATE TABLE NASDestination (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    celerra BOOLEAN,
    vnx BOOLEAN,
    vnxe BOOLEAN,
    network_appliance BOOLEAN,
    centera BOOLEAN,
    windows BOOLEAN,
    atmos BOOLEAN,
    data_domain BOOLEAN
);

CREATE TABLE CTAImplementationArray (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    location VARCHAR(256),
    appliance_type_id bigint,
    clustered_appliance BOOLEAN,
    clusters_num INT,
    source_file_server_type_id bigint,
    source_exports_shares_num INT,
    multi_tier_archiving BOOLEAN,
    multi_tier_sites_num INT,
    security_hardening BOOLEAN,
    nas_destination_id bigint,
    archive_policies_num INT,
    migration_policies_num INT,
    capacity_management BOOLEAN,
    FOREIGN KEY (appliance_type_id) REFERENCES CTAApplianceType (id),
    FOREIGN KEY (source_file_server_type_id) REFERENCES CTASourceFileServerType (id),
    FOREIGN KEY (nas_destination_id) REFERENCES NASDestination (id)
);

CREATE TABLE CTAImplementation (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    customer_expectations VARCHAR(256)
);

CREATE TABLE CTAImplementation_array (
    cta_implementation_id bigint NOT NULL,
    cta_implementation_array_id bigint NOT NULL,
    FOREIGN KEY (cta_implementation_id) REFERENCES CTAImplementation (id),
    FOREIGN KEY (cta_implementation_array_id) REFERENCES CTAImplementationArray (id)
);

CREATE TABLE CTAConversion (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    conversation_type INT,
    cloud_tiering_appliance_num INT,
    file_servers_num INT,
    management_sites_num INT,
    files_converted_num INT,
    file_archivers_num INT,
    cfa_records_num INT,
    monitoring_method INT,
);

CREATE TABLE CTARaininfinity (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    include_clustered_deployment BOOLEAN,
    hardware_conversion BOOLEAN,
    mstp BOOLEAN,
    cross_functional_migration BOOLEAN,
    billable_hours_num DECIMAL(20, 2),
    appliances_deployed_num INT,
    file_servers_num INT,
    file_systems_num INT,
    include_sid BOOLEAN,
    local_user_objects_num INT,
    include_windows_proxy BOOLEAN,
    include_remote_migration BOOLEAN,
    rainfinity_appliances_num INT,
    rainfinity_vlans_num INT,
    domains_num INT,
    switch_config_required BOOLEAN,
    include_local_migration BOOLEAN,
    migrate_data_amount INT
);

CREATE TABLE CTAServicesScope (
    id bigint auto_increment NOT NULL PRIMARY KEY, 
    cta_design_and_implementation BOOLEAN,
    cta_implementation BOOLEAN,
    cta_conversion BOOLEAN,
    rainfinity_design_and_implementation BOOLEAN
);

CREATE TABLE CTARequestData (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    services_scope_id bigint,
    implementation_id bigint,
    conversion_id bigint,
    raininfinity_id bigint,
    sites_involved_id bigint,
    days_of_knowledge_transfer DECIMAL(20, 2),
    general_comment VARCHAR(256),
    FOREIGN KEY (services_scope_id) REFERENCES CTAServicesScope (id),
    FOREIGN KEY (implementation_id) REFERENCES CTAImplementation (id),
    FOREIGN KEY (conversion_id) REFERENCES CTAConversion (id),
    FOREIGN KEY (raininfinity_id) REFERENCES CTARaininfinity (id),
    FOREIGN KEY (sites_involved_id) REFERENCES SitesInvolved (id)
);

CREATE TABLE RoleSkillLevel (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    roll_skill_name VARCHAR(256),
    time_period VARCHAR(256),
    quantity DECIMAL(20, 2),
    additional_info VARCHAR(256)
);

CREATE TABLE ResidencyRoleSkillLevels (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    special_handling_instructions VARCHAR(256)
);

CREATE TABLE ResidencyRoleSkillLevels_backupLevels (
    residency_role_skill_levels_id bigint NOT NULL,
    role_skill_level_id bigint NOT NULL,
    FOREIGN KEY (residency_role_skill_levels_id) REFERENCES ResidencyRoleSkillLevels (id),
    FOREIGN KEY (role_skill_level_id) REFERENCES RoleSkillLevel (id)
);

CREATE TABLE ResidencyRoleSkillLevels_projectLevels (
    residency_role_skill_levels_id bigint NOT NULL,
    role_skill_level_id bigint NOT NULL,
    FOREIGN KEY (residency_role_skill_levels_id) REFERENCES ResidencyRoleSkillLevels (id),
    FOREIGN KEY (role_skill_level_id) REFERENCES RoleSkillLevel (id)
);

CREATE TABLE ResidencyRoleSkillLevels_adminLevels (
    residency_role_skill_levels_id bigint NOT NULL,
    role_skill_level_id bigint NOT NULL,
    FOREIGN KEY (residency_role_skill_levels_id) REFERENCES ResidencyRoleSkillLevels (id),
    FOREIGN KEY (role_skill_level_id) REFERENCES RoleSkillLevel (id)
);

CREATE TABLE ResidencyRoleSkillLevels_storageLevels (
    residency_role_skill_levels_id bigint NOT NULL,
    role_skill_level_id bigint NOT NULL,
    FOREIGN KEY (residency_role_skill_levels_id) REFERENCES ResidencyRoleSkillLevels (id),
    FOREIGN KEY (role_skill_level_id) REFERENCES RoleSkillLevel (id)
);

CREATE TABLE ResidencyRoleSkillLevels_supportLevels (
    residency_role_skill_levels_id bigint NOT NULL,
    role_skill_level_id bigint NOT NULL,
    FOREIGN KEY (residency_role_skill_levels_id) REFERENCES ResidencyRoleSkillLevels (id),
    FOREIGN KEY (role_skill_level_id) REFERENCES RoleSkillLevel (id)
);

CREATE TABLE ResidencyRoleSkillLevels_vmwareLevels (
    residency_role_skill_levels_id bigint NOT NULL,
    role_skill_level_id bigint NOT NULL,
    FOREIGN KEY (residency_role_skill_levels_id) REFERENCES ResidencyRoleSkillLevels (id),
    FOREIGN KEY (role_skill_level_id) REFERENCES RoleSkillLevel (id)
);

CREATE TABLE ResidencyRoleSkillLevels_archive (
  residency_role_skill_levels_id BIGINT NOT NULL,
  role_skill_level_id BIGINT NOT NULL,
  FOREIGN KEY (residency_role_skill_levels_id) REFERENCES ResidencyRoleSkillLevels (id),
  FOREIGN KEY (role_skill_level_id) REFERENCES RoleSkillLevel (id)
);

CREATE TABLE ResidencyRoleSkillLevels_cloud (
  residency_role_skill_levels_id BIGINT NOT NULL,
  role_skill_level_id BIGINT NOT NULL,
  FOREIGN KEY (residency_role_skill_levels_id) REFERENCES ResidencyRoleSkillLevels (id),
  FOREIGN KEY (role_skill_level_id) REFERENCES RoleSkillLevel (id)
);

CREATE TABLE ResidencyRoleSkillLevels_dataWarehouse (
  residency_role_skill_levels_id BIGINT NOT NULL,
  role_skill_level_id BIGINT NOT NULL,
  FOREIGN KEY (residency_role_skill_levels_id) REFERENCES ResidencyRoleSkillLevels (id),
  FOREIGN KEY (role_skill_level_id) REFERENCES RoleSkillLevel (id)
);

CREATE TABLE ResidencyRoleSkillLevels_isilon (
  residency_role_skill_levels_id BIGINT NOT NULL,
  role_skill_level_id BIGINT NOT NULL,
  FOREIGN KEY (residency_role_skill_levels_id) REFERENCES ResidencyRoleSkillLevels (id),
  FOREIGN KEY (role_skill_level_id) REFERENCES RoleSkillLevel (id)
);

CREATE TABLE ResidencyRoleSkillLevels_storageManagement (
  residency_role_skill_levels_id BIGINT NOT NULL,
  role_skill_level_id BIGINT NOT NULL,
  FOREIGN KEY (residency_role_skill_levels_id) REFERENCES ResidencyRoleSkillLevels (id),
  FOREIGN KEY (role_skill_level_id) REFERENCES RoleSkillLevel (id)
);

CREATE TABLE ResidencyRoleSkillLevels_vblock (
  residency_role_skill_levels_id BIGINT NOT NULL,
  role_skill_level_id BIGINT NOT NULL,
  FOREIGN KEY (residency_role_skill_levels_id) REFERENCES ResidencyRoleSkillLevels (id),
  FOREIGN KEY (role_skill_level_id) REFERENCES RoleSkillLevel (id)
);

CREATE TABLE ResidencyRoleSkillLevels_virtualizationXtremeIO (
  residency_role_skill_levels_id BIGINT NOT NULL,
  role_skill_level_id BIGINT NOT NULL,
  FOREIGN KEY (residency_role_skill_levels_id) REFERENCES ResidencyRoleSkillLevels (id),
  FOREIGN KEY (role_skill_level_id) REFERENCES RoleSkillLevel (id)
);

CREATE TABLE ResidencyRequestData (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    payment_type_id bigint,
    location VARCHAR(256),
    special_conditions VARCHAR(256),
    work_start_day_id bigint,
    work_end_day_id bigint,
    approximate_start_date DATE,
    work_hours_num DECIMAL(20, 2),
    general_comment VARCHAR(256),
    role_skill_levels_id bigint,
    FOREIGN KEY (payment_type_id) REFERENCES ResidencyPaymentType (id),
    FOREIGN KEY (work_start_day_id) REFERENCES WeekDay (id),
    FOREIGN KEY (work_end_day_id) REFERENCES WeekDay (id),
    FOREIGN KEY (role_skill_levels_id) REFERENCES ResidencyRoleSkillLevels (id)
);

CREATE TABLE SourceOneFeatures (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    email_archiving BOOLEAN,
    discovery_manager BOOLEAN,
    share_point_archiving BOOLEAN,
    file_archiving BOOLEAN,
    email_supervisor BOOLEAN,
    share_point_storage_managment BOOLEAN,
    cloud_tiering_app_mgmt BOOLEAN,
);

CREATE TABLE SourceOneDROptions (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    full_dr BOOLEAN,
    dr_planning BOOLEAN,
    dr_testing BOOLEAN,
);

CREATE TABLE SourceOneDesignImpl (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    knowledge_transfer_hours DECIMAL(20, 2),
    mailboxes_num INT,
    include_piolt BOOLEAN,
    include_meeting BOOLEAN,
    features_id bigint,
    dr_options_id bigint,
    include_validation_sizing BOOLEAN,
    include_shortcut_email BOOLEAN,
    include_shortcut_file_archive BOOLEAN,
    include_lexicon_query BOOLEAN,
    supervised_users_num INT,
    master_servers_num INT,
    email_mgmt_servers_num INT,
    sharepoint_archiving_servers_num INT,
    file_archiving_servers_num INT,
    mgmt_consoles_num INT,
    mapped_folders_num INT,
    email_archive_policies_num INT,
    file_archive_policies_num INT,
    dis_manager_admin_console_num INT,
    dis_manager_client_num INT,
    hold_folders_num INT,
    sample_matter_num INT,
    legal_hold_folders_num INT,
    archive_sharepoint_farms_num INT,
    storage_mgmt_sharepoint_farms_num INT,
    file_archive_mapped_folders_num INT,
    file_archive_polices_to_be_configured_num INT,
    cloud_tiering_appliances_num INT,
    reviewer_clients_num INT,
    FOREIGN KEY (features_id) REFERENCES SourceOneFeatures (id),
    FOREIGN KEY (dr_options_id) REFERENCES SourceOneDROptions (id)
);

CREATE TABLE SourceOneUpgrade(
    id bigint auto_increment NOT NULL PRIMARY KEY,
    knowledge_transfer_hours DECIMAL(20, 2),
    current_version VARCHAR(256),
    upgrade_version VARCHAR(256),
    master_servers_num INT,
    worker_servers_num INT,
    billable_hours_num INT
);

CREATE TABLE SourceOneMigration(
    id bigint auto_increment NOT NULL PRIMARY KEY,
    knowledge_transfer_hours DECIMAL(20, 2),
    email_xtender_servers_num INT,
    migrated_size INT,
    billable_hours_num INT
);

CREATE TABLE SourceOneHealthCheck (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    knowledge_transfer_hours DECIMAL(20, 2),
    servers_num INT,
    assessment_interviews_num INT,
    master_servers_num INT,
    worker_servers_num INT
);

CREATE TABLE SourceOneServicesScope (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    design_and_impl BOOLEAN,
    upgrade BOOLEAN,
    migration BOOLEAN,
    health_check BOOLEAN
);

CREATE TABLE SourceOneRequestData (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    services_scope_id bigint,
    design_impl_id bigint,
    upgrade_id bigint,
    migration_id bigint,
    health_check_id bigint,
    sites_involved_num INT,
    general_comment VARCHAR(256),
    brs_sme_comment VARCHAR(250),
    FOREIGN KEY (services_scope_id) REFERENCES SourceOneServicesScope (id),
    FOREIGN KEY (design_impl_id) REFERENCES SourceOneDesignImpl (id),
    FOREIGN KEY (upgrade_id) REFERENCES SourceOneUpgrade (id),
    FOREIGN KEY (migration_id) REFERENCES SourceOneMigration (id),
    FOREIGN KEY (health_check_id) REFERENCES SourceOneHealthCheck (id)
);

CREATE TABLE ASDAppSync (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    install_vsi BOOLEAN,
    app_sync_instances_num INT,
    vcenter_servers_num INT,
    application_production_hosts_num INT,
    vnx_arrays_num INT,
    application_mount_hosts_num INT,
    recover_point_appliances_num INT,
    knowledge_transfer_hours DECIMAL(20,2)
);

CREATE TABLE ASDUIM (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    install_type_id bigint,
    upgrade_type_id bigint,
    include_remote_install_agent BOOLEAN,
    remote_install_agents_num INT,
    uim_provisioning_vapps_num INT,
    isolation_zones_num INT,
    include_vco BOOLEAN,
    vcenter_instances_num INT,
    uim_provisioning_servers_num INT,
    vcloud_director_instances_num INT,
    converged_hardware_systems_num INT,
    blade_storage_grades_num INT,
    identity_pools_num INT,
    network_profiles_num INT,
    uim_operations_vapps_num INT,
    service_offerings_to_create_num INT,
    services_to_create_num INT,
    blades_to_provision_num INT,
    luns_to_provision_num INT,
    services_to_provision_num INT,
    data_sources_num INT,
    snmp_alerts_num INT,
    uim_operations_servers_num INT,
    uim_operations_users_num INT,
    perform_elastic_provisioning BOOLEAN,
    services_requiring_elastic_operations_num INT,
    blades_impacted_num INT,
    migrate_services BOOLEAN,
    non_uim_converged_hardware_systems_num INT,
    services_adopted_migrated_num INT,
    blades_adopted_migrated_num INT,
    customer_known BOOLEAN,
    remediate_hours DECIMAL(20,2),
    sa_knowledge_transfer_hours DECIMAL(20,2),
    is_knowledge_transfer_hours DECIMAL(20,2)
);

CREATE TABLE ASDServicesScope (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    ncm BOOLEAN,
    app_sync BOOLEAN,
    uim BOOLEAN
);

CREATE TABLE ASDRequestData (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    services_scope_id bigint,
    app_sync_id bigint,
    uim_id bigint,
    general_comment VARCHAR(256),
    FOREIGN KEY (services_scope_id) REFERENCES ASDServicesScope (id),
    FOREIGN KEY (app_sync_id) REFERENCES ASDAppSync (id),
    FOREIGN KEY (uim_id) REFERENCES ASDUIM (id)
);

CREATE TABLE HealthCheckAvamar (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    avamar_grids_num INT,
    assessment_interviews_num INT
);

CREATE TABLE HealthCheckDataDomain (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    appliances_num INT,
    assessment_interviews_num INT
);

CREATE TABLE HealthCheckDPA (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    site_implementations_num INT
);

CREATE TABLE HealthCheckDLM (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    dlm_subsystem_num INT,
    storage_amount INT
);

CREATE TABLE HealthCheckGreenPlum (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    master_host_servers_num INT
);

CREATE TABLE HealthCheckIonix (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    include_executive_summary_presentation BOOLEAN,
    size_environment INT
);

CREATE TABLE HealthCheckNetWorker (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    include_emc_assessment BOOLEAN,
    data_zones_num INT,
    assessment_interviews_num INT
);

CREATE TABLE HealthCheckSanSecurity (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    assessment_interviews_num INT,
    assessed_sites_num INT,
    emc_storage_arrays_num INT,
    san_attached_hosts_num INT,
    storage_management_stations_num INT
);

CREATE TABLE HealthCheckSAP (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    dlm_subsystem_num INT,
    storage_amount INT
);

CREATE TABLE HealthCheckSourceOne (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    servers_num INT,
    assessment_interviews_num INT
);

CREATE TABLE HealthCheckSymmetrixVmax (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    events_sold_num INT,
    dmx_vmax_arrays_num INT
);

CREATE TABLE HealthCheckSymmetrixVmaxStorageReplication (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    include_final_report BOOLEAN,
    include_executive_summary_review_presentation BOOLEAN,
    assessment_interviews_num INT,
    consistency_groups_num INT,
    symmetrix_arrays_num INT,
    open_systems_hosts_num INT,
    logical_devices_num INT
);

CREATE TABLE HealthCheckUnified (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    health_check_type_id bigint,
    events_sold_num INT,
    file_arrays_num INT,
    block_arrays_num INT,
    FOREIGN KEY (health_check_type_id) REFERENCES UnifiedHealthCheckType (id)
);

CREATE TABLE HealthCheckVblock (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    include_interoperability_check BOOLEAN,
    include_performance_check BOOLEAN,
    include_capacity_analysis BOOLEAN,
    include_flare_software_update BOOLEAN,
    block_arrays_num INT,
    san_switches_num INT,
    san_hosts_num INT
);

CREATE TABLE HealthCheckVmwareVirtualInfrastructure (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    include_executive_summary_review BOOLEAN,
    assessment_interviews_num INT,
    esx_servers_num INT,
    virtual_hosts_num INT
);

CREATE TABLE HealthCheckVplex (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    clusters_reviewed_num INT,
    events_sold_num INT
);

CREATE TABLE HealthCheckServicesScope (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    avamar BOOLEAN,
    data_domain BOOLEAN,
    dpa BOOLEAN,
    dlm BOOLEAN,
    greenplum BOOLEAN,
    ionix BOOLEAN,
    net_worker BOOLEAN,
    san_security BOOLEAN,
    sap BOOLEAN,
    source_one BOOLEAN,
    symmetrix_vmax BOOLEAN,
    symmetrix_vmax_storage_replication BOOLEAN,
    unified BOOLEAN,
    vblock BOOLEAN,
    vmware_virtual_infrastructure BOOLEAN,
    vplex BOOLEAN
);

CREATE TABLE HealthCheckRequestData (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    services_scope_id bigint,
    avamar_id bigint,
    data_domain_id bigint,
    dpa_id bigint,
    dlm_id bigint,
    greenplum_id bigint,
    ionix_id bigint,
    net_worker_id bigint,
    san_security_id bigint,
    sap_id bigint,
    source_one_id bigint,
    symmetrix_vmax_id bigint,
    symmetrix_vmax_storage_replication_id bigint,
    unified_id bigint,
    vblock_id bigint,
    vmware_virtual_infrastructure_id bigint,
    vplex_id bigint,
    general_comment VARCHAR(256),
    FOREIGN KEY (services_scope_id) REFERENCES HealthCheckServicesScope (id),
    FOREIGN KEY (avamar_id) REFERENCES HealthCheckAvamar (id),
    FOREIGN KEY (data_domain_id) REFERENCES HealthCheckDataDomain (id),
    FOREIGN KEY (dpa_id) REFERENCES HealthCheckDPA (id),
    FOREIGN KEY (dlm_id) REFERENCES HealthCheckDLM (id),
    FOREIGN KEY (greenplum_id) REFERENCES HealthCheckGreenPlum (id),
    FOREIGN KEY (ionix_id) REFERENCES HealthCheckIonix (id),
    FOREIGN KEY (net_worker_id) REFERENCES HealthCheckNetWorker (id),
    FOREIGN KEY (san_security_id) REFERENCES HealthCheckSanSecurity (id),
    FOREIGN KEY (sap_id) REFERENCES HealthCheckSAP (id),
    FOREIGN KEY (source_one_id) REFERENCES HealthCheckSourceOne (id),
    FOREIGN KEY (symmetrix_vmax_id) REFERENCES HealthCheckSymmetrixVmax (id),
    FOREIGN KEY (symmetrix_vmax_storage_replication_id) REFERENCES HealthCheckSymmetrixVmaxStorageReplication (id),
    FOREIGN KEY (unified_id) REFERENCES HealthCheckUnified (id),
    FOREIGN KEY (vblock_id) REFERENCES HealthCheckVblock (id),
    FOREIGN KEY (vmware_virtual_infrastructure_id) REFERENCES HealthCheckVmwareVirtualInfrastructure (id),
    FOREIGN KEY (vplex_id) REFERENCES HealthCheckVplex (id)
);

CREATE TABLE IsilonClusterRelocation (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    isilon_12uservers_num INT,
    isilon_4uservers_num INT,
    infiniband_switches_num INT,
    infiniband_chassis_num INT
);

CREATE TABLE IsilonDesignAndImpl (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    install_hardware BOOLEAN,
    include_tech_refresh BOOLEAN,
    new_cluster BOOLEAN,
    subnets_num INT,
    smart_connect_zones_num INT,
    auth_methods_num INT,
    shares_exports_num INT,
    smart_quotas_num INT,
    snapshots_iqentries_num INT,
    include_email BOOLEAN,
    include_subnet BOOLEAN,
    include_advice BOOLEAN,
    include_smart_connect BOOLEAN,
    include_auth BOOLEAN,
    include_file_system_shares BOOLEAN,
    install_insight_iq BOOLEAN,
    include_smart_quotas BOOLEAN,
    include_snapshots BOOLEAN,
    include_ndmp BOOLEAN,
    include_smart_lock BOOLEAN,
    include_1u_switch_install BOOLEAN,
    include_4u_chassis_install BOOLEAN,
    include_12u_node_install BOOLEAN,
    include_4u_node_install BOOLEAN
);

CREATE TABLE IsilonNetAppNodeBaseMigration (
  id BIGINT AUTO_INCREMENT NOT NULL PRIMARY KEY,
  source_system_type VARCHAR(256),
  capacity_nodes_num_1 INT,
  capacity_nodes_num_2 INT,
  capacity_nodes_num_3 INT,
  capacity_nodes_num_4 INT,
  capacity_nodes_num_5 INT,
  multi_protocol_data BOOLEAN,
  wide_links BOOLEAN,
  historical_sids BOOLEAN,
  local_users_groups BOOLEAN,
  archived_data BOOLEAN,
  cutovers_num INT
);

CREATE TABLE IsilonMigration (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    net_app_3rd_party_migration BOOLEAN,
    celerra_unified_file BOOLEAN,
    sync_iq BOOLEAN,
    tech_refresh BOOLEAN,
    plan_and_design BOOLEAN,
    impl_and_migration BOOLEAN,
    additional_testing BOOLEAN,
    additional_monitoring BOOLEAN,
    scripting_work BOOLEAN,
    install_isilon_hardware BOOLEAN,
    cifs BOOLEAN,
    nfs BOOLEAN,
    multi_protocol BOOLEAN,
    cifs_data_amount INT,
    include_local_users_groups BOOLEAN,
    nfs_data_amount INT,
    multi_protocol_data_amount INT,
    average_duration DECIMAL(20,2),
    data_mig_events_num INT,
    monitor_weeks_num INT,
    cutover_events_num INT,
    smart_pools_enabled BOOLEAN,
    remove_nodes_num INT,
    required_events_num INT,
    tech_refresh_moved_data INT,
    net_app_node_migration BOOLEAN,
    net_app_node_id BIGINT,
    FOREIGN KEY (net_app_node_id) REFERENCES IsilonNetAppNodeBaseMigration (id) 
);

CREATE TABLE IsilonHardwareUpgrade (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    perform_config BOOLEAN,
    nodes_num INT
);

CREATE TABLE IsilonServicesScope (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    cluster_relocation BOOLEAN,
    hardware_upgrade BOOLEAN,
    migration BOOLEAN,
    design_and_impl BOOLEAN,
    config_assurance BOOLEAN
);

CREATE TABLE IsilonRequestData (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    knowledge_transfer_hours DECIMAL(20,2),
    general_comment VARCHAR(256),
    services_scope_id bigint,
    cluster_relocation_id bigint,
    hardware_upgrade_id bigint,
    migration_id bigint,
    design_and_impl_id bigint,
    FOREIGN KEY (services_scope_id) REFERENCES IsilonServicesScope (id),
    FOREIGN KEY (cluster_relocation_id) REFERENCES IsilonClusterRelocation (id),
    FOREIGN KEY (hardware_upgrade_id) REFERENCES IsilonHardwareUpgrade (id),
    FOREIGN KEY (migration_id) REFERENCES IsilonMigration (id),
    FOREIGN KEY (design_and_impl_id) REFERENCES IsilonDesignAndImpl (id)
);

CREATE TABLE ViprImplementation (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    new_impl_type BOOLEAN,
    controller_instances_num INT,
    include_data_services BOOLEAN,
    include_ldap BOOLEAN,
    watch_4net_exist BOOLEAN,
    include_block_services BOOLEAN,
    include_vcops BOOLEAN,
    include_vco BOOLEAN,
    include_vcac BOOLEAN,
    include_scvmm BOOLEAN,
    include_vsi BOOLEAN,
    unix_hosts_num INT,
    windows_hosts_num INT,
    v_center_hosts_num INT,
    file_only_arrays_num INT,
    block_arrays_num INT,
    vplex_arrays_num INT,
    recover_point_systems_num INT,
    cisco_switch_fabrics_num INT,
    brocade_switch_fabrics_num INT,
    virtual_arrays_num INT,
    catalog_services_num INT,
    user_roles_num INT,
    ds_buckets_num INT,
    ds_pools_num INT,
    data_stores_num INT,
    ds_ingestions_num INT,
    hadoop_clusters_num INT,
    hadoop_nodes_num INT,
    include_hdfs BOOLEAN,
    include_kerberos_auth BOOLEAN,
    sa_knowledge_transfer_hours DECIMAL(20,2),
    include_vipr_content_address_storage_api_support BOOLEAN,
    include_vipr_sofwtare_install_for_3rd_party_systems BOOLEAN,
    tenants_defined_num INT,
    openstack_cinder_arrays_integrated_num INT,
    scaleio_protection_domains_num INT,
    block_file_virtual_pools_num INT,
    projects_num INT,
    additional_hours_for_testing_num DECIMAL(20,2)
);


CREATE TABLE HostBasedMigrationTool (
    id bigint auto_increment NOT NULL PRIMARY KEY, 
    name VARCHAR(256)
);

CREATE TABLE XtremeHostBasedMigrationTool (
    id bigint auto_increment NOT NULL PRIMARY KEY, 
    name VARCHAR(256)
);

CREATE TABLE ECSApplianceDesignImpl (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    include_data_services_for_hdfs BOOLEAN,
    include_integration_with_ad_ldap BOOLEAN,
    include_kerberos_auth_mode BOOLEAN,
    include_vipr_content_address_storage_api_support BOOLEAN,
    watch4net_platform_exists BOOLEAN,
    ecs_systems_with_block_num INT,
    ecs_unstructured_systems_num INT,
    tenants_defined_num INT,
    hadoop_clusters_num INT,
    total_hadoop_cluster_nodes_num INT,
    virtual_arrays_num INT,
    block_virtual_pools_num INT,
    object_virtual_pools_num INT,
    projects_num INT,
    data_service_buckets_num INT,
    user_roles_defined_num INT,
    catalog_services_to_customize_num INT,
    cas_required_num INT
);

CREATE TABLE ViprDataServiceOnCommodityDesignImpl (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    include_data_services_for_hdfs BOOLEAN,
    include_integration_with_ad_ldap BOOLEAN,
    include_kerberos_auth_mode BOOLEAN,
    include_vipr_content_address_storage_api_support BOOLEAN,
    watch4net_platform_exists BOOLEAN,
    commodity_storage_systems_num INT,
    tenants_defined_num INT,
    hadoop_clusters_num INT,
    total_hadoop_cluster_nodes_num INT,
    virtual_arrays_num INT,
    object_virtual_pools_num INT,
    projects_num INT,
    user_roles_defined_num INT,
    catalog_services_to_customize_num INT,
    cas_required_num INT
);

CREATE TABLE ViprDataMigrationPPMEPlanningDesign (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    total_source_target_sites_num INT,
    new_physical_hosts_included_num INT,
    new_esx_servers_num INT,
    new_enterprise_directors_num INT,
    new_departmental_switches_num INT,
    new_vnx_block_storage_arrays_num INT,
    data_migration_complexity_factor_percent DECIMAL(20,2),
    new_symmetrix_storage_arrays_num INT,
    vnx_blocks_to_upgrade_num INT,
    symmetrix_to_upgrade_num INT,
    xtreme_io_clusters_num INT,
    non_emc_storage_arrays_num INT
);

CREATE TABLE ViprDataMigrationPPMEImplementationMigration (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    remove_existing_emc_storage BOOLEAN,
    relocate_reinstall_existing_emc_storage BOOLEAN,
    include_storage_data_erasure BOOLEAN,
    include_additional_bin_file_work BOOLEAN,
    bin_files_design_implement_num INT,
    hours_per_bin_file DECIMAL(20,2),
    include_xtreme_io_clusters_config BOOLEAN,
    tb_migrated_source_data_amount INT,
    data_migration_complexity_factor_percent DECIMAL(20,2),
    total_hosts_migrate_by_emc_num INT,
    new_design_included_hosts_num INT,
    new_esx_servers_num INT,
    customer_zonning_work_on_switches BOOLEAN,
    existing_san_fabrics_num INT,
    hosts_booted_from_san_num INT,
    customer_lun_device_allocation BOOLEAN,
    new_vnx_blocks_storage_arrays_num INT,
    vnx_blocks_upgrade_num INT,
    xtreme_io_clusters_num INT,
    xtreme_io_bricks_per_cluster_num INT,
    hosts_migrated_via_ppme_num INT,
    include_device_size_changes BOOLEAN,
    servers_requiring_lun_size_changes_percent DECIMAL(20,2),
    vnx_arrays_to_erase_data_num INT,
    vnx_arrays_serial_numbers VARCHAR(256),
    symmetrix_storage_to_erase_data_num INT,
    symmetrix_storage_serial_numbers VARCHAR(256)
);

CREATE TABLE ViprDataMigrationPPME (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    planning_and_design BOOLEAN,
    implementation_and_migration BOOLEAN,
    customer_does_migration_work_themselves BOOLEAN,
    emc_onsite_support BOOLEAN,
    host_based_migration_tool_id BIGINT,
    include_esx_hosts_migration_via_vmotion BOOLEAN,
    include_second_round_data_gathering BOOLEAN,
    include_eca BOOLEAN,
    storage_array_vnx_clariion BOOLEAN,
    storage_array_vmax_dmax_symm BOOLEAN,
    storage_array_3rd_party_non_emc_storage BOOLEAN,
    storage_array_no_source BOOLEAN,
    storage_array_xtreme_io_cluster BOOLEAN,
    existing_physical_hosts_num INT,
    existing_esx_servers_num INT,
    swing_frame_required_for_migration BOOLEAN,
    total_source_array_involved_in_migration INT,
    total_target_array_involved_in_migration INT,
    include_device_size_changes BOOLEAN,
    servers_requiring_lun_size_changes_percent DECIMAL(20,2),
    tb_data_migration_amount INT,
    hosts_migrated_via_ppme_num INT,
    vmware_machines_num INT,
    ppme_planning_design_id BIGINT,
    ppme_implementation_migration_id BIGINT,
    FOREIGN KEY (host_based_migration_tool_id) REFERENCES HostBasedMigrationTool (id),
    FOREIGN KEY (ppme_planning_design_id) REFERENCES ViprDataMigrationPPMEPlanningDesign (id),
    FOREIGN KEY (ppme_implementation_migration_id) REFERENCES ViprDataMigrationPPMEImplementationMigration (id)
);

CREATE TABLE ViprRequestData (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    knowledge_transfer_hours DECIMAL(20,2),
    general_comment VARCHAR(256),
    planning_design_impl BOOLEAN,
    data_migration_with_ppme BOOLEAN,
    design_impl_for_commodity_service BOOLEAN,
    ecs_appliance_design_impl BOOLEAN,
    impl_id bigint,
    vipr_data_migration_ppme_id bigint,
    ecs_appliance_design_impl_id bigint,
    vipr_data_service_on_commodity_design_impl_id bigint,
    FOREIGN KEY (impl_id) REFERENCES ViprImplementation (id),
    FOREIGN KEY (vipr_data_migration_ppme_id) REFERENCES ViprDataMigrationPPME (id),
    FOREIGN KEY (ecs_appliance_design_impl_id) REFERENCES ECSApplianceDesignImpl (id),
    FOREIGN KEY (vipr_data_service_on_commodity_design_impl_id) REFERENCES ViprDataServiceOnCommodityDesignImpl (id)
);

CREATE TABLE VblockProject (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    custom_project_description VARCHAR(256)
);

CREATE TABLE VblockDesignImpl (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    vnx_type BOOLEAN,
    symmetrix_type BOOLEAN,
    vnx_luns_num INT,
    symmetrix_luns_num INT,
    include_unified_file BOOLEAN,
    include_ionix_uim BOOLEAN,
    type1_vsphere_servers_num INT,
    type2_vsphere_servers_num INT,
    cisco_partner_hours DECIMAL(20,2),
    vmware_partner_hours DECIMAL(20,2),
    type1_luns_num INT,
    type2_luns_num INT,
    uft_type1_num INT,
    uft_type2_num INT
);

CREATE TABLE VblockInfrastructure (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    vblock_series300_num INT,
    vblock_series700_num INT
);

CREATE TABLE VblockTechAssessment (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    assessed_sites INT,
    vmware_identified_servers_num INT
);

CREATE TABLE VblockServices (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    design_impl BOOLEAN,
    infrastructure BOOLEAN,
    tech_assessment BOOLEAN
);

CREATE TABLE VblockRequestData (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    describe_options VARCHAR(256),
    general_comment VARCHAR(256),
    services_id bigint,
    design_impl_id bigint,
    infrastructure_id bigint,
    tech_assessment_id bigint,
    project_id bigint,
    FOREIGN KEY (services_id) REFERENCES VblockServices (id),
    FOREIGN KEY (design_impl_id) REFERENCES VblockDesignImpl (id),
    FOREIGN KEY (infrastructure_id) REFERENCES VblockInfrastructure (id),
    FOREIGN KEY (tech_assessment_id) REFERENCES VblockTechAssessment (id),
    FOREIGN KEY (project_id) REFERENCES VblockProject (id)
);

CREATE TABLE CenteraToAtmosMigration (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    applications_num INT,
    protection_type INT,
    data_amount INT
);

CREATE TABLE CenteraFileErasure (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    clips_to_delete_num INT
);

CREATE TABLE CenteraUniversalAccess (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    active_cuas_num INT,
    data_pools_num INT,
    standby_cuas_num INT,
    cua_hardware_type_id bigint,
    relocated_cuas_num INT,
    FOREIGN KEY (cua_hardware_type_id) REFERENCES CUAHardwareType (id)
);

CREATE TABLE CenteraIntraClusterMigration (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    source_cubes_num INT,
    target_cubes_num INT,
    new_nodes_num INT,
    removed_nodes_num INT,
    existing_nodes_gen3 BOOLEAN
);

CREATE TABLE ExpansionNodeOnly (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    flex_kits_num INT
);

CREATE TABLE ExistingCenteraCluster (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    location VARCHAR(256),
    serial_number VARCHAR(256),
    modem_number VARCHAR(256),
    edition_id bigint,
    generation_id bigint,
    health_check_id bigint,
    replication_target VARCHAR(256),
    migration_source VARCHAR(256),
    migration_target VARCHAR(256),
    cicm BOOLEAN,
    applications_writting VARCHAR(256),
    array_action_id bigint,
    certified_data_erasure_required BOOLEAN,
    data_deletion_required BOOLEAN,
    customer_clip_list BOOLEAN,
    FOREIGN KEY (edition_id) REFERENCES CenteraEditionType (id),
    FOREIGN KEY (generation_id) REFERENCES CenteraGenerationType (id),
    FOREIGN KEY (health_check_id) REFERENCES CenteraHealthCheckType (id),
    FOREIGN KEY (array_action_id) REFERENCES CenteraArrayActionType (id)
);

CREATE TABLE NewCenteraCluster (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    location VARCHAR(256),
    edition_id bigint,
    generation_id bigint,
    protection_scheme_id bigint,
    nodes_num INT,
    replication_target VARCHAR(256),
    migration_source VARCHAR(256),
    located_at_target_site BOOLEAN,
    moved_from_target_site BOOLEAN,
    applications_writting VARCHAR(256),
    FOREIGN KEY (edition_id) REFERENCES CenteraEditionType (id),
    FOREIGN KEY (generation_id) REFERENCES CenteraGenerationType (id),
    FOREIGN KEY (protection_scheme_id) REFERENCES CenteraProtectionSchemeType (id)
);

CREATE TABLE CenteraDesignImpl (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    centeras_exist BOOLEAN,
    existing_centeras_require_review BOOLEAN,
    existing_centeras_review_detail VARCHAR(256),
    hardware_repurposing_detail VARCHAR(256),
    array_relocation_detail VARCHAR(256),
    shipping_arranger_id bigint,
    need_develop_code BOOLEAN,
    develop_code_detail VARCHAR(256),
    custom_scripting BOOLEAN,
    custom_scripting_detail VARCHAR(256),
    expected_timeline VARCHAR(256),
    replication_type_id bigint,
    implement_tape_backup BOOLEAN,
    FOREIGN KEY (shipping_arranger_id) REFERENCES CenteraShippingArranger (id),
    FOREIGN KEY (replication_type_id) REFERENCES CenteraReplicationType (id)
);

CREATE TABLE CenteraDesignImpl_existingClusters (
    centera_design_impl_id bigint NOT NULL,
    existing_centera_cluster_id bigint NOT NULL,
    FOREIGN KEY (centera_design_impl_id) REFERENCES CenteraDesignImpl (id),
    FOREIGN KEY (existing_centera_cluster_id) REFERENCES ExistingCenteraCluster (id)
);

CREATE TABLE CenteraDesignImpl_newClusters (
    centera_design_impl_id bigint NOT NULL,
    new_centera_cluster_id bigint NOT NULL,
    FOREIGN KEY (centera_design_impl_id) REFERENCES CenteraDesignImpl (id),
    FOREIGN KEY (new_centera_cluster_id) REFERENCES NewCenteraCluster (id)
);

CREATE TABLE AtmosDesignImpl (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    include_acdp BOOLEAN,
    rmgs_num INT,
    rmgs_ve_num INT,
    installation_segments_num INT,
    cabinet_type_ws2 BOOLEAN,
    hardware_servers_num INT,
    cifs_servers_num INT,
    nfs_servers_num INT,
    ifs_servers_num INT,
    ws_servers_num INT,
    tenants_num INT,
    sub_tenants_num INT,
    policies_num INT,
    include_secondary_acdpsite BOOLEAN
);

CREATE TABLE AtmosCenteraServicesScope (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    centera_design_impl BOOLEAN,
    atmos_design_impl BOOLEAN,
    centera_to_atmos_mig BOOLEAN,
    acdp BOOLEAN,
    cva BOOLEAN,
    cua BOOLEAN,
    cicm BOOLEAN,
    centera_file_erasure BOOLEAN,
    expansion_node_only BOOLEAN
);

CREATE TABLE AtmosCenteraRequestData (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    have_high_level_design BOOLEAN,
    sites_involved_id bigint,
    days_of_knowledge_transfer DECIMAL(20,2),
    customer_has_centera BOOLEAN,
    general_comment VARCHAR(256),
    services_scope_id bigint,
    atmos_design_impl_id bigint,
    centera_design_impl_id bigint,
    centera_to_atmos_migration_id bigint,
    centera_file_erasure_id bigint,
    centera_universal_access_id bigint,
    centera_intra_cluster_migration_id bigint,
    expansion_node_only_id bigint,
    FOREIGN KEY (sites_involved_id) REFERENCES SitesInvolved (id),
    FOREIGN KEY (services_scope_id) REFERENCES AtmosCenteraServicesScope (id),
    FOREIGN KEY (atmos_design_impl_id) REFERENCES AtmosDesignImpl (id),
    FOREIGN KEY (centera_design_impl_id) REFERENCES CenteraDesignImpl (id),
    FOREIGN KEY (centera_to_atmos_migration_id) REFERENCES CenteraToAtmosMigration (id),
    FOREIGN KEY (centera_file_erasure_id) REFERENCES CenteraFileErasure (id),
    FOREIGN KEY (centera_universal_access_id) REFERENCES CenteraUniversalAccess (id),
    FOREIGN KEY (centera_intra_cluster_migration_id) REFERENCES CenteraIntraClusterMigration (id),
    FOREIGN KEY (expansion_node_only_id) REFERENCES ExpansionNodeOnly (id)
);

CREATE TABLE VMwareAssessment (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    assessment_type INT,
    include_single_config BOOLEAN,
    include_multiple_config BOOLEAN,
    present_emc_report BOOLEAN,
    capacity_planner_sites_num INT,
    capacity_planner_collectors_num INT,
    days_to_capture_collection_data INT,
    additional_servers_num INT,
    vsphere_clusters_num INT
);

CREATE TABLE VMwareBackupRecovery (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    virtual_center_installations_num INT,
    esx_servers_num INT,
    virtual_hosts_num INT,
    assessment_interviews_num INT
);

CREATE TABLE VMwareHealthChecks (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    include_executive_summary_review BOOLEAN,
    assessment_interviews_num INT,
    esx_servers_num INT,
    virtual_hosts_num INT
);

CREATE TABLE VMwareReplication (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    install_srm BOOLEAN,
    customer_require_srm_training BOOLEAN,
    srm_adopters_num INT,
    srm_plans_num INT,
    celerra_ip BOOLEAN,
    vnx_block BOOLEAN,
    recover_point BOOLEAN,
    symmetrix_srdf BOOLEAN,
    new_symmetrix_num INT,
    existing_symmetrix_num INT,
    new_vnx_block_num INT,
    existing_vnx_block_num INT,
    new_recover_point_clusters_num INT,
    existing_recover_point_clusters_num INT,
    new_unified_file_servers_num INT,
    existing_celerra_file_servers_num INT
);

CREATE TABLE VMwareTCOAssessment (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    assessment_scenario INT,
    data_center_locations_num INT,
    conducted_interviews_num INT
);

CREATE TABLE VMwareVblockDesignImpl (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    include_partner_loe BOOLEAN,
    cisco BOOLEAN,
    vmware BOOLEAN,
    cisco_partner_hours DECIMAL(20,2),
    vmware_partner_hours DECIMAL(20,2),
    include_unified_file_options BOOLEAN,
    include_ionix_uim BOOLEAN,
    type1 BOOLEAN,
    type2 BOOLEAN,
    type1_vblocks_num INT,
    type1_luns_num INT,
    type1_vsphere_servers_num INT,
    type2_vblocks_num INT,
    type2_luns_num INT,
    type2_vsphere_servers_num INT,
    unified_file_type_vg2_num INT,
    unified_file_type_vg8_num INT
);

CREATE TABLE VMwareVblockInfraImpl (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    vblock_300series_num INT,
    vblock_700series_num INT
);

CREATE TABLE VMwareVblockInfraTechAssessment (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    assessed_sites_num INT,
    identified_servers_num INT
);

CREATE TABLE VMwareVblock (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    design_impl BOOLEAN,
    infra_tech_assessment BOOLEAN,
    infra_impl BOOLEAN,
    vblock_design_impl_id bigint,
    vblock_infra_impl_id bigint,
    vblock_infra_tech_assessment_id bigint,
    FOREIGN KEY (vblock_design_impl_id) REFERENCES VMwareVblockDesignImpl (id),
    FOREIGN KEY (vblock_infra_impl_id) REFERENCES VMwareVblockInfraImpl (id),
    FOREIGN KEY (vblock_infra_tech_assessment_id) REFERENCES VMwareVblockInfraTechAssessment (id)
);

CREATE TABLE VMwareConverter (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    migration_performed BOOLEAN,
    include_jump_start_workshops BOOLEAN,
    installs_num INT,
    servers_num INT,
    additional_hours DECIMAL(20,2),
    billable_hours_per_str DECIMAL(20,2),
    billable_hours_for_testing DECIMAL(20,2)
);

CREATE TABLE VMwareSvMotion (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    include_virtual_infra_35 BOOLEAN,
    virtual_machines_num INT,
    additional_hours DECIMAL(20,2)
);

CREATE TABLE VMwareViewDesign (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    include_mssql BOOLEAN,
    include_oracle BOOLEAN,
    esx_servers_num INT,
    virtual_center_installations_num INT,
    automated_desktop_pools_num INT,
    manual_desktop_pools_num INT,
    manager_connection_servers_num INT,
    manager_replica_servers_num INT,
    composer_instances_num INT,
    sql_databases_num INT,
    oracle_databases_num INT,
    manager_pods_num INT,
    manager_partitions_num INT,
    desktop_profiles_num INT,
    application_profiles_num INT,
    virtual_desktops_per_esx_host_num INT
);

CREATE TABLE VMwareViewImpl (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    include_mssql BOOLEAN,
    include_oracle BOOLEAN,
    esx_servers_num INT,
    virtual_center_installations_num INT,
    automated_desktop_pools_num INT,
    manual_desktop_pools_num INT,
    manager_connection_servers_num INT,
    manager_replica_servers_num INT,
    composer_instances_num INT,
    sql_databases_num INT,
    oracle_databases_num INT,
    billable_hours_for_testing DECIMAL(20,2)
);

CREATE TABLE VMwareView (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    design BOOLEAN,
    impl BOOLEAN,
    view_design_id bigint,
    view_impl_id bigint,
    FOREIGN KEY (view_design_id) REFERENCES VMwareViewDesign (id),
    FOREIGN KEY (view_impl_id) REFERENCES VMwareViewImpl (id)
);

CREATE TABLE VMwareVirtualInfra (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    server_storage_design_service BOOLEAN,
    infra_impl_service BOOLEAN,
    design_impl_jump_start_service BOOLEAN,
    design_impl_service BOOLEAN,
    jump_start_only_service BOOLEAN,
    storage_config_varieties_num INT,
    esx_hosts_num INT,
    identified_servers_num INT,
    include_rdm BOOLEAN,
    impl_vcenter_servers_num INT,
    impl_esxi_servers_num INT,
    impl_esxi_clusters_num INT,
    design_impl_jumpstart_vcenter_servers_num INT,
    design_impl_jumpstart_esx_clusters_num INT,
    design_impl_jumpstart_esx_servers_num INT,
    design_impl_jumpstart_billable_hours_for_testing DECIMAL(20,2),
    design_impl_vcenter_servers_num INT,
    design_impl_esx_clusters_num INT,
    design_impl_esx_servers_num INT
);

CREATE TABLE VMwareVSphere (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    include_upgrades BOOLEAN,
    include_jump_start_workshops BOOLEAN,
    billable_hours_for_testing DECIMAL(20,2),
    vcenter_instances_num INT,
    esx_servers_num INT,
    jump_start_workshops_num INT
);

CREATE TABLE VMwareServicesScope (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    assessment BOOLEAN,
    backup_recovery BOOLEAN,
    health_checks BOOLEAN,
    replication BOOLEAN,
    tco_assessment BOOLEAN,
    vce_vblock BOOLEAN,
    converter BOOLEAN,
    sv_motion BOOLEAN,
    vm_view BOOLEAN,
    virtual_infrastructure BOOLEAN,
    vsphere BOOLEAN
);

CREATE TABLE VMwareRequestData (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    general_comments VARCHAR(256),
    services_scope_id bigint,
    assessment_id bigint,
    backup_recovery_id bigint,
    health_checks_id bigint,
    replication_id bigint,
    tco_assessment_id bigint,
    vce_vblock_id bigint,
    converter_id bigint,
    sv_motion_id bigint,
    view_id bigint,
    virtual_infrastructure_id bigint,
    vsphere_id bigint,
    FOREIGN KEY (services_scope_id) REFERENCES VMwareServicesScope (id),
    FOREIGN KEY (assessment_id) REFERENCES VMwareAssessment (id),
    FOREIGN KEY (backup_recovery_id) REFERENCES VMwareBackupRecovery (id),
    FOREIGN KEY (health_checks_id) REFERENCES VMwareHealthChecks (id),
    FOREIGN KEY (replication_id) REFERENCES VMwareReplication (id),
    FOREIGN KEY (tco_assessment_id) REFERENCES VMwareTCOAssessment (id),
    FOREIGN KEY (vce_vblock_id) REFERENCES VMwareVblock (id),
    FOREIGN KEY (converter_id) REFERENCES VMwareConverter (id),
    FOREIGN KEY (sv_motion_id) REFERENCES VMwareSvMotion (id),
    FOREIGN KEY (view_id) REFERENCES VMwareView (id),
    FOREIGN KEY (virtual_infrastructure_id) REFERENCES VMwareVirtualInfra (id),
    FOREIGN KEY (vsphere_id) REFERENCES VMwareVSphere (id)
);
CREATE TABLE RecoverPointInstallationAndImplementation (
  id                                          BIGINT AUTO_INCREMENT NOT NULL PRIMARY KEY,
  delivery_option_design                      BOOLEAN,
  delivery_option_impl                        BOOLEAN,
  recover_point_option_id                     BIGINT,
  rp_replication_method_local                 BOOLEAN,
  rp_replication_method_remote                BOOLEAN,
  include_cluster_enabler                     BOOLEAN,
  recover_point_splitter_type_id              BIGINT,
  vnx_or_clariion_involved                    BOOLEAN,
  vmax_dmx_or_symm_involved                   BOOLEAN,
  non_emc_or_3rd_party_storage_involved       BOOLEAN,
  no_source_array_involved                    BOOLEAN,
  xtrem_io_cluster_involved                   BOOLEAN,
  existing_physical_hosts_num                 INT,
  existing_esx_servers_num                    INT,
  rp_env_clients_servers_num                  INT,
  rp_appliances_num                           INT,
  storage_systems_req_splitter_num            INT,
  include_bandwidth_analysis                  BOOLEAN,
  dispatch_emc_team                           BOOLEAN,
  include_3rd_party_storage_array             BOOLEAN,
  include_3rd_party_storage_array_integration BOOLEAN,
  non_emc_storage_arrays_num                  INT,
  include_replication_manager_env_integration BOOLEAN,
  include_vmware_vcenter_site_integration     BOOLEAN,
  ms_failover_clusters_num                    INT,
  rp_ce_cluster_nodes_num                     INT,
  rp_consistency_groups_num                   INT,
  FOREIGN KEY (recover_point_splitter_type_id) REFERENCES RecoverPointSplitterType (id),
  FOREIGN KEY (recover_point_option_id) REFERENCES RecoverPointOption (id)
);

CREATE TABLE RPAHardwareUpgrade (
  id                    BIGINT AUTO_INCREMENT NOT NULL PRIMARY KEY,
  use_gen1_rpa_hardware BOOLEAN,
  rpas_to_upgrade_num   INT
);

CREATE TABLE IntelligentFabricSplitterMigration (
  id                                        BIGINT AUTO_INCREMENT NOT NULL PRIMARY KEY,
  intelligent_fabric_migration_method_id    BIGINT,
  grid_analysis_required                    BOOLEAN,
  vnx_or_clariion_involved                  BOOLEAN,
  vmax_dmx_or_symm_involved                 BOOLEAN,
  non_emc_or_3rd_party_storage_involved     BOOLEAN,
  no_source_array_involved                  BOOLEAN,
  xtrem_io_cluster_involved                 BOOLEAN,
  rpa_clusters_to_migrate_num               INT,
  rpa_volumes_hosts_to_migrate_num          INT,
  include_bandwidth_analysis                BOOLEAN,
  include_3rd_party_storage_array           BOOLEAN,
  recover_point_option_id                   BIGINT,
  vplex_clusters_num                        INT,
  volumes_to_encapsulate_num                INT,
  encapsulation_events_per_emc_resource_num INT,
  host_encapsulations_to_vplex_num          INT,
  maintenance_windows_hours                 FLOAT,
  rp_env_clients_servers_num                INT,
  rp_replication_method_local               BOOLEAN,
  rp_replication_method_remote              BOOLEAN,
  FOREIGN KEY (intelligent_fabric_migration_method_id) REFERENCES IntelligentFabricMigrationMethod (id),
  FOREIGN KEY (recover_point_option_id) REFERENCES RecoverPointOption (id)
);

CREATE TABLE RecoverPoint (
  id                                       BIGINT AUTO_INCREMENT NOT NULL PRIMARY KEY,
  install_and_implement                    BOOLEAN,
  migrate_intelligent_fabric_splitter      BOOLEAN,
  upgrade_rpa_hardware                     BOOLEAN,
  installation_implementation_id           BIGINT,
  intelligent_fabric_splitter_migration_id BIGINT,
  rpa_hardware_upgrade_id                  BIGINT,
  FOREIGN KEY (installation_implementation_id) REFERENCES RecoverPointInstallationAndImplementation (id),
  FOREIGN KEY (intelligent_fabric_splitter_migration_id) REFERENCES IntelligentFabricSplitterMigration (id),
  FOREIGN KEY (rpa_hardware_upgrade_id) REFERENCES RPAHardwareUpgrade (id)
);

CREATE TABLE EDLDesignImpl (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    replication BOOLEAN,
    acsls BOOLEAN,
    auto_engine_failover BOOLEAN,
    integrated_backup_application BOOLEAN,
    backend_storage_arrays_num INT,
    backup_servers_num INT,
    physical_tape_lib_units_num INT,
    virtual_tape_libraries_num INT,
    virtual_tapes_num INT,
    virtual_tape_drives_num INT,
    replications_created_num INT
);

CREATE TABLE EDL (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    knowledge_transfer_hours DECIMAL(20,2),
    design BOOLEAN,
    implementation BOOLEAN,
    design_impl_id bigint,
    FOREIGN KEY (design_impl_id) REFERENCES EDLDesignImpl (id)
);

CREATE TABLE AvamarOptions (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    configure_clients BOOLEAN,
    configure_ndmp BOOLEAN,
    configure_avf BOOLEAN,
    configure_advanced_network BOOLEAN,
    configure_download_server BOOLEAN,
    configure_replication BOOLEAN,
    vmware_integeration BOOLEAN,
    data_domain_integration BOOLEAN,
    configure_vcloud_director BOOLEAN
);

CREATE TABLE AvamarPlugins (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    exchange BOOLEAN,
    sql_server BOOLEAN,
    oracle BOOLEAN,
    db2 BOOLEAN,
    sharepoint BOOLEAN,
    lotus_domino BOOLEAN,
    exchange_plugins_num INT,
    sql_server_plugins_num INT,
    oracle_plugins_num INT,
    db2_plugins_num INT,
    sharepoint_plugins_num INT,
    lotus_domino_plugins_num INT
);

CREATE TABLE AvamarNDMP (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    emc_celerra BOOLEAN,
    network_appliance BOOLEAN,
    emc_isilon BOOLEAN,
    emc_vnx BOOLEAN,
    ndmp_nodes_num INT,
    include_multistream_support BOOLEAN,
    streams_per_node_num INT,
    celerra_targets_num INT,
    net_app_filer_targets_num INT,
    isilon_targets_num INT,
    vnx_targets_num INT,
    data_set_creation_hours DECIMAL(20,2)
);

CREATE TABLE AvamarDesign (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    plugins_id bigint,
    options_id bigint,
    servers_num INT,
    clients_num INT,
    esx_servers_num INT,
    image_level_backups_num INT,
    ndmp_nodes_num INT,
    ndmp_targets_num INT,
    expansion_nodes_num INT,
    FOREIGN KEY (plugins_id) REFERENCES AvamarPlugins (id),
    FOREIGN KEY (options_id) REFERENCES AvamarOptions (id)
);

CREATE TABLE AvamarImplementation (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    plugins_id bigint,
    options_id bigint,
    servers_num INT,
    clients_num INT,
    esx_servers_num INT,
    image_level_backups_num INT,
    billable_hours DECIMAL(20,2),
    include_backup_recovery_manager BOOLEAN,
    include_hardware_installation BOOLEAN,
    data_nodes_num INT,
    data_set_creation_hours DECIMAL(20,2),
    install_type INT,
    auth_method INT,
    clients_percent DECIMAL(20,2),
    ndmp_id bigint,
    proxies_num INT,
    replication_sets_num INT,
    data_domain_servers_num INT,
    dd_boost_plugins_num INT,
    FOREIGN KEY (plugins_id) REFERENCES AvamarPlugins (id),
    FOREIGN KEY (options_id) REFERENCES AvamarOptions (id),
    FOREIGN KEY (ndmp_id) REFERENCES AvamarNDMP (id)
);

CREATE TABLE AvamarTapeOutImplementation (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    adt_type INT,
    grids_num INT,
    archive_servers_num INT,
    esx_servers_num INT,
    replication_connections_num INT,
    adt_transport_nodes_num INT,
    adt_controllers_num INT
);

CREATE TABLE AvamarTapeOutDesign (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    include_domain_reconfiguring BOOLEAN,
    adt_controllers_num INT,
    adt_domains_num INT,
    adt_clients_num INT
);

CREATE TABLE AvamarOperationalAssurance (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    include_operations_guide BOOLEAN,
    include_troubleshooting_guide BOOLEAN,
    include_high_level_arch BOOLEAN,
    grids_num INT,
    replication_sites_num INT
);

CREATE TABLE AvamarHealthCheck (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    grids_num INT,
    assessment_interviews_num INT
);

CREATE TABLE AvamarMigration (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    migration_type INT,
    include_client_reconfiguration BOOLEAN,
    include_source_data_wipe BOOLEAN,
    source_sys_nodes_num INT,
    target_sys_nodes_num INT,
    replication_monitoring_events_num INT,
    reconfigure_clients_num INT
);

CREATE TABLE AvamarIntegration (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    workshop BOOLEAN,
    pilot BOOLEAN,
    clients_num INT,
    configured_clients_num INT,
    dtlt_clients_activated BOOLEAN,
    grids_num INT
);

CREATE TABLE AvamarADMEConfiguration (
  id          BIGINT AUTO_INCREMENT NOT NULL PRIMARY KEY,
  include_cloud_path_config BOOLEAN,
  replication_pairs_num INT,
  staging_servers_num INT,
  cloud_paths_num INT
);

CREATE TABLE Avamar (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    knowledge_transfer_hours DECIMAL(20,2),
    design_impl_service BOOLEAN,
    tape_out_design_impl_service BOOLEAN,
    operational_assurance_service BOOLEAN,
    health_check_service BOOLEAN,
    migration_service BOOLEAN,
    integration_service BOOLEAN,
    vcloud_director_service BOOLEAN,
    server_type_id bigint,
    design_deliver_option BOOLEAN,
    implementation_deliver_option BOOLEAN,
    design_id bigint,
    implementation_id bigint,
    tape_out_design_id bigint,
    tape_out_implementation_id bigint,
    operational_assurance_id bigint,
    health_check_id bigint,
    migration_id bigint,
    integration_id bigint,
    adme_service BOOLEAN,
    adme_id BIGINT,
    FOREIGN KEY (server_type_id) REFERENCES AvamarServerType (id),
    FOREIGN KEY (design_id) REFERENCES AvamarDesign (id),
    FOREIGN KEY (implementation_id) REFERENCES AvamarImplementation (id),
    FOREIGN KEY (tape_out_design_id) REFERENCES AvamarTapeOutDesign (id),
    FOREIGN KEY (tape_out_implementation_id) REFERENCES AvamarTapeOutImplementation (id),
    FOREIGN KEY (operational_assurance_id) REFERENCES AvamarOperationalAssurance (id),
    FOREIGN KEY (health_check_id) REFERENCES AvamarHealthCheck (id),
    FOREIGN KEY (migration_id) REFERENCES AvamarMigration (id),
    FOREIGN KEY (integration_id) REFERENCES AvamarIntegration (id),
    FOREIGN KEY (adme_id) REFERENCES AvamarADMEConfiguration (id)
);


CREATE TABLE DataDomainBoostBackupServer (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    nbu BOOLEAN,
    rman BOOLEAN,
    ddbda BOOLEAN,
    ddbma BOOLEAN
);

CREATE TABLE DataDomainDesignImplContent (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    boost_backup_server_id bigint,
    integrate_sap_hana BOOLEAN,
    plan_design_implement_vtl BOOLEAN,
    include_ibm_iseries_brms BOOLEAN,
    ibm_pars_num INT,
    vtl_appliances_num INT,
    install_fibre_cards_num INT,
    create_vtls_num INT,
    backup_servers_num INT,
    appliances_for_ddboost_num INT,
    oracle_rman_backup_servers_num INT,
    oracle_backup_config_servers_num INT,
    sap_hana_databases_num INT,
    db2_servers_num INT,
    sap_hana_db_servers_num INT,
    sap_hana_oracle_servers_num INT,
    ms_sql_servers_num INT,
    FOREIGN KEY (boost_backup_server_id) REFERENCES DataDomainBoostBackupServer (id)
);

CREATE TABLE DataDomainDesign (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    boost_backup_server_id bigint,
    integrate_sap_hana BOOLEAN,
    plan_design_implement_vtl BOOLEAN,
    include_ibm_iseries_brms BOOLEAN,
    ibm_pars_num INT,
    vtl_appliances_num INT,
    install_fibre_cards_num INT,
    create_vtls_num INT,
    backup_servers_num INT,
    appliances_for_ddboost_num INT,
    oracle_rman_backup_servers_num INT,
    oracle_backup_config_servers_num INT,
    sap_hana_databases_num INT,
    db2_servers_num         INT,
    sap_hana_db_servers_num INT,
    sap_hana_oracle_servers_num INT,
    ms_sql_servers_num      INT,
  FOREIGN KEY (boost_backup_server_id) REFERENCES DataDomainBoostBackupServer (id)
);

CREATE TABLE DataDomainDesignApplianceModel (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    model_name VARCHAR(256),
    appliances_num INT
);

CREATE TABLE DataDomainDesign_applianceModels (
    data_domain_design_id bigint NOT NULL,
    data_domain_design_appliance_model_id bigint NOT NULL,
    FOREIGN KEY (data_domain_design_id) REFERENCES DataDomainDesign (id),
    FOREIGN KEY (data_domain_design_appliance_model_id) REFERENCES DataDomainDesignApplianceModel (id)
);

CREATE TABLE DataDomainImplementation (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    boost_backup_server_id bigint,
    integrate_sap_hana BOOLEAN,
    plan_design_implement_vtl BOOLEAN,
    include_ibm_iseries_brms BOOLEAN,
    ibm_pars_num INT,
    vtl_appliances_num INT,
    install_fibre_cards_num INT,
    create_vtls_num INT,
    backup_servers_num INT,
    appliances_for_ddboost_num INT,
    oracle_rman_backup_servers_num INT,
    oracle_backup_config_servers_num INT,
    sap_hana_databases_num INT,
    db2_servers_num         INT,
    sap_hana_db_servers_num INT,
    sap_hana_oracle_servers_num INT,
    ms_sql_servers_num      INT,
    FOREIGN KEY (boost_backup_server_id) REFERENCES DataDomainBoostBackupServer (id)
);

CREATE TABLE DataDomainImplApplianceModel (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    model_name VARCHAR(256),
    appliances_num INT,
    expansion_shelves_num INT,
    include_ipreplication BOOLEAN,
    device_type_id bigint,
    db_boost BOOLEAN,
    edl_virtual_tape_libraries_num INT,
    dd_boost_servers_num INT,
    FOREIGN KEY (device_type_id) REFERENCES DataDomainDeviceType (id)
);

CREATE TABLE DataDomainImplementation_applianceModels (
    data_domain_impl_id bigint NOT NULL,
    data_domain_impl_appliance_model_id bigint NOT NULL,
    FOREIGN KEY (data_domain_impl_id) REFERENCES DataDomainImplementation (id),
    FOREIGN KEY (data_domain_impl_appliance_model_id) REFERENCES DataDomainImplApplianceModel (id)
);

CREATE TABLE DataDomainUpgrade (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    upgrade_type_id bigint,
    appliances_num INT,
    dd890 BOOLEAN,
    dd890_appliances_num INT,
    dd990 BOOLEAN,
    dd990_appliances_num INT,
    dd4200 BOOLEAN,
    dd4200_appliances_num INT,
    dd4500 BOOLEAN,
    dd4500_appliances_num INT,
    dd7200 BOOLEAN,
    dd7200_appliances_num INT,
    storage_expansion_shelves_num INT,
    system_controller_upgrades_num INT,
    FOREIGN KEY (upgrade_type_id) REFERENCES DataDomainUpgradeType (id)
);

CREATE TABLE DataDomainVTL (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    include_ibm_iseries_brms BOOLEAN,
    ibm_pars_num INT,
    vtl_appliances_num INT,
    install_fibre_cards_num INT,
    create_vtls_num INT
);

CREATE TABLE DataDomainExpansionShelf (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    storage_expansion_shelves_num INT
);

CREATE TABLE DataDomainDataStaging (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    data_staging_type_id bigint,
    FOREIGN KEY (data_staging_type_id) REFERENCES DataDomainDataStagingType (id)
);

CREATE TABLE DataDomainIntegration (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    include_rman_scripting BOOLEAN,
    max_backup_window_time_id bigint,
    appliances_for_ddboost_num INT,
    servers_for_ddboost_num INT,
    oracle_rman_backup_servers_num INT,
    oracle_backup_config_servers_num INT,
    integration_type_id bigint,
    ibm_tivoli_storage_manager BOOLEAN,
    networker BOOLEAN,
    net_backup BOOLEAN,
    rman BOOLEAN,
    conducted_interviews_num INT,
    ibm_tsm_instances_num INT,
    networker_data_zones_num INT,
    symantec_net_backup_domains_num INT,
    oracle_data_servers_num INT,
    sap_hana_databases_num INT,
    FOREIGN KEY (max_backup_window_time_id) REFERENCES DataDomainMaxBackupWindowTime (id),
    FOREIGN KEY (integration_type_id) REFERENCES DataDomainIntegrationType (id)
);

CREATE TABLE DataDomainHealthCheck (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    data_domain_appliances_num INT,
    assessment_interviews_num INT
);

CREATE TABLE DataDomainMigration (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    migration_type_id bigint,
    centera2dd_migrations_num INT,
    dd2dd_migrations_num INT,
    monitoring_events_num INT,
    FOREIGN KEY (migration_type_id) REFERENCES DataDomainMigrationType (id)
);

CREATE TABLE DataDomainPreRack (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    boost_backup_server_id bigint,
    integrate_sap_hana BOOLEAN,
    plan_design_implement_vtl BOOLEAN,
    include_ibm_iseries_brms BOOLEAN,
    ibm_pars_num INT,
    vtl_appliances_num INT,
    install_fibre_cards_num INT,
    create_vtls_num INT,
    backup_servers_num INT,
    appliances_for_ddboost_num INT,
    oracle_rman_backup_servers_num INT,
    oracle_backup_config_servers_num INT,
    sap_hana_databases_num INT,
    pre_rack_type_id bigint,
    pre_racked_system_racks_num INT,
    edl_virtual_tape_libraries_num INT,
    servers_for_ddboost_num INT,
    db2_servers_num         INT,
    sap_hana_db_servers_num INT,
    sap_hana_oracle_servers_num INT,
    ms_sql_servers_num      INT,
    FOREIGN KEY (pre_rack_type_id) REFERENCES DataDomainPreRackType (id),
    FOREIGN KEY (boost_backup_server_id) REFERENCES DataDomainBoostBackupServer (id)
);

CREATE TABLE DataDomainBoost (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    include_rman_scripting BOOLEAN,
    max_backup_window_time_id bigint,
    appliances_for_ddboost_num INT,
    servers_for_ddboost_num INT,
    oracle_rman_backup_servers_num INT,
    oracle_backup_config_servers_num INT,
    boost_type_id bigint,
    FOREIGN KEY (max_backup_window_time_id) REFERENCES DataDomainMaxBackupWindowTime (id),
    FOREIGN KEY (boost_type_id) REFERENCES DataDomainBoostType (id)
);

CREATE TABLE DataDomainExtendedRetentionConversion (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    applicances_to_convert_num INT
);

CREATE TABLE DataDomainManagementCenterConfig (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    management_center_config_type INT
);

CREATE TABLE DataDomainSapHana (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    sap_hana_databases_num INT
);

CREATE TABLE DataDomain (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    knowledge_transfer_hours DECIMAL(20,2),
    implement_service BOOLEAN,
    upgrade_service BOOLEAN,
    implement_vtl_service BOOLEAN,
    data_staging_service BOOLEAN,
    expansion_shelf_service BOOLEAN,
    integration_service BOOLEAN,
    health_check_service BOOLEAN,
    migration_service BOOLEAN,
    pre_racked_service BOOLEAN,
    boost_service BOOLEAN,
    extended_retention_conversion_service BOOLEAN,
    management_center_config_service BOOLEAN,
    sap_hana_service BOOLEAN,
    design_activity BOOLEAN,
    implementation_activity BOOLEAN,
    design_impl_identical BOOLEAN,
    design_id bigint,
    implementation_id bigint,
    upgrade_id bigint,
    vtl_id bigint,
    expansion_shelf_id bigint,
    data_staging_id bigint,
    integration_id bigint,
    health_check_id bigint,
    migration_id bigint,
    pre_rack_id bigint,
    boost_id bigint,
    extended_retention_conversion_id bigint,
    management_center_config_id bigint,
    sap_hana_id bigint,
    design_impl_content_id bigint,
    FOREIGN KEY (design_impl_content_id) REFERENCES DataDomainDesignImplContent (id),
    FOREIGN KEY (design_id) REFERENCES DataDomainDesign (id),
    FOREIGN KEY (implementation_id) REFERENCES DataDomainImplementation (id),
    FOREIGN KEY (upgrade_id) REFERENCES DataDomainUpgrade (id),
    FOREIGN KEY (vtl_id) REFERENCES DataDomainVTL (id),
    FOREIGN KEY (expansion_shelf_id) REFERENCES DataDomainExpansionShelf (id),
    FOREIGN KEY (data_staging_id) REFERENCES DataDomainDataStaging (id),
    FOREIGN KEY (integration_id) REFERENCES DataDomainIntegration (id),
    FOREIGN KEY (health_check_id) REFERENCES DataDomainHealthCheck (id),
    FOREIGN KEY (migration_id) REFERENCES DataDomainMigration (id),
    FOREIGN KEY (pre_rack_id) REFERENCES DataDomainPreRack (id),
    FOREIGN KEY (boost_id) REFERENCES DataDomainBoost (id),
    FOREIGN KEY (extended_retention_conversion_id) REFERENCES DataDomainExtendedRetentionConversion (id),
    FOREIGN KEY (management_center_config_id) REFERENCES DataDomainManagementCenterConfig (id),
    FOREIGN KEY (sap_hana_id) REFERENCES DataDomainSapHana (id)
);

CREATE TABLE DPADesign (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    install_on_extended_database BOOLEAN,
    include_analysis_jobs BOOLEAN,
    include_recoverability_analysis BOOLEAN,
    include_custom_report_development BOOLEAN,
    include_interface_customization BOOLEAN,
    include_scale_plan BOOLEAN,
    collection_nodes_num INT,
    collector_nodes_num INT
);

CREATE TABLE DPAImplementation (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    upgrade_from_v5_environment BOOLEAN,
    include_custom_report_development BOOLEAN,
    include_interface_customization BOOLEAN,
    include_recoverability_analysis BOOLEAN,
    include_analysis_jobs BOOLEAN,
    upgrade_install_on_external_database BOOLEAN,
    upgrade_include_edl_monitoring BOOLEAN,
    upgrade_collection_nodes_num INT,
    upgrade_collector_nodes_num INT,
    upgrade_emc_disk_libraries_num INT,
    custom_report_development_install_on_external_database BOOLEAN,
    custom_report_development_include_edl_monitoring BOOLEAN,
    custom_report_development_collection_nodes_num INT,
    custom_report_development_collector_nodes_num INT,
    custom_report_development_emc_disk_libraries_num INT,
    interface_customization_install_on_external_database BOOLEAN,
    interface_customization_include_edl_monitoring BOOLEAN,
    interface_customization_collection_nodes_num INT,
    interface_customization_collector_nodes_num INT,
    interface_customization_emc_disk_libraries_num INT,
    recoverability_analysis_install_on_external_database BOOLEAN,
    recoverability_analysis_include_edl_monitoring BOOLEAN,
    recoverability_analysis_collection_nodes_num INT,
    recoverability_analysis_collector_nodes_num INT,
    recoverability_analysis_emc_disk_libraries_num INT,
    recoverability_agents_num INT,
    analysis_jobs_install_on_external_database BOOLEAN,
    analysis_jobs_include_edl_monitoring BOOLEAN,
    analysis_jobs_collection_nodes_num INT,
    analysis_jobs_collector_nodes_num INT,
    analysis_jobs_emc_disk_libraries_num INT,
    analysis_jobs_num INT
);

CREATE TABLE DPACustomization (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    include_third_party_integration_development BOOLEAN,
    include_analysis_jobs BOOLEAN,
    include_interface_customization BOOLEAN,
    include_custom_report_development BOOLEAN,
    third_party_integration_development_include_requirements_workshop BOOLEAN,
    third_party_integration_development_include_scale_plan BOOLEAN,
    third_party_integration_development_collection_nodes_num INT,
    third_party_integration_development_collector_nodes_num INT,
    analysis_jobs_include_requirements_workshop BOOLEAN,
    analysis_jobs_include_scale_plan BOOLEAN,
    analysis_jobs_collection_nodes_num INT,
    analysis_jobs_collector_nodes_num INT,
    analysis_jobs_num INT,
    interface_customization_include_requirements_workshop BOOLEAN,
    interface_customization_include_scale_plan BOOLEAN,
    interface_customization_collection_nodes_num INT,
    interface_customization_collector_nodes_num INT,
    custom_report_development_include_requirements_workshop BOOLEAN,
    custom_report_development_include_scale_plan BOOLEAN,
    custom_report_development_collection_nodes_num INT,
    custom_report_development_collector_nodes_num INT
);

CREATE TABLE DPAOperationalAssurance (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    include_requirements_workshop BOOLEAN,
    analysis_site_implementations_num INT
);

CREATE TABLE DPAUpgradeMigration (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    upgrade_migration_version INT,
    manual_migrations BOOLEAN,
    customization_migration BOOLEAN,
    estimated_migration_volumes INT,
    reconfigure_agents_num INT
);

CREATE TABLE DPAHealthCheck (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    site_implementations_num INT
);

CREATE TABLE DPA (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    knowledge_transfer_hours DECIMAL(20,2),
    implement_service BOOLEAN,
    operational_assurance_service BOOLEAN,
    customization_service BOOLEAN,
    upgrade_migration_service BOOLEAN,
    health_check_service BOOLEAN,
    design_activity BOOLEAN,
    implementation_activity BOOLEAN,
    design_id bigint,
    implementation_id bigint,
    operational_assurance_id bigint,
    customization_id bigint,
    upgrade_migration_id bigint,
    health_check_id bigint,
    FOREIGN KEY (design_id) REFERENCES DPADesign (id),
    FOREIGN KEY (implementation_id) REFERENCES DPAImplementation (id),
    FOREIGN KEY (operational_assurance_id) REFERENCES DPAOperationalAssurance (id),
    FOREIGN KEY (customization_id) REFERENCES DPACustomization (id),
    FOREIGN KEY (upgrade_migration_id) REFERENCES DPAUpgradeMigration (id),
    FOREIGN KEY (health_check_id) REFERENCES DPAHealthCheck (id)
);

CREATE TABLE NetworkerComponents (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    server BOOLEAN,
    advanced_backup_tech BOOLEAN,
    storage_nodes BOOLEAN,
    file_system_client_backups BOOLEAN,
    media_devices BOOLEAN,
    application_backups BOOLEAN,
    emc_backup_recovery_manager BOOLEAN
);

CREATE TABLE NetworkerStorageNodes (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    storage_node BOOLEAN,
    dedicated_storage_node BOOLEAN,
    de_duplication_node BOOLEAN,
    storage_nodes_num INT,
    dedicated_storage_nodes_num INT,
    de_duplication_nodes_num INT
);

CREATE TABLE NetworkerMediaDevices (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    auto_changer BOOLEAN,
    dd_boost BOOLEAN,
    tape_device BOOLEAN,
    atmos BOOLEAN,
    advanced_file_type_device BOOLEAN,
    auto_changers_num INT,
    tape_devices_num INT,
    advanced_file_type_devices_num INT,
    dd_boost_devices_num INT,
    atmos_devices_num INT
);

CREATE TABLE NetworkerServerDesign (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    impl_env INT,
    servers_num INT
);

CREATE TABLE NetworkerAdvancedBackupTechDesign (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    snmp BOOLEAN,
    vmware BOOLEAN,
    snapshot_management BOOLEAN,
    nas BOOLEAN,
    include_vmware_protection_backups BOOLEAN,
    vmware_backup_appliances_num INT,
    snapshot_management_app_hosts_num INT,
    snapshot_management_mount_hosts_num INT,
    nas_data_movers_num INT,
    vmware_vsphere_hosts_num INT
);

CREATE TABLE NetworkerFileSystemClientBackupsDesign (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    clients_num INT,
    cluster_client_connections_num INT
);

CREATE TABLE NetworkerApplicationBackupsDesign (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    ms_sql BOOLEAN,
    exchange BOOLEAN,
    share_point BOOLEAN,
    hyperv BOOLEAN,
    oracle BOOLEAN,
    my_sql BOOLEAN,
    lotus_notes BOOLEAN,
    sap BOOLEAN,
    meditech BOOLEAN,
    include_mssql_server_cluster BOOLEAN,
    ms_sql_servers_num INT,
    implement_exchange_granular_backups BOOLEAN,
    include_clustered_exchange_servers BOOLEAN,
    exchange_mailbox_servers_num INT,
    exchange_database_stores_num INT,
    share_point_include_mssql_server_cluster BOOLEAN,
    include_granular_share_point_backups BOOLEAN,
    include_share_point_distributed_env BOOLEAN,
    share_point_mssql_servers_num INT,
    share_point_farms_num INT,
    share_point_web_apps_num INT,
    share_point_sites_num INT,
    share_point_sub_sites_num INT,
    hyperv_env_clustered BOOLEAN,
    hyperv_servers_num INT,
    clustered_oracle_servers BOOLEAN,
    oracle_rman_backup_servers_num INT,
    oracle_backup_config_databases_num INT,
    my_sql_env_clustered BOOLEAN,
    my_sql_servers_num INT,
    lotus_notes_apps_clustered BOOLEAN,
    lotus_domino_instances_num INT,
    sap_env_clustered BOOLEAN,
    sap_app_servers_num INT,
    ms_sql_databases_num INT,
    exchange_data_domain_boost BOOLEAN,
    share_point_sql_databases_num INT,
    share_point_data_domain_boost BOOLEAN,
    include_extensive_rman_scripting BOOLEAN,
    meditech_backup_type_id BIGINT,
    num_of_meditech_hosts INT,
    num_of_meditech_storage_arrays INT,
    FOREIGN KEY (meditech_backup_type_id) REFERENCES MeditechBackupType (id)
);

CREATE TABLE NetworkerDesign (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    components_id bigint,
    storage_nodes_id bigint,
    media_devices_id bigint,
    server_id bigint,
    advanced_backup_tech_id bigint,
    file_system_client_backups_id bigint,
    application_backups_id bigint,
    FOREIGN KEY (components_id) REFERENCES NetworkerComponents (id),
    FOREIGN KEY (storage_nodes_id) REFERENCES NetworkerStorageNodes (id),
    FOREIGN KEY (media_devices_id) REFERENCES NetworkerMediaDevices (id),
    FOREIGN KEY (server_id) REFERENCES NetworkerServerDesign (id),
    FOREIGN KEY (advanced_backup_tech_id) REFERENCES NetworkerAdvancedBackupTechDesign (id),
    FOREIGN KEY (file_system_client_backups_id) REFERENCES NetworkerFileSystemClientBackupsDesign (id),
    FOREIGN KEY (application_backups_id) REFERENCES NetworkerApplicationBackupsDesign (id)
);

CREATE TABLE NetworkerServerImpl (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    impl_env INT,
    servers_num INT,
    management_consoles_num INT
);

CREATE TABLE NetworkerAdvancedBackupTechImpl (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    snmp BOOLEAN,
    vmware BOOLEAN,
    snapshot_management BOOLEAN,
    nas BOOLEAN,
    include_vmware_protection_backups BOOLEAN,
    vmware_backup_appliances_num INT,
    snapshot_management_app_hosts_num INT,
    snapshot_management_mount_hosts_num INT,
    nas_data_movers_num INT,
    snmp_modules_num INT,
    external_vmware_protection_appliances_num INT,
    virtual_machine_clients_num INT,
    emc_disk_arrays_num INT
);

CREATE TABLE NetworkerFileSystemClientBackupsImpl (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    clients_num INT,
    cluster_client_connections_num INT,
    firewall_support BOOLEAN
);

CREATE TABLE NetworkerApplicationBackupsImpl (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    ms_sql BOOLEAN,
    exchange BOOLEAN,
    share_point BOOLEAN,
    hyperv BOOLEAN,
    oracle BOOLEAN,
    my_sql BOOLEAN,
    lotus_notes BOOLEAN,
    sap BOOLEAN,
    include_mssql_server_cluster BOOLEAN,
    ms_sql_servers_num INT,
    implement_exchange_granular_backups BOOLEAN,
    include_clustered_exchange_servers BOOLEAN,
    exchange_mailbox_servers_num INT,
    exchange_database_stores_num INT,
    share_point_include_mssql_server_cluster BOOLEAN,
    include_granular_share_point_backups BOOLEAN,
    include_share_point_distributed_env BOOLEAN,
    share_point_mssql_servers_num INT,
    share_point_farms_num INT,
    share_point_web_apps_num INT,
    share_point_sites_num INT,
    share_point_sub_sites_num INT,
    hyperv_env_clustered BOOLEAN,
    hyperv_servers_num INT,
    clustered_oracle_servers BOOLEAN,
    oracle_rman_backup_servers_num INT,
    oracle_backup_config_databases_num INT,
    my_sql_env_clustered BOOLEAN,
    my_sql_servers_num INT,
    lotus_notes_apps_clustered BOOLEAN,
    lotus_domino_instances_num INT,
    sap_env_clustered BOOLEAN,
    sap_app_servers_num INT,
    ms_sql_include_hardware_provider BOOLEAN,
    ms_sql_proxy_nodes_num INT,
    ms_sql_server_cluster_nodes_num INT,
    exchange_include_hardware_provider BOOLEAN,
    exchange_proxy_nodes_num INT,
    exchange_database_stores_average_size INT,
    exchange_cluster_nodes_num INT,
    ccr_clusters_num INT,
    share_point_include_hardware_provider BOOLEAN,
    share_point_proxy_nodes_num INT,
    share_point_mssql_server_cluster_nodes_num INT,
    share_point_physical_servers_num INT,
    hyperv_include_hardware_provider BOOLEAN,
    hyperv_proxy_nodes_num INT,
    hyperv_nmm_configured BOOLEAN,
    hyperv_physical_servers_num INT,
    hyperv_virtual_machines_num INT,
    oracle_physical_servers_num INT,
    my_sql_physical_servers_num INT,
    lotus_notes_physical_servers_num INT,
    sap_physical_servers_num INT
);

CREATE TABLE NetworkerImplementation (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    select_datazone_size BOOLEAN,
    datazone_size_id BIGINT,
    FOREIGN KEY (datazone_size_id) REFERENCES NetworkerDatazoneSize (id)
);

CREATE TABLE NetworkerUpgrade (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    server BOOLEAN,
    storage_nodes BOOLEAN,
    clients BOOLEAN,
    management_console BOOLEAN,
    current_version INT,
    upgrade_version INT,
    upgrade_to_new_hardware BOOLEAN,
    servers_num INT,
    storage_nodes_num INT,
    clients_num INT,
    management_consoles_num INT
);

CREATE TABLE NetWorkerHealthCheck (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    include_emc_assessment BOOLEAN,
    data_zones_num INT,
    assessment_interviews_num INT
);

CREATE TABLE Networker (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    knowledge_transfer_hours DECIMAL(20,2),
    implementation_service BOOLEAN,
    upgrade_planning_service BOOLEAN,
    health_check_service BOOLEAN,
    upgrade_service BOOLEAN,
    design_activity BOOLEAN,
    implementation_activity BOOLEAN,
    design_id bigint,
    implementation_id bigint,
    upgrade_id bigint,
    healthcheck_id bigint,
    FOREIGN KEY (design_id) REFERENCES NetworkerDesign (id),
    FOREIGN KEY (implementation_id) REFERENCES NetworkerImplementation (id),
    FOREIGN KEY (upgrade_id) REFERENCES NetworkerUpgrade (id),
    FOREIGN KEY (healthcheck_id) REFERENCES NetWorkerHealthCheck (id)
);

CREATE TABLE DPADServicesScope (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    avamar BOOLEAN,
    data_domain BOOLEAN,
    dpa BOOLEAN,
    edl BOOLEAN,
    networker BOOLEAN,
    dlm BOOLEAN,
    recover_point BOOLEAN,
    mozy BOOLEAN
);

-- Mozy
CREATE TABLE MozyCustom (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    account_setup_structure_config BOOLEAN,
    solutions_assurance BOOLEAN,
    branding BOOLEAN,
    federated_id_config BOOLEAN,
    develop_beta_plan_assist_rollout BOOLEAN,
    administration_training BOOLEAN,
    api_workshop BOOLEAN,
    l1_support_training BOOLEAN,
    api_workshop_planning_hours DECIMAL(20,2),
    assist_pilot_rollout_hours DECIMAL(20,2),
    administration_training_hours DECIMAL(20,2),
    client_branding_hours DECIMAL(20,2),
    admin_console_branding_hours DECIMAL(20,2),
    web_access_branding_hours DECIMAL(20,2),
    api_workshop_hours DECIMAL(20,2),
    l1_support_training_hours DECIMAL(20,2)
);

CREATE TABLE MozyOEMBranding (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    client_branding_hours DECIMAL(20,2),
    admin_console_hours DECIMAL(20,2),
    web_access_hours DECIMAL(20,2)
);

CREATE TABLE MozyOutTasking (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    start_date TIMESTAMP,
    out_tasking_hours DECIMAL(20,2)
);

CREATE TABLE Mozy (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    custom BOOLEAN,
    oem_branding BOOLEAN,
    out_tasking BOOLEAN,
    custom_id bigint,
    oem_branding_id bigint,
    out_tasking_id bigint,
    FOREIGN KEY (custom_id) REFERENCES MozyCustom (id),
    FOREIGN KEY (oem_branding_id) REFERENCES MozyOEMBranding (id),
    FOREIGN KEY (out_tasking_id) REFERENCES MozyOutTasking (id)
);
-- End of Mozy

CREATE TABLE DPADRequestData (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    sites_involved VARCHAR(256),
    general_comments VARCHAR(256),
    services_scope_id bigint,
    avamar_id bigint,
    edl_id bigint,
    recover_point_id bigint,
    data_domain_id bigint,
    dpa_id bigint,
    networker_id bigint,
    mozy_id bigint,
    FOREIGN KEY (services_scope_id) REFERENCES DPADServicesScope (id),
    FOREIGN KEY (recover_point_id) REFERENCES RecoverPoint (id),
    FOREIGN KEY (edl_id) REFERENCES EDL (id),
    FOREIGN KEY (avamar_id) REFERENCES Avamar (id),
    FOREIGN KEY (data_domain_id) REFERENCES DataDomain (id),
    FOREIGN KEY (dpa_id) REFERENCES DPA (id),
    FOREIGN KEY (networker_id) REFERENCES Networker (id),
    FOREIGN KEY (mozy_id) REFERENCES Mozy (id)
);

CREATE TABLE CoreOptions (
    id bigint auto_increment NOT NULL PRIMARY KEY, 
    symm_os BOOLEAN,
    symm_mf BOOLEAN,
    vblock BOOLEAN,
    unified BOOLEAN,
    replication BOOLEAN,
    san BOOLEAN,
    isilon BOOLEAN,
    xtremeIO BOOLEAN,
    vplex BOOLEAN,
    cta BOOLEAN,
    mainframe BOOLEAN,
    change_request BOOLEAN
);

CREATE TABLE OtherRequestOptions (
    id bigint auto_increment NOT NULL PRIMARY KEY, 
    residency BOOLEAN,
    i_series BOOLEAN,
    disk_retention BOOLEAN,
    move_request BOOLEAN,
    health_checks BOOLEAN,
    not_listed BOOLEAN,
    assessment BOOLEAN,
    protect_point BOOLEAN
);

CREATE TABLE NetworkServiceTemplateType (
  id   BIGINT AUTO_INCREMENT NOT NULL PRIMARY KEY,
  name VARCHAR(256)          NOT NULL
);

CREATE TABLE LANInfraComplexityType (
  id   BIGINT AUTO_INCREMENT NOT NULL PRIMARY KEY,
  name VARCHAR(256)          NOT NULL
);

CREATE TABLE DCLocationsAnalysisNumber (
  id   BIGINT AUTO_INCREMENT NOT NULL PRIMARY KEY,
  name VARCHAR(256)          NOT NULL
);

CREATE TABLE AssessmentData (
  id BIGINT AUTO_INCREMENT NOT NULL PRIMARY KEY,
  service_template_type_id BIGINT,
  lan_complexity_type_id BIGINT,
  dc_locations_number_id BIGINT,
  results_viewable BOOLEAN,
  FOREIGN KEY (service_template_type_id) REFERENCES NetworkServiceTemplateType (id),
  FOREIGN KEY (lan_complexity_type_id) REFERENCES LANInfraComplexityType (id),
  FOREIGN KEY (dc_locations_number_id) REFERENCES DCLocationsAnalysisNumber (id)
);

CREATE TABLE RecoveryLevelType (
  id   BIGINT AUTO_INCREMENT NOT NULL PRIMARY KEY,
  name VARCHAR(256)          NOT NULL
);

CREATE TABLE ProtectPointData (
  id                     BIGINT AUTO_INCREMENT NOT NULL PRIMARY KEY,
  data_domain_appls_backup_num INT,
  storage_arrays_backup_num INT,
  application_hosts_num INT,
  backup_config_files_num INT,
  db_instances_backup_num INT,
  recovery_level_type_id BIGINT,
  obj_level_recovery_num INT,
  full_lun_recovery_num INT,
  FOREIGN KEY (recovery_level_type_id) REFERENCES RecoveryLevelType (id)
);

CREATE TABLE DPADOptions (
    id bigint auto_increment NOT NULL PRIMARY KEY, 
    avamar BOOLEAN,
    source_one BOOLEAN,
    data_domain BOOLEAN,
    networker BOOLEAN,
    edl BOOLEAN,
    mozy BOOLEAN,
    dlm BOOLEAN,
    dpa BOOLEAN,
    recover_point BOOLEAN
);

CREATE TABLE ASDOptions (
    id bigint auto_increment NOT NULL PRIMARY KEY, 
    srm BOOLEAN,
    app_sync BOOLEAN,
    atmos BOOLEAN,
    w4n BOOLEAN,
    centera BOOLEAN,
    vipr BOOLEAN,
    uim BOOLEAN,
    ncm BOOLEAN
);

CREATE TABLE AffinityOptions (
    id bigint auto_increment NOT NULL PRIMARY KEY, 
    vmware BOOLEAN,
    pivotal BOOLEAN,
    rsa BOOLEAN,
    vce BOOLEAN,
    ecd BOOLEAN
);

CREATE TABLE ConsultingOptions (
    id bigint auto_increment NOT NULL PRIMARY KEY, 
    blue_printing BOOLEAN,
    dcm BOOLEAN,
    staff BOOLEAN,
    p2v BOOLEAN,
    vmware BOOLEAN
);

CREATE TABLE Attachment (
  id bigint auto_increment NOT NULL PRIMARY KEY, 
  attachment_filename VARCHAR(256),
  attachment_filepath VARCHAR(256),
  attachment_size bigint,
);

CREATE TABLE RequestContractData (
    id bigint auto_increment NOT NULL PRIMARY KEY, 
    sow_type_id bigint,
    customer_format_required BOOLEAN,
    services_agreement_type_id bigint,
    services_agreement_date TIMESTAMP,
    partner_information VARCHAR(256),
    FOREIGN KEY (sow_type_id) REFERENCES SowType (id),
    FOREIGN KEY (services_agreement_type_id) REFERENCES ServicesAgreementType (id),
);

CREATE TABLE StartRequestData (
    id bigint auto_increment NOT NULL PRIMARY KEY, 
    core_options_id bigint,
    dpad_options_id bigint,
    asd_options_id bigint,
    affinity_options_id bigint,
    consulting_options_id bigint,
    other_request_options_id bigint,
    selected_division_id bigint,
    selected_geography_id bigint,
    selected_state_id bigint,
    selected_district_id bigint,
    selected_pdm_name_id bigint,
    customer_name VARCHAR(256),
    project_name VARCHAR(256),
    project_type_id bigint,
    work_city VARCHAR(256),
    dx_quote_number VARCHAR(256),
    se_csd_name VARCHAR(256),
    pdm_name VARCHAR(256),
    pm_name VARCHAR(256),
    sfdc_number VARCHAR(256),
    se_csd_phone_country_code VARCHAR(256),
    se_csd_phone_number VARCHAR(256),
    meeting_status_id bigint,
    se_manager_name VARCHAR(256),
    program_delivery_manager_name VARCHAR(256),
    risk_level_id bigint,
    sow_language_id bigint,
    phone_call_request BOOLEAN,
    reseller_sold BOOLEAN,
    requested_return_date TIMESTAMP,
    return_equipment BOOLEAN,
    remote_access BOOLEAN,
    clearance_level_id bigint,
    request_contract_data_id bigint,
    service_request_scope CLOB,
    travel_requirements VARCHAR(256),
    expense_type_id bigint,
    oracle_party_id bigint,
    FOREIGN KEY (core_options_id) REFERENCES CoreOptions (id),
    FOREIGN KEY (dpad_options_id) REFERENCES DPADOptions (id),
    FOREIGN KEY (asd_options_id) REFERENCES ASDOptions (id),
    FOREIGN KEY (affinity_options_id) REFERENCES AffinityOptions (id),
    FOREIGN KEY (consulting_options_id) REFERENCES ConsultingOptions (id),
    FOREIGN KEY (other_request_options_id) REFERENCES OtherRequestOptions (id),
    FOREIGN KEY (selected_division_id) REFERENCES Division (id),
    FOREIGN KEY (selected_geography_id) REFERENCES Geography (id),
    FOREIGN KEY (selected_state_id) REFERENCES GeoState (id),
    FOREIGN KEY (selected_district_id) REFERENCES SalesDistrict (id),
    FOREIGN KEY (selected_pdm_name_id) REFERENCES PdmName (id),
    FOREIGN KEY (project_type_id) REFERENCES ProjectType (id),
    FOREIGN KEY (meeting_status_id) REFERENCES MeetingStatus (id),
    FOREIGN KEY (risk_level_id) REFERENCES RiskLevel (id),
    FOREIGN KEY (sow_language_id) REFERENCES SowLanguage (id),
    FOREIGN KEY (clearance_level_id) REFERENCES ClearanceLevel (id),
    FOREIGN KEY (request_contract_data_id) REFERENCES RequestContractData (id),
    FOREIGN KEY (expense_type_id) REFERENCES ExpenseType (id)
);

CREATE TABLE StartRequestData_attachments (
    id bigint auto_increment NOT NULL PRIMARY KEY, 
    start_request_data_id bigint,
    attachment_id bigint,
    FOREIGN KEY (start_request_data_id) REFERENCES StartRequestData (id),
    FOREIGN KEY (attachment_id) REFERENCES Attachment (id)
);

CREATE TABLE SiteInformation (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    address VARCHAR(2048),
    trailer_access BOOLEAN,
    loading_docks BOOLEAN,
    second_floor BOOLEAN,
    lift_gate BOOLEAN,
    packing_date VARCHAR(2048),
    pickup_date VARCHAR(2048),
    delivery_date VARCHAR(2048)
);

CREATE TABLE MoveRequestData (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    general_comments VARCHAR(2048),
    description VARCHAR(2048),
    after_hours_mss BOOLEAN,
    project_timeline VARCHAR(2048),
    target_date VARCHAR(2048),
    emc_racks_cnt INT,
    non_emc_racks_cnt INT,
    no_rack VARCHAR(2048),
    equip_no_maint_contract BOOLEAN,
    emc_mv_svcs BOOLEAN,
    after_hours_pickup BOOLEAN,
    single_event BOOLEAN,
    cfg_reset BOOLEAN,
    emc_packing_needed BOOLEAN,
    total_value VARCHAR(2048),
    comments VARCHAR(2048),
    shipping_timeline VARCHAR(2048),
    equipment VARCHAR(2048),
    recertification_required BOOLEAN,
    scope_move_services BOOLEAN NOT NULL DEFAULT FALSE,
    scope_power_up_down BOOLEAN NOT NULL DEFAULT FALSE,
    scope_reinstall BOOLEAN NOT NULL DEFAULT FALSE,
    scope_configuration BOOLEAN NOT NULL DEFAULT FALSE,
    pu_equipment VARCHAR(2048),
    install_equipment VARCHAR(2048),
    ip_change_required BOOLEAN,
    cust_requirements VARCHAR(2048)
);

CREATE TABLE MoveRequestData_siteInformation (
    move_request_data_id bigint NOT NULL,
    site_information_id bigint NOT NULL,
    FOREIGN KEY (move_request_data_id) REFERENCES MoveRequestData (id),
    FOREIGN KEY (site_information_id) REFERENCES SiteInformation (id)
);

CREATE TABLE ChangeRequestData (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    general_comments VARCHAR(2048),    
    no_of_months INT
);

CREATE TABLE ChangeRequestData_HoursByMonth (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    rows_id bigint,
    ChangeRequestData_id bigint,
    FOREIGN KEY (ChangeRequestData_id) REFERENCES ChangeRequestData (id)
);

CREATE TABLE HoursByMonth (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    sap_wbs_element_no VARCHAR(2048)
);

CREATE TABLE HoursByMonth_RoleHoursByMonth (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    rows_id bigint,
    HoursByMonth_id bigint,
    FOREIGN KEY (HoursByMonth_id) REFERENCES HoursByMonth (id)
);

CREATE TABLE RoleHoursByMonth (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    role VARCHAR(2048)
);

CREATE TABLE RoleHoursByMonth_Hours (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    month_num INT,
    hours VARCHAR(10),
    RoleHoursByMonth_id bigint,
    FOREIGN KEY (RoleHoursByMonth_id) REFERENCES RoleHoursByMonth (id)
);


CREATE TABLE Collector (
    id bigint auto_increment NOT NULL PRIMARY KEY, 
    name VARCHAR(256) NOT NULL
);
CREATE TABLE DCSolutionPack (
    id bigint auto_increment NOT NULL PRIMARY KEY, 
    name VARCHAR(256) NOT NULL
);
CREATE TABLE EMCSolutionPack (
    id bigint auto_increment NOT NULL PRIMARY KEY, 
    name VARCHAR(256) NOT NULL
);
CREATE TABLE MobileSolutionPack (
    id bigint auto_increment NOT NULL PRIMARY KEY, 
    name VARCHAR(256) NOT NULL
);
CREATE TABLE NetworkReportPack (
    id bigint auto_increment NOT NULL PRIMARY KEY, 
    name VARCHAR(256) NOT NULL
);
CREATE TABLE ServerReportPack (
    id bigint auto_increment NOT NULL PRIMARY KEY, 
    name VARCHAR(256) NOT NULL
);
CREATE TABLE SmartsDomainType (
    id bigint auto_increment NOT NULL PRIMARY KEY, 
    name VARCHAR(256) NOT NULL
);
CREATE TABLE StorageReportPack (
    id bigint auto_increment NOT NULL PRIMARY KEY, 
    name VARCHAR(256) NOT NULL
);
CREATE TABLE VOIPSolutionPack (
    id bigint auto_increment NOT NULL PRIMARY KEY, 
    name VARCHAR(256) NOT NULL
);
CREATE TABLE VPNReportPack (
    id bigint auto_increment NOT NULL PRIMARY KEY, 
    name VARCHAR(256) NOT NULL
);
CREATE TABLE WANAccelerator (
    id bigint auto_increment NOT NULL PRIMARY KEY, 
    name VARCHAR(256) NOT NULL
);
CREATE TABLE WiFiReportPack (
    id bigint auto_increment NOT NULL PRIMARY KEY, 
    name VARCHAR(256) NOT NULL
);

CREATE TABLE SRMRequestData (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    new_install BOOLEAN,
    migration BOOLEAN,
    v_app BOOLEAN,
    emc_control_center BOOLEAN,
    onsite_or_remote BOOLEAN,
    keyboard_access BOOLEAN,
    general_comments VARCHAR(2048),
    aix_vio INT,
    brocade INT,
    cisco_mds INT,
    cisco_ucs INT,
    converged_infra INT,
    data_centers INT,
    data_domain INT,
    emc_atmos INT,
    emc_avamar INT,
    emc_centera INT,
    emc_data_prot_adv INT,
    emc_isilon_nas INT,
    emc_recover_pt INT,
    emc_vipr INT,
    emc_vmax_symm INT,
    emc_vnx_block INT,
    emc_vnx_file_nas INT,
    emc_vplex INT,
    vmware_esx_servers INT,
    xtrem_io INT,
    hitachi_dev_mgr INT,
    hp_par_store INT,
    hp_eva INT,
    hp_storage_works INT,
    hyperv INT,
    ibm_ds_series INT,
    ibm_san_vol_contrlr INT,
    ibm_svc INT,
    ibm_xiv INT,
    net_app_filer_nas INT,
    oracle INT,
    physical_hosts INT,
    san_ports INT,
    vi_san_perf_probes INT
);

CREATE TABLE W4NData (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    general_comments VARCHAR(2048),
    w4n_install BOOLEAN NOT NULL DEFAULT false,
    w4n_upgrade BOOLEAN NOT NULL DEFAULT false,
    existing_smarts_cust BOOLEAN NOT NULL DEFAULT false,
    add_lab_install BOOLEAN NOT NULL DEFAULT false,
    itpr_migration BOOLEAN NOT NULL DEFAULT false,
    w4n_failover BOOLEAN,
    total_managed_devices INT,
    total_managed_pi INT,
    other_not_listed VARCHAR(1024),
    number_luns INT,
    number_disks INT,
    number_arrays INT,
    storage_soln_pack BOOLEAN,
    traffic_flows BOOLEAN,
    transactions BOOLEAN,
    enabled_flows_count INT
);

CREATE TABLE W4NData_SmartsDomainType (
    id bigint auto_increment NOT NULL PRIMARY KEY, 
    w4n_data_id bigint,
    smarts_domain_type_id bigint,
    FOREIGN KEY (w4n_data_id) REFERENCES W4NData (id),
    FOREIGN KEY (smarts_domain_type_id) REFERENCES SmartsDomainType (id)
);

CREATE TABLE W4NData_EMCSolutionPack (
    id bigint auto_increment NOT NULL PRIMARY KEY, 
    w4n_data_id bigint,
    EMCSolutionPack_id bigint,
    FOREIGN KEY (w4n_data_id) REFERENCES W4NData (id),
    FOREIGN KEY (EMCSolutionPack_id) REFERENCES EMCSolutionPack (id)
);

CREATE TABLE W4NData_WiFiReportPack (
    id bigint auto_increment NOT NULL PRIMARY KEY, 
    w4n_data_id bigint,
    WiFiReportPack_id bigint,
    FOREIGN KEY (w4n_data_id) REFERENCES W4NData (id),
    FOREIGN KEY (WiFiReportPack_id) REFERENCES WiFiReportPack (id)
);

CREATE TABLE W4NData_DCSolutionPack (
    id bigint auto_increment NOT NULL PRIMARY KEY, 
    w4n_data_id bigint,
    DCSolutionPack_id bigint,
    FOREIGN KEY (w4n_data_id) REFERENCES W4NData (id),
    FOREIGN KEY (DCSolutionPack_id) REFERENCES DCSolutionPack (id)
);

CREATE TABLE W4NData_VOIPSolutionPack (
    id bigint auto_increment NOT NULL PRIMARY KEY, 
    w4n_data_id bigint,
    VOIPSolutionPack_id bigint,
    FOREIGN KEY (w4n_data_id) REFERENCES W4NData (id),
    FOREIGN KEY (VOIPSolutionPack_id) REFERENCES VOIPSolutionPack (id)
);

CREATE TABLE W4NData_MobileSolutionPack (
    id bigint auto_increment NOT NULL PRIMARY KEY, 
    w4n_data_id bigint,
    MobileSolutionPack_id bigint,
    FOREIGN KEY (w4n_data_id) REFERENCES W4NData (id),
    FOREIGN KEY (MobileSolutionPack_id) REFERENCES MobileSolutionPack (id)
);

CREATE TABLE W4NData_Collector (
    id bigint auto_increment NOT NULL PRIMARY KEY, 
    w4n_data_id bigint,
    Collector_id bigint,
    FOREIGN KEY (w4n_data_id) REFERENCES W4NData (id),
    FOREIGN KEY (Collector_id) REFERENCES Collector (id)
);

CREATE TABLE W4NData_NetworkReportPack (
    id bigint auto_increment NOT NULL PRIMARY KEY, 
    w4n_data_id bigint,
    NetworkReportPack_id bigint,
    FOREIGN KEY (w4n_data_id) REFERENCES W4NData (id),
    FOREIGN KEY (NetworkReportPack_id) REFERENCES NetworkReportPack (id)
);

CREATE TABLE W4NData_VPNReportPack (
    id bigint auto_increment NOT NULL PRIMARY KEY, 
    w4n_data_id bigint,
    VPNReportPack_id bigint,
    FOREIGN KEY (w4n_data_id) REFERENCES W4NData (id),
    FOREIGN KEY (VPNReportPack_id) REFERENCES VPNReportPack (id)
);

CREATE TABLE W4NData_WANAccelerator (
    id bigint auto_increment NOT NULL PRIMARY KEY, 
    w4n_data_id bigint,
    WANAccelerator_id bigint,
    FOREIGN KEY (w4n_data_id) REFERENCES W4NData (id),
    FOREIGN KEY (WANAccelerator_id) REFERENCES WANAccelerator (id)
);

CREATE TABLE W4NData_ServerReportPack (
    id bigint auto_increment NOT NULL PRIMARY KEY, 
    w4n_data_id bigint,
    ServerReportPack_id bigint,
    FOREIGN KEY (w4n_data_id) REFERENCES W4NData (id),
    FOREIGN KEY (ServerReportPack_id) REFERENCES ServerReportPack (id)
);

CREATE TABLE W4NData_StorageReportPack (
    id bigint auto_increment NOT NULL PRIMARY KEY, 
    w4n_data_id bigint,
    StorageReportPack_id bigint,
    FOREIGN KEY (w4n_data_id) REFERENCES W4NData (id),
    FOREIGN KEY (StorageReportPack_id) REFERENCES StorageReportPack (id)
);

CREATE TABLE UnfundedProjectData (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    general_comments VARCHAR(2048),
    summary VARCHAR(1024),
    roi VARCHAR(1024),
    environment_type VARCHAR(1024),
    est_book_value DECIMAL,
    purchase_decision_dt TIMESTAMP,
    special_req VARCHAR(1024),
    start_dt TIMESTAMP,
    end_dt TIMESTAMP
);

-- Xtreme
CREATE TABLE XtremeDataMobilityType (
    id bigint auto_increment NOT NULL PRIMARY KEY, 
    name VARCHAR(256) NOT NULL
);


CREATE TABLE XtremeServices (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    design_and_impl BOOLEAN,
    cluster_expansion BOOLEAN,
    cache BOOLEAN,
    sf BOOLEAN,
    oracle_local_replication BOOLEAN
);

CREATE TABLE XtremeDataMigration (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    planning_and_design BOOLEAN,
    impl_and_migration BOOLEAN,
    xtreme_host_based_migration_tool_id BIGINT,
    hosts_migrated_by_open_migrator_num INT,
    hosts_migrated_by_ppme_num INT,
    include_esx_host_migration_vmotion BOOLEAN,
    rcli_installs_num INT,
    vmware_vm_vmotion_storage_num INT,
    storage_vmotion_additional_hours DECIMAL(20,2),
    implement_vplex_data_mobility BOOLEAN,
    xtreme_data_mobility_type_id BIGINT,
    use_encapsulation_under_vplex BOOLEAN,
    storage_volumens_imported_vplex_num INT,
    vplex_virtual_volumes_num INT,
    vplex_mirrors_num INT,
    vplex_data_mobility_jobs_num INT,
    implement_xtreme_io_snapshots BOOLEAN,
    swing_frame_box_required BOOLEAN,
    swing_box_hosts_migrated_by_emc_num INT,
    swing_box_hosts_migrated_by_open_migrator_num INT,
    swing_box_hosts_migrated_by_ppme_num INT,
    include_vmware_35_infrastructure BOOLEAN,
    total_source_target_sites_num INT,
    new_physical_hosts_in_design_num INT,
    new_esx_servers_in_design_num INT,
    new_enterprise_directors_num INT,
    new_departmental_switches_num INT,
    new_vnx_block_storage_arrays_num INT,
    new_symmetrix_storage_arrays_num INT,
    vnx_blocks_to_upgrade_num INT,
    symmetrix_to_upgrade_num INT,
    total_source_arrays_num INT,
    total_target_arrays_num INT,
    device_size_changes_required BOOLEAN,
    source_data_amount_to_migrate_to_tb INT,
    hosts_to_migrate_by_emc_num INT,
    total_hosts_to_migrate_by_emc_num INT,
    customer_zonning_work_on_switches BOOLEAN,
    hosts_booted_from_san_num INT,
    customer_lun_device_allocation BOOLEAN,    
    FOREIGN KEY (xtreme_host_based_migration_tool_id) REFERENCES XtremeHostBasedMigrationTool (id),
    FOREIGN KEY (xtreme_data_mobility_type_id) REFERENCES XtremeDataMobilityType (id)
);

CREATE TABLE XtremeDesignImpl (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    emc_customer_rack BOOLEAN,
    cluster_config_2_4_bricks BOOLEAN,
    additional_testing BOOLEAN,
    additional_monitoring BOOLEAN,
    scripting_work BOOLEAN,
    include_emc_equipment_removal BOOLEAN,
    include_xtreme_io_migration BOOLEAN,
    xtreme_io_clusters_num BIGINT,
    xtreme_io_bricks_per_cluster_num BIGINT,
    xtreme_io_hosts_num BIGINT,
    xtreme_snapshots_per_host_num BIGINT,
    xtreme_io_cluster_bricks_added_num BIGINT,
    deployed_infiniband_switches_num BIGINT,
    xtreme_data_migration_id BIGINT,
    FOREIGN KEY (xtreme_data_migration_id) REFERENCES XtremeDataMigration (id)
);

CREATE TABLE XtremeCache (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    is_assessment BOOLEAN,
    flash_cards_num BIGINT,
    include_cache_install_and_config BOOLEAN,
    cache_install_hosts_num BIGINT
);

CREATE TABLE XtremeSF (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    flash_cards_num BIGINT,
    cards_install_hosts_num BIGINT,
    cache_install_hosts_num BIGINT
);

CREATE TABLE XtremeOracleLocalReplication (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    perform_planning_design_snapshots BOOLEAN,
    functional_overview_hours DECIMAL(20,2)
);

CREATE TABLE XtremeRequestData (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    knowledge_transfer_hours DECIMAL(20,2),
    general_comments VARCHAR(2048),
    xtreme_design_impl_id BIGINT,
    xtreme_services_id BIGINT,
    xtreme_cache_id BIGINT,
    xtreme_sf_id BIGINT,
    xtreme_oracle_local_replication_id BIGINT,
    FOREIGN KEY (xtreme_design_impl_id) REFERENCES XtremeDesignImpl (id),
    FOREIGN KEY (xtreme_services_id) REFERENCES XtremeServices (id),
    FOREIGN KEY (xtreme_cache_id) REFERENCES XtremeCache (id),
    FOREIGN KEY (xtreme_sf_id) REFERENCES XtremeSF (id),
    FOREIGN KEY (xtreme_oracle_local_replication_id) REFERENCES XtremeOracleLocalReplication (id)
);
-- End of Xtreme

CREATE TABLE MultipleTheatersLanguagesInvolvementOption (
    id bigint auto_increment NOT NULL PRIMARY KEY, 
    name VARCHAR(256),
    risk INT
);

CREATE TABLE MultipleWorkgroupsDisciplinesOption (
    id bigint auto_increment NOT NULL PRIMARY KEY, 
    name VARCHAR(256),
    risk INT
);

CREATE TABLE EMCClientOption (
    id bigint auto_increment NOT NULL PRIMARY KEY, 
    name VARCHAR(256),
    risk INT
);

CREATE TABLE EMCClientRelationshipOption (
    id bigint auto_increment NOT NULL PRIMARY KEY, 
    name VARCHAR(256),
    risk INT
);

CREATE TABLE ProcessStaffMaturityOption (
    id bigint auto_increment NOT NULL PRIMARY KEY, 
    name VARCHAR(256),
    risk INT
);

CREATE TABLE ClientEnvironmentDocumentationOption (
  id BIGINT AUTO_INCREMENT NOT NULL PRIMARY KEY,
  name VARCHAR(256),
  risk INT
);

CREATE TABLE ProjectScopeUnderstandingOption (
  id BIGINT AUTO_INCREMENT NOT NULL PRIMARY KEY,
  name VARCHAR(256),
  risk INT
);

CREATE TABLE ProjectImpactOption (
  id BIGINT AUTO_INCREMENT NOT NULL PRIMARY KEY,
  name VARCHAR(256),
  risk INT
);

CREATE TABLE ProjectSponsorInvolvementOption (
  id BIGINT AUTO_INCREMENT NOT NULL PRIMARY KEY,
  name VARCHAR(256),
  risk INT
);

CREATE TABLE OfferingMaturityOption (
  id BIGINT AUTO_INCREMENT NOT NULL PRIMARY KEY,
  name VARCHAR(256),
  risk INT
);

CREATE TABLE ProjectComplexityLevelOption (
  id BIGINT AUTO_INCREMENT NOT NULL PRIMARY KEY,
  name VARCHAR(256),
  risk INT
);

CREATE TABLE ExternalFactorsOption (
  id BIGINT AUTO_INCREMENT NOT NULL PRIMARY KEY,
  name VARCHAR(256),
  risk INT
);

CREATE TABLE EMCStaffAvailabilityOption (
  id BIGINT AUTO_INCREMENT NOT NULL PRIMARY KEY,
  name VARCHAR(256),
  risk INT
);

CREATE TABLE PartnerStaffAvailabilityOption (
  id BIGINT AUTO_INCREMENT NOT NULL PRIMARY KEY,
  name VARCHAR(256),
  risk INT
);

CREATE TABLE RiskLevelOption (
  id BIGINT AUTO_INCREMENT NOT NULL PRIMARY KEY,
  name VARCHAR(256),
  risk INT
);

CREATE TABLE EMCFederatedCompaniesInvolvementOption (
  id BIGINT AUTO_INCREMENT NOT NULL PRIMARY KEY,
  name VARCHAR(256),
  risk INT
);

CREATE TABLE ThirdPartyInvolvementOption (
  id BIGINT AUTO_INCREMENT NOT NULL PRIMARY KEY,
  name VARCHAR(256),
  risk INT
);

CREATE TABLE TMBillingUsageOption (
  id BIGINT AUTO_INCREMENT NOT NULL PRIMARY KEY,
  name VARCHAR(256),
  risk INT
);

CREATE TABLE EMCAccountabilityOption (
  id BIGINT AUTO_INCREMENT NOT NULL PRIMARY KEY,
  name VARCHAR(256),
  risk INT
);

CREATE TABLE ProgramManagementUseCaseOption (
  id BIGINT AUTO_INCREMENT NOT NULL PRIMARY KEY,
  name VARCHAR(256)
);

CREATE TABLE RiskCalculationData (
    id BIGINT auto_increment NOT NULL PRIMARY KEY,
    theater_id BIGINT,
    division_id BIGINT,
    multi_theatre_lang_inv_opt_id BIGINT,
    multi_workgroups_disciplines_inv_opt_id BIGINT,
    emc_client_type_id BIGINT,
    emc_client_rel_type_id BIGINT,
    proc_staff_maturity_type_id BIGINT,
    client_env_doc_type_id BIGINT,
    project_scope_understand_type_id BIGINT,
    project_impact_type_id BIGINT,
    project_sponsor_inv_type_id BIGINT,
    list_price INT,
    potential_value INT,
    offering_maturity_type_id BIGINT,
    project_complexity_type_id BIGINT,
    external_factors_type_id BIGINT,
    emc_staff_avail_type_id BIGINT,
    partner_staff_avail_type_id BIGINT,
    risk_level_type_id BIGINT,
    risk VARCHAR(256),
    rationale VARCHAR(256),
    adjustment INT,
    emc_fed_comps_inv_type_id BIGINT,
    third_party_inv_type_id BIGINT,
    tm_billing_usage_type_id BIGINT,
    emc_acc_type_id BIGINT,
    pg_mgmt_use_case_type_id BIGINT,
    FOREIGN KEY (theater_id) REFERENCES Geography (id),
    FOREIGN KEY (division_id) REFERENCES Division (id),
    FOREIGN KEY (multi_theatre_lang_inv_opt_id) REFERENCES MultipleTheatersLanguagesInvolvementOption (id),
    FOREIGN KEY (multi_workgroups_disciplines_inv_opt_id) REFERENCES MultipleWorkgroupsDisciplinesOption (id),
    FOREIGN KEY (emc_client_type_id) REFERENCES EMCClientOption (id),
    FOREIGN KEY (emc_client_rel_type_id) REFERENCES EMCClientRelationshipOption (id),
    FOREIGN KEY (proc_staff_maturity_type_id) REFERENCES ProcessStaffMaturityOption (id),
    FOREIGN KEY (client_env_doc_type_id) REFERENCES ClientEnvironmentDocumentationOption (id),
    FOREIGN KEY (project_scope_understand_type_id) REFERENCES ProjectScopeUnderstandingOption (id),
    FOREIGN KEY (project_impact_type_id) REFERENCES ProjectImpactOption (id),
    FOREIGN KEY (project_sponsor_inv_type_id) REFERENCES ProjectSponsorInvolvementOption (id),
    FOREIGN KEY (offering_maturity_type_id) REFERENCES OfferingMaturityOption (id),
    FOREIGN KEY (project_complexity_type_id) REFERENCES ProjectComplexityLevelOption (id),
    FOREIGN KEY (external_factors_type_id) REFERENCES ExternalFactorsOption (id),
    FOREIGN KEY (emc_staff_avail_type_id) REFERENCES EMCStaffAvailabilityOption (id),
    FOREIGN KEY (partner_staff_avail_type_id) REFERENCES PartnerStaffAvailabilityOption (id),
    FOREIGN KEY (risk_level_type_id) REFERENCES RiskLevelOption (id),
    FOREIGN KEY (emc_fed_comps_inv_type_id) REFERENCES EMCFederatedCompaniesInvolvementOption (id),
    FOREIGN KEY (third_party_inv_type_id) REFERENCES ThirdPartyInvolvementOption (id),
    FOREIGN KEY (tm_billing_usage_type_id) REFERENCES TMBillingUsageOption (id),
    FOREIGN KEY (emc_acc_type_id) REFERENCES EMCAccountabilityOption (id),
    FOREIGN KEY (pg_mgmt_use_case_type_id) REFERENCES ProgramManagementUseCaseOption (id)
);

CREATE TABLE Users (
    id bigint auto_increment NOT NULL PRIMARY KEY,
    user_identifier VARCHAR(128) NOT NULL,
    first_name VARCHAR(128),
    last_name VARCHAR(128),
    email VARCHAR(128),
    title VARCHAR(128),
    country VARCHAR(128),
    correlated_id bigint,
    constraint unique_user_identifier UNIQUE (user_identifier)
);

CREATE TABLE Request (
    id bigint auto_increment NOT NULL PRIMARY KEY, 
    customer_id bigint,
    request_status VARCHAR(256),
    request_type_id bigint,
    project_name VARCHAR(256),
    project_type_id bigint,
    project_regulatory_type_id bigint,
    start_request_data_id bigint,
    engagement_type_data_id bigint,
    mainframe_request_data_id bigint,
    infrastucture_request_data_id bigint,
    bc_request_data_id bigint,
    unified_request_data_id bigint,
    mss_request_data_id bigint,
    cta_request_data_id bigint,
    residency_request_data_id bigint,
    sourceone_request_data_id bigint,
    asd_request_data_id bigint,
    healthcheck_request_data_id bigint,
    isilon_request_data_id bigint,
    vipr_request_data_id bigint,
    atmos_request_data_id bigint,
    vblock_request_data_id bigint,
    dpad_request_data_id bigint,
    vmware_request_data_id bigint,
    change_request_data_id bigint,
    move_request_data_id bigint,
    srm_request_data_id bigint,
    w4n_data_id bigint,
    unfunded_proj_data_id bigint,
    xtreme_request_data_id bigint,
    deal_governance_data_id bigint,
    estimates_data_id bigint,
    user_identifier VARCHAR(128),
    correlated_id bigint,
    project_start_date DATE,
    project_end_date DATE,
    risk_calculation_data_id BIGINT,
    project_description VARCHAR(150),
    san_tan_information_id BIGINT,
    approver_id bigint,
    assessment_id bigint,
    protectpoint_id bigint,
    FOREIGN KEY (customer_id) REFERENCES Customer (id),
    FOREIGN KEY (request_type_id) REFERENCES RequestType (id),
    FOREIGN KEY (project_type_id) REFERENCES ProjectType (id),
    FOREIGN KEY (project_regulatory_type_id) REFERENCES ProjectRegulatoryType (id),
    FOREIGN KEY (start_request_data_id) REFERENCES StartRequestData (id),
    FOREIGN KEY (mainframe_request_data_id) REFERENCES MainframeRequestData (id),
    FOREIGN KEY (infrastucture_request_data_id) REFERENCES InfrastructureRequestData (id),
    FOREIGN KEY (bc_request_data_id) REFERENCES BcRequestData (id),
    FOREIGN KEY (unified_request_data_id) REFERENCES UnifiedRequestData (id),
    FOREIGN KEY (change_request_data_id) REFERENCES ChangeRequestData (id),
    FOREIGN KEY (move_request_data_id) REFERENCES MoveRequestData (id),
    FOREIGN KEY (srm_request_data_id) REFERENCES SRMRequestData (id),
    FOREIGN KEY (w4n_data_id) REFERENCES W4NData (id),
    FOREIGN KEY (unfunded_proj_data_id) REFERENCES UnfundedProjectData (id),
    FOREIGN KEY (mss_request_data_id) REFERENCES MSSRequestData (id),
    FOREIGN KEY (cta_request_data_id) REFERENCES CTARequestData (id),
    FOREIGN KEY (residency_request_data_id) REFERENCES ResidencyRequestData (id),
    FOREIGN KEY (sourceone_request_data_id) REFERENCES SourceOneRequestData (id),
    FOREIGN KEY (asd_request_data_id) REFERENCES ASDRequestData (id),
    FOREIGN KEY (healthcheck_request_data_id) REFERENCES HealthCheckRequestData (id),
    FOREIGN KEY (isilon_request_data_id) REFERENCES IsilonRequestData (id),
    FOREIGN KEY (vipr_request_data_id) REFERENCES ViprRequestData (id),
    FOREIGN KEY (atmos_request_data_id) REFERENCES AtmosCenteraRequestData (id),
    FOREIGN KEY (vblock_request_data_id) REFERENCES VblockRequestData (id),
    FOREIGN KEY (dpad_request_data_id) REFERENCES DPADRequestData (id),
    FOREIGN KEY (vmware_request_data_id) REFERENCES VMwareRequestData (id),
    FOREIGN KEY (xtreme_request_data_id) REFERENCES XtremeRequestData (id),
    FOREIGN KEY (engagement_type_data_id) REFERENCES EngagementTypeData (id),
    FOREIGN KEY (deal_governance_data_id) REFERENCES DealGovernanceData (id),
    FOREIGN KEY (estimates_data_id) REFERENCES EstimatesData (id),
    FOREIGN KEY (risk_calculation_data_id) REFERENCES RiskCalculationData (id),
    FOREIGN KEY (san_tan_information_id) REFERENCES SanTanInformation (id),
    FOREIGN KEY (approver_id) REFERENCES Profile (id),
    FOREIGN KEY (assessment_id) REFERENCES AssessmentData (id),
    FOREIGN KEY (protectpoint_id) REFERENCES ProtectPointData (id)
);

CREATE TABLE AppIdentifier (
    identifier VARCHAR(64) NOT NULL PRIMARY KEY
);

CREATE SEQUENCE SOperationLog START WITH 1000 INCREMENT BY 1;

CREATE TABLE OperationLog (
    log_id VARCHAR(256) NOT NULL PRIMARY KEY,
    entity_id bigint NOT NULL,
    entity_type VARCHAR(128) NOT NULL,
    operation INT NOT NULL,
    timestamp bigint NOT NULL,
    user_identifier VARCHAR(128) NOT NULL,
    correlated_id bigint,
    seq bigint NOT NULL,
    constraint unique_operation_log UNIQUE (entity_id, entity_type, user_identifier)
);

CREATE TABLE SynchronizedOperationLog (
    log_id VARCHAR(256) NOT NULL PRIMARY KEY,
    entity_id bigint NOT NULL,
    entity_type VARCHAR(128) NOT NULL,
    operation INT NOT NULL,
    timestamp bigint NOT NULL,
    user_identifier VARCHAR(128) NOT NULL,
    correlated_id bigint,
    seq bigint NOT NULL
);

CREATE TABLE Request_AdditionalRecipients (
    id bigint auto_increment NOT NULL PRIMARY KEY, 
    request_id bigint,
    recipient_id bigint,
    FOREIGN KEY (request_id) REFERENCES Request (id),
    FOREIGN KEY (recipient_id) REFERENCES Profile (id)
);

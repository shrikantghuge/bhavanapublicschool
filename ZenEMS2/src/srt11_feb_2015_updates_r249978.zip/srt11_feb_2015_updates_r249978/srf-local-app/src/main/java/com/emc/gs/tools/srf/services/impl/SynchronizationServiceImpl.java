/*
 * This code is copyright (c) 2014-2015 EMC Corporation.
 */
package com.emc.gs.tools.srf.services.impl;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URI;
import java.net.URISyntaxException;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.persistence.PersistenceException;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.http.Header;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpDelete;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.client.methods.HttpRequestBase;
import org.apache.http.client.utils.URIBuilder;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.StringEntity;
import org.apache.http.entity.mime.MultipartEntityBuilder;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.message.BasicNameValuePair;
import org.apache.log4j.Logger;
import org.h2.util.IOUtils;
import org.springframework.transaction.annotation.Transactional;

import com.emc.gs.tools.srf.ServiceRequestToolConfigurationException;
import com.emc.gs.tools.srf.model.Attachment;
import com.emc.gs.tools.srf.model.AttachmentList;
import com.emc.gs.tools.srf.model.CorrelatedIdentifiableEntity;
import com.emc.gs.tools.srf.model.Customer;
import com.emc.gs.tools.srf.model.EntityOperationLog;
import com.emc.gs.tools.srf.model.Operation;
import com.emc.gs.tools.srf.model.OperationLog;
import com.emc.gs.tools.srf.model.Profile;
import com.emc.gs.tools.srf.model.Request;
import com.emc.gs.tools.srf.model.ServiceContext;
import com.emc.gs.tools.srf.model.SynchronizedOperationLog;
import com.emc.gs.tools.srf.model.User;
import com.emc.gs.tools.srf.services.AlreadySynchronizedException;
import com.emc.gs.tools.srf.services.CloudConnectionException;
import com.emc.gs.tools.srf.services.CloudServerException;
import com.emc.gs.tools.srf.services.CustomerService;
import com.emc.gs.tools.srf.services.EntityNotFoundException;
import com.emc.gs.tools.srf.services.OperationLogService;
import com.emc.gs.tools.srf.services.ProfileService;
import com.emc.gs.tools.srf.services.RequestService;
import com.emc.gs.tools.srf.services.ServiceRequestToolException;
import com.emc.gs.tools.srf.services.SynchronizationService;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JavaType;


/**
 * <p>
 * This is synchronization service implementation.
 * </p>
 *
 * <p>
 * <strong>Thread safety</strong>: This class is effectively thread safe after configuration, the configuration is done
 * in a thread safe manner.
 * </p>
 *
 * <p>
 * <strong>Changes V1.1:</strong>
 * <strong>SRT Phase 4 - ET Assembly 3</strong>
 * <ul>
 * <li>Implemented syncUpRequest, syncUpAllRequests, syncDownRequest, syncDownRequests.</li>
 * <li>Added the logics to upload attachments, download attachments and check attachments.</li>
 * <li>Removed objectMapper field, use Helper.OBJECT_MAPPER instead.</li>
 * <li>Removed customerOperationLogArrayType, profileOperationLogArrayType fields,
 * use TypeReference instead which is more straight forward.</li>
 * <li>Refactored addHttpHeaders into two methods: addAuthHttpHeaders and addApplicationJsonHttpHeaders.</li>
 * <li>Moved copyEntity to Helper.deepCloneEntity</li>
 * <li>Refactored deleteCustomerFromCloud to deleteEntityFromCloud</li>
 * </ul>
 * </p>
 *
 * <p>
 * Version 1.2 Change notes:
 *   <ol>
 *     <li>Removed <code>testSubmitEmailAddress</code> property from profile.</li>
 *     <li>Removed <code>emailOptions</code> property from profile.</li>
 *   </ol>
 * </p>
 *
 * <p>
 * Version 1.3 Change notes:
 *   <ol>
 *     <li>Supporting new Job Title and Country properties for User entity.</li>
 *   </ol>
 * </p>
 *
 * <p>
 * Version 1.4 Change notes:
 *   <ol>
 *     <li>Updated syncDownProfile method name to syncDownDefaultProfile.</li>
 *     <li>Updated operationLogService.get method calls, added new parameters.</li>
 *     <li>Added syncUpAllProfiles method.</li>
 *     <li>Added syncDownAllProfiles method.</li>
 *     <li>Added doSyncDownProfiles method.</li>
 *   </ol>
 * </p>
 *
 * <p>
 * Version 1.5 Change notes:
 *   <ol>
 *     <li>Removed <code>submitter</code> property from <code>Profile</code> and <code>User</code> entities.</li>
 *   </ol>
 * </p>
 *
 * @author zsudraco, MonicaMuranyi
 * @version 1.5
 * @since SRT Phase 4 - ET Assembly 2
 */
public class SynchronizationServiceImpl extends BasePersistenceService implements SynchronizationService {

    /**
     * <p>
     * Represents the class name.
     * </p>
     */
    private static final String CLASSNAME = SynchronizationServiceImpl.class.getName();

    /**
     * The type reference for List of Boolean.
     */
    private static final TypeReference<List<Boolean>> TYPE_REFERENCE_LIST_BOOLEAN =
            new TypeReference<List<Boolean>>() {
            };

    /**
     * The type reference for Array of EntityOperationLog of Profile.
     */
    private static final TypeReference<EntityOperationLog<Profile>[]> TYPE_REFERENCE_ENTITY_OPERATION_LOGS_PROFILE =
            new TypeReference<EntityOperationLog<Profile>[]>() {
            };

    /**
     * The type reference for Array of EntityOperationLog of Customer.
     */
    private static final TypeReference<EntityOperationLog<Customer>[]> TYPE_REFERENCE_ENTITY_OPERATION_LOGS_CUSTOMER =
            new TypeReference<EntityOperationLog<Customer>[]>() {
            };

    /**
     * The type reference for Array of EntityOperationLog of Request.
     */
    private static final TypeReference<EntityOperationLog<Request>[]> TYPE_REFERENCE_ENTITY_OPERATION_LOGS_REQUEST =
            new TypeReference<EntityOperationLog<Request>[]>() {
            };

    /**
     * This is the request service.
     * Required.
     */
    private RequestService requestService;

    /**
     * This is the customer service.
     * Required.
     */
    private CustomerService customerService;

    /**
     * This is the profile service.
     * Required.
     */
    private ProfileService profileService;

    /**
     * This is the operation log service.
     * Required.
     */
    private OperationLogService operationLogService;

    /**
     * This is attachment folder.
     * Not null, not empty.
     * It should be same as the RequestController.attachmentUploadFolder value.
     */
    private String attachmentFolder;

    /**
     * This is cloud service URL base.
     * Not null, not empty.
     */
    private String cloudServiceUrlBase;

    /**
     * This is HTTP header name of user identifier.
     * Not null, not empty.
     */
    private String userIdentifierHeaderName;

    /**
     * This is HTTP header name of first name.
     * Not null, not empty.
     */
    private String firstNameHeaderName;

    /**
     * This is HTTP header name of last name.
     * Not null, not empty.
     */
    private String lastNameHeaderName;

    /**
     * This is HTTP header name of email.
     * Not null, not empty.
     */
    private String emailHeaderName;

    /**
     * <p>A <code>String</code> providing the value for jobTitleHeaderName property.</p>
     *
     * @since 1.3
     */
    private String jobTitleHeaderName;

    /**
     * <p>A <code>String</code> providing the value for countryHeaderName property.</p>
     *
     * @since 1.3
     */
    private String countryHeaderName;

    /**
     * This is HTTP header name of synchronizing operation log.
     * Not null, not empty.
     */
    private String syncOpLogHeaderName;

    /**
     * The HTTP client. It is initialized in constructor and will not change.
     */
    private final HttpClient httpClient;

    /**
     * The JAXBContext instance used to deserialize Attachmentlist.
     */
    private final JAXBContext attachmentlistJaxbContext;

    /**
     * Default constructor.
     */
    public SynchronizationServiceImpl() {
        httpClient = HttpClients.createDefault();

        try {
            attachmentlistJaxbContext = JAXBContext.newInstance(AttachmentList.class);
        } catch (JAXBException ex) {
            throw new ServiceRequestToolConfigurationException("Failed to initialize attachmentlistJaxbContext", ex);
        }
    }

    /**
     * Create cloud URI.
     *
     * @param path
     *         the path
     * @param paramNames
     *         the parameter names, may be null
     * @param paramValues
     *         the parameter values, may be null
     * @return the cloud URI
     * @throws ServiceRequestToolException
     *         if there is any error
     */
    private URI createCloudURI(String path, String[] paramNames, String[] paramValues)
            throws ServiceRequestToolException {
        try {
            URIBuilder uriBuilder = new URIBuilder(cloudServiceUrlBase + path);

            if (paramNames != null && paramValues != null && paramNames.length == paramValues.length) {
                for (int i = 0; i < paramNames.length; i++) {
                    uriBuilder.addParameter(paramNames[i], paramValues[i]);
                }
            }
            return uriBuilder.build();
        } catch (URISyntaxException e) {
            throw new ServiceRequestToolException(
                    "Failed to create cloud URI: " + cloudServiceUrlBase + path, e);
        }
    }

    /*
     * Add auth HTTP headers. Note the current user must be present.
     *
     * @param httpRequest
     *         the HTTP request
     */
    private void addAuthHttpHeaders(HttpRequestBase httpRequest) {
        User currentUser = ServiceContext.getCurrentUser();

        httpRequest.addHeader(userIdentifierHeaderName, currentUser.getUserIdentifier());
        httpRequest.addHeader(firstNameHeaderName, currentUser.getFirstName());
        httpRequest.addHeader(lastNameHeaderName, currentUser.getLastName());
        httpRequest.addHeader(emailHeaderName, currentUser.getEmail());
        httpRequest.addHeader(jobTitleHeaderName, currentUser.getJobTitle());
        httpRequest.addHeader(countryHeaderName, currentUser.getCountry());
    }

    /**
     * Add auth and REST related HTTP headers. Note the current user must be present.
     *
     * @param httpRequest
     *         the HTTP request
     */
    private void addRestHeaders(HttpRequestBase httpRequest) {
        addAuthHttpHeaders(httpRequest);

        httpRequest.addHeader("Content-Type", "application/json");
        httpRequest.addHeader("Accept", "application/json");

        // AJAXExceptionResolver requires this header to take effect.
        // We need this so that the OperationLog for AlreadySynchronizedException can be retrieved.
        httpRequest.addHeader("X-Requested-With", "XMLHttpRequest");
    }

    /**
     * Execute HTTP request with TypeReference.
     *
     * @param http
     *         the HTTP request
     * @param resultType
     *         the result type
     * @return the parsed result. May be null
     * @throws CloudConnectionException
     *         if it fails to connect to the cloud
     * @throws AlreadySynchronizedException
     *         if operation log is already synchronized
     * @throws EntityNotFoundException
     *         if the entity to update/delete does not exist
     * @throws CloudServerException
     *         if cloud server returns status code rather than 200
     * @throws ServiceRequestToolException
     *         if there is any other error
     */
    private <T> T executeHTTP(HttpRequestBase http, TypeReference<T> resultType)
            throws ServiceRequestToolException {
        return executeHTTP(http, resultType == null ?
                null : Helper.OBJECT_MAPPER.getTypeFactory().constructType(resultType));
    }

    /**
     * Execute HTTP request with JavaType
     *
     * @param http
     *         the HTTP request
     * @param resultType
     *         the result type
     * @return the parsed result. May be null
     * @throws CloudConnectionException
     *         if it fails to connect to the cloud
     * @throws AlreadySynchronizedException
     *         if operation log is already synchronized
     * @throws EntityNotFoundException
     *         if the entity to update/delete does not exist
     * @throws CloudServerException
     *         if cloud server returns status code rather than 200
     * @throws ServiceRequestToolException
     *         if there is any other error
     */
    private <T> T executeHTTP(HttpRequestBase http, JavaType resultType)
            throws ServiceRequestToolException {

        HttpResponse response = null;
        InputStream resultStream = null;
        try {

            addRestHeaders(http);

            response = httpClient.execute(http);

            HttpEntity responseEntity = response.getEntity();

            if (responseEntity != null) {
                // need to assign the resultStream early, so that in case of an exception,
                // the resultStream can be closed in the finally block.
                resultStream = responseEntity.getContent();
            }

            int statusCode = response.getStatusLine().getStatusCode();

            Header syncOpLogHeader = response.getFirstHeader(syncOpLogHeaderName);
            if (syncOpLogHeader != null) {
                String syncOpLogHeaderValue = syncOpLogHeader.getValue();
                if (StringUtils.isNotBlank(syncOpLogHeaderValue)) {

                    if (statusCode == HttpStatus.SC_CONFLICT) {

                        SynchronizedOperationLog sol = Helper.OBJECT_MAPPER.readValue(syncOpLogHeaderValue,
                                SynchronizedOperationLog.class);

                        String errorMsg = response.getStatusLine().getReasonPhrase();
                        getLogger().warn(
                                "Cloud returns conflict error for: " + http + ". Idempotent operation log: "
                                        + syncOpLogHeaderValue + ". Message: " + errorMsg);
                        throw new AlreadySynchronizedException(sol, errorMsg);
                    } else if (statusCode == HttpStatus.SC_OK) {
                        ServiceContext.setCurrentOperationLog(Helper.OBJECT_MAPPER.readValue(syncOpLogHeaderValue,
                                OperationLog.class));
                    }
                }
            }

            if (statusCode == HttpStatus.SC_NOT_FOUND) {
                String errorMsg = response.getStatusLine().getReasonPhrase();
                // to differentiate a general 404 for URL not found or server not ready.
                if (errorMsg.startsWith(EntityNotFoundException.ENTITY_NOT_FOUND_PREFIX)) {
                    throw new EntityNotFoundException("Cloud returns server error for: " + http
                            + ". Status code: " + statusCode
                            + ". Message: " + response.getStatusLine().getReasonPhrase());
                }
            }

            if (statusCode != HttpStatus.SC_OK) {
                throw new CloudServerException(statusCode,
                        "Cloud returns server error for: " + http + ". Status code: " + statusCode
                                + ". Message: " + response.getStatusLine().getReasonPhrase());
            }

            Header responseTypeHeader = response.getFirstHeader("Content-Type");
            if (responseTypeHeader != null && !StringUtils.isBlank(responseTypeHeader.getValue())
                    && !responseTypeHeader.getValue().contains("application/json")) {
                // Not JSON response
                throw new CloudConnectionException("Cloud returns non-json response for: " + http
                        + ". Response type: " + responseTypeHeader);
            }

            if (resultType == null || responseEntity == null) {
                return null;
            }

            if (resultStream == null) {
                return null;
            }

            try {
                return Helper.OBJECT_MAPPER.readValue(resultStream, resultType);
            } catch (IOException e) {
                throw new CloudConnectionException("Failed to parse JSON response from: " + http, e);
            }

        } catch (ClientProtocolException e) {
            throw new ServiceRequestToolException("Protocol error occurs when connecting to cloud: " + http, e);
        } catch (IOException e) {
            throw new CloudConnectionException("IO error occurs when connecting to cloud: " + http, e);
        } finally {
            // Close response
            IOUtils.closeSilently(resultStream);
            if (response instanceof CloseableHttpResponse) {
                IOUtils.closeSilently((CloseableHttpResponse) response);
            }
        }
    }

    /**
     * Download the attachments to attachmentFolder.
     * The attachment is skipped if it already exists in attachmentFolder.
     *
     * @param attachments
     *         the attachments to download.
     * @throws CloudConnectionException
     *         if it fails to connect to the cloud
     * @throws CloudServerException
     *         if cloud server returns status code rather than 200
     * @throws ServiceRequestToolException
     *         if there is any other error
     */
    private void downloadAttachments(List<Attachment> attachments)
            throws ServiceRequestToolException {

        for (Attachment attachment : attachments) {

            File persistFile = new File(attachmentFolder, attachment.getAttachmentFilepath());
            if (persistFile.exists()) {
                // Persistent file already exists. We can just skip downloading,
                // as the attachment file content is immutable.
                // If the attachment file is updated, the file name would be different.
                continue;
            }

            HttpPost httpPost = new HttpPost(createCloudURI("/request/downloadAttachment", null, null));

            List<NameValuePair> params = new ArrayList<NameValuePair>();
            params.add(new BasicNameValuePair("attachmentName", attachment.getAttachmentFilename()));
            params.add(new BasicNameValuePair("attachmentPath", attachment.getAttachmentFilepath()));

            httpPost.setEntity(new UrlEncodedFormEntity(params, Charset.forName("UTF-8")));

            HttpResponse response = null;
            InputStream resultStream = null;
            OutputStream outputStream = null;

            try {
                addAuthHttpHeaders(httpPost);

                response = httpClient.execute(httpPost);

                HttpEntity responseEntity = response.getEntity();
                if (responseEntity == null) {
                    throw new ServiceRequestToolException("No response entity: " + httpPost);
                }

                resultStream = responseEntity.getContent();

                int statusCode = response.getStatusLine().getStatusCode();
                if (statusCode != HttpStatus.SC_OK) {
                    throw new CloudServerException(statusCode,
                            "Cloud returns server error for: " + httpPost + ". Status code: " + statusCode
                                    + ". Message: " + response.getStatusLine().getReasonPhrase());
                }

                String attachmentFileName = attachment.getAttachmentFilepath() + Helper.TMP_DOWNLOAD_SUFFIX;
                File attachmentFile = new File(attachmentFolder, attachmentFileName);

                // it will just overwrite the existing file if there is
                outputStream = new FileOutputStream(attachmentFile);
                IOUtils.copy(resultStream, outputStream);
                outputStream.flush();

                if (!attachmentFile.renameTo(persistFile)) {
                    // Rename failed, fall back to copy
                    try {
                        FileUtils.copyFile(attachmentFile, persistFile);
                    } catch (IOException e) {
                        throw new ServiceRequestToolException(
                                "Failed to copy attachment file: " + attachmentFile, e);
                    }
                }
            } catch (ClientProtocolException e) {
                throw new ServiceRequestToolException(
                        "Protocol error occurs when connecting to cloud: " + httpPost, e);
            } catch (IOException e) {
                throw new CloudConnectionException(
                        "IO error occurs when connecting to cloud: " + httpPost, e);
            } finally {
                // Close outputStream
                IOUtils.closeSilently(outputStream);

                // Close resultStream and response
                IOUtils.closeSilently(resultStream);
                if (response instanceof CloseableHttpResponse) {
                    IOUtils.closeSilently((CloseableHttpResponse) response);
                }
            }
        }
    }


    /**
     * Check whether the attachments exist in the cloud.
     * Only the new attachments that do not exist in the cloud are returned.
     *
     * @param attachments
     *         the attachments to check.
     * @return the new attachments.
     * @throws CloudConnectionException
     *         if it fails to connect to the cloud
     * @throws CloudServerException
     *         if cloud server returns status code rather than 200
     * @throws ServiceRequestToolException
     *         if there is any other error
     */
    private List<Attachment> getNewAttachments(List<Attachment> attachments)
            throws ServiceRequestToolException {

        if (attachments.size() == 0) {
            return attachments;
        }

        HttpPost httpPost = new HttpPost(createCloudURI("/request/checkAttachment", null, null));

        List<NameValuePair> params = new ArrayList<NameValuePair>();
        for (Attachment attachment : attachments) {
            params.add(new BasicNameValuePair("files[]", attachment.getAttachmentFilepath()));
        }

        httpPost.setEntity(new UrlEncodedFormEntity(params, Charset.forName("UTF-8")));

        HttpResponse response = null;
        InputStream resultStream = null;

        try {
            addAuthHttpHeaders(httpPost);

            response = httpClient.execute(httpPost);

            HttpEntity responseEntity = response.getEntity();
            if (responseEntity == null) {
                throw new ServiceRequestToolException("No response entity: " + httpPost);
            }

            resultStream = responseEntity.getContent();

            int statusCode = response.getStatusLine().getStatusCode();
            if (statusCode != HttpStatus.SC_OK) {
                throw new CloudServerException(statusCode,
                        "Cloud returns server error for: " + httpPost + ". Status code: " + statusCode
                                + ". Message: " + response.getStatusLine().getReasonPhrase());
            }

            List<Boolean> result;

            try {
                result = Helper.OBJECT_MAPPER.readValue(resultStream, TYPE_REFERENCE_LIST_BOOLEAN);
            } catch (IOException e) {
                throw new CloudConnectionException("Failed to parse JSON response from: " + httpPost, e);
            }

            if (result == null || result.size() != attachments.size()) {
                throw new ServiceRequestToolException(
                        "Result is null or size mismatches with attachments:" + result);
            }

            List<Attachment> newAttachments = new ArrayList<Attachment>();

            for (int i = 0; i < result.size(); i++) {
                if (!result.get(i)) {
                    newAttachments.add(attachments.get(i));
                }
            }

            return newAttachments;
        } catch (ClientProtocolException e) {
            throw new ServiceRequestToolException(
                    "Protocol error occurs when connecting to cloud: " + httpPost, e);
        } catch (IOException e) {
            throw new CloudConnectionException(
                    "IO error occurs when connecting to cloud: " + httpPost, e);
        } finally {
            // Close resultStream and response
            IOUtils.closeSilently(resultStream);
            if (response instanceof CloseableHttpResponse) {
                IOUtils.closeSilently((CloseableHttpResponse) response);
            }
        }
    }

    /**
     * Upload the attachments to the cloud.
     *
     * @param attachments
     *         the attachments to upload.
     * @throws CloudConnectionException
     *         if it fails to connect to the cloud
     * @throws CloudServerException
     *         if cloud server returns status code rather than 200
     * @throws ServiceRequestToolException
     *         if there is any other error
     */
    private void uploadAttachments(List<Attachment> attachments)
            throws ServiceRequestToolException {

        attachments = getNewAttachments(attachments);

        if (attachments.size() == 0) {
            return;
        }

        HttpPost httpPost = new HttpPost(createCloudURI("/request/uploadAttachment", null, null));

        MultipartEntityBuilder reqEntity = MultipartEntityBuilder.create();
        reqEntity.setLaxMode();

        for (Attachment attachment : attachments) {
            File persistFile = new File(attachmentFolder, attachment.getAttachmentFilepath());
            if (!persistFile.exists()) {
                throw new ServiceRequestToolException("Attachment file is not found: " + persistFile);
            }

            reqEntity.addBinaryBody("files[]",
                    persistFile, ContentType.DEFAULT_BINARY, attachment.getAttachmentFilepath());
        }

        httpPost.setEntity(reqEntity.build());

        HttpResponse response = null;
        InputStream resultStream = null;

        try {
            addAuthHttpHeaders(httpPost);

            response = httpClient.execute(httpPost);

            HttpEntity responseEntity = response.getEntity();
            if (responseEntity == null) {
                throw new ServiceRequestToolException("No response entity: " + httpPost);
            }

            resultStream = response.getEntity().getContent();

            int statusCode = response.getStatusLine().getStatusCode();
            if (statusCode != HttpStatus.SC_OK) {
                throw new CloudServerException(statusCode,
                        "Cloud returns server error for: " + httpPost + ". Status code: " + statusCode
                                + ". Message: " + response.getStatusLine().getReasonPhrase());
            }

            AttachmentList attachmentList;

            try {
                attachmentList = (AttachmentList) attachmentlistJaxbContext.createUnmarshaller().unmarshal(
                        resultStream);
            } catch (JAXBException e) {
                throw new CloudConnectionException("Failed to parse XML response from: " + httpPost, e);
            }

            if (attachmentList == null || attachmentList.getList() == null) {
                throw new ServiceRequestToolException(
                        "Empty attachmentList: " + httpPost);
            }

            if (attachments.size() != attachmentList.getList().size()) {
                throw new ServiceRequestToolException(
                        "attachmentList has different size: " + httpPost);
            }

            for (int i = 0; i < attachments.size(); i++) {
                Attachment left = attachments.get(i);
                Attachment right = attachmentList.getList().get(i);

                if (!StringUtils.equals(left.getAttachmentFilepath(), right.getAttachmentFilepath())
                        || !StringUtils.equals(left.getAttachmentFilepath(), right.getAttachmentFilename())) {
                    throw new ServiceRequestToolException(
                            "attachmentList has mismatched filePath or filename: " + httpPost);
                }
            }
        } catch (ClientProtocolException e) {
            throw new ServiceRequestToolException("Protocol error occurs when connecting to cloud: " + httpPost, e);
        } catch (IOException e) {
            throw new CloudConnectionException("IO error occurs when connecting to cloud: " + httpPost, e);
        } finally {
            // Close resultStream and response
            IOUtils.closeSilently(resultStream);
            if (response instanceof CloseableHttpResponse) {
                IOUtils.closeSilently((CloseableHttpResponse) response);
            }
        }
    }


    /**
     * Get local entity ID by correlated ID.
     *
     * @param entityClazz
     *         the entity class
     * @param correlatedId
     *         the correlated cloud entity ID
     * @return the local entity ID. May be 0 if entity does not exist.
     * @throws ServiceRequestToolException
     *         if there is any error when getting entity ID
     */
    private long getLocalEntityId(Class<? extends CorrelatedIdentifiableEntity> entityClazz, long correlatedId)
            throws ServiceRequestToolException {

        try {
            List<Long> ids = getEntityManager().createQuery(
                    "select e.id from " + entityClazz.getSimpleName()
                            + " e where e.correlatedId = :correlatedId", Long.class)
                    .setParameter("correlatedId", correlatedId)
                    .setMaxResults(1).getResultList();

            return ids != null && ids.size() > 0 ? ids.get(0) : 0;
        } catch (IllegalStateException e) {
            throw new ServiceRequestToolException(
                    "The entity manager has been closed.", e);
        } catch (PersistenceException e) {
            throw new ServiceRequestToolException(
                    "An error has occurred while accessing the persistence.", e);
        }
    }

    /**
     * Synchronize all cloud customer data down to local storage.
     *
     * @throws CloudConnectionException
     *         if it fails to connect to the cloud
     * @throws ServiceRequestToolException
     *         if there is any other error
     */
    @Transactional
    public void syncDownAllCustomers() throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#syncDownAllCustomers()";
        final Logger logger = getLogger();

        // Log entry
        logger.info("Start sync down all customers.");

        User currentUser = ServiceContext.getCurrentUser();

        if (currentUser == null) {
            // We need know which user to synchronize data for
            logger.warn("Current user is not set, can not synchronize.");
            Helper.logExit(logger, signature, null);
            return;
        }

        List<OperationLog> localLogs = operationLogService.get(Customer.class.getSimpleName(), null, null, false);
        if (localLogs != null && localLogs.size() > 0) {
            logger.info("There are pending changes in local, can not synchronize down from cloud.");
            Helper.logExit(logger, signature, null);
            return;
        }

        try {
            Long lastSeq = operationLogService.getLastSynchronizedSequence(Customer.class.getSimpleName());
            lastSeq = lastSeq == null ? 0 : lastSeq;

            HttpGet httpGet = new HttpGet(
                    createCloudURI("/operationLogs",
                            new String[]{"entityType", "beginSeq"},
                            new String[]{Customer.class.getSimpleName(), lastSeq + ""}));

            EntityOperationLog<Customer>[] cloudLogs = executeHTTP(
                    httpGet, TYPE_REFERENCE_ENTITY_OPERATION_LOGS_CUSTOMER);

            if (cloudLogs != null) {
                for (EntityOperationLog<Customer> cloudEntityLog : cloudLogs) {
                    // Fix the correlatedId of cloud log, this is because even a single user
                    // can have multiple local apps
                    OperationLog cloudLog = cloudEntityLog.getOperationLog();
                    cloudLog.setCorrelatedId(cloudLog.getOperation() == Operation.CREATE ? 0
                            : getLocalEntityId(Customer.class, cloudLog.getEntityId()));
                }
            }

            doSyncDownCustomers(cloudLogs);
        } catch (ServiceRequestToolException e) {
            throw Helper.logException(logger, signature, e);
        }

        // Log Exit
        logger.info("End sync down all customers.");
    }


    /**
     * Synchronize the customer of the given id from cloud down to local storage.
     *
     * @param customerId
     *         the customer id
     * @throws IllegalArgumentException
     *         if the given id is not positive
     * @throws CloudConnectionException
     *         if it fails to connect to the cloud
     * @throws ServiceRequestToolException
     *         if there is any other error
     */
    @Transactional
    public void syncDownCustomer(long customerId) throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#syncDownCustomer(long customerId)";
        final Logger logger = getLogger();

        // Log entry
        logger.info("Start sync down customer: " + customerId);

        Helper.checkPositive(logger, signature, customerId, "customerId");

        User currentUser = ServiceContext.getCurrentUser();

        if (currentUser == null) {
            // We need know which user to synchronize data for
            logger.warn("Current user is not set, can not synchronize.");
            Helper.logExit(logger, signature, null);
            return;
        }

        List<OperationLog> localLogs = operationLogService.get(Customer.class.getSimpleName(), customerId, null, false);
        if (localLogs != null && localLogs.size() > 0) {
            logger.info("There are pending changes in local, can not synchronize down from cloud.");
            Helper.logExit(logger, signature, null);
            return;
        }

        // Get customer
        Customer customer = customerService.get(customerId);
        if (customer == null) {
            // Nothing to to
            return;
        }
        long cloudCustomerId = customer.getCorrelatedId();
        if (cloudCustomerId == 0) {
            // Nothing to to
            return;
        }

        try {
            Long lastSeq = operationLogService.getLastSynchronizedSequence(Customer.class.getSimpleName());
            lastSeq = lastSeq == null ? 0 : lastSeq;

            HttpGet httpGet = new HttpGet(
                    createCloudURI("/operationLogs",
                            new String[]{"entityType", "entityId", "beginSeq"},
                            new String[]{Customer.class.getSimpleName(), "" + cloudCustomerId, "" + lastSeq}));

            EntityOperationLog<Customer>[] cloudLogs = executeHTTP(
                    httpGet, TYPE_REFERENCE_ENTITY_OPERATION_LOGS_CUSTOMER);

            if (cloudLogs != null) {
                for (EntityOperationLog<Customer> cloudEntityLog : cloudLogs) {
                    // Fix the correlatedId of cloud log, this is because even a single user
                    // can have multiple local apps
                    OperationLog cloudLog = cloudEntityLog.getOperationLog();
                    cloudLog.setCorrelatedId(customerId);
                }
            }

            doSyncDownCustomers(cloudLogs);
        } catch (ServiceRequestToolException e) {
            throw Helper.logException(logger, signature, e);
        }

        // Log Exit
        logger.info("End sync down customer: " + customerId);
    }

    /**
     * Do synchronize down customers.
     *
     * @param cloudLogs
     *         the operation logs from cloud
     * @throws CloudConnectionException
     *         if it fails to connect to the cloud
     * @throws ServiceRequestToolException
     *         if there is any other error
     */
    private void doSyncDownCustomers(EntityOperationLog<Customer>[] cloudLogs) throws ServiceRequestToolException {

        if (cloudLogs == null || cloudLogs.length == 0) {
            getLogger().info("No customer operation log found in cloud to sync down.");
            return;
        }

        for (EntityOperationLog<Customer> cloudEntityLog : cloudLogs) {

            OperationLog cloudLog = cloudEntityLog.getOperationLog();

            long cloudCustomerId = cloudLog.getEntityId();
            long localCustomerId = cloudLog.getCorrelatedId();

            // Set current operation log to sync
            ServiceContext.setCurrentOperationLog(cloudLog);

            switch (cloudLog.getOperation()) {
                case CREATE:
                case UPDATE:
                    Customer cloudCustomer = cloudEntityLog.getEntity();

                    if (cloudCustomer == null) {
                        // Nothing to synchronize
                        getLogger().warn("Cloud customer is null, unable to sync down - " + cloudLog.getOperation());
                        operationLogService.operationLogSynchronizedDown(cloudLog);
                        continue;
                    }

                    // Zero the ids
                    Helper.zeroCustomerId(cloudCustomer);

                    // After zero ids we can name it localCustomer.
                    Customer localCustomer = cloudCustomer;

                    localCustomer.setCorrelatedId(cloudCustomerId);

                    if (localCustomerId > 0) {
                        // For update
                        localCustomer.setId(localCustomerId);
                        updateCustomerToLocal(localCustomer, cloudLog);
                    } else {
                        createCustomerToLocal(localCustomer, cloudLog);
                    }

                    break;
                case DELETE:
                    deleteCustomerFromLocal(localCustomerId, cloudLog);
                    break;
                default:
                    throw new ServiceRequestToolException("Unsupported operation : " + cloudLog.getOperation());
            }

            getLogger().info("Customer is synchronized down, cloud id: " + cloudCustomerId
                    + ", local id: " + cloudLog.getCorrelatedId() + ", operation: " + cloudLog.getOperation());
        }
    }

    /**
     * Create customer to local.
     *
     * @param customer
     *         the customer to be created to local
     * @param cloudLog
     *         the related cloud operation log
     * @throws ServiceRequestToolException
     *         if there is any error
     */
    private void createCustomerToLocal(Customer customer, OperationLog cloudLog) throws ServiceRequestToolException {

        customer.setId(0);
        try {
            customerService.create(customer);
        } catch (AlreadySynchronizedException ase) {
            // Ignore
        }
    }

    /**
     * Update customer to local.
     *
     * @param customer
     *         the customer to be updated to local
     * @param cloudLog
     *         the related cloud operation log
     * @throws ServiceRequestToolException
     *         if there is any error
     */
    private void updateCustomerToLocal(Customer customer, OperationLog cloudLog) throws ServiceRequestToolException {

        try {
            customerService.update(customer);
        } catch (EntityNotFoundException e) {
            // The entity is updated on cloud side but deleted on local side
            // , fall back to create, at least we don't lost data
            getLogger().warn("Customer is updated on cloud side but deleted on local side, cloud id: "
                    + cloudLog.getEntityId() + ", local id: " + customer.getId());
            cloudLog.setOperation(Operation.CREATE);
            createCustomerToLocal(customer, cloudLog);
        } catch (AlreadySynchronizedException ase) {
            // Ignore
        }
    }

    /**
     * Delete customer from local.
     *
     * @param localCustomerId
     *         the id of the customer to be deleted from local
     * @param cloudLog
     *         the related cloud operation log
     * @throws ServiceRequestToolException
     *         if there is any error
     */
    private void deleteCustomerFromLocal(long localCustomerId, OperationLog cloudLog) throws ServiceRequestToolException {

        if (localCustomerId > 0) {
            try {
                customerService.delete(new long[]{localCustomerId});
            } catch (EntityNotFoundException e) {
                // Already deleted
                operationLogService.operationLogSynchronizedDown(cloudLog);
            } catch (AlreadySynchronizedException e) {
                // Ignore
            }
        } else {
            // Nothing to delete
            operationLogService.operationLogSynchronizedDown(cloudLog);
        }
    }

    /**
     * Synchronize all local pending updates of customers up to cloud.
     *
     * @throws CloudConnectionException
     *         if it fails to connect to the cloud
     * @throws ServiceRequestToolException
     *         if there is any other error
     */
    @Transactional
    public void syncUpAllCustomers() throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#syncUpAllCustomers()";
        final Logger logger = getLogger();

        // Log entry
        logger.info("Start sync up all customers.");

        User currentUser = ServiceContext.getCurrentUser();

        if (currentUser == null) {
            // We need know which user to synchronize data for
            logger.warn("Current user is not set, can not synchronize.");
            Helper.logExit(logger, signature, null);
            return;
        }

        try {
            List<OperationLog> localLogs = operationLogService.get(Customer.class.getSimpleName(), null, null, false);

            doSyncUpCustomers(localLogs);
        } catch (ServiceRequestToolException e) {
            throw Helper.logException(logger, signature, e);
        }

        // Log Exit
        logger.info("End sync up all customers.");
    }
    
    /**
     * Synchronize all local pending updates of customers up to cloud.
     *
     * @throws CloudConnectionException
     *         if it fails to connect to the cloud
     * @throws ServiceRequestToolException
     *         if there is any other error
     */
    @Transactional
    public void syncUpAllProfiles() throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#syncUpAllProfiles()";
        final Logger logger = getLogger();

        // Log entry
        logger.info("Start sync up all profiles.");

        User currentUser = ServiceContext.getCurrentUser();

        if (currentUser == null) {
            // We need know which user to synchronize data for
            logger.warn("Current user is not set, can not synchronize.");
            Helper.logExit(logger, signature, null);
            return;
        }

        try {
            List<OperationLog> localLogs = operationLogService.get(Profile.class.getSimpleName(), null, null, true);
            doSyncUpProfiles(localLogs);
        } catch (ServiceRequestToolException e) {
            throw Helper.logException(logger, signature, e);
        }

        // Log Exit
        logger.info("End sync up all customers.");
    }
    
    /**
     * Do synchronize up profiles.
     *
     * @param localLogs
     *         the operation logs from local
     * @throws CloudConnectionException
     *         if it fails to connect to the cloud
     * @throws ServiceRequestToolException
     *         if there is any other error
     */
    private void doSyncUpProfiles(List<OperationLog> localLogs) throws ServiceRequestToolException {

        if (localLogs == null || localLogs.size() == 0) {
            getLogger().info("No profile operation log found in local to sync up.");
            return;
        }

        for (OperationLog localLog : localLogs) {

            long localProfileId = localLog.getEntityId();
            long cloudProfileId = localLog.getCorrelatedId();

            switch (localLog.getOperation()) {
                case CREATE:
                case UPDATE:
                    Profile localProfile = profileService.get(localProfileId);

                    if (localProfile == null) {
                        // Nothing to synchronize
                        getLogger().warn("Local Profile is null, unable to sync up - " + localLog.getOperation());
                        operationLogService.operationLogSynchronizedUp(localLog);
                        continue;
                    }

                    // Copy entity
                    Profile cloudProfile = Helper.deepCloneEntity(localProfile);

                    cloudProfile.setCorrelatedId(localProfileId);
                    if (cloudProfileId > 0) {
                        cloudProfile.setId(cloudProfileId);
                        // For update
                        updateEntityToCloud(cloudProfile, localLog);
                    } else {
                        // For create
                        createEntityToCloud(cloudProfile, localLog);
                    }

                    break;
                default:
                    throw new ServiceRequestToolException("Unsupported operation : " + localLog.getOperation());
            }

            getLogger().info("Profile is synchronized up, local id: " + localProfileId
                    + ", cloud id: " + localLog.getCorrelatedId() + ", operation: " + localLog.getOperation());
        }
    }


    /**
     * Synchronize the customer of the given id from local storage up to cloud.
     *
     * @param customerId
     *         the customer id
     * @throws IllegalArgumentException
     *         if the given id is not positive
     * @throws CloudConnectionException
     *         if it fails to connect to the cloud
     * @throws ServiceRequestToolException
     *         if there is any other error
     */
    @Transactional
    public void syncUpCustomer(long customerId) throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#syncUpCustomer(long customerId)";
        final Logger logger = getLogger();

        // Log entry
        logger.info("Start sync up customer: " + customerId);

        Helper.checkPositive(logger, signature, customerId, "customerId");

        User currentUser = ServiceContext.getCurrentUser();

        if (currentUser == null) {
            // We need know which user to synchronize data for
            logger.warn("Current user is not set, can not synchronize.");
            Helper.logExit(logger, signature, null);
            return;
        }

        try {
            List<OperationLog> localLogs = operationLogService.get(Customer.class.getSimpleName(), customerId, null, false);

            doSyncUpCustomers(localLogs);
        } catch (ServiceRequestToolException e) {
            throw Helper.logException(logger, signature, e);
        }

        // Log Exit
        logger.info("End sync up customer: " + customerId);
    }

    /**
     * Do synchronize up customers.
     *
     * @param localLogs
     *         the operation logs from local
     * @throws CloudConnectionException
     *         if it fails to connect to the cloud
     * @throws ServiceRequestToolException
     *         if there is any other error
     */
    private void doSyncUpCustomers(List<OperationLog> localLogs) throws ServiceRequestToolException {

        if (localLogs == null || localLogs.size() == 0) {
            getLogger().info("No customer operation log found in local to sync up.");
            return;
        }

        for (OperationLog localLog : localLogs) {

            long localCustomerId = localLog.getEntityId();
            long cloudCustomerId = localLog.getCorrelatedId();

            switch (localLog.getOperation()) {
                case CREATE:
                case UPDATE:
                    Customer localCustomer = customerService.get(localCustomerId);

                    if (localCustomer == null) {
                        // Nothing to synchronize
                        getLogger().warn("Local customer is null, unable to sync up - " + localLog.getOperation());
                        operationLogService.operationLogSynchronizedUp(localLog);
                        continue;
                    }

                    // Copy entity
                    Customer cloudCustomer = Helper.deepCloneEntity(localCustomer);

                    // Zero ids
                    Helper.zeroCustomerId(cloudCustomer);

                    cloudCustomer.setCorrelatedId(localCustomerId);

                    if (cloudCustomerId > 0) {
                        cloudCustomer.setId(cloudCustomerId);
                        // For update
                        updateEntityToCloud(cloudCustomer, localLog);
                    } else {
                        // For create
                        createEntityToCloud(cloudCustomer, localLog);
                    }

                    break;
                case DELETE:
                    // For delete
                    deleteEntityFromCloud(Customer.class, cloudCustomerId, localLog);
                    break;
                default:
                    throw new ServiceRequestToolException("Unsupported operation : " + localLog.getOperation());
            }

            getLogger().info("Customer is synchronized up, local id: " + localCustomerId
                    + ", cloud id: " + localLog.getCorrelatedId() + ", operation: " + localLog.getOperation());
        }
    }


    /**
     * Synchronize cloud default profile data down to local storage.
     *
     * @throws CloudConnectionException
     *         if it fails to connect to the cloud
     * @throws ServiceRequestToolException
     *         if there is any other error
     */
    @Transactional
    public void syncDownDefaultProfile() throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#syncDownDefaultProfile()";
        final Logger logger = getLogger();

        // Log entry
        logger.info("Start sync down default profile");

        User currentUser = ServiceContext.getCurrentUser();

        if (currentUser == null) {
            // We need know which user to synchronize data for
            logger.warn("Current user is not set, can not synchronize.");
            Helper.logExit(logger, signature, null);
            return;
        }

        List<OperationLog> localLogs = operationLogService.get(Profile.class.getSimpleName(), null, null, false);
        if (localLogs != null && localLogs.size() > 0) {
            logger.info("There are pending changes in local, can not synchronize down from cloud.");
            Helper.logExit(logger, signature, null);
            return;
        }

        try {
            Long lastSeq = operationLogService.getLastSynchronizedSequence(Profile.class.getSimpleName());
            lastSeq = lastSeq == null ? 0 : lastSeq;

            HttpGet httpGet = new HttpGet(
                    createCloudURI("/operationLogs",
                            new String[]{"entityType", "beginSeq"},
                            new String[]{Profile.class.getSimpleName(), "" + lastSeq}));

            EntityOperationLog<Profile>[] cloudLogs = executeHTTP(
                    httpGet, TYPE_REFERENCE_ENTITY_OPERATION_LOGS_PROFILE);

            Profile defaultProfile = profileService.getDefaultProfile();

            if (cloudLogs != null) {
                for (EntityOperationLog<Profile> cloudEntityLog : cloudLogs) {
                    // Fix the correlatedId of cloud log, this is because even a single user
                    // can have multiple local apps
                    OperationLog cloudLog = cloudEntityLog.getOperationLog();
                    cloudLog.setCorrelatedId(defaultProfile == null ? 0 : defaultProfile.getId());
                }
            }

            if (cloudLogs == null || cloudLogs.length == 0) {
                getLogger().info("No profile operation log found in cloud to sync down.");
                return;
            }

            for (EntityOperationLog<Profile> cloudEntityLog : cloudLogs) {

                OperationLog cloudLog = cloudEntityLog.getOperationLog();

                long cloudId = cloudLog.getEntityId();
                long localId = cloudLog.getCorrelatedId();

                // Set current operation log to sync
                ServiceContext.setCurrentOperationLog(cloudLog);

                switch (cloudLog.getOperation()) {
                    case CREATE:
                    case UPDATE:
                        Profile cloudProfile = cloudEntityLog.getEntity();

                        if (cloudProfile == null) {
                            // Nothing to synchronize
                            getLogger().warn("Cloud profile is null, unable to sync down - " + cloudLog.getOperation());
                            operationLogService.operationLogSynchronizedDown(cloudLog);
                            continue;
                        }

                        // Zero the ids
                        cloudProfile.setId(0);

                        // After zero ids we can name it localProfile..
                        Profile localProfile = cloudProfile;

                        localProfile.setCorrelatedId(cloudId);

                        if (localId > 0) {
                            // For update
                            localProfile.setId(localId);
                            updateProfileToLocal(localProfile, cloudLog);
                        } else {
                            createProfileToLocal(localProfile, cloudLog);
                        }

                        break;
                    default:
                        throw new ServiceRequestToolException("Unsupported operation : " + cloudLog.getOperation());
                }

                getLogger().info("Profile is synchronized down, cloud id: " + cloudId
                        + ", local id: " + cloudLog.getCorrelatedId() + ", operation: " + cloudLog.getOperation());
            }
        } catch (ServiceRequestToolException e) {
            throw Helper.logException(logger, signature, e);
        }

        // Log Exit
        logger.info("End sync down default profile");
    }

    /**
     * Create profile to local.
     *
     * @param profile
     *         the profile to be created to local
     * @param cloudLog
     *         the related cloud operation log
     * @throws ServiceRequestToolException
     *         if there is any error
     */
    private void createProfileToLocal(Profile profile, OperationLog cloudLog) throws ServiceRequestToolException {

        profile.setId(0);
        try {
            profileService.create(profile);
        } catch (AlreadySynchronizedException ase) {
            // Ignore
        }
    }

    /**
     * Update profile to local.
     *
     * @param profile
     *         the profile to be updated to local
     * @param cloudLog
     *         the related cloud operation log
     * @throws ServiceRequestToolException
     *         if there is any error
     */
    private void updateProfileToLocal(Profile profile, OperationLog cloudLog) throws ServiceRequestToolException {

        try {
            profileService.update(profile);
            // Update the current user's roles
            User currentUser = ServiceContext.getCurrentUser();
            if(currentUser.getUserIdentifier().equals(profile.getUserIdentifier())){
                currentUser.setApprover(profile.isApprover());
            }
        } catch (EntityNotFoundException e) {
            // The entity is updated on cloud side but deleted on local side
            // , fall back to create, at least we don't lost data
            getLogger().warn("Profile is updated on cloud side but deleted on local side, cloud id: "
                    + cloudLog.getEntityId() + ", local id: " + profile.getId());
            cloudLog.setOperation(Operation.CREATE);
            createProfileToLocal(profile, cloudLog);
        } catch (AlreadySynchronizedException ase) {
            // Ignore
        }
    }

    /**
     * Synchronize local pending update of profile up to cloud.
     *
     * @throws CloudConnectionException
     *         if it fails to connect to the cloud
     * @throws ServiceRequestToolException
     *         if there is any other error
     */
    @Transactional
    public void syncUpProfile() throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#syncUpProfile()";
        final Logger logger = getLogger();

        // Log entry
        logger.info("Start sync up profile");

        User currentUser = ServiceContext.getCurrentUser();

        if (currentUser == null) {
            // We need know which user to synchronize data for
            logger.warn("Current user is not set, can not synchronize.");
            Helper.logExit(logger, signature, null);
            return;
        }

        try {
            List<OperationLog> localLogs = operationLogService.get(Profile.class.getSimpleName(), null, null, false);

            if (localLogs == null || localLogs.size() == 0) {
                getLogger().info("No profile operation log found in local to sync up.");
                return;
            }

            for (OperationLog localLog : localLogs) {

                long localId = localLog.getEntityId();
                long cloudId = localLog.getCorrelatedId();

                switch (localLog.getOperation()) {
                    case CREATE:
                    case UPDATE:
                        Profile localProfile = profileService.getDefaultProfile();

                        if (localProfile == null) {
                            // Nothing to synchronize
                            getLogger().warn("Local profile is null, unable to sync up - " + localLog.getOperation());
                            operationLogService.operationLogSynchronizedUp(localLog);
                            continue;
                        }

                        // Copy entity
                        Profile cloudProfile = Helper.deepCloneEntity(localProfile);

                        // Zero ids
                        cloudProfile.setId(0);
                        cloudProfile.setCorrelatedId(localId);

                        if (cloudId > 0) {
                            cloudProfile.setId(cloudId);
                            // For update
                            updateEntityToCloud(cloudProfile, localLog);
                        } else {
                            // For create
                            createEntityToCloud(cloudProfile, localLog);
                        }

                        break;
                    case DELETE:
                    default:
                        throw new ServiceRequestToolException("Unsupported operation : " + localLog.getOperation());
                }

                getLogger().info("Profile is synchronized up, local id: " + localId
                        + ", cloud id: " + localLog.getCorrelatedId() + ", operation: " + localLog.getOperation());
            }
        } catch (ServiceRequestToolException e) {
            throw Helper.logException(logger, signature, e);
        }

        // Log Exit
        logger.info("End sync up profile");
    }

    /**
     * Create entity to cloud.
     *
     * @param entity
     *         the entity to be created to cloud
     * @param localLog
     *         the related local operation log
     * @throws CloudConnectionException
     *         if it fails to connect to the cloud
     * @throws ServiceRequestToolException
     *         if there is any other error
     */
    private void createEntityToCloud(CorrelatedIdentifiableEntity entity, OperationLog localLog)
            throws ServiceRequestToolException {

        localLog.setOperation(Operation.CREATE);
        entity.setId(0);

        HttpPost httpPost = new HttpPost(createCloudURI("/" + entity.getClass().getSimpleName().toLowerCase(),
                null, null));
        try {
            httpPost.addHeader(syncOpLogHeaderName, Helper.OBJECT_MAPPER.writeValueAsString(localLog));
            httpPost.setEntity(new StringEntity(
                    Helper.OBJECT_MAPPER.writeValueAsString(entity), ContentType.APPLICATION_JSON));
        } catch (IOException e) {
            throw new ServiceRequestToolException("Failed to populate HTTP JSON content", e);
        }

        long cloudId;
        try {
            CorrelatedIdentifiableEntity created = executeHTTP(
                    httpPost, Helper.OBJECT_MAPPER.getTypeFactory().constructType(entity.getClass()));
            cloudId = created.getId();
        } catch (AlreadySynchronizedException ase) {
            // Ignore
            cloudId = ase.getSynchronizedLog().getCorrelatedId();
        }

        // For local operation log, delete them after synchronized up
        localLog.setCorrelatedId(cloudId);
        operationLogService.operationLogSynchronizedUp(localLog);

        // Mark cloud response log as synchronized down
        OperationLog cloudLog = ServiceContext.getCurrentOperationLog();
        if (cloudLog != null) {
            operationLogService.operationLogSynchronizedDown(cloudLog);
        }
    }

    /**
     * Update entity to cloud.
     *
     * @param entity
     *         the entity to be updated to cloud
     * @param localLog
     *         the related local operation log
     * @throws CloudConnectionException
     *         if it fails to connect to the cloud
     * @throws ServiceRequestToolException
     *         if there is any other error
     */
    private void updateEntityToCloud(CorrelatedIdentifiableEntity entity, OperationLog localLog)
            throws ServiceRequestToolException {

        localLog.setOperation(Operation.UPDATE);

        HttpPut httpPut = new HttpPut(createCloudURI("/" + entity.getClass().getSimpleName().toLowerCase() + "/"
                + entity.getId(), null, null));

        try {
            httpPut.addHeader(syncOpLogHeaderName, Helper.OBJECT_MAPPER.writeValueAsString(localLog));
            httpPut.setEntity(new StringEntity(
                    Helper.OBJECT_MAPPER.writeValueAsString(entity), ContentType.APPLICATION_JSON));
        } catch (IOException e) {
            throw new ServiceRequestToolException("Failed to populate HTTP JSON content", e);
        }

        try {
            executeHTTP(httpPut, (JavaType) null);
        } catch (EntityNotFoundException e) {
            // The entity is updated on local side but deleted on cloud side
            // , fall back to create, at least we don't lost data
            getLogger().warn(entity.getClass().getSimpleName()
                    + " is updated on local side but deleted on cloud side, local id: "
                    + localLog.getEntityId() + ", cloud id: " + entity.getId());
            createEntityToCloud(entity, localLog);
            return;
        } catch (AlreadySynchronizedException e) {
            // Ignore
        }

        // For local operation log, delete them after synchronized up
        operationLogService.operationLogSynchronizedUp(localLog);

        // Mark cloud response log as synchronized down
        OperationLog cloudLog = ServiceContext.getCurrentOperationLog();
        if (cloudLog != null) {
            operationLogService.operationLogSynchronizedDown(cloudLog);
        }
    }

    /**
     * Delete entity from cloud.
     *
     * @param cloudEntityType
     *         the type of entity to be deleted from cloud
     * @param cloudEntityId
     *         the id of entity to be deleted from cloud
     * @param localLog
     *         the related local operation log
     * @throws CloudConnectionException
     *         if it fails to connect to the cloud
     * @throws ServiceRequestToolException
     *         if there is any other error
     */
    private void deleteEntityFromCloud(Class cloudEntityType, long cloudEntityId, OperationLog localLog)
            throws ServiceRequestToolException {

        localLog.setOperation(Operation.DELETE);

        if (cloudEntityId > 0) {
            HttpDelete httpDelete = new HttpDelete(createCloudURI("/" + cloudEntityType.getSimpleName().toLowerCase()
                    + "/" + cloudEntityId, null, null));

            try {
                httpDelete.addHeader(syncOpLogHeaderName, Helper.OBJECT_MAPPER.writeValueAsString(localLog));
            } catch (IOException e) {
                throw new ServiceRequestToolException("Failed to populate HTTP JSON content", e);
            }

            try {
                executeHTTP(httpDelete, (JavaType) null);
            } catch (EntityNotFoundException e) {
                // The entity has already been deleted from cloud
            } catch (AlreadySynchronizedException e) {
                // Ignore
            }
        }

        // For local operation log, delete them after synchronized up
        operationLogService.operationLogSynchronizedUp(localLog);

        // Mark cloud response log as synchronized down
        OperationLog cloudLog = ServiceContext.getCurrentOperationLog();
        if (cloudLog != null) {
            operationLogService.operationLogSynchronizedDown(cloudLog);
        }
    }


    /**
     * Synchronize all cloud request data down to local storage.
     *
     * @throws CloudConnectionException
     *         if it fails to connect to the cloud
     * @throws ServiceRequestToolException
     *         if there is any other error
     */
    @Transactional
    public void syncDownAllRequests() throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#syncDownAllRequests()";
        final Logger logger = getLogger();

        // Log entry
        logger.info("Start sync down all requests.");

        User currentUser = ServiceContext.getCurrentUser();

        if (currentUser == null) {
            // We need know which user to synchronize data for
            logger.warn("Current user is not set, can not synchronize.");
            Helper.logExit(logger, signature, null);
            return;
        }

        List<OperationLog> localLogs = operationLogService.get(Request.class.getSimpleName(), null, null, false);
        if (localLogs != null && localLogs.size() > 0) {
            logger.info("There are pending changes in local, can not synchronize down from cloud.");
            Helper.logExit(logger, signature, null);
            return;
        }

        try {
            Long lastSeq = operationLogService.getLastSynchronizedSequence(Request.class.getSimpleName());
            lastSeq = lastSeq == null ? 0 : lastSeq;

            HttpGet httpGet = new HttpGet(
                    createCloudURI("/operationLogs",
                            new String[]{"entityType", "beginSeq"},
                            new String[]{Request.class.getSimpleName(), lastSeq + ""}));

            EntityOperationLog<Request>[] cloudLogs = executeHTTP(
                    httpGet, TYPE_REFERENCE_ENTITY_OPERATION_LOGS_REQUEST);

            if (cloudLogs != null) {
                for (EntityOperationLog<Request> cloudEntityLog : cloudLogs) {
                    // Fix the correlatedId of cloud log, this is because even a single user
                    // can have multiple local apps
                    OperationLog cloudLog = cloudEntityLog.getOperationLog();
                    cloudLog.setCorrelatedId(cloudLog.getOperation() == Operation.CREATE ? 0
                            : getLocalEntityId(Request.class, cloudLog.getEntityId()));
                }
            }

            doSyncDownRequests(cloudLogs);
        } catch (ServiceRequestToolException e) {
            throw Helper.logException(logger, signature, e);
        }

        // Log Exit
        logger.info("End sync down all requests.");
    }

    /**
     * Do synchronize down requests.
     *
     * @param cloudLogs
     *         the operation logs from cloud
     * @throws CloudConnectionException
     *         if it fails to connect to the cloud
     * @throws ServiceRequestToolException
     *         if there is any other error
     */
    private void doSyncDownRequests(EntityOperationLog<Request>[] cloudLogs) throws ServiceRequestToolException {

        if (cloudLogs == null || cloudLogs.length == 0) {
            getLogger().info("No request operation log found in cloud to sync down.");
            return;
        }

        for (EntityOperationLog<Request> cloudEntityLog : cloudLogs) {

            OperationLog cloudLog = cloudEntityLog.getOperationLog();

            long cloudRequestId = cloudLog.getEntityId();
            long localRequestId = cloudLog.getCorrelatedId();

            // Set current operation log to sync
            ServiceContext.setCurrentOperationLog(cloudLog);

            switch (cloudLog.getOperation()) {
                case CREATE:
                case UPDATE:
                    Request cloudRequest = cloudEntityLog.getEntity();

                    if (cloudRequest == null) {
                        // Nothing to synchronize
                        getLogger().warn("Cloud request is null, unable to sync down - " + cloudLog.getOperation());
                        operationLogService.operationLogSynchronizedDown(cloudLog);
                        continue;
                    }

                    if (cloudRequest.getStartRequestData() != null) {
                        downloadAttachments(cloudRequest.getStartRequestData().getAttachments());
                    }

                    // Zero the ids
                    Helper.zeroRequestId(cloudRequest);

                    // After zero ids we can name it localRequest.
                    Request localRequest = cloudRequest;

                    localRequest.setCorrelatedId(cloudRequestId);
                    
                    Profile approver = localRequest.getApprover();
                    if(approver != null){
                        approver.setId(approver.getCorrelatedId());
                    }
                    
                    List<Profile> additionalRecipients = localRequest.getAdditionalRecipients();
                    if(additionalRecipients != null){
                        for (int i = 0; i < additionalRecipients.size(); i++) {
                            Profile recipient = additionalRecipients.get(i);
                            recipient.setId(recipient.getCorrelatedId());
                        }
                    }
                    
                    if (localRequestId > 0) {
                        // For update
                        localRequest.setId(localRequestId);
                        updateRequestToLocal(localRequest, cloudLog);
                    } else {
                        createRequestToLocal(localRequest, cloudLog);
                    }

                    break;
                case DELETE:
                    deleteRequestFromLocal(localRequestId, cloudLog);
                    break;
                default:
                    throw new ServiceRequestToolException("Unsupported operation : " + cloudLog.getOperation());
            }

            getLogger().info("Request is synchronized down, cloud id: " + cloudRequestId
                    + ", local id: " + cloudLog.getCorrelatedId() + ", operation: " + cloudLog.getOperation());
        }
    }

    /**
     * Create request to local.
     *
     * @param request
     *         the request to be created to local
     * @param cloudLog
     *         the related cloud operation log
     * @throws ServiceRequestToolException
     *         if there is any error
     */
    private void createRequestToLocal(Request request, OperationLog cloudLog) throws ServiceRequestToolException {

        request.setId(0);
        try {
            requestService.create(request);
        } catch (AlreadySynchronizedException ase) {
            // Ignore
        }
    }

    /**
     * Update request to local.
     *
     * @param request
     *         the request to be updated to local
     * @param cloudLog
     *         the related cloud operation log
     * @throws ServiceRequestToolException
     *         if there is any error
     */
    private void updateRequestToLocal(Request request, OperationLog cloudLog) throws ServiceRequestToolException {

        try {
            requestService.update(request);
        } catch (EntityNotFoundException e) {
            // The entity is updated on cloud side but deleted on local side
            // , fall back to create, at least we don't lost data
            getLogger().warn("Request is updated on cloud side but deleted on local side, cloud id: "
                    + cloudLog.getEntityId() + ", local id: " + request.getId());
            cloudLog.setOperation(Operation.CREATE);
            createRequestToLocal(request, cloudLog);
        } catch (AlreadySynchronizedException ase) {
            // Ignore
        }
    }

    /**
     * Delete request from local.
     *
     * @param localRequestId
     *         the id of the request to be deleted from local
     * @param cloudLog
     *         the related cloud operation log
     * @throws ServiceRequestToolException
     *         if there is any error
     */
    private void deleteRequestFromLocal(long localRequestId, OperationLog cloudLog) throws ServiceRequestToolException {

        if (localRequestId > 0) {
            try {
                requestService.delete(new long[]{localRequestId});
            } catch (EntityNotFoundException e) {
                // Already deleted
                operationLogService.operationLogSynchronizedDown(cloudLog);
            } catch (AlreadySynchronizedException e) {
                // Ignore
            }
        } else {
            // Nothing to delete
            operationLogService.operationLogSynchronizedDown(cloudLog);
        }
    }

    /**
     * Synchronize the request of the given id from cloud down to local storage.
     *
     * @param requestId
     *         the request id
     * @throws IllegalArgumentException
     *         if the given id is not positive
     * @throws CloudConnectionException
     *         if it fails to connect to the cloud
     * @throws ServiceRequestToolException
     *         if there is any other error
     */
    @Transactional
    public void syncDownRequest(long requestId) throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#syncDownRequest(long requestId)";
        final Logger logger = getLogger();

        // Log entry
        logger.info("Start sync down request: " + requestId);

        Helper.checkPositive(logger, signature, requestId, "requestId");

        User currentUser = ServiceContext.getCurrentUser();

        if (currentUser == null) {
            // We need know which user to synchronize data for
            logger.warn("Current user is not set, can not synchronize.");
            Helper.logExit(logger, signature, null);
            return;
        }

        List<OperationLog> localLogs = operationLogService.get(Request.class.getSimpleName(), requestId, null, false);
        if (localLogs != null && localLogs.size() > 0) {
            logger.info("There are pending changes in local, can not synchronize down from cloud.");
            Helper.logExit(logger, signature, null);
            return;
        }

        // Get request
        Request request = requestService.get(requestId);
        if (request == null) {
            // Nothing to to
            return;
        }
        long cloudRequestId = request.getCorrelatedId();
        if (cloudRequestId == 0) {
            // Nothing to to
            return;
        }

        try {
            Long lastSeq = operationLogService.getLastSynchronizedSequence(Request.class.getSimpleName());
            lastSeq = lastSeq == null ? 0 : lastSeq;

            HttpGet httpGet = new HttpGet(
                    createCloudURI("/operationLogs",
                            new String[]{"entityType", "entityId", "beginSeq", "allUserLogs"},
                            new String[]{Request.class.getSimpleName(), "" + cloudRequestId, "" + lastSeq, "true"}));

            EntityOperationLog<Request>[] cloudLogs = executeHTTP(
                    httpGet, TYPE_REFERENCE_ENTITY_OPERATION_LOGS_REQUEST);

            if (cloudLogs != null) {
                for (EntityOperationLog<Request> cloudEntityLog : cloudLogs) {
                    // Fix the correlatedId of cloud log, this is because even a single user
                    // can have multiple local apps
                    OperationLog cloudLog = cloudEntityLog.getOperationLog();
                    cloudLog.setCorrelatedId(requestId);
                }
            }

            doSyncDownRequests(cloudLogs);
        } catch (ServiceRequestToolException e) {
            throw Helper.logException(logger, signature, e);
        }

        // Log Exit
        logger.info("End sync down request: " + requestId);
    }
    
    /**
     * Synchronize all cloud profile data down to local storage.
     *
     * @throws CloudConnectionException
     *         if it fails to connect to the cloud
     * @throws ServiceRequestToolException
     *         if there is any other error
     * @since 1.4
     */
    @Override
    @Transactional
    public void syncDownAllProfiles() throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#syncDownAllProfiles()";
        final Logger logger = getLogger();

        // Log entry
        logger.info("Start sync down all profiles.");

        User currentUser = ServiceContext.getCurrentUser();

        if (currentUser == null) {
            // We need know which user to synchronize data for
            logger.warn("Current user is not set, can not synchronize.");
            Helper.logExit(logger, signature, null);
            return;
        }

        try {
            Long lastSeq = operationLogService.getLastSynchronizedSequence(Profile.class.getSimpleName());
            lastSeq = lastSeq == null ? 0 : lastSeq;

            HttpGet httpGet = new HttpGet(
                    createCloudURI("/operationLogs",
                            new String[]{"entityType", "beginSeq", "allUserLogs"},
                            new String[]{Profile.class.getSimpleName(), lastSeq + "", "true"}));

            EntityOperationLog<Profile>[] cloudLogs = executeHTTP(
                    httpGet, TYPE_REFERENCE_ENTITY_OPERATION_LOGS_PROFILE);

            if (cloudLogs != null) {
                for (EntityOperationLog<Profile> cloudEntityLog : cloudLogs) {
                    // Fix the correlatedId of cloud log, this is because even a single user
                    // can have multiple local apps
                    OperationLog cloudLog = cloudEntityLog.getOperationLog();
                    cloudLog.setCorrelatedId(cloudLog.getOperation() == Operation.CREATE ? 0
                            : getLocalEntityId(Profile.class, cloudLog.getEntityId()));
                }
            }

            doSyncDownProfiles(cloudLogs);
            syncUpAllProfiles();
        } catch (ServiceRequestToolException e) {
            throw Helper.logException(logger, signature, e);
        }

        // Log Exit
        logger.info("End sync down all profiles.");
    }
    
    /**
     * Do synchronize down profiles.
     *
     * @param cloudLogs
     *         the operation logs from cloud
     * @throws CloudConnectionException
     *         if it fails to connect to the cloud
     * @throws ServiceRequestToolException
     *         if there is any other error
     * @since 1.4
     */
    private void doSyncDownProfiles(EntityOperationLog<Profile>[] cloudLogs) throws ServiceRequestToolException {

        if (cloudLogs == null || cloudLogs.length == 0) {
            getLogger().info("No profile operation log found in cloud to sync down.");
            return;
        }

        for (EntityOperationLog<Profile> cloudEntityLog : cloudLogs) {

            OperationLog cloudLog = cloudEntityLog.getOperationLog();

            long cloudProfileId = cloudLog.getEntityId();
            long localProfileId = cloudLog.getCorrelatedId();

            // Set current operation log to sync
            ServiceContext.setCurrentOperationLog(cloudLog);
            
            switch (cloudLog.getOperation()) {
            case CREATE:
            case UPDATE:
                Profile cloudProfile = cloudEntityLog.getEntity();

                if (cloudProfile == null) {
                    // Nothing to synchronize
                    getLogger().warn("Cloud profile is null, unable to sync down - " + cloudLog.getOperation());
                    operationLogService.operationLogSynchronizedDown(cloudLog);
                    continue;
                }


                // After zero ids we can name it localCustomer.
                Profile localProfile = cloudProfile;

                localProfile.setCorrelatedId(cloudProfileId);

                if (localProfileId > 0) {
                    // For update
                    localProfile.setId(localProfileId);
                    updateProfileToLocal(localProfile, cloudLog);
                } else {
                    createProfileToLocal(localProfile, cloudLog);
                }

                break;
            case DELETE:
                deleteCustomerFromLocal(localProfileId, cloudLog);
                break;
            default:
                throw new ServiceRequestToolException("Unsupported operation : " + cloudLog.getOperation());
        }

            getLogger().info("Profile is synchronized down, cloud id: " + cloudProfileId
                    + ", local id: " + cloudLog.getCorrelatedId() + ", operation: " + cloudLog.getOperation());
        }
    }



    /**
     * Synchronize all local pending updates of requests up to cloud.
     *
     * @throws CloudConnectionException
     *         if it fails to connect to the cloud
     * @throws ServiceRequestToolException
     *         if there is any other error
     */
    @Transactional
    public void syncUpAllRequests() throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#syncUpAllRequests()";
        final Logger logger = getLogger();

        // Log entry
        logger.info("Start sync up all requests.");

        User currentUser = ServiceContext.getCurrentUser();

        if (currentUser == null) {
            // We need know which user to synchronize data for
            logger.warn("Current user is not set, can not synchronize.");
            Helper.logExit(logger, signature, null);
            return;
        }

        try {
            List<OperationLog> localLogs = operationLogService.get(Request.class.getSimpleName(), null, null, false);

            doSyncUpRequests(localLogs);
        } catch (ServiceRequestToolException e) {
            throw Helper.logException(logger, signature, e);
        }

        // Log Exit
        logger.info("End sync up all requests.");
    }


    /**
     * Synchronize the request of the given id from local storage up to cloud.
     *
     * @param requestId
     *         the request id
     * @throws IllegalArgumentException
     *         if the given id is not positive
     * @throws CloudConnectionException
     *         if it fails to connect to the cloud
     * @throws ServiceRequestToolException
     *         if there is any other error
     */
    @Transactional
    public void syncUpRequest(long requestId) throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#syncUpRequest(long requestId)";
        final Logger logger = getLogger();

        // Log entry
        logger.info("Start sync up request: " + requestId);

        Helper.checkPositive(logger, signature, requestId, "requestId");

        User currentUser = ServiceContext.getCurrentUser();

        if (currentUser == null) {
            // We need know which user to synchronize data for
            logger.warn("Current user is not set, can not synchronize.");
            Helper.logExit(logger, signature, null);
            return;
        }

        try {
            List<OperationLog> localLogs = operationLogService.get(Request.class.getSimpleName(), requestId, null, false);

            doSyncUpRequests(localLogs);
        } catch (ServiceRequestToolException e) {
            throw Helper.logException(logger, signature, e);
        }

        // Log Exit
        logger.info("End sync up request: " + requestId);
    }

    /**
     * Do synchronize up requests.
     *
     * @param localLogs
     *         the operation logs from local
     * @throws CloudConnectionException
     *         if it fails to connect to the cloud
     * @throws ServiceRequestToolException
     *         if there is any other error
     */
    private void doSyncUpRequests(List<OperationLog> localLogs) throws ServiceRequestToolException {

        if (localLogs == null || localLogs.size() == 0) {
            getLogger().info("No request operation log found in local to sync up.");
            return;
        }

        for (OperationLog localLog : localLogs) {

            long localRequestId = localLog.getEntityId();
            long cloudRequestId = localLog.getCorrelatedId();

            switch (localLog.getOperation()) {
                case CREATE:
                case UPDATE:
                    Request localRequest = requestService.get(localRequestId);

                    if (localRequest == null) {
                        // Nothing to synchronize
                        getLogger().warn("Local request is null, unable to sync up - " + localLog.getOperation());
                        operationLogService.operationLogSynchronizedUp(localLog);
                        continue;
                    }

                    if (localRequest.getStartRequestData() != null) {
                        uploadAttachments(localRequest.getStartRequestData().getAttachments());
                    }

                    // Copy entity
                    Request cloudRequest = Helper.deepCloneEntity(localRequest);

                    // Zero ids
                    Helper.zeroRequestId(cloudRequest);

                    cloudRequest.setCorrelatedId(localRequestId);
                    Profile approver = cloudRequest.getApprover();
                    if(approver != null){
                        approver.setId(approver.getCorrelatedId());
                    }
                    
                    List<Profile> additionalRecipients = cloudRequest.getAdditionalRecipients();
                    if(additionalRecipients != null){
                        for (int i = 0; i < additionalRecipients.size(); i++) {
                            Profile recipient = additionalRecipients.get(i);
                            recipient.setId(recipient.getCorrelatedId());
                        }
                    }

                    if (cloudRequestId > 0) {
                        cloudRequest.setId(cloudRequestId);
                        // For update
                        updateEntityToCloud(cloudRequest, localLog);
                    } else {
                        // For create
                        createEntityToCloud(cloudRequest, localLog);
                    }

                    break;
                case DELETE:
                    // For delete
                    deleteEntityFromCloud(Request.class, cloudRequestId, localLog);
                    break;
                default:
                    throw new ServiceRequestToolException("Unsupported operation : " + localLog.getOperation());
            }

            getLogger().info("Request is synchronized up, local id: " + localRequestId
                    + ", cloud id: " + localLog.getCorrelatedId() + ", operation: " + localLog.getOperation());
        }
    }

    /**
     * Check if all required fields are initialized properly.
     *
     * @throws ServiceRequestToolConfigurationException
     *         if entityManager/requestService/customerService/profileService/operationLogService is null,
     *         or if attachmentFolder/cloudServiceUrlBase/userIdentifierHeaderName/
     *         firstNameHeaderName/lastNameHeaderName/emailHeaderName/syncOpLogHeaderName is null or empty.
     */
    @PostConstruct
    @Override
    protected void checkInit() {
        super.checkInit();

        Helper.checkState(requestService == null, "'requestService' can't be null.");
        Helper.checkState(customerService == null, "'customerService' can't be null.");
        Helper.checkState(profileService == null, "'profileService' can't be null.");
        Helper.checkState(operationLogService == null, "'operationLogService' can't be null.");

        Helper.checkState(Helper.isStringNullOrEmpty(attachmentFolder), "'attachmentFolder' can't be null/empty.");
        Helper.checkState(Helper.isStringNullOrEmpty(cloudServiceUrlBase), "'cloudServiceUrlBase' can't be null/empty.");
        Helper.checkState(Helper.isStringNullOrEmpty(userIdentifierHeaderName),
                "'userIdentifierHeaderName' can't be null/empty.");
        Helper.checkState(Helper.isStringNullOrEmpty(firstNameHeaderName), "'firstNameHeaderName' can't be null/empty.");
        Helper.checkState(Helper.isStringNullOrEmpty(lastNameHeaderName), "'lastNameHeaderName' can't be null/empty.");
        Helper.checkState(Helper.isStringNullOrEmpty(emailHeaderName), "'emailHeaderName' can't be null/empty.");

        Helper.checkState(Helper.isStringNullOrEmpty(syncOpLogHeaderName), "'syncOpLogHeaderName' can't be null/empty.");
    }

    /**
     * Setter method for property <tt>requestService</tt>.
     *
     * @param requestService
     *         value to be assigned to property requestService
     */
    public void setRequestService(RequestService requestService) {
        this.requestService = requestService;
    }

    /**
     * Setter method for property <tt>customerService</tt>.
     *
     * @param customerService
     *         value to be assigned to property customerService
     */
    public void setCustomerService(CustomerService customerService) {
        this.customerService = customerService;
    }

    /**
     * Setter method for property <tt>profileService</tt>.
     *
     * @param profileService
     *         value to be assigned to property profileService
     */
    public void setProfileService(ProfileService profileService) {
        this.profileService = profileService;
    }

    /**
     * Setter method for property <tt>operationLogService</tt>.
     *
     * @param operationLogService
     *         value to be assigned to property operationLogService
     */
    public void setOperationLogService(OperationLogService operationLogService) {
        this.operationLogService = operationLogService;
    }

    /**
     * Setter method for property <tt>attachmentFolder</tt>.
     *
     * @param attachmentFolder
     *         value to be assigned to property attachmentFolder
     */
    public void setAttachmentFolder(String attachmentFolder) {
        this.attachmentFolder = attachmentFolder;
    }

    /**
     * Setter method for property <tt>cloudServiceUrlBase</tt>.
     *
     * @param cloudServiceUrlBase
     *         value to be assigned to property cloudServiceUrlBase
     */
    public void setCloudServiceUrlBase(String cloudServiceUrlBase) {
        this.cloudServiceUrlBase = cloudServiceUrlBase;
    }

    /**
     * Setter method for property <tt>userIdentifierHeaderName</tt>.
     *
     * @param userIdentifierHeaderName
     *         value to be assigned to property userIdentifierHeaderName
     */
    public void setUserIdentifierHeaderName(String userIdentifierHeaderName) {
        this.userIdentifierHeaderName = userIdentifierHeaderName;
    }

    /**
     * Setter method for property <tt>firstNameHeaderName</tt>.
     *
     * @param firstNameHeaderName
     *         value to be assigned to property firstNameHeaderName
     */
    public void setFirstNameHeaderName(String firstNameHeaderName) {
        this.firstNameHeaderName = firstNameHeaderName;
    }

    /**
     * Setter method for property <tt>lastNameHeaderName</tt>.
     *
     * @param lastNameHeaderName
     *         value to be assigned to property lastNameHeaderName
     */
    public void setLastNameHeaderName(String lastNameHeaderName) {
        this.lastNameHeaderName = lastNameHeaderName;
    }

    /**
     * Setter method for property <tt>emailHeaderName</tt>.
     *
     * @param emailHeaderName
     *         value to be assigned to property emailHeaderName
     */
    public void setEmailHeaderName(String emailHeaderName) {
        this.emailHeaderName = emailHeaderName;
    }

    /**
     * <p>
     * Sets the value to syncOpLogHeaderName field.
     * </p>
     *
     * @param syncOpLogHeaderName
     *         the syncOpLogHeaderName to set
     * @since SRT Phase 4 - ET Assembly 2
     */
    public void setSyncOpLogHeaderName(String syncOpLogHeaderName) {
        this.syncOpLogHeaderName = syncOpLogHeaderName;
    }

    /**
     * <p>Sets the countryHeaderName property.</p>
     *
     * @param countryHeaderName a <code>String</code> providing the value for countryHeaderName property.
     * @since 1.3
     */
    public void setCountryHeaderName(String countryHeaderName) {
        this.countryHeaderName = countryHeaderName;
    }

    /**
     * <p>Sets the jobTitleHeaderName property.</p>
     *
     * @param jobTitleHeaderName a <code>String</code> providing the value for jobTitleHeaderName property.
     * @since 1.3
     */
    public void setJobTitleHeaderName(String jobTitleHeaderName) {
        this.jobTitleHeaderName = jobTitleHeaderName;
    }
}

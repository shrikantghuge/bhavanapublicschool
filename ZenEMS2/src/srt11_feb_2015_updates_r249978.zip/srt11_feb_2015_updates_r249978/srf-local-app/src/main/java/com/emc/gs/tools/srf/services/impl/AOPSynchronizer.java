/*
 * This code is copyright (c) 2014-2015 EMC Corporation.
 */
package com.emc.gs.tools.srf.services.impl;

import javax.annotation.PostConstruct;

import org.apache.log4j.Logger;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.core.annotation.AnnotationUtils;

import com.emc.gs.tools.srf.ServiceRequestToolConfigurationException;
import com.emc.gs.tools.srf.model.Customer;
import com.emc.gs.tools.srf.model.IdentifiableEntity;
import com.emc.gs.tools.srf.model.Profile;
import com.emc.gs.tools.srf.model.Request;
import com.emc.gs.tools.srf.services.CloudConnectionException;
import com.emc.gs.tools.srf.services.ServiceRequestToolException;
import com.emc.gs.tools.srf.services.SyncDown;
import com.emc.gs.tools.srf.services.SyncUp;
import com.emc.gs.tools.srf.services.SynchronizationService;


/**
 * <p>
 * This class is the local app side AOP synchronizer.
 * </p>
 *
 * <p>
 * <strong>Thread safety</strong>: This class is effectively thread safe after configuration, the configuration is done
 * in a thread safe manner.
 * </p>
 *
 * <p>
 * Version 1.1 Change notes (SRT 1.1 Approval Process Assembly):
 *   <ol>
 *     <li>Modified syncDown method, added call to sync down all profiles when a request is synced down.</li>
 *   </ol>
 * </p>
 *
 * @author TCSASSEMBLER
 * @version 1.1
 * @since SRT Phase 4 - ET Assembly 2
 */
@Aspect
public class AOPSynchronizer extends BaseLoggerService {

    /**
     * <p>
     * Represents the class name.
     * </p>
     */
    private static final String CLASSNAME = AOPSynchronizer.class.getName();

    /**
     * This is synchronization service. Required.
     */
    private SynchronizationService synchronizationService;

    /**
     * Empty constructor.
     */
    public AOPSynchronizer() {
    }

    /**
     * <p>
     * Synchronize down entity.
     * </p>
     *
     * @param joinPoint
     *            The join point
     * @throws IllegalArgumentException
     *             if given join point is null
     * @throws ServiceRequestToolException
     *             if there is any error
     */
    @Before("@annotation(com.emc.gs.tools.srf.services.SyncDown)")
    public void syncDown(JoinPoint joinPoint) throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#syncDown(JoinPoint joinPoint)";
        Logger logger = getLogger();

        // Log entry
        Helper.logEntrance(logger, signature, new String[]{"joinPoint"}, new Object[]{joinPoint});
        Helper.checkNull(logger, signature, joinPoint, "joinPoint");

        MethodSignature met = (MethodSignature) joinPoint.getSignature();
        Object[] arguments = joinPoint.getArgs();

        SyncDown syncDownAnno = AnnotationUtils.findAnnotation(met.getMethod(), SyncDown.class);

        String entityType = syncDownAnno.entityType();
        boolean downAll = syncDownAnno.syncDownAll();

        try {
            if (Customer.class.getSimpleName().equals(entityType)) {
                if (downAll) {
                    synchronizationService.syncDownAllCustomers();
                } else {
                    long customerId = (Long) arguments[0];
                    synchronizationService.syncDownCustomer(customerId);
                }
            } else if (Request.class.getSimpleName().equals(entityType)) {
                // Also sync down profiles to update the non-submitter/approver roles
                synchronizationService.syncDownAllProfiles();
                if (downAll) {
                    synchronizationService.syncDownAllRequests();
                } else {
                    long requestId = (Long) arguments[0];
                    synchronizationService.syncDownRequest(requestId);
                }
            } else if (Profile.class.getSimpleName().equals(entityType)) {
                synchronizationService.syncDownDefaultProfile();
            }
        } catch (CloudConnectionException cce) {
            // Log and ignore
            logger.error("Failed to connect to cloud when synchronize down " + entityType, cce);
        }

        // Log exit
        Helper.logExit(logger, signature, null);
    }

    /**
     * <p>
     * Synchronize up entity.
     * </p>
     * 
     * @param joinPoint
     *            The join point
     * @param retVal
     *            The method return value
     * @throws IllegalArgumentException
     *             if given join point is null
     * @throws ServiceRequestToolException
     *             if there is any error
     */
    @AfterReturning(pointcut = "@annotation(com.emc.gs.tools.srf.services.SyncUp)", returning = "retVal")
    public void syncUp(JoinPoint joinPoint, Object retVal) throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#syncUp(JoinPoint joinPoint)";
        Logger logger = getLogger();

        // Log entry
        Helper.logEntrance(logger, signature, new String[]{"joinPoint"}, new Object[]{joinPoint});
        Helper.checkNull(logger, signature, joinPoint, "joinPoint");

        MethodSignature met = (MethodSignature) joinPoint.getSignature();
        Object[] arguments = joinPoint.getArgs();

        SyncUp syncUpAnno = AnnotationUtils.findAnnotation(met.getMethod(), SyncUp.class);

        String entityType = syncUpAnno.entityType();

        long entityId = 0;
        if (retVal != null) {
            entityId = ((IdentifiableEntity) retVal).getId();
        } else {
            entityId = (Long) arguments[0];
        }

        try {
            if (Customer.class.getSimpleName().equals(entityType)) {
                synchronizationService.syncUpCustomer(entityId);
            } else if (Request.class.getSimpleName().equals(entityType)) {
                synchronizationService.syncUpRequest(entityId);
            } else if (Profile.class.getSimpleName().equals(entityType)) {
                synchronizationService.syncUpProfile();
            }
        } catch (CloudConnectionException cce) {
            // Log and ignore
            logger.error("Failed to connect to cloud when synchronize up " + entityType, cce);
        }

        // Log exit
        Helper.logExit(logger, signature, null);
    }

    /**
     * This method checks whether the instance of the class was initialized properly.
     *
     * @throws ServiceRequestToolConfigurationException
     *             if synchronizationService is null
     */
    @PostConstruct
    protected void checkInit() {
        Helper.checkState(synchronizationService == null, "'synchronizationService' can't be null.");
    }

    /**
     * Setter method for property <tt>synchronizationService</tt>.
     *
     * @param synchronizationService
     *            value to be assigned to property synchronizationService
     */
    public void setSynchronizationService(SynchronizationService synchronizationService) {
        this.synchronizationService = synchronizationService;
    }
}

/*
 * This code is copyright (c) 2015 EMC Corporation.
 */
package com.emc.gs.tools.srf.services.impl;

import com.emc.gs.tools.srf.services.ServiceRequestToolException;
import com.emc.gs.tools.srf.services.UserAdminService;

/**
 * <p>
 * This class is the local side implementation of the UserAdminService.
 * </p>
 *
 * <p>
 * <strong>Thread safety</strong>: This class is effectively thread safe after
 * configuration, the configuration is done in a thread safe manner.
 * </p>
 *
 * @author TCSASSEMBLER
 * @version 1.0
 * @since SRT 1.1 Approval Process Assembly
 */
public class LocalUserAdminServiceImpl implements UserAdminService {

    /**
     * Default constructor.
     */
    public LocalUserAdminServiceImpl() {
        // Empty
    }

    /**
     * Decides if a user has user management permission.
     * Local app does not implement user management, therefore this method always returns false.
     *
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     * @param userIdentifier
     *            the user's identifier
     * @return true if the user has management user permission; false otherwise
     */
    @Override
    public boolean hasUserManagementPermission(String userIdentifier) throws ServiceRequestToolException {
        return false;
    }
}

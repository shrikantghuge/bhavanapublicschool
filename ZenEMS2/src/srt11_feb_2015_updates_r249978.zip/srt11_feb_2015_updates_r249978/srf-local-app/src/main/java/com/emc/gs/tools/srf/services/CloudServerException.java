/*
 * This code is copyright (c) 2014 EMC Corporation.
 */
package com.emc.gs.tools.srf.services;


/**
 * <p>
 * This exception is thrown if the cloud server returns status code rather than 200.
 * </p>
 *
 * <p>
 * <strong>Thread safety</strong>: exception class is not thread safety.
 * </p>
 *
 * @author TCSASSEMBLER
 * @version 1.0
 * @since SRT Phase 4 - ET Assembly 2
 */
public class CloudServerException extends ServiceRequestToolException {

    /**
     * The serial version UID.
     */
    private static final long serialVersionUID = -3794157913758805799L;

    /**
     * The status code returned from cloud server.
     */
    private final int statusCode;

    /**
     * Creates the exception with the provided message and status code.
     *
     * @param statusCode
     *            the status code.
     * @param message
     *            the error message.
     */
    public CloudServerException(int statusCode, String message) {
        super(message);
        this.statusCode = statusCode;
    }

    /**
     * Getter method for property <tt>statusCode</tt>.
     *
     * @return property value of statusCode
     */
    public int getStatusCode() {
        return statusCode;
    }

}

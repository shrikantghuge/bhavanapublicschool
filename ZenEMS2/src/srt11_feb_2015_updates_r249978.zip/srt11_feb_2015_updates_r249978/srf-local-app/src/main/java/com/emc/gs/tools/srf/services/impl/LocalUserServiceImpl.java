/*
 * This code is copyright (c) 2014-2015 EMC Corporation.
 */
package com.emc.gs.tools.srf.services.impl;

import java.util.List;

import javax.annotation.PostConstruct;
import javax.persistence.PersistenceException;
import javax.persistence.TypedQuery;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.transaction.annotation.Transactional;

import com.emc.gs.tools.srf.AuthorizationException;
import com.emc.gs.tools.srf.ServiceRequestToolConfigurationException;
import com.emc.gs.tools.srf.model.ServiceContext;
import com.emc.gs.tools.srf.model.User;
import com.emc.gs.tools.srf.services.CloudConnectionException;
import com.emc.gs.tools.srf.services.ProfileService;
import com.emc.gs.tools.srf.services.ServiceRequestToolException;
import com.emc.gs.tools.srf.services.SynchronizationService;
import com.emc.gs.tools.srf.services.UserService;

/**
 * <p>
 * This class is the local app side implementation of the UserService.
 * </p>
 *
 * <p>
 * <strong>Thread safety</strong>: This class is effectively thread safe after configuration, the configuration is done
 * in a thread safe manner.
 * </p>
 *
 * <p>
 * Version 1.1 Change notes (SRT 1.1 Approval Process Assembly):
 *   <ol>
 *     <li>Changed syncDownProfile method name to syncDownDefaultProfile.</li>
 *   </ol>
 * </p>
 *
 * @author zsudraco, MonicaMuranyi
 * @version 1.1
 * @since SRT Phase 4 - ET Assembly 2
 */
public class LocalUserServiceImpl extends BaseUserService implements UserService {

    /**
     * This is synchronization service. Required.
     */
    private SynchronizationService synchronizationService;

    /**
     * This is profile service. Required.
     */
    private ProfileService profileService;

    /**
     * Empty constructor.
     */
    public LocalUserServiceImpl() {
    }

    /**
     * Gets matched user.
     * 
     * @param user
     *            the user to be authenticated
     * @return the matched user
     * @throws ServiceRequestToolException 
     * @throws AuthorizationException
     *             if current user does not match given user
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     */
    @Override
    protected User getMatchedUser(User user) throws ServiceRequestToolException {
        try {
            // Local app has only one user
            TypedQuery<User> query = getEntityManager().createQuery("select u from User u order by id asc", User.class)
                    .setMaxResults(1);
            List<User> users = query.getResultList();

            User currentUser = users != null && users.size() > 0 ? users.get(0) : null;

            // User must have same user identifier
            if (currentUser != null && !StringUtils.equals(user.getUserIdentifier(), currentUser.getUserIdentifier())) {
                throw new AuthorizationException("Only same user can access the application.");
            }

            return currentUser;
        } catch (IllegalStateException e) {
            throw new ServiceRequestToolException(
                    "The entity manager has been closed.", e);
        } catch (PersistenceException e) {
            throw new ServiceRequestToolException(
                    "An error has occurred while accessing the persistence.", e);
        }
    }

    /**
     * Authenticate given user, and perform synchronization.
     * 
     * @param user
     *            the user to be authenticated
     * @return the authenticated user
     * @throws IllegalArgumentException
     *             if given user is null, or if its userIdentifier is null or empty
     * @throws AuthorizationException
     *             if given user is not authorized
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     */
    @Override
    @Transactional(rollbackFor = {AuthorizationException.class, ServiceRequestToolException.class})
    public User authenticate(User user) throws ServiceRequestToolException {

        // Delegate to super authentication
        user = super.authenticate(user);

        // User successfully login, perform sync here, so that user can see latest data after login
        // first perform sync up, only if sync up is successful then perform sync down
        // CloudConnectionException should be logged and then ignored
        Logger logger = getLogger();
        logger.info("Start synchronize on user login.");

        // Set current user, SynchronizationService needs the current user being present
        ServiceContext.setCurrentUser(user);

        try {
            synchronizationService.syncUpProfile();
            synchronizationService.syncUpAllCustomers();
            synchronizationService.syncUpAllRequests();

            synchronizationService.syncDownDefaultProfile();
            // After sync down profile, if profile is still null, no need sync down customer/request
            if (profileService.getDefaultProfile() != null) {
                synchronizationService.syncDownAllCustomers();
                synchronizationService.syncDownAllProfiles();
                synchronizationService.syncDownAllRequests();
            }
        } catch (CloudConnectionException cce) {
            // Log and ignore
            logger.error("Failed to connect to cloud for synchronization on user login.", cce);
        } finally {
            // Always clear context here, let ServiceContextInterceptor play its part
            ServiceContext.clear();
        }

        logger.info("End synchronize on user login.");

        return user;
    }

    /**
     * This method checks whether the instance of the class was initialized properly.
     *
     * @throws ServiceRequestToolConfigurationException
     *             if entityManager/synchronizationService/profileService is null
     */
    @Override
    @PostConstruct
    protected void checkInit() {
        super.checkInit();
        Helper.checkState(synchronizationService == null, "'synchronizationService' can't be null.");
        Helper.checkState(profileService == null, "'profileService' can't be null.");
    }

    /**
     * Setter method for property <tt>synchronizationService</tt>.
     *
     * @param synchronizationService
     *            value to be assigned to property synchronizationService
     */
    public void setSynchronizationService(SynchronizationService synchronizationService) {
        this.synchronizationService = synchronizationService;
    }

    /**
     * Setter method for property <tt>profileService</tt>.
     *
     * @param profileService
     *            value to be assigned to property profileService
     */
    public void setProfileService(ProfileService profileService) {
        this.profileService = profileService;
    }
}

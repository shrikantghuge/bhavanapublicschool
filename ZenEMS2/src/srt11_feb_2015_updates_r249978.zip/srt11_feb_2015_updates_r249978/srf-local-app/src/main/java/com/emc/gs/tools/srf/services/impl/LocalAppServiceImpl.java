/*
 * This code is copyright (c) 2014 EMC Corporation.
 */
package com.emc.gs.tools.srf.services.impl;

import java.util.List;
import java.util.UUID;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.TransactionCallbackWithoutResult;
import org.springframework.transaction.support.TransactionTemplate;

import com.emc.gs.tools.srf.ServiceRequestToolConfigurationException;
import com.emc.gs.tools.srf.model.AppIdentifier;
import com.emc.gs.tools.srf.services.AppService;

/**
 * <p>
 * TThis is the local side implementation of AppService.
 * </p>
 *
 * <p>
 * <strong>Thread safety</strong>: This class is immutable after initialization and effectively thread safe.
 * </p>
 *
 * @author TCSASSEMBLER
 * @version 1.0
 * @since SRT Phase 4 - ET Assembly 2
 */
public class LocalAppServiceImpl extends BasePersistenceService implements AppService {

    /**
     * The transaction manager injected by Spring.
     */
    @Autowired
    private JpaTransactionManager transactionManager;

    /**
     * The application identifier, initialized in init() method and will not change afterwards.
     */
    private String appIdentifier;

    /**
     * <p>A <code>boolean</code> providing the value for standalone property.</p>
     * 
     * @since 1.1
     */
    private boolean standaloneMode;


    /**
     * Empty constructor.
     */
    public LocalAppServiceImpl() {
    }

    /**
     * Local app, return false always.
     * 
     * @return false always
     */
    public boolean isCloudApp() {
        return false;
    }

    /**
     * Gets application identifier. Different local apps will have different identifier, even for a single user.
     * 
     * @return application identifier.
     */
    public String getAppIdentifier() {
        return appIdentifier;
    }

    /**
     * <p>Gets the standalone property.</p>
     *
     * @return a <code>boolean</code> providing the value for standalone property.
     * @since 1.1
     */
    public boolean isStandaloneMode() {
        return this.standaloneMode;
    }

    /**
     * <p>Sets the standalone property.</p>
     *
     * @param standaloneMode a <code>boolean</code> providing the value for standalone proeprty.
     * @since 1.1
     */
    public void setStandaloneMode(boolean standaloneMode) {
        this.standaloneMode = standaloneMode;
    }

    /**
     * Initialize application identifier on application startup.
     *
     * @throws ServiceRequestToolConfigurationException
     *             if entityManager/transactionManager is null
     */
    @PostConstruct
    protected void init() {
        super.checkInit();
        Helper.checkState(transactionManager == null, "'transactionManager' can't be null.");

        new TransactionTemplate(transactionManager).execute(new TransactionCallbackWithoutResult() {

            @Override
            protected void doInTransactionWithoutResult(TransactionStatus status) {
                List<AppIdentifier> ids = getEntityManager()
                        .createQuery("select e from AppIdentifier e", AppIdentifier.class).setMaxResults(1)
                        .getResultList();

                AppIdentifier id = ids == null || ids.size() == 0 ? null : ids.get(0);

                if (id == null) {
                    id = new AppIdentifier();
                    id.setIdentifier("local-" + UUID.randomUUID().toString());
                    getEntityManager().persist(id);
                }
                appIdentifier = id.getIdentifier();
            }
        });
    }
}

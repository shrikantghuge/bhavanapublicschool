/*
 * This code is copyright (c) 2014 EMC Corporation.
 */
package com.emc.gs.tools.srf.services.impl;

import javax.annotation.PostConstruct;

import org.apache.log4j.Logger;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.JavaMailSenderImpl;

import com.emc.gs.tools.srf.ServiceRequestToolConfigurationException;
import com.emc.gs.tools.srf.model.EmailOptions;
import com.emc.gs.tools.srf.model.Profile;
import com.emc.gs.tools.srf.services.MailSenderFactory;

/**
 * <p>
 * This class is the local app side implementation of the MailSenderFactory.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is effectively thread safe after configuration, the configuration is done
 * in a thread safe manner.
 * </p>
 *
 * <p>
 * Version 1.1 Change notes:
 *   <ol>
 *     <li>Removed <code>testSubmitEmailAddress</code> property from profile.</li>
 *     <li>Removed <code>emailOptions</code> property from profile.</li>
 *   </ol>
 * </p>
 * 
 * @author TCSASSEMBLER
 * @version 1.1
 * @since SRT Phase 4 - ET Assembly 2
 */
public class LocalMailSenderFactoryImpl extends BaseLoggerService implements MailSenderFactory {

    /**
     * <p>
     * Represents the class name.
     * </p>
     */
    private static final String CLASSNAME = LocalMailSenderFactoryImpl.class.getName();

    /**
     * Represents the SMTP host. It is modified by setter. It is injected by Spring. It can not be
     * null after injected.
     */
    private String smtpHost;

    /**
     * Represents the SMTP port. It is modified by setter. It is injected by Spring. It can not be
     * null after injected.
     */
    private int smtpPort;

    /**
     * Empty constructor.
     */
    public LocalMailSenderFactoryImpl() {
    }

    /**
     * Creates a mail sender.
     * 
     * @param profile
     *            The user profile
     * @throws IllegalArgumentException
     *             if profile is null
     * @return mail sender
     */
    public JavaMailSender createJavaMailSender(Profile profile) {
        final String signature = CLASSNAME + "#createJavaMailSender(Profile profile)";
        Logger logger = getLogger();

        // Log entry
        Helper.logEntrance(logger, signature, new String[] {"profile"}, new Object[] {profile});

        // Check profile
        Helper.checkNull(logger, signature, profile, "profile");

        JavaMailSenderImpl mailSender = new JavaMailSenderImpl();
        mailSender.setHost(smtpHost);
        mailSender.setPort(smtpPort);

        // Log exit
        Helper.logExit(logger, signature, new Object[]{mailSender});

        return mailSender;
    }

    /**
     * This method checks whether the instance of the class was initialized properly.
     * 
     * @throws ServiceRequestToolConfigurationException
     *             if smtpHost is null/empty, smtpPort is negative or zero
     */
    @PostConstruct
    protected void checkInit() {
        Helper.checkState(Helper.isStringNullOrEmpty(smtpHost), "'smtpHost' can't be null/empty.");
        Helper.checkState(smtpPort <= 0, "'smtpPort' can't be negative or zero.");
    }

    /**
     * Setter method for property <tt>smtpHost</tt>.
     * 
     * @param smtpHost
     *            value to be assigned to property smtpHost
     */
    public void setSmtpHost(String smtpHost) {
        this.smtpHost = smtpHost;
    }

    /**
     * Setter method for property <tt>smtpPort</tt>.
     * 
     * @param smtpPort
     *            value to be assigned to property smtpPort
     */
    public void setSmtpPort(int smtpPort) {
        this.smtpPort = smtpPort;
    }
}

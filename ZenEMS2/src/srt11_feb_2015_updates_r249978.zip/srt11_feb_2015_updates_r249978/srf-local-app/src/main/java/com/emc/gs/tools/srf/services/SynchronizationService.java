/*
 * This code is copyright (c) 2014-2015 EMC Corporation.
 */
package com.emc.gs.tools.srf.services;


/**
 * <p>
 * This service defines methods to manage synchronization.
 * </p>
 *
 * <p>
 * <strong>Thread safety</strong>: Implementations should be effective thread safe.
 * </p>
 *
 * <p>
 * Version 1.1 Change notes:
 *   <ol>
 *     <li>Added syncDownAllProfiles method.</li>
 *     <li>Added syncUpAllProfiles method.</li>
 *   </ol>
 * </p>
 *
 * @author zsudraco, MonicaMuranyi
 * @version 1.1
 * @since SRT Phase 4 - ET Assembly 2
 */
public interface SynchronizationService {

    /**
     * Synchronize all cloud request data down to local storage.
     *
     * @throws CloudConnectionException
     *             if it fails to connect to the cloud
     * @throws ServiceRequestToolException
     *             if there is any other error
     */
    public void syncDownAllRequests() throws ServiceRequestToolException;

    /**
     * Synchronize all local pending updates of requests up to cloud.
     *
     * @throws CloudConnectionException
     *             if it fails to connect to the cloud
     * @throws ServiceRequestToolException
     *             if there is any other error
     */
    public void syncUpAllRequests() throws ServiceRequestToolException;

    /**
     * Synchronize the request of the given id from cloud down to local storage.
     *
     * @param requestId
     *            the request id
     * @throws IllegalArgumentException
     *             if the given id is not positive
     * @throws CloudConnectionException
     *             if it fails to connect to the cloud
     * @throws ServiceRequestToolException
     *             if there is any other error
     */
    public void syncDownRequest(long requestId) throws ServiceRequestToolException;

    /**
     * Synchronize the request of the given id from local storage up to cloud.
     *
     * @param requestId
     *            the request id
     * @throws IllegalArgumentException
     *             if the given id is not positive
     * @throws CloudConnectionException
     *             if it fails to connect to the cloud
     * @throws ServiceRequestToolException
     *             if there is any other error
     */
    public void syncUpRequest(long requestId) throws ServiceRequestToolException;

    /**
     * Synchronize all cloud customer data down to local storage.
     *
     * @throws CloudConnectionException
     *             if it fails to connect to the cloud
     * @throws ServiceRequestToolException
     *             if there is any other error
     */
    public void syncDownAllCustomers() throws ServiceRequestToolException;

    /**
     * Synchronize all local pending updates of customers up to cloud.
     *
     * @throws CloudConnectionException
     *             if it fails to connect to the cloud
     * @throws ServiceRequestToolException
     *             if there is any other error
     */
    public void syncUpAllCustomers() throws ServiceRequestToolException;

    /**
     * Synchronize the customer of the given id from cloud down to local storage.
     *
     * @param customerId
     *            the customer id
     * @throws IllegalArgumentException
     *             if the given id is not positive
     * @throws CloudConnectionException
     *             if it fails to connect to the cloud
     * @throws ServiceRequestToolException
     *             if there is any other error
     */
    public void syncDownCustomer(long customerId) throws ServiceRequestToolException;

    /**
     * Synchronize the customer of the given id from local storage up to cloud.
     *
     * @param customerId
     *            the customer id
     * @throws IllegalArgumentException
     *             if the given id is not positive
     * @throws CloudConnectionException
     *             if it fails to connect to the cloud
     * @throws ServiceRequestToolException
     *             if there is any other error
     */
    public void syncUpCustomer(long customerId) throws ServiceRequestToolException;

    /**
     * Synchronize cloud default profile data down to local storage.
     * 
     * @throws CloudConnectionException
     *             if it fails to connect to the cloud
     * @throws ServiceRequestToolException
     *             if there is any other error
     */
    public void syncDownDefaultProfile() throws ServiceRequestToolException;

    /**
     * Synchronize local pending update of profile up to cloud.
     *
     * @throws CloudConnectionException
     *             if it fails to connect to the cloud
     * @throws ServiceRequestToolException
     *             if there is any other error
     */
    public void syncUpProfile() throws ServiceRequestToolException;

    /**
     * Synchronize all cloud profiles down to local storage.
     *
     * @throws CloudConnectionException
     *             if it fails to connect to the cloud
     * @throws ServiceRequestToolException
     *             if there is any other error
     * @since 1.1
     */
    public void syncDownAllProfiles() throws ServiceRequestToolException;

    /**
     * Synchronize all local pending updates of profiles up to cloud.
     *
     * @throws CloudConnectionException
     *             if it fails to connect to the cloud
     * @throws ServiceRequestToolException
     *             if there is any other error
     */
    public void syncUpAllProfiles() throws ServiceRequestToolException;
}

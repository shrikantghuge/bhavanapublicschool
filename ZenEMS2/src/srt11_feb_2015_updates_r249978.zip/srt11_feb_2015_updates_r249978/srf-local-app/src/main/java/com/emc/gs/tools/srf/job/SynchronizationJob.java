/*
 * This code is copyright (c) 2014-2015 EMC Corporation.
 */
package com.emc.gs.tools.srf.job;

import com.emc.gs.tools.srf.model.ServiceContext;
import com.emc.gs.tools.srf.model.User;
import com.emc.gs.tools.srf.services.CloudConnectionException;
import com.emc.gs.tools.srf.services.ServiceRequestToolException;
import com.emc.gs.tools.srf.services.SynchronizationService;
import com.emc.gs.tools.srf.services.impl.BasePersistenceService;
import com.emc.gs.tools.srf.services.impl.Helper;

import org.apache.log4j.Logger;

import javax.annotation.PostConstruct;
import javax.persistence.TypedQuery;

import java.util.List;

/**
 * <p>
 * This is a bean job to be scheduled using Spring's scheduling functionalities.
 * We use the 'scheduled-tasks' element to schedule running the syncUp and syncDown methods periodically.
 * </p>
 *
 * <p>
 * <strong>Thread safety</strong>: This class is effectively thread safe after configuration, the configuration is done
 * in a thread safe manner.
 * </p>
 *
 * <p>
 * Version 1.1 Change notes (SRT 1.1 Approval Process Assembly):
 *   <ol>
 *     <li>Modified syncDown method, added call to sync down all profiles.</li>
 *   </ol>
 * </p>
 *
 * @author zsudraco, MonicaMuranyi
 * @version 1.1
 */
public class SynchronizationJob extends BasePersistenceService {
    /**
     * <p>
     * Represents the class name.
     * </p>
     */
    private static final String CLASSNAME = SynchronizationJob.class.getName();

    /**
     * This is synchronization service. Required.
     */
    private SynchronizationService synchronizationService;

    /**
     * Gets the only user in the local app and sets it to ServiceContext.
     *
     * @throws javax.persistence.PersistenceException
     *         if unable to fetch the user from the persistence layer
     */
    private void setCurrentUser() {

        // Local app has only one user
        TypedQuery<User> query = getEntityManager().createQuery("select u from User u order by id asc", User.class)
                .setMaxResults(1);
        List<User> users = query.getResultList();

        User currentUser = users != null && users.size() > 0 ? users.get(0) : null;

        ServiceContext.setCurrentUser(currentUser);
    }

    /**
     * Logs a step with the signature as the prefix.
     *
     * @param signature
     *         the signature of the step
     * @param step
     *         the step message
     */
    private void logStep(String signature, String step) {
        final Logger logger = getLogger();

        logger.info(signature + ": " + step);
    }

    /**
     * Synchronize all the data up to the cloud
     *
     * If CloudConnectionException is thrown, it will be logged and then ignored.
     *
     * @throws ServiceRequestToolException
     *         if there is any other error
     */
    public void syncUp() throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#syncUp()";

        // Log entry
        logStep(signature, "Start syncUp job.");

        try {

            logStep(signature, "setCurrentUser");
            setCurrentUser();

            logStep(signature, "syncUpAllRequests");
            synchronizationService.syncUpAllRequests();

            logStep(signature, "syncUpAllCustomers");
            synchronizationService.syncUpAllCustomers();

            logStep(signature, "syncUpProfile");
            synchronizationService.syncUpProfile();

        } catch (CloudConnectionException cce) {
            // Log and ignore
            getLogger().error("Failed to connect to cloud for synchronization in the SynchronizationJob.", cce);
        } catch(ServiceRequestToolException ex) {
            throw Helper.logException(getLogger(), signature, ex);
        } finally {
            ServiceContext.clear();
        }

        // Log Exit
        logStep(signature, "End syncUp job.");
    }

    /**
     * Synchronize all the data down from the cloud.
     *
     * If CloudConnectionException is thrown, it will be logged and then ignored.
     *
     * @throws ServiceRequestToolException
     *         if there is any other error
     */
    public void syncDown() throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#syncDown()";

        // Log entry
        logStep(signature, "Start syncDown job.");

        try {
            logStep(signature, "setCurrentUser");
            setCurrentUser();

            logStep(signature, "syncDownAllProfiles");
            synchronizationService.syncDownAllProfiles();
            
            logStep(signature, "syncDownAllRequests");
            synchronizationService.syncDownAllRequests();

            logStep(signature, "syncDownAllCustomers");
            synchronizationService.syncDownAllCustomers();

        } catch (CloudConnectionException cce) {
            // Log and ignore
            getLogger().error("Failed to connect to cloud for synchronization in the SynchronizationJob.", cce);
        } catch(ServiceRequestToolException ex) {
            throw Helper.logException(getLogger(), signature, ex);
        } finally {
            ServiceContext.clear();
        }

        // Log Exit
        logStep(signature, "End syncDown job.");
    }

    /**
     * This method checks whether the instance of the class was initialized properly.
     *
     * @throws com.emc.gs.tools.srf.ServiceRequestToolConfigurationException
     *         if synchronizationService is null, or if entityManager is null
     */
    @PostConstruct
    protected void checkInit() {
        super.checkInit();
        Helper.checkState(synchronizationService == null, "'synchronizationService' can't be null.");
    }

    /**
     * Setter method for property <tt>synchronizationService</tt>.
     *
     * @param synchronizationService
     *         value to be assigned to property synchronizationService
     */
    public void setSynchronizationService(SynchronizationService synchronizationService) {
        this.synchronizationService = synchronizationService;
    }
}

DELETE FROM request;
DELETE FROM startrequestdata_attachments;
DELETE FROM startrequestdata;
DELETE FROM customer_customerworksite;
DELETE FROM customer;
DELETE FROM customerworksite;
DELETE FROM profile;
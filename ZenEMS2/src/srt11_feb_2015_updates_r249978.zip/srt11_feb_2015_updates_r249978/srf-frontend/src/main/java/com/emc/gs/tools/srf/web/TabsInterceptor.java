/*
 * This code is copyright (c) 2014 EMC Corporation
 */
package com.emc.gs.tools.srf.web;

import javax.annotation.PostConstruct;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;
import org.springframework.web.servlet.view.RedirectView;

import com.emc.gs.tools.srf.ServiceRequestToolConfigurationException;
import com.emc.gs.tools.srf.services.EnabledTabs;
import com.emc.gs.tools.srf.services.impl.Helper;

/**
 * <p>
 * Interceptor used to set enabled tabs.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is effectively thread safe after configuration, the configuration is done
 * in a thread safe manner.
 * </p>
 * 
 * @author TCSASSEMBLER
 * @version 1.0
 * @since SRT Phase 3-3 - Isilon and Residency Tabs Assembly
 */
public class TabsInterceptor extends HandlerInterceptorAdapter {

    /**
     * Represents the tabs enabled. It is modified by setter. It is injected by Spring. It can not be null or empty
     * after injected.
     */
    private EnabledTabs enabledTabs;

    /**
     * <p>
     * The default constructor.
     * </p>
     */
    public TabsInterceptor() {
    }

    /**
     * Set enabled tabs in model. It will be rendered in parent.jsp and used in javascript to
     * enable/disable the tabs.
     * 
     * @param request
     *            the {@link HttpServletRequest} instance
     * @param response
     *            the {@link HttpServletResponse} instance
     * @param modelAndView
     *            the model and view object
     * @param handler
     *            the handler object
     */
    public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler,
            ModelAndView modelAndView) {
        // ModelAndView is null for AJAX request
        // For redirect don't need set model value
        if (modelAndView != null
                && ((modelAndView.getViewName() != null && !modelAndView.getViewName().startsWith("redirect:"))
                    || (modelAndView.getView() != null && !(modelAndView.getView() instanceof RedirectView)))) {

            modelAndView.addObject("enabledTabs", enabledTabs);
        }
    }

    /**
     * This method checks whether the instance of the class was initialized properly.
     * 
     * @throws ServiceRequestToolConfigurationException
     *             if enabledTabs is null
     */
    @PostConstruct
    protected void checkInit() {
        Helper.checkState(enabledTabs == null, "'enabledTabs' can't be null.");
    }

    /**
     * Setter method for property <tt>enabledTabs</tt>.
     * 
     * @param enabledTabs
     *            value to be assigned to property enabledTabs
     */
    public void setEnabledTabs(EnabledTabs enabledTabs) {
        this.enabledTabs = enabledTabs;
    }

}

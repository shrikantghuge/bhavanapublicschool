/*
 * This code is copyright (c) 2013 - 2014 EMC Corporation.
 */
package com.emc.gs.tools.srf.web;

import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.hibernate3.Hibernate3Module;

/**
 * <p>
 * This class use to disable FAIL_ON_EMPTY_BEANS for json converter.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is effectively thread safe.
 * </p>
 *
 * <p>
 * <strong>Changes V1.1:</strong>
 * <strong>SRT Release Assembly - BC Tab</strong>
 * <ul>
 * <li>Change to use Jackson2 and Hibernate3Module</li>
 * </ul>
 * </p>
 *
 * @author faeton, TCSASSEMBLER
 * @version 1.1
 */
@SuppressWarnings("serial")
public class HibernateObjectMapper extends ObjectMapper {
    /**
     * The constructor.
     */
    public HibernateObjectMapper() {
        Hibernate3Module hbm = new Hibernate3Module();
        hbm.enable(Hibernate3Module.Feature.FORCE_LAZY_LOADING);
        this.registerModule(hbm);

        this.disable(SerializationFeature.FAIL_ON_EMPTY_BEANS);
        this.setSerializationInclusion(Include.NON_NULL);
    }
}

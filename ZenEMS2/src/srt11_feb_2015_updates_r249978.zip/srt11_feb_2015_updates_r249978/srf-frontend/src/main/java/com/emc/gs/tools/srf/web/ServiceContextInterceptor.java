/*
 * This code is copyright (c) 2014 EMC Corporation.
 */
package com.emc.gs.tools.srf.web;

import com.emc.gs.tools.srf.ServiceRequestToolConfigurationException;
import com.emc.gs.tools.srf.model.OperationLog;
import com.emc.gs.tools.srf.model.ServiceContext;
import com.emc.gs.tools.srf.model.User;
import com.emc.gs.tools.srf.services.AppService;
import com.emc.gs.tools.srf.services.ServiceRequestToolException;
import com.emc.gs.tools.srf.services.impl.Helper;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;
import org.springframework.web.servlet.view.RedirectView;

import javax.annotation.PostConstruct;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * <p>
 * The interceptor to handle ServiceContext initialization/cleanup.
 * </p>
 *
 * <p>
 * <strong>Thread safety</strong>: This class is effectively thread safe after configuration, the configuration is done
 * in a thread safe manner.
 * </p>
 *
 * <p>
 * <strong>Changes V1.1:</strong>
 * <strong>SRT Phase 4 - ET Assembly 2</strong>
 * <ul>
 * <li>Add initialization/cleanup of synchronization flag.</li>
 * </ul>
 * </p>
 *
 * <p>
 * <strong>Changes V1.2:</strong>
 * <strong>SRT Phase 4 - ET Assembly 3</strong>
 * <ul>
 * <li>Make sure ServiceContext.clear() is invoked for exception as well.</li>
 * </ul>
 * </p>
 *
 * @author zsudraco, TCSASSEMBLER
 * @version 1.2
 */
public class ServiceContextInterceptor extends HandlerInterceptorAdapter {

    /**
     * <p>
     * Represents the class name.
     * </p>
     */
    private static final String CLASSNAME = ServiceContextInterceptor.class.getName();

    /**
     * Represents the userSessionAttributeName. It is modified by
     * setter. It is injected by Spring. It can not be null after injected.
     */
    private String userSessionAttributeName = "user";

    /**
     * Represents the syncOpLogHeaderName. It is modified by
     * setter. It is injected by Spring. It can not be null after injected.
     * @since SRT Phase 4 - ET Assembly 2
     */
    private String syncOpLogHeaderName;

    /**
     * Represents the appService. It is modified by
     * setter. It is injected by Spring. It can not be null after injected.
     * @since SRT Phase 4 - ET Assembly 2
     */
    private AppService appService;

    /**
     * This is the logger used for logging. It is initialized in constructor and never changed afterwards. It can not be
     * null.
     */
    private final Logger logger;

    /**
     * Default constructor.
     */
    public ServiceContextInterceptor() {
        this.logger = Logger.getLogger(this.getClass());
    }

    /**
     * This method checks whether the instance of the class was initialized properly.
     *
     * @throws ServiceRequestToolConfigurationException if appService is null, or if
     *             userSessionAttributeName/syncOpLogHeaderName is null or empty
     */
    @PostConstruct
    protected void checkInit() {
        Helper.checkState(Helper.isStringNullOrEmpty(userSessionAttributeName),
                "'userSessionAttributeName' can't be null/empty.");
        Helper.checkState(Helper.isStringNullOrEmpty(syncOpLogHeaderName),
                "'syncOpLogHeaderName' can't be null/empty.");
        Helper.checkState(appService == null,
                "'appService' can't be null.");
    }

    /**
     * Initialize ServiceContext if user is present in session.
     * 
     * @param request
     *            the {@link javax.servlet.http.HttpServletRequest} instance
     * @param response
     *            the {@link javax.servlet.http.HttpServletResponse} instance
     * @param handler
     *            the handler
     * @return true
     * @throws ServiceRequestToolException
     *             if there is any error
     */
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
            throws ServiceRequestToolException {
        final String signature = CLASSNAME
                + "#preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)";

        // Log entry
        Helper.logEntrance(logger, signature, new String[]{"request", "response", "handler"},
                new Object[]{request, response, handler});

        // Just to make sure it's cleared.
        ServiceContext.clear();

        User user = (User) request.getSession().getAttribute(userSessionAttributeName);
        if (user != null) {
            ServiceContext.setCurrentUser(user);
        }

        if (appService.isCloudApp()) {
            String logToSync = request.getHeader(syncOpLogHeaderName);
            if (StringUtils.isNotBlank(logToSync)) {
                try {
                    ServiceContext.setCurrentOperationLog(Helper.OBJECT_MAPPER.readValue(logToSync, OperationLog.class));
                } catch (IOException e) {
                    throw Helper.logException(logger, signature, new ServiceRequestToolException(
                            "Failed to parse operation log request header", e));
                }
            }
        }

        // Log exit
        Helper.logExit(logger, signature, new Object[]{true});

        return true;
    }

    /**
     * Post process related to ServiceContext on success.
     * 
     * @param request
     *            the {@link javax.servlet.http.HttpServletRequest} instance
     * @param response
     *            the {@link javax.servlet.http.HttpServletResponse} instance
     * @param handler
     *            the handler
     * @param modelAndView
     *            the modelAndView
     * @throws ServiceRequestToolException
     *             if there is any error
     */
    public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler,
            ModelAndView modelAndView) throws ServiceRequestToolException {
        final String signature = CLASSNAME
                + "#postHandle(HttpServletRequest request, HttpServletResponse response, Object handler, ModelAndView modelAndView)";

        // Log entry
        Helper.logEntrance(logger, signature, new String[]{"request", "response", "handler", "modelAndView"},
                new Object[]{request, response, handler, modelAndView});

        User user = ServiceContext.getCurrentUser();
        // ModelAndView is null for AJAX request
        // For redirect don't need set model value
        if (user != null && modelAndView != null
                && ((modelAndView.getViewName() != null && !modelAndView.getViewName().startsWith("redirect:"))
                || (modelAndView.getView() != null && !(modelAndView.getView() instanceof RedirectView)))) {
            // used to render user info in pages
            modelAndView.addObject("user", user);
        }

        if (appService.isCloudApp()) {
            OperationLog opLog = ServiceContext.getCurrentOperationLog();
            if (opLog != null) {
                try {
                    response.setHeader(syncOpLogHeaderName, Helper.OBJECT_MAPPER.writeValueAsString(opLog));
                } catch (IOException e) {
                    throw Helper.logException(logger, signature, new ServiceRequestToolException(
                            "Failed to format operation log response header", e));
                }
            }
        }

       // Log exit
        Helper.logExit(logger, signature, null);
    }

    /**
     * This is called for both success and exception.
     * Move the ServiceContext.clear() from postHandle to here.
     *
     * @param request
     *         the {@link javax.servlet.http.HttpServletRequest} instance
     * @param response
     *         the {@link javax.servlet.http.HttpServletResponse} instance
     * @param handler
     *         the handler
     * @param ex
     *         the exception
     */
    @Override
    public void afterCompletion(
            HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex) {

        ServiceContext.clear();
    }

    /**
     * <p>
     * Sets the value to userSessionAttributeName field.
     * </p>
     *
     * @param userSessionAttributeName the userSessionAttributeName to set
     */
    public void setUserSessionAttributeName(String userSessionAttributeName) {
        this.userSessionAttributeName = userSessionAttributeName;
    }

    /**
     * <p>
     * Sets the value to syncOpLogHeaderName field.
     * </p>
     *
     * @param syncOpLogHeaderName the syncOpLogHeaderName to set
     * @since SRT Phase 4 - ET Assembly 2
     */
    public void setSyncOpLogHeaderName(String syncOpLogHeaderName) {
        this.syncOpLogHeaderName = syncOpLogHeaderName;
    }

    /**
     * <p>
     * Sets the value to appService field.
     * </p>
     *
     * @param appService the appService to set
     * @since SRT Phase 4 - ET Assembly 2
     */
    public void setAppService(AppService appService) {
        this.appService = appService;
    }
}

/*
 * This code is copyright (c) 2014 EMC Corporation.
 */
package com.emc.gs.tools.srf.web;

import java.io.IOException;

import javax.annotation.PostConstruct;

import org.springframework.http.HttpOutputMessage;
import org.springframework.http.converter.HttpMessageNotWritableException;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;

import com.emc.gs.tools.srf.ServiceRequestToolConfigurationException;
import com.emc.gs.tools.srf.model.OperationLog;
import com.emc.gs.tools.srf.model.ServiceContext;
import com.emc.gs.tools.srf.services.AppService;
import com.emc.gs.tools.srf.services.impl.Helper;

/**
 * <p>
 * Spring's built-in MappingJackson2HttpMessageConverter flushes the response right after writing JSON content
 * and will lost the custom outgoing response headers which are added in Interceptor#postHandle method. Use this
 * class to add any custom response headers in writeInternal() method.
 * </p>
 *
 * <p>
 * <strong>Thread safety</strong>: This class is immutable after configuration and effectively thread safe.
 * </p>
 *
 * @author TCSASSEMBLER
 * @version 1.0
 * @since SRT Phase 4 - ET Assembly 2
 */
public class Jackson2HttpMessageConverter extends MappingJackson2HttpMessageConverter {

    /**
     * Represents the syncOpLogHeaderName. It is modified by
     * setter. It is injected by Spring. It can not be null after injected.
     *
     * @since SRT Phase 4 - ET Assembly 2
     */
    private String syncOpLogHeaderName;

    /**
     * Represents the appService. It is modified by
     * setter. It is injected by Spring. It can not be null after injected.
     *
     * @since SRT Phase 4 - ET Assembly 2
     */
    private AppService appService;

    /**
     * Empty constructor.
     */
    public Jackson2HttpMessageConverter() {
    }

    /**
     * Overrides the base method to add custom outgoing headers before writing to response.
     *
     * @param object
     *            the object to write to the output message
     * @param outputMessage
     *            the message to write to
     * @throws IOException
     *             in case of I/O errors
     * @throws HttpMessageNotWritableException
     *             in case of conversion errors
     */
    @Override
    protected void writeInternal(Object object, HttpOutputMessage outputMessage) throws IOException,
            HttpMessageNotWritableException {

        // Add response headers
        if (appService.isCloudApp()) {
            OperationLog opLog = ServiceContext.getCurrentOperationLog();
            if (opLog != null) {
                outputMessage.getHeaders().set(syncOpLogHeaderName, Helper.OBJECT_MAPPER.writeValueAsString(opLog));
            }
        }

        // Delete to super to write JSON content
        super.writeInternal(object, outputMessage);
    }

    /**
     * This method checks whether the instance of the class was initialized properly.
     *
     * @throws ServiceRequestToolConfigurationException
     *             if appService is null, or if syncOpLogHeaderName is null or empty
     */
    @PostConstruct
    protected void checkInit() {
        Helper.checkState(Helper.isStringNullOrEmpty(syncOpLogHeaderName),
                "'syncOpLogHeaderName' can't be null/empty.");
        Helper.checkState(appService == null,
                "'appService' can't be null.");
    }

    /**
     * <p>
     * Sets the value to syncOpLogHeaderName field.
     * </p>
     *
     * @param syncOpLogHeaderName the syncOpLogHeaderName to set
     * @since SRT Phase 4 - ET Assembly 2
     */
    public void setSyncOpLogHeaderName(String syncOpLogHeaderName) {
        this.syncOpLogHeaderName = syncOpLogHeaderName;
    }

    /**
     * <p>
     * Sets the value to appService field.
     * </p>
     *
     * @param appService the appService to set
     * @since SRT Phase 4 - ET Assembly 2
     */
    public void setAppService(AppService appService) {
        this.appService = appService;
    }
}

/*
 * This code is copyright (c) 2013 - 2014 EMC Corporation.
 */
package com.emc.gs.tools.srf.web;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;

import com.emc.gs.tools.srf.model.ExpenseType;
import com.emc.gs.tools.srf.model.dpad.MeditechBackupType;
import com.emc.gs.tools.srf.model.dpad.NetworkerDatazoneSize;
import com.emc.gs.tools.srf.model.engagement.DeliveryCountry;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.emc.gs.tools.srf.ServiceRequestToolConfigurationException;
import com.emc.gs.tools.srf.model.ClearanceLevel;
import com.emc.gs.tools.srf.model.GeoState;
import com.emc.gs.tools.srf.model.KnowledgeTransferLevel;
import com.emc.gs.tools.srf.model.LookupEntity;
import com.emc.gs.tools.srf.model.MeetingStatus;
import com.emc.gs.tools.srf.model.ProjectType;
import com.emc.gs.tools.srf.model.ProjectRegulatoryType;
import com.emc.gs.tools.srf.model.RequestType;
import com.emc.gs.tools.srf.model.RiskLevel;
import com.emc.gs.tools.srf.model.ServicesAgreementType;
import com.emc.gs.tools.srf.model.SowLanguage;
import com.emc.gs.tools.srf.model.SowType;
import com.emc.gs.tools.srf.model.TestAcceptancePlanType;
import com.emc.gs.tools.srf.model.bc.AreaSizingType;
import com.emc.gs.tools.srf.model.bc.ArrayModel;
import com.emc.gs.tools.srf.model.bc.BcvCloneOption;
import com.emc.gs.tools.srf.model.bc.ConfigChangeType;
import com.emc.gs.tools.srf.model.bc.DocumentationLevel;
import com.emc.gs.tools.srf.model.bc.MigrationTestNumber;
import com.emc.gs.tools.srf.model.bc.MvConnectionType;
import com.emc.gs.tools.srf.model.bc.MvMode;
import com.emc.gs.tools.srf.model.bc.NetworkLinkStatus;
import com.emc.gs.tools.srf.model.bc.PostSalesCompletionQualifier;
import com.emc.gs.tools.srf.model.bc.PushPullOption;
import com.emc.gs.tools.srf.model.bc.ReplicationManagerImplementation;
import com.emc.gs.tools.srf.model.bc.ReplicationManagerProductSpecificPreparation;
import com.emc.gs.tools.srf.model.bc.ScriptingLevel;
import com.emc.gs.tools.srf.model.bc.ScriptingLevelOption;
import com.emc.gs.tools.srf.model.bc.SrdfConnectionType;
import com.emc.gs.tools.srf.model.bc.SrdfMode;
import com.emc.gs.tools.srf.model.bc.SrdfStaticDynamicType;
import com.emc.gs.tools.srf.model.bc.SymmetrixModel;
import com.emc.gs.tools.srf.model.infrastructure.EmcMigrationInvolvement;
import com.emc.gs.tools.srf.model.infrastructure.EnvironmentArrayType;
import com.emc.gs.tools.srf.model.infrastructure.EnvironmentDeviceType;
import com.emc.gs.tools.srf.model.infrastructure.EnvironmentGatherer;
import com.emc.gs.tools.srf.model.infrastructure.FlashStorageLayoutServices;
import com.emc.gs.tools.srf.model.infrastructure.HostSoftwareInstaller;
import com.emc.gs.tools.srf.model.infrastructure.MigrationWorker;
import com.emc.gs.tools.srf.model.infrastructure.SanImplementator;
import com.emc.gs.tools.srf.model.infrastructure.UnifiedConversionType;
import com.emc.gs.tools.srf.model.infrastructure.VnxClariionInstallType;
import com.emc.gs.tools.srf.model.infrastructure.VnxInstallProtocolSubType;
import com.emc.gs.tools.srf.model.infrastructure.VnxInstallProtocolType;
import com.emc.gs.tools.srf.model.infrastructure.VolumeSizeChange;
import com.emc.gs.tools.srf.model.unified.CelerraArrayType;
import com.emc.gs.tools.srf.model.unified.CelerraModel;
import com.emc.gs.tools.srf.model.unified.CelerraSetupType;
import com.emc.gs.tools.srf.model.unified.CelerraVnxModel;
import com.emc.gs.tools.srf.model.unified.GatewayStorageType;
import com.emc.gs.tools.srf.model.unified.IOInterfaceModule;
import com.emc.gs.tools.srf.model.unified.MigrationMethod;
import com.emc.gs.tools.srf.model.unified.RackAndStackOption;
import com.emc.gs.tools.srf.model.unified.ReplicationFailoverLevel;
import com.emc.gs.tools.srf.model.unified.SourceVnxType;
import com.emc.gs.tools.srf.model.unified.SynchronousMode;
import com.emc.gs.tools.srf.model.unified.TargetCelerra;
import com.emc.gs.tools.srf.model.unified.TargetCelerraType;
import com.emc.gs.tools.srf.model.unified.VNXProtocol;
import com.emc.gs.tools.srf.model.w4n.Collector;
import com.emc.gs.tools.srf.model.w4n.DCSolutionPack;
import com.emc.gs.tools.srf.model.w4n.EMCSolutionPack;
import com.emc.gs.tools.srf.model.w4n.MobileSolutionPack;
import com.emc.gs.tools.srf.model.w4n.NetworkReportPack;
import com.emc.gs.tools.srf.model.w4n.ServerReportPack;
import com.emc.gs.tools.srf.model.w4n.SmartsDomainType;
import com.emc.gs.tools.srf.model.w4n.StorageReportPack;
import com.emc.gs.tools.srf.model.w4n.VOIPSolutionPack;
import com.emc.gs.tools.srf.model.w4n.VPNReportPack;
import com.emc.gs.tools.srf.model.w4n.WANAccelerator;
import com.emc.gs.tools.srf.model.w4n.WiFiReportPack;
import com.emc.gs.tools.srf.services.LookupService;
import com.emc.gs.tools.srf.services.ServiceRequestToolException;
import com.emc.gs.tools.srf.services.impl.Helper;

/**
 * <p>
 * This class represents the controller used to retrieve lookup values. It provides list of methods that will
 * be AJAX-called and provide necessary data.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is effectively thread safe after configuration, the
 * configuration is done in a thread safe manner.
 * </p>
 *
 * <p>
 * <strong>Changes V1.1:</strong>
 * <strong>SRT Release Assembly - Base</strong>
 * <ul>
 * <li>Release_assembly_tasks.xls Row#8: Added lookup for sow types</li>
 * </ul>
 * </p>
 *
 * <p>
 * <strong>Changes V1.2:</strong>
 * <strong>SRT Release Assembly - BC Tab</strong>
 * <ul>
 * <li>Add getAllScriptingLevelOptions() method</li>
 * </ul>
 * </p>
 *
 * <p>
 * <strong>Changes V1.3:</strong>
 * <strong>SRT Release Assembly - Unified Tab</strong>
 * <ul>
 * <li>Add getAllSynchronousModes() and getAllReplicationFailoverLevels() methods</li>
 * </ul>
 * </p>
 *
 * <p>
 * <strong>Changes V1.4:</strong>
 * <strong>SRT Bug Fixes</strong>
 * <ul>
 * <li>Removed getAllVsdGrabAnalysisLevels() method.</li>
 * </ul>
 * </p>
 *
 * <p>
 * <strong>Changes V1.5:</strong>
 * <ul>
 * <li>Removed getAllTargetTfR2Devices, getAllMicrocodeFamilies, getAllFlarecodeFamilies,
 * getAllMonitoringScripts, getAllNetworkConnectionTypes, getAllMdlDlmLibraryTypes methods.</li>
 * </ul>
 * </p>
 *
 * <p>
 * <strong>Changes V1.6:</strong>
 * <strong>https://apps.topcoder.com/bugs/browse/SRT-35</strong>
 * <ul>
 * <li>Added getAllRecoverPointLicenses, getAllReplicationManagerProductSpecificPreparations, getAllVNXProtocols,
 * getAllMigrationMethods methods.</li>
 * </ul>
 * </p>
 *
 * <p>
 * <strong>Changes V1.7:</strong> <strong>SRT Phase 3-5 - BRS Tabs Part 1 Assembly</strong>
 * <ul>
 * <li>Delete getAllDataMobilityImplementations() method.</li>
 * <li>Delete getAllInstallTypes() method.</li>
 * <li>Delete getAllRecoverPointLicenses() method.</li>
 * <li>Delete getAllSplitterOptions() method.</li>
 * <li>Delete getAllJournalSizings() method.</li>
 * <li>Delete getAllSplitterTypes() method.</li>
 * </ul>
 * </p>
 *
 * <p>
 * <strong>Changes V1.8:</strong> <strong>SRT Phase 3 Merge Assembly</strong>
 * <ul>
 * <li>Added getAllLookupsByClass method and classMapping attribute for generic retrieval</li>
 * </ul>
 * </p>
 *
 * <p>
 * Version 1.9 (SRT Phase 4 - ET Release Assembly) Change notes:
 *   <ol>
 *     <li>Added {@link #getAllProjectRegulatoryTypes()} method.</li>
 *     <li>Added {@link #getAllExpenseTypes()} method.</li>
 *   </ol>
 * </p>
 *
 * <p>
 * Version 1.10 (SRT 4 OCT2014 Updates Part 1 Assembly) Change notes:
 *   <ol>
 *     <li>Added {@link #getAllNetworkerDatazoneSizes()} method.</li>
 *     <li>Added {@link #getAllMeditechBackupTypes()} method.</li>
 *   </ol>
 * </p>
 *
 * <p>
 * Version 1.11 (SRT 1.1 DEC 2014 Updates Assembly) Change notes:
 *   <ol>
 *     <li>Replaced {@link #getAllCountries()} method with {@link #getAllDeliveryCountries()} method.</li>
 *   </ol>
 * </p>
 * 
 * @author faeton, MonicaMuranyi, isv
 * @version 1.11
 */
@Controller
public class LookupController extends BaseController {
    /**
     * <p>
     * Represents the class name.
     * </p>
     */
    private static final String CLASSNAME = LookupController.class.getName();

    /**
     * Represents the LookupService instance for retrieving data. It is modified by setter. It is injected by
     * Spring. It can not be null after injected.
     */
    private LookupService lookupService;

    /**
     * Mapped lookup classes.
     */
    private Map<String, Class<?>> classMapping = new HashMap<String, Class<?>>();

    /**
     * Creates instance of the class.
     */
    public LookupController() {
        classMapping.put("Collector", Collector.class);
        classMapping.put("DCSolutionPack", DCSolutionPack.class);
        classMapping.put("EMCSolutionPack", EMCSolutionPack.class);
        classMapping.put("MobileSolutionPack", MobileSolutionPack.class);
        classMapping.put("NetworkReportPack", NetworkReportPack.class);
        classMapping.put("ServerReportPack", ServerReportPack.class);
        classMapping.put("SmartsDomainType", SmartsDomainType.class);
        classMapping.put("StorageReportPack", StorageReportPack.class);
        classMapping.put("VOIPSolutionPack", VOIPSolutionPack.class);
        classMapping.put("VPNReportPack", VPNReportPack.class);
        classMapping.put("WANAccelerator", WANAccelerator.class);
        classMapping.put("WiFiReportPack", WiFiReportPack.class);
    }

    /**
     * Returns all delivery countries.
     *
     * @return Whole list of lookup values, may be empty.
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     */
    @RequestMapping(value = "lookup/deliveryCountries", method = RequestMethod.GET)
    @ResponseBody
    public List<DeliveryCountry> getAllDeliveryCountries() throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#getAllDeliveryCountries()";

        // Log entry
        Helper.logEntrance(getLogger(), signature, null, null);

        List<DeliveryCountry> result = lookupService.getAllDeliveryCountries();
        Collections.sort(result, LookupCodeEntityComparator.BY_NAME);

        // Log exit
        Helper.logExit(getLogger(), signature, new Object[]{result});

        return result;
    }

    /**
     * Returns all geography states.
     *
     * @return Whole list of lookup values, may be empty.
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     */
    @RequestMapping(value = "lookup/geoStates", method = RequestMethod.GET)
    @ResponseBody
    public List<GeoState> getAllGeoStates() throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#getAllGeoStates()";

        // Log entry
        Helper.logEntrance(getLogger(), signature, null, null);

        List<GeoState> result = lookupService.getAllGeoStates();

        // Log exit
        Helper.logExit(getLogger(), signature, new Object[] {result});

        return result;
    }

    /**
     * Returns all services agreement types.
     *
     * @return Whole list of lookup values, may be empty
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     */
    @RequestMapping(value = "lookup/servicesAgreementTypes", method = RequestMethod.GET)
    @ResponseBody
    public List<ServicesAgreementType> getAllServicesAgreementTypes() throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#getAllServicesAgreementTypes()";

        // Log entry
        Helper.logEntrance(getLogger(), signature, null, null);

        List<ServicesAgreementType> result = lookupService.getAllServicesAgreementTypes();

        // Log exit
        Helper.logExit(getLogger(), signature, new Object[] {result});

        return result;
    }

    /**
     * Returns all Sow types.
     *
     * @return Whole list of lookup values, may be empty
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     * @since 1.1
     */
    @RequestMapping(value = "lookup/sowTypes", method = RequestMethod.GET)
    @ResponseBody
    public List<SowType> getAllSowTypes() throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#getAllSowTypes()";

        // Log entry
        Helper.logEntrance(getLogger(), signature, null, null);

        List<SowType> result = lookupService.getAllSowTypes();

        // Log exit
        Helper.logExit(getLogger(), signature, new Object[] {result});

        return result;
    }

    /**
     * Returns all request types.
     *
     * @return Whole list of lookup values, may be empty
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     */
    @RequestMapping(value = "lookup/requestTypes", method = RequestMethod.GET)
    @ResponseBody
    public List<RequestType> getAllRequestTypes() throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#getAllRequestTypes()";

        // Log entry
        Helper.logEntrance(getLogger(), signature, null, null);

        List<RequestType> result = lookupService.getAllRequestTypes();

        // Log exit
        Helper.logExit(getLogger(), signature, new Object[] {result});

        return result;
    }

    /**
     * Returns all risk levels.
     *
     * @return Whole list of lookup values, may be empty
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     */
    @RequestMapping(value = "lookup/riskLevels", method = RequestMethod.GET)
    @ResponseBody
    public List<RiskLevel> getAllRiskLevels() throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#getAllRiskLevels()";

        // Log entry
        Helper.logEntrance(getLogger(), signature, null, null);

        List<RiskLevel> result = lookupService.getAllRiskLevels();

        // Log exit
        Helper.logExit(getLogger(), signature, new Object[] {result});

        return result;
    }

    /**
     * Returns all sow project types.
     *
     * @return Whole list of lookup values, may be empty
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     */
    @RequestMapping(value = "lookup/projectTypes", method = RequestMethod.GET)
    @ResponseBody
    public List<ProjectType> getAllProjectTypes() throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#getAllProjectTypes()";

        // Log entry
        Helper.logEntrance(getLogger(), signature, null, null);

        List<ProjectType> result = lookupService.getAllProjectTypes();

        // Log exit
        Helper.logExit(getLogger(), signature, new Object[] {result});

        return result;
    }

    /**
     * <p>Gets the list of available project regulatory types.</p>
     *
     * @return a <code>List</code> listing the available project regulatory types, may be empty. 
     * @throws ServiceRequestToolException if any other error occurred during the operation.
     * @since 1.9
     */
    @RequestMapping(value = "lookup/projectRegulatoryTypes", method = RequestMethod.GET)
    @ResponseBody
    public List<ProjectRegulatoryType> getAllProjectRegulatoryTypes() throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#getAllProjectRegulatoryTypes()";

        // Log entry
        Helper.logEntrance(getLogger(), signature, null, null);

        List<ProjectRegulatoryType> result = lookupService.getAllProjectRegulatoryTypes();

        // Log exit
        Helper.logExit(getLogger(), signature, new Object[]{result});

        return result;
    }

    /**
     * <p>Gets the list of available expense types.</p>
     *
     * @return a <code>List</code> listing the available expense types, may be empty.
     * @throws ServiceRequestToolException if any other error occurred during the operation.
     * @since 1.9
     */
    @RequestMapping(value = "lookup/expenseTypes", method = RequestMethod.GET)
    @ResponseBody
    public List<ExpenseType> getAllExpenseTypes() throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#getAllExpenseTypes()";

        // Log entry
        Helper.logEntrance(getLogger(), signature, null, null);

        List<ExpenseType> result = lookupService.getAllExpenseTypes();

        // Log exit
        Helper.logExit(getLogger(), signature, new Object[]{result});

        return result;
    }

    /**
     * <p>Gets the list of available Networker datazone sizes.</p>
     *
     * @return a <code>List</code> listing the available Networker datazone sizes, may be empty.
     * @throws ServiceRequestToolException if any other error occurred during the operation.
     * @since 1.10
     */
    @RequestMapping(value = "lookup/networkerDatazoneSizes", method = RequestMethod.GET)
    @ResponseBody
    public List<NetworkerDatazoneSize> getAllNetworkerDatazoneSizes() throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#getAllNetworkerDatazoneSizes()";

        // Log entry
        Helper.logEntrance(getLogger(), signature, null, null);

        List<NetworkerDatazoneSize> result = lookupService.getAllNetworkerDatazoneSizes();

        // Log exit
        Helper.logExit(getLogger(), signature, new Object[]{result});

        return result;
    }

    /**
     * <p>Gets the list of available Meditech backup types.</p>
     *
     * @return a <code>List</code> listing the available Meditech backup types, may be empty.
     * @throws ServiceRequestToolException if any other error occurred during the operation.
     * @since 1.10
     */
    @RequestMapping(value = "lookup/meditechBackupTypes", method = RequestMethod.GET)
    @ResponseBody
    public List<MeditechBackupType> getAllMeditechBackupTypes() throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#getAllMeditechBackupTypes()";

        // Log entry
        Helper.logEntrance(getLogger(), signature, null, null);

        List<MeditechBackupType> result = lookupService.getAllMeditechBackupTypes();

        // Log exit
        Helper.logExit(getLogger(), signature, new Object[]{result});

        return result;
    }

    /**
     * Returns all clearance levels.
     *
     * @return Whole list of lookup values, may be empty
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     */
    @RequestMapping(value = "lookup/clearanceLevels", method = RequestMethod.GET)
    @ResponseBody
    public List<ClearanceLevel> getAllClearanceLevels() throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#getAllClearanceLevels()";

        // Log entry
        Helper.logEntrance(getLogger(), signature, null, null);

        List<ClearanceLevel> result = lookupService.getAllClearanceLevels();

        // Log exit
        Helper.logExit(getLogger(), signature, new Object[] {result});

        return result;
    }

    /**
     * Returns all sow languages.
     *
     * @return Whole list of lookup values, may be empty
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     */
    @RequestMapping(value = "lookup/sowLanguages", method = RequestMethod.GET)
    @ResponseBody
    public List<SowLanguage> getAllSowLanguages() throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#getAllSowLanguages()";

        // Log entry
        Helper.logEntrance(getLogger(), signature, null, null);

        List<SowLanguage> result = lookupService.getAllSowLanguages();

        // Log exit
        Helper.logExit(getLogger(), signature, new Object[] {result});

        return result;
    }

    /**
     * Returns all meeting statuses.
     *
     * @return Whole list of lookup values, may be empty
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     */
    @RequestMapping(value = "lookup/meetingStatuses", method = RequestMethod.GET)
    @ResponseBody
    public List<MeetingStatus> getAllMeetingStatuses() throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#getAllMeetingStatuses()";

        // Log entry
        Helper.logEntrance(getLogger(), signature, null, null);

        List<MeetingStatus> result = lookupService.getAllMeetingStatuses();

        // Log exit
        Helper.logExit(getLogger(), signature, new Object[] {result});

        return result;
    }

    /**
     * Returns all environment gatherers .
     *
     * @return Whole list of lookup values, may be empty
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     */
    @RequestMapping(value = "lookup/environmentGatherers", method = RequestMethod.GET)
    @ResponseBody
    public List<EnvironmentGatherer> getAllEnvironmentGatherers() throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#getAllEnvironmentGatherers()";

        // Log entry
        Helper.logEntrance(getLogger(), signature, null, null);

        List<EnvironmentGatherer> result = lookupService.getAllEnvironmentGatherers();

        // Log exit
        Helper.logExit(getLogger(), signature, new Object[] {result});

        return result;
    }

    /**
     * Returns all host software installers.
     *
     * @return Whole list of lookup values, may be empty
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     */
    @RequestMapping(value = "lookup/hostSoftwareInstallers", method = RequestMethod.GET)
    @ResponseBody
    public List<HostSoftwareInstaller> getAllHostSoftwareInstallers() throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#getAllHostSoftwareInstallers()";

        // Log entry
        Helper.logEntrance(getLogger(), signature, null, null);

        List<HostSoftwareInstaller> result = lookupService.getAllHostSoftwareInstallers();

        // Log exit
        Helper.logExit(getLogger(), signature, new Object[] {result});

        return result;
    }

    /**
     * Returns all san implementators.
     *
     * @return Whole list of lookup values, may be empty
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     */
    @RequestMapping(value = "lookup/sanImplementators", method = RequestMethod.GET)
    @ResponseBody
    public List<SanImplementator> getAllSanImplementators() throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#getAllSanImplementators()";

        // Log entry
        Helper.logEntrance(getLogger(), signature, null, null);

        List<SanImplementator> result = lookupService.getAllSanImplementators();

        // Log exit
        Helper.logExit(getLogger(), signature, new Object[] {result});

        return result;
    }

    /**
     * Returns all environment array types.
     *
     * @return Whole list of lookup values, may be empty
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     */
    @RequestMapping(value = "lookup/environmentArrayTypes", method = RequestMethod.GET)
    @ResponseBody
    public List<EnvironmentArrayType> getAllEnvironmentArrayTypes() throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#getAllEnvironmentArrayTypes()";

        // Log entry
        Helper.logEntrance(getLogger(), signature, null, null);

        List<EnvironmentArrayType> result = lookupService.getAllEnvironmentArrayTypes();

        // Log exit
        Helper.logExit(getLogger(), signature, new Object[] {result});

        return result;
    }

    /**
     * Returns all environment device types.
     *
     * @return Whole list of lookup values, may be empty
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     */
    @RequestMapping(value = "lookup/environmentDeviceTypes", method = RequestMethod.GET)
    @ResponseBody
    public List<EnvironmentDeviceType> getAllEnvironmentDeviceTypes() throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#getAllEnvironmentDeviceTypes()";

        // Log entry
        Helper.logEntrance(getLogger(), signature, null, null);

        List<EnvironmentDeviceType> result = lookupService.getAllEnvironmentDeviceTypes();

        // Log exit
        Helper.logExit(getLogger(), signature, new Object[] {result});

        return result;
    }

    /**
     * Returns all migration workers.
     *
     * @return Whole list of lookup values, may be empty
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     */
    @RequestMapping(value = "lookup/migrationWorkers", method = RequestMethod.GET)
    @ResponseBody
    public List<MigrationWorker> getAllMigrationWorkers() throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#getAllMigrationWorkers()";

        // Log entry
        Helper.logEntrance(getLogger(), signature, null, null);

        List<MigrationWorker> result = lookupService.getAllMigrationWorkers();

        // Log exit
        Helper.logExit(getLogger(), signature, new Object[] {result});

        return result;
    }

    /**
     * Returns all volume size changes.
     *
     * @return Whole list of lookup values, may be empty
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     */
    @RequestMapping(value = "lookup/volumeSizeChanges", method = RequestMethod.GET)
    @ResponseBody
    public List<VolumeSizeChange> getAllVolumeSizeChanges() throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#getAllVolumeSizeChanges()";

        // Log entry
        Helper.logEntrance(getLogger(), signature, null, null);

        List<VolumeSizeChange> result = lookupService.getAllVolumeSizeChanges();

        // Log exit
        Helper.logExit(getLogger(), signature, new Object[] {result});

        return result;
    }

    /**
     * Returns all emc migration involvements.
     *
     * @return Whole list of lookup values, may be empty
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     */
    @RequestMapping(value = "lookup/emcMigrationInvolvments", method = RequestMethod.GET)
    @ResponseBody
    public List<EmcMigrationInvolvement> getAllEmcMigrationInvolvements() throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#getAllEmcMigrationInvolvements()";

        // Log entry
        Helper.logEntrance(getLogger(), signature, null, null);

        List<EmcMigrationInvolvement> result = lookupService.getAllEmcMigrationInvolvements();

        // Log exit
        Helper.logExit(getLogger(), signature, new Object[] {result});

        return result;
    }

    /**
     * Returns all scripting levels.
     *
     * @return Whole list of lookup values, may be empty
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     */
    @RequestMapping(value = "lookup/scriptLevels", method = RequestMethod.GET)
    @ResponseBody
    public List<ScriptingLevel> getAllScriptingLevels() throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#getAllScriptingLevels()";

        // Log entry
        Helper.logEntrance(getLogger(), signature, null, null);

        List<ScriptingLevel> result = lookupService.getAllScriptingLevels();

        // Log exit
        Helper.logExit(getLogger(), signature, new Object[] {result});

        return result;
    }

    /**
     * Returns all scripting level options.
     *
     * @return Whole list of lookup values, may be empty
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     * @since SRT Release Assembly - BC Tab
     */
    @RequestMapping(value = "lookup/scriptLevelOptions", method = RequestMethod.GET)
    @ResponseBody
    public List<ScriptingLevelOption> getAllScriptingLevelOptions() throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#getAllScriptingLevelOptions()";

        // Log entry
        Helper.logEntrance(getLogger(), signature, null, null);

        List<ScriptingLevelOption> result = lookupService.getAllScriptingLevelOptions();

        // Log exit
        Helper.logExit(getLogger(), signature, new Object[] {result});

        return result;
    }

    /**
     * Returns all test acceptance plan types.
     *
     * @return Whole list of lookup values, may be empty
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     */
    @RequestMapping(value = "lookup/testAcceptancePlanTypes", method = RequestMethod.GET)
    @ResponseBody
    public List<TestAcceptancePlanType> getAllTestAcceptancePlanTypes() throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#getAllTestAcceptancePlanTypes()";

        // Log entry
        Helper.logEntrance(getLogger(), signature, null, null);

        List<TestAcceptancePlanType> result = lookupService.getAllTestAcceptancePlanTypes();

        // Log exit
        Helper.logExit(getLogger(), signature, new Object[] {result});

        return result;
    }

    /**
     * Returns all documentation levels.
     *
     * @return Whole list of lookup values, may be empty
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     */
    @RequestMapping(value = "lookup/documentationLevels", method = RequestMethod.GET)
    @ResponseBody
    public List<DocumentationLevel> getAllDocumentationLevels() throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#getAllDocumentationLevels()";

        // Log entry
        Helper.logEntrance(getLogger(), signature, null, null);

        List<DocumentationLevel> result = lookupService.getAllDocumentationLevels();

        // Log exit
        Helper.logExit(getLogger(), signature, new Object[] {result});

        return result;
    }

    /**
     * Returns all knowledge transfer levels.
     *
     * @return Whole list of lookup values, may be empty
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     */
    @RequestMapping(value = "lookup/knowledgeTransferLevels", method = RequestMethod.GET)
    @ResponseBody
    public List<KnowledgeTransferLevel> getAllKnowledgeTransferLevels() throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#getAllKnowledgeTransferLevels()";

        // Log entry
        Helper.logEntrance(getLogger(), signature, null, null);

        List<KnowledgeTransferLevel> result = lookupService.getAllKnowledgeTransferLevels();

        // Log exit
        Helper.logExit(getLogger(), signature, new Object[] {result});

        return result;
    }

    /**
     * Returns all push/pull options.
     *
     * @return Whole list of lookup values, may be empty
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     */
    @RequestMapping(value = "lookup/pushPullOptions", method = RequestMethod.GET)
    @ResponseBody
    public List<PushPullOption> getAllPushPullOptions() throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#getAllPushPullOptions()";

        // Log entry
        Helper.logEntrance(getLogger(), signature, null, null);

        List<PushPullOption> result = lookupService.getAllPushPullOptions();

        // Log exit
        Helper.logExit(getLogger(), signature, new Object[] {result});

        return result;
    }

    /**
     * Returns all post sales completion qualifiers.
     *
     * @return Whole list of lookup values, may be empty
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     */
    @RequestMapping(value = "lookup/postSalesCompletionQualifiers", method = RequestMethod.GET)
    @ResponseBody
    public List<PostSalesCompletionQualifier> getAllPostSalesCompletionQualifiers()
        throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#getAllPostSalesCompletionQualifiers()";

        // Log entry
        Helper.logEntrance(getLogger(), signature, null, null);

        List<PostSalesCompletionQualifier> result = lookupService.getAllPostSalesCompletionQualifiers();

        // Log exit
        Helper.logExit(getLogger(), signature, new Object[] {result});

        return result;
    }

    /**
     * Returns all migration test numbers.
     *
     * @return Whole list of lookup values, may be empty
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     */
    @RequestMapping(value = "lookup/migrationTestNumbers", method = RequestMethod.GET)
    @ResponseBody
    public List<MigrationTestNumber> getAllMigrationTestNumbers() throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#getAllMigrationTestNumbers()";

        // Log entry
        Helper.logEntrance(getLogger(), signature, null, null);

        List<MigrationTestNumber> result = lookupService.getAllMigrationTestNumbers();

        // Log exit
        Helper.logExit(getLogger(), signature, new Object[] {result});

        return result;
    }

    /**
     * Returns all symmetrix models.
     *
     * @return Whole list of lookup values, may be empty
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     */
    @RequestMapping(value = "lookup/symmetrixModels", method = RequestMethod.GET)
    @ResponseBody
    public List<SymmetrixModel> getAllSymmetrixModels() throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#getAllSymmetrixModels()";

        // Log entry
        Helper.logEntrance(getLogger(), signature, null, null);

        List<SymmetrixModel> result = lookupService.getAllSymmetrixModels();

        // Log exit
        Helper.logExit(getLogger(), signature, new Object[] {result});

        return result;
    }

    /**
     * Returns all srdf modes.
     *
     * @return Whole list of lookup values, may be empty
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     */
    @RequestMapping(value = "lookup/srdfModes", method = RequestMethod.GET)
    @ResponseBody
    public List<SrdfMode> getAllSrdfModes() throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#getAllSrdfModes()";

        // Log entry
        Helper.logEntrance(getLogger(), signature, null, null);

        List<SrdfMode> result = lookupService.getAllSrdfModes();

        // Log exit
        Helper.logExit(getLogger(), signature, new Object[] {result});

        return result;
    }

    /**
     * Returns all srdf connection types.
     *
     * @return Whole list of lookup values, may be empty
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     */
    @RequestMapping(value = "lookup/srdfConnectionTypes", method = RequestMethod.GET)
    @ResponseBody
    public List<SrdfConnectionType> getAllSrdfConnectionTypes() throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#getAllSrdfConnectionTypes()";

        // Log entry
        Helper.logEntrance(getLogger(), signature, null, null);

        List<SrdfConnectionType> result = lookupService.getAllSrdfConnectionTypes();

        // Log exit
        Helper.logExit(getLogger(), signature, new Object[] {result});

        return result;
    }

    /**
     * Returns all array models.
     *
     * @return Whole list of lookup values, may be empty
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     */
    @RequestMapping(value = "lookup/arrayModels", method = RequestMethod.GET)
    @ResponseBody
    public List<ArrayModel> getAllArrayModels() throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#getAllArrayModels()";

        // Log entry
        Helper.logEntrance(getLogger(), signature, null, null);

        List<ArrayModel> result = lookupService.getAllArrayModels();

        // Log exit
        Helper.logExit(getLogger(), signature, new Object[] {result});

        return result;
    }

    /**
     * Returns all MV modes.
     *
     * @return Whole list of lookup values, may be empty
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     */
    @RequestMapping(value = "lookup/mvModels", method = RequestMethod.GET)
    @ResponseBody
    public List<MvMode> getAllMvModes() throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#getAllMvModes()";

        // Log entry
        Helper.logEntrance(getLogger(), signature, null, null);

        List<MvMode> result = lookupService.getAllMvModes();

        // Log exit
        Helper.logExit(getLogger(), signature, new Object[] {result});

        return result;
    }

    /**
     * Returns all MVC connection types.
     *
     * @return Whole list of lookup values, may be empty
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     */
    @RequestMapping(value = "lookup/mvConnectionTypes", method = RequestMethod.GET)
    @ResponseBody
    public List<MvConnectionType> getAllMvConnectionTypes() throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#getAllMvConnectionTypes()";

        // Log entry
        Helper.logEntrance(getLogger(), signature, null, null);

        List<MvConnectionType> result = lookupService.getAllMvConnectionTypes();

        // Log exit
        Helper.logExit(getLogger(), signature, new Object[] {result});

        return result;
    }

    /**
     * Returns all srdf static/dynamic types.
     *
     * @return Whole list of lookup values, may be empty
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     */
    @RequestMapping(value = "lookup/srdfStaticDynamicTypes", method = RequestMethod.GET)
    @ResponseBody
    public List<SrdfStaticDynamicType> getAllSrdfStaticDynamicTypes() throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#getAllSrdfStaticDynamicTypes()";

        // Log entry
        Helper.logEntrance(getLogger(), signature, null, null);

        List<SrdfStaticDynamicType> result = lookupService.getAllSrdfStaticDynamicTypes();

        // Log exit
        Helper.logExit(getLogger(), signature, new Object[] {result});

        return result;
    }

    /**
     * Returns all area sizing types.
     *
     * @return Whole list of lookup values, may be empty
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     */
    @RequestMapping(value = "lookup/areaSizingTypes", method = RequestMethod.GET)
    @ResponseBody
    public List<AreaSizingType> getAllAreaSizingTypes() throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#getAllAreaSizingTypes()";

        // Log entry
        Helper.logEntrance(getLogger(), signature, null, null);

        List<AreaSizingType> result = lookupService.getAllAreaSizingTypes();

        // Log exit
        Helper.logExit(getLogger(), signature, new Object[] {result});

        return result;
    }

    /**
     * Returns all network link statuses.
     *
     * @return Whole list of lookup values, may be empty
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     */
    @RequestMapping(value = "lookup/networkLinkStatuses", method = RequestMethod.GET)
    @ResponseBody
    public List<NetworkLinkStatus> getAllNetworkLinkStatuses() throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#getAllNetworkLinkStatuses()";

        // Log entry
        Helper.logEntrance(getLogger(), signature, null, null);

        List<NetworkLinkStatus> result = lookupService.getAllNetworkLinkStatuses();

        // Log exit
        Helper.logExit(getLogger(), signature, new Object[] {result});

        return result;
    }

    /**
     * Returns all bcv clone options.
     *
     * @return Whole list of lookup values, may be empty
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     */
    @RequestMapping(value = "lookup/bcvCloneOptions", method = RequestMethod.GET)
    @ResponseBody
    public List<BcvCloneOption> getAllBcvCloneOptions() throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#getAllBcvCloneOptions()";

        // Log entry
        Helper.logEntrance(getLogger(), signature, null, null);

        List<BcvCloneOption> result = lookupService.getAllBcvCloneOptions();

        // Log exit
        Helper.logExit(getLogger(), signature, new Object[] {result});

        return result;
    }

    /**
     * Returns all config change types.
     *
     * @return Whole list of lookup values, may be empty
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     */
    @RequestMapping(value = "lookup/configChangeTypes", method = RequestMethod.GET)
    @ResponseBody
    public List<ConfigChangeType> getAllConfigChangeTypes() throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#getAllConfigChangeTypes()";

        // Log entry
        Helper.logEntrance(getLogger(), signature, null, null);

        List<ConfigChangeType> result = lookupService.getAllConfigChangeTypes();

        // Log exit
        Helper.logExit(getLogger(), signature, new Object[] {result});

        return result;
    }

    /**
     * Returns all replication manager implementations.
     *
     * @return Whole list of lookup values, may be empty
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     */
    @RequestMapping(value = "lookup/replicationManagerImplementations", method = RequestMethod.GET)
    @ResponseBody
    public List<ReplicationManagerImplementation> getAllReplicationManagerImplementations()
        throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#getAllReplicationManagerImplementations()";

        // Log entry
        Helper.logEntrance(getLogger(), signature, null, null);

        List<ReplicationManagerImplementation> result = lookupService.getAllReplicationManagerImplementations();

        // Log exit
        Helper.logExit(getLogger(), signature, new Object[] {result});

        return result;
    }

    /**
     * Returns all replication manager product specific preparations.
     *
     * @return Whole list of lookup values, may be empty
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     */
    @RequestMapping(value = "lookup/replicationManagerProductSpecificPreparations", method = RequestMethod.GET)
    @ResponseBody
    public List<ReplicationManagerProductSpecificPreparation> getAllReplicationManagerProductSpecificPreparations()
        throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#getAllReplicationManagerProductSpecificPreparations()";

        // Log entry
        Helper.logEntrance(getLogger(), signature, null, null);

        List<ReplicationManagerProductSpecificPreparation> result = lookupService
                .getAllReplicationManagerProductSpecificPreparations();

        // Log exit
        Helper.logExit(getLogger(), signature, new Object[] {result});

        return result;
    }

    /**
     * Returns all celerra models.
     *
     * @return Whole list of lookup values, may be empty
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     */
    @RequestMapping(value = "lookup/celerraModels", method = RequestMethod.GET)
    @ResponseBody
    public List<CelerraModel> getAllCelerraModels() throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#getAllCelerraModels()";

        // Log entry
        Helper.logEntrance(getLogger(), signature, null, null);

        List<CelerraModel> result = lookupService.getAllCelerraModels();

        // Log exit
        Helper.logExit(getLogger(), signature, new Object[] {result});

        return result;
    }

    /**
     * Returns all vnx protocols.
     *
     * @return Whole list of lookup values, may be empty
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     */
    @RequestMapping(value = "lookup/vnxProtocols", method = RequestMethod.GET)
    @ResponseBody
    public List<VNXProtocol> getAllVNXProtocols() throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#getAllVNXProtocols()";

        // Log entry
        Helper.logEntrance(getLogger(), signature, null, null);

        List<VNXProtocol> result = lookupService.getAllVNXProtocols();

        // Log exit
        Helper.logExit(getLogger(), signature, new Object[] {result});

        return result;
    }

    /**
     * Returns all rack and stack options.
     *
     * @return Whole list of lookup values, may be empty
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     */
    @RequestMapping(value = "lookup/rackAndStackOptions", method = RequestMethod.GET)
    @ResponseBody
    public List<RackAndStackOption> getAllRackAndStackOptions() throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#getAllRackAndStackOptions()";

        // Log entry
        Helper.logEntrance(getLogger(), signature, null, null);

        List<RackAndStackOption> result = lookupService.getAllRackAndStackOptions();

        // Log exit
        Helper.logExit(getLogger(), signature, new Object[] {result});

        return result;
    }

    /**
     * Returns all gateway storage types.
     *
     * @return Whole list of lookup values, may be empty
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     */
    @RequestMapping(value = "lookup/gatewayStorageTypes", method = RequestMethod.GET)
    @ResponseBody
    public List<GatewayStorageType> getAllGatewayStorageTypes() throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#getAllGatewayStorageTypes()";

        // Log entry
        Helper.logEntrance(getLogger(), signature, null, null);

        List<GatewayStorageType> result = lookupService.getAllGatewayStorageTypes();

        // Log exit
        Helper.logExit(getLogger(), signature, new Object[] {result});

        return result;
    }

    /**
     * Returns all celerra setup types.
     *
     * @return Whole list of lookup values, may be empty
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     */
    @RequestMapping(value = "lookup/celerraSetupTypes", method = RequestMethod.GET)
    @ResponseBody
    public List<CelerraSetupType> getAllCelerraSetupTypes() throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#getAllCelerraSetupTypes()";

        // Log entry
        Helper.logEntrance(getLogger(), signature, null, null);

        List<CelerraSetupType> result = lookupService.getAllCelerraSetupTypes();

        // Log exit
        Helper.logExit(getLogger(), signature, new Object[] {result});

        return result;
    }

    /**
     * Returns all target celerra types.
     *
     * @return Whole list of lookup values, may be empty
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     */
    @RequestMapping(value = "lookup/targetCelerraTypes", method = RequestMethod.GET)
    @ResponseBody
    public List<TargetCelerraType> getAllTargetCelerraTypes() throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#getAllTargetCelerraTypes()";

        // Log entry
        Helper.logEntrance(getLogger(), signature, null, null);

        List<TargetCelerraType> result = lookupService.getAllTargetCelerraTypes();

        // Log exit
        Helper.logExit(getLogger(), signature, new Object[] {result});

        return result;
    }

    /**
     * Returns all celerra array types.
     *
     * @return Whole list of lookup values, may be empty
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     */
    @RequestMapping(value = "lookup/celerraArrayTypes", method = RequestMethod.GET)
    @ResponseBody
    public List<CelerraArrayType> getAllCelerraArrayTypes() throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#getAllCelerraArrayTypes()";

        // Log entry
        Helper.logEntrance(getLogger(), signature, null, null);

        List<CelerraArrayType> result = lookupService.getAllCelerraArrayTypes();

        // Log exit
        Helper.logExit(getLogger(), signature, new Object[] {result});

        return result;
    }

    /**
     * Returns all target celerras.
     *
     * @return Whole list of lookup values, may be empty
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     */
    @RequestMapping(value = "lookup/targetCelerras", method = RequestMethod.GET)
    @ResponseBody
    public List<TargetCelerra> getAllTargetCelerras() throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#getAllTargetCelerras()";

        // Log entry
        Helper.logEntrance(getLogger(), signature, null, null);

        List<TargetCelerra> result = lookupService.getAllTargetCelerras();

        // Log exit
        Helper.logExit(getLogger(), signature, new Object[] {result});

        return result;
    }

    /**
     * Returns all celerra vnx models.
     *
     * @return Whole list of lookup values, may be empty
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     */
    @RequestMapping(value = "lookup/celerraVnxModels", method = RequestMethod.GET)
    @ResponseBody
    public List<CelerraVnxModel> getAllCelerraVnxModels() throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#getAllCelerraVnxModels()";

        // Log entry
        Helper.logEntrance(getLogger(), signature, null, null);

        List<CelerraVnxModel> result = lookupService.getAllCelerraVnxModels();

        // Log exit
        Helper.logExit(getLogger(), signature, new Object[] {result});

        return result;
    }

    /**
     * Returns all celerra vnx models.
     *
     * @return Whole list of lookup values, may be empty
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     */
    @RequestMapping(value = "lookup/migrationMethods", method = RequestMethod.GET)
    @ResponseBody
    public List<MigrationMethod> getAllMigrationMethods() throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#getAllMigrationMethods()";

        // Log entry
        Helper.logEntrance(getLogger(), signature, null, null);

        List<MigrationMethod> result = lookupService.getAllMigrationMethods();

        // Log exit
        Helper.logExit(getLogger(), signature, new Object[] {result});

        return result;
    }

    /**
     * Returns all vnx clariion install types.
     *
     * @return Whole list of lookup values, may be empty
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     */
    @RequestMapping(value = "lookup/vnxClariionInstallTypes", method = RequestMethod.GET)
    @ResponseBody
    public List<VnxClariionInstallType> getAllVnxClariionInstallTypes() throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#getAllVnxClariionInstallTypes()";

        // Log entry
        Helper.logEntrance(getLogger(), signature, null, null);

        List<VnxClariionInstallType> result = lookupService.getAllVnxClariionInstallTypes();

        // Log exit
        Helper.logExit(getLogger(), signature, new Object[] {result});

        return result;
    }

    /**
     * Returns all unified conversion types.
     *
     * @return Whole list of lookup values, may be empty
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     */
    @RequestMapping(value = "lookup/unifiedConversionTypes", method = RequestMethod.GET)
    @ResponseBody
    public List<UnifiedConversionType> getAllUnifiedConversionTypes() throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#getAllUnifiedConversionTypes()";

        // Log entry
        Helper.logEntrance(getLogger(), signature, null, null);

        List<UnifiedConversionType> result = lookupService.getAllUnifiedConversionTypes();

        // Log exit
        Helper.logExit(getLogger(), signature, new Object[] {result});

        return result;
    }

    /**
     * Returns all vnx install protocol types.
     *
     * @return Whole list of lookup values, may be empty
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     */
    @RequestMapping(value = "lookup/vnxInstallProtocolTypes", method = RequestMethod.GET)
    @ResponseBody
    public List<VnxInstallProtocolType> getAllVnxInstallProtocolTypes() throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#getAllVnxInstallProtocolTypes()";

        // Log entry
        Helper.logEntrance(getLogger(), signature, null, null);

        List<VnxInstallProtocolType> result = lookupService.getAllVnxInstallProtocolTypes();

        // Log exit
        Helper.logExit(getLogger(), signature, new Object[] {result});

        return result;
    }

    /**
     * Returns all vnx install protocol sub type.
     *
     * @return Whole list of lookup values, may be empty
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     */
    @RequestMapping(value = "lookup/vnxInstallProtocolSubTypes", method = RequestMethod.GET)
    @ResponseBody
    public List<VnxInstallProtocolSubType> getAllVnxInstallProtocolSubTypes() throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#getAllVnxInstallProtocolSubTypes()";

        // Log entry
        Helper.logEntrance(getLogger(), signature, null, null);

        List<VnxInstallProtocolSubType> result = lookupService.getAllVnxInstallProtocolSubTypes();

        // Log exit
        Helper.logExit(getLogger(), signature, new Object[] {result});

        return result;
    }

    /**
     * Returns all io interface modules.
     *
     * @return Whole list of lookup values, may be empty
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     */
    @RequestMapping(value = "lookup/ioInterfaceModules", method = RequestMethod.GET)
    @ResponseBody
    public List<IOInterfaceModule> getAllIOInterfaceModules() throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#getAllIOInterfaceModules()";

        // Log entry
        Helper.logEntrance(getLogger(), signature, null, null);

        List<IOInterfaceModule> result = lookupService.getAllIOInterfaceModules();

        // Log exit
        Helper.logExit(getLogger(), signature, new Object[] {result});

        return result;
    }

    /**
     * Returns all FlashStorageLayoutServices modules.
     *
     * @return Whole list of lookup values, may be empty
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     */
    @RequestMapping(value = "lookup/flashStorageLayoutServices", method = RequestMethod.GET)
    @ResponseBody
    public List<FlashStorageLayoutServices> getAllFlashStorageLayoutServices() throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#getAllFlashStorageLayoutServices()";

        // Log entry
        Helper.logEntrance(getLogger(), signature, null, null);

        List<FlashStorageLayoutServices> result = lookupService.getAllFlashStorageLayoutServices();

        // Log exit
        Helper.logExit(getLogger(), signature, new Object[] {result});

        return result;
    }

    /**
     * Returns all SourceVnxType modules.
     *
     * @return Whole list of lookup values, may be empty
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     */
    @RequestMapping(value = "lookup/sourceVnxTypes", method = RequestMethod.GET)
    @ResponseBody
    public List<SourceVnxType> getAllSourceVnxTypes() throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#getAllSourceVnxTypes()";

        // Log entry
        Helper.logEntrance(getLogger(), signature, null, null);

        List<SourceVnxType> result = lookupService.getAllSourceVnxTypes();

        // Log exit
        Helper.logExit(getLogger(), signature, new Object[] {result});

        return result;
    }

    /**
     * Returns all SynchronousMode modules.
     *
     * @return Whole list of lookup values, may be empty
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     * @since SRT Release Assembly - Unified Tab
     */
    @RequestMapping(value = "lookup/synchronousModes", method = RequestMethod.GET)
    @ResponseBody
    public List<SynchronousMode> getAllSynchronousModes() throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#getAllSynchronousModes()";

        // Log entry
        Helper.logEntrance(getLogger(), signature, null, null);

        List<SynchronousMode> result = lookupService.getAllSynchronousModes();

        // Log exit
        Helper.logExit(getLogger(), signature, new Object[] {result});

        return result;
    }

    /**
     * Returns all ReplicationFailoverLevel modules.
     *
     * @return Whole list of lookup values, may be empty
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     * @since SRT Release Assembly - Unified Tab
     */
    @RequestMapping(value = "lookup/replicationFailoverLevels", method = RequestMethod.GET)
    @ResponseBody
    public List<ReplicationFailoverLevel> getAllReplicationFailoverLevels() throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#getAllReplicationFailoverLevels()";

        // Log entry
        Helper.logEntrance(getLogger(), signature, null, null);

        List<ReplicationFailoverLevel> result = lookupService.getAllReplicationFailoverLevels();

        // Log exit
        Helper.logExit(getLogger(), signature, new Object[] {result});

        return result;
    }

    /**
     * Returns all the options for the given lookup type modules.
     *
     * @param <T>
     *            the generic class type
     * @param className
     *            the lookup entity class name
     * @return Whole list of lookup values, may be empty
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     * @since SRT Phase 3 Merge Assembly
     */
    @SuppressWarnings("unchecked")
    @RequestMapping(value = "lookup/class/{className}", method = RequestMethod.GET)
    @ResponseBody
    public <T extends LookupEntity> List<T> getAllLookupsByClass(@PathVariable String className)
        throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#getAllLookupsByClass()";

        // Log entry
        Helper.logEntrance(getLogger(), signature, new String[]{"className"}, new Object[]{className});

        Class<T> cls = (Class<T>) classMapping.get(className);
        if (cls == null) {
            ServiceRequestToolException error = new ServiceRequestToolException("Invalid type parameter.");
            Helper.logException(getLogger(), signature, error);
            throw error;
        }

        List<T> result = lookupService.getLookupEnities(cls);
        // Log exit
        Helper.logExit(getLogger(), signature, new Object[] {result});
        return result;
    }

    /**
     * This method checks whether the instance of the class was initialized properly.
     *
     * @throws ServiceRequestToolConfigurationException
     *             if lookupService is null
     */
    @PostConstruct
    protected void checkInit() {
        Helper.checkState(lookupService == null, "'lookupService' can't be null.");
    }

    /**
     * <p>
     * Sets the value to lookupService field.
     * </p>
     *
     * @param lookupService
     *            the value of lookupService to set
     */
    public void setLookupService(LookupService lookupService) {
        this.lookupService = lookupService;
    }

}

/*
 * This code is copyright (c) 2013 - 2015 EMC Corporation.
 */
package com.emc.gs.tools.srf.web;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.emc.gs.tools.srf.AuthorizationException;
import com.emc.gs.tools.srf.ServiceRequestToolConfigurationException;
import com.emc.gs.tools.srf.model.Customer;
import com.emc.gs.tools.srf.model.EntityOperationLog;
import com.emc.gs.tools.srf.model.Operation;
import com.emc.gs.tools.srf.model.OperationLog;
import com.emc.gs.tools.srf.model.Profile;
import com.emc.gs.tools.srf.model.Request;
import com.emc.gs.tools.srf.services.CustomerService;
import com.emc.gs.tools.srf.services.OperationLogService;
import com.emc.gs.tools.srf.services.ProfileService;
import com.emc.gs.tools.srf.services.RequestService;
import com.emc.gs.tools.srf.services.ServiceRequestToolException;
import com.emc.gs.tools.srf.services.impl.Helper;

/**
 * <p>
 * This is operation log controller to query operation logs for data synchronization.
 * </p>
 *
 * <p>
 * <strong>Thread safety</strong>: This class is effectively thread safe after configuration, the
 * configuration is done in a thread safe manner.
 * </p>
 *
 * <p>
 * <strong>Changes V1.1:</strong>
 * <strong>SRT Phase 4 - ET Assembly 2</strong>
 * <ul>
 * <li>Change the get() method to accept entity id and begin sequence parameters
 *  and return list of EntityOperationLog DTO.</li>
 * </ul>
 * </p>
 *
 * <p>
 * <strong>Changes V1.2:</strong>
 * <strong>SRT 1.1 Approval Process Assembly</strong>
 * <ul>
 * <li>Added allUserLogs param to get method.</li>
 * </ul>
 * </p>
 *
 * @author zsudraco, MonicaMuranyi
 * @version 1.2
 */
@Controller
public class OperationLogController extends BaseController {
    /**
     * <p>
     * Represents the class name.
     * </p>
     */
    private static final String CLASSNAME = OperationLogController.class.getName();

    /**
     * Represents the operationLogService. It is modified by
     * setter. It is injected by Spring. It can not be null after injected.
     */
    private OperationLogService operationLogService;

    /**
     * Represents the ProfileService instance for retrieving profiles. It is modified by setter. It is injected by Spring.
     * It can not be null after injected.
     * @since SRT Phase 4 - ET Assembly 2
     */
    private ProfileService profileService;

    /**
     * Represents the RequestService instance for retrieving requests. It is modified by setter. It is injected by Spring.
     * It can not be null after injected.
     * @since SRT Phase 4 - ET Assembly 2
     */
    private RequestService requestService;

    /**
     * Represents the CustomerService instance for retrieving customers. It is modified by setter. It is injected by Spring.
     * It can not be null after injected.
     * @since SRT Phase 4 - ET Assembly 2
     */
    private CustomerService customerService;

    /**
     * Default constructor.
     */
    public OperationLogController() {
        // empty
    }

    /**
     * Gets all logs for the specified entity type, entity ID and begin sequence.
     *
     * @param entityType
     *            the entityTyp of the logs to retrieve
     * @param entityId
     *            the entityId for the search, if present then only
     *            log for that entity ID will be returned
     * @param beginSeq
     *            the begin sequence for the search, if present then only
     *            logs newer than this sequence will be returned
     * @return The list of the matching operation logs
     * @throws IllegalArgumentException
     *             if entityType is null or empty
     * @throws AuthorizationException
     *             if user is not allowed to get operation log
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     */
    @SuppressWarnings({"rawtypes", "unchecked"})
    @RequestMapping(value = "operationLogs", method = RequestMethod.GET)
    @ResponseBody
    @Transactional
    public List<EntityOperationLog<?>> get(@RequestParam String entityType,
            @RequestParam(value = "entityId", required = false) Long entityId,
            @RequestParam(value = "beginSeq", required = false) Long beginSeq,
            @RequestParam(value = "allUserLogs", required = false) boolean allUserLogs) throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#get(String entityType, Long entityId, Long beginSeq, boolean allUserLogs)";
        Logger logger = getLogger();

        // Log entry
        Helper.logEntrance(logger, signature, new String[]{"entityType", "entityId", "beginSeq"},
                new Object[]{entityType, entityId, beginSeq});

        Helper.checkStrNullEmpty(logger, signature, entityType, "entityType");

        List<OperationLog> result = operationLogService.get(entityType, entityId, beginSeq, allUserLogs);

        List<EntityOperationLog<?>> entityLogs = new ArrayList<EntityOperationLog<?>>();
        for (OperationLog log : result) {
            EntityOperationLog entityLog = new EntityOperationLog();
            entityLog.setOperationLog(log);

            if (log.getOperation() != Operation.DELETE) {
                if (Customer.class.getSimpleName().equals(entityType)) {
                    entityLog.setEntity(customerService.get(log.getEntityId()));
                } else if (Profile.class.getSimpleName().equals(entityType)) {
                    entityLog.setEntity(profileService.get(log.getEntityId()));
                } if (Request.class.getSimpleName().equals(entityType)) {
                    entityLog.setEntity(requestService.get(log.getEntityId()));
                }
            }

            entityLogs.add(entityLog);
        }

        // Log exit
        Helper.logExit(logger, signature, new Object[]{entityLogs});
        return entityLogs;
    }

    /**
     * This method checks whether the instance of the class was initialized properly.
     *
     * @throws ServiceRequestToolConfigurationException
     *             if operationLogService/requestService/customerService/profileService is null
     */
    @PostConstruct
    protected void checkInit() {
        Helper.checkState(operationLogService == null, "'operationLogService' can't be null.");
        Helper.checkState(requestService == null, "'requestService' can't be null.");
        Helper.checkState(customerService == null, "'customerService' can't be null.");
        Helper.checkState(profileService == null, "'profileService' can't be null.");
    }

    /**
     * <p>
     * Sets the value to operationLogService field.
     * </p>
     *
     * @param operationLogService the operationLogService to set
     */
    public void setOperationLogService(OperationLogService operationLogService) {
        this.operationLogService = operationLogService;
    }

    /**
     * Setter method for property <tt>profileService</tt>.
     *
     * @param profileService
     *            value to be assigned to property profileService
     * @since SRT Phase 4 - ET Assembly 2
     */
    public void setProfileService(ProfileService profileService) {
        this.profileService = profileService;
    }

    /**
     * Setter method for property <tt>requestService</tt>.
     *
     * @param requestService
     *            value to be assigned to property requestService
     * @since SRT Phase 4 - ET Assembly 2
     */
    public void setRequestService(RequestService requestService) {
        this.requestService = requestService;
    }

    /**
     * Setter method for property <tt>customerService</tt>.
     *
     * @param customerService
     *            value to be assigned to property customerService
     * @since SRT Phase 4 - ET Assembly 2
     */
    public void setCustomerService(CustomerService customerService) {
        this.customerService = customerService;
    }
}

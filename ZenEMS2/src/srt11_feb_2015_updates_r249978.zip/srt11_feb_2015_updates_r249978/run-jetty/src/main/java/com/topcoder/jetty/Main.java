package com.topcoder.jetty;

import java.awt.Desktop;
import java.io.File;
import java.io.InputStream;
import java.net.URI;

import org.eclipse.jetty.server.Server;
import org.eclipse.jetty.server.handler.ContextHandlerCollection;
import org.eclipse.jetty.webapp.WebAppContext;
import org.eclipse.jetty.xml.XmlConfiguration;

/**
 * Main class
 */
public class Main {

    public static void main(String[] args) throws Exception {
        if (args == null || args.length < 3) {
            System.err.println("Invalid arguments. Database URL, War file and attachments folder must be supplied.");
            return;
        }

        System.out.println("==================================");
        System.out.println("Database url: " + args[0]);
        System.out.println("War file: " + args[1]);
        System.out.println("Attachments folder: " + args[2]);
        System.out.println("==================================");

        System.setProperty("jdbc.url", args[0]);
        System.setProperty("attachments.folder", args[2]);

        Server server = new Server();

        InputStream config = Main.class.getResourceAsStream("/jetty.xml");

        XmlConfiguration xmlConfiguration = new XmlConfiguration(config);
        xmlConfiguration.configure(server);

        ContextHandlerCollection contexts = server.getChildHandlerByClass(ContextHandlerCollection.class);

        WebAppContext context = new WebAppContext();
        context.setServer(server);
        context.setContextPath("/srt");
        context.setWar(args[1]);

        if (args.length > 3) {
            context.setTempDirectory(new File(args[3]));
        }
        contexts.addHandler(context);

        try {
            server.start();
            URI url = new URI("http://localhost:8080/srt/");
            Desktop.getDesktop().browse(url);
            System.in.read();
            server.join();
        } catch (Exception e) {
            e.printStackTrace();
            System.exit(100);
        }
    }
}

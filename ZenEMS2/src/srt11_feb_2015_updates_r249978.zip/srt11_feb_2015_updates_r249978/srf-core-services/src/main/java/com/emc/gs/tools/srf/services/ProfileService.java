/*
 * This code is copyright (c) 2013 - 2015 EMC Corporation.
 */
package com.emc.gs.tools.srf.services;

import com.emc.gs.tools.srf.model.Profile;
import com.emc.gs.tools.srf.model.ProfileSearchCriteria;
import com.emc.gs.tools.srf.model.SearchResult;

/**
 * <p>
 * This interface defines a contract for managing a profile. It is simply extends GenericService to provide necessary
 * create, update, delete and get methods.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: The implementation are required to be thread safe.
 * </p>
 *
 * <p>
 * <strong>Changes V1.1:</strong>
 * <strong>SRT Release Assembly - Unified Tab</strong>
 * <ul>
 * <li>Add getDefaultProfile() method</li>
 * </ul>
 * </p>
 *
 * <p>
 * <strong>Changes V1.2:</strong>
 * <strong>SRT 1.1 Approval Process Assembly</strong>
 * <ul>
 * <li>Added search related methods.</li>
 * </ul>
 * </p>
 *
 * @author faeton, stevenfrog, MonicaMuranyi
 * @version 1.2
 */
public interface ProfileService extends GenericService<Profile> {
    /**
     * Retrieves default profile.
     *
     * @return The default profile, if there's no default profile
     * @throws IllegalArgumentException
     *             if id is not positive
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     * @since SRT Release Assembly - Unified Tab
     */
    public Profile getDefaultProfile() throws ServiceRequestToolException;
    
    /**
     * Search profiles based on the search criteria.
     *
     * @throws IllegalArgumentException
     *             if criteria is null, or if criteria.pageNumber is positive, criteria.pageSize is not positive
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     * @param criteria
     *            the search criteria
     * @return the search result
     * @since 1.2
     */
    public SearchResult<Profile> search(ProfileSearchCriteria criteria) throws ServiceRequestToolException;
}

/*
 * This code is copyright (c) 2014 EMC Corporation.
 */
package com.emc.gs.tools.srf;

/**
 * <p>
 * This exception is thrown when a user request access to an entity, which doesn't belong to him.
 * </p>
 *
 * <p>
 * <strong>Thread safety</strong>: exception class is not thread safe.
 * </p>
 *
 * @author zsudraco, TCSASSEMBLER
 * @version 1.0
 */
public class AuthorizationException extends RuntimeException {
    /**
     * The serial version UID.
     */
    private static final long serialVersionUID = -655458736874156643L;

    /**
     * Creates the exception with the provided message.
     *
     * @param message
     *            the error message.
     */
    public AuthorizationException(String message) {
        super(message);
    }

    /**
     * Creates the exception with the provided message and cause.
     *
     * @param message
     *            the error message.
     * @param cause
     *            the error cause.
     */
    public AuthorizationException(String message, Throwable cause) {
        super(message, cause);
    }
}

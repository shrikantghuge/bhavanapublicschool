/*
 * This code is copyright (c) 2015 EMC Corporation.
 */
package com.emc.gs.tools.srf.services;

/**
 * <p>
 * This service defines a method to decide if a user has user management permission.
 * </p>
 * 
 * <p>
 * <strong>Thread safety</strong>: The implementation are required to be thread safe.
 * </p>
 * 
 * @author TCSASSEMBLER
 * @version 1.0
 * @since SRT 1.1 Approval Process Assembly
 */
public interface UserAdminService {

    
    /**
     * Decides if a user has user management permission.
     *
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     * @param userIdentifier
     *            the user's identifier
     * @return true if the user has management user permission; false otherwise
     */
    public boolean hasUserManagementPermission(String userIdentifier) throws ServiceRequestToolException;
}

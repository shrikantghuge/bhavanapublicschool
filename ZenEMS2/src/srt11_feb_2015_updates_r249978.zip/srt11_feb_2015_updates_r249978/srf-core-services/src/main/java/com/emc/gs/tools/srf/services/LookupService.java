/*
 * This code is copyright (c) 2013 - 2014 EMC Corporation.
 */
package com.emc.gs.tools.srf.services;

import java.util.List;

import com.emc.gs.tools.srf.model.ClearanceLevel;
import com.emc.gs.tools.srf.model.ExpenseType;
import com.emc.gs.tools.srf.model.GeoState;
import com.emc.gs.tools.srf.model.Geography;
import com.emc.gs.tools.srf.model.IdentifiableEntity;
import com.emc.gs.tools.srf.model.KnowledgeTransferLevel;
import com.emc.gs.tools.srf.model.MeetingStatus;
import com.emc.gs.tools.srf.model.ProjectType;
import com.emc.gs.tools.srf.model.ProjectRegulatoryType;
import com.emc.gs.tools.srf.model.RequestType;
import com.emc.gs.tools.srf.model.RiskLevel;
import com.emc.gs.tools.srf.model.ServicesAgreementType;
import com.emc.gs.tools.srf.model.SowLanguage;
import com.emc.gs.tools.srf.model.SowType;
import com.emc.gs.tools.srf.model.TestAcceptancePlanType;
import com.emc.gs.tools.srf.model.bc.AreaSizingType;
import com.emc.gs.tools.srf.model.bc.ArrayModel;
import com.emc.gs.tools.srf.model.bc.BcvCloneOption;
import com.emc.gs.tools.srf.model.bc.ConfigChangeType;
import com.emc.gs.tools.srf.model.bc.DocumentationLevel;
import com.emc.gs.tools.srf.model.bc.MigrationTestNumber;
import com.emc.gs.tools.srf.model.bc.MvConnectionType;
import com.emc.gs.tools.srf.model.bc.MvMode;
import com.emc.gs.tools.srf.model.bc.NetworkLinkStatus;
import com.emc.gs.tools.srf.model.bc.PostSalesCompletionQualifier;
import com.emc.gs.tools.srf.model.bc.PushPullOption;
import com.emc.gs.tools.srf.model.bc.ReplicationManagerImplementation;
import com.emc.gs.tools.srf.model.bc.ReplicationManagerProductSpecificPreparation;
import com.emc.gs.tools.srf.model.bc.ScriptingLevel;
import com.emc.gs.tools.srf.model.bc.ScriptingLevelOption;
import com.emc.gs.tools.srf.model.bc.SrdfConnectionType;
import com.emc.gs.tools.srf.model.bc.SrdfMode;
import com.emc.gs.tools.srf.model.bc.SrdfStaticDynamicType;
import com.emc.gs.tools.srf.model.bc.SymmetrixModel;
import com.emc.gs.tools.srf.model.dpad.MeditechBackupType;
import com.emc.gs.tools.srf.model.dpad.NetworkerDatazoneSize;
import com.emc.gs.tools.srf.model.engagement.DeliveryCountry;
import com.emc.gs.tools.srf.model.estimate.Competency;
import com.emc.gs.tools.srf.model.infrastructure.EmcMigrationInvolvement;
import com.emc.gs.tools.srf.model.infrastructure.EnvironmentArrayType;
import com.emc.gs.tools.srf.model.infrastructure.EnvironmentDeviceType;
import com.emc.gs.tools.srf.model.infrastructure.EnvironmentGatherer;
import com.emc.gs.tools.srf.model.infrastructure.FlashStorageLayoutServices;
import com.emc.gs.tools.srf.model.infrastructure.HostSoftwareInstaller;
import com.emc.gs.tools.srf.model.infrastructure.MigrationWorker;
import com.emc.gs.tools.srf.model.infrastructure.SanImplementator;
import com.emc.gs.tools.srf.model.infrastructure.UnifiedConversionType;
import com.emc.gs.tools.srf.model.infrastructure.VnxClariionInstallType;
import com.emc.gs.tools.srf.model.infrastructure.VnxInstallProtocolSubType;
import com.emc.gs.tools.srf.model.infrastructure.VnxInstallProtocolType;
import com.emc.gs.tools.srf.model.infrastructure.VolumeSizeChange;
import com.emc.gs.tools.srf.model.unified.CelerraArrayType;
import com.emc.gs.tools.srf.model.unified.CelerraModel;
import com.emc.gs.tools.srf.model.unified.CelerraSetupType;
import com.emc.gs.tools.srf.model.unified.CelerraVnxModel;
import com.emc.gs.tools.srf.model.unified.GatewayStorageType;
import com.emc.gs.tools.srf.model.unified.IOInterfaceModule;
import com.emc.gs.tools.srf.model.unified.MigrationMethod;
import com.emc.gs.tools.srf.model.unified.RackAndStackOption;
import com.emc.gs.tools.srf.model.unified.ReplicationFailoverLevel;
import com.emc.gs.tools.srf.model.unified.SourceVnxType;
import com.emc.gs.tools.srf.model.unified.SynchronousMode;
import com.emc.gs.tools.srf.model.unified.TargetCelerra;
import com.emc.gs.tools.srf.model.unified.TargetCelerraType;
import com.emc.gs.tools.srf.model.unified.VNXProtocol;

/**
 * <p>
 * This interface defines a generic contract for retrieving full lists of lookup
 * values.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: The implementation are required to be thread
 * safe.
 * </p>
 * 
 * <p>
 * <strong>Changes V1.1:</strong> <strong>SRT Release Assembly - Base</strong>
 * <ul>
 * <li>Release_assembly_tasks.xls Row#8: Added lookup for sow types</li>
 * </ul>
 * </p>
 * 
 * <p>
 * <strong>Changes V1.2:</strong> <strong>SRT Release Assembly - Unified
 * Tab</strong>
 * <ul>
 * <li>Add getAllSynchronousModes() and getAllReplicationFailoverLevels()
 * methods</li>
 * </ul>
 * </p>
 * 
 * <p>
 * <strong>Changes V1.3:</strong>
 * <ul>
 * <li>Removed getAllMicrocodeFamilies, getAllFlarecodeFamilies, getAllMonitoringScripts, 
 * getAllNetworkConnectionTypes, getAllMdlDlmLibraryTypes, getAllTargetTfR2Devices methods.</li>
 * </ul>
 * </p>
 * 
 * <p>
 * <strong>Changes V1.4:</strong>
 * <strong>https://apps.topcoder.com/bugs/browse/SRT-35</strong>
 * <ul>
 * <li>Added getAllRecoverPointLicenses, getAllReplicationManagerProductSpecificPreparations, getAllVNXProtocols, 
 * getAllMigrationMethods methods.</li>
 * </ul>
 * </p>
 *
 * <p>
 * <strong>Changes V1.5:</strong> <strong>SRT Phase 3-1 - CTA Rainfinity and MSS Tabs Assembly</strong>
 * <ul>
 * <li>Added a common getLookupEnities() method.</li>
 * </ul>
 * </p>
 *
 * <p>
 * <strong>Changes V1.6:</strong> <strong>SRT Phase 3-5 - BRS Tabs Part 1 Assembly</strong>
 * <ul>
 * <li>Delete getAllDataMobilityImplementations() method.</li>
 * <li>Delete getAllInstallTypes() method.</li>
 * <li>Delete getAllRecoverPointLicenses() method.</li>
 * <li>Delete getAllSplitterOptions() method.</li>
 * <li>Delete getAllJournalSizings() method.</li>
 * <li>Delete getAllSplitterTypes() method.</li>
 * </ul>
 * </p>
 *
 * <p>
 * Version 1.7 (SRT Phase 4 - ET Release Assembly) Change notes:
 *   <ol>
 *     <li>Added {@link #getAllProjectRegulatoryTypes()} method.</li>
 *     <li>Added {@link #getAllExpenseTypes()} method.</li>
 *   </ol>
 * </p>
 *
 * <p>
 * Version 1.8 (SRT 4 OCT2014 Updates Part 1 Assembly) Change notes:
 *   <ol>
 *     <li>Added {@link #getAllNetworkerDatazoneSizes()} method.</li>
 *     <li>Added {@link #getAllMeditechBackupTypes()} method.</li>
 *   </ol>
 * </p>
 * 
 * <p>
 * Version 1.9 (SRT 1.1 DEC 2014 Updates Assembly) Change notes:
 *   <ol>
 *     <li>Replaced {@link #getAllCountries()} method with {@link #getAllDeliveryCountries()} method.</li>
 *   </ol>
 * </p>
 *
 * <p>
 * Version 1.10 Change notes:
 *   <ol>
 *     <li>Added {@link #getCompetenciesForLOB(long)} method.</li>
 *   </ol>
 * </p>
 * 
 * @author faeton, stevenfrog, MonicaMuranyi, isv
 * @version 1.10
 */
public interface LookupService {

    /**
    * Get the lookup entities from DB.
    *
    * @param <T>
    *            the lookup entity class type
    * @param clazz
    *            the class
    * @return the lookup entities
     * @throws IllegalArgumentException
     *             if clazz is null
    * @throws ServiceRequestToolException
    *             if any error occurs
    */
   public <T extends IdentifiableEntity> List<T> getLookupEnities(Class<T> clazz) throws ServiceRequestToolException;

   /**
     * Returns all SourceVnxType.
     * 
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     * @return Whole list of lookup values, may be empty.
     */
    public List<SourceVnxType> getAllSourceVnxTypes() throws ServiceRequestToolException;

    /**
     * Returns all Delivery Countries.
     * 
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     * @return Whole list of lookup values, may be empty.
     */
    public List<DeliveryCountry> getAllDeliveryCountries() throws ServiceRequestToolException;

    /**
     * Returns all Geographies.
     * 
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     * @return Whole list of lookup values, may be empty.
     */
    public List<Geography> getAllGeographies() throws ServiceRequestToolException;

    /**
     * Returns all services agreement types.
     * 
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     * @return Whole list of lookup values, may be empty.
     */
    public List<ServicesAgreementType> getAllServicesAgreementTypes() throws ServiceRequestToolException;

    /**
     * Returns all Sow types.
     * 
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     * @return Whole list of lookup values, may be empty.
     * @since 1.1
     */
    public List<SowType> getAllSowTypes() throws ServiceRequestToolException;

    /**
     * Returns all request types.
     * 
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     * @return Whole list of lookup values, may be empty.
     */
    public List<RequestType> getAllRequestTypes() throws ServiceRequestToolException;

    /**
     * Returns all risk levels.
     * 
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     * @return Whole list of lookup values, may be empty.
     */
    public List<RiskLevel> getAllRiskLevels() throws ServiceRequestToolException;

    /**
     * Returns all sow languages.
     * 
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     * @return Whole list of lookup values, may be empty.
     */
    public List<SowLanguage> getAllSowLanguages() throws ServiceRequestToolException;

    /**
     * Returns all clearance levels.
     * 
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     * @return Whole list of lookup values, may be empty.
     */
    public List<ClearanceLevel> getAllClearanceLevels() throws ServiceRequestToolException;

    /**
     * Returns all project types.
     * 
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     * @return Whole list of lookup values, may be empty.
     */
    public List<ProjectType> getAllProjectTypes() throws ServiceRequestToolException;

    /**
     * <p>Gets the list of available project regulatory types.</p>
     *
     * @return a <code>List</code> listing the available project regulatory types, may be empty. 
     * @throws ServiceRequestToolException if any other error occurred during the operation.
     * @since 1.7
     */
    public List<ProjectRegulatoryType> getAllProjectRegulatoryTypes() throws ServiceRequestToolException;

    /**
     * <p>Gets the list of available expense types.</p>
     *
     * @return a <code>List</code> listing the available expense types, may be empty.
     * @throws ServiceRequestToolException if any other error occurred during the operation.
     * @since 1.7
     */
    public List<ExpenseType> getAllExpenseTypes() throws ServiceRequestToolException;

    /**
     * Returns all meeting statuses.
     * 
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     * @return Whole list of lookup values, may be empty.
     */
    public List<MeetingStatus> getAllMeetingStatuses() throws ServiceRequestToolException;

    /**
     * Returns all environment gatherers .
     * 
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     * @return Whole list of lookup values, may be empty.
     */
    public List<EnvironmentGatherer> getAllEnvironmentGatherers() throws ServiceRequestToolException;

    /**
     * Returns all host software installers.
     * 
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     * @return Whole list of lookup values, may be empty.
     */
    public List<HostSoftwareInstaller> getAllHostSoftwareInstallers() throws ServiceRequestToolException;

    /**
     * Returns all san implementators.
     * 
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     * @return Whole list of lookup values, may be empty.
     */
    public List<SanImplementator> getAllSanImplementators() throws ServiceRequestToolException;

    /**
     * Returns all environment array types.
     * 
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     * @return Whole list of lookup values, may be empty.
     */
    public List<EnvironmentArrayType> getAllEnvironmentArrayTypes() throws ServiceRequestToolException;

    /**
     * Returns all environment device types.
     * 
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     * @return Whole list of lookup values, may be empty.
     */
    public List<EnvironmentDeviceType> getAllEnvironmentDeviceTypes() throws ServiceRequestToolException;

    /**
     * Returns all migration workers.
     * 
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     * @return Whole list of lookup values, may be empty.
     */
    public List<MigrationWorker> getAllMigrationWorkers() throws ServiceRequestToolException;

    /**
     * Returns all volume size changes.
     * 
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     * @return Whole list of lookup values, may be empty.
     */
    public List<VolumeSizeChange> getAllVolumeSizeChanges() throws ServiceRequestToolException;

    /**
     * Returns all emc migration involvements.
     * 
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     * @return Whole list of lookup values, may be empty.
     */
    public List<EmcMigrationInvolvement> getAllEmcMigrationInvolvements() throws ServiceRequestToolException;

    /**
     * Returns all scripting levels.
     * 
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     * @return Whole list of lookup values, may be empty.
     */
    public List<ScriptingLevel> getAllScriptingLevels() throws ServiceRequestToolException;

    /**
     * Returns all test acceptance plan types.
     * 
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     * @return Whole list of lookup values, may be empty.
     */
    public List<TestAcceptancePlanType> getAllTestAcceptancePlanTypes() throws ServiceRequestToolException;

    /**
     * Returns all documentation levels.
     * 
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     * @return Whole list of lookup values, may be empty.
     */
    public List<DocumentationLevel> getAllDocumentationLevels() throws ServiceRequestToolException;

    /**
     * Returns all knowledge transfer levels.
     * 
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     * @return Whole list of lookup values, may be empty.
     */
    public List<KnowledgeTransferLevel> getAllKnowledgeTransferLevels() throws ServiceRequestToolException;

    /**
     * Returns all push/pull options.
     * 
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     * @return Whole list of lookup values, may be empty.
     */
    public List<PushPullOption> getAllPushPullOptions() throws ServiceRequestToolException;

    /**
     * Returns all post sales completion qualifiers.
     * 
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     * @return Whole list of lookup values, may be empty.
     */
    public List<PostSalesCompletionQualifier> getAllPostSalesCompletionQualifiers() throws ServiceRequestToolException;

    /**
     * Returns all migration test numbers.
     * 
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     * @return Whole list of lookup values, may be empty.
     */
    public List<MigrationTestNumber> getAllMigrationTestNumbers() throws ServiceRequestToolException;

    /**
     * Returns all symmetrix models.
     * 
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     * @return Whole list of lookup values, may be empty.
     */
    public List<SymmetrixModel> getAllSymmetrixModels() throws ServiceRequestToolException;

    /**
     * Returns all srdf modes.
     * 
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     * @return Whole list of lookup values, may be empty.
     */
    public List<SrdfMode> getAllSrdfModes() throws ServiceRequestToolException;

    /**
     * Returns all srdf connection types.
     * 
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     * @return Whole list of lookup values, may be empty.
     */
    public List<SrdfConnectionType> getAllSrdfConnectionTypes() throws ServiceRequestToolException;

    /**
     * Returns all array models.
     * 
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     * @return Whole list of lookup values, may be empty.
     */
    public List<ArrayModel> getAllArrayModels() throws ServiceRequestToolException;

    /**
     * Returns all MV modes.
     * 
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     * @return Whole list of lookup values, may be empty.
     */
    public List<MvMode> getAllMvModes() throws ServiceRequestToolException;

    /**
     * Returns all MVC connection types.
     * 
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     * @return Whole list of lookup values, may be empty.
     */
    public List<MvConnectionType> getAllMvConnectionTypes() throws ServiceRequestToolException;

    /**
     * Returns all srdf static/dynamic types.
     * 
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     * @return Whole list of lookup values, may be empty.
     */
    public List<SrdfStaticDynamicType> getAllSrdfStaticDynamicTypes() throws ServiceRequestToolException;

    /**
     * Returns all network link statuses.
     * 
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     * @return Whole list of lookup values, may be empty.
     */
    public List<NetworkLinkStatus> getAllNetworkLinkStatuses() throws ServiceRequestToolException;

    /**
     * Returns all area sizing types.
     *
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     * @return Whole list of lookup values, may be empty.
     */
    public List<AreaSizingType> getAllAreaSizingTypes() throws ServiceRequestToolException;
    
    /**
     * Returns all bcv clone options.
     * 
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     * @return Whole list of lookup values, may be empty.
     */
    public List<BcvCloneOption> getAllBcvCloneOptions() throws ServiceRequestToolException;

    /**
     * Returns all config change types.
     * 
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     * @return Whole list of lookup values, may be empty.
     */
    public List<ConfigChangeType> getAllConfigChangeTypes() throws ServiceRequestToolException;

    /**
     * Returns all replication manager product specific preparations.
     * 
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     * @return Whole list of lookup values, may be empty.
     */
    public List<ReplicationManagerProductSpecificPreparation> getAllReplicationManagerProductSpecificPreparations()
            throws ServiceRequestToolException;
    
    /**
     * Returns all replication manager implementations.
     * 
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     * @return Whole list of lookup values, may be empty.
     */
    public List<ReplicationManagerImplementation> getAllReplicationManagerImplementations()
            throws ServiceRequestToolException;

    /**
     * Returns all celerra models.
     * 
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     * @return Whole list of lookup values, may be empty.
     */
    public List<CelerraModel> getAllCelerraModels() throws ServiceRequestToolException;
    
    /**
     * Returns all vnx protocols.
     * 
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     * @return Whole list of lookup values, may be empty.
     */
    public List<VNXProtocol> getAllVNXProtocols() throws ServiceRequestToolException;

    /**
     * Returns all rack and stack options.
     * 
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     * @return Whole list of lookup values, may be empty.
     */
    public List<RackAndStackOption> getAllRackAndStackOptions() throws ServiceRequestToolException;

    /**
     * Returns all gateway storage types.
     * 
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     * @return Whole list of lookup values, may be empty.
     */
    public List<GatewayStorageType> getAllGatewayStorageTypes() throws ServiceRequestToolException;

    /**
     * Returns all celerra setup types.
     * 
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     * @return Whole list of lookup values, may be empty.
     */
    public List<CelerraSetupType> getAllCelerraSetupTypes() throws ServiceRequestToolException;

    /**
     * Returns all target celerra types.
     * 
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     * @return Whole list of lookup values, may be empty.
     */
    public List<TargetCelerraType> getAllTargetCelerraTypes() throws ServiceRequestToolException;

    /**
     * Returns all celerra array types.
     * 
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     * @return Whole list of lookup values, may be empty.
     */
    public List<CelerraArrayType> getAllCelerraArrayTypes() throws ServiceRequestToolException;

    /**
     * Returns all target celerras.
     * 
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     * @return Whole list of lookup values, may be empty.
     */
    public List<TargetCelerra> getAllTargetCelerras() throws ServiceRequestToolException;

    /**
     * Returns all celerra vnx models.
     * 
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     * @return Whole list of lookup values, may be empty.
     */
    public List<CelerraVnxModel> getAllCelerraVnxModels() throws ServiceRequestToolException;
    
    /**
     * Returns all migration methods models.
     * 
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     * @return Whole list of lookup values, may be empty.
     */
    public List<MigrationMethod> getAllMigrationMethods() throws ServiceRequestToolException;
    
    /**
     * Returns all vnx clariion install types.
     * 
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     * @return Whole list of lookup values, may be empty.
     */
    public List<VnxClariionInstallType> getAllVnxClariionInstallTypes() throws ServiceRequestToolException;

    /**
     * Returns all unified conversion types.
     * 
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     * @return Whole list of lookup values, may be empty.
     */
    public List<UnifiedConversionType> getAllUnifiedConversionTypes() throws ServiceRequestToolException;

    /**
     * Returns all vnx install protocol types.
     * 
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     * @return Whole list of lookup values, may be empty.
     */
    public List<VnxInstallProtocolType> getAllVnxInstallProtocolTypes() throws ServiceRequestToolException;

    /**
     * Returns all vnx install protocol sub type.
     * 
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     * @return Whole list of lookup values, may be empty.
     */
    public List<VnxInstallProtocolSubType> getAllVnxInstallProtocolSubTypes() throws ServiceRequestToolException;

    /**
     * Returns all IO interface modules.
     * 
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     * @return Whole list of lookup values, may be empty.
     */
    public List<IOInterfaceModule> getAllIOInterfaceModules() throws ServiceRequestToolException;

    /**
     * Returns all scripting level options.
     * 
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     * @return Whole list of lookup values, may be empty.
     */
    public List<ScriptingLevelOption> getAllScriptingLevelOptions() throws ServiceRequestToolException;

    /**
     * Returns all country states.
     * 
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     * @return Whole list of lookup values, may be empty.
     */
    public List<GeoState> getAllGeoStates() throws ServiceRequestToolException;

    /**
     * Returns all FlashStorageLayoutServices.
     * 
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     * @return Whole list of lookup values, may be empty.
     */
    public List<FlashStorageLayoutServices> getAllFlashStorageLayoutServices() throws ServiceRequestToolException;

    /**
     * Returns SynchronousMode.
     * 
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     * @return Whole list of lookup values, may be empty.
     * @since SRT Release Assembly - Unified Tab
     */
    public List<SynchronousMode> getAllSynchronousModes() throws ServiceRequestToolException;

    /**
     * Returns ReplicationFailoverLevel.
     * 
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     * @return Whole list of lookup values, may be empty.
     * @since SRT Release Assembly - Unified Tab
     */
    public List<ReplicationFailoverLevel> getAllReplicationFailoverLevels() throws ServiceRequestToolException;

    /**
     * <p>Gets the list of available Networker datazone sizes.</p>
     *
     * @return a <code>List</code> listing the available Networker datazone sizes, may be empty.
     * @throws ServiceRequestToolException if any other error occurred during the operation.
     * @since 1.8
     */
    public List<NetworkerDatazoneSize> getAllNetworkerDatazoneSizes() throws ServiceRequestToolException;

    /**
     * <p>Gets the list of available Meditech backup types.</p>
     *
     * @return a <code>List</code> listing the available Meditech backup types, may be empty.
     * @throws ServiceRequestToolException if any other error occurred during the operation.
     * @since 1.8
     */
    public List<MeditechBackupType> getAllMeditechBackupTypes() throws ServiceRequestToolException;

    /**
     * <p>Gets the list of competencies for specified LOB.</p>
     *
     * @param lobId a <code>long</code> providing the ID of a LOB to get competencies for.
     * @return a <code>List</code> listing the available competencies for specified LOB, may be empty.
     * @throws ServiceRequestToolException if any other error occurred during the operation.
     * @since 1.10
     */
    public List<Competency> getCompetenciesForLOB(long lobId) throws ServiceRequestToolException;
}

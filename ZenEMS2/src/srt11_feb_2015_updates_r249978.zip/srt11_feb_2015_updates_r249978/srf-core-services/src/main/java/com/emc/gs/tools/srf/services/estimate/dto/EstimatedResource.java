/*
 * This code is copyright (c) 2014 EMC Corporation.
 */
package com.emc.gs.tools.srf.services.estimate.dto;

import java.math.BigDecimal;

import com.emc.gs.tools.srf.model.estimate.LOBResource;

/**
 * <p>
 * This is EstimatedResource DTO class. It extends form LOBResource.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is mutable, it is not thread safety.
 * </p>
 * 
 * @author TCSASSEMBLER
 * @version 1.0
 * @since SRT Phase 4 - ET Assembly 1
 */
public class EstimatedResource extends LOBResource {

    /**
     * The Budgeted Hours.
     */
    private BigDecimal budgetedHours = BigDecimal.ZERO;

    /**
     * The Standard Bill Rate.
     */
    private BigDecimal standardBillRate = BigDecimal.ZERO;

    /**
     * The Bill Rate w/ Expense.
     */
    private BigDecimal billRateWithExpense = BigDecimal.ZERO;

    /**
     * The Standard Fees.
     */
    private BigDecimal standardFees = BigDecimal.ZERO;

    /**
     * The Discounted Fees.
     */
    private BigDecimal discountedFees = BigDecimal.ZERO;

    /* Cost data may be null */

    /**
     * The Hourly Std Cost Rate.
     */
    private BigDecimal hourlyStdCostRate;

    /**
     * The Standard Cost.
     */
    private BigDecimal standardCost;

    /**
     * The Gross Margin.
     */
    private BigDecimal grossMargin;

    /**
     * The Gross Margin percent.
     */
    private BigDecimal grossMarginPercent;

    /* Bill rate override may be null */

    /**
     * The Bill rate override percentage.
     */
    private BigDecimal billRateOverridePercent;

    /**
     * Constructor with the resource entity.
     * 
     * @param resource
     *            the resource entity
     */
    public EstimatedResource(LOBResource resource) {

        // Copy all properties
        super.setId(resource.getId());

        super.setRole(resource.getRole());
        super.setCompetency(resource.getCompetency());

        super.setStartDate(resource.getStartDate());
        super.setWeeks(resource.getWeeks());
        super.setEndDate(resource.getEndDate());
        super.setMonthHours(resource.getMonthHours());
        super.setContingencyPercent(resource.getContingencyPercent());

        super.setBillRateOverride(resource.getBillRateOverride());
        super.setProjectStaff(resource.getProjectStaff());
    }

    /**
     * Getter method for property <tt>standardBillRate</tt>.
     * 
     * @return property value of standardBillRate
     */
    public BigDecimal getStandardBillRate() {
        return standardBillRate;
    }

    /**
     * Setter method for property <tt>standardBillRate</tt>.
     * 
     * @param standardBillRate
     *            value to be assigned to property standardBillRate
     */
    public void setStandardBillRate(BigDecimal standardBillRate) {
        this.standardBillRate = standardBillRate;
    }

    /**
     * Getter method for property <tt>billRateWithExpense</tt>.
     * 
     * @return property value of billRateWithExpense
     */
    public BigDecimal getBillRateWithExpense() {
        return billRateWithExpense;
    }

    /**
     * Setter method for property <tt>billRateWithExpense</tt>.
     * 
     * @param billRateWithExpense
     *            value to be assigned to property billRateWithExpense
     */
    public void setBillRateWithExpense(BigDecimal billRateWithExpense) {
        this.billRateWithExpense = billRateWithExpense;
    }

    /**
     * Getter method for property <tt>budgetedHours</tt>.
     * 
     * @return property value of budgetedHours
     */
    public BigDecimal getBudgetedHours() {
        return budgetedHours;
    }

    /**
     * Setter method for property <tt>budgetedHours</tt>.
     * 
     * @param budgetedHours
     *            value to be assigned to property budgetedHours
     */
    public void setBudgetedHours(BigDecimal budgetedHours) {
        this.budgetedHours = budgetedHours;
    }

    /**
     * Getter method for property <tt>standardFees</tt>.
     * 
     * @return property value of standardFees
     */
    public BigDecimal getStandardFees() {
        return standardFees;
    }

    /**
     * Setter method for property <tt>standardFees</tt>.
     * 
     * @param standardFees
     *            value to be assigned to property standardFees
     */
    public void setStandardFees(BigDecimal standardFees) {
        this.standardFees = standardFees;
    }

    /**
     * Getter method for property <tt>discountedFees</tt>.
     * 
     * @return property value of discountedFees
     */
    public BigDecimal getDiscountedFees() {
        return discountedFees;
    }

    /**
     * Setter method for property <tt>discountedFees</tt>.
     * 
     * @param discountedFees
     *            value to be assigned to property discountedFees
     */
    public void setDiscountedFees(BigDecimal discountedFees) {
        this.discountedFees = discountedFees;
    }

    /**
     * Getter method for property <tt>hourlyStdCostRate</tt>.
     * 
     * @return property value of hourlyStdCostRate
     */
    public BigDecimal getHourlyStdCostRate() {
        return hourlyStdCostRate;
    }

    /**
     * Setter method for property <tt>hourlyStdCostRate</tt>.
     * 
     * @param hourlyStdCostRate
     *            value to be assigned to property hourlyStdCostRate
     */
    public void setHourlyStdCostRate(BigDecimal hourlyStdCostRate) {
        this.hourlyStdCostRate = hourlyStdCostRate;
    }

    /**
     * Getter method for property <tt>standardCost</tt>.
     * 
     * @return property value of standardCost
     */
    public BigDecimal getStandardCost() {
        return standardCost;
    }

    /**
     * Setter method for property <tt>standardCost</tt>.
     * 
     * @param standardCost
     *            value to be assigned to property standardCost
     */
    public void setStandardCost(BigDecimal standardCost) {
        this.standardCost = standardCost;
    }

    /**
     * Getter method for property <tt>grossMargin</tt>.
     * 
     * @return property value of grossMargin
     */
    public BigDecimal getGrossMargin() {
        return grossMargin;
    }

    /**
     * Setter method for property <tt>grossMargin</tt>.
     * 
     * @param grossMargin
     *            value to be assigned to property grossMargin
     */
    public void setGrossMargin(BigDecimal grossMargin) {
        this.grossMargin = grossMargin;
    }

    /**
     * Getter method for property <tt>grossMarginPercent</tt>.
     * 
     * @return property value of grossMarginPercent
     */
    public BigDecimal getGrossMarginPercent() {
        return grossMarginPercent;
    }

    /**
     * Setter method for property <tt>grossMarginPercent</tt>.
     * 
     * @param grossMarginPercent
     *            value to be assigned to property grossMarginPercent
     */
    public void setGrossMarginPercent(BigDecimal grossMarginPercent) {
        this.grossMarginPercent = grossMarginPercent;
    }

    /**
     * Getter method for property <tt>billRateOverridePercent</tt>.
     * 
     * @return property value of billRateOverridePercent
     */
    public BigDecimal getBillRateOverridePercent() {
        return billRateOverridePercent;
    }

    /**
     * Setter method for property <tt>billRateOverridePercent</tt>.
     * 
     * @param billRateOverridePercent
     *            value to be assigned to property billRateOverridePercent
     */
    public void setBillRateOverridePercent(BigDecimal billRateOverridePercent) {
        this.billRateOverridePercent = billRateOverridePercent;
    }

}

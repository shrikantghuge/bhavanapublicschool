/*
 * This code is copyright (c) 2013 - 2014 EMC Corporation.
 */
package com.emc.gs.tools.srf.services.impl;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceException;
import javax.persistence.TypedQuery;

import com.emc.gs.tools.srf.model.ExpenseType;
import com.emc.gs.tools.srf.model.dpad.MeditechBackupType;
import com.emc.gs.tools.srf.model.dpad.NetworkerDatazoneSize;
import com.emc.gs.tools.srf.model.engagement.DeliveryCountry;

import com.emc.gs.tools.srf.model.estimate.Competency;
import org.apache.log4j.Logger;

import com.emc.gs.tools.srf.model.ClearanceLevel;
import com.emc.gs.tools.srf.model.GeoState;
import com.emc.gs.tools.srf.model.Geography;
import com.emc.gs.tools.srf.model.IdentifiableEntity;
import com.emc.gs.tools.srf.model.KnowledgeTransferLevel;
import com.emc.gs.tools.srf.model.MeetingStatus;
import com.emc.gs.tools.srf.model.ProjectType;
import com.emc.gs.tools.srf.model.ProjectRegulatoryType;
import com.emc.gs.tools.srf.model.RequestType;
import com.emc.gs.tools.srf.model.RiskLevel;
import com.emc.gs.tools.srf.model.ServicesAgreementType;
import com.emc.gs.tools.srf.model.SowLanguage;
import com.emc.gs.tools.srf.model.SowType;
import com.emc.gs.tools.srf.model.TestAcceptancePlanType;
import com.emc.gs.tools.srf.model.bc.AreaSizingType;
import com.emc.gs.tools.srf.model.bc.ArrayModel;
import com.emc.gs.tools.srf.model.bc.BcvCloneOption;
import com.emc.gs.tools.srf.model.bc.ConfigChangeType;
import com.emc.gs.tools.srf.model.bc.DocumentationLevel;
import com.emc.gs.tools.srf.model.bc.MigrationTestNumber;
import com.emc.gs.tools.srf.model.bc.MvConnectionType;
import com.emc.gs.tools.srf.model.bc.MvMode;
import com.emc.gs.tools.srf.model.bc.NetworkLinkStatus;
import com.emc.gs.tools.srf.model.bc.PostSalesCompletionQualifier;
import com.emc.gs.tools.srf.model.bc.PushPullOption;
import com.emc.gs.tools.srf.model.bc.ReplicationManagerImplementation;
import com.emc.gs.tools.srf.model.bc.ReplicationManagerProductSpecificPreparation;
import com.emc.gs.tools.srf.model.bc.ScriptingLevel;
import com.emc.gs.tools.srf.model.bc.ScriptingLevelOption;
import com.emc.gs.tools.srf.model.bc.SrdfConnectionType;
import com.emc.gs.tools.srf.model.bc.SrdfMode;
import com.emc.gs.tools.srf.model.bc.SrdfStaticDynamicType;
import com.emc.gs.tools.srf.model.bc.SymmetrixModel;
import com.emc.gs.tools.srf.model.infrastructure.EmcMigrationInvolvement;
import com.emc.gs.tools.srf.model.infrastructure.EnvironmentArrayType;
import com.emc.gs.tools.srf.model.infrastructure.EnvironmentDeviceType;
import com.emc.gs.tools.srf.model.infrastructure.EnvironmentGatherer;
import com.emc.gs.tools.srf.model.infrastructure.FlashStorageLayoutServices;
import com.emc.gs.tools.srf.model.infrastructure.HostSoftwareInstaller;
import com.emc.gs.tools.srf.model.infrastructure.MigrationWorker;
import com.emc.gs.tools.srf.model.infrastructure.SanImplementator;
import com.emc.gs.tools.srf.model.infrastructure.UnifiedConversionType;
import com.emc.gs.tools.srf.model.infrastructure.VnxClariionInstallType;
import com.emc.gs.tools.srf.model.infrastructure.VnxInstallProtocolSubType;
import com.emc.gs.tools.srf.model.infrastructure.VnxInstallProtocolType;
import com.emc.gs.tools.srf.model.infrastructure.VolumeSizeChange;
import com.emc.gs.tools.srf.model.unified.CelerraArrayType;
import com.emc.gs.tools.srf.model.unified.CelerraModel;
import com.emc.gs.tools.srf.model.unified.CelerraSetupType;
import com.emc.gs.tools.srf.model.unified.CelerraVnxModel;
import com.emc.gs.tools.srf.model.unified.GatewayStorageType;
import com.emc.gs.tools.srf.model.unified.IOInterfaceModule;
import com.emc.gs.tools.srf.model.unified.MigrationMethod;
import com.emc.gs.tools.srf.model.unified.RackAndStackOption;
import com.emc.gs.tools.srf.model.unified.ReplicationFailoverLevel;
import com.emc.gs.tools.srf.model.unified.SourceVnxType;
import com.emc.gs.tools.srf.model.unified.SynchronousMode;
import com.emc.gs.tools.srf.model.unified.TargetCelerra;
import com.emc.gs.tools.srf.model.unified.TargetCelerraType;
import com.emc.gs.tools.srf.model.unified.VNXProtocol;
import com.emc.gs.tools.srf.services.LookupService;
import com.emc.gs.tools.srf.services.ServiceRequestToolException;

/**
 * <p>
 * This class is the implementation of the LookupService. It utilizes JPA EntityManager for necessary operations.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is effectively thread safe after configuration, the configuration is done
 * in a thread safe manner.
 * </p>
 * <p>
 * <strong>Changes V1.1:</strong> <strong>SRT Release Assembly - Base</strong>
 * <ul>
 * <li>Release_assembly_tasks.xls Row#8: Added lookup for sow types</li>
 * </ul>
 * </p>
 * <p>
 * <strong>Changes V1.2:</strong> <strong>SRT Release Assembly - Unified Tab</strong>
 * <ul>
 * <li>Add getAllSynchronousModes() and getAllReplicationFailoverLevels() methods</li>
 * </ul>
 * </p>
 * <p>
 * <strong>Changes V1.3:</strong> <strong>SRT Bug Fixes</strong>
 * <ul>
 * <li>Removed SQL_QUERY_VSD_GRAB_ANALYSIS_LEVEL constant.</li>
 * <li>Removed getAllVsdGrabAnalysisLevels() method.</li>
 * </ul>
 * </p>
 * <p>
 * <strong>Changes V1.4:</strong>
 * <ul>
 * <li>Removed SQL_QUERY_TARGET_TFR2DEVICE, SQL_QUERY_MICROCODE_FAMILY, SQL_QUERY_FLARECODE_FAMILY,
 * SQL_QUERY_MONITORING_SCRIPT, SQL_QUERY_NETWORK_CONNECTION_TYPE, SQL_QUERY_MDL_DLM_LIBRARY_TYPE constants.</li>
 * <li>Removed getAllMicrocodeFamilies, getAllFlarecodeFamilies, getAllMonitoringScripts, getAllNetworkConnectionTypes,
 * getAllMdlDlmLibraryTypes, getAllTargetTfR2Devices methods.</li>
 * </ul>
 * </p>
 * <p>
 * <strong>Changes V1.5:</strong> <strong>https://apps.topcoder.com/bugs/browse/SRT-35</strong>
 * <ul>
 * <li>Added SQL_QUERY_RECOVER_POINT_LICENSE, SQL_QUERY_REPLICATION_MANAGER_PRODUCT_SPECIFIC_PREPARATION,
 * SQL_QUERY_VNX_PROTOCOL, SQL_QUERY_MIGRATION_METHOD_MODEL constants.</li>
 * <li>Added getAllRecoverPointLicenses, getAllReplicationManagerProductSpecificPreparations, getAllVNXProtocols,
 * getAllMigrationMethods methods.</li>
 * </ul>
 * </p>
 *
 * <p>
 * <strong>Changes V1.6:</strong> <strong>SRT Phase 3-1 - CTA Rainfinity and MSS Tabs Assembly</strong>
 * <ul>
 * <li>Added a common getLookupEnities() method.</li>
 * </ul>
 * </p>
 *
 * <p>
 * <strong>Changes V1.7:</strong> <strong>SRT Phase 3-5 - BRS Tabs Part 1 Assembly</strong>
 * <ul>
 * <li>Delete getAllDataMobilityImplementations() method.</li>
 * <li>Delete getAllInstallTypes() method.</li>
 * <li>Delete getAllRecoverPointLicenses() method.</li>
 * <li>Delete getAllSplitterOptions() method.</li>
 * <li>Delete getAllJournalSizings() method.</li>
 * <li>Delete getAllSplitterTypes() method.</li>
 * </ul>
 * </p>
 *
 * <p>
 * Version 1.8 (SRT Phase 4 - ET Release Assembly) Change notes:
 *   <ol>
 *     <li>Added {@link #getAllProjectRegulatoryTypes()} method.</li>
 *     <li>Added {@link #SQL_QUERY_PROJECT_REGULATORY_TYPE} property.</li>
 *     <li>Added {@link #getAllExpenseTypes()} method.</li>
 *     <li>Added {@link #SQL_QUERY_EXPENSE_TYPE} property.</li>
 *   </ol>
 * </p>
 *
 * <p>
 * Version 1.9 (SRT 4 OCT2014 Updates Part 1 Assembly) Change notes:
 *   <ol>
 *     <li>Added {@link #getAllNetworkerDatazoneSizes()} method.</li>
 *     <li>Added {@link #SQL_QUERY_NETWORKER_DATAZONE_SIZE} property.</li>
 *     <li>Added {@link #getAllMeditechBackupTypes()} method.</li>
 *     <li>Added {@link #SQL_QUERY_MEDITECH_BACKUP_TYPE} property.</li>
 *   </ol>
 * </p>
 * 
 * <p>
 * Version 1.10 (SRT 1.1 DEC 2014 Updates Assembly) Change notes:
 *   <ol>
 *     <li>Replaced {@link #getAllCountries()} method with {@link #getAllDeliveryCountries()}.</li>
 *     <li>Replaced {@link #SQL_QUERY_COUNTRY} property with {@link #SQL_QUERY_DELIVERY_COUNTRY} property.</li>
 *   </ol>
 * </p>
 *
 * <p>
 * Version 1.11 Change notes:
 *   <ol>
 *     <li>Added {@link #getCompetenciesForLOB(long)} method.</li>
 *   </ol>
 * </p>
 * 
 * @author faeton, stevenfrog, MonicaMuranyi, isv
 * @version 1.11
 */
public class LookupServiceImpl extends BasePersistenceService implements LookupService {
    /**
     * <p>
     * Represents the class name.
     * </p>
     */
    private static final String CLASSNAME = LookupServiceImpl.class.getName();

    /**
     * The sql string to query FlashStorageLayoutServices.
     */
    private static final String SQL_QUERY_FLASHSTORAGELAYOUTSERVICES = "SELECT f FROM FlashStorageLayoutServices f";

    /**
     * The sql string to query Country.
     */
    private static final String SQL_QUERY_SOURCE_VNX_TYPES = "SELECT s FROM SourceVnxType s";

    /**
     * The sql string to query DeliveryCountry.
     */
    private static final String SQL_QUERY_DELIVERY_COUNTRY = "SELECT c FROM DeliveryCountry c";

    /**
     * The sql string to query GeoState.
     */
    private static final String SQL_QUERY_GEOSTATE = "SELECT c FROM GeoState c";

    /**
     * The sql string to query ScriptingLevelOption.
     */
    private static final String SQL_QUERY_SCRIPTINGLEVELOPTION = "SELECT s FROM ScriptingLevelOption s";

    /**
     * The sql string to query Geography.
     */
    private static final String SQL_QUERY_GEOGRAPHY = "SELECT g FROM Geography g";

    /**
     * The sql string to query ServicesAgreementType.
     */
    private static final String SQL_QUERY_SERVICES_AGREEMENT_TYPE = "SELECT s FROM ServicesAgreementType s";

    /**
     * The sql string to query SowType.
     */
    private static final String SQL_QUERY_SOW_TYPE = "SELECT s FROM SowType s";

    /**
     * The sql string to query RequestType.
     */
    private static final String SQL_QUERY_REQUEST_TYPE = "SELECT r FROM RequestType r";

    /**
     * The sql string to query RiskLevel.
     */
    private static final String SQL_QUERY_RISK_LEVEL = "SELECT r FROM RiskLevel r";

    /**
     * The sql string to query SowLanguage.
     */
    private static final String SQL_QUERY_SOW_LANGUAGE = "SELECT s FROM SowLanguage s";

    /**
     * The sql string to query ClearanceLevel.
     */
    private static final String SQL_QUERY_CLEARANCE_LEVEL = "SELECT c FROM ClearanceLevel c";

    /**
     * The sql string to query ProjectType.
     */
    private static final String SQL_QUERY_PROJECT_TYPE = "SELECT p FROM ProjectType p";

    /**
     * The sql string to query ProjectRegulatoryType.
     * 
     * @since 1.8
     */
    private static final String SQL_QUERY_PROJECT_REGULATORY_TYPE = "SELECT p FROM ProjectRegulatoryType p";

    /**
     * The sql string to query ExpenseType.
     *
     * @since 1.8
     */
    private static final String SQL_QUERY_EXPENSE_TYPE = "SELECT p FROM ExpenseType p";

    /**
     * The sql string to query MeetingStatus.
     */
    private static final String SQL_QUERY_MEETING_STATUS = "SELECT m FROM MeetingStatus m";

    /**
     * The sql string to query EnvironmentGatherer.
     */
    private static final String SQL_QUERY_ENVIRONMENT_GATHERER = "SELECT e FROM EnvironmentGatherer e";

    /**
     * The sql string to query HostSoftwareInstaller.
     */
    private static final String SQL_QUERY_HOST_SOFTWARE_INSTALLER = "SELECT h FROM HostSoftwareInstaller h";

    /**
     * The sql string to query SanImplementator.
     */
    private static final String SQL_QUERY_SAN_IMPLEMENTATOR = "SELECT s FROM SanImplementator s";

    /**
     * The sql string to query EnvironmentArrayType.
     */
    private static final String SQL_QUERY_ENVIRONMENT_ARRAY_TYPE = "SELECT e FROM EnvironmentArrayType e";

    /**
     * The sql string to query EnvironmentDeviceType.
     */
    private static final String SQL_QUERY_ENVIRONMENT_DEVICE_TYPE = "SELECT e FROM EnvironmentDeviceType e";

    /**
     * The sql string to query MigrationWorker.
     */
    private static final String SQL_QUERY_MIGRATION_WORKER = "SELECT m FROM MigrationWorker m";

    /**
     * The sql string to query VolumeSizeChange.
     */
    private static final String SQL_QUERY_VOLUME_SIZE_CHANGE = "SELECT v FROM VolumeSizeChange v";

    /**
     * The sql string to query EmcMigrationInvolvement.
     */
    private static final String SQL_QUERY_EMC_MIGRATION_INVOLVEMENT = "SELECT e FROM EmcMigrationInvolvement e";

    /**
     * The sql string to query ScriptingLevel.
     */
    private static final String SQL_QUERY_SCRIPTING_LEVEL = "SELECT s FROM ScriptingLevel s";

    /**
     * The sql string to query TestAcceptancePlanType.
     */
    private static final String SQL_QUERY_TEST_ACCEPTANCE_PLAN_TYPE = "SELECT t FROM TestAcceptancePlanType t";

    /**
     * The sql string to query DocumentationLevel.
     */
    private static final String SQL_QUERY_DOCUMENTATION_LEVEL = "SELECT d FROM DocumentationLevel d";

    /**
     * The sql string to query KnowledgeTransferLevel.
     */
    private static final String SQL_QUERY_KNOWLEDGE_TRANSFER_LEVEL = "SELECT k FROM KnowledgeTransferLevel k";

    /**
     * The sql string to query PushPullOption.
     */
    private static final String SQL_QUERY_PUSH_PULL_OPTION = "SELECT p FROM PushPullOption p";

    /**
     * The sql string to query PostSalesCompletionQualifier.
     */
    private static final String SQL_QUERY_POST_SALES_COMPLETION_QUALIFIER = "SELECT p FROM"
            + " PostSalesCompletionQualifier p";

    /**
     * The sql string to query MigrationTestNumber.
     */
    private static final String SQL_QUERY_MIGRATION_TEST_NUMBER = "SELECT m FROM MigrationTestNumber m";

    /**
     * The sql string to query SymmetrixModel.
     */
    private static final String SQL_QUERY_SYMMETRIX_MODEL = "SELECT s FROM SymmetrixModel s";

    /**
     * The sql string to query SrdfMode.
     */
    private static final String SQL_QUERY_SRDF_MODE = "SELECT s FROM SrdfMode s";

    /**
     * The sql string to query SrdfConnectionType.
     */
    private static final String SQL_QUERY_SRDF_CONNECTION_TYPE = "SELECT s FROM SrdfConnectionType s";

    /**
     * The sql string to query ArrayModel.
     */
    private static final String SQL_QUERY_ARRAY_MODEL = "SELECT a FROM ArrayModel a";

    /**
     * The sql string to query MvMode.
     */
    private static final String SQL_QUERY_MV_MODE = "SELECT m FROM MvMode m";

    /**
     * The sql string to query MvConnectionType.
     */
    private static final String SQL_QUERY_MV_CONNECTION_TYPE = "SELECT m FROM MvConnectionType m";

    /**
     * The sql string to query SrdfStaticDynamicType.
     */
    private static final String SQL_QUERY_SRDF_STATIC_DYNAMIC_TYPE = "SELECT s FROM SrdfStaticDynamicType s";

    /**
     * The sql string to query NetworkLinkStatus.
     */
    private static final String SQL_QUERY_NETWORK_LINK_STATUS = "SELECT n FROM NetworkLinkStatus n";

    /**
     * The sql string to query AreaSizingType.
     */
    private static final String SQL_QUERY_AREA_SIZING_TYPE = "SELECT a FROM AreaSizingType a";

    /**
     * The sql string to query BcvCloneOption.
     */
    private static final String SQL_QUERY_BCV_CLONE_OPTION = "SELECT b FROM BcvCloneOption b";

    /**
     * The sql string to query ConfigChangeType.
     */
    private static final String SQL_QUERY_CONFIG_CHANGE_TYPE = "SELECT c FROM ConfigChangeType c";

    /**
     * The sql string to query ReplicationManagerImplementation.
     */
    private static final String SQL_QUERY_REPLICATION_MANAGER_IMPLEMENTATION = "SELECT r FROM"
            + " ReplicationManagerImplementation r";

    /**
     * The sql string to query ReplicationManagerProductSpecificPreparation.
     */
    private static final String SQL_QUERY_REPLICATION_MANAGER_PRODUCT_SPECIFIC_PREPARATION = "SELECT r FROM"
            + " ReplicationManagerProductSpecificPreparation r";

    /**
     * The sql string to query CelerraModel.
     */
    private static final String SQL_QUERY_CELERRA_MODEL = "SELECT c FROM CelerraModel c";

    /**
     * The sql string to query VNXProtocol.
     */
    private static final String SQL_QUERY_VNX_PROTOCOL = "SELECT v FROM VNXProtocol v";

    /**
     * The sql string to query RackAndStackOption.
     */
    private static final String SQL_QUERY_RACK_AND_STACK_OPTION = "SELECT r FROM RackAndStackOption r";

    /**
     * The sql string to query GatewayStorageType.
     */
    private static final String SQL_QUERY_GATEWAY_STORAGE_TYPE = "SELECT g FROM GatewayStorageType g";

    /**
     * The sql string to query CelerraSetupType.
     */
    private static final String SQL_QUERY_CELERRA_SETUP_TYPE = "SELECT c FROM CelerraSetupType c";

    /**
     * The sql string to query TargetCelerraType.
     */
    private static final String SQL_QUERY_TARGET_CELERRA_TYPE = "SELECT t FROM TargetCelerraType t";

    /**
     * The sql string to query CelerraArrayType.
     */
    private static final String SQL_QUERY_CELERRA_ARRAY_TYPE = "SELECT c FROM CelerraArrayType c";

    /**
     * The sql string to query TargetCelerra.
     */
    private static final String SQL_QUERY_TARGET_CELERRA = "SELECT t FROM TargetCelerra t";

    /**
     * The sql string to query CelerraVnxModel.
     */
    private static final String SQL_QUERY_CELERRA_VNX_MODEL = "SELECT c FROM CelerraVnxModel c";

    /**
     * The sql string to query MigrationMethod.
     */
    private static final String SQL_QUERY_MIGRATION_METHOD_MODEL = "SELECT c FROM MigrationMethod c";

    /**
     * The sql string to query VnxClariionInstallType.
     */
    private static final String SQL_QUERY_VNX_CLARIION_INSTALL_TYPE = "SELECT v FROM VnxClariionInstallType v";

    /**
     * The sql string to query UnifiedConversionType.
     */
    private static final String SQL_QUERY_UNIFIED_CONVERSION_TYPE = "SELECT u FROM UnifiedConversionType u";

    /**
     * The sql string to query VnxInstallProtocolType.
     */
    private static final String SQL_QUERY_VNX_INSTALL_PROTOCOL_TYPE = "SELECT v FROM VnxInstallProtocolType v";

    /**
     * The sql string to query VnxInstallProtocolSubType.
     */
    private static final String SQL_QUERY_VNX_INSTALL_PROTOCOL_SUB_TYPE = "SELECT v FROM VnxInstallProtocolSubType v";

    /**
     * The sql string to query IOInterfaceModule.
     */
    private static final String SQL_QUERY_IO_INTERFACE_MODULE = "SELECT i FROM IOInterfaceModule i";

    /**
     * The sql string to query SynchronousMode.
     */
    private static final String SQL_QUERY_SYNCHRONOUS_MODE = "SELECT s FROM SynchronousMode s";

    /**
     * The sql string to query ReplicationFailoverLevel.
     */
    private static final String SQL_QUERY_REPLICATION_FAILOVER_LEVEL = "SELECT r FROM ReplicationFailoverLevel r";

    /**
     * The sql string to query NetworkerDatazoneSize.
     * 
     * @since 1.9
     */
    private static final String SQL_QUERY_NETWORKER_DATAZONE_SIZE = "SELECT n FROM NetworkerDatazoneSize n";

    /**
     * The sql string to query MeditechBackupType.
     *
     * @since 1.9
     */
    private static final String SQL_QUERY_MEDITECH_BACKUP_TYPE = "SELECT m FROM MeditechBackupType m";

    /**
     * The sql string to query Competency per LOB.
     *
     * @since 1.11
     */
    private static final String SQL_QUERY_COMPETENCY_FOR_LOB = "SELECT c FROM Competency c WHERE c.lobId = ";

    /**
     * Creates instance of the class.
     */
    public LookupServiceImpl() {
        // Empty
    }

    /**
     * Returns all ScriptingLevelOptions.
     * 
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     * @return Whole list of lookup values, may be empty.
     */
    public List<ScriptingLevelOption> getAllScriptingLevelOptions() throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#getAllScriptingLevelOptions()";

        return getEnities(getLogger(), signature, SQL_QUERY_SCRIPTINGLEVELOPTION, ScriptingLevelOption.class);
    }

    /**
     * Returns all Geographies.
     * 
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     * @return Whole list of lookup values, may be empty.
     */
    public List<Geography> getAllGeographies() throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#getAllCountries()";

        return getEnities(getLogger(), signature, SQL_QUERY_GEOGRAPHY, Geography.class);
    }

    /**
     * Returns all services agreement types.
     * 
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     * @return Whole list of lookup values, may be empty.
     */
    public List<ServicesAgreementType> getAllServicesAgreementTypes() throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#getAllServicesAgreementTypes()";

        return getEnities(getLogger(), signature, SQL_QUERY_SERVICES_AGREEMENT_TYPE, ServicesAgreementType.class);
    }

    /**
     * Returns all Sow types.
     * 
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     * @return Whole list of lookup values, may be empty.
     * @since 1.1
     */
    public List<SowType> getAllSowTypes() throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#getAllSowTypes()";

        return getEnities(getLogger(), signature, SQL_QUERY_SOW_TYPE, SowType.class);
    }

    /**
     * Returns all request types.
     * 
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     * @return Whole list of lookup values, may be empty.
     */
    public List<RequestType> getAllRequestTypes() throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#getAllRequestTypes()";

        return getEnities(getLogger(), signature, SQL_QUERY_REQUEST_TYPE, RequestType.class);
    }

    /**
     * Returns all risk levels.
     * 
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     * @return Whole list of lookup values, may be empty.
     */
    public List<RiskLevel> getAllRiskLevels() throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#getAllRiskLevels()";

        return getEnities(getLogger(), signature, SQL_QUERY_RISK_LEVEL, RiskLevel.class);
    }

    /**
     * Returns all SowLanguages.
     * 
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     * @return Whole list of lookup values, may be empty.
     */
    public List<SowLanguage> getAllSowLanguages() throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#getAllSowLanguages()";

        return getEnities(getLogger(), signature, SQL_QUERY_SOW_LANGUAGE, SowLanguage.class);
    }

    /**
     * Returns all clearance levels.
     * 
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     * @return Whole list of lookup values, may be empty.
     */
    public List<ClearanceLevel> getAllClearanceLevels() throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#getAllClearanceLevels()";

        return getEnities(getLogger(), signature, SQL_QUERY_CLEARANCE_LEVEL, ClearanceLevel.class);
    }

    /**
     * Returns all project types.
     * 
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     * @return Whole list of lookup values, may be empty.
     */
    public List<ProjectType> getAllProjectTypes() throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#getAllProjectTypes()";

        return getEnities(getLogger(), signature, SQL_QUERY_PROJECT_TYPE, ProjectType.class);
    }

    /**
     * <p>Gets the list of available project regulatory types.</p>
     *
     * @return a <code>List</code> listing the available project regulatory types, may be empty. 
     * @throws ServiceRequestToolException if any other error occurred during the operation.
     * @since 1.8
     */
    public List<ProjectRegulatoryType> getAllProjectRegulatoryTypes() throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#getAllProjectRegulatoryTypes()";

        return getEnities(getLogger(), signature, SQL_QUERY_PROJECT_REGULATORY_TYPE, ProjectRegulatoryType.class);
    }

    /**
     * <p>Gets the list of available expense types.</p>
     *
     * @return a <code>List</code> listing the available expense types, may be empty.
     * @throws ServiceRequestToolException if any other error occurred during the operation.
     * @since 1.8
     */
    public List<ExpenseType> getAllExpenseTypes() throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#getAllExpenseTypes()";

        return getEnities(getLogger(), signature, SQL_QUERY_EXPENSE_TYPE, ExpenseType.class);
    }

    /**
     * Returns all meeting statuses.
     * 
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     * @return Whole list of lookup values, may be empty.
     */
    public List<MeetingStatus> getAllMeetingStatuses() throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#getAllMeetingStatuses()";

        return getEnities(getLogger(), signature, SQL_QUERY_MEETING_STATUS, MeetingStatus.class);
    }

    /**
     * Returns all environment gatherers.
     * 
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     * @return Whole list of lookup values, may be empty.
     */
    public List<EnvironmentGatherer> getAllEnvironmentGatherers() throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#getAllEnvironmentGatherers()";

        return getEnities(getLogger(), signature, SQL_QUERY_ENVIRONMENT_GATHERER, EnvironmentGatherer.class);
    }

    /**
     * Returns all HostSoftwareInstallers.
     * 
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     * @return Whole list of lookup values, may be empty.
     */
    public List<HostSoftwareInstaller> getAllHostSoftwareInstallers() throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#getAllHostSoftwareInstallers()";

        return getEnities(getLogger(), signature, SQL_QUERY_HOST_SOFTWARE_INSTALLER, HostSoftwareInstaller.class);
    }

    /**
     * Returns all SanImplementators.
     * 
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     * @return Whole list of lookup values, may be empty.
     */
    public List<SanImplementator> getAllSanImplementators() throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#getAllSanImplementators()";

        return getEnities(getLogger(), signature, SQL_QUERY_SAN_IMPLEMENTATOR, SanImplementator.class);
    }

    /**
     * Returns all environment array types.
     * 
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     * @return Whole list of lookup values, may be empty.
     */
    public List<EnvironmentArrayType> getAllEnvironmentArrayTypes() throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#getAllEnvironmentArrayTypes()";

        return getEnities(getLogger(), signature, SQL_QUERY_ENVIRONMENT_ARRAY_TYPE, EnvironmentArrayType.class);
    }

    /**
     * Returns all environment device types.
     * 
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     * @return Whole list of lookup values, may be empty.
     */
    public List<EnvironmentDeviceType> getAllEnvironmentDeviceTypes() throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#getAllEnvironmentDeviceTypes()";

        return getEnities(getLogger(), signature, SQL_QUERY_ENVIRONMENT_DEVICE_TYPE, EnvironmentDeviceType.class);
    }

    /**
     * Returns all migration workers.
     * 
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     * @return Whole list of lookup values, may be empty.
     */
    public List<MigrationWorker> getAllMigrationWorkers() throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#getAllMigrationWorkers()";

        return getEnities(getLogger(), signature, SQL_QUERY_MIGRATION_WORKER, MigrationWorker.class);
    }

    /**
     * Returns all volume size changes.
     * 
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     * @return Whole list of lookup values, may be empty.
     */
    public List<VolumeSizeChange> getAllVolumeSizeChanges() throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#getAllVolumeSizeChanges()";

        return getEnities(getLogger(), signature, SQL_QUERY_VOLUME_SIZE_CHANGE, VolumeSizeChange.class);
    }

    /**
     * Returns all emc migration involvements.
     * 
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     * @return Whole list of lookup values, may be empty.
     */
    public List<EmcMigrationInvolvement> getAllEmcMigrationInvolvements() throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#getAllEmcMigrationInvolvements()";

        return getEnities(getLogger(), signature, SQL_QUERY_EMC_MIGRATION_INVOLVEMENT,
                EmcMigrationInvolvement.class);
    }

    /**
     * Returns all scripting levels.
     * 
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     * @return Whole list of lookup values, may be empty.
     */
    public List<ScriptingLevel> getAllScriptingLevels() throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#getAllScriptingLevels()";

        return getEnities(getLogger(), signature, SQL_QUERY_SCRIPTING_LEVEL, ScriptingLevel.class);
    }

    /**
     * Returns all test acceptance plan types.
     * 
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     * @return Whole list of lookup values, may be empty.
     */
    public List<TestAcceptancePlanType> getAllTestAcceptancePlanTypes() throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#getAllTestAcceptancePlanTypes()";

        return getEnities(getLogger(), signature, SQL_QUERY_TEST_ACCEPTANCE_PLAN_TYPE,
                TestAcceptancePlanType.class);
    }

    /**
     * Returns all documentation levels.
     * 
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     * @return Whole list of lookup values, may be empty.
     */
    public List<DocumentationLevel> getAllDocumentationLevels() throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#getAllDocumentationLevels()";

        return getEnities(getLogger(), signature, SQL_QUERY_DOCUMENTATION_LEVEL, DocumentationLevel.class);
    }

    /**
     * Returns all knowledge transfer levels.
     * 
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     * @return Whole list of lookup values, may be empty.
     */
    public List<KnowledgeTransferLevel> getAllKnowledgeTransferLevels() throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#getAllKnowledgeTransferLevels()";

        return getEnities(getLogger(), signature, SQL_QUERY_KNOWLEDGE_TRANSFER_LEVEL, KnowledgeTransferLevel.class);
    }

    /**
     * Returns all push pull options.
     * 
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     * @return Whole list of lookup values, may be empty.
     */
    public List<PushPullOption> getAllPushPullOptions() throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#getAllPushPullOptions()";

        return getEnities(getLogger(), signature, SQL_QUERY_PUSH_PULL_OPTION, PushPullOption.class);
    }

    /**
     * Returns all post sales completion qualifiers.
     * 
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     * @return Whole list of lookup values, may be empty.
     */
    public List<PostSalesCompletionQualifier> getAllPostSalesCompletionQualifiers()
            throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#getAllPostSalesCompletionQualifiers()";

        return getEnities(getLogger(), signature, SQL_QUERY_POST_SALES_COMPLETION_QUALIFIER,
                PostSalesCompletionQualifier.class);
    }

    /**
     * Returns all migration test numbers.
     * 
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     * @return Whole list of lookup values, may be empty.
     */
    public List<MigrationTestNumber> getAllMigrationTestNumbers() throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#getAllMigrationTestNumbers()";

        return getEnities(getLogger(), signature, SQL_QUERY_MIGRATION_TEST_NUMBER, MigrationTestNumber.class);
    }

    /**
     * Returns all symmetrix models.
     * 
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     * @return Whole list of lookup values, may be empty.
     */
    public List<SymmetrixModel> getAllSymmetrixModels() throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#getAllSymmetrixModels()";

        return getEnities(getLogger(), signature, SQL_QUERY_SYMMETRIX_MODEL, SymmetrixModel.class);
    }

    /**
     * Returns all srdf modes.
     * 
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     * @return Whole list of lookup values, may be empty.
     */
    public List<SrdfMode> getAllSrdfModes() throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#getAllSrdfModes()";

        return getEnities(getLogger(), signature, SQL_QUERY_SRDF_MODE, SrdfMode.class);
    }

    /**
     * Returns all srdf connection types.
     * 
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     * @return Whole list of lookup values, may be empty.
     */
    public List<SrdfConnectionType> getAllSrdfConnectionTypes() throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#getAllSrdfConnectionTypes()";

        return getEnities(getLogger(), signature, SQL_QUERY_SRDF_CONNECTION_TYPE, SrdfConnectionType.class);
    }

    /**
     * Returns all array models.
     * 
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     * @return Whole list of lookup values, may be empty.
     */
    public List<ArrayModel> getAllArrayModels() throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#getAllArrayModels()";

        return getEnities(getLogger(), signature, SQL_QUERY_ARRAY_MODEL, ArrayModel.class);
    }

    /**
     * Returns all MV modes.
     * 
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     * @return Whole list of lookup values, may be empty.
     */
    public List<MvMode> getAllMvModes() throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#getAllMvModes()";

        return getEnities(getLogger(), signature, SQL_QUERY_MV_MODE, MvMode.class);
    }

    /**
     * Returns all MVC connection types.
     * 
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     * @return Whole list of lookup values, may be empty.
     */
    public List<MvConnectionType> getAllMvConnectionTypes() throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#getAllMvConnectionTypes()";

        return getEnities(getLogger(), signature, SQL_QUERY_MV_CONNECTION_TYPE, MvConnectionType.class);
    }

    /**
     * Returns all srdf static dynamic types.
     * 
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     * @return Whole list of lookup values, may be empty.
     */
    public List<SrdfStaticDynamicType> getAllSrdfStaticDynamicTypes() throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#getAllSrdfStaticDynamicTypes()";

        return getEnities(getLogger(), signature, SQL_QUERY_SRDF_STATIC_DYNAMIC_TYPE, SrdfStaticDynamicType.class);
    }

    /**
     * Returns all network link statuses.
     * 
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     * @return Whole list of lookup values, may be empty.
     */
    public List<NetworkLinkStatus> getAllNetworkLinkStatuses() throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#getAllNetworkLinkStatuses()";

        return getEnities(getLogger(), signature, SQL_QUERY_NETWORK_LINK_STATUS, NetworkLinkStatus.class);
    }

    /**
     * Returns all area sizing types.
     * 
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     * @return Whole list of lookup values, may be empty.
     */
    public List<AreaSizingType> getAllAreaSizingTypes() throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#getAllAreaSizingTypes()";

        return getEnities(getLogger(), signature, SQL_QUERY_AREA_SIZING_TYPE, AreaSizingType.class);
    }

    /**
     * Returns all bcv clone options.
     * 
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     * @return Whole list of lookup values, may be empty.
     */
    public List<BcvCloneOption> getAllBcvCloneOptions() throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#getAllBcvCloneOptions()";

        return getEnities(getLogger(), signature, SQL_QUERY_BCV_CLONE_OPTION, BcvCloneOption.class);
    }

    /**
     * Returns all config change types.
     * 
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     * @return Whole list of lookup values, may be empty.
     */
    public List<ConfigChangeType> getAllConfigChangeTypes() throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#getAllConfigChangeTypes()";

        return getEnities(getLogger(), signature, SQL_QUERY_CONFIG_CHANGE_TYPE, ConfigChangeType.class);
    }

    /**
     * Returns all replication manager implementations.
     * 
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     * @return Whole list of lookup values, may be empty.
     */
    public List<ReplicationManagerImplementation> getAllReplicationManagerImplementations()
            throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#getAllReplicationManagerImplementations()";

        return getEnities(getLogger(), signature, SQL_QUERY_REPLICATION_MANAGER_IMPLEMENTATION,
                ReplicationManagerImplementation.class);
    }

    /**
     * Returns all replication manager product specific preparations.
     * 
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     * @return Whole list of lookup values, may be empty.
     */
    public List<ReplicationManagerProductSpecificPreparation> getAllReplicationManagerProductSpecificPreparations()
            throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#getAllReplicationManagerProductSpecificPreparations()";

        return getEnities(getLogger(), signature, SQL_QUERY_REPLICATION_MANAGER_PRODUCT_SPECIFIC_PREPARATION,
                ReplicationManagerProductSpecificPreparation.class);
    }

    /**
     * Returns all celerra models.
     * 
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     * @return Whole list of lookup values, may be empty.
     */
    public List<CelerraModel> getAllCelerraModels() throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#getAllCelerraModels()";

        return getEnities(getLogger(), signature, SQL_QUERY_CELERRA_MODEL, CelerraModel.class);
    }

    /**
     * Returns all celerra models.
     * 
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     * @return Whole list of lookup values, may be empty.
     */
    public List<VNXProtocol> getAllVNXProtocols() throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#getAllVNXProtocols()";

        return getEnities(getLogger(), signature, SQL_QUERY_VNX_PROTOCOL, VNXProtocol.class);
    }

    /**
     * Returns all rack and stack options.
     * 
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     * @return Whole list of lookup values, may be empty.
     */
    public List<RackAndStackOption> getAllRackAndStackOptions() throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#getAllRackAndStackOptions()";

        return getEnities(getLogger(), signature, SQL_QUERY_RACK_AND_STACK_OPTION, RackAndStackOption.class);
    }

    /**
     * Returns all gateway storage types.
     * 
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     * @return Whole list of lookup values, may be empty.
     */
    public List<GatewayStorageType> getAllGatewayStorageTypes() throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#getAllGatewayStorageTypes()";

        return getEnities(getLogger(), signature, SQL_QUERY_GATEWAY_STORAGE_TYPE, GatewayStorageType.class);
    }

    /**
     * Returns all celerra setup types.
     * 
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     * @return Whole list of lookup values, may be empty.
     */
    public List<CelerraSetupType> getAllCelerraSetupTypes() throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#getAllCelerraSetupTypes()";

        return getEnities(getLogger(), signature, SQL_QUERY_CELERRA_SETUP_TYPE, CelerraSetupType.class);
    }

    /**
     * Returns all target celerra types.
     * 
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     * @return Whole list of lookup values, may be empty.
     */
    public List<TargetCelerraType> getAllTargetCelerraTypes() throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#getAllTargetCelerraTypes()";

        return getEnities(getLogger(), signature, SQL_QUERY_TARGET_CELERRA_TYPE, TargetCelerraType.class);
    }

    /**
     * Returns all celerra array types.
     * 
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     * @return Whole list of lookup values, may be empty.
     */
    public List<CelerraArrayType> getAllCelerraArrayTypes() throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#getAllCelerraArrayTypes()";

        return getEnities(getLogger(), signature, SQL_QUERY_CELERRA_ARRAY_TYPE, CelerraArrayType.class);
    }

    /**
     * Returns all target celerras.
     * 
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     * @return Whole list of lookup values, may be empty.
     */
    public List<TargetCelerra> getAllTargetCelerras() throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#getAllTargetCelerras()";

        return getEnities(getLogger(), signature, SQL_QUERY_TARGET_CELERRA, TargetCelerra.class);
    }

    /**
     * Returns all celerra vnx models.
     * 
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     * @return Whole list of lookup values, may be empty.
     */
    public List<CelerraVnxModel> getAllCelerraVnxModels() throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#getAllCelerraVnxModels()";

        return getEnities(getLogger(), signature, SQL_QUERY_CELERRA_VNX_MODEL, CelerraVnxModel.class);
    }

    /**
     * Returns all migration method models.
     * 
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     * @return Whole list of lookup values, may be empty.
     */
    public List<MigrationMethod> getAllMigrationMethods() throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#getAllMigrationMethods()";

        return getEnities(getLogger(), signature, SQL_QUERY_MIGRATION_METHOD_MODEL, MigrationMethod.class);
    }

    /**
     * Returns all vnx clariion install types.
     * 
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     * @return Whole list of lookup values, may be empty.
     */
    public List<VnxClariionInstallType> getAllVnxClariionInstallTypes() throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#getAllVnxClariionInstallTypes()";

        return getEnities(getLogger(), signature, SQL_QUERY_VNX_CLARIION_INSTALL_TYPE,
                VnxClariionInstallType.class);
    }

    /**
     * Returns all unified conversion types.
     * 
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     * @return Whole list of lookup values, may be empty.
     */
    public List<UnifiedConversionType> getAllUnifiedConversionTypes() throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#getAllUnifiedConversionTypes()";

        return getEnities(getLogger(), signature, SQL_QUERY_UNIFIED_CONVERSION_TYPE, UnifiedConversionType.class);
    }

    /**
     * Returns all vnx install protocol types.
     * 
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     * @return Whole list of lookup values, may be empty.
     */
    public List<VnxInstallProtocolType> getAllVnxInstallProtocolTypes() throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#getAllVnxInstallProtocolTypes()";

        return getEnities(getLogger(), signature, SQL_QUERY_VNX_INSTALL_PROTOCOL_TYPE,
                VnxInstallProtocolType.class);
    }

    /**
     * Returns all vnx install protocol sub types.
     * 
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     * @return Whole list of lookup values, may be empty.
     */
    public List<VnxInstallProtocolSubType> getAllVnxInstallProtocolSubTypes() throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#getAllVnxInstallProtocolSubTypes()";

        return getEnities(getLogger(), signature, SQL_QUERY_VNX_INSTALL_PROTOCOL_SUB_TYPE,
                VnxInstallProtocolSubType.class);
    }

    /**
     * Returns all io interface modules.
     * 
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     * @return Whole list of lookup values, may be empty.
     */
    public List<IOInterfaceModule> getAllIOInterfaceModules() throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#getAllIOInterfaceModules()";

        return getEnities(getLogger(), signature, SQL_QUERY_IO_INTERFACE_MODULE, IOInterfaceModule.class);
    }

    /**
     * Get the entities from DB.
     * 
     * @param <T>
     *            the class type
     * @param logger
     *            the logger
     * @param signature
     *            the signature
     * @param queryStr
     *            the query string
     * @param clazz
     *            the class
     * @return the entities
     * @throws ServiceRequestToolException
     *             if any error occurs
     */
    private <T extends IdentifiableEntity> List<T> getEnities(Logger logger, String signature, String queryStr,
            Class<T> clazz) throws ServiceRequestToolException {
        try {
            // Log entry
            Helper.logEntrance(logger, signature, null, null);

            EntityManager entityManager = getEntityManager();
            TypedQuery<T> query = entityManager.createQuery(queryStr, clazz);

            // Turn on query cache
            query.setHint("org.hibernate.cacheable", true);

            List<T> result = query.getResultList();

            // Log exit
            Helper.logExit(logger, signature, new Object[] {
                result
            });

            return result;
        } catch (IllegalStateException e) {
            // Log exception
            throw Helper.logException(logger, signature, new ServiceRequestToolException(
                    "The entity manager has been closed.", e));
        } catch (PersistenceException e) {
            // Log exception
            throw Helper.logException(logger, signature, new ServiceRequestToolException(
                    "An error has occurred while accessing the persistence.", e));
        }
    }

    /**
     * Returns all geography states.
     * 
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     * @return Whole list of lookup values, may be empty.
     */
    public List<GeoState> getAllGeoStates() throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#getAllGeoStates()";

        return getEnities(getLogger(), signature, SQL_QUERY_GEOSTATE, GeoState.class);
    }

    /**
     * Returns all delivery countries.
     * 
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     * @return Whole list of lookup values, may be empty.
     */
    public List<DeliveryCountry> getAllDeliveryCountries() throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#getAllDeliveryCountries()";

        return getEnities(getLogger(), signature, SQL_QUERY_DELIVERY_COUNTRY, DeliveryCountry.class);
    }

    /**
     * Returns FlashStorageLayoutServices.
     * 
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     * @return Whole list of lookup values, may be empty.
     */
    public List<FlashStorageLayoutServices> getAllFlashStorageLayoutServices() throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#getAllFlashStorageLayoutServices()";

        return getEnities(getLogger(), signature, SQL_QUERY_FLASHSTORAGELAYOUTSERVICES,
                FlashStorageLayoutServices.class);
    }

    /**
     * Returns SourceVnxType.
     * 
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     * @return Whole list of lookup values, may be empty.
     */
    public List<SourceVnxType> getAllSourceVnxTypes() throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#getAllSourceVnxTypes()";

        return getEnities(getLogger(), signature, SQL_QUERY_SOURCE_VNX_TYPES, SourceVnxType.class);
    }

    /**
     * Returns SynchronousMode.
     * 
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     * @return Whole list of lookup values, may be empty.
     * @since SRT Release Assembly - Unified Tab
     */
    public List<SynchronousMode> getAllSynchronousModes() throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#getAllSynchronousModes()";

        return getEnities(getLogger(), signature, SQL_QUERY_SYNCHRONOUS_MODE, SynchronousMode.class);
    }

    /**
     * Returns ReplicationFailoverLevel.
     * 
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     * @return Whole list of lookup values, may be empty.
     * @since SRT Release Assembly - Unified Tab
     */
    public List<ReplicationFailoverLevel> getAllReplicationFailoverLevels() throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#getAllReplicationFailoverLevels()";

        return getEnities(getLogger(), signature, SQL_QUERY_REPLICATION_FAILOVER_LEVEL,
                ReplicationFailoverLevel.class);
    }

    /**
     * <p>Gets the list of available Networker datazone sizes.</p>
     *
     * @return a <code>List</code> listing the available Networker datazone sizes, may be empty.
     * @throws ServiceRequestToolException if any other error occurred during the operation.
     * @since 1.9
     */
    @Override
    public List<NetworkerDatazoneSize> getAllNetworkerDatazoneSizes() throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#getAllNetworkerDatazoneSizes()";

        return getEnities(getLogger(), signature, SQL_QUERY_NETWORKER_DATAZONE_SIZE, NetworkerDatazoneSize.class);
    }

    /**
     * <p>Gets the list of available Meditech backup types.</p>
     *
     * @return a <code>List</code> listing the available Meditech backup types, may be empty.
     * @throws ServiceRequestToolException if any other error occurred during the operation.
     * @since 1.9
     */
    @Override
    public List<MeditechBackupType> getAllMeditechBackupTypes() throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#getAllMeditechBackupTypes()";

        return getEnities(getLogger(), signature, SQL_QUERY_MEDITECH_BACKUP_TYPE, MeditechBackupType.class);
    }

    /**
     * Get the lookup entities from DB.
     * 
     * @param <T>
     *            the lookup entity class type
     * @param clazz
     *            the class
     * @return the lookup entities
     * @throws IllegalArgumentException
     *             if clazz is null
     * @throws ServiceRequestToolException
     *             if any error occurs
     */
    public <T extends IdentifiableEntity> List<T> getLookupEnities(Class<T> clazz)
        throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#getLookupEnities(Class<T> clazz)";
        Logger logger = getLogger();

        // Log entry
        Helper.logEntrance(logger, signature, new String[] {
            "clazz"
        }, new Object[] {
            clazz
        });

        Helper.checkNull(logger, signature, clazz, "clazz");
        return getEnities(logger, signature, "select e from " + clazz.getSimpleName() + " e", clazz);
    }

    /**
     * <p>Gets the list of competencies for specified LOB.</p>
     *
     * @param lobId a <code>long</code> providing the ID of a LOB to get competencies for.
     * @return a <code>List</code> listing the available competencies for specified LOB, may be empty.
     * @throws ServiceRequestToolException if any other error occurred during the operation.
     * @since 1.11
     */
    @Override
    public List<Competency> getCompetenciesForLOB(long lobId) throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#getCompetenciesForLOB()";

        return getEnities(getLogger(), signature, SQL_QUERY_COMPETENCY_FOR_LOB + lobId, Competency.class);
    }
}

/*
 * This code is copyright (c) 2015 EMC Corporation.
 */
package com.emc.gs.tools.srf.services.impl;

import com.emc.gs.tools.srf.model.Request;
import com.emc.gs.tools.srf.model.engagement.EngagementTypeData;
import com.emc.gs.tools.srf.services.FTPService;
import com.emc.gs.tools.srf.services.ServiceRequestToolException;
import org.apache.commons.net.ftp.FTP;
import org.apache.commons.net.ftp.FTPClient;
import org.apache.commons.net.ftp.FTPReply;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.SocketException;

/**
 * <p>An utility class providing the methods for sending files to FTP server.</p>
 *
 * <p>
 * Version 1.1 Change notes:
 *   <ol>
 *     <li>Files are transferred to <code>Work</code> sub-folder within destination folder.</li>
 *   </ol>
 * </p>
 *
 * @author isv
 * @version 1.1
 */
public class FTPServiceImpl extends BaseLoggerService implements FTPService {

    /**
     * <p>Represents the class name.</p>
     */
    private static final String CLASSNAME = FTPServiceImpl.class.getName();

    /**
     * <p>A <code>String</code> providing the value for host property.</p>
     */
    private String host;

    /**
     * <p>A <code>int</code> providing the value for port property.</p>
     */
    private int port;

    /**
     * <p>A <code>String</code> providing the value for username property.</p>
     */
    private String username;

    /**
     * <p>A <code>String</code> providing the value for password property.</p>
     */
    private String password;

    /**
     * <p>Sets the password property.</p>
     *
     * @param password a <code>String</code> providing the value for password property.
     */
    public void setPassword(String password) {
        this.password = password;
    }

    /**
     * <p>Sets the username property.</p>
     *
     * @param username a <code>String</code> providing the value for username property.
     */
    public void setUsername(String username) {
        this.username = username;
    }

    /**
     * <p>Sets the port property.</p>
     *
     * @param port a <code>int</code> providing the value for port property.
     */
    public void setPort(int port) {
        this.port = port;
    }

    /**
     * <p>Sets the host property.</p>
     *
     * @param host a <code>String</code> providing the value for host property.
     */
    public void setHost(String host) {
        this.host = host;
    }

    /**
     * <p>Constructs new <code>FTPServiceImpl</code> instance. This implementation does nothing.</p>
     */
    public FTPServiceImpl() {
    }

    /**
     * <p>Transfers the specified generated XML presentation of specified request to intended FTP server when request is
     * submitted.</p>
     *
     * @param request a <code>Request</code> representing the request to be sent to server.
     * @param exportedRequest a <code>File</code> referencing the generated XML presentation of specified request.
     */
    public void sendRequest(Request request, File exportedRequest) throws ServiceRequestToolException {
        final String signature = CLASSNAME + "#sendRequest(Request request, File exportedRequest)";
        
        if (request.getEstimatesData().getDeliverAction() == null) {
            getLogger().info("No delivery action specified for request " + request.getId() + ". Transferring to FTP " +
                "server is skipped.");
            return;
        }

        FTPClient ftp = new FTPClient();
        FileInputStream input = null;
        try {
            ftp.connect(this.host, this.port);

            // After connection attempt, you should check the reply code to verify
            // success.
            int reply = ftp.getReplyCode();
            if (FTPReply.isPositiveCompletion(reply)) {
                if (ftp.login(this.username, this.password)) {
                    ftp.setFileType(FTP.ASCII_FILE_TYPE);
                    ftp.enterLocalPassiveMode();
                    ftp.setFileType(FTP.ASCII_FILE_TYPE, FTP.ASCII_FILE_TYPE);
                    ftp.setFileTransferMode(FTP.ASCII_FILE_TYPE);
                    
                    // Determine the remote directory based on delivery action type
                    String remoteDir = null;
                    long deliverActionTypeId = request.getEstimatesData().getDeliverAction().getId();
                    EngagementTypeData engagementTypeData = request.getEngagementTypeData();
                    boolean emcEcdGroup = engagementTypeData.isEmc() || engagementTypeData.isEcd();
                    boolean msRsaGroup = engagementTypeData.isMs() || engagementTypeData.isRsa();

                    switch ((int) deliverActionTypeId) {
                        case 1:
                        case 6: {
                            remoteDir = "LOEMD";
                            break;
                        }
                        case 2: 
                        case 3:
                        case 4: {
                            if (emcEcdGroup && !msRsaGroup) {
                                remoteDir = "BOEDXP";
                            }
                            break;
                        }
                        case 5: {
                            if (emcEcdGroup && !msRsaGroup) {
                                remoteDir = "BOECR";
                            }
                            break;
                        }
                        case 7: {
                            if (emcEcdGroup && !msRsaGroup) {
                                remoteDir = "BOESR";
                            }
                            break;
                        }
                        case 8:
                        case 9:
                        case 10:
                        case 11: {
                            if (msRsaGroup && !emcEcdGroup) {
                                remoteDir = "LOEMD";
                            }
                            break;
                        }
                    }

                    if (remoteDir != null) {
                        String remoteFileName = Helper.generateExportFileName(request) + ".xml";
                        getLogger().debug("Transferring generated XML for request " + request.getId() + " to FTP " +
                            "server. Target directory: " + remoteDir + ", target file: " + remoteFileName);
                        if (ftp.changeWorkingDirectory(remoteDir)) {
                            if (ftp.changeWorkingDirectory("Work")) {
                                input = new FileInputStream(exportedRequest);
                                boolean storeResult = ftp.storeFile(remoteFileName, input);
                                input.close();
                                if (!storeResult) {
                                    throw Helper.logException(getLogger(), signature,
                                        new ServiceRequestToolException("Failed to transfer request XML content to FTP "
                                            + "server"));
                                }
                            } else {
                                getLogger().error( "Failed to transfer request XML content to FTP server. Could not " +
                                    "CD to " + remoteDir + "/Work");
                                throw Helper.logException(getLogger(), signature,
                                    new ServiceRequestToolException("Failed to transfer request XML content to FTP server."));
                            }
                        } else {
                            getLogger().error(
                                "Failed to transfer request XML content to FTP server. Could not CD to " + remoteDir);
                            throw Helper.logException(getLogger(), signature,
                                new ServiceRequestToolException("Failed to transfer request XML content to FTP server."));
                        }
                        ftp.logout();
                    } else {
                        getLogger().info("Could not determine the target FTP directory for transporting request. " +
                            + request.getId() + ". Probably incorrect combination of LOBs is selected.");
                    }
                } else {
                    ftp.logout();
                    throw Helper.logException(getLogger(), signature,
                        new ServiceRequestToolException("Failed to authenticate to FTP server"));
                }
            } else {
                ftp.disconnect(); 
                throw Helper.logException(getLogger(), signature,
                    new ServiceRequestToolException("FTP server refused connection."));
            }
        } catch (SocketException e) {
            throw Helper.logException(getLogger(), signature, 
                new ServiceRequestToolException("Could not establish a connection to FTP server", e));
        } catch (IOException e) {
            throw Helper.logException(getLogger(), signature,
                new ServiceRequestToolException("Failed to transfer file to FTP server", e));
        } finally {
            if (ftp.isConnected()) {
                try {
                    ftp.disconnect();
                } catch (IOException f) {
                    // do nothing
                }
            }
            if (input != null) {
                try {
                    input.close();
                } catch (IOException e) {
                    // do nothing
                }
            }
        }
    }
}

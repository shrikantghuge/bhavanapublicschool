/*
 * This code is copyright (c) 2014 EMC Corporation.
 */
package com.emc.gs.tools.srf.services;

import java.io.OutputStream;

import com.emc.gs.tools.srf.model.Request;
import com.emc.gs.tools.srf.services.estimate.dto.EstimatedResult;

/**
 * <p>
 * This interface defines a contract to estimate request and export estimates request XML.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: The implementation are required to be thread safe.
 * </p>
 * 
 * @author TCSASSEMBLER
 * @version 1.0
 * @since SRT Phase 4 - ET Assembly 1
 */
public interface EstimatesService {

    /**
     * Estimates request.
     * 
     * @param request
     *            the request to estimate.
     * @return the estimate result DTO. Null is returned if given request does not have estimate data.
     * @throws IllegalArgumentException
     *             if any argument is null.
     * @throws ServiceRequestToolException
     *             if error occurs when estimating request.
     */
    public EstimatedResult estimate(Request request) throws ServiceRequestToolException;

    /**
     * Exports SRT4 path request to XML.
     * 
     * @param request
     *            A SRT4 path request.
     * @param stream
     *            the output stream
     * @throws IllegalArgumentException
     *             if any argument is null.
     * @throws ExportServiceException
     *             if there is any problem when performing operation.
     */
    public void exportRequest(Request request, OutputStream stream) throws ExportServiceException;
}

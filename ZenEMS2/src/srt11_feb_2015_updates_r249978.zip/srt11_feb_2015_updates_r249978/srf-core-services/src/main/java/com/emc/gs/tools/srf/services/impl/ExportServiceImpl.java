/*
 * This code is copyright (c) 2013 - 2015 EMC Corporation.
 */
package com.emc.gs.tools.srf.services.impl;

import static com.emc.gs.tools.srf.services.impl.Helper.int2StringNoPad;
import static com.emc.gs.tools.srf.services.impl.Helper.decimal2String;
import static com.emc.gs.tools.srf.services.impl.Helper.enum2String;
import static com.emc.gs.tools.srf.services.impl.Helper.isBooleanFalse;
import static com.emc.gs.tools.srf.services.impl.Helper.isBooleanTrue;
import static com.emc.gs.tools.srf.services.impl.Helper.lookupEntity2String;
import static com.emc.gs.tools.srf.services.impl.Helper.trimToEmpty;

import java.awt.Color;
import java.io.IOException;
import java.io.OutputStream;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;

import com.emc.gs.tools.srf.model.AssessmentData;
import com.emc.gs.tools.srf.model.ProtectPointData;
import com.emc.gs.tools.srf.model.RecoveryLevelType;
import com.emc.gs.tools.srf.model.deal.ClientEnvironmentDocumentationQualityOption;
import com.emc.gs.tools.srf.model.deal.EMCAccountabilityOption;
import com.emc.gs.tools.srf.model.deal.EMCClientOption;
import com.emc.gs.tools.srf.model.deal.EMCClientRelationshipOption;
import com.emc.gs.tools.srf.model.deal.EMCFederatedCompaniesInvolvementOption;
import com.emc.gs.tools.srf.model.deal.EMCStaffAvailabilityOption;
import com.emc.gs.tools.srf.model.deal.ExternalFactorsOption;
import com.emc.gs.tools.srf.model.deal.MultipleTheatersLanguagesInvolvementOption;
import com.emc.gs.tools.srf.model.deal.MultipleWorkgroupsDisciplinesOption;
import com.emc.gs.tools.srf.model.deal.OfferingMaturityOption;
import com.emc.gs.tools.srf.model.deal.PartnerStaffAvailabilityOption;
import com.emc.gs.tools.srf.model.deal.ProcessStaffMaturityOption;
import com.emc.gs.tools.srf.model.deal.ProgramManagementUseCaseOption;
import com.emc.gs.tools.srf.model.deal.ProjectComplexityLevelOption;
import com.emc.gs.tools.srf.model.deal.ProjectImpactOption;
import com.emc.gs.tools.srf.model.deal.ProjectScopeUnderstandingOption;
import com.emc.gs.tools.srf.model.deal.ProjectSponsorInvolvementOption;
import com.emc.gs.tools.srf.model.deal.RiskCalculationData;
import com.emc.gs.tools.srf.model.deal.RiskLevelOption;
import com.emc.gs.tools.srf.model.deal.TMBillingUsageOption;
import com.emc.gs.tools.srf.model.deal.ThirdPartyInvolvementOption;
import com.emc.gs.tools.srf.model.dpad.AvamarADMEConfiguration;
import com.emc.gs.tools.srf.model.dpad.DataDomainImplBase;
import com.emc.gs.tools.srf.model.dpad.Mozy;
import com.emc.gs.tools.srf.model.dpad.MozyCustom;
import com.emc.gs.tools.srf.model.dpad.MozyOEMBranding;
import com.emc.gs.tools.srf.model.dpad.MozyOutTasking;
import com.emc.gs.tools.srf.model.dpad.NetworkerDatazoneSize;
import com.emc.gs.tools.srf.model.dpad.NetworkerHealthcheck;
import com.emc.gs.tools.srf.model.dpad.RPAHardwareUpgrade;
import com.emc.gs.tools.srf.model.dpad.IntelligentFabricMigrationMethod;
import com.emc.gs.tools.srf.model.dpad.IntelligentFabricSplitterMigration;
import com.emc.gs.tools.srf.model.dpad.RecoverPointInstallationAndImplementation;
import com.emc.gs.tools.srf.model.dpad.RecoverPointOption;
import com.emc.gs.tools.srf.model.infrastructure.SymmetrixInformationBase;
import com.emc.gs.tools.srf.model.infrastructure.SymmetrixMF;
import com.emc.gs.tools.srf.model.infrastructure.SymmetrixOS;
import com.emc.gs.tools.srf.model.isilon.IsilonNetAppNodeBaseMigration;
import com.emc.gs.tools.srf.model.vipr.ECSApplianceDesignImpl;
import com.emc.gs.tools.srf.model.vipr.HostBasedMigrationTool;
import com.emc.gs.tools.srf.model.vipr.ViprDataMigrationPPME;
import com.emc.gs.tools.srf.model.vipr.ViprDataMigrationPPMEImplementationMigration;
import com.emc.gs.tools.srf.model.vipr.ViprDataMigrationPPMEPlanningDesign;
import com.emc.gs.tools.srf.model.vipr.ViprDataServiceOnCommodityDesignImpl;
import com.emc.gs.tools.srf.model.xtreme.XtremeCache;
import com.emc.gs.tools.srf.model.xtreme.XtremeDataMigration;
import com.emc.gs.tools.srf.model.xtreme.XtremeDataMobilityType;
import com.emc.gs.tools.srf.model.xtreme.XtremeDesignImpl;
import com.emc.gs.tools.srf.model.xtreme.XtremeHostBasedMigrationTool;
import com.emc.gs.tools.srf.model.xtreme.XtremeIOOracleLocalReplication;
import com.emc.gs.tools.srf.model.xtreme.XtremeRequestData;
import com.emc.gs.tools.srf.model.xtreme.XtremeSF;
import com.emc.gs.tools.srf.model.xtreme.XtremeServices;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.apache.pdfbox.exceptions.COSVisitorException;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.common.PDRectangle;
import org.apache.pdfbox.pdmodel.edit.PDPageContentStream;
import org.apache.pdfbox.pdmodel.font.PDFont;
import org.apache.pdfbox.pdmodel.font.PDType1Font;
import org.apache.pdfbox.pdmodel.interactive.action.type.PDActionURI;
import org.apache.pdfbox.pdmodel.interactive.annotation.PDAnnotationLink;

import com.emc.gs.tools.srf.ServiceRequestToolConfigurationException;
import com.emc.gs.tools.srf.model.ASDOptions;
import com.emc.gs.tools.srf.model.AffinityOptions;
import com.emc.gs.tools.srf.model.Attachment;
import com.emc.gs.tools.srf.model.ClearanceLevel;
import com.emc.gs.tools.srf.model.ConsultingOptions;
import com.emc.gs.tools.srf.model.CoreOptions;
import com.emc.gs.tools.srf.model.Customer;
import com.emc.gs.tools.srf.model.CustomerWorkSite;
import com.emc.gs.tools.srf.model.DPADOptions;
import com.emc.gs.tools.srf.model.Division;
import com.emc.gs.tools.srf.model.ExpenseType;
import com.emc.gs.tools.srf.model.Geography;
import com.emc.gs.tools.srf.model.LookupEntity;
import com.emc.gs.tools.srf.model.MeetingStatus;
import com.emc.gs.tools.srf.model.OtherRequestOptions;
import com.emc.gs.tools.srf.model.PdmName;
import com.emc.gs.tools.srf.model.Phone;
import com.emc.gs.tools.srf.model.ProjectType;
import com.emc.gs.tools.srf.model.Region;
import com.emc.gs.tools.srf.model.Request;
import com.emc.gs.tools.srf.model.RequestContractData;
import com.emc.gs.tools.srf.model.RequestType;
import com.emc.gs.tools.srf.model.RiskLevel;
import com.emc.gs.tools.srf.model.ServicesAgreementType;
import com.emc.gs.tools.srf.model.SowLanguage;
import com.emc.gs.tools.srf.model.SowType;
import com.emc.gs.tools.srf.model.StartRequestData;
import com.emc.gs.tools.srf.model.asd.ASDAppSync;
import com.emc.gs.tools.srf.model.asd.ASDRequestData;
import com.emc.gs.tools.srf.model.asd.ASDServicesScope;
import com.emc.gs.tools.srf.model.asd.ASDUIM;
import com.emc.gs.tools.srf.model.atmos.AtmosCenteraRequestData;
import com.emc.gs.tools.srf.model.atmos.AtmosCenteraServicesScope;
import com.emc.gs.tools.srf.model.atmos.AtmosDesignImpl;
import com.emc.gs.tools.srf.model.atmos.CenteraDesignImpl;
import com.emc.gs.tools.srf.model.atmos.CenteraFileErasure;
import com.emc.gs.tools.srf.model.atmos.CenteraIntraClusterMigration;
import com.emc.gs.tools.srf.model.atmos.CenteraToAtmosMigration;
import com.emc.gs.tools.srf.model.atmos.CenteraUniversalAccess;
import com.emc.gs.tools.srf.model.atmos.ExistingCenteraCluster;
import com.emc.gs.tools.srf.model.atmos.ExpansionNodeOnly;
import com.emc.gs.tools.srf.model.atmos.NewCenteraCluster;
import com.emc.gs.tools.srf.model.bc.AreaSizingType;
import com.emc.gs.tools.srf.model.bc.BCServicesScope;
import com.emc.gs.tools.srf.model.bc.BcRequestData;
import com.emc.gs.tools.srf.model.bc.ConfigChangeType;
import com.emc.gs.tools.srf.model.bc.MirrorViewInformation;
import com.emc.gs.tools.srf.model.bc.MirrorViewSourceArrayInformation;
import com.emc.gs.tools.srf.model.bc.MirrorViewTargetArrayInformation;
import com.emc.gs.tools.srf.model.bc.NetworkLinkStatus;
import com.emc.gs.tools.srf.model.bc.OpenReplicator;
import com.emc.gs.tools.srf.model.bc.PostSalesCompletionQualifier;
import com.emc.gs.tools.srf.model.bc.ReplicationManagerImplementation;
import com.emc.gs.tools.srf.model.bc.ReplicationManagerInformation;
import com.emc.gs.tools.srf.model.bc.ReplicationManagerProductSpecificPreparation;
import com.emc.gs.tools.srf.model.bc.ScriptingLevel;
import com.emc.gs.tools.srf.model.bc.SnapViewInformation;
import com.emc.gs.tools.srf.model.bc.SrdfInformation;
import com.emc.gs.tools.srf.model.bc.SrdfSourceArrayInformation;
import com.emc.gs.tools.srf.model.bc.SrdfStaticDynamicType;
import com.emc.gs.tools.srf.model.bc.SrdfTargetArrayInformation;
import com.emc.gs.tools.srf.model.bc.TimeFinderInformation;
import com.emc.gs.tools.srf.model.change.ChangeRequestData;
import com.emc.gs.tools.srf.model.change.HoursByMonth;
import com.emc.gs.tools.srf.model.change.RoleHoursByMonth;
import com.emc.gs.tools.srf.model.cta.CTAConversion;
import com.emc.gs.tools.srf.model.cta.CTAImplementation;
import com.emc.gs.tools.srf.model.cta.CTAImplementationArray;
import com.emc.gs.tools.srf.model.cta.CTARaininfinity;
import com.emc.gs.tools.srf.model.cta.CTARequestData;
import com.emc.gs.tools.srf.model.cta.CTAServicesScope;
import com.emc.gs.tools.srf.model.cta.NASDestination;
import com.emc.gs.tools.srf.model.dpad.Avamar;
import com.emc.gs.tools.srf.model.dpad.AvamarDesign;
import com.emc.gs.tools.srf.model.dpad.AvamarHealthCheck;
import com.emc.gs.tools.srf.model.dpad.AvamarImplementation;
import com.emc.gs.tools.srf.model.dpad.AvamarIntegration;
import com.emc.gs.tools.srf.model.dpad.AvamarMigration;
import com.emc.gs.tools.srf.model.dpad.AvamarNDMP;
import com.emc.gs.tools.srf.model.dpad.AvamarOperationalAssurance;
import com.emc.gs.tools.srf.model.dpad.AvamarOptions;
import com.emc.gs.tools.srf.model.dpad.AvamarPlugins;
import com.emc.gs.tools.srf.model.dpad.AvamarTapeOutDesign;
import com.emc.gs.tools.srf.model.dpad.AvamarTapeOutImplementation;
import com.emc.gs.tools.srf.model.dpad.DPA;
import com.emc.gs.tools.srf.model.dpad.DPACustomization;
import com.emc.gs.tools.srf.model.dpad.DPACustomizationData;
import com.emc.gs.tools.srf.model.dpad.DPADRequestData;
import com.emc.gs.tools.srf.model.dpad.DPADServicesScope;
import com.emc.gs.tools.srf.model.dpad.DPADesign;
import com.emc.gs.tools.srf.model.dpad.DPAHealthCheck;
import com.emc.gs.tools.srf.model.dpad.DPAImplementation;
import com.emc.gs.tools.srf.model.dpad.DPAImplementationData;
import com.emc.gs.tools.srf.model.dpad.DPAOperationalAssurance;
import com.emc.gs.tools.srf.model.dpad.DPAUpgradeMigration;
import com.emc.gs.tools.srf.model.dpad.DataDomain;
import com.emc.gs.tools.srf.model.dpad.DataDomainBoost;
import com.emc.gs.tools.srf.model.dpad.DataDomainBoostBackupServer;
import com.emc.gs.tools.srf.model.dpad.DataDomainDataStaging;
import com.emc.gs.tools.srf.model.dpad.DataDomainDesign;
import com.emc.gs.tools.srf.model.dpad.DataDomainDesignApplianceModel;
import com.emc.gs.tools.srf.model.dpad.DataDomainExpansionShelf;
import com.emc.gs.tools.srf.model.dpad.DataDomainExtendedRetentionConversion;
import com.emc.gs.tools.srf.model.dpad.DataDomainHealthCheck;
import com.emc.gs.tools.srf.model.dpad.DataDomainImplApplianceModel;
import com.emc.gs.tools.srf.model.dpad.DataDomainImplementation;
import com.emc.gs.tools.srf.model.dpad.DataDomainIntegration;
import com.emc.gs.tools.srf.model.dpad.DataDomainManagementCenterConfig;
import com.emc.gs.tools.srf.model.dpad.DataDomainMigration;
import com.emc.gs.tools.srf.model.dpad.DataDomainPreRack;
import com.emc.gs.tools.srf.model.dpad.DataDomainSapHana;
import com.emc.gs.tools.srf.model.dpad.DataDomainUpgrade;
import com.emc.gs.tools.srf.model.dpad.DataDomainVTL;
import com.emc.gs.tools.srf.model.dpad.EDL;
import com.emc.gs.tools.srf.model.dpad.EDLDesignImpl;
import com.emc.gs.tools.srf.model.dpad.Networker;
import com.emc.gs.tools.srf.model.dpad.NetworkerAdvancedBackupTechBase;
import com.emc.gs.tools.srf.model.dpad.NetworkerAdvancedBackupTechDesign;
import com.emc.gs.tools.srf.model.dpad.NetworkerApplicationBackupsBase;
import com.emc.gs.tools.srf.model.dpad.NetworkerApplicationBackupsDesign;
import com.emc.gs.tools.srf.model.dpad.NetworkerComponents;
import com.emc.gs.tools.srf.model.dpad.NetworkerDesign;
import com.emc.gs.tools.srf.model.dpad.NetworkerFileSystemClientBackupsDesign;
import com.emc.gs.tools.srf.model.dpad.NetworkerImplementation;
import com.emc.gs.tools.srf.model.dpad.NetworkerMediaDevices;
import com.emc.gs.tools.srf.model.dpad.NetworkerServerDesign;
import com.emc.gs.tools.srf.model.dpad.NetworkerStorageNodes;
import com.emc.gs.tools.srf.model.dpad.NetworkerUpgrade;
import com.emc.gs.tools.srf.model.dpad.RecoverPoint;
import com.emc.gs.tools.srf.model.dpad.Vplex;
import com.emc.gs.tools.srf.model.engagement.DeliveryCountry;
import com.emc.gs.tools.srf.model.engagement.EngagementTypeData;
import com.emc.gs.tools.srf.model.engagement.SRTPath;
import com.emc.gs.tools.srf.model.estimate.BOERole;
import com.emc.gs.tools.srf.model.estimate.BillingType;
import com.emc.gs.tools.srf.model.estimate.Competency;
import com.emc.gs.tools.srf.model.estimate.DealCurrency;
import com.emc.gs.tools.srf.model.estimate.DeliverAction;
import com.emc.gs.tools.srf.model.estimate.EstimatesData;
import com.emc.gs.tools.srf.model.estimate.LOB;
import com.emc.gs.tools.srf.model.estimate.MaterialCode;
import com.emc.gs.tools.srf.model.healthcheck.HealthCheckAvamar;
import com.emc.gs.tools.srf.model.healthcheck.HealthCheckDLM;
import com.emc.gs.tools.srf.model.healthcheck.HealthCheckDPA;
import com.emc.gs.tools.srf.model.healthcheck.HealthCheckDataDomain;
import com.emc.gs.tools.srf.model.healthcheck.HealthCheckGreenPlum;
import com.emc.gs.tools.srf.model.healthcheck.HealthCheckIonix;
import com.emc.gs.tools.srf.model.healthcheck.HealthCheckNetWorker;
import com.emc.gs.tools.srf.model.healthcheck.HealthCheckRequestData;
import com.emc.gs.tools.srf.model.healthcheck.HealthCheckSAP;
import com.emc.gs.tools.srf.model.healthcheck.HealthCheckSanSecurity;
import com.emc.gs.tools.srf.model.healthcheck.HealthCheckServicesScope;
import com.emc.gs.tools.srf.model.healthcheck.HealthCheckSourceOne;
import com.emc.gs.tools.srf.model.healthcheck.HealthCheckSymmetrixVmax;
import com.emc.gs.tools.srf.model.healthcheck.HealthCheckSymmetrixVmaxStorageReplication;
import com.emc.gs.tools.srf.model.healthcheck.HealthCheckUnified;
import com.emc.gs.tools.srf.model.healthcheck.HealthCheckVblock;
import com.emc.gs.tools.srf.model.healthcheck.HealthCheckVmwareVirtualInfrastructure;
import com.emc.gs.tools.srf.model.healthcheck.HealthCheckVplex;
import com.emc.gs.tools.srf.model.infrastructure.DataMigrationInformation;
import com.emc.gs.tools.srf.model.infrastructure.DataMigrationInformationArray;
import com.emc.gs.tools.srf.model.infrastructure.EnvironmentDetailsHostInfo;
import com.emc.gs.tools.srf.model.infrastructure.EnvironmentDetailsInformation;
import com.emc.gs.tools.srf.model.infrastructure.EnvironmentGatherer;
import com.emc.gs.tools.srf.model.infrastructure.InfrastructureRequestData;
import com.emc.gs.tools.srf.model.infrastructure.SanTanInformation;
import com.emc.gs.tools.srf.model.infrastructure.VnxClariionInformation;
import com.emc.gs.tools.srf.model.infrastructure.VnxInstallProtocolType;
import com.emc.gs.tools.srf.model.isilon.IsilonClusterRelocation;
import com.emc.gs.tools.srf.model.isilon.IsilonDesignAndImpl;
import com.emc.gs.tools.srf.model.isilon.IsilonHardwareUpgrade;
import com.emc.gs.tools.srf.model.isilon.IsilonMigration;
import com.emc.gs.tools.srf.model.isilon.IsilonRequestData;
import com.emc.gs.tools.srf.model.isilon.IsilonServicesScope;
import com.emc.gs.tools.srf.model.mainframe.BooleanServiceData;
import com.emc.gs.tools.srf.model.mainframe.MainframeRequestData;
import com.emc.gs.tools.srf.model.mainframe.MainframeServicesScope;
import com.emc.gs.tools.srf.model.mainframe.ServiceData;
import com.emc.gs.tools.srf.model.mainframe.StringServiceData;
import com.emc.gs.tools.srf.model.move.MoveRequestData;
import com.emc.gs.tools.srf.model.move.SiteInformation;
import com.emc.gs.tools.srf.model.mss.MSSArray;
import com.emc.gs.tools.srf.model.mss.MSSAtmos;
import com.emc.gs.tools.srf.model.mss.MSSAvamarNodes;
import com.emc.gs.tools.srf.model.mss.MSSCenteraNodes;
import com.emc.gs.tools.srf.model.mss.MSSClariionAx4Drives;
import com.emc.gs.tools.srf.model.mss.MSSDataDomain;
import com.emc.gs.tools.srf.model.mss.MSSFcAtaDrives;
import com.emc.gs.tools.srf.model.mss.MSSFlashDrives;
import com.emc.gs.tools.srf.model.mss.MSSGreenplum;
import com.emc.gs.tools.srf.model.mss.MSSRequestData;
import com.emc.gs.tools.srf.model.mss.MSSVnxSasDrives;
import com.emc.gs.tools.srf.model.residency.ResidencyRequestData;
import com.emc.gs.tools.srf.model.residency.RoleSkillLevel;
import com.emc.gs.tools.srf.model.sourceone.SourceOneDROptions;
import com.emc.gs.tools.srf.model.sourceone.SourceOneDesignImpl;
import com.emc.gs.tools.srf.model.sourceone.SourceOneFeatures;
import com.emc.gs.tools.srf.model.sourceone.SourceOneHealthCheck;
import com.emc.gs.tools.srf.model.sourceone.SourceOneMigration;
import com.emc.gs.tools.srf.model.sourceone.SourceOneRequestData;
import com.emc.gs.tools.srf.model.sourceone.SourceOneServicesScope;
import com.emc.gs.tools.srf.model.sourceone.SourceOneUpgrade;
import com.emc.gs.tools.srf.model.srm.SRMRequestData;
import com.emc.gs.tools.srf.model.unfunded.UnfundedProjectData;
import com.emc.gs.tools.srf.model.unified.CelerraDetailInformation;
import com.emc.gs.tools.srf.model.unified.NasFeature;
import com.emc.gs.tools.srf.model.unified.NasIpReplicationInformation;
import com.emc.gs.tools.srf.model.unified.NasMigrationInformation;
import com.emc.gs.tools.srf.model.unified.UnifiedRequestData;
import com.emc.gs.tools.srf.model.unified.UnifiedServicesScope;
import com.emc.gs.tools.srf.model.vblock.VblockDesignImpl;
import com.emc.gs.tools.srf.model.vblock.VblockInfrastructure;
import com.emc.gs.tools.srf.model.vblock.VblockProject;
import com.emc.gs.tools.srf.model.vblock.VblockRequestData;
import com.emc.gs.tools.srf.model.vblock.VblockServices;
import com.emc.gs.tools.srf.model.vblock.VblockTechAssessment;
import com.emc.gs.tools.srf.model.vipr.ViprImplementation;
import com.emc.gs.tools.srf.model.vipr.ViprRequestData;
import com.emc.gs.tools.srf.model.vmware.VMwareAssessment;
import com.emc.gs.tools.srf.model.vmware.VMwareAssessmentType;
import com.emc.gs.tools.srf.model.vmware.VMwareBackupRecovery;
import com.emc.gs.tools.srf.model.vmware.VMwareConverter;
import com.emc.gs.tools.srf.model.vmware.VMwareHealthChecks;
import com.emc.gs.tools.srf.model.vmware.VMwareReplication;
import com.emc.gs.tools.srf.model.vmware.VMwareRequestData;
import com.emc.gs.tools.srf.model.vmware.VMwareServicesScope;
import com.emc.gs.tools.srf.model.vmware.VMwareSvMotion;
import com.emc.gs.tools.srf.model.vmware.VMwareTCOAssessment;
import com.emc.gs.tools.srf.model.vmware.VMwareVSphere;
import com.emc.gs.tools.srf.model.vmware.VMwareVblock;
import com.emc.gs.tools.srf.model.vmware.VMwareVblockDesignImpl;
import com.emc.gs.tools.srf.model.vmware.VMwareVblockInfraImpl;
import com.emc.gs.tools.srf.model.vmware.VMwareVblockInfraTechAssessment;
import com.emc.gs.tools.srf.model.vmware.VMwareView;
import com.emc.gs.tools.srf.model.vmware.VMwareViewDesign;
import com.emc.gs.tools.srf.model.vmware.VMwareViewImpl;
import com.emc.gs.tools.srf.model.vmware.VMwareVirtualInfra;
import com.emc.gs.tools.srf.model.vmware.VMwareVirtualInfraDesignImpl;
import com.emc.gs.tools.srf.model.vmware.VMwareVirtualInfraDesignImplJumpStart;
import com.emc.gs.tools.srf.model.vmware.VMwareVirtualInfraImpl;
import com.emc.gs.tools.srf.model.vmware.VMwareVirtualInfraServerStorageDesign;
import com.emc.gs.tools.srf.model.w4n.W4NData;
import com.emc.gs.tools.srf.services.EnabledTabs;
import com.emc.gs.tools.srf.services.EstimatesService;
import com.emc.gs.tools.srf.services.ExportService;
import com.emc.gs.tools.srf.services.ExportServiceException;
import com.emc.gs.tools.srf.services.ServiceRequestToolException;
import com.emc.gs.tools.srf.services.estimate.dto.EstimatedLOB;
import com.emc.gs.tools.srf.services.estimate.dto.EstimatedResource;
import com.emc.gs.tools.srf.services.estimate.dto.EstimatedResult;
import com.emc.gs.tools.srf.services.estimate.dto.PricingOverview;

/**
 * <p>
 * This class is the implementation of the ExportService. It utilizes Apache PDFBox for necessary operations.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is immutable and thread safe
 * </p>
 * <p>
 * <strong>Changes V1.1:</strong> <strong>SRT Release Assembly - Base</strong>
 * <ul>
 * <li>Release_assembly_tasks.xls Row#2: Removed programDeliveryManagerName getter/setter from StartRequestData</li>
 * <li>Release_assembly_tasks.xls Row#3: Added travelRequirements</li>
 * <li>Release_assembly_tasks.xls Row#4: Renamed selera to celerra</li>
 * <li>Release_assembly_tasks.xls Row#5: Renamed getter/setter of name to contactName</li>
 * <li>Release_assembly_tasks.xls Row#7: Renamed CustomerContractData to RequestContractData</li>
 * <li>Changes to add customer information</li>
 * <li>Changes to add infrastructure information</li>
 * </ul>
 * </p>
 * <p>
 * <strong>Changes V1.2:</strong> <strong>SRT Release Assembly - BC Tab</strong>
 * <ul>
 * <li>Change to use {@link GeneralProjectParameters#getScriptingLevelOption()} property instead of scriptingLevel</li>
 * </ul>
 * </p>
 * <p>
 * <strong>Changes V1.3:</strong> <strong>SRT Bug Fixes</strong>
 * <ul>
 * <li>Rename/Remove some exported fields.</li>
 * </ul>
 * </p>
 * <p>
 * <strong>Changes V1.4:</strong> <strong>SRT Bug Fixes - F121, F153, F154, F162</strong>
 * <ul>
 * <li>Change "# days of knowledge transfer" label to "# hours of knowledge transfer".</li>
 * <li>Add logic for "# hours of knowledge transfer" field from the sub-sections .</li>
 * <li>Add getTotalHoursOfKnOwrowledgeTransferInf, getTotalHoursOfKnowledgeTransferUnified,
 * getTotalHoursOfKnowledgeTransferBc methods.</li>
 * </ul>
 * </p>
 * <p>
 * <strong>Changes V1.5:</strong>
 * <ul>
 * <li>Removed logic related to removed fields/sections.</li>
 * </ul>
 * </p>
 * <p>
 * <strong>Changes V1.6:</strong> <strong>https://apps.topcoder.com/bugs/browse/SRT-35</strong>
 * <ul>
 * <li>Added logic related to removed fields/sections.</li>
 * </ul>
 * </p>
 * <p>
 * <strong>Changes V1.7:</strong> <strong>SRT Phase 3-3 - BRS Tab Assembly</strong>
 * <ul>
 * <li>Added methods to write BRS request data to PDF.</li>
 * <li>Added drawDynColTable() method which is commonly suitable to draw dynamic columns table.</li>
 * <li>Added writeAnswer() method which is commonly suitable to write question & answer pair.</li>
 * <li>Enhanced drawTable() method by adding highlightLastRow parameter which indicates whether to highlight the last
 * row.</li>
 * </ul>
 * </p>
 * <p>
 * <strong>Changes V1.8:</strong> <strong>SRT Phase 3-1 - CTA Rainfinity and MSS Tabs Assembly</strong>
 * <ul>
 * <li>Added methods to write MSS/CTA request data to PDF.</li>
 * </ul>
 * </p>
 * <p>
 * <strong>Changes V1.9:</strong> <strong>SRT Phase 3-3 - Isilon and Residency Tabs Assembly</strong>
 * <ul>
 * <li>Added methods to write Isilon/Residency request data to PDF.</li>
 * <li>Enhanced drawTable() method by adding columnWidths parameter for customize the columns width.</li>
 * </ul>
 * </p>
 * <p>
 * <strong>Changes V2.0:</strong> <strong>SRT Phase 3-1 - CTA Rainfinity and MSS Tabs Update Assembly</strong>
 * <ul>
 * <li>Add "General Comment" field for all tabs</li>
 * <li>Update CTA/MSS tabs.</li>
 * </ul>
 * </p>
 * <p>
 * <strong>Changes V2.1:</strong>
 * <strong>SRT Phase 3-3 - Remove BRS and Isilon and Update Residency and Implement SourceOne Tabs Assembly</strong>
 * <ul>
 * <li>Remove BRS/Isilon tabs.</li>
 * <li>Update Residency tab.</li>
 * <li>Add SourceOne tab.</li>
 * </ul>
 * </p>
 * <p>
 * <strong>Changes V2.2:</strong>
 * <strong>SRT Phase 3-4 - ASD and Healthcheck Tabs Assembly</strong>
 * <ul>
 * <li>Update ASD options.</li>
 * <li>Add ASD/HealthCheck tabs.</li>
 * </ul>
 * </p>
 * <p>
 * <strong>Changes V2.3:</strong>
 * <strong>SRT Phase 3-3 - Implement Isilon and ViPR Tabs Assembly</strong>
 * <ul>
 * <li>Add Isilon/ViPR tabs.</li>
 * </ul>
 * </p>
 * <p>
 * <strong>Changes V2.4:</strong>
 * <strong>SRT Phase 3-1 - Atmos Centera and Vblock Tabs Assembly</strong>
 * <ul>
 * <li>Add Atmos/Vblock tabs.</li>
 * <li>Add a common method drawHyperLink() to draw hyper link.</li>
 * </ul>
 * </p>
 * <p>
 * <strong>Changes V2.5:</strong>
 * <strong>SRT Phase 3-5 - BRS Tabs Part 1 Assembly</strong>
 * <ul>
 * <li>Add DPAD tab. Move Vplex and RecoverPorint sections to DPAD tab.</li>
 * </ul>
 * </p>
 * <p>
 * <strong>Changes V2.6:</strong>
 * <strong>SRT Phase 3-1 - Implement VMWare Tab Assembly</strong>
 * <ul>
 * <li>Add VMWare tab.</li>
 * </ul>
 * </p>
 * <p>
 * <strong>Changes V2.7:</strong>
 * <strong>SRT Phase 3-5 - BRS Tabs Part 2 Assembly</strong>
 * <ul>
 * <li>Add Data Domain and DPA sections to DPAD tab.</li>
 * </ul>
 * </p>
 * <p>
 * <strong>Changes V2.8:</strong>
 * <strong>SRT Phase 3-5 - BRS Tabs Part 3 Assembly</strong>
 * <ul>
 * <li>Add Networker section to DPAD tab.</li>
 * </ul>
 * </p>
 * <p>
 * <strong>Changes V2.9:</strong>
 * <strong>SRT Phase 3 Merge Assembly</strong>
 * <ul>
 * <li>Add methods to export MoveRequest/ChangeRequest/W4N/Unfunded/SRM data.</li>
 * </ul>
 * </p>
 *
 * <p>
 * Version 2.10 (SRT Phase 3 Pilot - Mozy and Xtrem and Vipr Tabs Assembly) Change notes:
 *   <ol>
 *     <li>Added support for exporting Mozy tab data.</li>
 *     <li>Added support for exporting Xtreme tab data.</li>
 *   </ol>
 * </p>
 *
 * <p>
 * <strong>Changes V2.11:</strong>
 * <strong>SRT Phase 4 - ET Assembly 1</strong>
 * <ul>
 * <li>SRT Phase 4 refactor.</li>
 * </ul>
 * </p>
 *
 * <p>
 * Version 2.12 (SRT Phase 4 - ET Release Assembly) Change notes:
 *   <ol>
 *     <li>Changed {@link #writeProjectInfo(PDPageContentStream, Request, int)} method to output "Presales Risk Factor"
 *     title instead of "Risk Level"</li>
 *     <li>Changed {@link #writeProjectInfo(PDPageContentStream, Request, int)} method to output "Project Regulatory
 *     Type" field.</li>
 *     <li>Changed {@link #writeProjectInfo(PDPageContentStream, Request, int)} method to output "Expense Type" field.
 *     </li>
 *   </ol>
 * </p>
 *
 * <p>
 * Version 2.13 (SRT 4 OCT2014 Updates Part 1 Assembly) Change notes:
 *   <ol>
 *     <li>Updated {@link #getBcRequestDataOptions1(BcRequestData)} method to reflect the change to
 *     {@link BCServicesScope} class.</li>
 *     <li>Updated {@link #writeSRDFTargetArrayInformation(PDPageContentStream, SrdfInformation, int)} method to reflect
 *     the changes to "SRDF Target Array Information" section.</li>
 *     <li>Updated {@link #writeBcRequestData(PDPageContentStream, BcRequestData, UnifiedRequestData,
 *     InfrastructureRequestData, int, PDPage)} method to reflect the changes to "SRDF", "TimeFinder", "MirrorView",
 *     "SnapView/Snapshots" sections.</li>
 *     <li>Updated {@link #writeResidencyRequestData(PDPageContentStream, ResidencyRequestData, int, PDPage)} method to
 *     reflect the changes to "Residency" tab.</l>
 *     <li>Removed <code>getBcTimefinderDatabaseContents</code> method.</li>
 *     <li>Added {@link #writeXtremeIOOracleLocalReplication(PDPageContentStream, XtremeIOOracleLocalReplication, int,
 *     float)} method.</li>
 *     <li>Updated {@link #getHostMigrationInformationContents(InfrastructureRequestData)} method to remove Topology
 *     column.</li>
 *     <li>Updated {@link #writeNetworker(PDPageContentStream, PDPage, Networker, int, float)} method to write content
 *     of newly defined <code>Networker Healthcheck</code> section.</li>
 *     <li>Added {@link #writeNetworkerHealthcheck(PDPageContentStream, NetworkerHealthcheck, int, float)} method.</li>
 *   </ol>
 * </p>
 *
 * <p>
 * Version 2.14 (SRT 4 OCT2014 Updates Part 2 Assembly) Change notes:
 *   <ol>
 *     <li>Updated {@link #getTotalKnowledgeTransferHoursDPAD(DPADRequestData)} method to exclude RecoverPoint class.</li>
 *     <li>Removed <code>getRecoverPointSiteContents</code> method.</li>
 *     <li>Removed <code>getRecoverPointHostContents</code> method.</li>
 *     <li>Re-written {@link #writeRecoverPoint(PDPageContentStream, PDPage, RecoverPoint, int, float)} method to follow
 *     the design for <code>RecoverPoint</code> class.</li>
 *     <li>Updated {@link #getRoleSkillLevelColumns(RoleSkillLevel)} as <code>RoleSkillLevel#rate</code> property has
 *     been removed.</li>
 *     <li>Updated <code>getResidency...</code> methods to remove "Rate ($) column.</li>
 *     <li>Updated {@link #writeIsilonRequestDataDesignImpl(PDPageContentStream, IsilonRequestData, int, PDPage)} method
 *     to export newly added fields.</li>
 *     <li>Updated {@link #writeIsilonRequestDataHardwareUpgrade(PDPageContentStream, IsilonRequestData, int, PDPage)} 
 *     to export numeric field for any choise for Yes/No field.</li>
 *     <li>Updated {@link #writeVblockRequestData(PDPageContentStream, VblockRequestData, int, PDPage)} to remove 
 *     exporting requested properties and add newly defined properties.</li>
 *     <li>Updated {@link #writeResidencyRequestData(PDPageContentStream, ResidencyRequestData, int, PDPage)} method
 *     to export newly added fields.</li>
 *   </ol>
 * </p>
 *
 * <p>
 * Version 2.15 (SRT 1.1 DEC 2014 Updates Assembly) Change notes:
 *   <ol>
 *     <li>Updated {@link #writeCustomerInfo(PDPageContentStream, Request, int)} method 
 *     with the new customer work site fields.</li>
 *     <li>Renamed "Product Lead" to "Product Led" and "Service Lead" to "Service Led".</li>
 *   </ol>
 * </p>
 *
 * <p>
 * Version 2.16 Change notes:
 *   <ol>
 *     <li>Updated {@link #writeProjectInfo(PDPageContentStream, Request, int)} method to write project description.
 *     </li>
 *   </ol>
 * </p>
 *
 * <p>
 * Version 2.17 Change notes:
 *   <ol>
 *     <li>The logic for exporting SAN/Connectivity tab data is separated from Infrastructure tab.</li>
 *   </ol>
 * </p>
 *
 * <p>
 * Version 2.18 Change notes:
 *   <ol>
 *     <li>Added logic for exporting Symm MF, Symm OS data.</li>
 *   </ol>
 * </p>
 *
 * <p>
 * Version 2.19 Change notes:
 *   <ol>
 *     <li>Updated {@link #writeEngagement(PDPageContentStream, Request, int)} method to use "Booking Country" title
 *     instead of "Delivery Country".</li>
 *   </ol>
 * </p>
 * 
 *
 * <p>
 * Version 2.20 Change notes:
 * <ol>
 * <li>Added ET request PDF export functionality.</li>
 * </ol>
 * </p>
 * 
 * <p>
 * Version 2.21 Change notes:
 *   <ol>
 *     <li>Changed the type of {@link EnvironmentDetailsInformation#hostInformation} property from <code>Map</code> to 
 *     <code>List</code>.</li>
 *     <li>Removed <code>Symmetrix</code> data from <code>Core</code> tab.</li>
 *     <li>Moved <code>VPLEX</code> data from <code>DPAD</code> to <code>Core</code> tab.</li>
 *     <li>Expanded DataDomainDesign entity with same set of properties as DataDomainImplementation entity.</li>
 *   </ol>
 * </p>
 *
 * <p>
 * Version 2.22 Change notes:
 *   <ol>
 *     <li>Fixed bug in {@link #writePsProjectData(PDPageContentStream, Request, int)} method with matching work cities
 *     to customer site.</li>
 *   </ol>
 * </p>
 *
 * <p>
 * Version 2.23 Change notes:
 *   <ol>
 *     <li>Removed old SRT4 PDF export methods/fields</li>
 *     <li>Added FONT_TEXT_OBLIQUE, RISK_CALC_COL_WIDTH constants</li>
 *     <li>Updated exportRequests method with the new sections to be exported</li>
 *     <li>Updated exportETRequest method with the new sections to be exported</li>
 *     <li>Added exportRiskCalculation method</li>
 *     <li>Added getPgmoHours method</li>
 *     <li>Added getIncreasedRiskBasedOnListPrice method</li>
 *     <li>Added calculateContingency method</li>
 *     <li>Implemented exportEstimates method</li>
 *     <li>Added exportPricingOverview method</li>
 *     <li>Added setPricingOverviewNumberText method</li>
 *     <li>Added setPricingOverviewDecimalText method</li>
 *     <li>Added setPricingOverviewDecimalPercentText method</li>
 *     <li>Added exportPricingExpenses method</li>
 *     <li>Added exportPricingDiscounting method</li>
 *     <li>Added drawPricingTable method</li>
 *     <li>Added drawPricingOverviewDynColTable method</li>
 *     <li>Added createLongWidthTableContent method</li>
 *     <li>Added getExpensesTableContents method</li>
 *     <li>Added getFPMCDiscountingTableContents method</li>
 *     <li>Added getTMDiscountingTableContents method</li>
 *     <li>Added writeText method</li>
 *     <li>Added drawEstimatesDynColTable method</li>
 *     <li>Added hasColon parameter to writeToCol method</li>
 *     <li>Updated breakToLinesBySpace method, changed work breaking regex</li>
 *   </ol>
 * </p>
 *
 * <p>
 * Version 2.24 Change notes:
 *   <ol>
 *     <li>Estimates tab "Months of Entry" is extended up to 7 years (84 months).</li>
 *     <li>Changed the type of {@link StartRequestData#remoteAccess} property to <code>Boolean</code>.</li>
 *     <li>Renamed "DXP Opportunity Number" field to "Opportunity Number".</li>
 *     <li>Renamed "Direct Express (DX) Quote Number" field to "Quote Number".</li>
 *     <li>Renamed "Disk Retention / Certified Data Erasure - Single Disk" option to 
 *     "Certified Data Erasure - Single Disk"</li>
 *     <li>Risk Calculation is exported based on request conditions.</li>
 *     <li>Added logic for exporting data for <code>Avamar ADME Configuration</code> section.</li>
 *     <li>Added logic for exporting data for <code>Assessment</code> section.</li>
 *     <li>Added logic for exporting data for <code>ProtectPoint</code> section.</li>
 *     <li>Renamed "# of EDL Virtual Tape Libraries" to "# of VTL's to create" in
 *     {@link #writeDataDomainImpl(PDPageContentStream, PDPage, DataDomain, int, float)} method.</li>
 *     <li>Removed exporting "Virtual Tape Library Appliances" column from
 *     {@link #writeDataDomainImpl(PDPageContentStream, PDPage, DataDomain, int, float)} method.</li>
 *     <li>Added logic for exporting data for <code>Netapp migration to Isilon (Node Based/3rd party tools)</code> 
 *     section in <code>Isilon Migration</code>.</li>
 *   </ol>
 * </p>
 * 
 * @author faeton, stevenfrog, isv, MonicaMuranyi
 * @version 2.24
 */
public class ExportServiceImpl extends BaseLoggerService implements ExportService {
    /**
     * <p>
     * Represents the class name.
     * </p>
     */
    private static final String CLASSNAME = ExportServiceImpl.class.getName();

    /**
     * The default font size.
     */
    private static final String DEFAULT_DATE_FORMAT = "MM/dd/yyyy";
    /**
     * The default font size.
     */
    private static final int DEFAULT_FONT_SIZE = 8;

    /**
     * The default page height.
     */
    private static final float DEFAULT_PAGE_HEIGHT = 18000;
    /**
     * The default page width.
     */
    private static final float DEFAULT_PAGE_WIDTH = PDPage.PAGE_SIZE_A4.getWidth();
    /**
     * The default page padding.
     */
    private static final float DEFAULT_PAGE_PADDING = 30.0f;
    /**
     * The default page padding.
     */
    private static final float CELL_HEIGHT = 15.0f;
    /**
     * Font Helvetica.
     */
    private static final PDFont FONT_TEXT = PDType1Font.HELVETICA;
    /**
     * Font Helvetica Bold.
     */
    private static final PDFont FONT_TEXT_BOLD = PDType1Font.HELVETICA_BOLD;
    /**
     * Font Helvetica Oblique.
     */
    private static final PDFont FONT_TEXT_OBLIQUE = PDType1Font.HELVETICA_OBLIQUE;
    /**
     * The default page padding.
     */
    private static final float COLON_PADDING = 10.0f;
    /**
     * The default page padding.
     */
    private static final float SECOND_LIST_START = 280.0f;
    /**
     * The default page padding.
     */
    private static final float PROJECT_COL_WIDTH = 160.0f;
    /**
     * The risk calculation column width.
     */
    private static final float RISK_CALC_COL_WIDTH = 200.0f;

    /**
     * Platforms.
     */
    private static final String[] PLATFORMS = new String[] {"Windows", "Solaris", "AIX", "HP-UX", "Linux",
        "VMWare ESX", "NetWare", "HP VMS", "Other"};

    /**
     * Represents the tabs enabled. It is modified by setter. It is injected by Spring. It can not be null or empty
     * after injected.
     */
    private EnabledTabs enabledTabs;

    /**
     * Represents the EstimatesService instance for managing estimates data. It is modified by setter. It is injected by
     * Spring. It can not be null after injected.
     */
    private EstimatesService estimatesService;

    /**
     * Creates instance of the class.
     */
    public ExportServiceImpl() {
        // Empty
    }

    /**
     * Exports the requests to the PDF. The contents of the PDF are written to the output stream.
     *
     * @param requests
     *            the list of requests to export
     * @param stream
     *            output stream to write PDF contents.
     * @throws IllegalArgumentException
     *             if requests is null/contains null elements, stream is null.
     * @throws ExportServiceException
     *             if there is any problem when performing operation.
     */
    public void exportRequests(List<Request> requests, OutputStream stream) throws ExportServiceException {
        final String signature = CLASSNAME + "#exportRequests(List<Request> requests, OutputStream stream)";
        Logger logger = getLogger();

        // Log entry
        Helper.logEntrance(logger, signature, new String[] {"requests"}, new Object[] {requests});

        Helper.checkNull(logger, signature, requests, "requests");
        Helper.checkNull(logger, signature, stream, "stream");
        for (Request request : requests) {
            Helper.checkNull(logger, signature, request, "item in requests");
        }

        PDDocument document = null;
        try {
            // Create a document
            document = new PDDocument();
            for (Request request : requests) {

                // Calculate path
                SRTPath path = request.getEngagementTypeData() == null ? SRTPath.UNKNOWN
                        : request.getEngagementTypeData().calculateSRTPath();

                // Create a new page
                PDPage page = newPage(document);
                // Start streaming the content
                PDPageContentStream contentStream = new PDPageContentStream(document, page);

                try {
                    int row = 1;

                    // Write Project Info
                    row = writeProjectInfo(contentStream, request, row, path);

                    // Write Engagement Type
                    row = writeEngagement(contentStream, request, row);

                    if (path == SRTPath.SRT3 || path == SRTPath.SRT_HYBRID) {
                        // Write Service Request information
                        row = writeServiceRequestInfo(contentStream, request, row);

                        // Write Customer information
                        row = writeCustomerInfo(contentStream, request, row);
                    }

                    endPage(page, row);
                } finally {
                    contentStream.close();
                }

                if (path == SRTPath.SRT3 || path == SRTPath.SRT_HYBRID) {
                    // Write Service Activities
                    exportServiceActivities(request, document);
                }

                if (path == SRTPath.SRT_HYBRID) {
                    // Export Estimates information
                    exportEstimates(request, document);

                    // Export Pricing Overview information
                    exportPricingOverview(request, document);

                    // Export Pricing Expenses information
                    exportPricingExpenses(request, document);

                    // Export Pricing Discounting information
                    exportPricingDiscounting(request, document);
                }
                
                if (path == SRTPath.SRT3 || path == SRTPath.SRT_HYBRID) {
                    // Export Risk Calculation information
                    if (Helper.isRiskCalculationRequired(request)) {
                        exportRiskCalculation(request, document);
                    }
                }
            }

            document.save(stream);

            // Log exit
            Helper.logExit(logger, signature, null);
        } catch (IOException e) {
            // Log exception
            throw Helper.logException(logger, signature, new ExportServiceException("IO error occurs.", e));
        } catch (COSVisitorException e) {
            // Log exception
            throw Helper.logException(logger, signature, new ExportServiceException(
                    "Error occurs while saving stream.", e));
        } catch (ServiceRequestToolException e) {
            // Log exception
            throw Helper.logException(logger, signature, new ExportServiceException(
                    "Server error occurs.", e));
        } catch (Throwable e) {
            // Log exception
            throw Helper.logException(logger, signature, new ExportServiceException("Server error occurs.", e));
        } finally {
            if (document != null) {
                try {
                    document.close();
                } catch (IOException e) {
                    // Ignore
                }
            }
        }
    }

    /**
     * Exports the requests to the PDF. The contents of the PDF are written to
     * the output stream.
     *
     * @param requests
     *            the list of requests to export
     * @param stream
     *            output stream to write PDF contents.
     * @throws IllegalArgumentException
     *             if requests is null/contains null elements, stream is null.
     * @throws ExportServiceException
     *             if there is any problem when performing operation.
     * @since 2.20
     */
    public void exportETRequest(Request request, OutputStream stream) throws ExportServiceException {
        final String signature = CLASSNAME + "#exportETRequest(Request request, OutputStream stream)";
        Logger logger = getLogger();
 
        // Log entry
        Helper.logEntrance(logger, signature, new String[] { "request" }, new Object[] { request });
 
        Helper.checkNull(logger, signature, request, "request");
        Helper.checkNull(logger, signature, stream, "stream");
 
        PDDocument document = null;
        try {
            // Create a document
            document = new PDDocument();
 
            // Create a new page
            PDPage page = newPage(document);
            // Start streaming the content
            PDPageContentStream contentStream = new PDPageContentStream(document, page);
            try {
                int row = 1;
                
                // Calculate path
                SRTPath path = request.getEngagementTypeData() == null ? SRTPath.UNKNOWN
                        : request.getEngagementTypeData().calculateSRTPath();
                
                // Write Project Info
                row = writeProjectInfo(contentStream, request, row, path);
                
                // Write Engagement Type
                row = writeEngagement(contentStream, request, row);
                
                endPage(page, row);
            } finally {
                contentStream.close();
            }
            try {
                // Export Estimates information
                exportEstimates(request, document);

                // Export Pricing Overview information
                exportPricingOverview(request, document);

                // Export Pricing Expenses information
                exportPricingExpenses(request, document);

                // Export Pricing Discounting information
                exportPricingDiscounting(request, document);

                // Export Risk Calculation information

                if (Helper.isRiskCalculationRequired(request)) {
                    exportRiskCalculation(request, document);
                }
            } finally {
                document.save(stream);
            }
 
            // Log exit
            Helper.logExit(logger, signature, null);
        } catch (IOException e) {
            // Log exception
            throw Helper.logException(logger, signature, new ExportServiceException("IO error occurs.", e));
        } catch (COSVisitorException e) {
            // Log exception
            throw Helper.logException(logger, signature, new ExportServiceException(
                    "Error occurs while saving stream.", e));
        } catch (Throwable e) {
            // Log exception
            throw Helper.logException(logger, signature, new ExportServiceException("Server error occurs.", e));
        } finally {
            if (document != null) {
                try {
                    document.close();
                } catch (IOException e) {
                    // Ignore
                }
            }
        }
    }

    /**
     * Exports risk calculation info.
     *
     * @param request
     *            The service request.
     * @param document
     *            The PDF document.
     * @throws IOException
     *             if any I/O error occurs
     * @since 2.23
     */
    private void exportRiskCalculation(Request request, PDDocument document) throws IOException {

        PDPageContentStream contentStream;
        PDPage page;
        int row = 1;

        RiskCalculationData riskCalculationData = request.getRiskCalculationData();
        if (riskCalculationData != null) {

            page = newPage(document);
            contentStream = new PDPageContentStream(document, page);
            try {
                float leftOffset = 0f;
                float middleOffset = 210f;
                float rightOffset = 345f;

                Integer risk = 0;

                row = writeFont(contentStream, "RISK CALCULATION", ++row, leftOffset, true);
                row = writeFont(contentStream, "Risk Factors", ++row, leftOffset, true);
                row = writeFont(contentStream, "Input", row, middleOffset, true);
                row = writeFont(contentStream, "Comment / Guidelines", row, rightOffset, true);

                int startRow = ++row;
                row = writeFont(contentStream, "Theater", startRow, leftOffset, false);
                Geography theater = riskCalculationData.getTheater();
                if (theater != null) {
                    row = Math.max(row, writeFont(contentStream, theater.getName(), startRow, middleOffset, false));
                }
                startRow = ++row;
                row = writeFont(contentStream, "Division", startRow, leftOffset, false);
                Division division = riskCalculationData.getDivision();
                if (division != null) {
                    row = Math.max(row, writeFont(contentStream, division.getDivisionName(), startRow, middleOffset, false));
                }
                row = Math.max(row, writeText(contentStream, "Select the Division the Risk-Calculation is done for", startRow,
                        rightOffset, false, false, true, RISK_CALC_COL_WIDTH));
                row++;
                row = writeFont(contentStream, "ORGANIZATIONAL", ++row, leftOffset, true);
                startRow = ++row;
                row = writeFont(contentStream, "Will delivery involve multiple Theaters or Languages?", startRow,
                        leftOffset, false, RISK_CALC_COL_WIDTH);
                MultipleTheatersLanguagesInvolvementOption multipleTheatresLanguagesInvolvement = riskCalculationData
                        .getMultipleTheatresLanguagesInvolvement();
                if (multipleTheatresLanguagesInvolvement != null) {
                    risk += multipleTheatresLanguagesInvolvement.getRisk();
                    row = Math.max(row, writeFont(contentStream, multipleTheatresLanguagesInvolvement.getName(), startRow,
                            middleOffset, false));
                }
                row = Math.max(row, writeText(contentStream,
                        "If delivery will require resources in multiple Theaters or languages.", startRow, rightOffset,
                        false, false, true, RISK_CALC_COL_WIDTH));
                startRow = ++row;
                row = writeFont(contentStream, "Will delivery involve any EMC Federated companies?", startRow,
                        leftOffset, false, RISK_CALC_COL_WIDTH);
                EMCFederatedCompaniesInvolvementOption emcFederatedCompaniesInvolvement = riskCalculationData
                        .getEmcFederatedCompaniesInvolvement();
                if (emcFederatedCompaniesInvolvement != null) {
                    risk += emcFederatedCompaniesInvolvement.getRisk();
                    row = Math.max(row, writeFont(contentStream, emcFederatedCompaniesInvolvement.getName(), startRow,
                            middleOffset, false));
                }
                row = Math.max(row, writeText(contentStream, "EMC Federated companies such as Pivotal, VMWare, RSA, or ECD",
                        startRow, rightOffset, false, false, true, RISK_CALC_COL_WIDTH));
                startRow = ++row;
                row = writeFont(contentStream, "Will delivery involve multiple Workgroups or Disciplines?",
                        startRow, leftOffset, false, RISK_CALC_COL_WIDTH);
                MultipleWorkgroupsDisciplinesOption multipleWorkgroupsDisciplinesInvolvement = riskCalculationData
                        .getMultipleWorkgroupsDisciplinesInvolvement();
                if (multipleWorkgroupsDisciplinesInvolvement != null) {
                    risk += multipleWorkgroupsDisciplinesInvolvement.getRisk();
                    row = Math.max(row, writeFont(contentStream, multipleWorkgroupsDisciplinesInvolvement.getName(), startRow,
                            middleOffset, false));
                }
                row = Math.max(row, writeText(contentStream,
                        "Will the project team be comprised multiple Work Groups or Disciplines", startRow, rightOffset,
                        false, false, true, RISK_CALC_COL_WIDTH));
                startRow = ++row;
                row = writeFont(contentStream, "Is there a 3rd Party between us and the end Client?", startRow,
                        leftOffset, false, RISK_CALC_COL_WIDTH);
                ThirdPartyInvolvementOption thirdPartyInvolvement = riskCalculationData.getThirdPartyInvolvement();
                if (thirdPartyInvolvement != null) {
                    risk += thirdPartyInvolvement.getRisk();
                    row = Math.max(row, writeFont(contentStream, thirdPartyInvolvement.getName(), startRow, middleOffset, false));
                }
                row = Math.max(row, writeText(contentStream,
                        "If EMC is a sub or working under another services firm, select yes", startRow, rightOffset, false, false, true,
                        RISK_CALC_COL_WIDTH));
                row++;
                row = writeFont(contentStream, "CLIENT", ++row, leftOffset, true);
                startRow = ++row;
                row = writeFont(contentStream, "Is this a new or existing EMC Client?", startRow, leftOffset,
                        false, RISK_CALC_COL_WIDTH);
                EMCClientOption emcClientType = riskCalculationData.getEmcClientType();
                if (emcClientType != null) {
                    risk += emcClientType.getRisk();
                    row = Math.max(row, writeFont(contentStream, emcClientType.getName(), startRow, middleOffset, false));
                }
                row = Math.max(row, writeText(contentStream,
                        "If we have not engaged with the client for more than 3 years, select new", startRow, rightOffset,
                        false, false, true, RISK_CALC_COL_WIDTH));
                startRow = ++row;
                row = writeFont(contentStream, "What is the state of the EMC relationship with this Client?",
                        startRow, leftOffset, false, RISK_CALC_COL_WIDTH);
                EMCClientRelationshipOption emcClientRelationshipType = riskCalculationData
                        .getEmcClientRelationshipType();
                if (emcClientRelationshipType != null) {
                    risk += emcClientRelationshipType.getRisk();
                    row = Math.max(row, writeFont(contentStream, emcClientRelationshipType.getName(), startRow, middleOffset,
                            false));
                }
                row = Math.max(row, writeText(contentStream, "Nature of relationship with Buyer and/or Organization", startRow,
                        rightOffset, false, false, true, RISK_CALC_COL_WIDTH));
                startRow = ++row;
                row = writeFont(contentStream, "What is the client's process and staff maturity?", startRow,
                        leftOffset, false, RISK_CALC_COL_WIDTH);
                ProcessStaffMaturityOption clientProcessStaffMaturityType = riskCalculationData
                        .getClientProcessStaffMaturityType();
                if (clientProcessStaffMaturityType != null) {
                    risk += clientProcessStaffMaturityType.getRisk();
                    row = Math.max(row, writeFont(contentStream, clientProcessStaffMaturityType.getName(), startRow,
                            middleOffset, false));
                }
                row = Math.max(row, writeText(contentStream,
                        "Does the customer have well defined processes and knowledgeable internal staff", startRow,
                        rightOffset, false, false, true, RISK_CALC_COL_WIDTH));
                startRow = ++row;
                row = writeFont(contentStream, "How well is the client's environment documented?", startRow,
                        leftOffset, false, RISK_CALC_COL_WIDTH);
                ClientEnvironmentDocumentationQualityOption clientEnvironmentDocumentationType = riskCalculationData
                        .getClientEnvironmentDocumentationType();
                if (clientEnvironmentDocumentationType != null) {
                    risk += clientEnvironmentDocumentationType.getRisk();
                    row = Math.max(row, writeFont(contentStream, clientEnvironmentDocumentationType.getName(), startRow,
                            middleOffset, false));
                }
                row = Math.max(row, writeText(contentStream,
                        "Select extensive only if the documentation is accurate, available, and useful", startRow,
                        rightOffset, false, false, true, RISK_CALC_COL_WIDTH));
                startRow = ++row;
                row = writeFont(contentStream, "Does EMC and the client fully understand the Project Scope?",
                        startRow, leftOffset, false, RISK_CALC_COL_WIDTH);
                ProjectScopeUnderstandingOption projectScopeUnderstandingType = riskCalculationData
                        .getProjectScopeUnderstandingType();
                if (projectScopeUnderstandingType != null) {
                    risk += projectScopeUnderstandingType.getRisk();
                    row = Math.max(row, writeFont(contentStream, projectScopeUnderstandingType.getName(), startRow, middleOffset,
                            false));
                }
                row = Math.max(row, writeText(contentStream,
                        "Rate the level of confidence that we understand scope/expections", startRow, rightOffset, false, false, true,
                        RISK_CALC_COL_WIDTH));
                startRow =  ++row;
                row = writeFont(contentStream, "How strategic is the Project to EMC and Client?", startRow,
                        leftOffset, false, RISK_CALC_COL_WIDTH);
                ProjectImpactOption projectImpactType = riskCalculationData.getProjectImpactType();
                if (projectImpactType != null) {
                    risk += projectImpactType.getRisk();
                    row = Math.max(row, writeFont(contentStream, projectImpactType.getName(), startRow, middleOffset, false));
                }
                row = Math.max(row, writeText(contentStream,
                        "How visible will this project be to client/EMC executives? Any relationship impacts?", startRow,
                        rightOffset, false, false, true, RISK_CALC_COL_WIDTH));
                startRow = ++row;
                row = writeFont(contentStream, "How involved will the client project sponsor be?", startRow,
                        leftOffset, false, RISK_CALC_COL_WIDTH);
                ProjectSponsorInvolvementOption projectSponsorInvolvementType = riskCalculationData
                        .getProjectSponsorInvolvementType();
                if (projectSponsorInvolvementType != null) {
                    risk += projectSponsorInvolvementType.getRisk();
                    row = Math.max(row, writeFont(contentStream, projectSponsorInvolvementType.getName(), startRow, middleOffset,
                            false));
                }
                row = Math.max(row, writeText(contentStream,
                        "Estimate the level of involvement of the project sponsor / executive", startRow, rightOffset,
                        false, false, true, RISK_CALC_COL_WIDTH));
                row++;
                row = writeFont(contentStream, "CONTRACTUAL", ++row, leftOffset, true);
                startRow = ++row;
                row = writeFont(contentStream, "What is the list price ($) of this opportunity?", startRow,
                        leftOffset, false, RISK_CALC_COL_WIDTH);
                Integer listPrice = riskCalculationData.getListPrice();
                if (listPrice != null) {
                    row = Math.max(row, writeFont(contentStream, listPrice + "", startRow, middleOffset, false));
                } else {
                    listPrice = 0;
                }
                row = Math.max(row, writeText(contentStream,
                        "What is list value for this particular phase of the engagement", startRow, rightOffset, false, false, true,
                        RISK_CALC_COL_WIDTH));
                startRow = ++row;
                row = writeFont(contentStream, "What is the potential value of subsequent phases?", startRow,
                        leftOffset, false, RISK_CALC_COL_WIDTH);
                Integer potentialValue = riskCalculationData.getPotentialValue();
                row = Math.max(row, writeFont(contentStream, (potentialValue == null ? "" : String.valueOf(potentialValue)), startRow,
                        middleOffset, false));
                row = Math.max(row, writeText(contentStream,
                        "Potential value of subsequent follow-on phases for this opportunity", startRow, rightOffset, false, false, true,
                        RISK_CALC_COL_WIDTH));
                startRow = ++row;
                row = writeFont(contentStream, "Will standard T&M billing will be used?", startRow, leftOffset,
                        false, RISK_CALC_COL_WIDTH);
                TMBillingUsageOption tmBillingUsageType = riskCalculationData.getTmBillingUsageType();
                if (tmBillingUsageType != null) {
                    risk += tmBillingUsageType.getRisk();
                    row = Math.max(row, writeFont(contentStream, tmBillingUsageType.getName(), startRow, middleOffset, false));
                }
                row = Math.max(row, writeText(contentStream, "Select No for Fixed Fee, T&M with cap, Event based", startRow,
                        rightOffset, false, false, true, RISK_CALC_COL_WIDTH));
                startRow = ++row;
                row = writeFont(contentStream, "Will EMC be accountable for any deliverables?", startRow,
                        leftOffset, false, RISK_CALC_COL_WIDTH);
                EMCAccountabilityOption emcAccountabilityType = riskCalculationData.getEmcAccountabilityType();
                if (emcAccountabilityType != null) {
                    risk += emcAccountabilityType.getRisk();
                    row = Math.max(row, writeFont(contentStream, emcAccountabilityType.getName(), startRow, middleOffset, false));
                }
                row = Math.max(row, writeText(contentStream,
                        "Deliverables could be contractual or implied. Select No for staff augmentation projects", startRow,
                        rightOffset, false, false, true, RISK_CALC_COL_WIDTH));
                row++;
                row = writeFont(contentStream, "DELIVERY", ++row, leftOffset, true);
                startRow = ++row;
                row = writeFont(contentStream, "What is the maturity of the offering being proposed?", startRow,
                        leftOffset, false, RISK_CALC_COL_WIDTH);
                OfferingMaturityOption offeringMaturityType = riskCalculationData.getOfferingMaturityType();
                if (offeringMaturityType != null) {
                    risk += offeringMaturityType.getRisk();
                    row = Math.max(row, writeFont(contentStream, offeringMaturityType.getName(), startRow, middleOffset, false));
                }
                row = Math.max(row, writeText(contentStream, "Rate the maturity of the offering we are selling", startRow,
                        rightOffset, false, false, true, RISK_CALC_COL_WIDTH));
                startRow = ++row;
                row = writeFont(contentStream, "What is the expected complexity level of the project?", startRow,
                        leftOffset, false, RISK_CALC_COL_WIDTH);
                ProjectComplexityLevelOption projectComplexityLevel = riskCalculationData.getProjectComplexityLevel();
                if (projectComplexityLevel != null) {
                    risk += projectComplexityLevel.getRisk();
                    row = Math.max(row, writeFont(contentStream, projectComplexityLevel.getName(), startRow, middleOffset, false));
                }
                row = Math.max(row, writeText(contentStream, "Rate the complexity of the project", startRow, rightOffset, false, false, true,
                        RISK_CALC_COL_WIDTH));
                startRow = ++row;
                row = writeFont(contentStream,
                        "Are there any external factors impacting the project schedule?", startRow, leftOffset, false,
                        RISK_CALC_COL_WIDTH);
                ExternalFactorsOption externalFactorsType = riskCalculationData.getExternalFactorsType();
                if (externalFactorsType != null) {
                    risk += externalFactorsType.getRisk();
                    row = Math.max(row, writeFont(contentStream, externalFactorsType.getName(), startRow, middleOffset, false));
                }
                row = Math.max(row, writeText(contentStream,
                        "Are timelines reasonable? Is there a lack of urgency that will hurt us?", startRow, rightOffset,
                        false, false, true, RISK_CALC_COL_WIDTH));
                startRow = ++row;
                row = writeFont(contentStream, "What is the availability of EMC staff to deliver this?",
                        startRow, leftOffset, false, RISK_CALC_COL_WIDTH);
                EMCStaffAvailabilityOption emcStaffAvailability = riskCalculationData.getEmcStaffAvailability();
                if (emcStaffAvailability != null) {
                    risk += emcStaffAvailability.getRisk();
                    row = Math.max(row, writeFont(contentStream, emcStaffAvailability.getName(), startRow, middleOffset, false));
                }
                row = Math.max(row, writeText(contentStream,
                        "Are the right people available or are we going to source them?", startRow, rightOffset, false, false, true,
                        RISK_CALC_COL_WIDTH));
                startRow = ++row;
                row = writeFont(contentStream, "What is the availability of partner staff to deliver this?",
                        startRow, leftOffset, false, RISK_CALC_COL_WIDTH);
                PartnerStaffAvailabilityOption partnerStaffAvailability = riskCalculationData
                        .getPartnerStaffAvailability();
                if (partnerStaffAvailability != null) {
                    risk += partnerStaffAvailability.getRisk();
                    row = Math.max(row, writeFont(contentStream, partnerStaffAvailability.getName(), startRow, middleOffset,
                            false));
                }
                row = Math.max(row, writeText(contentStream,
                        "Are we likely to use subs? If so, do we have history with them?", startRow, rightOffset, false, false, true,
                        RISK_CALC_COL_WIDTH));
                startRow = ++row;
                row = writeFont(
                        contentStream,
                        "Any additional risks not mentioned above? (use only if\nadditional unspecified risk factors apply)",
                        startRow, leftOffset, false, RISK_CALC_COL_WIDTH);
                RiskLevelOption additionalRiskLevel = riskCalculationData.getAdditionalRiskLevel();
                if (additionalRiskLevel != null) {
                    risk += additionalRiskLevel.getRisk();
                    row = Math.max(row, writeFont(contentStream, additionalRiskLevel.getName(), startRow, middleOffset, false));
                }
                row =  Math.max(row, writeFont(contentStream, riskCalculationData.getRisk(), startRow, rightOffset, false,
                        RISK_CALC_COL_WIDTH));

                risk = getIncreasedRiskBasedOnListPrice(risk, listPrice);

                String projectRiskTier = "";
                String projectRiskTierDesc = "";

                if (risk >= 0 && risk < 80) {
                    projectRiskTier = "PR1";
                    projectRiskTierDesc = "To be reviewed and approved locally by named Tier";
                } else if (risk >= 80 && risk < 130) {
                    projectRiskTier = "PR2";
                    projectRiskTierDesc = "To be reviewed and approved locally by PSD Lead";
                } else if (risk >= 130 && risk < 180) {
                    projectRiskTier = "PR3";
                    projectRiskTierDesc = "To be reviewed and approved at Solution Review by regional PSD Lead + Theater BusOps";
                } else {
                    projectRiskTier = "PR4";
                    projectRiskTierDesc = "To be reviewed and approved at Solution Review by Theater PSD Lead + Theater BusOps";
                }
                contentStream.setNonStrokingColor(143, 30, 0);
                row = writeFont(contentStream, "Project Risk Tier", ++row, leftOffset, false);
                row = writeFont(contentStream, projectRiskTier, row, middleOffset, false);
                row = writeFont(contentStream, projectRiskTierDesc, row, rightOffset, false,
                        RISK_CALC_COL_WIDTH);
                contentStream.setNonStrokingColor(Color.BLACK);
                row = writeFont(contentStream, "Business Recommendations", ++row, leftOffset, false);
                contentStream.setNonStrokingColor(Color.RED);
                row = writeFont(contentStream, "Contingency", ++row, leftOffset, false);
                row = writeFont(contentStream, "Based on calculated Risk Tier", row, middleOffset, false);
                row = writeFont(contentStream, "Adjustment", row, middleOffset + 130, false);
                contentStream.setNonStrokingColor(Color.BLACK);
                row = writeFont(contentStream, "Rationale:", row, middleOffset + 190, false);
                contentStream.setNonStrokingColor(Color.RED);
                row = writeFont(contentStream, riskCalculationData.getRationale(), row, middleOffset + 230,
                        false);
                row = writeFont(contentStream, "V", ++row, middleOffset + 50, false);
                row = writeFont(contentStream, "V", row, middleOffset + 149, false);

                Double contingency = calculateContingency(risk);

                row = writeFont(contentStream,
                        Helper.decimal2GroupedString(new BigDecimal(contingency), 1, false) + "%", ++row,
                        middleOffset + 45, false);
                row = writeFont(contentStream, "+", row, middleOffset + 116, false);
                Integer adjustment = riskCalculationData.getAdjustment();
                if (adjustment == null) {
                    adjustment = 0;
                }
                row = writeFont(contentStream, adjustment + "%", row, middleOffset + 130, false);
                row = writeFont(contentStream, "=", row, middleOffset + 180, false);
                row = writeFont(contentStream,
                        Helper.decimal2GroupedString(new BigDecimal(Math.ceil(contingency + adjustment)), 0, false)
                                + "%", row, middleOffset + 200, false);
                row = writeFont(contentStream, ">>", row, middleOffset + 260, false);
                row = writeFont(
                        contentStream,
                        Helper.decimal2GroupedString(
                                new BigDecimal((Math.ceil((double) listPrice * (contingency + adjustment) / 100))), 0,
                                false) + " $", row, middleOffset + 275, false);
                row++;
                row = writeFont(contentStream, "Program Management for PR1/PR2/PR3 and PR4", ++row,
                        leftOffset, true);

                contentStream.setNonStrokingColor(79, 98, 40);
                row = writeFont(contentStream, "Does Opportunity Meet PgM Use Case(s)", ++row, leftOffset,
                        false);
                ProgramManagementUseCaseOption programManagementUseCaseType = riskCalculationData
                        .getProgramManagementUseCaseType();
                String pmUseCaseName = "";
                if (programManagementUseCaseType != null) {
                    pmUseCaseName = programManagementUseCaseType.getName();
                }
                Integer pgmoHours = getPgmoHours(projectRiskTier, pmUseCaseName);

                row = writeFont(contentStream, pmUseCaseName+" "+pgmoHours + " hrs/week PgM Oversight hours per week", row, middleOffset, false);

                Integer eqoHours = 0;
                if (projectRiskTier.equals("PR3")) {
                    eqoHours = 4;
                } else if (projectRiskTier.equals("PR4")) {
                    eqoHours = 6;
                }

                row = writeFont(contentStream, "Engagement Quality Oversight hrs (per Week)", ++row,
                        leftOffset, false);
                row = writeFont(contentStream, eqoHours + " hrs/week", row, middleOffset, false);
                contentStream.setNonStrokingColor(Color.BLACK);
                row = writeFont(contentStream, "Text for SAP to copy", ++row, leftOffset, false);
                row = writeText(
                        contentStream,
                        projectRiskTier
                                + " ("
                                + Integer.toHexString(risk).toUpperCase()
                                + ") / Cont:"
                                + Helper.decimal2GroupedString(new BigDecimal(contingency + adjustment), 1,
                                        false) + "% / PrgM:" + pgmoHours + "h/w / QA:" + eqoHours + "h/w", row,
                        middleOffset, false, false, true);

                endPage(page, row);
            } finally {
                contentStream.close();
            }
        }

    }

    /**
     * Calculates the pgmo hours
     * 
     * @param projectRiskTier
     *            The project risk tier
     * @param pmUseCaseName
     *            The pm use case name
     * @return The pgmo hours
     * @since 2.23
     */
    private Integer getPgmoHours(String projectRiskTier, String pmUseCaseName) {
        Integer pgmoHours = 0;
        if (projectRiskTier.equals("PR1")) {
            pgmoHours = 10;
        } else if (projectRiskTier.equals("PR2")) {
            pgmoHours = 20;
        } else if (projectRiskTier.equals("PR3")) {
            pgmoHours = 30;
        } else if (projectRiskTier.equals("PR4")) {
            pgmoHours = 40;
        }
        return pgmoHours;
    }

    /**
     * Calculates the increased risk based on list price
     * 
     * @param risk
     *            The risk
     * @param listPrice
     *            The list price
     * @return The increased risk based on list price
     * @since 2.23
     */
    private Integer getIncreasedRiskBasedOnListPrice(Integer risk, Integer listPrice) {
        if (listPrice >= 0 && listPrice < 100000) {
            risk += 0;
        } else if (listPrice >= 100000 && listPrice < 250000) {
            risk += 5;
        } else if (listPrice >= 250000 && listPrice < 500000) {
            risk += 10;
        } else if (listPrice >= 500000 && listPrice < 1000000) {
            risk += 15;
        } else if (listPrice >= 1000000 && listPrice < 2000000) {
            risk += 20;
        } else if (listPrice >= 2000000) {
            risk += 50;
        }
        return risk;
    }

    /**
     * Calculated contingency
     * 
     * @param risk
     *            The risk
     * @return The contingency
     * @since 2.23
     */
    private Double calculateContingency(Integer risk) {
        Double contingency = 0d;
        if (risk >= 0 && risk < 80) {
            contingency = 0d;
        } else if (risk >= 80 && risk < 105) {
            contingency = 5d;
        } else if (risk >= 105 && risk < 130) {
            contingency = 7.5;
        } else if (risk >= 130 && risk < 155) {
            contingency = 10d;
        } else if (risk >= 155 && risk < 180) {
            contingency = 12.5;
        } else if (risk >= 180 && risk < 225) {
            contingency = 15d;
        } else if (risk >= 225 && risk < 250) {
            contingency = 20d;
        } else if (risk >= 250) {
            contingency = 25d;
        }
        return contingency;
    }

    /**
     * Exports estimates data.
     *
     * @param request
     *            The service request.
     * @param document
     *            The PDF document.
     * @throws IOException
     *             if any I/O error occurs
     * @throws ServiceRequestToolException
     *             if any other error occurs
     */
    private void exportEstimates(Request request, PDDocument document) throws IOException, ServiceRequestToolException {
        PDPageContentStream contentStream;
        PDPage page;
        int row = 1;
        EstimatesData estimatesData = request.getEstimatesData();
        if (estimatesData != null) {
            page = newPage(document);
            contentStream = new PDPageContentStream(document, page);
            EstimatedResult estimatesResult = estimatesService.estimate(request);
            DealCurrency baseCurrency = request.getEngagementTypeData().getDeliveryCountry().getDealCurrency();
            try {
                float leftOffset = 0f;

                row = writeFont(contentStream, "Estimates", ++row, leftOffset, true);
                row++;
                row = writeFont(contentStream, "CURRENCY CONVERSION", ++row, leftOffset, true);
                writeToCol(contentStream, "Currency", baseCurrency.getName(), ++row, false, PROJECT_COL_WIDTH, true);
                DealCurrency dealCurrency = estimatesData.getDealCurrency();
                String dealCurrencyName = dealCurrency == null ? "" : dealCurrency.getName();
                writeToCol(contentStream, "Deal Currency", dealCurrencyName, ++row, false, PROJECT_COL_WIDTH, true);
                writeToCol(contentStream, "Project Start Date", estimatesResult.getProjectStartDate(), ++row, false,
                        PROJECT_COL_WIDTH, true);
                writeToCol(contentStream, "Project End Date", estimatesResult.getProjectEndDate(), ++row, false,
                        PROJECT_COL_WIDTH, true);
                String exchange = Helper.decimal2GroupedString(
                    new BigDecimal(1).divide(
                        dealCurrency.getExchangeRate().divide(baseCurrency.getExchangeRate(), RoundingMode.HALF_UP), 8, RoundingMode.HALF_UP), 8,
                        true);
                writeToCol(contentStream, "", exchange + " " + dealCurrencyName + "/" + baseCurrency.getName(), ++row, false,
                        PROJECT_COL_WIDTH, false);
                
                row++;
                writeToCol(contentStream, "Contingency %", Helper.decimal2GroupedString(estimatesData.getContingencyPercent(), 2, false), ++row, false,
                        PROJECT_COL_WIDTH, true);
                for (EstimatedLOB estimatedLOB : estimatesResult.getEstimatedLOBs()) {
                    row = writeFont(contentStream, "LOB / RESOURCES", ++row, leftOffset, true);
                    LOB lob = estimatedLOB.getLob();
                    MaterialCode materialCode = estimatedLOB.getMaterialCode();
                    Competency competency = estimatedLOB.getCompetency();
                    BillingType billingType = estimatedLOB.getBillingType();
                    row = writeFont(contentStream, "LOB: " + (lob == null ? "" : lob.getName())
                            + "          Material Code: " + (materialCode == null ? "" : materialCode.getName())
                            + "          Competency: " + (competency == null ? "" : competency.getName())
                            + "          Billing Type: " + (billingType == null ? "" : billingType.getName()), ++row,
                            leftOffset, false);
                    Integer monthsNum = estimatedLOB.getMonthsNum();
                    if (monthsNum == null) {
                        monthsNum = 0;
                    }
                    writeToCol(contentStream, "Months of Entry", String.valueOf(monthsNum >= 6 && monthsNum <= 84 ? monthsNum : 6),
                            ++row, false, PROJECT_COL_WIDTH, true);
                    List<EstimatedResource> estimatedResources = estimatedLOB.getEstimatedResources();
                    List<String> rowNames = new ArrayList<String>();

                    rowNames.add("Role (BOE)");
                    rowNames.add("");
                    for (int i = 0; i < estimatedResources.size(); i++) {
                        EstimatedResource estimatedResource = estimatedResources.get(i);
                        BOERole role = estimatedResource.getRole();
                        String roleName = role == null ? "" : role.getName();
                        rowNames.add(roleName);
                    }
                    ExpenseType expenseType = request.getStartRequestData().getExpenseType();
                    List<String[]> content = createLongWidthTableContent(rowNames, 5
                            + (expenseType != null && expenseType.getId() == 1 ? 1 : 0));

                    for (int i = 0; i < estimatedResources.size() + 2; i++) {
                        int colNum = 1;
                        if (i == 0) {
                            content.get(i)[colNum++] = "Competency";
                            content.get(i)[colNum++] = "Budgeted Hours";
                            DealCurrency estimateResultDealCurrency = estimatesResult.getDealCurrency();
                            String estimateResultDealCurrencyName = estimateResultDealCurrency == null ? ""
                                    : estimateResultDealCurrency.getName();
                            String currecyNameToExport = estimateResultDealCurrencyName == null ? ""
                                    : estimateResultDealCurrencyName;
                            content.get(i)[colNum++] = "Standard Bill Rate (" + currecyNameToExport + ")";
                            if (expenseType != null && expenseType.getId() == 1) {
                                content.get(i)[colNum++] = "Bill Rate w/ Expense %";
                            }
                            content.get(i)[colNum++] = "Hourly Std Cost Rate (" + currecyNameToExport + ")";
                            content.get(i)[colNum++] = "Standard Fees (" + currecyNameToExport + ")";
                        } else if (i == 1) {
                            content.get(i)[colNum++] = "";
                            content.get(i)[colNum++] = "w/Contingency";
                            content.get(i)[colNum++] = "(calculated)";
                            BigDecimal estimatedPercent = estimatesResult.getEstimatedPercent();
                            if (estimatedPercent == null) {
                                estimatedPercent = new BigDecimal(15);
                            }
                            if (expenseType != null && expenseType.getId() == 1) {
                                content.get(i)[colNum++] = Helper.decimal2GroupedString(estimatedPercent, 1, false) + "%";
                            }
                            content.get(i)[colNum++] = "(calculated)";
                            content.get(i)[colNum++] = Helper.decimal2GroupedString(estimatedLOB.getStandardFees(), 2,
                                    true);
                        } else {
                            EstimatedResource estimatedResource = estimatedResources.get(i - 2);
                            Competency resourceCompetency = estimatedResource.getCompetency();
                            String resourceCompetencyName = resourceCompetency == null ? "" : resourceCompetency
                                    .getName();
                            content.get(i)[colNum++] = resourceCompetencyName == null ? "" : resourceCompetencyName;
                            content.get(i)[colNum++] = Helper.decimal2GroupedString(
                                    estimatedResource.getBudgetedHours(), 2, true);
                            content.get(i)[colNum++] = Helper.decimal2GroupedString(
                                    estimatedResource.getStandardBillRate(), 2, true);
                            if (expenseType != null && expenseType.getId() == 1) {
                                content.get(i)[colNum++] = Helper.decimal2GroupedString(
                                        estimatedResource.getBillRateWithExpense(), 2, true);
                            }
                            content.get(i)[colNum++] = Helper.decimal2GroupedString(
                                    estimatedResource.getHourlyStdCostRate(), 2, true);
                            content.get(i)[colNum++] = Helper.decimal2GroupedString(
                                    estimatedResource.getStandardFees(), 2, true);
                        }
                    }

                    row += drawEstimatesDynColTable(page, contentStream, getYPos(++row), 30, 100, 66,
                            content.toArray(new String[content.size()][]));
                    row++;
                }

                endPage(page, row);
            } finally {
                contentStream.close();
            }
        }
    }

    /**
     * Exports pricing overview data.
     *
     * @param request
     *            The service request.
     * @param document
     *            The PDF document.
     * @throws IOException
     *             if any I/O error occurs
     * @throws ServiceRequestToolException
     *             if any other error occurs
     * @since 2.23            
     */
    private void exportPricingOverview(Request request, PDDocument document) throws IOException,
            ServiceRequestToolException {
        PDPageContentStream contentStream;
        PDPage page;
        int row = 1;
        EstimatesData estimatesData = request.getEstimatesData();
        if (estimatesData != null) {
            page = newPage(document);
            contentStream = new PDPageContentStream(document, page);
            EstimatedResult estimatesResult = estimatesService.estimate(request);
            try {
                float leftOffset = 0f;

                row = writeFont(contentStream, "Pricing - Pricing overview", ++row, leftOffset, true);
                row++;
                row = writeFont(contentStream, "PRICING OVERVIEW", ++row, leftOffset, true);
                DealCurrency dealCurrency = estimatesData.getDealCurrency();
                String dealCurrencyName = dealCurrency == null ? "" : dealCurrency.getName();
                row = writeFont(contentStream, dealCurrencyName, ++row,
                        (page.findMediaBox().getWidth() - (2 * DEFAULT_PAGE_PADDING)) / 2 - 10, true);

                int nrOfLobs = estimatesResult.getEstimatedLOBs().size();
                List<String> rowNames = new ArrayList<String>();
                rowNames.add("");
                rowNames.add("Services Fees @Standard");
                rowNames.add("Less Discount");
                rowNames.add("Total Fees");
                rowNames.add("+ Expense Recovery");
                rowNames.add("Total Revenue");
                rowNames.add("Cost of Services");
                rowNames.add("Cost of Expenses");
                EngagementTypeData engagementTypeData = request.getEngagementTypeData();
                boolean showGrossMargin = engagementTypeData.isEmc() && (engagementTypeData.isEcd() || engagementTypeData.isMs() || engagementTypeData.isRsa());
                if(showGrossMargin){
                    rowNames.add("Total Gross Margin");
                    rowNames.add("Total Gross Margin %");
                }
                if(engagementTypeData.isEcd()){
                    rowNames.add("IP Amount");
                    rowNames.add("Edu Amount");
                }
                if(showGrossMargin && engagementTypeData.isEcd()){
                    rowNames.add("Total Gross Margin w/IP/EDU");
                }
                rowNames.add("Grand Total");
                rowNames.add("Other Deal Metrics:");
                rowNames.add("Fee-only margin%");
                rowNames.add("Discount Only %");
                rowNames.add("Billable Expense as % Fees");
                rowNames.add("Margin loss due to Expense Cap");
                rowNames.add("Total Work Effort in Days");
                rowNames.add("Total Work Effort in Hour");
                rowNames.add("Avg Daily Rate (ADR) fees only");
                rowNames.add("Avg Daily Rate (ADR) all Revenue");
                rowNames.add("Avg Hourly Rate (AHR) Fees only");
                rowNames.add("Avg Hourly Rate (AHR) all Revenue");
                List<String[]> content = createDynColTableContent(rowNames.toArray(new String[rowNames.size()]), nrOfLobs + 1);

                for (int i = 1; i <= nrOfLobs; i++) {
                    EstimatedLOB estimatedLOB = estimatesResult.getEstimatedLOBs().get(i - 1);
                    Competency competency = estimatedLOB.getCompetency();
                    if (competency != null){
                        int rowNum = 0;
                        content.get(rowNum++)[i] = trimToEmpty(competency.getName());
                        PricingOverview pricingOverview = estimatedLOB.getPricingOverview();
                        setPricingOverviewDecimalText(pricingOverview.getServicesFees(), content, rowNum++, i, 2);
                        setPricingOverviewDecimalText(pricingOverview.getDiscount(), content, rowNum++, i, 2);
                        setPricingOverviewDecimalText(pricingOverview.getTotalFees(), content, rowNum++, i, 2);
                        setPricingOverviewDecimalText(pricingOverview.getExpenseRecovery(), content, rowNum++, i, 2);
                        setPricingOverviewDecimalText(pricingOverview.getTotalRevenue(), content, rowNum++, i, 2);
                        setPricingOverviewDecimalText(pricingOverview.getServicesCost(), content, rowNum++, i, 2);
                        setPricingOverviewDecimalText(pricingOverview.getExpensesCost(), content, rowNum++, i, 2);
                        if(showGrossMargin){
                            setPricingOverviewDecimalText(pricingOverview.getTotalGrossMargin(), content, rowNum++, i, 2);
                            setPricingOverviewDecimalPercentText(pricingOverview.getTotalGrossMarginPercent(), content, rowNum++, i, 2);
                        }
                        if(engagementTypeData.isEcd()){
                            setPricingOverviewDecimalText(pricingOverview.getIpAmount(), content, rowNum++, i, 2);
                            setPricingOverviewDecimalText(pricingOverview.getEduAmount(), content, rowNum++, i, 2);
                        }
                        if(showGrossMargin && engagementTypeData.isEcd()){
                            setPricingOverviewDecimalText(pricingOverview.getTotalGrossMarginWithIpEdu(), content, rowNum++, i, 2);
                        }
                        setPricingOverviewDecimalText(pricingOverview.getGrandTotal(), content, rowNum++, i, 2);
                        content.get(rowNum++)[i] = "";
                        setPricingOverviewDecimalPercentText(pricingOverview.getFeeOnlyMarginPercent(), content, rowNum++, i, 1);
                        setPricingOverviewDecimalPercentText(pricingOverview.getDiscountOnlyPercent(), content, rowNum++, i, 1);
                        setPricingOverviewDecimalPercentText(pricingOverview.getBillableExpensePercent(), content, rowNum++, i, 1);
                        setPricingOverviewDecimalPercentText(pricingOverview.getMarginLossPercent(), content, rowNum++, i, 1);
                        setPricingOverviewNumberText(pricingOverview.getTotalDays(), content, rowNum++, i, " d");
                        setPricingOverviewNumberText(pricingOverview.getTotalHours(), content, rowNum++, i, " h");
                        setPricingOverviewDecimalText(pricingOverview.getAdrFees(), content, rowNum++, i, 2);
                        setPricingOverviewDecimalText(pricingOverview.getAdrRevenue(), content, rowNum++, i, 2);
                        setPricingOverviewDecimalText(pricingOverview.getAhrFees(), content, rowNum++, i, 2);
                        setPricingOverviewDecimalText(pricingOverview.getAhrRevenue(), content, rowNum++, i, 2);
                    }
                }
                int rowNum = 0;
                content.get(rowNum++)[nrOfLobs + 1] = "Total EMC Professional Services";
                PricingOverview totalOverview = estimatesResult.getTotalOverview();
                setPricingOverviewDecimalText(totalOverview.getServicesFees(), content, rowNum++, nrOfLobs + 1, 2);
                setPricingOverviewDecimalText(totalOverview.getDiscount(), content, rowNum++, nrOfLobs + 1, 2);
                setPricingOverviewDecimalText(totalOverview.getTotalFees(), content, rowNum++, nrOfLobs + 1, 2);
                setPricingOverviewDecimalText(totalOverview.getExpenseRecovery(), content, rowNum++, nrOfLobs + 1, 2);
                setPricingOverviewDecimalText(totalOverview.getTotalRevenue(), content, rowNum++, nrOfLobs + 1, 2);
                setPricingOverviewDecimalText(totalOverview.getServicesCost(), content, rowNum++, nrOfLobs + 1, 2);
                setPricingOverviewDecimalText(totalOverview.getExpensesCost(), content, rowNum++, nrOfLobs + 1, 2);
                if(showGrossMargin){
                    setPricingOverviewDecimalText(totalOverview.getTotalGrossMargin(), content, rowNum++, nrOfLobs + 1, 2);
                    setPricingOverviewDecimalPercentText(totalOverview.getTotalGrossMarginPercent(), content, rowNum++, nrOfLobs + 1, 2);
                }
                if(engagementTypeData.isEcd()){
                    setPricingOverviewDecimalText(totalOverview.getIpAmount(), content, rowNum++, nrOfLobs + 1, 2);
                    setPricingOverviewDecimalText(totalOverview.getEduAmount(), content, rowNum++, nrOfLobs + 1, 2);
                }
                if(showGrossMargin && engagementTypeData.isEcd()){
                    setPricingOverviewDecimalText(totalOverview.getTotalGrossMarginWithIpEdu(), content, rowNum++, nrOfLobs + 1, 2);
                }
                setPricingOverviewDecimalText(totalOverview.getGrandTotal(), content, rowNum++, nrOfLobs + 1, 2);
                content.get(rowNum++)[nrOfLobs + 1] = "";
                setPricingOverviewDecimalPercentText(totalOverview.getFeeOnlyMarginPercent(), content, rowNum++, nrOfLobs + 1, 1);
                setPricingOverviewDecimalPercentText(totalOverview.getDiscountOnlyPercent(), content, rowNum++, nrOfLobs + 1, 1);
                setPricingOverviewDecimalPercentText(totalOverview.getBillableExpensePercent(), content, rowNum++, nrOfLobs + 1, 1);
                setPricingOverviewDecimalPercentText(totalOverview.getMarginLossPercent(), content, rowNum++, nrOfLobs + 1, 1);
                setPricingOverviewNumberText(totalOverview.getTotalDays(), content, rowNum++, nrOfLobs + 1, " d");
                setPricingOverviewNumberText(totalOverview.getTotalHours(), content, rowNum++, nrOfLobs + 1, " h");
                setPricingOverviewDecimalText(totalOverview.getAdrFees(), content, rowNum++, nrOfLobs + 1, 2);
                setPricingOverviewDecimalText(totalOverview.getAdrRevenue(), content, rowNum++, nrOfLobs + 1, 2);
                setPricingOverviewDecimalText(totalOverview.getAhrFees(), content, rowNum++, nrOfLobs + 1, 2);
                setPricingOverviewDecimalText(totalOverview.getAhrRevenue(), content, rowNum++, nrOfLobs + 1, 2);
                row += drawPricingOverviewDynColTable(page, contentStream, getYPos(++row), 30, 110, 80,
                        content.toArray(new String[content.size()][]));
                endPage(page, row);
            } finally {
                contentStream.close();
            }
        }

    }
    
    /**
     * Sets pricing overview number text
     * 
     * @param number
     *            The number
     * @param content
     *            The content
     * @param rowNum
     *            The row number
     * @param colNum
     *            The column number
     * @param suffix
     *            The suffix
     * @since 2.23
     */
    private void setPricingOverviewNumberText(BigDecimal number, List<String[]> content, int rowNum, int col, String suffix) {
        String numberToBeExported = "-";
        if(number != null){
            if(number.doubleValue() < 0){
                numberToBeExported = "("+number.abs()+")";
            } else if (!number.equals(BigDecimal.ZERO)) {
                numberToBeExported = Helper.decimal2GroupedString(
                        number, 0, true);
            }
        }
        content.get(rowNum)[col] = numberToBeExported + suffix;
    }
    
    /**
     * Sets pricing overview number text
     * 
     * @param number
     *            The number
     * @param content
     *            The content
     * @param rowNum
     *            The row number
     * @param colNum
     *            The column number
     * @param digits
     *            The nr of digits
     * @since 2.23
     */
    private void setPricingOverviewDecimalText(BigDecimal number, List<String[]> content, int rowNum, int col, int digits) {
        String numberToBeExported = "-";
        if(number != null){
            if(number.doubleValue() < 0){
                numberToBeExported = "("+Helper.decimal2GroupedString(
                        number.abs(), digits, true)+")";
            } else if (!number.equals(BigDecimal.ZERO)) {
                numberToBeExported = Helper.decimal2GroupedString(
                        number, digits, true);
            }
        }
        content.get(rowNum)[col] = numberToBeExported;
    }
    
    /**
     * Sets pricing overview number text
     * 
     * @param number
     *            The number
     * @param content
     *            The content
     * @param rowNum
     *            The row number
     * @param colNum
     *            The column number
     * @param digits
     *            The nr of digits
     * @since 2.23
     */
    private void setPricingOverviewDecimalPercentText(BigDecimal number, List<String[]> content, int rowNum, int col, int digits) {
        String numberToBeExported = "-";
        if(number != null && !number.equals(BigDecimal.ZERO)){
            numberToBeExported = Helper.decimal2GroupedString(
                    number, digits, true);
        }
        content.get(rowNum)[col] = numberToBeExported + (numberToBeExported.length() > 1 ? "%" : "");
    }

    /**
     * Exports pricing expenses data.
     *
     * @param request
     *            The service request.
     * @param document
     *            The PDF document.
     * @throws IOException
     *             if any I/O error occurs
     * @throws ServiceRequestToolException
     *             if any other error occurs
     * @since 2.23
     */
    private void exportPricingExpenses(Request request, PDDocument document) throws IOException,
            ServiceRequestToolException {
        PDPageContentStream contentStream;
        PDPage page;
        int row = 1;
        EstimatesData estimatesData = request.getEstimatesData();
        if (estimatesData != null) {
            page = newPage(document);
            contentStream = new PDPageContentStream(document, page);
            EstimatedResult estimatesResult = estimatesService.estimate(request);
            try {
                float leftOffset = 0f;

                row = writeFont(contentStream, "Pricing - Expenses", ++row, leftOffset, true);
                row++;
                row = writeFont(contentStream, "EXPENSES", ++row, leftOffset, true);
                BigDecimal estimatedPercent = estimatesResult.getEstimatedPercent();
                if (estimatedPercent == null) {
                    estimatedPercent = new BigDecimal(15);
                }
                contentStream.setNonStrokingColor(Color.RED);
                row = writeFont(contentStream, "Estimated at", ++row, leftOffset, true);
                contentStream.setNonStrokingColor(Color.BLACK);
                row = writeFont(contentStream, "or Calculated to be :", row, 230, true);
                row = writeFont(contentStream, ":  " + Helper.decimal2GroupedString(estimatedPercent, 0, true)
                        + "%", row, PROJECT_COL_WIDTH - 50, false);
                row = writeFont(contentStream, "Expense Amount", ++row, leftOffset, true);
                row = writeFont(contentStream,
                        ":  " + Helper.decimal2GroupedString(estimatesResult.getExpenseAmount(), 2, true), row,
                        PROJECT_COL_WIDTH - 50, false);
                row = writeFont(contentStream, "Capped at", ++row, leftOffset, true);
                row = writeFont(contentStream,
                        ":  " + Helper.decimal2GroupedString(estimatesResult.getCappedPercent(), 0, true) + "%", row,
                        PROJECT_COL_WIDTH - 50, false);

                String[][] contents = getExpensesTableContents(estimatesResult);
                int tableRows = drawPricingTable(page, contentStream, getYPos(row - 1), 260, contents, new float[] {
                        30f, 100f, 100f, 80f });
                row += tableRows;

                endPage(page, row);
            } finally {
                contentStream.close();
            }
        }

    }

    /**
     * Exports pricing discounting data.
     *
     * @param request
     *            The service request.
     * @param document
     *            The PDF document.
     * @throws IOException
     *             if any I/O error occurs
     * @throws ServiceRequestToolException
     *             if any other error occurs
     * @since 2.23
     */
    private void exportPricingDiscounting(Request request, PDDocument document) throws IOException,
            ServiceRequestToolException {
        PDPageContentStream contentStream;
        PDPage page;
        int row = 1;
        EstimatesData estimatesData = request.getEstimatesData();
        if (estimatesData != null) {
            page = newPage(document);
            contentStream = new PDPageContentStream(document, page);
            EstimatedResult estimatesResult = estimatesService.estimate(request);
            try {
                float leftOffset = 0f;

                row = writeFont(contentStream, "Pricing - Discounting", ++row, leftOffset, true);
                row++;
                row = writeFont(contentStream, "PRICING ALTERNATIVES", ++row, leftOffset, true);
                row++;
                row = writeFont(contentStream, "Multi-LOB Discounting", ++row, leftOffset, true);
                row++;
                row = writeFont(contentStream, "RESOURCES", ++row, leftOffset, true);
                row++;
                row = writeFont(contentStream, "FIXED PRICE MATERIAL CODES", ++row, leftOffset, true);
                row++;

                String[][] contents = getFPMCDiscountingTableContents(estimatesResult);
                int tableRows = drawPricingTable(page, contentStream, getYPos(row), 30, contents, new float[] { 70f, 100f, 220f, 80f, 70f });
                row += tableRows;

                row = writeFont(contentStream, "TIME AND MATERIALS", ++row, leftOffset, true);
                row++;

                contents = getTMDiscountingTableContents(estimatesResult);
                tableRows = drawPricingTable(page, contentStream, getYPos(row), 30, contents, new float[] { 70f, 100f,
                        120f, 100f, 80f, 70f });
                row += tableRows;

                row = writeFont(contentStream, "Client Pricing Override (Enter Amount or Formula)", ++row,
                        leftOffset, true);
                DealCurrency dealCurrency = estimatesResult.getDealCurrency();
                row = writeFont(contentStream,
                        ":  " + Helper.decimal2GroupedString(estimatesResult.getClientPricingOverride(), 2, true)
                                + "   " + (dealCurrency == null ? "" : dealCurrency.getName()), row, 300, false);
                endPage(page, row);
            } finally {
                contentStream.close();
            }
        }

    }

    /**
     * Exports service activities.
     *
     * @param request The service request.
     * @param document The PDF document.
     * @throws IOException
     *             if any I/O error occurs
     */
    private void exportServiceActivities(Request request, PDDocument document) throws IOException {

        PDPageContentStream contentStream;
        PDPage page;
        int row = 1;

        // Write InfrastructureRequestData
        InfrastructureRequestData infrastuctureRequestData = request.getInfrastuctureRequestData();
        if (infrastuctureRequestData != null) {

            page = newPage(document);
            contentStream = new PDPageContentStream(document, page);
            try {
                row = writeInfrastructureRequestData(contentStream, infrastuctureRequestData, 1, page);
                endPage(page, row);
            } finally {
                contentStream.close();
            }
        }

        // Write San/Connectivity
        SanTanInformation sanTanInformation = request.getSanTanInformation();
        if (sanTanInformation != null) {
            page = newPage(document);
            contentStream = new PDPageContentStream(document, page);
            try {
                row = writeSanTanConnectData(contentStream, sanTanInformation, 1);
                endPage(page, row);
            } finally {
                contentStream.close();
            }
        }

        // Write UnifiedRequestData
        UnifiedRequestData unifiedRequestData = request.getUnifiedRequestData();
        if (unifiedRequestData != null) {

            page = newPage(document);
            contentStream = new PDPageContentStream(document, page);
            try {
                row = writeUnifiedRequestData(contentStream, unifiedRequestData, infrastuctureRequestData, 1);
                endPage(page, row);
            } finally {
                contentStream.close();
            }
        }

        // Write MainframeRequestData
        MainframeRequestData mainframeRequestData = request.getMainframeRequestData();
        if (mainframeRequestData != null) {

            page = newPage(document);
            contentStream = new PDPageContentStream(document, page);

            try {
                row = writeMainframeRequestData(contentStream, mainframeRequestData, 1);
                endPage(page, row);
            } finally {
                contentStream.close();
            }
        }

        // Write BcRequestData
        BcRequestData bcRequestData = request.getBcRequestData();
        if (bcRequestData != null) {

            page = newPage(document);
            contentStream = new PDPageContentStream(document, page);

            try {
                row = writeBcRequestData(contentStream, bcRequestData, unifiedRequestData,
                        infrastuctureRequestData, 1, page);
                endPage(page, row);
            } finally {
                contentStream.close();
            }
        }

        SRMRequestData srmRequestData = request.getSrmRequestData();
        if (enabledTabs.isEnableSRM() && srmRequestData != null) {

            page = newPage(document);
            contentStream = new PDPageContentStream(document, page);

            try {
                row = writeSRMData(contentStream, srmRequestData, 1, page);
                endPage(page, row);
            } finally {
                contentStream.close();
            }
        }

        W4NData w4nData = request.getW4nData();
        if (enabledTabs.isEnableW4N() && w4nData != null) {

            page = newPage(document);
            contentStream = new PDPageContentStream(document, page);

            try {
                row = writeW4NData(contentStream, w4nData, 1, page);
                endPage(page, row);
            } finally {
                contentStream.close();
            }
        }

        MoveRequestData moveRequestData = request.getMoveRequestData();
        if (enabledTabs.isEnableMoveRequest() && moveRequestData != null) {

            page = newPage(document);
            contentStream = new PDPageContentStream(document, page);

            try {
                row = writeMoveRequestData(contentStream, moveRequestData, 1, page);
                endPage(page, row);
            } finally {
                contentStream.close();
            }
        }

        ChangeRequestData changeRequestData = request.getChangeRequestData();
        if (enabledTabs.isEnableChangeRequest() && changeRequestData != null) {

            page = newPage(document);
            contentStream = new PDPageContentStream(document, page);

            try {
                row = writeChangeRequestData(contentStream, changeRequestData, 1, page);
                endPage(page, row);
            } finally {
                contentStream.close();
            }
        }

        UnfundedProjectData unfundedProjectData = request.getUnfundedProjectData();
        if (unfundedProjectData != null) {

            page = newPage(document);
            contentStream = new PDPageContentStream(document, page);

            try {
                row = writeUnfundedProjectData(contentStream, request.getProjectType(), unfundedProjectData,
                        1, page);
                endPage(page, row);
            } finally {
                contentStream.close();
            }
        }

        // Write VblockRequestData
        VblockRequestData vblockRequestData = request.getVblockRequestData();
        if (enabledTabs.isEnableVblock() && vblockRequestData != null) {

            page = newPage(document);
            contentStream = new PDPageContentStream(document, page);
            try {
                row = writeVblockRequestData(contentStream, vblockRequestData, 1, page);
                endPage(page, row);
            } finally {
                contentStream.close();
            }
        }

        // Write MSSRequestData
        MSSRequestData mssRequestData = request.getMssRequestData();
        if (enabledTabs.isEnableMSS() && mssRequestData != null) {

            page = newPage(document);
            contentStream = new PDPageContentStream(document, page);
            try {
                row = writeMSSRequestData(contentStream, mssRequestData, 1, page);
                endPage(page, row);
            } finally {
                contentStream.close();
            }
        }

        // Write CTARequestData
        CTARequestData ctaRequestData = request.getCtaRequestData();
        if (enabledTabs.isEnableCTA() && ctaRequestData != null) {

            page = newPage(document);
            contentStream = new PDPageContentStream(document, page);
            try {
                row = writeCTARequestData(contentStream, ctaRequestData, 1, page);
                endPage(page, row);
            } finally {
                contentStream.close();
            }
        }

        // Write AtmosCenteraRequestData
        AtmosCenteraRequestData atmosRequestData = request.getAtmosRequestData();
        if (enabledTabs.isEnableAtmos() && atmosRequestData != null) {

            page = newPage(document);
            contentStream = new PDPageContentStream(document, page);
            try {
                row = writeAtmosRequestData(contentStream, atmosRequestData, 1, page);
                endPage(page, row);
            } finally {
                contentStream.close();
            }
        }

        // Write ResidencyRequestData
        ResidencyRequestData residencyRequestData = request.getResidencyRequestData();
        if (enabledTabs.isEnableResidency() && residencyRequestData != null) {

            page = newPage(document);
            contentStream = new PDPageContentStream(document, page);
            try {
                row = writeResidencyRequestData(contentStream, residencyRequestData, 1, page);
                endPage(page, row);
            } finally {
                contentStream.close();
            }
        }

        // Write SourceOneRequestData
        SourceOneRequestData sourceOneRequestData = request.getSourceOneRequestData();
        if (enabledTabs.isEnableSourceOne() && sourceOneRequestData != null) {

            page = newPage(document);
            contentStream = new PDPageContentStream(document, page);
            try {
                row = writeSourceOneRequestData(contentStream, sourceOneRequestData, 1, page);
                endPage(page, row);
            } finally {
                contentStream.close();
            }
        }

        // Write ASDRequestData
        ASDRequestData asdRequestData = request.getAsdRequestData();
        if (enabledTabs.isEnableASD() && asdRequestData != null) {

            page = newPage(document);
            contentStream = new PDPageContentStream(document, page);
            try {
                row = writeASDRequestData(contentStream, asdRequestData, 1, page);
                endPage(page, row);
            } finally {
                contentStream.close();
            }
        }

        // Write HealthCheckRequestData
        HealthCheckRequestData healthCheckRequestData = request.getHealthCheckRequestData();
        if (enabledTabs.isEnableHealthCheck() && healthCheckRequestData != null) {

            page = newPage(document);
            contentStream = new PDPageContentStream(document, page);
            try {
                row = writeHealthCheckRequestData(contentStream, healthCheckRequestData, 1, page);
                endPage(page, row);
            } finally {
                contentStream.close();
            }
        }

        // Write IsilonRequestData
        IsilonRequestData isilonRequestData = request.getIsilonRequestData();
        if (enabledTabs.isEnableIsilon() && isilonRequestData != null) {

            page = newPage(document);
            contentStream = new PDPageContentStream(document, page);
            try {
                row = writeIsilonRequestData(contentStream, isilonRequestData, 1, page);
                endPage(page, row);
            } finally {
                contentStream.close();
            }
        }

        // Write ViprRequestData
        ViprRequestData viprRequestData = request.getViprRequestData();
        if (enabledTabs.isEnableViPR() && viprRequestData != null) {

            page = newPage(document);
            contentStream = new PDPageContentStream(document, page);
            try {
                row = writeViprRequestData(contentStream, viprRequestData, 1, page);
                endPage(page, row);
            } finally {
                contentStream.close();
            }
        }

        // Write DPADRequestData
        DPADRequestData dpadRequestData = request.getDpadRequestData();
        if (enabledTabs.isEnableDPAD() && dpadRequestData != null) {

            page = newPage(document);
            contentStream = new PDPageContentStream(document, page);
            try {
                row = writeDPADRequestData(contentStream, dpadRequestData, 1, page);
                endPage(page, row);
            } finally {
                contentStream.close();
            }
        }

        // Write VMWareRequestData
        VMwareRequestData vmwareRequestData = request.getVmwareRequestData();
        if (enabledTabs.isEnableVMWare() && vmwareRequestData != null) {

            page = newPage(document);
            contentStream = new PDPageContentStream(document, page);
            try {
                row = writeVMWareRequestData(contentStream, vmwareRequestData, 1, page);
                endPage(page, row);
            } finally {
                contentStream.close();
            }
        }

        // Write XtremeRequestData
        XtremeRequestData xtremeRequestData = request.getXtremeRequestData();
        if (enabledTabs.isEnableXtreme() && xtremeRequestData != null) {

            page = newPage(document);
            contentStream = new PDPageContentStream(document, page);
            try {
                row = writeXtremeRequestData(contentStream, xtremeRequestData, 1);
                endPage(page, row);
            } finally {
                contentStream.close();
            }
        }

        // Write AssessmentData
        AssessmentData assessmentData = request.getAssessmentData();
        if (assessmentData != null) {

            page = newPage(document);
            contentStream = new PDPageContentStream(document, page);
            try {
                row = writeAssessmentData(contentStream, assessmentData, 1);
                endPage(page, row);
            } finally {
                contentStream.close();
            }
        }

        // Write ProtectPointData
        ProtectPointData protectPointData = request.getProtectPointData();
        if (protectPointData != null) {

            page = newPage(document);
            contentStream = new PDPageContentStream(document, page);
            try {
                row = writeProtectPointData(contentStream, protectPointData, 1);
                endPage(page, row);
            } finally {
                contentStream.close();
            }
        }
    }
    /**
     * <p>Writes the Xtreme data section.</p>
     *
     * @param contentStream the content stream.
     * @param xtremeRequestData the data to render.
     * @param row the current row.
     * @return the ending row.
     * @throws IOException for any errors encountered.
     * @since 2.10
     */
    private int writeXtremeRequestData(PDPageContentStream contentStream, XtremeRequestData xtremeRequestData, int row)
        throws IOException {
        float questionWidth = 300f;
        row = writeFont(contentStream, "Services & Activities - Xtreme", ++row, 0, true);

        // General information
        row++;

        row = writeFont(contentStream, "GENERAL INFORMATION", ++row, 0, true);

        row = writeAnswer(contentStream, row, questionWidth, "# of Hours of Knowledge Transfer",
            decimal2String(xtremeRequestData.getKnowledgeTransferHours(), 2));
        row = writeAnswer(contentStream, row, questionWidth, "General Comments",
            trimToEmpty(xtremeRequestData.getGeneralComments()));

        // Services scope
        XtremeServices servicesScope = xtremeRequestData.getXtremeServices();
        row++;
        row = writeFont(contentStream, "XTREM SERVICES", ++row, 0, true);
        List<String> options = getXtremeServices(servicesScope);
        row = writeOptions(contentStream, options, ++row, 0, 1, 200f);

        if (servicesScope != null) {
            if (servicesScope.getDesignAndImplementation() || servicesScope.getClusterExpansion()) {
                row = writeXtremeDesignImplementation(contentStream,
                    xtremeRequestData.getXtremeDesignAndImplementation(), row, questionWidth,
                    servicesScope.getDesignAndImplementation(), servicesScope.getClusterExpansion());
            }
            if (servicesScope.getCache()) {
                row = writeXtremeCache(contentStream, xtremeRequestData.getXtremeCache(), row, questionWidth);
            }
            if (servicesScope.getSf()) {
                row = writeXtremeSF(contentStream, xtremeRequestData.getXtremeSF(), row, questionWidth);
            }
            if (servicesScope.getOracleLocalReplication()) {
                row = writeXtremeIOOracleLocalReplication(contentStream,
                    xtremeRequestData.getXtremeIOOracleLocalReplication(), row, questionWidth);
            }
        }
        return row;
    }

    /**
     * <p>Writes the content of specified Oracle Local Replication for XtremIO section of Xtreme tab to specified PDF
     * document.</p>
     *
     * @param contentStream a <code>PDPageContentStream</code> to write content to.
     * @param xtremeIOOracleLocalReplication a <code>XtremeIOOracleLocalReplication</code> object providing the content
     *       of Oracle Local Replication for XtremIO section of Xtreme tab.
     * @param row an <code>int</code> providing the current row number to start writing from.
     * @param questionWidth a <code>float</code> providing the with of the column.
     * @return an <code>int</code> providing the new row number.
     * @throws IOException if an I/O error occurs.
     * @since 2.13
     */
    private int writeXtremeIOOracleLocalReplication(PDPageContentStream contentStream,
                                                    XtremeIOOracleLocalReplication xtremeIOOracleLocalReplication,
                                                    int row, float questionWidth) throws IOException {
        if (xtremeIOOracleLocalReplication == null) {
            return row;
        }

        row++;
        row = writeFont(contentStream, "ORACLE LOCAL REPLICATION FOR XTREMIO", ++row, 0, true);

        row = writeAnswer(contentStream, row, questionWidth,
            "Perform Planning and Design for Oracle Local Replication with XtremIO Snapshots?",
            bool2String(xtremeIOOracleLocalReplication.getPerformPlanningDesignWithSnapshots()));
        row = writeAnswer(contentStream, row, questionWidth,
            "# of Hours of Functional Overview Delivered by Solutions Architect?",
            decimal2String(xtremeIOOracleLocalReplication.getFunctionalOverviewHours(), 2));

        return row;
    }

    /**
     * <p>Writes the content of specified Xtreme Design and Implementation section of Xtreme tab to specified PDF
     * document.</p>
     *
     * @param contentStream a <code>PDPageContentStream</code> to write content to.
     * @param xtremeDesignAndImplementation a <code>XtremeDesignImpl</code> object providing the content of Xtreme
     * Design and Implementation section of Xtreme tab.
     * @param row an <code>int</code> providing the current row number to start writing from.
     * @param questionWidth a <code>float</code> providing the with of the column.
     * @param designAndImplementation a <code>boolean</code> indicating if XtremIO Design and Implementation service is
     *        selected or not.
     * @param clusterExpansion a <code>boolean</code> indicating if XtremIO Cluster Expansion service is selected or
     *        not.
     * @return an <code>int</code> providing the new row number.
     * @throws IOException if an I/O error occurs.
     * @since 2.10
     */
    private int writeXtremeDesignImplementation(PDPageContentStream contentStream,
                                                XtremeDesignImpl xtremeDesignAndImplementation, int row,
                                                float questionWidth, boolean designAndImplementation,
                                                boolean clusterExpansion) throws IOException {
        if (xtremeDesignAndImplementation == null) {
            return row;
        }

        row++;
        row = writeFont(contentStream, "XTREMIO DESIGN AND IMPLEMENTATION", ++row, 0, true);

        if (designAndImplementation || clusterExpansion) {
            row = writeAnswer(contentStream, row, questionWidth, "EMC or Customer Rack?",
                bool2String(xtremeDesignAndImplementation.getEmcOrCustomerRack()));
            row = writeAnswer(contentStream, row, questionWidth,
                "Include XtremIO clusters 2-brick or 4-brick configurations?",
                bool2String(xtremeDesignAndImplementation.getInclude2or4BricksXtremeIOClusterConfig()));
            row = writeAnswer(contentStream, row, questionWidth, "Additional Testing?",
                bool2String(xtremeDesignAndImplementation.getAdditionalTesting()));
            row = writeAnswer(contentStream, row, questionWidth, "Additional Monitoring?",
                bool2String(xtremeDesignAndImplementation.getAdditionalMonitoring()));
            row = writeAnswer(contentStream, row, questionWidth, "Scripting Work?",
                bool2String(xtremeDesignAndImplementation.getScriptingWork()));
        }
        if (designAndImplementation) {
            row = writeAnswer(contentStream, row, questionWidth, "Include removal of EMC equipment?",
                bool2String(xtremeDesignAndImplementation.getIncludeEMCEquipmentRemoval()));
        }
        if (designAndImplementation || clusterExpansion) {
            row = writeAnswer(contentStream, row, questionWidth, "Include XtremeIO migration (host-based)?",
                bool2String(xtremeDesignAndImplementation.getIncludeXtremeIOMigration()));
            row = writeAnswer(contentStream, row, questionWidth,
                "# of XtremIO Clusters", int2String(xtremeDesignAndImplementation.getXtremeIOClustersNum()));
        }
        if (designAndImplementation) {
            row = writeAnswer(contentStream, row, questionWidth, "# of XtremIO Bricks per Cluster",
                int2String(xtremeDesignAndImplementation.getXtremeIOBricksPerClusterNum()));
        }
        if (designAndImplementation || clusterExpansion) {
            row = writeAnswer(contentStream, row, questionWidth, "# of XtremIO Hosts",
                int2String(xtremeDesignAndImplementation.getXtremeIOHostsNum()));
            row = writeAnswer(contentStream, row, questionWidth, "# of XtremIO Snapshots per Host",
                int2String(xtremeDesignAndImplementation.getXtremeIOSnapshotsPerHostNum()));
        }
        if (clusterExpansion) {
            row = writeAnswer(contentStream, row, questionWidth,
                "# of Bricks to be added to the existing XtremIO Cluster",
                int2String(xtremeDesignAndImplementation.getAddedXtremeIOClusterBricksNum()));
        }
        if (designAndImplementation) {
            row = writeAnswer(contentStream, row, questionWidth, "# of Infiniband Switches to be deployed",
                int2String(xtremeDesignAndImplementation.getDeployedInfinibandSwitchesNum()));
        }

        Boolean dataMigrationIncluded = xtremeDesignAndImplementation.getIncludeXtremeIOMigration();
        if (dataMigrationIncluded != null && dataMigrationIncluded) {
            row = writeXtremeDataMigration(contentStream, xtremeDesignAndImplementation.getXtremeDataMigration(),
                row, questionWidth);
        }

        return row;
    }

    /**
     * <p>Writes the content of specified Data Migration sub-section of Xtreme Design and Implementation section of
     * Xtreme tab to specified PDF document.</p>
     *
     * @param contentStream a <code>PDPageContentStream</code> to write content to.
     * @param xtremeDataMigration a <code>XtremeDataMigration</code> object providing the content of Xtreme Data
     *        Migration section of Xtreme tab.
     * @param row an <code>int</code> providing the current row number to start writing from.
     * @param questionWidth a <code>float</code> providing the with of the column.
     * @return an <code>int</code> providing the new row number.
     * @throws IOException if an I/O error occurs.
     * @since 2.10
     */
    private int writeXtremeDataMigration(PDPageContentStream contentStream, XtremeDataMigration xtremeDataMigration,
                                         int row, float questionWidth) throws IOException {
        if (xtremeDataMigration == null) {
            return row;
        }

        row++;
        row = writeFont(contentStream, "DATA MIGRATION", ++row, 0, true);

        row = writeFont(contentStream, "Select the level of EMC involvement for the data migration", ++row, 0, false);

        List<String> hardwareActivities = new ArrayList<String>();
        if (xtremeDataMigration.getPlanningAndDesign()) {
            hardwareActivities.add("Planning and Design");
        }
        if (xtremeDataMigration.getImplementationMigration()) {
            hardwareActivities.add("Implementation / Migration");
        }
        row = writeOptions(contentStream, hardwareActivities, row, questionWidth, 1, 120f);

        XtremeHostBasedMigrationTool hostBasedMigrationTool = xtremeDataMigration.getHostBasedMigrationTool();
        row = writeAnswer(contentStream, row, questionWidth, "Host-based migration tool to be used",
            hostBasedMigrationTool == null ? "" : hostBasedMigrationTool.getName());

        if (hostBasedMigrationTool != null) {
            if (hostBasedMigrationTool.getId() == 2) {
                row = writeAnswer(contentStream, row, questionWidth,
                    "# of hosts to be migrated via Open Migrator / LM by EMC",
                    int2String(xtremeDataMigration.getNumberOfHostsToMigrateByOpenMigrator()));
            } else if (hostBasedMigrationTool.getId() == 3) {
                row = writeAnswer(contentStream, row, questionWidth,
                    "# of hosts to be migrated via PowerPath Migration Enabler by EMC",
                    int2String(xtremeDataMigration.getNumberOfHostsToMigrateByPPME()));
            }
        }

        row = writeAnswer(contentStream, row, questionWidth, "Include ESX host migration via Storage vMotion?",
            bool2String(xtremeDataMigration.getIncludeESXHostMigrationViaStorageVMotion()));

        if (getBooleanValue(xtremeDataMigration.getIncludeESXHostMigrationViaStorageVMotion())) {
            row = writeAnswer(contentStream, row, questionWidth,
                "# of RCLI installs (Number of RCLI instances - needed for VI 3.5)",
                int2String(xtremeDataMigration.getNumberOfRCLIInstalls()));
            row = writeAnswer(contentStream, row, questionWidth, "# of VMware Virtual Machines to Storage vMotion",
                int2String(xtremeDataMigration.getNumberOfVMWareVMsToStorageVMotion()));
            row = writeAnswer(contentStream, row, questionWidth,
                "# of additional hours needed for Storage vMotion (To be determined by Field)",
                decimal2String(xtremeDataMigration.getAdditionalHoursToStorageVMotion(), 2));
        }


        row = writeAnswer(contentStream, row, questionWidth, "Will VPLEX Data Mobility be implemented?",
            bool2String(xtremeDataMigration.getImplementVPLEXDataMobility()));

        if (getBooleanValue(xtremeDataMigration.getImplementVPLEXDataMobility())) {
            XtremeDataMobilityType xtremeDataMobilityType = xtremeDataMigration.getDataMobilityType();
            row = writeAnswer(contentStream, row, questionWidth, "Select the type of data mobility to be implemented",
                xtremeDataMobilityType == null ? "" : xtremeDataMobilityType.getName());
            row = writeAnswer(contentStream, row, questionWidth,
                "Will encapsulation be used on existing hosts to migrate under VPLEX?",
                bool2String(xtremeDataMigration.getUseEncapsulationForExistingHostsMigrationUnderVPLEX()));
            row = writeAnswer(contentStream, row, questionWidth, "# of storage volumes imported into VPLEX",
                int2String(xtremeDataMigration.getNumberOfStorageVolumesImportedIntoVPLEX()));
            row = writeAnswer(contentStream, row, questionWidth, "# of VPLEX virtual volumes",
                int2String(xtremeDataMigration.getNumberOfVPLEXVirtualVolumes()));
            row = writeAnswer(contentStream, row, questionWidth, "# of VPLEX mirrors",
                int2String(xtremeDataMigration.getNumberOfVPLEXMirrors()));
            row = writeAnswer(contentStream, row, questionWidth, "# of VPLEX data mobility jobs",
                int2String(xtremeDataMigration.getNumberOfVPLEXDataMobilityJobs()));
        }


        row = writeAnswer(contentStream, row, questionWidth, "Implement XtremeIO Snapshots?",
            bool2String(xtremeDataMigration.getImplementXtremeIOSnapshots()));
        row = writeAnswer(contentStream, row, questionWidth, "Swingframe or Swingbox required for migration?",
            bool2String(xtremeDataMigration.getSwingFrameSwingBoxRequired()));

        if (getBooleanValue(xtremeDataMigration.getSwingFrameSwingBoxRequired())) {
            row = writeAnswer(contentStream, row, questionWidth,
                "# of hosts to be migrated via host-based tools by EMC on a host acting as a Swingbox",
                int2String(xtremeDataMigration.getNumberOfHostsToMigrateToSwingBoxByEMC()));
            row = writeAnswer(contentStream, row, questionWidth,
                "# of hosts to be migrated via Open Migrator / LM by EMC on a host acting as a Swingbox",
                int2String(xtremeDataMigration.getNumberOfHostsToMigrateToSwingBoxByOpenMigrator()));
            row = writeAnswer(contentStream, row, questionWidth, "# of hosts to be migrated via PowerPath Migration " +
                "Enabler by EMC on a host acting as a Swingbox",
                int2String(xtremeDataMigration.getNumberOfHostsToMigrateToSwingBoxByPPME()));
        }

        row = writeAnswer(contentStream, row, questionWidth, "Include VMware Virtual Infrastructure 3.5 as part of " +
            "this storage migration (vCenter 2.5)?",
            bool2String(xtremeDataMigration.getIncludeVMWare35Infrastructure()));
        row = writeAnswer(contentStream, row, questionWidth, "# of source and target sites (total)",
            int2String(xtremeDataMigration.getTotalNumberOfSourceAndTargetSites()));
        row = writeAnswer(contentStream, row, questionWidth, "# of new physical hosts included in design",
            int2String(xtremeDataMigration.getNumberOfNewPhysicalHostsIncludedInDesign()));
        row = writeAnswer(contentStream, row, questionWidth, "# of new ESX Servers in design",
            int2String(xtremeDataMigration.getNumberOfNewESXServersInDesign()));
        row = writeAnswer(contentStream, row, questionWidth, "# of New Enterprise Directors",
            int2String(xtremeDataMigration.getNumberOfNewEnterpriseDirectors()));
        row = writeAnswer(contentStream, row, questionWidth, "# of New Departmental Switches",
            int2String(xtremeDataMigration.getNumberOfNewDepartmentalSwitches()));
        row = writeAnswer(contentStream, row, questionWidth, "# of new VNX Block storage arrays",
            int2String(xtremeDataMigration.getNumberOfNewVNXBlockStorageArrays()));
        row = writeAnswer(contentStream, row, questionWidth, "# of new Symmetrix storage arrays",
            int2String(xtremeDataMigration.getNumberOfNewSymmetrixStorageArrays()));
        row = writeAnswer(contentStream, row, questionWidth, "# of VNX Block arrays to be upgraded",
            int2String(xtremeDataMigration.getNumberOfVNXBlockArraysToUpgrade()));
        row = writeAnswer(contentStream, row, questionWidth, "# of Symmetrix to be upgraded",
            int2String(xtremeDataMigration.getNumberOfSymmetrixToUpgrade()));
        row = writeAnswer(contentStream, row, questionWidth, "Total # of source arrays involved in a migration",
            int2String(xtremeDataMigration.getTotalNumberOfSourceArrays()));
        row = writeAnswer(contentStream, row, questionWidth, "Total # of target arrays involved in a migratior",
            int2String(xtremeDataMigration.getTotalNumberOfTargetArrays()));
        row = writeAnswer(contentStream, row, questionWidth, "Does the data migration include device-size changes?",
            bool2String(xtremeDataMigration.getDeviceSizeChangesRequired()));
        row = writeAnswer(contentStream, row, questionWidth, "Amount of source data to be migrated in TB",
            int2String(xtremeDataMigration.getAmountOfSourceDataToMigrateToTB()));
        row = writeAnswer(contentStream, row, questionWidth, "# of hosts to be migrated via host-based tools by EMC",
            int2String(xtremeDataMigration.getNumberOfHostsToMigrateByEMC()));
        row = writeAnswer(contentStream, row, questionWidth, "Total # of hosts (physical hosts & ESX Servers) to be " +
            "migrated by EMC", int2String(xtremeDataMigration.getTotalNumberOfHostsToMigrateByEMC()));
        row = writeAnswer(contentStream, row, questionWidth, "Will the customer do the zoning work on the switches?",
            bool2String(xtremeDataMigration.getWillCustomerDoZonningWorkOnSwitches()));
        row = writeAnswer(contentStream, row, questionWidth, "# of hosts to be booted from the SAN",
            int2String(xtremeDataMigration.getNumberOfHostsBootedFromSAN()));
        row = writeAnswer(contentStream, row, questionWidth, "Will the customer do the LUN or device allocation work " +
            "on the storage?", bool2String(xtremeDataMigration.getWillCustomerDoLUNDeviceAllocationWork()));

        return row;
    }

    /**
     * <p>Writes the content of specified XtremeCache section of Xtreme tab to specified PDF document.</p>
     *
     * @param contentStream a <code>PDPageContentStream</code> to write content to.
     * @param xtremeCache a <code>XtremeCache</code> object providing the content of XtremeCache section of Xtreme tab.
     * @param row an <code>int</code> providing the current row number to start writing from.
     * @param questionWidth a <code>float</code> providing the with of the column.
     * @return an <code>int</code> providing the new row number.
     * @throws IOException if an I/O error occurs.
     * @since 2.10
     */
    private int writeXtremeCache(PDPageContentStream contentStream, XtremeCache xtremeCache, int row,
                                 float questionWidth) throws IOException {
        if (xtremeCache == null) {
            return row;
        }

        row++;
        row = writeFont(contentStream, "XTREMCACHE", ++row, 0, true);

        row = writeAnswer(contentStream, row, questionWidth, "Is this an assesment?",
            bool2String(xtremeCache.getAssessment()));
        row = writeAnswer(contentStream, row, questionWidth, "Number of hosts for XtremCache installation?",
            int2String(xtremeCache.getNumberOfHostsForXtremeCacheInstallation()));
        row = writeAnswer(contentStream, row, questionWidth, "Include installation and configuration of XtremCache?",
            bool2String(xtremeCache.getIncludeInstallationAndConfigurationOfXtremeCache()));
        row = writeAnswer(contentStream, row, questionWidth, "# of XtremSF flash cards to install and configure?",
            int2String(xtremeCache.getNumberOfXtremSFFlashCardsToInstallAndConfigure()));

        return row;
    }

    /**
     * <p>Writes the content of specified XtremeSF section of Xtreme tab to specified PDF document.</p>
     *
     * @param contentStream a <code>PDPageContentStream</code> to write content to.
     * @param xtremeSF a <code>XtremeSF</code> object providing the content of XtremeSF section of Xtreme tab.
     * @param row an <code>int</code> providing the current row number to start writing from.
     * @param questionWidth a <code>float</code> providing the with of the column.
     * @return an <code>int</code> providing the new row number.
     * @throws IOException if an I/O error occurs.
     * @since 2.10
     */
    private int writeXtremeSF(PDPageContentStream contentStream, XtremeSF xtremeSF, int row,
                              float questionWidth) throws IOException {
        if (xtremeSF == null) {
            return row;
        }

        row++;
        row = writeFont(contentStream, "XTREMSF", ++row, 0, true);

        row = writeAnswer(contentStream, row, questionWidth, "# of XtremSF flash cards to install and configure?",
            int2String(xtremeSF.getNumberOfXtremSFFlashCardsToInstallAndConfigure()));
        row = writeAnswer(contentStream, row, questionWidth, "# of hosts for the XtremSF card installs?",
            int2String(xtremeSF.getNumberOfHostsForXtremSFCardInstalls()));
        row = writeAnswer(contentStream, row, questionWidth, "Number of hosts for XtremCache installation?",
            int2String(xtremeSF.getNumberOfHostsForXtremeCacheInstallation()));

        return row;
    }

    /**
     * Creates the unfunded project data section.
     *
     * @param contentStream the content stream
     * @param projectType the requested project type
     * @param data the data to render
     * @param row the current row
     * @param page the current page
     * @return the ending row
     * @throws IOException for any errors encountered
     * @since SRT Phase 3-2 - W4N and Unfunded Project Tabs Assembly
     */
    private int writeUnfundedProjectData(PDPageContentStream contentStream, ProjectType projectType,
        UnfundedProjectData data, int row, PDPage page) throws IOException {
        row++;
        row = writeFont(contentStream, "Services & Activities - Unfunded Project", ++row, 0, true);
        row = writeFont(contentStream, "GENERAL INFORMATION", ++row, 0, true);

        float answerStart = 350f;
        row = writeFont(contentStream, "Unfunded Project Type", ++row, 0, false);
        row = writeFont(contentStream, projectType.getName(), row, answerStart, false);
        row = writeFont(contentStream, "Executive Summary Describing Project", ++row, 0, false);
        row = writeFont(contentStream, data.getExecutiveSummary(), row, answerStart, false);
        row = writeFont(contentStream, "What will EMC receive in return for making this investment?", ++row, 0, false);
        row = writeFont(contentStream, data.getReturnOnInvestment(), row, answerStart, false);
        row = writeFont(contentStream, "In what type of environment will the POC be performed Lab or Production?",
                ++row, 0, false);
        row = writeFont(contentStream, data.getEnvironmentType(), row, answerStart, false);
        row = writeFont(contentStream, "If the POC converts to a sale, what is the estimated booking value?", ++row, 0,
                false);
        row = writeFont(contentStream, moneyFormat(data.getEstBookingValue()), row, answerStart, false);
        row = writeFont(contentStream, "What is the estimated date of purchase decision?", ++row, 0, false);
        row = writeFont(contentStream, date2String(data.getPurchaseDecisionDate()), row, answerStart, false);
        row = writeFont(contentStream, "Special Delivery Requirements (specific resources, Security Clearences, etc)",
                ++row, 0, false);
        row = writeFont(contentStream, data.getSpecialRequirements(), row, answerStart, false);
        row = writeFont(contentStream, "Period of Performance", ++row, 0, false);
        row = writeFont(contentStream, date2String(data.getStartDate()) + " - " + date2String(data.getEndDate()), row,
                answerStart, false);
        row = writeFont(contentStream, "General Comments", ++row, 0, false);
        row = writeMultiLineFont(contentStream, data.getGeneralComments(), row, answerStart, false);

        return row;
    }

    /**
     * Write the message to stream.
     *
     * @param contentStream
     *            the contest stream
     * @param message
     *            the message
     * @param row
     *            the row
     * @param x
     *            the x position
     * @param isHeader
     *            the flag whether the message is header
     * @return the new row number
     * @throws IOException
     *             if any IO error occurs
     * @since SRT Phase 3-2 - Implement SRM and Update Change Request and Move Request Tabs Assembly
     */
    private int writeMultiLineFont(PDPageContentStream contentStream, String message, int row,
        float x, boolean isHeader) throws IOException {
        if (message == null) {
            return writeFont(contentStream, message, row, x, false);
        } else {
            String[] lines = message.split("\n");
            for (String string : lines) {
                row = writeFont(contentStream, string, row, x, false);
                row++;
            }
        }
        return row;
    }

    /**
     * Formats the given value as currency.
     * @param value the value to format
     * @return the formatted value
     * @since SRT Phase 3-2 - W4N and Unfunded Project Tabs Assembly
     */
    private String moneyFormat(BigDecimal value) {
        if (value == null) {
            return "";
        }
        return DecimalFormat.getNumberInstance().format(value.doubleValue());
    }

    /**
     * Creates the SRM data section.
     *
     * @param contentStream
     *            the content stream
     * @param data
     *            the data to render
     * @param row
     *            the current row
     * @param page
     *            the current page
     * @return the ending row
     * @throws IOException
     *             for any errors encountered
     * @since SRT Phase 3-2 - Implement SRM and Update Change Request and Move Request Tabs Assembly
     */
    private int writeSRMData(PDPageContentStream contentStream, SRMRequestData data, int row, PDPage page)
        throws IOException {
        row++;
        row = writeFont(contentStream, "Services & Activities - SRM", ++row, 0, true);

        row = writeFont(contentStream, "GENERAL INFORMATION", ++row, 0, true);

        float xPoint = 350f;

        row = writeFont(contentStream, "Is this an SRM new installation?", ++row, 0, false);
        row = writeFont(contentStream, bool2String(data.getNewInstallation()), row, xPoint, false);
        row = writeFont(contentStream, "Is this an SRM Migration?", ++row, 0, false);
        row = writeFont(contentStream, bool2String(data.getMigration()), row, xPoint, false);
        row = writeFont(contentStream, "Will the installation be a virtual appliance (vApp) or on physical servers?",
                ++row, 0, false);
        row = writeFont(contentStream, bool2String(data.getvApp()), row, xPoint, false);
        row = writeFont(contentStream, "Is EMC ControlCenter currently installed?", ++row, 0, false);
        row = writeFont(contentStream, bool2String(data.getEmcControlCenterInstalled()), row, xPoint, false);
        row = writeFont(contentStream, "Will this be an onsite or remote SRM installation?", ++row, 0, false);
        row = writeFont(contentStream, bool2String(data.getOnsiteOrRemoteInstallation()), row, xPoint, false);
        row = writeFont(contentStream, "Will there be Keyboard Access?", ++row, 0, false);
        row = writeFont(contentStream, bool2String(data.getKeyboardAccess()), row, xPoint, false);
        row = writeFont(contentStream, "General Comments", ++row, 0, false);
        row = writeMultiLineFont(contentStream, data.getGeneralComments(), row, xPoint, false);

        row = writeFont(contentStream, "SRM IMPLEMENTATION", ++row, 0, true);

        row = writeFont(contentStream, "CURRENT ENVIRONMENT - GENERAL", ++row, 20, true);
        row = writeFont(contentStream, "# of AIX VIO?", ++row, 0, false);
        row = writeFont(contentStream, int2StringNoPad(data.getAixVio()), row, xPoint, false);
        row = writeFont(contentStream, "# of Brocade?", ++row, 0, false);
        row = writeFont(contentStream, int2StringNoPad(data.getBrocade()), row, xPoint, false);
        row = writeFont(contentStream, "# of Cisco MDS?", ++row, 0, false);
        row = writeFont(contentStream, int2StringNoPad(data.getCiscoMds()), row, xPoint, false);
        row = writeFont(contentStream, "# of Cisco UCS?", ++row, 0, false);
        row = writeFont(contentStream, int2StringNoPad(data.getCiscoUcs()), row, xPoint, false);
        row = writeFont(contentStream, "# of Converged Infrastructure?", ++row, 0, false);
        row = writeFont(contentStream, int2StringNoPad(data.getConvergedInfrastracture()), row, xPoint, false);
        row = writeFont(contentStream, "# of Data Cernters?", ++row, 0, false);
        row = writeFont(contentStream, int2StringNoPad(data.getDataCenters()), row, xPoint, false);

        row = writeFont(contentStream, "CURRENT ENVIRONMENT - EMC EQUIPMENT", ++row, 20, true);
        row = writeFont(contentStream, "# of Data Domain?", ++row, 0, false);
        row = writeFont(contentStream, int2StringNoPad(data.getDataDomain()), row, xPoint, false);
        row = writeFont(contentStream, "# of EMC Atmos?", ++row, 0, false);
        row = writeFont(contentStream, int2StringNoPad(data.getEmcAtmos()), row, xPoint, false);
        row = writeFont(contentStream, "# of EMC Avamar?", ++row, 0, false);
        row = writeFont(contentStream, int2StringNoPad(data.getEmcAvamar()), row, xPoint, false);
        row = writeFont(contentStream, "# of EMC Centera?", ++row, 0, false);
        row = writeFont(contentStream, int2StringNoPad(data.getEmcCentera()), row, xPoint, false);
        row = writeFont(contentStream, "# of EMC Data Protection Advisors?", ++row, 0, false);
        row = writeFont(contentStream, int2StringNoPad(data.getEmcDataProtectionAdvisor()), row, xPoint, false);
        row = writeFont(contentStream, "# of EMC Isilon / NAS?", ++row, 0, false);
        row = writeFont(contentStream, int2StringNoPad(data.getEmcIsilonNas()), row, xPoint, false);
        row = writeFont(contentStream, "# of EMC RecoverPoint?", ++row, 0, false);
        row = writeFont(contentStream, int2StringNoPad(data.getEmcRecoverPoint()), row, xPoint, false);
        row = writeFont(contentStream, "# of EMC ViPR?", ++row, 0, false);
        row = writeFont(contentStream, int2StringNoPad(data.getEmcVipr()), row, xPoint, false);
        row = writeFont(contentStream, "# of EMC VMAX/Symmetrix?", ++row, 0, false);
        row = writeFont(contentStream, int2StringNoPad(data.getEmcVmaxSymmetrix()), row, xPoint, false);
        row = writeFont(contentStream, "# of EMC VNX Block?", ++row, 0, false);
        row = writeFont(contentStream, int2StringNoPad(data.getEmcVnxBlock()), row, xPoint, false);
        row = writeFont(contentStream, "# of EMC VNX File / NAS?", ++row, 0, false);
        row = writeFont(contentStream, int2StringNoPad(data.getEmcVnxFileNas()), row, xPoint, false);
        row = writeFont(contentStream, "# of EMC VPLEX?", ++row, 0, false);
        row = writeFont(contentStream, int2StringNoPad(data.getEmcVplex()), row, xPoint, false);
        row = writeFont(contentStream, "# of VMware ESX Servers?", ++row, 0, false);
        row = writeFont(contentStream, int2StringNoPad(data.getVmwareEsxServers()), row, xPoint, false);
        row = writeFont(contentStream, "# of XtremIO?", ++row, 0, false);
        row = writeFont(contentStream, int2StringNoPad(data.getXtremIo()), row, xPoint, false);

        row = writeFont(contentStream, "CURRENT ENVIRONMENT - 3RD PARTY", ++row, 20, true);
        row = writeFont(contentStream, "# of Hitachi Device Manager?", ++row, 0, false);
        row = writeFont(contentStream, int2StringNoPad(data.getHitachiDeviceManager()), row, xPoint, false);
        row = writeFont(contentStream, "# of HP 3Par Store Serv?", ++row, 0, false);
        row = writeFont(contentStream, int2StringNoPad(data.getHp3ParStoreServ()), row, xPoint, false);
        row = writeFont(contentStream, "# of HP EVA?", ++row, 0, false);
        row = writeFont(contentStream, int2StringNoPad(data.getHpEva()), row, xPoint, false);
        row = writeFont(contentStream, "# of HP StorageWorks 9000?", ++row, 0, false);
        row = writeFont(contentStream, int2StringNoPad(data.getHpStorageWorks()), row, xPoint, false);
        row = writeFont(contentStream, "# of Hyper-V?", ++row, 0, false);
        row = writeFont(contentStream, int2StringNoPad(data.getHyperV()), row, xPoint, false);
        row = writeFont(contentStream, "# of IBM DS Series?", ++row, 0, false);
        row = writeFont(contentStream, int2StringNoPad(data.getIbmDsSeries()), row, xPoint, false);
        row = writeFont(contentStream, "# of IBM SAN Volume Controllers?", ++row, 0, false);
        row = writeFont(contentStream, int2StringNoPad(data.getIbmSanVolumeControllers()), row, xPoint, false);
        row = writeFont(contentStream, "# of IBM SVC / V7000?", ++row, 0, false);
        row = writeFont(contentStream, int2StringNoPad(data.getIbmSvc()), row, xPoint, false);
        row = writeFont(contentStream, "# of IBM XIV?", ++row, 0, false);
        row = writeFont(contentStream, int2StringNoPad(data.getIbmXiv()), row, xPoint, false);
        row = writeFont(contentStream, "# of NetApp Filer / NAS?", ++row, 0, false);
        row = writeFont(contentStream, int2StringNoPad(data.getNetAppFilerNas()), row, xPoint, false);
        row = writeFont(contentStream, "# of Oracle?", ++row, 0, false);
        row = writeFont(contentStream, int2StringNoPad(data.getOracle()), row, xPoint, false);
        row = writeFont(contentStream, "# of Physical Hosts?", ++row, 0, false);
        row = writeFont(contentStream, int2StringNoPad(data.getPhysicalHosts()), row, xPoint, false);
        row = writeFont(contentStream, "# of SAN Ports?", ++row, 0, false);
        row = writeFont(contentStream, int2StringNoPad(data.getSanPorts()), row, xPoint, false);
        row = writeFont(contentStream, "# of VI Virtual Instruments SAN Performance Probes?", ++row, 0, false);
        row = writeFont(contentStream, int2StringNoPad(data.getViSanPerfProbes()), row, xPoint, false);

        return row;
    }

    /**
     * Creates the W4N data section.
     *
     * @param contentStream the content stream
     * @param data the data to render
     * @param row the current row
     * @param page the current page
     * @return the ending row
     * @throws IOException for any errors encountered
     * @since SRT Phase 3-2 - W4N and Unfunded Project Tabs Assembly
     */
    private int writeW4NData(PDPageContentStream contentStream, W4NData data, int row, PDPage page) throws IOException {
        row++;
        float shortStart = 150f;
        float answerStart = 350f;

        row = writeFont(contentStream, "Services & Activities - W4N", ++row, 0, true);

        row = writeFont(contentStream, "GENERAL INFORMATION", ++row, 0, true);
        row = writeFont(contentStream, "General Comments", ++row, 0, false);
        row = writeMultiLineFont(contentStream, data.getGeneralComments(), row, answerStart, false);

        row = writeFont(contentStream, "PRODUCTS FOR DEPLOYMENT", ++row, 0, true);
        row = writeFont(contentStream, "Service Type", ++row, 0, false);

        List<String> w4nTypes = new ArrayList<String>();
        if (data.isW4nInstall()) {
            w4nTypes.add("W4N Install");
        }
        if (data.isW4nUpgrade()) {
            w4nTypes.add("W4N Upgrade");
        }
        if (data.isExistingSmartsCustomer()) {
            w4nTypes.add("Existing Smarts Customer");
        }
        if (data.isAdditionalLabInstall()) {
            w4nTypes.add("Addtl.Lab Install");
        }
        if (data.isItprMigration()) {
            w4nTypes.add("ITPR Migration");
        }
        row = writeOptions(contentStream, w4nTypes, row, shortStart, 1, 100f);

        row = writeFont(contentStream, "W4N Failover", ++row, 0, false);
        row = writeFont(contentStream, bool2String(data.getW4nFailover()), row, answerStart, false);
        row = writeFont(contentStream, "Total Managed Devices", ++row, 0, false);
        row = writeFont(contentStream, int2StringNoPad(data.getTotalManagedDevices()), row, answerStart, false);
        if (data.isExistingSmartsCustomer()) {
            row = writeFont(contentStream, "Total Managed P&I", ++row, 0, false);
            row = writeFont(contentStream, int2StringNoPad(data.getTotalManagedPandI()), row, answerStart, false);

            row = writeFont(contentStream, "Other SP / Coll / RP not Listed", ++row, 0, false);
            row = writeFont(contentStream, data.getOtherSPNotListed(), row, answerStart, false);

            row = writeLookupSelection(contentStream, row, answerStart, data.getSmartsDomainTypes(),
                    "SMARTS Domain Types Source for W4N");
        }

        row = writeFont(contentStream, "SOLUTION PACKS", ++row, 0, true);
        row = writeLookupSelection(contentStream, row, answerStart, data.getEmcSolutionPacks(), "EMC / NMS");
        row = writeLookupSelection(contentStream, row, answerStart, data.getDcSolutionPacks(),
                "Data Center, Virtualization");

        row = writeFont(contentStream, "Traffic Flows & Transactions / End-User", ++row, 0, true);
        row = writeFont(contentStream, "Traffic Flows", ++row, 0, false);
        row = writeFont(contentStream, bool2String(data.getTrafficFlows()), row, answerStart, false);
        row = writeFont(contentStream, "# of Flow enabled Routers", ++row, 0, false);
        row = writeFont(contentStream, int2StringNoPad(data.getEnabledFlowsCount()), row, answerStart, false);
        row = writeFont(contentStream, "Transactions", ++row, 0, false);
        row = writeFont(contentStream, bool2String(data.getTransactions()), row, answerStart, false);

        row = writeLookupSelection(contentStream, row, answerStart, data.getVoipSolutionPacks(), "VoIP");
        row = writeLookupSelection(contentStream, row, answerStart, data.getMobileSolutionPacks(), "Mobile / Wireless");

        row = writeFont(contentStream, "COLLECTORS", ++row, 0, true);
        row = writeLookupSelection(contentStream, row, answerStart, data.getCollectors(), "Collectors");

        row = writeFont(contentStream, "REPORT PACKS", ++row, 0, true);
        row = writeLookupSelection(contentStream, row, answerStart, data.getNetworkReportPacks(), "Network");
        row = writeLookupSelection(contentStream, row, answerStart, data.getVpnReportPacks(), "Firewall / VPN");
        row = writeLookupSelection(contentStream, row, answerStart, data.getWiFiReportPacks(), "WiFi");
        row = writeLookupSelection(contentStream, row, answerStart, data.getWanAccelerators(), "WAN Accelerator");
        row = writeLookupSelection(contentStream, row, answerStart, data.getServerReportPacks(),
                "Servers Applications");

        row = writeFont(contentStream, "STORAGE", ++row, 0, true);
        row = writeFont(contentStream, "Storage Information", ++row, 0, true);
        row = writeFont(contentStream, "# of LUNS", ++row, 0, false);
        row = writeFont(contentStream, int2StringNoPad(data.getNumberOfLUNS()), row, answerStart, false);
        row = writeFont(contentStream, "# of Disks", ++row, 0, false);
        row = writeFont(contentStream, int2StringNoPad(data.getNumberOfDisks()), row, answerStart, false);
        row = writeFont(contentStream, "# of Arrays", ++row, 0, false);
        row = writeFont(contentStream, int2StringNoPad(data.getNumberOfArrays()), row, answerStart, false);
        row = writeFont(contentStream, "Storage Solution Pack", ++row, 0, false);
        row = writeFont(contentStream, bool2String(data.getStorageSolutionPack()), row, answerStart, false);
        row = writeLookupSelection(contentStream, row, answerStart, data.getStorageReportPacks(),
                "Storage Report Packs");
        return row;
    }

    /**
     * Writes a list of lookup selections.
     * @param contentStream the current stream
     * @param row the current row
     * @param answerStart the start of the response column
     * @param entities the entities to write
     * @param label the label for the field
     * @return the new row
     * @throws IOException for any errors encountered
     * @since SRT Phase 3-2 - W4N and Unfunded Project Tabs Assembly
     */
    private int writeLookupSelection(PDPageContentStream contentStream, int row, float answerStart,
        List<? extends LookupEntity> entities, String label) throws IOException {
        row = writeFont(contentStream, label, ++row, 0, false);
        List<String> options = new ArrayList<String>();
        if (entities != null) {
            for (LookupEntity lookup : entities) {
                options.add(lookup.getName());
            }
        }
        row = writeOptions(contentStream, options, row, answerStart, 1, 100f, true);
        return row;
    }

    /**
     * Creates the change request data section.
     *
     * Currently we flatten the grid so data is vertically presented because there could be up to 24 months, and it will
     * not fit the page.
     *
     * @param contentStream the content stream
     * @param data the data to render
     * @param row the current row
     * @param page the current page
     * @return the ending row
     * @throws IOException for any errors encountered
     * @since SRT Phase 3-2 - Move Request and Change Request Tabs Assembly
     */
    private int writeChangeRequestData(PDPageContentStream contentStream, ChangeRequestData data, int row,
        PDPage page) throws IOException {
        row++;

        float answerStart = 350f;
        row = writeFont(contentStream, "Services & Activities - Change Request", ++row, 0, true);
        row = writeFont(contentStream, "GENERAL INFORMATION", ++row, 0, true);
        row = writeFont(contentStream, "# of Months", ++row, 0, false);
        row = writeFont(contentStream, int2String(data.getNumberOfMonths()), row, answerStart, false);
        row = writeFont(contentStream, "General Comments", ++row, 0, false);
        row = writeMultiLineFont(contentStream, data.getGeneralComments(), row, answerStart, false);

        if (data.getRows() == null) {
            return row;
        }

        int numMonths = data.getNumberOfMonths() == null ? 6 : data.getNumberOfMonths();
        for (HoursByMonth d : data.getRows()) {
            row = writeFont(contentStream, "HOURS BY MONTH", ++row, 0, true);
            row = writeFont(contentStream, "Current SAP WBS Element #:", ++row, 0, false);
            row = writeFont(contentStream, d.getCurrentSAPWBSElementNo(), row, answerStart, false);

            List<RoleHoursByMonth> rows = d.getRows();
            if (rows != null) {
                for (RoleHoursByMonth r : rows) {
                    row = writeFont(contentStream, "Role", ++row, 0, false);
                    row = writeFont(contentStream, r.getRole(), row, answerStart, false);
                    Map<Integer, String> hours = r.getHours();
                    if (hours != null) {
                        for (int counter = 1; counter <= numMonths; counter++) {
                            String h = trimToEmpty(hours.get(counter));
                            row = writeFont(contentStream, "     Month " + counter, ++row, 0, false);
                            row = writeFont(contentStream, h, row, answerStart, false);
                        }
                    }
                }
            }
        }
        return row;
    }

    /**
     * Creates the move request data section.
     * @param contentStream the content stream
     * @param data the data to render
     * @param row the current row
     * @param page the current page
     * @return the ending row
     * @throws IOException for any errors encountered
     * @since SRT Phase 3-2 - Move Request and Change Request Tabs Assembly
     */
    private int writeMoveRequestData(PDPageContentStream contentStream, MoveRequestData data, int row,
        PDPage page) throws IOException {

        row++;

        float answerStart = 350f;

        row = writeFont(contentStream, "Services & Activities - CS Services", ++row, 0, true);
        row = writeFont(contentStream, "GENERAL INFORMATION", ++row, 0, true);

        row = writeFont(contentStream, "Full Project Description / Scope", ++row, 0, false);
        row = writeMultiLineFont(contentStream, data.getFullDescription(), row, answerStart, false);
        row = writeFont(contentStream, "Are after-hours, holiday, or weekend services needed?", ++row, 0, false);
        row = writeFont(contentStream, bool2String(data.getAfterHoursMSSNeeded()), row, answerStart, false);
        row = writeFont(contentStream, "What is the project timeline?", ++row, 0, false);
        row = writeFont(contentStream, data.getProjectTimeline(), row, answerStart, false);
        row = writeFont(contentStream, "Weekday or Weekend delivery (Target date)?", ++row, 0, false);
        row = writeFont(contentStream, data.getTargetDate(), row, answerStart, false);
        row = writeFont(contentStream, "General Comments", ++row, 0, false);
        row = writeMultiLineFont(contentStream, data.getGeneralComments(), row, answerStart, false);

        row = writeFont(contentStream, "CS SERVICES SCOPE", ++row, 0, true);
        if (data.isMoveServices()) {
            row = writeFont(contentStream, "- Move Services", ++row, 0, false);
        }
        if (data.isPowerDownPowerUp()) {
            row = writeFont(contentStream, "- Power Down / Power Up", ++row, 0, false);
            row = writeFont(contentStream, "List of Equipment Required", ++row, 0, false);
            row = writeFont(contentStream, data.getPowerUpEquipment(), row, answerStart, false);
        }
        if (data.isDeinstallReinstall()) {
            row = writeFont(contentStream, "- Deinstall / Reinstall", ++row, 0, false);
            row = writeFont(contentStream, "List of Equipment Required", ++row, 0, false);
            row = writeFont(contentStream, data.getDeinstallUpEquipment(), row, answerStart, false);
            row = writeFont(contentStream, "IP Change Required?", ++row, 0, false);
            row = writeFont(contentStream, bool2String(data.getIpChangeRequired()), row, answerStart, false);
        }
        if (data.isReconfigurationSupport()) {
            row = writeFont(contentStream, "- Reconfiguration Support", ++row, 0, false);
            row = writeFont(contentStream, "Explain Customer Requirements", ++row, 0, false);
            row = writeFont(contentStream, data.getExplainCustRequirements(), row, answerStart, false);
        }

        if (data.isMoveServices()) {
            row = writeFont(contentStream, "EQUIPMENT INVOLVED", ++row, 0, true);
            row = writeFont(contentStream, "How many EMC Racks Total?", ++row, 0, false);
            row = writeFont(contentStream, int2String(data.getEmcRacksTotal()), row, answerStart, false);
            row = writeFont(contentStream, "How many NON-EMC Racks Total?", ++row, 0, false);
            row = writeFont(contentStream, int2String(data.getNonEmcRacksTotal()), row, answerStart, false);
            row = writeFont(contentStream, "If no rack please provide a description of the components", ++row,
                    0, false);
            row = writeFont(contentStream, data.getNoRack(), row, answerStart, false);
            row = writeFont(contentStream, "Equipment", ++row, 0, false);
            row = writeFont(contentStream, data.getEquipment(), row, answerStart, false);
            row = writeFont(contentStream, "Is this equipment under an EMC Maintenance contract?", ++row, 0, false);
            row = writeFont(contentStream, bool2String(data.getEquipmentUnderMaintenance()), row, answerStart, false);
            row = writeFont(contentStream, "Is any EMC Equipment recertification required?", ++row, 0, false);
            row = writeFont(contentStream, bool2String(data.getEmcCertificationRequired()), row, answerStart, false);

            row = writeFont(contentStream, "MOVE SERVICES", ++row, 0, true);
            row = writeFont(contentStream, "Are EMC move services needed? (Y/N)", ++row, 0, false);
            row = writeFont(contentStream, bool2String(data.getEmcMoveServicesNeeded()), row, answerStart, false);
            row = writeFont(contentStream, "Does the pickup/delivery need to be completed after-business hours? (Y/N)",
                    ++row, 0, false);
            row = writeFont(contentStream, bool2String(data.getPickupAfterHours()), row, answerStart, false);
            row = writeFont(contentStream, "Will the move take place as a single event? (Y/N)", ++row, 0, false);
            row = writeFont(contentStream, bool2String(data.getSingleEvent()), row, answerStart, false);
            row = writeFont(contentStream, "Does each piece of equipment need networking configuration reset? (Y/N)",
                    ++row, 0, false);
            row = writeFont(contentStream, bool2String(data.getEachPieceNeedsNetCfgReset()), row, answerStart, false);
            row = writeFont(contentStream, "Is EMC packaging material needed? (Y/N)", ++row, 0, false);
            row = writeFont(contentStream, bool2String(data.getEmcPackingMaterialsNeeded()), row, answerStart, false);

            row = writeFont(contentStream, "Gross Value of equipment (Hardware) (US$) ? (Brazil Requirments)", ++row,
                    0, false);
            row = writeFont(contentStream, data.getTotalValue(), row, answerStart, false);

            row = writeAnswer(contentStream, row, answerStart,
                    "EMC requires the customer sign a Data Loss Liability Waiver "
                            + "before equipment is moved. Leave any comments in this box.", data.getComments());

            row = writeAnswer(contentStream, row, answerStart,
                    "Please indicate desired shipping speed (this will affect shipping price)"
                            + " Examples: Same-day, Overnight, 2 day, 3 day, etc.", data.getShippingTimeline());

            List<SiteInformation> sites = data.getSiteInformation();
            PDDocument mockdoc = new PDDocument();
            PDRectangle pdRectangle = new PDRectangle(DEFAULT_PAGE_WIDTH, DEFAULT_PAGE_HEIGHT);
            PDPage mockpage = new PDPage(pdRectangle);
            mockdoc.addPage(mockpage);
            // Start streaming the content
            PDPageContentStream mockStream = new PDPageContentStream(mockdoc, mockpage);

            float datacell = 160f;
            float cellWidth = 65f;
            int cRow = row + 1;
            int[] dRows = new int[] {1, 1, 1, 1, 1, 1, 1, 1};
            int beforeWrite = 0;
            // determine the #of rows per question.
            for (int i = 0; i < sites.size(); i++) {
                cRow = row + 1;
                SiteInformation site = sites.get(i);
                float dataCellStart = 0;

                beforeWrite = cRow;
                cRow = writeMultilineCell(mockStream, site.getAddress(), cRow, dataCellStart, false, cellWidth);
                dRows[0] = Math.max(cRow - beforeWrite, dRows[0]);
                beforeWrite = cRow;
                cRow = writeCelerraCell(mockStream, site.getTrailerAccess(), cRow, dataCellStart, false, cellWidth);
                dRows[1] = Math.max(cRow - beforeWrite, dRows[1]);
                beforeWrite = cRow;
                cRow = writeCelerraCell(mockStream, site.getLoadingDocks(), cRow, dataCellStart, false, cellWidth);
                dRows[2] = Math.max(cRow - beforeWrite, dRows[2]);
                beforeWrite = cRow;
                cRow = writeCelerraCell(mockStream, site.getEquipmentOnSecondFloor(), cRow, dataCellStart,
                        false, cellWidth);
                dRows[3] = Math.max(cRow - beforeWrite, dRows[3]);
                beforeWrite = cRow;
                cRow = writeCelerraCell(mockStream, site.getTruckLiftGateRequired(), cRow, dataCellStart,
                        false, cellWidth);
                dRows[4] = Math.max(cRow - beforeWrite, dRows[4]);
                beforeWrite = cRow;
                cRow = writeMultilineCell(mockStream, site.getPackingMaterialsOnsiteDate(), cRow, dataCellStart,
                        false, cellWidth);
                dRows[5] = Math.max(cRow - beforeWrite, dRows[5]);
                beforeWrite = cRow;
                cRow = writeMultilineCell(mockStream, site.getPickupDate(), cRow, dataCellStart,
                        false, cellWidth);
                dRows[6] = Math.max(cRow - beforeWrite, dRows[6]);
                beforeWrite = cRow;
                cRow = writeMultilineCell(mockStream, site.getDeliveryDate(), cRow,
                        dataCellStart, false, cellWidth);
                dRows[7] = Math.max(cRow - beforeWrite, dRows[7]);
                beforeWrite = cRow;
            }

            ArrayList<SiteInformation> group = new ArrayList<SiteInformation>(sites);
            ArrayList<SiteInformation> cgroup = new ArrayList<SiteInformation>();
            int written = 0;
            while (!group.isEmpty()) {
                cgroup.add(group.remove(0));
                if (cgroup.size() == 4) {
                    row = writeMoveSites(contentStream, row, cgroup, datacell, cellWidth, dRows, written);
                    written += 4;
                    cgroup.clear();
                }
            }
            if (!cgroup.isEmpty()) {
                row = writeMoveSites(contentStream, row, cgroup, datacell, cellWidth, dRows, written);
            }
        }
        return row;
    }

    /**
     * Write the multiline cell to a Celerra Table.
     *
     * @param contentStream
     *            the content stream
     * @param value
     *            the object to export/write
     * @param row
     *            the row number
     * @param datacell
     *            the data cell start position
     * @param b flag for boolean
     * @param cellWidth cell width
     * @return the ending row
     * @throws IOException
     *             if any I/O error occurs
     * @since SRT Phase 3-2 - Implement SRM and Update Change Request and Move Request Tabs Assembly
     */
    private int writeMultilineCell(PDPageContentStream contentStream, String value, int row, float datacell,
        boolean b, float cellWidth) throws IOException {
        if (value == null) {
            return writeCelerraCell(contentStream, "", row, datacell, b, cellWidth);
        }
        String[] lines = value.split("\n");
        for (String string : lines) {
            row = writeCelerraCell(contentStream, string, row, datacell, b, cellWidth);
        }

        return row;
    }

    /**
     * Writes move request sites information.
     * @param contentStream
     *            the content stream
     * @param row
     *            the row number to start
     * @param sites
     *            the move request sites information
     * @param datacell
     *            the data cell start position
     * @param cellWidth cell width
     * @param dRows the row numbers pre-determined
     * @param written Site count have written
     * @return new row number
     * @throws IOException
     *             if any I/O error occurs
     * @since SRT Phase 3-2 - Move Request and Change Request Tabs Assembly
     */
    private int writeMoveSites(PDPageContentStream contentStream, int row, List<SiteInformation> sites, float datacell,
        float cellWidth, int[] dRows, int written) throws IOException {
        if (sites != null && sites.size() > 0) {
            row++;
            row = writeFont(contentStream, "Sites:", ++row, 0, true);

            int dataRow = row + 1;
            for (int i = 0; i < sites.size(); i++) {
                row = writeFont(contentStream, "Site " + (written + i + 1), row, (8 * i) + datacell + cellWidth
                        * (i + 1), true);
            }

            writeFont(contentStream, "Site Address", dataRow, 0, false);
            dataRow = dataRow + dRows[0];
            writeFont(contentStream, "Trailer Access?", dataRow, 0, false);
            dataRow = dataRow + dRows[1];
            writeFont(contentStream, "Loading Docks?", dataRow, 0, false);
            dataRow = dataRow + dRows[2];
            writeFont(contentStream, "Equipment on the 2nd floor?", dataRow, 0, false);
            dataRow = dataRow + dRows[3];
            writeFont(contentStream, "Truck lift gate required?", dataRow, 0, false);
            dataRow = dataRow + dRows[4];
            writeFont(contentStream, "When does packaging material need to be on site?", dataRow, 0, false);
            dataRow = dataRow + dRows[5];
            writeFont(contentStream, "When is the equipment to be picked up for transport?", dataRow, 0, false);
            dataRow = dataRow + dRows[6];
            writeFont(contentStream, "When is the equipment to be delivered?", dataRow, 0, false);

            for (int i = 0; i < sites.size(); i++) {
                dataRow = row + 1;
                SiteInformation site = sites.get(i);
                float dataCellStart = (8 * i) + datacell + cellWidth * (i + 1);
                writeCelerraCell(contentStream, site.getAddress(), dataRow, dataCellStart, false, cellWidth);
                dataRow = dataRow + dRows[0];
                writeCelerraCell(contentStream, site.getTrailerAccess(), dataRow, dataCellStart, false, cellWidth);
                dataRow = dataRow + dRows[1];
                writeCelerraCell(contentStream, site.getLoadingDocks(), dataRow, dataCellStart, false, cellWidth);
                dataRow = dataRow + dRows[2];
                writeCelerraCell(contentStream, site.getEquipmentOnSecondFloor(), dataRow, dataCellStart, false,
                        cellWidth);
                dataRow = dataRow + dRows[3];
                writeCelerraCell(contentStream, site.getTruckLiftGateRequired(), dataRow, dataCellStart,
                        false, cellWidth);
                dataRow = dataRow + dRows[4];
                writeCelerraCell(contentStream, site.getPackingMaterialsOnsiteDate(), dataRow, dataCellStart,
                        false, cellWidth);
                dataRow = dataRow + dRows[5];
                writeCelerraCell(contentStream, site.getPickupDate(), dataRow, dataCellStart,
                        false, cellWidth);
                dataRow = dataRow + dRows[6];
                writeCelerraCell(contentStream, site.getDeliveryDate(), dataRow,
                        dataCellStart, false, cellWidth);
            }
            row = dataRow + dRows[7];
        }
        return row;
    }

    /**
     * Create a new page.
     * @param document
     *            PDF document
     * @return new page
     */
    private PDPage newPage(PDDocument document) {

        PDRectangle pdRectangle = new PDRectangle(DEFAULT_PAGE_WIDTH, DEFAULT_PAGE_HEIGHT);
        PDPage page = new PDPage(pdRectangle);
        document.addPage(page);
        return page;
    }

    /**
     * End the page.
     * @param page
     *            PDF page
     * @param row
     *            the row number of the PDF page
     */
    private void endPage(PDPage page, int row) {

        PDRectangle mediaBox = page.getMediaBox();
        mediaBox.setLowerLeftY(mediaBox.getLowerLeftY() + getYPos(row) - DEFAULT_PAGE_PADDING);
        page.setCropBox(mediaBox);
    }

    /**
     * Write the VMWare Assessment information.
     *
     * @param contentStream
     *            The content stream
     * @param assessment
     *            The VMWare Assessment information
     * @param row
     *            the start row number
     * @param questionWidth
     *            the question width
     * @return the new row number
     * @throws IOException
     *             if any IO error occurs
     * @since SRT Phase 3-1 - Implement VMWare Tab Assembly
     */
    private int writeVMWareAssessment(PDPageContentStream contentStream, VMwareAssessment assessment, int row,
            float questionWidth) throws IOException {
        if (assessment == null) {
            return row;
        }

        row++;
        row = writeFont(contentStream, "ASSESSMENT", ++row, 0, true);

        VMwareAssessmentType assessmentType = assessment.getAssessmentType();

        row = writeAnswers(contentStream, row, questionWidth, "Assessment Type",
            breakToLinesBySpace(assessmentType == null ? "" : assessmentType.toString(),
                DEFAULT_PAGE_WIDTH - DEFAULT_PAGE_PADDING - questionWidth - 1, FONT_TEXT, DEFAULT_FONT_SIZE));

        if (assessmentType == VMwareAssessmentType.CAPACITY_PLANNER) {
            row = writeAnswer(contentStream, row, questionWidth,
                    "Include Configuration of Vmware Capacity Planner for a single site"
                    + " and One Data Manager Collector?",
                    bool2String(assessment.getIncludeSingleConfig()));
            row = writeAnswer(contentStream, row, questionWidth,
                    "Include configuration of multiple sites and Data Manager collectors"
                    + " with VMware Capacity Planner?",
                    bool2String(assessment.getIncludeMultipleConfig()));
            row = writeAnswer(contentStream, row, questionWidth,
                    "Present EMC Virtualization Assessment Service Analysis Summary Report?",
                    bool2String(assessment.getPresentEMCReport()));

            if (assessment.getIncludeMultipleConfig() != null && assessment.getIncludeMultipleConfig()) {
                row = writeAnswer(contentStream, row, questionWidth,
                        "# of VMware Capacity Planner sites?",
                        int2String(assessment.getCapacityPlannerSitesNum()));
                row = writeAnswer(contentStream, row, questionWidth,
                        "# of VMware Capacity Planner Data Manager Collectors?",
                        int2String(assessment.getCapacityPlannerCollectorsNum()));
                row = writeAnswer(contentStream, row, questionWidth,
                        "# of days to capture collection data for this engagement?",
                        int2String(assessment.getDaysToCaptureCollectionData()));
                row = writeAnswer(contentStream, row, questionWidth,
                        "# of additional servers to be analyzed beyond the initial 200?",
                        int2String(assessment.getAdditionalServersNum()));
            }
        } else if (assessmentType == VMwareAssessmentType.STORAGE_FOR_VCENTER
                || assessmentType == VMwareAssessmentType.STORAGE_FOR_VSPHERE) {
            row = writeAnswer(contentStream, row, questionWidth,
                    "# of VMware vSphere Clusters to be analyzed as part of this engagement?",
                    int2String(assessment.getVsphereClustersNum()));
        }

        return row;
    }

    /**
     * Write the VMWare backup and recovery information.
     *
     * @param contentStream
     *            The content stream
     * @param backupRecovery
     *            The VMWare backup and recovery information
     * @param row
     *            the start row number
     * @param questionWidth
     *            the question width
     * @return the new row number
     * @throws IOException
     *             if any IO error occurs
     * @since SRT Phase 3-1 - Implement VMWare Tab Assembly
     */
    private int writeVMWareBackupRecovery(PDPageContentStream contentStream, VMwareBackupRecovery backupRecovery,
        int row, float questionWidth) throws IOException {
        if (backupRecovery == null) {
            return row;
        }

        row++;
        row = writeFont(contentStream, "BACKUP AND RECOVERY", ++row, 0, true);

        row = writeFont(contentStream, "Backup Assessment for VmWare", ++row, 0, false);

        row = writeAnswer(contentStream, row, questionWidth, "# of existing VirtualCenter installations?",
            int2String(backupRecovery.getVirtualCenterInstallationsNum()));
        row = writeAnswer(contentStream, row, questionWidth,
                "# of existing ESX/ESXi Servers?",
                int2String(backupRecovery.getEsxServersNum()));
        row = writeAnswer(contentStream, row, questionWidth,
                "# of existing VMware virtual hosts?",
                int2String(backupRecovery.getVirtualHostsNum()));
        row = writeAnswer(contentStream, row, questionWidth,
                "# of assessment interviews?",
                int2String(backupRecovery.getAssessmentInterviewsNum()));

        return row;
    }

    /**
     * Write the VMWare health checks information.
     *
     * @param contentStream
     *            The content stream
     * @param healthChecks
     *            The VMWare health checks information
     * @param row
     *            the start row number
     * @param questionWidth
     *            the question width
     * @return the new row number
     * @throws IOException
     *             if any IO error occurs
     * @since SRT Phase 3-1 - Implement VMWare Tab Assembly
     */
    private int writeVMWareHealthChecks(PDPageContentStream contentStream, VMwareHealthChecks healthChecks, int row,
            float questionWidth) throws IOException {
        if (healthChecks == null) {
            return row;
        }

        row++;
        row = writeFont(contentStream, "HEALTH CHECKS", ++row, 0, true);

        row = writeFont(contentStream, "Health Check for Vmware Virtual Infrastructure", ++row, 0, false);

        row = writeAnswer(contentStream, row, questionWidth,
                "Include the Vmware Health Check Executive Summary review with the Project Sponsor?",
                bool2String(healthChecks.getIncludeExecutiveSummaryReview()));
        row = writeAnswer(contentStream, row, questionWidth,
                "# of assessment interviews?",
                int2String(healthChecks.getAssessmentInterviewsNum()));
        row = writeAnswer(contentStream, row, questionWidth,
                "# of existing ESX/ESXi Servers?",
                int2String(healthChecks.getEsxServersNum()));
        row = writeAnswer(contentStream, row, questionWidth, "# of existing VMware virtual hosts?",
            int2String(healthChecks.getVirtualHostsNum()));

        return row;
    }

    /**
     * Write the VMWare TCO assessment information.
     *
     * @param contentStream
     *            The content stream
     * @param tcoAssessment
     *            The VMWare TCO assessment information
     * @param row
     *            the start row number
     * @param questionWidth
     *            the question width
     * @return the new row number
     * @throws IOException
     *             if any IO error occurs
     * @since SRT Phase 3-1 - Implement VMWare Tab Assembly
     */
    private int writeVMWareTCOAssessment(PDPageContentStream contentStream, VMwareTCOAssessment tcoAssessment,
            int row, float questionWidth) throws IOException {
        if (tcoAssessment == null) {
            return row;
        }

        row++;
        row = writeFont(contentStream, "TCO ASSESSMENT FOR VIRTUAL INFRASTRUCTURE", ++row, 0, true);

        row = writeAnswer(contentStream, row, questionWidth, "TCO Assessment Scenario",
            tcoAssessment.getAssessmentScenario() == null ? "" : tcoAssessment.getAssessmentScenario().toString());
        row = writeAnswer(contentStream, row, questionWidth,
                "# of Data Center Locations under analysis?",
                int2String(tcoAssessment.getDataCenterLocationsNum()));
        row = writeAnswer(contentStream, row, questionWidth,
                "# of interviews to be conducted for engagement?",
                int2String(tcoAssessment.getConductedInterviewsNum()));

        return row;
    }

    /**
     * Write the VMWare replication information.
     *
     * @param contentStream
     *            The content stream
     * @param replication
     *            The VMWare replication information
     * @param row
     *            the start row number
     * @param questionWidth
     *            the question width
     * @return the new row number
     * @throws IOException
     *             if any IO error occurs
     * @since SRT Phase 3-1 - Implement VMWare Tab Assembly
     */
    private int writeVMWareReplication(PDPageContentStream contentStream, VMwareReplication replication, int row,
            float questionWidth) throws IOException {
        if (replication == null) {
            return row;
        }

        row++;
        row = writeFont(contentStream, "REPLICATION", ++row, 0, true);

        row = writeFont(contentStream, "Vmware Site Recovery Manager - Integration with Replication Technologies",
                ++row, 0, false);

        row = writeAnswer(contentStream, row, questionWidth,
                "Install VMware Site Recovery Manager?",
                bool2String(replication.getInstallSRM()));
        row = writeAnswer(contentStream, row, questionWidth,
                "Does the customer require VMware SRM \"JumpStart\" Training (Three day Workshop)?",
                bool2String(replication.getCustomerRequireSRMTraining()));

        if (replication.getInstallSRM() != null && replication.getInstallSRM()) {
            row = writeAnswer(contentStream, row, questionWidth,
                    "# of VMware SRM Site Recovery Adopters (SRAs)?",
                    int2String(replication.getSrmAdoptersNum()));
            row = writeAnswer(contentStream, row, questionWidth,
                    "# of VMware SRM Recovery Plans for Protection Groups?",
                    int2String(replication.getSrmPlansNum()));
        }

        row = writeQuestion(contentStream, "Replication Technology Type for VMware SRM Environment", ++row, 0, false,
            questionWidth);

        List<String> replicationTypes = new ArrayList<String>();
        if (replication.isCelerraIP()) {
            replicationTypes.add("Celerra IP/VNX IP Replcator Option");
        }
        if (replication.isVnxBlock()) {
            replicationTypes.add("VNX Block MV/S Option");
        }
        if (replication.isRecoverPoint()) {
            replicationTypes.add("RecoverPoint Option");
        }
        if (replication.isSymmetrixSRDF()) {
            replicationTypes.add("Symmetrix SRDF A/S Option");
        }
        row = writeOptions(contentStream, replicationTypes, row, questionWidth, 1, 200f);

        if (replication.isSymmetrixSRDF()) {
            row = writeAnswer(contentStream, row, questionWidth,
                    "# of new Symmetrix using SRDF A/S in VMware SRM environment?",
                    int2String(replication.getNewSymmetrixNum()));
            row = writeAnswer(contentStream, row, questionWidth,
                    "# of existing Symmetrix using SRDF A/S in VMware SRM environment?",
                    int2String(replication.getExistingSymmetrixNum()));
        }

        if (replication.isVnxBlock()) {
            row = writeAnswer(contentStream, row, questionWidth,
                    "# of New VNX Block arrays Using Mirror View/S in VMware SRM environment?",
                    int2String(replication.getNewVNXBlockNum()));
            row = writeAnswer(contentStream, row, questionWidth,
                    "# of Existing VNX Block Using Mirror View/S in VMware SRM environment?",
                    int2String(replication.getExistingVNXBlockNum()));
        }

        if (replication.isRecoverPoint()) {
            row = writeAnswer(contentStream, row, questionWidth,
                    "# of New RecoverPoint Clusters in VMware SRM environment?",
                    int2String(replication.getNewRecoverPointClustersNum()));
            row = writeAnswer(contentStream, row, questionWidth,
                    "# of Existing RecoverPoint Clusters in VMware SRM environment?",
                    int2String(replication.getExistingRecoverPointClustersNum()));
        }

        if (replication.isCelerraIP()) {
            row = writeAnswer(contentStream, row, questionWidth,
                    "# of New Unified File network servers using IP Replicator in a VMware SRM environment?",
                    int2String(replication.getNewUnifiedFileServersNum()));
            row = writeAnswer(contentStream, row, questionWidth,
                    "# of Existing Celerra File Servers using IP Replicator in VMware SRM environment?",
                    int2String(replication.getExistingCelerraFileServersNum()));
        }

        return row;
    }

    /**
     * Write the VMWare vblock information.
     *
     * @param contentStream
     *            The content stream
     * @param vblock
     *            The VMWare vblock information
     * @param row
     *            the start row number
     * @param questionWidth
     *            the question width
     * @return the new row number
     * @throws IOException
     *             if any IO error occurs
     * @since SRT Phase 3-1 - Implement VMWare Tab Assembly
     */
    private int writeVMWareVblock(PDPageContentStream contentStream, VMwareVblock vblock, int row,
            float questionWidth) throws IOException {
        if (vblock == null) {
            return row;
        }

        row++;
        row = writeFont(contentStream, "VCE VBLOCK", ++row, 0, true);

        row = writeQuestion(contentStream, "VCE VBlock Services", ++row, 0, false, 150f);

        List<String> vblockServices = new ArrayList<String>();
        if (vblock.isDesignImpl()) {
            vblockServices.add("Design and Implementation for Vblock");
        }
        if (vblock.isInfraTechAssessment()) {
            vblockServices.add("Technical Assessment for Vblock Infrastructure");
        }
        if (vblock.isInfraImpl()) {
            vblockServices.add("Implementation for Vblock Infrastructure");
        }
        row = writeOptions(contentStream, vblockServices, row, 150f, 1, 200f);

        float indent = 20f;

        VMwareVblockDesignImpl designImpl = vblock.getVblockDesignImpl();
        if (vblock.isDesignImpl() && designImpl != null) {
            row++;
            row = writeFont(contentStream, "DESIGN AND IMPLEMENTATION FOR VBLOCK", ++row, indent, true);
            row = writeAnswer(contentStream, row, questionWidth, indent,
                    "Include Vblock Partner LOE Efforts and Oversight?",
                    bool2String(designImpl.getIncludePartnerLOE()));

            if (designImpl.getIncludePartnerLOE() != null && designImpl.getIncludePartnerLOE()) {

                row = writeQuestion(contentStream, "Select Vblock Partners to include in LOE: (Cisco, VmWare)",
                        ++row, indent * 2, false, questionWidth - indent * 2);

                List<String> vblockPartners = new ArrayList<String>();
                if (designImpl.isCisco()) {
                    vblockPartners.add("Cisco");
                }
                if (designImpl.isVmware()) {
                    vblockPartners.add("Vmware");
                }
                row = writeOptions(contentStream, vblockPartners, row, questionWidth, 1, 200f);

                if (designImpl.isCisco()) {
                    row = writeAnswer(contentStream, row, questionWidth, indent * 2,
                            "# of hours for Vblock Cisco partner",
                            decimal2String(designImpl.getCiscoPartnerHours(), 2));
                }
                if (designImpl.isVmware()) {
                    row = writeAnswer(contentStream, row, questionWidth, indent * 2,
                            "# of hours for Vblock VMware partner",
                            decimal2String(designImpl.getVmwarePartnerHours(), 2));
                }
            }

            row = writeAnswer(contentStream, row, questionWidth, indent,
                    "Include Unified File Options?",
                    bool2String(designImpl.getIncludeUnifiedFileOptions()));
            row = writeAnswer(contentStream, row, questionWidth, indent,
                    "Include Ionix UIM?",
                    bool2String(designImpl.getIncludeIonixUIM()));

            row = writeQuestion(contentStream, "Select the Vblock type(s) to implement",
                    ++row, indent, false, questionWidth - indent);

            List<String> vblockTypes = new ArrayList<String>();
            if (designImpl.isType1()) {
                vblockTypes.add("Type1");
            }
            if (designImpl.isType2()) {
                vblockTypes.add("Type2");
            }
            row = writeOptions(contentStream, vblockTypes, row, questionWidth, 2, 50f);

            if (designImpl.isType1()) {
                row = writeAnswer(contentStream, row, questionWidth, indent,
                        "# of Type 1 Vblocks (VNX Block)",
                        int2String(designImpl.getType1VblocksNum()));
                row = writeAnswer(contentStream, row, questionWidth, indent,
                        "# of Type 1 LUNs (estimate)",
                        int2String(designImpl.getType1LUNsNum()));
                row = writeAnswer(contentStream, row, questionWidth, indent,
                        "# of Type 1 Vsphere Servers",
                        int2String(designImpl.getType1VsphereServersNum()));
            }

            if (designImpl.isType2()) {
                row = writeAnswer(contentStream, row, questionWidth, indent,
                        "# of Type 2 Vblocks (VNX Block)",
                        int2String(designImpl.getType2VblocksNum()));
                row = writeAnswer(contentStream, row, questionWidth, indent,
                        "# of Type 2 LUNs (estimate)",
                        int2String(designImpl.getType2LUNsNum()));
                row = writeAnswer(contentStream, row, questionWidth, indent,
                        "# of Type 2 Vsphere Servers",
                        int2String(designImpl.getType2VsphereServersNum()));
            }

            if (designImpl.getIncludeUnifiedFileOptions() != null && designImpl.getIncludeUnifiedFileOptions()) {
                row = writeAnswer(contentStream, row, questionWidth, indent,
                        "# of Unified File Type 1 (VG2)",
                        int2String(designImpl.getUnifiedFileTypeVG2Num()));
                row = writeAnswer(contentStream, row, questionWidth, indent,
                        "# of Unified File Type 2 (VG8)",
                        int2String(designImpl.getUnifiedFileTypeVG8Num()));
            }
        }

        VMwareVblockInfraImpl infraImpl = vblock.getVblockInfraImpl();
        if (vblock.isInfraImpl() && infraImpl != null) {
            row++;
            row = writeFont(contentStream, "IMPLEMENTATION FOR VBLOCK INFRASTRUCTURE", ++row, indent, true);
            row = writeAnswer(contentStream, row, questionWidth, indent,
                    "# of Vblock 300 Series to be installed",
                    int2String(infraImpl.getVblock300SeriesNum()));
            row = writeAnswer(contentStream, row, questionWidth, indent,
                    "# of Vblock 700 Series to be installed",
                    int2String(infraImpl.getVblock700SeriesNum()));
        }

        VMwareVblockInfraTechAssessment tech = vblock.getVblockInfraTechAssessment();
        if (vblock.isInfraTechAssessment() && tech != null) {
            row++;
            row = writeFont(contentStream, "TECHNICAL ASSESSMENT FOR VBLOCK INFRASTRUCTURE", ++row, indent, true);
            row = writeAnswer(contentStream, row, questionWidth, indent,
                    "# of sites to be Assessed",
                    int2String(tech.getAssessedSitesNum()));
            row = writeAnswer(contentStream, row, questionWidth, indent,
                    "# of Servers identified for VMWare consolidation",
                    int2String(tech.getIdentifiedServersNum()));
        }

        return row;
    }

    /**
     * Write the VMWare converter information.
     *
     * @param contentStream
     *            The content stream
     * @param converter
     *            The VMWare converter information
     * @param row
     *            the start row number
     * @param questionWidth
     *            the question width
     * @return the new row number
     * @throws IOException
     *             if any IO error occurs
     * @since SRT Phase 3-1 - Implement VMWare Tab Assembly
     */
    private int writeVMWareConverter(PDPageContentStream contentStream, VMwareConverter converter, int row,
            float questionWidth) throws IOException {
        if (converter == null) {
            return row;
        }

        row++;
        row = writeFont(contentStream, "VMWARE CONVERTER", ++row, 0, true);

        float indent = 20f;

        row = writeAnswer(contentStream, row, questionWidth, indent,
                "Will a migration be performed with VMware Converter?",
                bool2String(converter.getMigrationPerformed()));
        row = writeAnswer(contentStream, row, questionWidth, indent,
                "Include VMware Converter \"JumpStart\" workshops?",
                bool2String(converter.getIncludeJumpStartWorkshops()));
        row = writeAnswer(contentStream, row, questionWidth, indent,
                "# of VMware Converter Installs",
                int2String(converter.getInstallsNum()));
        row = writeAnswer(contentStream, row, questionWidth, indent, "# of Servers to P2V-V2V-B2V",
            int2String(converter.getServersNum()));
        row = writeAnswer(contentStream, row, questionWidth, indent,
            "# of additional hours needed for P2V, V2V and B2V (To be determined by Field)",
            decimal2String(converter.getAdditionalHours(), 2));
        row = writeAnswer(contentStream, row, questionWidth, indent,
                "# of billable hours per STR that an Implementation Specialist will monitor the"
                + " replication or migration activity",
                decimal2String(converter.getBillableHoursPerSTR(), 2));
        row = writeAnswer(contentStream, row, questionWidth, indent,
                "# of billable hours for additional testing to be done by an Implementation Specialist",
                decimal2String(converter.getBillableHoursForTesting(), 2));

        return row;
    }

    /**
     * Write the VMWare SvMotion information.
     *
     * @param contentStream
     *            The content stream
     * @param svMotion
     *            The VMWare SvMotion information
     * @param row
     *            the start row number
     * @param questionWidth
     *            the question width
     * @return the new row number
     * @throws IOException
     *             if any IO error occurs
     * @since SRT Phase 3-1 - Implement VMWare Tab Assembly
     */
    private int writeVMWareSvMotion(PDPageContentStream contentStream, VMwareSvMotion svMotion, int row,
            float questionWidth) throws IOException {
        if (svMotion == null) {
            return row;
        }

        row++;
        row = writeFont(contentStream, "VMWARE SVMOTION", ++row, 0, true);

        float indent = 20f;

        row = writeAnswer(contentStream, row, questionWidth, indent,
                "Include VMware Virtual Infrastructure 3.5 as part of this storage migration (vCenter 2.5)?",
                bool2String(svMotion.getIncludeVirtualInfra35()));
        row = writeAnswer(contentStream, row, questionWidth, indent,
                "# of VMware Virtual Machines to Storage vMotion",
                int2String(svMotion.getVirtualMachinesNum()));
        row = writeAnswer(contentStream, row, questionWidth, indent,
                "# of additional hours needed for Storage vMotion (To be determined by Field)",
                decimal2String(svMotion.getAdditionalHours(), 2));

        return row;
    }

    /**
     * Write the VMWare view information.
     *
     * @param contentStream
     *            The content stream
     * @param view
     *            The VMWare view information
     * @param row
     *            the start row number
     * @param questionWidth
     *            the question width
     * @return the new row number
     * @throws IOException
     *             if any IO error occurs
     * @since SRT Phase 3-1 - Implement VMWare Tab Assembly
     */
    private int writeVMWareView(PDPageContentStream contentStream, VMwareView view, int row,
            float questionWidth) throws IOException {
        if (view == null) {
            return row;
        }

        row++;
        row = writeFont(contentStream, "VMWARE VIEW", ++row, 0, true);

        row = writeQuestion(contentStream, "Vmware View Services", ++row, 0, false, 150f);

        List<String> viewServices = new ArrayList<String>();
        if (view.isDesign()) {
            viewServices.add("Design");
        }
        if (view.isImpl()) {
            viewServices.add("Implementation");
        }
        row = writeOptions(contentStream, viewServices, row, 150f, 2, 70f);

        float indent = 20f;

        VMwareViewDesign design = view.getViewDesign();
        if (view.isDesign() && design != null) {
            row++;
            row = writeFont(contentStream, "DESIGN FOR VMWARE VIEW", ++row, indent, true);
            row = writeAnswer(contentStream, row, questionWidth, indent,
                    "Include Microsoft SQL Databases?",
                    bool2String(design.getIncludeMSSQL()));
            row = writeAnswer(contentStream, row, questionWidth, indent,
                    "Include Oracle Databases?",
                    bool2String(design.getIncludeOracle()));
            row = writeAnswer(contentStream, row, questionWidth, indent,
                    "# of existing ESX/ESXi Servers",
                    int2String(design.getEsxServersNum()));
            row = writeAnswer(contentStream, row, questionWidth, indent,
                    "# of existing VirtualCenter installations",
                    int2String(design.getVirtualCenterInstallationsNum()));
            row = writeAnswer(contentStream, row, questionWidth, indent,
                    "# of VMware View Automated Desktop Pools",
                    int2String(design.getAutomatedDesktopPoolsNum()));
            row = writeAnswer(contentStream, row, questionWidth, indent,
                    "# of VMware View Manual Desktop Pools",
                    int2String(design.getManualDesktopPoolsNum()));
            row = writeAnswer(contentStream, row, questionWidth, indent,
                    "# of VMware View Manager (Standard) Connection Servers",
                    int2String(design.getManagerConnectionServersNum()));
            row = writeAnswer(contentStream, row, questionWidth, indent,
                    "# of VMware View Manager Replica Servers",
                    int2String(design.getManagerReplicaServersNum()));
            row = writeAnswer(contentStream, row, questionWidth, indent,
                    "# of VMware View Manager Pods",
                    int2String(design.getManagerPodsNum()));
            row = writeAnswer(contentStream, row, questionWidth, indent,
                    "# of VMware View Manager Partitions",
                    int2String(design.getManagerPartitionsNum()));
            row = writeAnswer(contentStream, row, questionWidth, indent,
                    "# of Desktop Profiles to Baseline and Document in the Configuration Guide",
                    int2String(design.getDesktopProfilesNum()));
            row = writeAnswer(contentStream, row, questionWidth, indent,
                    "# of Application Profiles to Baseline and Document in the Configuration Guide",
                    int2String(design.getApplicationProfilesNum()));
            row = writeAnswer(contentStream, row, questionWidth, indent,
                    "# of VMware View Virtual Desktops Per ESX/ESXi Host",
                    int2String(design.getVirtualDesktopsPerESXHostNum()));
            row = writeAnswer(contentStream, row, questionWidth, indent,
                    "# of VMware View Composer Instances",
                    int2String(design.getComposerInstancesNum()));

            if (design.getIncludeMSSQL() != null && design.getIncludeMSSQL()) {
                row = writeAnswer(contentStream, row, questionWidth, indent,
                        "# of Micrsoft SQL Databases to Configure",
                        int2String(design.getSqlDatabasesNum()));
            }
            if (design.getIncludeOracle() != null && design.getIncludeOracle()) {
                row = writeAnswer(contentStream, row, questionWidth, indent,
                        "# of Oracle Databases to Configure",
                        int2String(design.getOracleDatabasesNum()));
            }
        }

        VMwareViewImpl impl = view.getViewImpl();
        if (view.isImpl() && impl != null) {
            row++;
            row = writeFont(contentStream, "IMPLEMENTATION FOR VMWARE VIEW", ++row, indent, true);
            row = writeAnswer(contentStream, row, questionWidth, indent,
                    "Include Microsoft SQL Databases?",
                    bool2String(impl.getIncludeMSSQL()));
            row = writeAnswer(contentStream, row, questionWidth, indent,
                    "Include Oracle Databases?",
                    bool2String(impl.getIncludeOracle()));

            row = writeAnswer(contentStream, row, questionWidth, indent,
                    "# of VMware View Manager (Standard) Connection Servers",
                    int2String(impl.getManagerConnectionServersNum()));
            row = writeAnswer(contentStream, row, questionWidth, indent,
                    "# of VMware View Composer Instances",
                    int2String(impl.getComposerInstancesNum()));
            row = writeAnswer(contentStream, row, questionWidth, indent,
                    "# of existing VirtualCenter installations",
                    int2String(impl.getVirtualCenterInstallationsNum()));
            row = writeAnswer(contentStream, row, questionWidth, indent,
                    "# of VMware View Manager Replica Servers",
                    int2String(impl.getManagerReplicaServersNum()));
            row = writeAnswer(contentStream, row, questionWidth, indent,
                    "# of VMware View Automated Desktop Pools",
                    int2String(impl.getAutomatedDesktopPoolsNum()));
            row = writeAnswer(contentStream, row, questionWidth, indent,
                    "# of VMware View Manual Desktop Pools",
                    int2String(impl.getManualDesktopPoolsNum()));
            row = writeAnswer(contentStream, row, questionWidth, indent,
                    "# of existing ESX/ESXi Servers",
                    int2String(impl.getEsxServersNum()));
            row = writeAnswer(contentStream, row, questionWidth, indent,
                    "# of billable hours for additional testing to be done by an IS",
                    decimal2String(impl.getBillableHoursForTesting(), 2));

            if (impl.getIncludeMSSQL() != null && impl.getIncludeMSSQL()) {
                row = writeAnswer(contentStream, row, questionWidth, indent,
                        "# of Micrsoft SQL Databases to Configure",
                        int2String(impl.getSqlDatabasesNum()));
            }
            if (impl.getIncludeOracle() != null && impl.getIncludeOracle()) {
                row = writeAnswer(contentStream, row, questionWidth, indent,
                        "# of Oracle Databases to Configure",
                        int2String(impl.getOracleDatabasesNum()));
            }
        }

        return row;
    }

    /**
     * Write the VMWare virtual infrastructure information.
     *
     * @param contentStream
     *            The content stream
     * @param virtualInfra
     *            The VMWare virtual infrastructure information
     * @param row
     *            the start row number
     * @param questionWidth
     *            the question width
     * @return the new row number
     * @throws IOException
     *             if any IO error occurs
     * @since SRT Phase 3-1 - Implement VMWare Tab Assembly
     */
    private int writeVMWareVirtualInfra(PDPageContentStream contentStream, VMwareVirtualInfra virtualInfra, int row,
            float questionWidth) throws IOException {
        if (virtualInfra == null) {
            return row;
        }

        row++;
        row = writeFont(contentStream, "VMWARE VIRTUAL INFRASTRUCTURE", ++row, 0, true);

        float indent = 20f;

        row = writeQuestion(contentStream, "Virtual Infrastructure Services", ++row, indent, false, 150f - indent);

        List<String> virtualInfraServices = new ArrayList<String>();
        if (virtualInfra.isServerStorageDesignService()) {
            virtualInfraServices.add("Design for Server and Storage Virtualization");
        }
        if (virtualInfra.isInfraImplService()) {
            virtualInfraServices.add("Implementation for Virtual Infrastructure");
        }
        if (virtualInfra.isDesignImplJumpStartService()) {
            virtualInfraServices.add("Virtual Infrastructure Design and Implementation with Jumpstart Workshop");
        }
        if (virtualInfra.isDesignImplService()) {
            virtualInfraServices.add("Virtual Infrastructure Design and Implementation");
        }
        if (virtualInfra.isJumpStartOnlyService()) {
            virtualInfraServices.add("Virtual Infrastructure Jumpstart Workshop Only");
        }
        row = writeOptions(contentStream, virtualInfraServices, row, 150f, 1, 200f);

        VMwareVirtualInfraServerStorageDesign ssd = virtualInfra.getServerStorageDesign();
        if (virtualInfra.isServerStorageDesignService() && ssd != null) {
            row = writeAnswer(contentStream, row, questionWidth, indent,
                    "# of storage configuration varieties for VMWare",
                    int2String(ssd.getStorageConfigVarietiesNum()));
            row = writeAnswer(contentStream, row, questionWidth, indent,
                    "# of ESX hosts proposed by CapacityPlanner",
                    int2String(ssd.getEsxHostsNum()));
            row = writeAnswer(contentStream, row, questionWidth, indent,
                    "# of servers identified for VMWare consolidation",
                    int2String(ssd.getIdentifiedServersNum()));
            row = writeAnswer(contentStream, row, questionWidth, indent,
                    "Include Raw Disk Mapping (RDM)?",
                    bool2String(ssd.getIncludeRDM()));
        }

        VMwareVirtualInfraImpl impl = virtualInfra.getInfraImpl();
        if (virtualInfra.isInfraImplService() && impl != null) {
            row = writeAnswer(contentStream, row, questionWidth, indent,
                    "# of VMware vCenter servers to install (minimum of one)",
                    int2String(impl.getVcenterServersNum()));
            row = writeAnswer(contentStream, row, questionWidth, indent,
                    "# of VMware ESXi servers to install",
                    int2String(impl.getEsxiServersNum()));
            row = writeAnswer(contentStream, row, questionWidth, indent,
                    "# of VMware ESX/ESXi Clusters",
                    int2String(impl.getEsxiClustersNum()));
        }

        VMwareVirtualInfraDesignImplJumpStart jumpStart = virtualInfra.getDesignImplJumpStart();
        if (virtualInfra.isDesignImplJumpStartService() && jumpStart != null) {
            row = writeAnswer(contentStream, row, questionWidth, indent,
                    "# of VMware vCenter servers to install (minimum of one)",
                    int2String(jumpStart.getVcenterServersNum()));
            row = writeAnswer(contentStream, row, questionWidth, indent,
                    "# of VMware ESX clusters to create (minimum of two)",
                    int2String(jumpStart.getEsxClustersNum()));
            row = writeAnswer(contentStream, row, questionWidth, indent,
                    "# of VMware ESX servers to install (minimum of ten)",
                    int2String(jumpStart.getEsxServersNum()));
            row = writeAnswer(contentStream, row, questionWidth, indent,
                    "# of billable hours for additional testing to be done by an IS",
                    decimal2String(jumpStart.getBillableHoursForTesting(), 2));
        }

        VMwareVirtualInfraDesignImpl designImpl = virtualInfra.getDesignImpl();
        if (virtualInfra.isDesignImplService() && designImpl != null) {
            row = writeAnswer(contentStream, row, questionWidth, indent,
                    "# of VMware vCenter servers to install (minimum of one)",
                    int2String(designImpl.getVcenterServersNum()));
            row = writeAnswer(contentStream, row, questionWidth, indent,
                    "# of VMware ESX clusters to create (minimum of two)",
                    int2String(designImpl.getEsxClustersNum()));
            row = writeAnswer(contentStream, row, questionWidth, indent,
                    "# of VMware ESX servers to install (minimum of ten)",
                    int2String(designImpl.getEsxServersNum()));
        }

        return row;
    }

    /**
     * Write the VMWare vSphere information.
     *
     * @param contentStream
     *            The content stream
     * @param vsphere
     *            The VMWare vSphere information
     * @param row
     *            the start row number
     * @param questionWidth
     *            the question width
     * @return the new row number
     * @throws IOException
     *             if any IO error occurs
     * @since SRT Phase 3-1 - Implement VMWare Tab Assembly
     */
    private int writeVMWareVSphere(PDPageContentStream contentStream, VMwareVSphere vsphere, int row,
            float questionWidth) throws IOException {
        if (vsphere == null) {
            return row;
        }

        row++;
        row = writeFont(contentStream, "VMWARE VSPHERE", ++row, 0, true);

        float indent = 20f;

        row = writeAnswer(contentStream, row, questionWidth, indent,
                "Include VMware vSphere Upgrades?",
                bool2String(vsphere.getIncludeUpgrades()));
        row = writeAnswer(contentStream, row, questionWidth, indent,
                "Include VMware vSphere \"JumpStart\" workshops?",
                bool2String(vsphere.getIncludeJumpStartWorkshops()));
        row = writeAnswer(contentStream, row, questionWidth, indent,
                "# of billable hours for additional testing to be done by an IS",
                decimal2String(vsphere.getBillableHoursForTesting(), 2));

        if (vsphere.getIncludeUpgrades() != null && vsphere.getIncludeUpgrades()) {
            row = writeAnswer(contentStream, row, questionWidth, indent,
                    "# of VMware vCenter 2.x Instances to Upgrade to vCenter 4.x",
                    int2String(vsphere.getVcenterInstancesNum()));
            row = writeAnswer(contentStream, row, questionWidth, indent,
                    "# of VMware ESX 3.x Servers to Upgrade to ESX 4.x Server",
                    int2String(vsphere.getEsxServersNum()));
        }

        if (vsphere.getIncludeJumpStartWorkshops() != null && vsphere.getIncludeJumpStartWorkshops()) {
            row = writeAnswer(contentStream, row, questionWidth, indent,
                    "# of VMware vSphere \"JumpStart\" workshops to Deliver",
                    int2String(vsphere.getJumpStartWorkshopsNum()));
        }

        return row;
    }

    /**
     * Write VMWare request data.
     *
     * @param contentStream
     *            the stream
     * @param vmwareRequestData
     *            the vmwareRequestData
     * @param row
     *            the start row number
     * @param page
     *            the PDF page
     * @return the new row number
     * @throws IOException
     *             if any IO error occurs
     * @since SRT Phase 3-1 - Implement VMWare Tab Assembly
     */
    private int writeVMWareRequestData(PDPageContentStream contentStream, VMwareRequestData vmwareRequestData,
            int row, PDPage page) throws IOException {
        float questionWidth = 150f;
        row = writeFont(contentStream, "Services & Activities - VMWare", ++row, 0, true);

        // General information
        row++;

        row = writeFont(contentStream, "GENERAL INFORMATION", ++row, 0, true);

        row = writeAnswer(contentStream, row, questionWidth,
                "General Comments",
                trimToEmpty(vmwareRequestData.getGeneralComments()));

        // Services scope
        VMwareServicesScope servicesScope = vmwareRequestData.getServicesScope();
        row++;
        row = writeFont(contentStream, "SERVICES TO BE SCOPED IN THIS BOE", ++row, 0, true);
        List<String> options = getVMWareServices(servicesScope);
        row = writeOptions(contentStream, options, ++row, 0, 1, 200f);

        questionWidth = 370f;

        if (servicesScope != null) {
            if (servicesScope.isAssessment()) {
                row = writeVMWareAssessment(contentStream, vmwareRequestData.getAssessment(), row, questionWidth);
            }
            if (servicesScope.isBackupRecovery()) {
                row = writeVMWareBackupRecovery(contentStream, vmwareRequestData.getBackupRecovery(), row,
                        questionWidth);
            }
            if (servicesScope.isHealthChecks()) {
                row = writeVMWareHealthChecks(contentStream, vmwareRequestData.getHealthChecks(), row,
                        questionWidth);
            }
            if (servicesScope.isTcoAssessment()) {
                row = writeVMWareTCOAssessment(contentStream, vmwareRequestData.getTcoAssessment(), row,
                        questionWidth);
            }
            if (servicesScope.isReplication()) {
                row = writeVMWareReplication(contentStream, vmwareRequestData.getReplication(), row, questionWidth);
            }
            if (servicesScope.isVceVblock()) {
                row = writeVMWareVblock(contentStream, vmwareRequestData.getVceVblock(), row, questionWidth);
            }
            if (servicesScope.isConverter()) {
                row = writeVMWareConverter(contentStream, vmwareRequestData.getConverter(), row, questionWidth);
            }
            if (servicesScope.isSvMotion()) {
                row = writeVMWareSvMotion(contentStream, vmwareRequestData.getSvMotion(), row, questionWidth);
            }
            if (servicesScope.isView()) {
                row = writeVMWareView(contentStream, vmwareRequestData.getView(), row, questionWidth);
            }
            if (servicesScope.isVirtualInfrastructure()) {
                row = writeVMWareVirtualInfra(contentStream, vmwareRequestData.getVirtualInfrastructure(), row,
                        questionWidth);
            }
            if (servicesScope.isVsphere()) {
                row = writeVMWareVSphere(contentStream, vmwareRequestData.getVsphere(), row, questionWidth);
            }
        }

        return row;
    }

    /**
     * Get VMWare services in scope.
     *
     * @param servicesScope
     *            the VMWare services scope
     * @return VMWare services in scope.
     * @since SRT Phase 3-1 - Implement VMWare Tab Assembly
     */
    private static List<String> getVMWareServices(VMwareServicesScope servicesScope) {

        List<String> options = new ArrayList<String>();
        if (servicesScope != null) {
            if (servicesScope.isAssessment()) {
                options.add("Assessment");
            }
            if (servicesScope.isBackupRecovery()) {
                options.add("Backup and Recovery");
            }
            if (servicesScope.isHealthChecks()) {
                options.add("Health Checks");
            }
            if (servicesScope.isReplication()) {
                options.add("Replication");
            }
            if (servicesScope.isTcoAssessment()) {
                options.add("TCO Assessment for Virtual Infrastructure");
            }
            if (servicesScope.isVceVblock()) {
                options.add("VCE Vblock");
            }
            if (servicesScope.isConverter()) {
                options.add("Vmware Converter");
            }
            if (servicesScope.isSvMotion()) {
                options.add("Vmware SvMotion");
            }
            if (servicesScope.isView()) {
                options.add("Vmware View");
            }
            if (servicesScope.isVirtualInfrastructure()) {
                options.add("Vmware Virtual Infrastructure");
            }
            if (servicesScope.isVsphere()) {
                options.add("Vmware Vsphere");
            }
        }
        return options;
    }

    /**
     * Get total knowledge transfer hours for DPAD request data.
     *
     * @param dpadRequestData
     *            the dpadRequestData
     * @return total knowledge transfer hours for DPAD request data.
     */
    private BigDecimal getTotalKnowledgeTransferHoursDPAD(DPADRequestData dpadRequestData) {
        BigDecimal total = new BigDecimal(0);
        DPADServicesScope servicesScope = dpadRequestData.getServicesScope();

        if (servicesScope != null) {
            if (servicesScope.isAvamar() && dpadRequestData.getAvamar() != null
                    && dpadRequestData.getAvamar().getKnowledgeTransferHours() != null) {
                total = total.add(dpadRequestData.getAvamar().getKnowledgeTransferHours());
            }
            if (servicesScope.isEdl() && dpadRequestData.getEdl() != null
                    && dpadRequestData.getEdl().getKnowledgeTransferHours() != null) {
                total = total.add(dpadRequestData.getEdl().getKnowledgeTransferHours());
            }
            if (servicesScope.isDataDomain() && dpadRequestData.getDataDomain() != null
                    && dpadRequestData.getDataDomain().getKnowledgeTransferHours() != null) {
                total = total.add(dpadRequestData.getDataDomain().getKnowledgeTransferHours());
            }
            if (servicesScope.isDpa() && dpadRequestData.getDpa() != null
                    && dpadRequestData.getDpa().getKnowledgeTransferHours() != null) {
                total = total.add(dpadRequestData.getDpa().getKnowledgeTransferHours());
            }
            if (servicesScope.isNetworker() && dpadRequestData.getNetworker() != null
                    && dpadRequestData.getNetworker().getKnowledgeTransferHours() != null) {
                total = total.add(dpadRequestData.getNetworker().getKnowledgeTransferHours());
            }
        }

        return total;
    }

    /**
     * Write DPAD request data.
     *
     * @param contentStream
     *            the stream
     * @param dpadRequestData
     *            the dpadRequestData
     * @param row
     *            the start row number
     * @param page
     *            the PDF page
     * @return the new row number
     * @throws IOException
     *             if any IO error occurs
     * @since SRT Phase 3-5 - BRS Tabs Part 1 Assembly
     */
    private int writeDPADRequestData(PDPageContentStream contentStream, DPADRequestData dpadRequestData,
            int row, PDPage page) throws IOException {
        float questionWidth = 300f;
        row = writeFont(contentStream, "Services & Activities - DPAD", ++row, 0, true);

        // General information
        row++;

        row = writeFont(contentStream, "GENERAL INFORMATION", ++row, 0, true);

        row = writeAnswer(contentStream, row, questionWidth,
                "# of sites involved?",
                trimToEmpty(dpadRequestData.getSitesInvolved()));
        row = writeAnswer(contentStream, row, questionWidth,
                "# of Hours of Knowledge Transfer",
                decimal2String(getTotalKnowledgeTransferHoursDPAD(dpadRequestData), 2));
        row = writeAnswer(contentStream, row, questionWidth,
                "General Comments",
                trimToEmpty(dpadRequestData.getGeneralComments()));

        // Services scope
        DPADServicesScope servicesScope = dpadRequestData.getServicesScope();
        row++;
        row = writeFont(contentStream, "SERVICES TO BE SCOPED IN THIS BOE", ++row, 0, true);
        List<String> options = getDPADServices(servicesScope);
        row = writeOptions(contentStream, options, ++row, 0, 1, 200f);

        if (servicesScope != null) {
            if (servicesScope.isAvamar()) {
                row = writeAvamar(contentStream, dpadRequestData.getAvamar(), row, questionWidth);
            }
            if (servicesScope.isDataDomain()) {
                row = writeDataDomain(contentStream, page, dpadRequestData.getDataDomain(), row, questionWidth);
            }
            if (servicesScope.isEdl()) {
                row = writeEDL(contentStream, dpadRequestData.getEdl(), row, questionWidth);
            }
            if (servicesScope.isDpa()) {
                row = writeDPA(contentStream, page, dpadRequestData.getDpa(), row, questionWidth);
            }
            if (servicesScope.isNetworker()) {
                row = writeNetworker(contentStream, page, dpadRequestData.getNetworker(), row, questionWidth);
            }
            if (servicesScope.isRecoverPoint()) {
                row = writeRecoverPoint(contentStream, page, dpadRequestData.getRecoverPoint(), row, questionWidth);
            }
            if (servicesScope.isMozy()) {
                row = writeMozy(contentStream, dpadRequestData.getMozy(), row, questionWidth);
            }
        }
        return row;
    }

    /**
     * <p>Writes the content of specified Mozy tab to specified PDF document.</p>
     *
     * @param contentStream a <code>PDPageContentStream</code> to write content to.
     * @param mozy a <code>Mozy</code> object providing the content of Mozy tab.
     * @param row an <code>int</code> providing the current row number to start writing from.
     * @param questionWidth a <code>float</code> providing the with of the column.
     * @return an <code>int</code> providing the new row number.
     * @throws IOException if an I/O error occurs.
     * @since 2.10
     */
    private int writeMozy(PDPageContentStream contentStream, Mozy mozy, int row, float questionWidth)
        throws IOException {
        if (mozy == null) {
            return row;
        }

        row++;
        row = writeFont(contentStream, "MOZY SERVICES", ++row, 0, true);

        List<String> services = new ArrayList<String>();
        if (mozy.getMozyCustom()) {
            services.add("Mozy Custom");
        }
        if (mozy.getMozyOEMBranding()) {
            services.add("Mozy OEM Branding");
        }
        if (mozy.getMozyOutTasking()) {
            services.add("Mozy Out Tasking");
        }
        row = writeOptions(contentStream, services, row, questionWidth, 1, 120f);

        if (mozy.getMozyCustom()) {
            row = writeMozyCustom(contentStream, mozy.getCustom(), row, questionWidth);
        }
        if (mozy.getMozyOEMBranding()) {
            row = writeMozyOEMBranding(contentStream, mozy.getOemBranding(), row, questionWidth);
        }
        if (mozy.getMozyOutTasking()) {
            row = writeMozyOutTasking(contentStream, mozy.getOutTasking(), row, questionWidth);
        }

        return row;

    }

    /**
     * <p>Writes the content of specified Mozy Custom section of Mozy tab to specified PDF document.</p>
     *
     * @param contentStream a <code>PDPageContentStream</code> to write content to.
     * @param custom a <code>MozyCustom</code> object providing the content of Mozy Custom section of Mozy tab.
     * @param row an <code>int</code> providing the current row number to start writing from.
     * @param questionWidth a <code>float</code> providing the with of the column.
     * @return an <code>int</code> providing the new row number.
     * @throws IOException if an I/O error occurs.
     * @since 2.10
     */
    private int writeMozyCustom(PDPageContentStream contentStream, MozyCustom custom, int row, float questionWidth)
        throws IOException {
        if (custom == null) {
            return row;
        }

        row++;
        row = writeFont(contentStream, "MOZY CUSTOM", ++row, 0, true);

        List<String> services = new ArrayList<String>();
        if (custom.getAccountSetupAndStructureConfiguration()) {
            services.add("Account Setup and Structure Configuration");
        }
        if (custom.getDevelopBetaPlanAndAssistWithRollout()) {
            services.add("Develop Beta Plan and Assist with Rollout\n");
        }
        if (custom.getSolutionsAssurance()) {
            services.add("Solutions Assurance");
        }
        if (custom.getAdministrationTraining()) {
            services.add("Administration Training\n");
        }
        if (custom.getBranding()) {
            services.add("Branding");
        }
        if (custom.getApiWorkshop()) {
            services.add("API Workshop");
        }
        if (custom.getFederatedIDConfiguration()) {
            services.add("Federated ID Configuration");
        }
        if (custom.getL1SupportTraining()) {
            services.add("L1 Support Training");
        }

        row = writeOptions(contentStream, services, row, questionWidth, 1, 120f);

        if (custom.getAccountSetupAndStructureConfiguration() || custom.getBranding() || custom.getApiWorkshop()
            || custom.getFederatedIDConfiguration()) {
            row = writeAnswer(contentStream, row, questionWidth, "# of hours for API Workshop Planning",
                decimal2String(custom.getHoursForAPIWorkshopPlanning(), 2));
        }
        if (custom.getDevelopBetaPlanAndAssistWithRollout()) {
            row = writeAnswer(contentStream, row, questionWidth, "# of Hours to assist with Pilot Roll-Ou",
                decimal2String(custom.getHoursToAssistWithPilotRollout(), 2));
        }
        if (custom.getAdministrationTraining()) {
            row = writeAnswer(contentStream, row, questionWidth, "# of Hours for Mozy Administration Training",
                decimal2String(custom.getHoursForAdministrationTraining(), 2));
        }
        if (custom.getBranding()) {
            row = writeAnswer(contentStream, row, questionWidth, "# of hours for Client Branding",
                decimal2String(custom.getHoursForClientBranding(), 2));
            row = writeAnswer(contentStream, row, questionWidth, "# of hours for Branding Admin Console",
                decimal2String(custom.getHoursForAdminConsoleBranding(), 2));
            row = writeAnswer(contentStream, row, questionWidth, "# of Hours for Web Access Branding",
                decimal2String(custom.getHoursForWebAccessBranding(), 2));
        }
        if (custom.getApiWorkshop()) {
            row = writeAnswer(contentStream, row, questionWidth, "# of Hours for Mozy API Workshop",
                decimal2String(custom.getHoursForAPIWorkshop(), 2));
        }
        if (custom.getL1SupportTraining()) {
            row = writeAnswer(contentStream, row, questionWidth, "# of L1 Support Training Hours",
                decimal2String(custom.getHoursForL1SupportTraining(), 2));
        }

        return row;
    }

    /**
     * <p>Writes the content of specified Mozy OEM Branding section of Mozy tab to specified PDF document.</p>
     *
     * @param contentStream a <code>PDPageContentStream</code> to write content to.
     * @param oemBranding a <code>MozyOEMBranding</code> object providing the content of Mozy OEM Branding section of
     * Mozy tab.
     * @param row an <code>int</code> providing the current row number to start writing from.
     * @param questionWidth a <code>float</code> providing the with of the column.
     * @return an <code>int</code> providing the new row number.
     * @throws IOException if an I/O error occurs.
     * @since 2.10
     */
    private int writeMozyOEMBranding(PDPageContentStream contentStream, MozyOEMBranding oemBranding, int row,
                                     float questionWidth) throws IOException {
        if (oemBranding == null) {
            return row;
        }

        row++;
        row = writeFont(contentStream, "MOZY OEM BRANDING", ++row, 0, true);

        row = writeAnswer(contentStream, row, questionWidth, "# of hours for Client Branding",
            decimal2String(oemBranding.getHoursForClientBranding(), 2));
        row = writeAnswer(contentStream, row, questionWidth, "# of Hours for Branding Admin Console",
            decimal2String(oemBranding.getHoursForBrandingAdminConsole(), 2));
        row = writeAnswer(contentStream, row, questionWidth, "# of Hours for Web Access Branding",
            decimal2String(oemBranding.getHoursForWebAccessBranding(), 2));

        return row;
    }

    /**
     * <p>Writes the content of specified Mozy Out Tasking section of Mozy tab to specified PDF document.</p>
     *
     * @param contentStream a <code>PDPageContentStream</code> to write content to.
     * @param outTasking a <code>MozyOutTasking</code> object providing the content of Mozy Out Tasking section of
     *        Mozy tab.
     * @param row an <code>int</code> providing the current row number to start writing from.
     * @param questionWidth a <code>float</code> providing the with of the column.
     * @return an <code>int</code> providing the new row number.
     * @throws IOException if an I/O error occurs.
     * @since 2.10
     */
    private int writeMozyOutTasking(PDPageContentStream contentStream, MozyOutTasking outTasking, int row,
                                    float questionWidth) throws IOException {
        if (outTasking == null) {
            return row;
        }

        row++;
        row = writeFont(contentStream, "MOZY OUT TASKING", ++row, 0, true);

        row = writeAnswer(contentStream, row, questionWidth, "Select Out Tasking Start Date",
            date2String(outTasking.getOutTaskingStartDate()));
        row = writeAnswer(contentStream, row, questionWidth, "# of Hours for Mozy Out-Tasking",
            decimal2String(outTasking.getHoursForMozyOutTasking(), 2));

        return row;
    }

    /**
     * Get DPAD services in scope.
     *
     * @param servicesScope
     *            the DPAD services scope
     * @return DPAD services in scope.
     * @since SRT Phase 3-5 - BRS Tabs Part 1 Assembly
     */
    private static List<String> getDPADServices(DPADServicesScope servicesScope) {

        List<String> options = new ArrayList<String>();
        if (servicesScope != null) {
            if (servicesScope.isAvamar()) {
                options.add("Avamar");
            }
            if (servicesScope.isDataDomain()) {
                options.add("Data Domain");
            }
            if (servicesScope.isDpa()) {
                options.add("Data Protection Advisor");
            }
            if (servicesScope.isEdl()) {
                options.add("EMC Disk Library");
            }
            if (servicesScope.isNetworker()) {
                options.add("Networker");
            }
            if (servicesScope.isDlm()) {
                options.add("DLM");
            }
            if (servicesScope.isRecoverPoint()) {
                options.add("RecoverPoint");
            }
            if (servicesScope.isMozy()) {
                options.add("Mozy");
            }
        }
        return options;
    }

    /**
     * <p>Gets Xtreme services in scope.</p>
     *
     * @param servicesScope the Xtreme services scope.
     * @return Xtreme services in scope.
     * @since 2.10
     */
    private static List<String> getXtremeServices(XtremeServices servicesScope) {

        List<String> options = new ArrayList<String>();
        if (servicesScope != null) {
            if (servicesScope.getDesignAndImplementation()) {
                options.add("XtremIO Design and Implementation");
            }
            if (servicesScope.getClusterExpansion()) {
                options.add("XtremIO Cluster Expansion");
            }
            if (servicesScope.getCache()) {
                options.add("XtremCache");
            }
            if (servicesScope.getSf()) {
                options.add("XtremSF");
            }
            if (servicesScope.getOracleLocalReplication()) {
                options.add("Oracle Local Replication for XtremIO");
            }
        }
        return options;
    }

    /**
     * Get Avamar services in scope.
     *
     * @param avamar
     *            the Avamar data
     * @return Avamar services in scope.
     * @since SRT Phase 3-5 - BRS Tabs Part 1 Assembly
     */
    private static List<String> getAvamarServices(Avamar avamar) {

        List<String> options = new ArrayList<String>();

        if (avamar != null) {
            if (avamar.isDesignImplService()) {
                options.add("Avamar Design & Implementation");
            }
            if (avamar.isTapeOutDesignImplService()) {
                options.add("Avamar Tape Out Design & Implementation");
            }
            if (avamar.isOperationalAssuranceService()) {
                options.add("Operational Assurance for Avamar");
            }
            if (avamar.isHealthCheckService()) {
                options.add("Health Check for Avamar");
            }
            if (avamar.isMigrationService()) {
                options.add("Migration for Avamar");
            }
            if (avamar.isIntegrationService()) {
                options.add("Intergration - Avamar Desktop-Laptop Pilot and Workshop");
            }
            if (avamar.isVcloudDirectorService()) {
                options.add("Implementation for Avamar for vCloud Director Plug-in");
            }
            if (avamar.getAdmeService()) {
                options.add("ADME");
            }
        }
        return options;
    }

    /**
     * Get Avamar deliver options in scope.
     *
     * @param avamar
     *            the Avamar data
     * @return Avamar deliver options in scope.
     * @since SRT Phase 3-5 - BRS Tabs Part 1 Assembly
     */
    private static List<String> getAvamarDeliverOptions(Avamar avamar) {

        List<String> options = new ArrayList<String>();

        if (avamar != null) {
            if (avamar.isDesignDeliverOption()) {
                options.add("Design");
            }
            if (avamar.isImplementationDeliverOption()) {
                options.add("Implementation");
            }
        }
        return options;
    }

    /**
     * Get Avamar plugins in scope.
     *
     * @param plugins
     *            the Avamar plugins data
     * @return Avamar plugins in scope.
     * @since SRT Phase 3-5 - BRS Tabs Part 1 Assembly
     */
    private static List<String> getAvamarPlugins(AvamarPlugins plugins) {

        List<String> options = new ArrayList<String>();

        if (plugins != null) {
            if (plugins.isExchange()) {
                options.add("Microsoft Exchange");
            }
            if (plugins.isSqlServer()) {
                options.add("Microsoft SQL Server");
            }
            if (plugins.isOracle()) {
                options.add("Oracle");
            }
            if (plugins.isDb2()) {
                options.add("DB2");
            }
            if (plugins.isSharepoint()) {
                options.add("Microsoft Sharepoint");
            }
            if (plugins.isLotusDomino()) {
                options.add("Lotus Domino");
            }
        }
        return options;
    }

    /**
     * Get Avamar options in scope.
     *
     * @param avaOpts
     *            the Avamar options data
     * @return Avamar options in scope.
     * @since SRT Phase 3-5 - BRS Tabs Part 1 Assembly
     */
    private static List<String> getAvamarOptions1(AvamarOptions avaOpts) {

        List<String> options = new ArrayList<String>();

        if (avaOpts != null) {
            if (avaOpts.isConfigureClients()) {
                options.add("Configure Avamar Clients");
            }
            if (avaOpts.isConfigureNDMP()) {
                options.add("Configure Avamar NDMP");
            }
            if (avaOpts.isConfigureAVF()) {
                options.add("Configure Avamar AvF");
            }
            if (avaOpts.isConfigureReplication()) {
                options.add("Configure Avamar Replication");
            }
            if (avaOpts.isVmwareIntegeration()) {
                options.add("VMware Integration");
            }
            if (avaOpts.isDataDomainIntegration()) {
                options.add("Data Domain Integration");
            }
        }
        return options;
    }

    /**
     * Get Avamar options in scope.
     *
     * @param avaOpts
     *            the Avamar options data
     * @return Avamar options in scope.
     * @since SRT Phase 3-5 - BRS Tabs Part 1 Assembly
     */
    private static List<String> getAvamarOptions2(AvamarOptions avaOpts) {

        List<String> options = new ArrayList<String>();

        if (avaOpts != null) {
            if (avaOpts.isConfigureDownloadServer()) {
                options.add("Configure Avamar Download Server");
            }
            if (avaOpts.isConfigureAdvancedNetwork()) {
                options.add("Configure Advanced Network Options");
            }
            if (avaOpts.isConfigureVCloudDirector()) {
                options.add("Configure Avamar for vCloud Director Plug-in");
            }
        }
        return options;
    }

    /**
     * Get Avamar NDMP node types in scope.
     *
     * @param ndmp
     *            the Avamar NDMP data
     * @return Avamar NDMP node types in scope.
     * @since SRT Phase 3-5 - BRS Tabs Part 1 Assembly
     */
    private static List<String> getAvamarNDMPNodeTypes(AvamarNDMP ndmp) {
        List<String> options = new ArrayList<String>();

        if (ndmp != null) {
            if (ndmp.isEmcCelerra()) {
                options.add("EMC Celerra");
            }
            if (ndmp.isNetworkAppliance()) {
                options.add("Network Appliance");
            }
            if (ndmp.isEmcIsilon()) {
                options.add("EMC Isilon");
            }
            if (ndmp.isEmcVnx()) {
                options.add("EMC VNX/VNXe");
            }
        }
        return options;
    }

    /**
     * Write the Avamar information.
     *
     * @param contentStream
     *            The content stream
     * @param avamar
     *            The Avamar information
     * @param row
     *            the start row number
     * @param questionWidth
     *            the question width
     * @return the new row number
     * @throws IOException
     *             if any IO error occurs
     * @since SRT Phase 3-5 - BRS Tabs Part 1 Assembly
     */
    private int writeAvamar(PDPageContentStream contentStream, Avamar avamar, int row, float questionWidth)
        throws IOException {
        if (avamar == null) {
            return row;
        }

        row++;
        row = writeFont(contentStream, "AVAMAR", ++row, 0, true);

        row = writeAnswer(contentStream, row, questionWidth,
                "# of Hours of Knowledge Transfer",
                decimal2String(avamar.getKnowledgeTransferHours(), 2));

        row = writeFont(contentStream, "Avamar Services", ++row, 0, false);
        row = writeOptions(contentStream, getAvamarServices(avamar), row, questionWidth, 1, 200f);

        String serverType = lookupEntity2String(avamar.getServerType());
        row = writeAnswer(contentStream, row, questionWidth,
                "Avamar Server Type", serverType);

        if (avamar.isDesignImplService() || avamar.isTapeOutDesignImplService()) {
            row = writeFont(contentStream, "Avamar Deliver Option", ++row, 0, false);
            row = writeOptions(contentStream, getAvamarDeliverOptions(avamar), row, questionWidth, 2, 70f);
        }

        // Avamar Design
        if (avamar.isDesignImplService() && avamar.isDesignDeliverOption()) {
            row = writeAvamarDesign(contentStream, avamar.getDesign(), serverType, row, questionWidth);
        }

        // Avamar Implementation
        if (avamar.isDesignImplService() && avamar.isImplementationDeliverOption()) {
            row = writeAvamarImplementation(contentStream, avamar.getImplementation(), serverType, row,
                    questionWidth);
        }

        // Avamar Design - Tape Out
        if (avamar.isTapeOutDesignImplService() && avamar.isDesignDeliverOption()) {
            row = writeAvamarTapeOutDesign(contentStream, avamar.getTapeOutDesign(), row, questionWidth);
        }

        // Avamar Implementation - Tape Out
        if (avamar.isTapeOutDesignImplService() && avamar.isImplementationDeliverOption()) {
            row = writeAvamarTapeOutImpl(contentStream, avamar.getTapeOutImplementation(), row, questionWidth);
        }

        // Operational Assurance
        if (avamar.isOperationalAssuranceService()) {
            row = writeAvamarOperationalAssurance(contentStream, avamar.getOperationalAssurance(), row,
                    questionWidth);
        }

        // Health Check
        if (avamar.isHealthCheckService()) {
            row = writeAvamarHealthCheck(contentStream, avamar.getHealthCheck(), row, questionWidth);
        }

        // Migration
        if (avamar.isMigrationService()) {
            row = writeAvamarMigration(contentStream, avamar.getMigration(), row, questionWidth);
        }

        // Avamar Integration Desktop Laptop Pilot and Workshop
        if (avamar.isIntegrationService()) {
            row = writeAvamarIntegration(contentStream, avamar.getIntegration(), row, questionWidth);
        }

        // Avamar ADME
        if (avamar.getAdmeService()) {
            row = writeAvamarADMEConfiguration(contentStream, avamar.getAdmeConfiguration(), row, questionWidth);
        }

        return row;
    }

    /**
     * Write the AvamarADMEConfiguration information.
     *
     * @param contentStream The content stream
     * @param admeConfiguration The AvamarIntegration information.
     * @param row the start row number.
     * @param questionWidth the question width.
     * @return the new row number.
     * @throws IOException if any IO error occurs.
     */
    private int writeAvamarADMEConfiguration(PDPageContentStream contentStream,
                                             AvamarADMEConfiguration admeConfiguration, int row, float questionWidth)
        throws IOException {
        if (admeConfiguration == null) {
            return row;
        }

        row++;
        row = writeFont(contentStream, "AVAMAR ADME SOFTWARE CONFIGURATION", ++row, 0, true);

        row = writeAnswer(contentStream, row, questionWidth,
            "Include ADMe Configuration for Cloud Extended Retention Path?",
            bool2String(admeConfiguration.getIncludeCloudExtendedRetentionPathConfig()));
        
        if (getBooleanValue(admeConfiguration.getIncludeCloudExtendedRetentionPathConfig())) {
            row = writeAnswer(contentStream, row, questionWidth, "# of Replication Pairs",
                int2String(admeConfiguration.getNumberOfReplicationPairs()));
            row = writeAnswer(contentStream, row, questionWidth, "# of ADMe Staging Servers",
                int2String(admeConfiguration.getNumberOfStagingServers()));
            row = writeAnswer(contentStream, row, questionWidth, "# of Cloud Extended Retention Paths",
                int2String(admeConfiguration.getNumberOfCloudExtendedRetentionPaths()));
        }

        return row;
    }

    /**
     * Write the AssessmentData information.
     *
     * @param contentStream The content stream
     * @param assessmentData The AssessmentData information.
     * @param row the start row number.
     * @return the new row number.
     * @throws IOException if any IO error occurs.
     * @since 2.24
     */
    private int writeAssessmentData(PDPageContentStream contentStream, AssessmentData assessmentData, int row)
        throws IOException {
        if (assessmentData == null) {
            return row;
        }

        float questionWidth = 300f;
        
        row++;
        
        row = writeFont(contentStream, "Services & Activities - Assessment", ++row, 0, true);

        row = writeAnswer(contentStream, row, questionWidth, "Select the Networking Service Template",
            lookupEntity2String(assessmentData.getNetworkingServiceTemplateType()));

        if (assessmentData.getNetworkingServiceTemplateType() != null 
            && assessmentData.getNetworkingServiceTemplateType().getId() == 2) {
            row = writeAnswer(contentStream, row, questionWidth,
                "Select the complexity of the customer's LAN Infrastructure",
                lookupEntity2String(assessmentData.getCustomerLANInfrastructureComplexityType()));
            row = writeAnswer(contentStream, row, questionWidth,
                "Select the number of Data Center Locations under analysis",
                lookupEntity2String(assessmentData.getNumberOfDataCenterLocations()));
            row = writeAnswer(contentStream, row, questionWidth, 
                "Select whether the Technical Assessment Results will be reviewed with the Project Sponsor",
                bool2String(assessmentData.getResultsViewableByProjectSponsor()));
        }

        return row;
    }

    /**
     * Write the ProtectPointData information.
     *
     * @param contentStream The content stream
     * @param protectPointData The ProtectPointData information.
     * @param row the start row number.
     * @return the new row number.
     * @throws IOException if any IO error occurs.
     * @since 2.24
     */
    private int writeProtectPointData(PDPageContentStream contentStream, ProtectPointData protectPointData, int row)
        throws IOException {
        if (protectPointData == null) {
            return row;
        }

        float questionWidth = 300f;

        row++;

        row = writeFont(contentStream, "Services & Activities - ProtectPoint", ++row, 0, true);

        row = writeAnswer(contentStream, row, questionWidth,
            "# of Data Domain appliances that are targeted for ProtectPoint backups?",
            int2String(protectPointData.getNumberOfDataDomainAppliancesForBackups()));
        row = writeAnswer(contentStream, row, questionWidth, "# of storage arrays targeted for ProtectPoint backups?",
            int2String(protectPointData.getNumberOfStorageArraysForBackups()));
        row = writeAnswer(contentStream, row, questionWidth, "# of ProtectPoint application hosts?",
            int2String(protectPointData.getNumberOfApplicationHosts()));
        row = writeAnswer(contentStream, row, questionWidth, "# of ProtectPoint backup config files?",
            int2String(protectPointData.getNumberOfBackupConfigFiles()));
        row = writeAnswer(contentStream, row, questionWidth, "# of database instances to backup?",
            int2String(protectPointData.getNumberOfDatabaseInstancesToBackup()));
        RecoveryLevelType recoveryLevelType = protectPointData.getRecoveryLevelType();
        row = writeAnswer(contentStream, row, questionWidth, "Select the type(s) of recovery levels to be performed",
            lookupEntity2String(recoveryLevelType));

        if (recoveryLevelType != null) {
            if (recoveryLevelType.getId() == 1) {
                row = writeAnswer(contentStream, row, questionWidth, "# of database instances for Object Level Recovery?",
                    int2String(protectPointData.getNumberOfDatabaseInstancesForObjectLevelRecovery()));
            } else if (recoveryLevelType.getId() == 2) {
                row = writeAnswer(contentStream, row, questionWidth, "# of database instances for Full LUN Recovery?",
                    int2String(protectPointData.getNumberOfDatabaseInstancesForFullLUNRecovery()));
            }
        }

        return row;
    }

    /**
     * Write the AvamarIntegration information.
     *
     * @param contentStream
     *            The content stream
     * @param integration
     *            The AvamarIntegration information
     * @param row
     *            the start row number
     * @param questionWidth
     *            the question width
     * @return the new row number
     * @throws IOException
     *             if any IO error occurs
     * @since SRT Phase 3-5 - BRS Tabs Part 1 Assembly
     */
    private int writeAvamarIntegration(PDPageContentStream contentStream,
        AvamarIntegration integration, int row, float questionWidth) throws IOException {
        if (integration == null) {
            return row;
        }

        row++;
        row = writeFont(contentStream, "AVAMAR INTEGRATION - DESKTOP - LAPTOP PILOT AND WORKSHOP", ++row, 0, true);

        row = writeAnswer(contentStream, row, questionWidth,
                "Design Workshop?",
                bool2String(integration.getWorkshop()));
        row = writeAnswer(contentStream, row, questionWidth,
                "Pilot?",
                bool2String(integration.getPilot()));

        row = writeAnswer(contentStream, row, questionWidth,
                "# of Avamar Desktop / Laptop Clients",
                int2String(integration.getClientsNum()));
        if (integration.getPilot() != null && integration.getPilot()) {
            row = writeAnswer(contentStream, row, questionWidth,
                    "# of Clients to be Configured as part of the Avamar Desktop/Laptop Pilot Rollout",
                    int2String(integration.getConfiguredClientsNum()));
        }
        row = writeAnswer(contentStream, row, questionWidth,
                "Will the DTLT Clients be activated by Batch Script?",
                bool2String(integration.getDtltClientsActivated()));
        row = writeAnswer(contentStream, row, questionWidth,
                "# of Avamar Grids",
                int2String(integration.getGridsNum()));

        return row;
    }

    /**
     * Write the AvamarMigration information.
     *
     * @param contentStream
     *            The content stream
     * @param migration
     *            The AvamarMigration information
     * @param row
     *            the start row number
     * @param questionWidth
     *            the question width
     * @return the new row number
     * @throws IOException
     *             if any IO error occurs
     * @since SRT Phase 3-5 - BRS Tabs Part 1 Assembly
     */
    private int writeAvamarMigration(PDPageContentStream contentStream,
            AvamarMigration migration, int row, float questionWidth) throws IOException {
        if (migration == null) {
            return row;
        }

        row++;
        row = writeFont(contentStream, "AVAMAR MIGRATION", ++row, 0, true);

        row = writeAnswer(contentStream, row, questionWidth,
                "Select Migration Type",
                migration.getMigrationType() == null ? "" : migration.getMigrationType().toString());

        row = writeAnswer(contentStream, row, questionWidth,
                "Include Client Reconfiguration",
                bool2String(migration.getIncludeClientReconfiguration()));
        row = writeAnswer(contentStream, row, questionWidth,
                "Include Source Avamar Data Wipe",
                bool2String(migration.getIncludeSourceDataWipe()));
        row = writeAnswer(contentStream, row, questionWidth,
                "# of Source System Nodes",
                int2String(migration.getSourceSysNodesNum()));
        row = writeAnswer(contentStream, row, questionWidth,
                "# of Target System Nodes",
                int2String(migration.getTargetSysNodesNum()));
        row = writeAnswer(contentStream, row, questionWidth,
                "# of Replication Monitoring Events(1 Hour Per)",
                int2String(migration.getReplicationMonitoringEventsNum()));
        row = writeAnswer(contentStream, row, questionWidth,
                "# of Avamar Clients to Reconfigure",
                int2String(migration.getReconfigureClientsNum()));

        return row;
    }

    /**
     * Write the AvamarHealthCheck information.
     *
     * @param contentStream
     *            The content stream
     * @param healthCheck
     *            The AvamarHealthCheck information
     * @param row
     *            the start row number
     * @param questionWidth
     *            the question width
     * @return the new row number
     * @throws IOException
     *             if any IO error occurs
     * @since SRT Phase 3-5 - BRS Tabs Part 1 Assembly
     */
    private int writeAvamarHealthCheck(PDPageContentStream contentStream,
            AvamarHealthCheck healthCheck, int row, float questionWidth) throws IOException {
        if (healthCheck == null) {
            return row;
        }

        row++;
        row = writeFont(contentStream, "AVAMAR HEALTHCHECK", ++row, 0, true);

        row = writeAnswer(contentStream, row, questionWidth,
                "# of Avamar Grids",
                int2String(healthCheck.getGridsNum()));
        row = writeAnswer(contentStream, row, questionWidth,
                "# of assessment interviews",
                int2String(healthCheck.getAssessmentInterviewsNum()));

        return row;
    }

    /**
     * Write the AvamarOperationalAssurance information.
     *
     * @param contentStream
     *            The content stream
     * @param assurance
     *            The AvamarOperationalAssurance information
     * @param row
     *            the start row number
     * @param questionWidth
     *            the question width
     * @return the new row number
     * @throws IOException
     *             if any IO error occurs
     * @since SRT Phase 3-5 - BRS Tabs Part 1 Assembly
     */
    private int writeAvamarOperationalAssurance(PDPageContentStream contentStream,
            AvamarOperationalAssurance assurance, int row, float questionWidth) throws IOException {
        if (assurance == null) {
            return row;
        }

        row++;
        row = writeFont(contentStream, "OPERATIONAL ASSURANCE", ++row, 0, true);

        row = writeAnswer(contentStream, row, questionWidth,
                "Include Avamar Custom Operations Guide",
                bool2String(assurance.getIncludeOperationsGuide()));
        if (assurance.getIncludeOperationsGuide() != null
                && assurance.getIncludeOperationsGuide()) {
            row = writeAnswer(contentStream, row, questionWidth,
                    "Include Avamar Custom Troubleshooting Guide",
                    bool2String(assurance.getIncludeTroubleshootingGuide()));
        }
        row = writeAnswer(contentStream, row, questionWidth,
                "Include Avamar High Level Architectural Improvement Diagram",
                bool2String(assurance.getIncludeHighLevelArch()));

        row = writeAnswer(contentStream, row, questionWidth,
                "# of Avamar Grids",
                int2String(assurance.getGridsNum()));
        row = writeAnswer(contentStream, row, questionWidth,
                "# of Archive Replication Sites",
                int2String(assurance.getReplicationSitesNum()));

        return row;
    }

    /**
     * Write the AvamarTapeOutImplementation information.
     *
     * @param contentStream
     *            The content stream
     * @param impl
     *            The AvamarTapeOutImplementation information
     * @param row
     *            the start row number
     * @param questionWidth
     *            the question width
     * @return the new row number
     * @throws IOException
     *             if any IO error occurs
     * @since SRT Phase 3-5 - BRS Tabs Part 1 Assembly
     */
    private int writeAvamarTapeOutImpl(PDPageContentStream contentStream, AvamarTapeOutImplementation impl,
            int row, float questionWidth) throws IOException {
        if (impl == null) {
            return row;
        }

        row++;
        row = writeFont(contentStream, "AVAMAR IMPLEMENTATION - TAPE OUT", ++row, 0, true);

        row = writeAnswer(contentStream, row, questionWidth, "Select for ADT Implementation?",
            impl.getAdtType() == null ? "" : impl.getAdtType().toString());
        row = writeAnswer(contentStream, row, questionWidth,
                "# of Avamar Grids",
                int2String(impl.getGridsNum()));
        row = writeAnswer(contentStream, row, questionWidth,
                "# of Archive Servers",
                int2String(impl.getArchiveServersNum()));
        row = writeAnswer(contentStream, row, questionWidth,
                "# of Existing ESX/ESXi Servers",
                int2String(impl.getEsxServersNum()));
        row = writeAnswer(contentStream, row, questionWidth,
                "# of Avamar Replication Connections",
                int2String(impl.getReplicationConnectionsNum()));
        row = writeAnswer(contentStream, row, questionWidth,
                "# of ADT Transport Nodes Needed to Support ADT Processing Requirements",
                int2String(impl.getAdtTransportNodesNum()));
        row = writeAnswer(contentStream, row, questionWidth,
                "# of ADT Controllers",
                int2String(impl.getAdtControllersNum()));

        return row;
    }

    /**
     * Write the AvamarTapeOutDesign information.
     *
     * @param contentStream
     *            The content stream
     * @param design
     *            The AvamarTapeOutDesign information
     * @param row
     *            the start row number
     * @param questionWidth
     *            the question width
     * @return the new row number
     * @throws IOException
     *             if any IO error occurs
     * @since SRT Phase 3-5 - BRS Tabs Part 1 Assembly
     */
    private int writeAvamarTapeOutDesign(PDPageContentStream contentStream, AvamarTapeOutDesign design,
            int row, float questionWidth) throws IOException {
        if (design == null) {
            return row;
        }

        row++;
        row = writeFont(contentStream, "AVAMAR DESIGN - TAPE OUT", ++row, 0, true);

        row = writeAnswer(contentStream, row, questionWidth, "Include Avamar Domain Reconfiguring and Tuning?",
            bool2String(design.getIncludeDomainReconfiguring()));
        row = writeAnswer(contentStream, row, questionWidth,
                "# of ADT Controllers",
                int2String(design.getAdtControllersNum()));
        row = writeAnswer(contentStream, row, questionWidth,
                "# of Avamar Domains Needing Tuning and Reconfiguring for ADT Implementation",
                int2String(design.getAdtDomainsNum()));
        row = writeAnswer(contentStream, row, questionWidth,
                "# of ADT Clients",
                int2String(design.getAdtClientsNum()));

        return row;
    }

    /**
     * Write the AvamarImplementation information.
     *
     * @param contentStream
     *            The content stream
     * @param impl
     *            The AvamarImplementation information
     * @param serverType
     *            the Avamar server type
     * @param row
     *            the start row number
     * @param questionWidth
     *            the question width
     * @return the new row number
     * @throws IOException
     *             if any IO error occurs
     * @since SRT Phase 3-5 - BRS Tabs Part 1 Assembly
     */
    private int writeAvamarImplementation(PDPageContentStream contentStream, AvamarImplementation impl,
        String serverType, int row, float questionWidth) throws IOException {
        if (impl == null) {
            return row;
        }

        boolean notCapacityExpansion = "Avamar Single Node".equals(serverType)
                || "Avamar Multi-Node".equals(serverType)
                || "Avamar Virtual Edition".equals(serverType);

        row++;
        row = writeFont(contentStream, "AVAMAR IMPLEMENTATION", ++row, 0, true);

        row = writeAnswer(contentStream, row, questionWidth,
                "# of billable hours for additional testing to be done by an Implementation Specialist",
                decimal2String(impl.getBillableHours(), 2));

        if (notCapacityExpansion) {
            row = writeFont(contentStream, "Select one or more Avamar Options for Implementation", ++row, 0, false);
            row = writeOptions(contentStream, getAvamarOptions1(impl.getOptions()), row, questionWidth, 2, 120f);
            List<String> optionsPart2 = getAvamarOptions2(impl.getOptions());
            if (!optionsPart2.isEmpty()) {
                row = writeOptions(contentStream, optionsPart2, ++row, questionWidth, 1, 200f);
            }
        }

        row = writeAnswer(contentStream, row, questionWidth,
                "Include Backup & Recovery Manager?",
                bool2String(impl.getIncludeBackupRecoveryManager()));

        if ("Avamar Single Node".equals(serverType)
                || "Avamar Multi-Node".equals(serverType)
                || "Avamar Capacity Expansion".equals(serverType)) {
            row = writeAnswer(contentStream, row, questionWidth,
                    "Include Hardware Installation?",
                    bool2String(impl.getIncludeHardwareInstallation()));
        }

        row = writeAnswer(contentStream, row, questionWidth,
                "# of Avamar Servers(Count one per AVE,Single Node and/or Grid)",
                int2String(impl.getServersNum()));
        row = writeAnswer(contentStream, row, questionWidth,
                "# of Avamar Data Nodes(Data Store)",
                int2String(impl.getDataNodesNum()));
        row = writeAnswer(contentStream, row, questionWidth,
                "Estimate # of hours for DataSet creation (4 hours avg)",
                decimal2String(impl.getDataSetCreationHours(), 2));
        row = writeAnswer(contentStream, row, questionWidth,
                "Select Avamar Install Type",
                impl.getInstallType() == null ? "" : impl.getInstallType().toString());
        row = writeAnswer(contentStream, row, questionWidth,
                "Select Avamar Authentication Method",
                impl.getAuthMethod() == null ? "" : impl.getAuthMethod().toString());

        if (notCapacityExpansion && impl.getOptions() != null) {
            AvamarOptions avaOpts = impl.getOptions();

            if (avaOpts.isConfigureClients()) {
                row = writeFont(contentStream, "Select one or more Avamar plugins", ++row, 0, false);
                row = writeOptions(contentStream, getAvamarPlugins(impl.getPlugins()), row, questionWidth, 2, 120f);

                row = writeAnswer(contentStream, row, questionWidth, "# of Avamar clients in design",
                        int2String(impl.getClientsNum()));
                row = writeAnswer(contentStream, row, questionWidth, "% of Avamar Clients to implement",
                        decimal2String(impl.getClientsPercent(), 2));

                AvamarPlugins plugins = impl.getPlugins();
                if (plugins != null) {
                    if (plugins.isExchange()) {
                        row = writeAnswer(contentStream, row, questionWidth,
                                "# of Avamar Application Plug-ins for Microsoft Exchange",
                                int2String(plugins.getExchangePluginsNum()));
                    }
                    if (plugins.isOracle()) {
                        row = writeAnswer(contentStream, row, questionWidth,
                                "# of Avamar Application Plug-ins for Oracle",
                                int2String(plugins.getOraclePluginsNum()));
                    }
                    if (plugins.isDb2()) {
                        row = writeAnswer(contentStream, row, questionWidth,
                                "# of Avamar Application Plug-ins for DB2", int2String(plugins.getDb2PluginsNum()));
                    }
                    if (plugins.isSharepoint()) {
                        row = writeAnswer(contentStream, row, questionWidth,
                                "# of Avamar Application Plug-ins for Microsoft Sharepoint",
                                int2String(plugins.getSharepointPluginsNum()));
                    }
                    if (plugins.isSqlServer()) {
                        row = writeAnswer(contentStream, row, questionWidth,
                                "# of Avamar Application Plug-ins for Microsoft SQL Server",
                                int2String(plugins.getSqlServerPluginsNum()));
                    }
                    if (plugins.isLotusDomino()) {
                        row = writeAnswer(contentStream, row, questionWidth,
                                "# of Avamar Application Plug-ins for Lotus Domino",
                                int2String(plugins.getLotusDominoPluginsNum()));
                    }
                }
            }

            if (avaOpts.isConfigureNDMP() && impl.getNdmp() != null) {
                AvamarNDMP ndmp = impl.getNdmp();
                row = writeFont(contentStream, "Select one or more Avamar NDMP Accelerator node types", ++row, 0,
                        false);
                row = writeOptions(contentStream, getAvamarNDMPNodeTypes(ndmp), row, questionWidth, 2, 100f);

                row = writeAnswer(contentStream, row, questionWidth, "# of Avamar NDMP Accelerator Nodes",
                        int2String(ndmp.getNdmpNodesNum()));
                row = writeAnswer(contentStream, row, questionWidth, "Include Avamar NDMP Multistream support?",
                        bool2String(ndmp.getIncludeMultistreamSupport()));

                if (ndmp.getIncludeMultistreamSupport() != null
                        && ndmp.getIncludeMultistreamSupport()) {
                    row = writeAnswer(contentStream, row, questionWidth, "# of Streams per NDMP Node",
                            int2String(ndmp.getStreamsPerNodeNum()));
                }

                if (ndmp.isEmcCelerra()) {
                    row = writeAnswer(contentStream, row, questionWidth, "# of Celerra NDMP Targets for NDMP",
                            int2String(ndmp.getCelerraTargetsNum()));
                }
                if (ndmp.isNetworkAppliance()) {
                    row = writeAnswer(contentStream, row, questionWidth, "# of NetApp Filer NDMP Targets",
                            int2String(ndmp.getNetAppFilerTargetsNum()));
                }
                if (ndmp.isEmcIsilon()) {
                    row = writeAnswer(contentStream, row, questionWidth, "# of Isilon NDMP targets",
                            int2String(ndmp.getIsilonTargetsNum()));
                }
                if (ndmp.isEmcVnx()) {
                    row = writeAnswer(contentStream, row, questionWidth, "# of VNX/VNXe NDMP targets",
                            int2String(ndmp.getVnxTargetsNum()));
                }

                row = writeAnswer(contentStream, row, questionWidth,
                        "# of hours for NDMP Data Set and Policy Creation(Default 4 Hrs)",
                        decimal2String(ndmp.getDataSetCreationHours(), 2));
            }

            if (avaOpts.isConfigureReplication()) {
                row = writeAnswer(contentStream, row, questionWidth, "# of Avamar Replication Sets",
                        int2String(impl.getReplicationSetsNum()));
            }

            if (avaOpts.isVmwareIntegeration()) {
                row = writeAnswer(contentStream, row, questionWidth,
                        "# of ESX Servers for Avamar Integration",
                        int2String(impl.getEsxServersNum()));
                row = writeAnswer(contentStream, row, questionWidth,
                        "# of Avamar VMware Proxies",
                        int2String(impl.getProxiesNum()));
                row = writeAnswer(contentStream, row, questionWidth,
                        "# of Avamar Image Level Backups to Configure",
                        int2String(impl.getImageLevelBackupsNum()));
            }

            if (avaOpts.isDataDomainIntegration()) {
                row = writeAnswer(contentStream, row, questionWidth,
                        "# of Avamar Servers to configure for Data Domain",
                        int2String(impl.getDataDomainServersNum()));
                row = writeAnswer(contentStream, row, questionWidth,
                        "# of Avamar Plug-ins configured with DDBoost",
                        int2String(impl.getDdBoostPluginsNum()));
            }
        }

        return row;
    }

    /**
     * Write the AvamarDesign information.
     *
     * @param contentStream
     *            The content stream
     * @param design
     *            The AvamarDesign information
     * @param serverType
     *            the Avamar server type
     * @param row
     *            the start row number
     * @param questionWidth
     *            the question width
     * @return the new row number
     * @throws IOException
     *             if any IO error occurs
     * @since SRT Phase 3-5 - BRS Tabs Part 1 Assembly
     */
    private int writeAvamarDesign(PDPageContentStream contentStream, AvamarDesign design, String serverType,
            int row, float questionWidth) throws IOException {
        if (design == null) {
            return row;
        }

        boolean notCapacityExpansion = "Avamar Single Node".equals(serverType)
                || "Avamar Multi-Node".equals(serverType)
                || "Avamar Virtual Edition".equals(serverType);

        row++;
        row = writeFont(contentStream, "AVAMAR DESIGN", ++row, 0, true);

        if (notCapacityExpansion) {
            row = writeFont(contentStream, "Select one or more Avamar plugins", ++row, 0, false);
            row = writeOptions(contentStream, getAvamarPlugins(design.getPlugins()), row, questionWidth, 2, 120f);

            row = writeFont(contentStream, "Select one or more Avamar Options for Design", ++row, 0, false);
            row = writeOptions(contentStream, getAvamarOptions1(design.getOptions()), row, questionWidth, 2, 120f);
            List<String> optionsPart2 = getAvamarOptions2(design.getOptions());
            if (!optionsPart2.isEmpty()) {
                row = writeOptions(contentStream, optionsPart2, ++row, questionWidth, 1, 200f);
            }
        }

        row = writeAnswer(contentStream, row, questionWidth,
                "# of Avamar Servers(Count one per AVE,Single Node and/or Grid)",
                int2String(design.getServersNum()));

        if (notCapacityExpansion) {
            AvamarPlugins plugins = design.getPlugins();
            if (plugins != null) {
                if (plugins.isExchange()) {
                    row = writeAnswer(contentStream, row, questionWidth,
                            "# of Avamar Application Plug-ins for Microsoft Exchange",
                            int2String(plugins.getExchangePluginsNum()));
                }
                if (plugins.isSqlServer()) {
                    row = writeAnswer(contentStream, row, questionWidth,
                            "# of Avamar Application Plug-ins for Microsoft SQL Server",
                            int2String(plugins.getSqlServerPluginsNum()));
                }
                if (plugins.isOracle()) {
                    row = writeAnswer(contentStream, row, questionWidth,
                            "# of Avamar Application Plug-ins for Oracle",
                            int2String(plugins.getOraclePluginsNum()));
                }
                if (plugins.isDb2()) {
                    row = writeAnswer(contentStream, row, questionWidth,
                            "# of Avamar Application Plug-ins for DB2",
                            int2String(plugins.getDb2PluginsNum()));
                }
                if (plugins.isSharepoint()) {
                    row = writeAnswer(contentStream, row, questionWidth,
                            "# of Avamar Application Plug-ins for Microsoft Sharepoint",
                            int2String(plugins.getSharepointPluginsNum()));
                }
                if (plugins.isLotusDomino()) {
                    row = writeAnswer(contentStream, row, questionWidth,
                            "# of Avamar Application Plug-ins for Lotus Domino",
                            int2String(plugins.getLotusDominoPluginsNum()));
                }
            }

            AvamarOptions avaOpts = design.getOptions();
            if (avaOpts != null) {
                if (avaOpts.isConfigureClients()) {
                    row = writeAnswer(contentStream, row, questionWidth,
                            "# of Avamar clients in design",
                            int2String(design.getClientsNum()));
                }
                if (avaOpts.isConfigureNDMP()) {
                    row = writeAnswer(contentStream, row, questionWidth,
                            "# of Avamar NDMP Accelerator Nodes",
                            int2String(design.getNdmpNodesNum()));
                    row = writeAnswer(contentStream, row, questionWidth,
                            "# of NDMP Targets for Backup",
                            int2String(design.getNdmpTargetsNum()));
                }
                if (avaOpts.isVmwareIntegeration()) {
                    row = writeAnswer(contentStream, row, questionWidth,
                            "# of ESX Servers for Avamar Integration",
                            int2String(design.getEsxServersNum()));
                    row = writeAnswer(contentStream, row, questionWidth,
                            "# of Avamar Image Level Backups to Configure",
                            int2String(design.getImageLevelBackupsNum()));
                }
            }
        }

        if ("Avamar Capacity Expansion".equals(serverType)) {
            row = writeAnswer(contentStream, row, questionWidth,
                    "# of Avamar Datastore Expansion Nodes",
                    int2String(design.getExpansionNodesNum()));
        }

        return row;
    }

    /**
     * Get Networker components in scope.
     *
     * @param components
     *            the Networker components data
     * @return Networker components in scope.
     * @since SRT Phase 3-5 - BRS Tabs Part 3 Assembly
     */
    private static List<String> getNetworkerComponents(NetworkerComponents components) {

        List<String> options = new ArrayList<String>();

        if (components != null) {
            if (components.isServer()) {
                options.add("Networker Server");
            }
            if (components.isAdvancedBackupTech()) {
                options.add("Networker Advanced Backup Technology");
            }
            if (components.isStorageNodes()) {
                options.add("Networker Storage Nodes");
            }
            if (components.isFileSystemClientBackups()) {
                options.add("Networker File System Client Backups");
            }
            if (components.isMediaDevices()) {
                options.add("Media Devices");
            }
            if (components.isApplicationBackups()) {
                options.add("Networker Application Backups");
            }
            if (components.isEmcBackupRecoveryManager()) {
                options.add("EMC Backup and Recovery Manager");
            }
        }
        return options;
    }

    /**
     * Get Networker storage node types in scope.
     *
     * @param storageNodes
     *            the Networker storage nodes data
     * @return Networker storage node types in scope.
     * @since SRT Phase 3-5 - BRS Tabs Part 3 Assembly
     */
    private static List<String> getNetworkerStorageNodeTypes(NetworkerStorageNodes storageNodes) {

        List<String> options = new ArrayList<String>();

        if (storageNodes != null) {
            if (storageNodes.isStorageNode()) {
                options.add("Storage Node");
            }
            if (storageNodes.isDedicatedStorageNode()) {
                options.add("Dedicated Storage Node");
            }
            if (storageNodes.isDeDuplicationNode()) {
                options.add("Avamar De-Duplication Node");
            }
        }
        return options;
    }

    /**
     * Get Networker media devices in scope.
     *
     * @param mediaDevices
     *            the Networker media devices data
     * @return Networker media devices in scope.
     * @since SRT Phase 3-5 - BRS Tabs Part 3 Assembly
     */
    private static List<String> getNetworkerMediaDevices(NetworkerMediaDevices mediaDevices) {

        List<String> options = new ArrayList<String>();

        if (mediaDevices != null) {
            if (mediaDevices.isAutoChanger()) {
                options.add("Auto Changer");
            }
            if (mediaDevices.isDdBoost()) {
                options.add("DD Boost");
            }
            if (mediaDevices.isTapeDevice()) {
                options.add("Tape Device");
            }
            if (mediaDevices.isAtmos()) {
                options.add("ATMOS");
            }
            if (mediaDevices.isAdvancedFileTypeDevice()) {
                options.add("Advanced File Type Device");
            }
        }
        return options;
    }

    /**
     * Get Networker advanced backup applications in scope.
     *
     * @param advancedBackup
     *            the Networker advanced backup data
     * @return Networker advanced backup applications in scope.
     * @since SRT Phase 3-5 - BRS Tabs Part 3 Assembly
     */
    private static List<String> getNetworkerAdvancedBackupApps(NetworkerAdvancedBackupTechBase advancedBackup) {

        List<String> options = new ArrayList<String>();

        if (advancedBackup != null) {
            if (advancedBackup.isSnmp()) {
                options.add("SNMP");
            }
            if (advancedBackup.isVmware()) {
                options.add("VMWARE");
            }
            if (advancedBackup.isSnapshotManagement()) {
                options.add("Snapshot Management");
            }
        }
        return options;
    }

    /**
     * Get Networker backup applications in scope.
     *
     * @param appBackup
     *            the Networker application backup data
     * @return Networker backup applications in scope.
     * @since SRT Phase 3-5 - BRS Tabs Part 3 Assembly
     */
    private static List<String> getNetworkerBackupApps(NetworkerApplicationBackupsBase appBackup) {

        List<String> options = new ArrayList<String>();

        if (appBackup != null) {
            if (appBackup.isMsSql()) {
                options.add("Microsoft SQL");
            }
            if (appBackup.isExchange()) {
                options.add("Microsoft Exchange");
            }
            if (appBackup.isSharePoint()) {
                options.add("Microsoft Sharepoint");
            }
            if (appBackup.isHyperv()) {
                options.add("Microsoft Hyper-V");
            }
            if (appBackup.isOracle()) {
                options.add("Oracle");
            }
            if (appBackup.isMySql()) {
                options.add("MySQL");
            }
            if (appBackup.isLotusNotes()) {
                options.add("Lotus Notes");
            }
            if (appBackup.isSap()) {
                options.add("SAP");
            }
            if (appBackup.isMeditech()) {
                options.add("Meditech");
            }
        }
        return options;
    }

    /**
     * Get Networker upgrade components in scope.
     *
     * @param upgrade
     *            the Networker upgrade data
     * @return Networker upgrade components in scope.
     * @since SRT Phase 3-5 - BRS Tabs Part 3 Assembly
     */
    private static List<String> getNetworkerUpgradeComponents(NetworkerUpgrade upgrade) {

        List<String> options = new ArrayList<String>();

        if (upgrade != null) {
            if (upgrade.isServer()) {
                options.add("Networker Server");
            }
            if (upgrade.isStorageNodes()) {
                options.add("Networker Storage Nodes");
            }
            if (upgrade.isClients()) {
                options.add("Networker Clients");
            }
            if (upgrade.isManagementConsole()) {
                options.add("Networker Management Console");
            }
        }
        return options;
    }

    /**
     * Write the Networker information.
     *
     * @param contentStream
     *            The content stream
     * @param page
     *            PDF page
     * @param networker
     *            The Networker information
     * @param row
     *            the start row number
     * @param questionWidth
     *            the question width
     * @return the new row number
     * @throws IOException
     *             if any IO error occurs
     * @since SRT Phase 3-5 - BRS Tabs Part 3 Assembly
     */
    private int writeNetworker(PDPageContentStream contentStream, PDPage page, Networker networker, int row,
            float questionWidth) throws IOException {
        if (networker == null) {
            return row;
        }

        row++;
        row = writeFont(contentStream, "NETWORKER", ++row, 0, true);

        row = writeAnswer(contentStream, row, questionWidth,
                "# of Hours of Knowledge Transfer",
                decimal2String(networker.getKnowledgeTransferHours(), 2));

        row = writeFont(contentStream, "Networker Services", ++row, 0, false);
        List<String> services = new ArrayList<String>();
        if (networker.isImplementationService()) {
            services.add("Networker Implementation");
        }
        if (networker.isUpgradePlanningService()) {
            services.add("Networker Upgrade Planning");
        }
        if (networker.isHealthCheckService()) {
            services.add("Networker Healthcheck");
        }
        if (networker.isUpgradeService()) {
            services.add("Networker Upgrade");
        }
        row = writeOptions(contentStream, services, row, questionWidth, 2, 120f);

        if (networker.isImplementationService() || networker.isUpgradePlanningService()) {
            row = writeFont(contentStream, "Networker Activity Type", ++row, 0, false);
            List<String> activityTypes = new ArrayList<String>();
            if (networker.isDesignActivity()) {
                activityTypes.add("Design");
            }
            if (networker.isImplementationActivity()) {
                activityTypes.add("Implementation");
            }
            row = writeOptions(contentStream, activityTypes, row, questionWidth, 2, 70f);

            if (networker.isDesignActivity()) {
                row = writeNetworkerDesign(contentStream, networker.getDesign(), row, questionWidth);
            }
            if (networker.isImplementationActivity()) {
                row = writeNetworkerImplementation(contentStream, networker.getImplementation(), row, questionWidth);
            }
        }

        if (networker.isHealthCheckService()) {
            row = writeNetworkerHealthcheck(contentStream, networker.getHealthcheck(), row, questionWidth);
        }

        if (networker.isUpgradeService()) {
            row = writeNetworkerUpgrade(contentStream, networker.getUpgrade(), row, questionWidth);
        }

        return row;
    }

    /**
     * <p>Writes the content of specified NetworkerHealhcheck section of Networker tab to specified PDF document.</p>
     *
     * @param contentStream a <code>PDPageContentStream</code> to write content to.
     * @param healthcheck a <code>NetworkerHealthcheck</code> object providing the content of NetworkerHealhcheck
     *        section of Networker tab.
     * @param row an <code>int</code> providing the current row number to start writing from.
     * @param questionWidth a <code>float</code> providing the with of the column.
     * @return an <code>int</code> providing the new row number.
     * @throws IOException if an I/O error occurs.
     * @since 2.13
     */
    private int writeNetworkerHealthcheck(PDPageContentStream contentStream, NetworkerHealthcheck healthcheck, int row,
                                          float questionWidth) throws IOException {

        if (healthcheck == null) {
            return row;
        }

        row++;
        row = writeFont(contentStream, "NETWORKER HEALTHCHECK", ++row, 0, true);

        row = writeAnswer(contentStream, row, questionWidth,
            "Will a presentation of EMC Assessment Service Analysis be given?",
            bool2String(healthcheck.getEmcAssessmentServiceAnalysisPresentation()));
        row = writeAnswer(contentStream, row, questionWidth, "# of Networker Datazones?",
            int2String(healthcheck.getNumberOfNetworkerDatazones()));
        row = writeAnswer(contentStream, row, questionWidth, "# of Assessment Interviews?",
            int2String(healthcheck.getNumberOfAssessmentInterviews()));

        return row;
    }

    /**
     * Write the Networker storage nodes information.
     *
     * @param contentStream
     *            The content stream
     * @param storageNodes
     *            The Networker storage nodes information
     * @param row
     *            the start row number
     * @param questionWidth
     *            the question width
     * @return the new row number
     * @throws IOException
     *             if any IO error occurs
     * @since SRT Phase 3-5 - BRS Tabs Part 3 Assembly
     */
    private int writeNetworkerStorageNodes(PDPageContentStream contentStream, NetworkerStorageNodes storageNodes,
            int row, float questionWidth) throws IOException {

        if (storageNodes == null) {
            return row;
        }

        row = writeFont(contentStream, "Select Networker Storage Node Types to Be Implemented", ++row, 0, false);
        row = writeOptions(contentStream, getNetworkerStorageNodeTypes(storageNodes), row, questionWidth, 2, 120f);

        if (storageNodes.isStorageNode()) {
            row = writeAnswer(contentStream, row, questionWidth,
                    "# of Networker Storage Nodes",
                    int2String(storageNodes.getStorageNodesNum()));
        }
        if (storageNodes.isDedicatedStorageNode()) {
            row = writeAnswer(contentStream, row, questionWidth,
                    "# of Networker Dedicated Storage Nodes",
                    int2String(storageNodes.getDedicatedStorageNodesNum()));
        }
        if (storageNodes.isDeDuplicationNode()) {
            row = writeAnswer(contentStream, row, questionWidth,
                    "# of Networker De-Duplication Nodes",
                    int2String(storageNodes.getDeDuplicationNodesNum()));
        }

        return row;
    }

    /**
     * Write the Networker media devices information.
     *
     * @param contentStream
     *            The content stream
     * @param mediaDevices
     *            The Networker media devices information
     * @param row
     *            the start row number
     * @param questionWidth
     *            the question width
     * @return the new row number
     * @throws IOException
     *             if any IO error occurs
     * @since SRT Phase 3-5 - BRS Tabs Part 3 Assembly
     */
    private int writeNetworkerMediaDevices(PDPageContentStream contentStream, NetworkerMediaDevices mediaDevices,
            int row, float questionWidth) throws IOException {

        if (mediaDevices == null) {
            return row;
        }

        row = writeFont(contentStream, "Select Networker Media Devices to be configured", ++row, 0, false);
        row = writeOptions(contentStream, getNetworkerMediaDevices(mediaDevices), row, questionWidth, 2, 120f);

        if (mediaDevices.isAutoChanger()) {
            row = writeAnswer(contentStream, row, questionWidth,
                    "# of Networker Auto Changers",
                    int2String(mediaDevices.getAutoChangersNum()));
        }
        if (mediaDevices.isTapeDevice()) {
            row = writeAnswer(contentStream, row, questionWidth,
                    "# of Networker Tape Devices",
                    int2String(mediaDevices.getTapeDevicesNum()));
        }
        if (mediaDevices.isAdvancedFileTypeDevice()) {
            row = writeAnswer(contentStream, row, questionWidth,
                    "# of Networker Advanced File Type Devices",
                    int2String(mediaDevices.getAdvancedFileTypeDevicesNum()));
        }
        if (mediaDevices.isDdBoost()) {
            row = writeAnswer(contentStream, row, questionWidth,
                    "# of Networker DD Boost Devices",
                    int2String(mediaDevices.getDdBoostDevicesNum()));
        }
        if (mediaDevices.isAtmos()) {
            row = writeAnswer(contentStream, row, questionWidth,
                    "# of Networker ATMOS Devices",
                    int2String(mediaDevices.getAtmosDevicesNum()));
        }

        return row;
    }

    /**
     * Write the Networker Design information.
     *
     * @param contentStream
     *            The content stream
     * @param design
     *            The Networker Design information
     * @param row
     *            the start row number
     * @param questionWidth
     *            the question width
     * @return the new row number
     * @throws IOException
     *             if any IO error occurs
     * @since SRT Phase 3-5 - BRS Tabs Part 3 Assembly
     */
    private int writeNetworkerDesign(PDPageContentStream contentStream, NetworkerDesign design, int row,
            float questionWidth) throws IOException {

        if (design == null) {
            return row;
        }

        row++;
        row = writeFont(contentStream, "NETWORKER DESIGN", ++row, 0, true);

        NetworkerComponents components = design.getComponents();
        row = writeFont(contentStream, "Select Networker Components to be Implemented", ++row, 0, false);
        row = writeOptions(contentStream, getNetworkerComponents(components), row, questionWidth, 1, 200f);

        if (components == null) {
            return row;
        }

        NetworkerServerDesign server = design.getServer();
        if ((components.isServer() || components.isStorageNodes()) && server != null) {
            row = writeAnswer(contentStream, row, questionWidth,
                    "Select the Networker Implementation Environment",
                    enum2String(server.getImplEnv()));
            row = writeAnswer(contentStream, row, questionWidth,
                    "# of Networker Servers",
                    int2String(server.getServersNum()));
        }

        if (components.isStorageNodes()) {
            row = writeNetworkerStorageNodes(contentStream, design.getStorageNodes(), row, questionWidth);
        }

        if (components.isMediaDevices()) {
            row = writeNetworkerMediaDevices(contentStream, design.getMediaDevices(), row, questionWidth);
        }

        NetworkerAdvancedBackupTechDesign advancedBackup = design.getAdvancedBackupTech();
        if (components.isAdvancedBackupTech() && advancedBackup != null) {
            row = writeFont(contentStream, "Select Networker Advanced Applications to be Backed Up", ++row, 0,
                    false);
            row = writeOptions(contentStream, getNetworkerAdvancedBackupApps(advancedBackup), row, questionWidth,
                    2, 120f);
            if (advancedBackup.isNas()) {
                row = writeOptions(contentStream,
                        Arrays.asList("NAS (Includes NDMP and Snapshot Management for NAS)"), ++row, questionWidth,
                        1, 200f);
            }

            if (advancedBackup.isVmware()) {
                Boolean includeVmwareProtectionBackups = advancedBackup.getIncludeVmwareProtectionBackups();
                row = writeAnswer(contentStream, row, questionWidth,
                        "Include Networker VMWare Protection Backups?",
                        bool2String(includeVmwareProtectionBackups));

                if (isBooleanFalse(includeVmwareProtectionBackups)) {
                    row = writeAnswer(contentStream, row, questionWidth,
                            "# of VMWare vSphere Hosts",
                            int2String(advancedBackup.getVmwareVsphereHostsNum()));
                }
                if (isBooleanTrue(includeVmwareProtectionBackups)) {
                    row = writeAnswer(contentStream, row, questionWidth,
                            "# of VMWare Backup Appliances",
                            int2String(advancedBackup.getVmwareBackupAppliancesNum()));
                }
            }

            if (advancedBackup.isSnapshotManagement()) {
                row = writeAnswer(contentStream, row, questionWidth,
                        "# of Networker Snapshot Management Application Hosts",
                        int2String(advancedBackup.getSnapshotManagementAppHostsNum()));
                row = writeAnswer(contentStream, row, questionWidth,
                        "# of Networker Snapshot Management Mount Hosts",
                        int2String(advancedBackup.getSnapshotManagementMountHostsNum()));
            }

            if (advancedBackup.isNas()) {
                row = writeAnswer(contentStream, row, questionWidth,
                        "# of NAS DataMovers to be Backed Up via NDMP",
                        int2String(advancedBackup.getNasDataMoversNum()));
            }
        }

        NetworkerFileSystemClientBackupsDesign fileSystemClientBackups = design.getFileSystemClientBackups();
        if (components.isFileSystemClientBackups() && fileSystemClientBackups != null) {
            row = writeAnswer(contentStream, row, questionWidth,
                    "# of Networker Clients (Windows / Unix / Linux)",
                    int2String(fileSystemClientBackups.getClientsNum()));
            row = writeAnswer(contentStream, row, questionWidth,
                    "# of Networker Cluster Client Connections",
                    int2String(fileSystemClientBackups.getClusterClientConnectionsNum()));
        }

        NetworkerApplicationBackupsDesign applicationBackup = design.getApplicationBackups();
        if (components.isApplicationBackups() && applicationBackup != null) {
            row = writeFont(contentStream, "Select Applications to be Backed Up", ++row, 0, false);
            row = writeOptions(contentStream, getNetworkerBackupApps(applicationBackup), row, questionWidth, 2,
                    120f);

            if (applicationBackup.isMsSql()) {
                row = writeAnswer(contentStream, row, questionWidth,
                        "Include Microsoft SQL Server Cluster?",
                        bool2String(applicationBackup.getIncludeMSSqlServerCluster()));
                row = writeAnswer(contentStream, row, questionWidth,
                        "# of Microsoft SQL Servers",
                        int2String(applicationBackup.getMsSqlServersNum()));
                row = writeAnswer(contentStream, row, questionWidth,
                        "# of SQL Databases",
                        int2String(applicationBackup.getMsSqlDatabasesNum()));
            }

            if (applicationBackup.isExchange()) {
                row = writeAnswer(contentStream, row, questionWidth,
                        "Do you want Exchange Granular Backups to Be Implemented?",
                        bool2String(applicationBackup.getImplementExchangeGranularBackups()));
                row = writeAnswer(contentStream, row, questionWidth,
                        "Include Clustered Exchange Servers?",
                        bool2String(applicationBackup.getIncludeClusteredExchangeServers()));
                row = writeAnswer(contentStream, row, questionWidth,
                        "# of Microsoft Exchange Mailbox Servers",
                        int2String(applicationBackup.getExchangeMailboxServersNum()));
                row = writeAnswer(contentStream, row, questionWidth,
                        "# of Microsoft Exchange Database Stores",
                        int2String(applicationBackup.getExchangeDatabaseStoresNum()));
                row = writeAnswer(contentStream, row, questionWidth,
                        "Data Domain Boost?",
                        bool2String(applicationBackup.getExchangeDataDomainBoost()));
            }

            if (applicationBackup.isSharePoint()) {
                row = writeAnswer(contentStream, row, questionWidth,
                        "Include Microsoft SQL Server Cluster?",
                        bool2String(applicationBackup.getSharePointIncludeMSSqlServerCluster()));
                row = writeAnswer(contentStream, row, questionWidth,
                        "Include Granular SharePoint Backups?",
                        bool2String(applicationBackup.getIncludeGranularSharePointBackups()));
                row = writeAnswer(contentStream, row, questionWidth,
                        "Include SharePoint Distributed Environment?",
                        bool2String(applicationBackup.getIncludeSharePointDistributedEnv()));
                row = writeAnswer(contentStream, row, questionWidth,
                        "# of Microsoft SQL Servers",
                        int2String(applicationBackup.getSharePointMSSqlServersNum()));
                row = writeAnswer(contentStream, row, questionWidth,
                        "# of SQL Databases",
                        int2String(applicationBackup.getSharePointSqlDatabasesNum()));
                row = writeAnswer(contentStream, row, questionWidth,
                        "# of SharePoint Farms",
                        int2String(applicationBackup.getSharePointFarmsNum()));
                row = writeAnswer(contentStream, row, questionWidth,
                        "# of SharePoint Web Applications",
                        int2String(applicationBackup.getSharePointWebAppsNum()));
                row = writeAnswer(contentStream, row, questionWidth,
                        "# of SharePoint Sites",
                        int2String(applicationBackup.getSharePointSitesNum()));
                row = writeAnswer(contentStream, row, questionWidth,
                        "# of SharePoint Sub-Sites",
                        int2String(applicationBackup.getSharePointSubSitesNum()));
                row = writeAnswer(contentStream, row, questionWidth,
                        "Data Domain Boost?",
                        bool2String(applicationBackup.getSharePointDataDomainBoost()));
            }

            if (applicationBackup.isHyperv()) {
                row = writeAnswer(contentStream, row, questionWidth,
                        "Are any of the Hyper-V Environments Clustered?",
                        bool2String(applicationBackup.getHypervEnvClustered()));
                row = writeAnswer(contentStream, row, questionWidth,
                        "# of Microsoft Hyper-V Servers to be Backed Up with NMM",
                        int2String(applicationBackup.getHypervServersNum()));
            }

            if (applicationBackup.isOracle()) {
                row = writeAnswer(contentStream, row, questionWidth,
                        "Are there any clustered Oracle Servers to be backed up",
                        bool2String(applicationBackup.getClusteredOracleServers()));
                row = writeAnswer(contentStream, row, questionWidth,
                        "Include Extensive RMAN Scripting",
                        bool2String(applicationBackup.getIncludeExtensiveRMANScripting()));
                row = writeAnswer(contentStream, row, questionWidth,
                        "# of Oracle Database Servers for RMAN Backup",
                        int2String(applicationBackup.getOracleRMANBackupServersNum()));
                row = writeAnswer(contentStream, row, questionWidth,
                        "# of Oracle Databases for Backup Configuration",
                        int2String(applicationBackup.getOracleBackupConfigDatabasesNum()));
            }

            if (applicationBackup.isMySql()) {
                row = writeAnswer(contentStream, row, questionWidth,
                        "MySql Environment Clustered?",
                        bool2String(applicationBackup.getMySqlEnvClustered()));
                row = writeAnswer(contentStream, row, questionWidth,
                        "# of MySQL Servers",
                        int2String(applicationBackup.getMySqlServersNum()));
            }

            if (applicationBackup.isLotusNotes()) {
                row = writeAnswer(contentStream, row, questionWidth,
                        "Are any of the Lotus Notes Applications Clustered",
                        bool2String(applicationBackup.getLotusNotesAppsClustered()));
                row = writeAnswer(contentStream, row, questionWidth,
                        "# of IBM Lotus Domino Instances",
                        int2String(applicationBackup.getLotusDominoInstancesNum()));
            }

            if (applicationBackup.isSap()) {
                row = writeAnswer(contentStream, row, questionWidth,
                        "Is SAP Environment Clustered?",
                        bool2String(applicationBackup.getSapEnvClustered()));
                row = writeAnswer(contentStream, row, questionWidth,
                        "# of SAP Applicaiton Servers",
                        int2String(applicationBackup.getSapAppServersNum()));
            }

            if (applicationBackup.isMeditech()) {
                row = writeAnswer(contentStream, row, questionWidth,
                    "Select the type of Meditech backups to be configured", 
                    lookupEntity2String(applicationBackup.getMeditechBackupType()));
                row = writeAnswer(contentStream, row, questionWidth, "# of Meditech Hosts?",
                    int2String(applicationBackup.getNumberOfMeditechHosts()));
                row = writeAnswer(contentStream, row, questionWidth, "# of Storage Arrays in the Meditech Environment?",
                    int2String(applicationBackup.getNumberOfMeditechStorageArrays()));
            }
        }

        return row;
    }

    /**
     * Write the Networker Implementation information.
     *
     * @param contentStream
     *            The content stream
     * @param impl
     *            The Networker Implementation information
     * @param row
     *            the start row number
     * @param questionWidth
     *            the question width
     * @return the new row number
     * @throws IOException
     *             if any IO error occurs
     * @since SRT Phase 3-5 - BRS Tabs Part 3 Assembly
     */
    private int writeNetworkerImplementation(PDPageContentStream contentStream, NetworkerImplementation impl,
            int row, float questionWidth) throws IOException {

        if (impl == null) {
            return row;
        }

        row++;
        row = writeFont(contentStream, "NETWORKER IMPLEMENTATION", ++row, 0, true);

        row = writeAnswer(contentStream, row, questionWidth,
            "Knowledge Acquisition and Data Gathering for NetWorker Upgrade Planning",
            bool2String(impl.getSelectDataZoneSize()));
        
        if (impl.getSelectDataZoneSize() != null && impl.getSelectDataZoneSize()) {
            NetworkerDatazoneSize dataZoneSize = impl.getDataZoneSize();
            if (dataZoneSize == null) {
                dataZoneSize = new NetworkerDatazoneSize();
            }
            row = writeAnswer(contentStream, row, questionWidth, "", lookupEntity2String(dataZoneSize));
        }

        return row;
    }

    /**
     * Write the Networker Upgrade information.
     *
     * @param contentStream
     *            The content stream
     * @param upgrade
     *            The Networker Upgrade information
     * @param row
     *            the start row number
     * @param questionWidth
     *            the question width
     * @return the new row number
     * @throws IOException
     *             if any IO error occurs
     * @since SRT Phase 3-5 - BRS Tabs Part 3 Assembly
     */
    private int writeNetworkerUpgrade(PDPageContentStream contentStream, NetworkerUpgrade upgrade,
            int row, float questionWidth) throws IOException {

        if (upgrade == null) {
            return row;
        }

        row++;
        row = writeFont(contentStream, "NETWORKER UPGRADE", ++row, 0, true);

        row = writeFont(contentStream, "Select Networker Components to be Upgraded", ++row, 0, false);
        row = writeOptions(contentStream, getNetworkerUpgradeComponents(upgrade), row, questionWidth, 2, 120f);

        if (upgrade.isServer()) {
            row = writeAnswer(contentStream, row, questionWidth,
                    "Select the Current Networker Version",
                    enum2String(upgrade.getCurrentVersion()));
            row = writeAnswer(contentStream, row, questionWidth,
                    "Select the Networker Version to Upgrade to",
                    enum2String(upgrade.getUpgradeVersion()));
            row = writeAnswer(contentStream, row, questionWidth,
                    "Will the Networker Server Be Upgraded to New Hardware?",
                    bool2String(upgrade.getUpgradeToNewHardware()));
            row = writeAnswer(contentStream, row, questionWidth,
                    "# of Networker Servers to Be Upgraded",
                    int2String(upgrade.getServersNum()));
        }

        if (upgrade.isStorageNodes()) {
            row = writeAnswer(contentStream, row, questionWidth,
                    "# of Networker Storage Nodes to Be Upgraded",
                    int2String(upgrade.getStorageNodesNum()));
        }

        if (upgrade.isClients()) {
            row = writeAnswer(contentStream, row, questionWidth,
                    "# of Networker Clients to Be Upgraded",
                    int2String(upgrade.getClientsNum()));
        }

        if (upgrade.isManagementConsole()) {
            row = writeAnswer(contentStream, row, questionWidth,
                    "# of Networker Management Consoles to Be Upgraded",
                    int2String(upgrade.getManagementConsolesNum()));
        }

        return row;
    }

    /**
     * Get DPA activity types in scope.
     *
     * @param dpa
     *            the DPA data
     * @return DPA activity types in scope.
     * @since SRT Phase 3-5 - BRS Tabs Part 2 Assembly
     */
    private static List<String> getDPAActivityTypes(DPA dpa) {

        List<String> options = new ArrayList<String>();

        if (dpa != null) {
            if (dpa.isDesignActivity()) {
                options.add("Design");
            }
            if (dpa.isImplementationActivity()) {
                options.add("Implementation");
            }
        }
        return options;
    }

    /**
     * Get DPA services in scope.
     *
     * @param dpa
     *            the DPA data
     * @return DPA services in scope.
     * @since SRT Phase 3-5 - BRS Tabs Part 2 Assembly
     */
    private static List<String> getDPAServices(DPA dpa) {

        List<String> options = new ArrayList<String>();

        if (dpa != null) {
            if (dpa.isImplementService()) {
                options.add("Implement Data Protection Advisor");
            }
            if (dpa.isOperationalAssuranceService()) {
                options.add("Operational Assurance for Data Protection Advisor");
            }
            if (dpa.isCustomizationService()) {
                options.add("Customization for Data Protection Advisor");
            }
            if (dpa.isUpgradeMigrationService()) {
                options.add("Upgrade and Migration for Data Protection Advisor");
            }
            if (dpa.isHealthCheckService()) {
                options.add("Health Check for Data Protection Advisor");
            }
        }
        return options;
    }

    /**
     * Write the DPA (Data Protection Advisor) information.
     *
     * @param contentStream
     *            The content stream
     * @param page
     *            PDF page
     * @param dpa
     *            The DPA information
     * @param row
     *            the start row number
     * @param questionWidth
     *            the question width
     * @return the new row number
     * @throws IOException
     *             if any IO error occurs
     * @since SRT Phase 3-5 - BRS Tabs Part 2 Assembly
     */
    private int writeDPA(PDPageContentStream contentStream, PDPage page, DPA dpa, int row,
            float questionWidth) throws IOException {
        if (dpa == null) {
            return row;
        }

        row++;
        row = writeFont(contentStream, "DATA PROTECTION ADVISOR", ++row, 0, true);

        row = writeAnswer(contentStream, row, questionWidth,
                "# of Hours of Knowledge Transfer",
                decimal2String(dpa.getKnowledgeTransferHours(), 2));

        row = writeFont(contentStream, "Data Protection Advisor Services", ++row, 0, false);
        row = writeOptions(contentStream, getDPAServices(dpa), row, questionWidth, 1, 200f);

        if (dpa.isImplementService()) {
            row = writeFont(contentStream, "Data Domain Activity Type", ++row, 0, false);
            row = writeOptions(contentStream, getDPAActivityTypes(dpa), row, questionWidth, 2, 70f);
        }

        if (dpa.isImplementService()) {
            if (dpa.isDesignActivity()) {
                row = writeDPADesign(contentStream, dpa.getDesign(), row, questionWidth);
            }
            if (dpa.isImplementationActivity()) {
                row = writeDPAImpl(contentStream, dpa.getImplementation(), row, questionWidth);
            }
        }

        if (dpa.isOperationalAssuranceService()) {
            row = writeDPAOperationalAssurance(contentStream, dpa.getOperationalAssurance(), row, questionWidth);
        }

        if (dpa.isCustomizationService()) {
            row = writeDPACustomization(contentStream, dpa.getCustomization(), row, questionWidth);
        }

        if (dpa.isUpgradeMigrationService()) {
            row = writeDPAUpgradeMigration(contentStream, dpa.getUpgradeMigration(), row, questionWidth);
        }

        if (dpa.isHealthCheckService()) {
            row = writeDPAHealthCheck(contentStream, dpa.getHealthCheck(), row, questionWidth);
        }

        return row;
    }

    /**
     * Write the DPA Health Check information.
     *
     * @param contentStream
     *            The content stream
     * @param healthCheck
     *            The DPA Health Check information
     * @param row
     *            the start row number
     * @param questionWidth
     *            the question width
     * @return the new row number
     * @throws IOException
     *             if any IO error occurs
     * @since SRT Phase 3-5 - BRS Tabs Part 2 Assembly
     */
    private int writeDPAHealthCheck(PDPageContentStream contentStream, DPAHealthCheck healthCheck, int row,
            float questionWidth) throws IOException {

        if (healthCheck == null) {
            return row;
        }

        row++;
        row = writeFont(contentStream, "DATA PROTECTION ADVISOR HEALTH CHECK", ++row, 0, true);

        row = writeAnswer(contentStream, row, questionWidth,
                "# of Data Protection Advisor Site Implementations",
                int2String(healthCheck.getSiteImplementationsNum()));

        return row;
    }

    /**
     * Write the DPA Upgrade And Migration information.
     *
     * @param contentStream
     *            The content stream
     * @param upgradeMigration
     *            The DPA Upgrade And Migration information
     * @param row
     *            the start row number
     * @param questionWidth
     *            the question width
     * @return the new row number
     * @throws IOException
     *             if any IO error occurs
     * @since SRT Phase 3-5 - BRS Tabs Part 2 Assembly
     */
    private int writeDPAUpgradeMigration(PDPageContentStream contentStream, DPAUpgradeMigration upgradeMigration,
        int row, float questionWidth) throws IOException {

        if (upgradeMigration == null) {
            return row;
        }

        row++;
        row = writeFont(contentStream, "DATA PROTECTION ADVISOR UPGRADE AND MIGRATION", ++row, 0, true);

        row = writeAnswer(contentStream, row, questionWidth,
                "Select Current Data Protection Advisor Version for Upgrade / Migration",
                enum2String(upgradeMigration.getUpgradeMigrationVersion()));

        List<String> options = new ArrayList<String>();
        if (upgradeMigration.isManualMigrations()) {
            options.add("Manual Migrations");
        }
        if (upgradeMigration.isCustomizationMigration()) {
            options.add("Customization Migration");
        }

        row = writeFont(contentStream, "Select Data Protection Advisor Migration Options", ++row, 0, false);
        row = writeOptions(contentStream, options, row, questionWidth, 2, 110f);

        row = writeAnswer(contentStream, row, questionWidth,
                "Estimated Data Protection Advisor Migration Volumes in GB",
                int2String(upgradeMigration.getEstimatedMigrationVolumes()));
        row = writeAnswer(contentStream, row, questionWidth,
                "# of Data Protection Advisor Agents to Reconfigure",
                int2String(upgradeMigration.getReconfigureAgentsNum()));

        return row;
    }

    /**
     * Write the DPA customization information.
     *
     * @param contentStream
     *            The content stream
     * @param customization
     *            The DPA customization information
     * @param row
     *            the start row number
     * @param questionWidth
     *            the question width
     * @return the new row number
     * @throws IOException
     *             if any IO error occurs
     * @since SRT Phase 3-5 - BRS Tabs Part 2 Assembly
     */
    private int writeDPACustomization(PDPageContentStream contentStream, DPACustomization customization, int row,
            float questionWidth) throws IOException {

        if (customization == null) {
            return row;
        }

        row++;
        row = writeFont(contentStream, "DATA PROTECTION ADVISOR CUSTOMIZATION", ++row, 0, true);

        row = writeAnswer(contentStream, row, questionWidth,
                "Include Data Protection Advisor Third Party Integration Development",
                bool2String(customization.getIncludeThirdPartyIntegrationDevelopment()));
        row = writeAnswer(contentStream, row, questionWidth,
                "Include Data Protection Advisor Analysis Jobs",
                bool2String(customization.getIncludeAnalysisJobs()));
        row = writeAnswer(contentStream, row, questionWidth,
                "Include Data Protection Advisor Interface Customization",
                bool2String(customization.getIncludeInterfaceCustomization()));
        row = writeAnswer(contentStream, row, questionWidth,
                "Include Data Protection Advisor Custom Report Development",
                bool2String(customization.getIncludeCustomReportDevelopment()));

        if (isBooleanTrue(customization.getIncludeThirdPartyIntegrationDevelopment())) {
            row = writeDPACustomizationData(contentStream,
                    customization.getThirdPartyIntegrationDevelopmentData(), row, questionWidth);
        }

        if (isBooleanTrue(customization.getIncludeAnalysisJobs())) {
            row = writeDPACustomizationData(contentStream,
                    customization.getAnalysisJobsData(), row, questionWidth);
            row = writeAnswer(contentStream, row, questionWidth,
                    "# of Data Protection Advisor Analysis Jobs (Estimated)",
                    int2String(customization.getAnalysisJobsNum()));
        }

        if (isBooleanTrue(customization.getIncludeInterfaceCustomization())) {
            row = writeDPACustomizationData(contentStream,
                    customization.getInterfaceCustomizationData(), row, questionWidth);
        }

        if (isBooleanTrue(customization.getIncludeCustomReportDevelopment())) {
            row = writeDPACustomizationData(contentStream,
                    customization.getCustomReportDevelopmentData(), row, questionWidth);
        }

        return row;
    }

    /**
     * Write the DPA customization data.
     *
     * @param contentStream
     *            The content stream
     * @param data
     *            The DPA customization data
     * @param row
     *            the start row number
     * @param questionWidth
     *            the question width
     * @return the new row number
     * @throws IOException
     *             if any IO error occurs
     * @since SRT Phase 3-5 - BRS Tabs Part 2 Assembly
     */
    private int writeDPACustomizationData(PDPageContentStream contentStream, DPACustomizationData data, int row,
            float questionWidth) throws IOException {

        if (data == null) {
            return row;
        }

        row = writeAnswer(contentStream, row, questionWidth,
                "Include Requirements Workshop",
                bool2String(data.getIncludeRequirementsWorkshop()));
        row = writeAnswer(contentStream, row, questionWidth, "Include Data Protection Advisor Scale Plan",
            bool2String(data.getIncludeScalePlan()));
        row = writeAnswer(contentStream, row, questionWidth,
                "# of Data Protection Advisor Collection Nodes",
                int2String(data.getCollectionNodesNum()));
        row = writeAnswer(contentStream, row, questionWidth,
                "# of Data Protection Collector Nodes to Configure",
                int2String(data.getCollectorNodesNum()));

        return row;
    }

    /**
     * Write the DPA Operational Assurance information.
     *
     * @param contentStream
     *            The content stream
     * @param operAssurance
     *            The DPA Operational Assurance information
     * @param row
     *            the start row number
     * @param questionWidth
     *            the question width
     * @return the new row number
     * @throws IOException
     *             if any IO error occurs
     * @since SRT Phase 3-5 - BRS Tabs Part 2 Assembly
     */
    private int writeDPAOperationalAssurance(PDPageContentStream contentStream,
            DPAOperationalAssurance operAssurance, int row, float questionWidth) throws IOException {
        if (operAssurance == null) {
            return row;
        }

        row++;
        row = writeFont(contentStream, "DATA PROTECTION ADVISOR OPERATIONAL ASSURANCE", ++row, 0, true);

        row = writeAnswer(contentStream, row, questionWidth,
                "Include Requirements Workshop",
                bool2String(operAssurance.getIncludeRequirementsWorkshop()));
        row = writeAnswer(contentStream, row, questionWidth,
                "# of Data Protection Advisor Analysis Site Implementations",
                int2String(operAssurance.getAnalysisSiteImplementationsNum()));

        return row;
    }

    /**
     * Write the DPA Implementation information.
     *
     * @param contentStream
     *            The content stream
     * @param impl
     *            The DPA Implementation information
     * @param row
     *            the start row number
     * @param questionWidth
     *            the question width
     * @return the new row number
     * @throws IOException
     *             if any IO error occurs
     * @since SRT Phase 3-5 - BRS Tabs Part 2 Assembly
     */
    private int writeDPAImpl(PDPageContentStream contentStream, DPAImplementation impl, int row,
            float questionWidth) throws IOException {
        if (impl == null) {
            return row;
        }

        row++;
        row = writeFont(contentStream, "DATA PROTECTION ADVISOR IMPLEMENTATION", ++row, 0, true);

        row = writeAnswer(contentStream, row, questionWidth,
                "Upgrade from Data Protection Advisor 5.0 Environment",
                bool2String(impl.getUpgradeFromV5Environment()));
        row = writeAnswer(contentStream, row, questionWidth,
                "Include Data Protection Advisor Custom Report Development",
                bool2String(impl.getIncludeCustomReportDevelopment()));
        row = writeAnswer(contentStream, row, questionWidth,
                "Include Data Protection Advisor Interface Customization",
                bool2String(impl.getIncludeInterfaceCustomization()));
        row = writeAnswer(contentStream, row, questionWidth,
                "Include Data Protection Advisor Recoverability Analysis",
                bool2String(impl.getIncludeRecoverabilityAnalysis()));
        row = writeAnswer(contentStream, row, questionWidth,
                "Include Data Protection Advisor Analysis Jobs",
                bool2String(impl.getIncludeAnalysisJobs()));

        if (isBooleanTrue(impl.getUpgradeFromV5Environment())) {
            row = writeDPAImplementationData(contentStream, impl.getUpgradeData(), row, questionWidth);
        }

        if (isBooleanTrue(impl.getIncludeCustomReportDevelopment())) {
            row = writeDPAImplementationData(contentStream, impl.getCustomReportDevelopmentData(), row,
                    questionWidth);
        }

        if (isBooleanTrue(impl.getIncludeInterfaceCustomization())) {
            row = writeDPAImplementationData(contentStream, impl.getInterfaceCustomizationData(), row,
                    questionWidth);
        }

        if (isBooleanTrue(impl.getIncludeRecoverabilityAnalysis())) {
            DPAImplementationData data = impl.getRecoverabilityAnalysisData();
            row = writeDPAImplementationData(contentStream, data, row, questionWidth);
            if (data != null && isBooleanTrue(data.getIncludeEDLMonitoring())) {
                row = writeAnswer(contentStream, row, questionWidth,
                        "# of Recoverability Agents",
                        int2String(impl.getRecoverabilityAgentsNum()));
            }
        }

        if (isBooleanTrue(impl.getIncludeAnalysisJobs())) {
            DPAImplementationData data = impl.getAnalysisJobsData();
            row = writeDPAImplementationData(contentStream, data, row, questionWidth);
            if (data != null && isBooleanTrue(data.getIncludeEDLMonitoring())) {
                row = writeAnswer(contentStream, row, questionWidth,
                        "# of Data Protection Advisor Analysis Jobs (Estimated)",
                        int2String(impl.getAnalysisJobsNum()));
            }
        }

        return row;
    }

    /**
     * Write the DPA implementation data.
     *
     * @param contentStream
     *            The content stream
     * @param data
     *            The DPA implementation data
     * @param row
     *            the start row number
     * @param questionWidth
     *            the question width
     * @return the new row number
     * @throws IOException
     *             if any IO error occurs
     * @since SRT Phase 3-5 - BRS Tabs Part 2 Assembly
     */
    private int writeDPAImplementationData(PDPageContentStream contentStream, DPAImplementationData data, int row,
            float questionWidth) throws IOException {

        if (data == null) {
            return row;
        }

        row = writeAnswer(contentStream, row, questionWidth,
                "Install Data Protection Advisor on External Database (Oracle, MS SQL, etc.)",
                bool2String(data.getInstallOnExternalDatabase()));
        row = writeAnswer(contentStream, row, questionWidth,
                "Include Data Protection Advisor EDL Monitoring",
                bool2String(data.getIncludeEDLMonitoring()));
        row = writeAnswer(contentStream, row, questionWidth,
                "# of Data Protection Advisor Collection Nodes",
                int2String(data.getCollectionNodesNum()));
        row = writeAnswer(contentStream, row, questionWidth,
                "# of Data Protection Collector Nodes to Configure",
                int2String(data.getCollectorNodesNum()));
        if (isBooleanTrue(data.getIncludeEDLMonitoring())) {
            row = writeAnswer(contentStream, row, questionWidth,
                    "# of EMC Disk Libraries",
                    int2String(data.getEmcDiskLibrariesNum()));
        }
        return row;
    }

    /**
     * Write the DPA Design information.
     *
     * @param contentStream
     *            The content stream
     * @param design
     *            The DPA Design information
     * @param row
     *            the start row number
     * @param questionWidth
     *            the question width
     * @return the new row number
     * @throws IOException
     *             if any IO error occurs
     * @since SRT Phase 3-5 - BRS Tabs Part 2 Assembly
     */
    private int writeDPADesign(PDPageContentStream contentStream, DPADesign design, int row,
            float questionWidth) throws IOException {
        if (design == null) {
            return row;
        }

        row++;
        row = writeFont(contentStream, "DATA PROTECTION ADVISOR DESIGN", ++row, 0, true);

        row = writeAnswer(contentStream, row, questionWidth,
                "Install Data Protection Advisor on Extended Database (Oracle, MS SQL, etc.)",
                bool2String(design.getInstallOnExtendedDatabase()));
        row = writeAnswer(contentStream, row, questionWidth,
                "Include Data Protection Advisor Analysis Jobs",
                bool2String(design.getIncludeAnalysisJobs()));
        row = writeAnswer(contentStream, row, questionWidth,
                "Include Data Protection Advisor Recoverability Analysis",
                bool2String(design.getIncludeRecoverabilityAnalysis()));
        row = writeAnswer(contentStream, row, questionWidth,
                "Include Data Protection Advisor Custom Report Development",
                bool2String(design.getIncludeCustomReportDevelopment()));
        row = writeAnswer(contentStream, row, questionWidth,
                "Include Data Protection Advisor Interface Customization",
                bool2String(design.getIncludeInterfaceCustomization()));
        row = writeAnswer(contentStream, row, questionWidth,
                "Include Data Protection Advisor Scale Plan",
                bool2String(design.getIncludeScalePlan()));

        row = writeAnswer(contentStream, row, questionWidth,
                "# of Data Protection Advisor Collection Nodes",
                int2String(design.getCollectionNodesNum()));
        row = writeAnswer(contentStream, row, questionWidth,
                "# of Data Protection Collector Nodes to Configure",
                int2String(design.getCollectorNodesNum()));

        return row;
    }

    /**
     * Write the DataDomain information.
     *
     * @param contentStream
     *            The content stream
     * @param page
     *            PDF page
     * @param dataDomain
     *            The DataDomain information
     * @param row
     *            the start row number
     * @param questionWidth
     *            the question width
     * @return the new row number
     * @throws IOException
     *             if any IO error occurs
     * @since SRT Phase 3-5 - BRS Tabs Part 2 Assembly
     */
    private int writeDataDomain(PDPageContentStream contentStream, PDPage page, DataDomain dataDomain, int row,
            float questionWidth) throws IOException {
        if (dataDomain == null) {
            return row;
        }

        row++;
        row = writeFont(contentStream, "DATA DOMAIN", ++row, 0, true);

        row = writeAnswer(contentStream, row, questionWidth,
                "# of Hours of Knowledge Transfer",
                decimal2String(dataDomain.getKnowledgeTransferHours(), 2));

        row = writeFont(contentStream, "Data Domain Services", ++row, 0, false);
        row = writeOptions(contentStream, getDataDomainServices(dataDomain), row, questionWidth, 1, 200f);

        if (dataDomain.isImplementService()) {
            row = writeFont(contentStream, "Data Domain Activity Type", ++row, 0, false);
            row = writeOptions(contentStream, getDataDomainActivityTypes(dataDomain), row, questionWidth, 2, 70f);
            if (dataDomain.isDesignActivity() && dataDomain.isImplementationActivity()) {
                row = writeAnswer(contentStream, row, questionWidth, "Are Design and implementation the same content?",
                    bool2String(dataDomain.getDesignImplementationIdentical()));
                if (dataDomain.getDesignImplementationIdentical()) {
                    row = writeDataDomainDesignImpl(contentStream, row, questionWidth,
                                                    dataDomain.getDesignImplContent());
                }
            }

            if (dataDomain.isDesignActivity()) {
                row = writeDataDomainDesign(contentStream, page, dataDomain, row, questionWidth);
            }

            if (dataDomain.isImplementationActivity()) {
                row = writeDataDomainImpl(contentStream, page, dataDomain, row, questionWidth);
            }
        }

        if (dataDomain.isUpgradeService()) {
            row = writeDataDomainUpgrade(contentStream, dataDomain.getUpgrade(), row, questionWidth);
        }

        if (dataDomain.isImplementVTLService()) {
            row = writeDataDomainVTL(contentStream, dataDomain.getVtl(), row, questionWidth);
        }

        if (dataDomain.isExpansionShelfService()) {
            row = writeDataDomainExpansionShelf(contentStream, dataDomain.getExpansionShelf(), row, questionWidth);
        }

        if (dataDomain.isDataStagingService()) {
            row = writeDataDomainStaging(contentStream, dataDomain.getDataStaging(), row, questionWidth);
        }

        if (dataDomain.isIntegrationService()) {
            row = writeDataDomainIntegration(contentStream, dataDomain.getIntegration(), row, questionWidth);
        }

        if (dataDomain.isHealthCheckService()) {
            row = writeDataDomainHealthCheck(contentStream, dataDomain.getHealthCheck(), row, questionWidth);
        }

        if (dataDomain.isMigrationService()) {
            row = writeDataDomainMigration(contentStream, dataDomain.getMigration(), row, questionWidth);
        }

        if (dataDomain.isPreRackedService()) {
            row = writeDataDomainPreRack(contentStream, dataDomain.getPreRack(), row, questionWidth);
        }

        if (dataDomain.isBoostService()) {
            row = writeDataDomainBoost(contentStream, dataDomain.getBoost(), row, questionWidth);
        }

        if (dataDomain.isExtendedRetentionConversionService()) {
            row = writeDataDomainExtendedRetentionConversion(contentStream,
                    dataDomain.getExtendedRetentionConversion(), row, questionWidth);
        }

        if (dataDomain.isManagementCenterConfigService()) {
            row = writeDataDomainManagementCenterConfig(contentStream,
                    dataDomain.getManagementCenterConfig(), row, questionWidth);
        }

        if (dataDomain.isSapHanaService()) {
            row = writeDataDomainSapHana(contentStream, dataDomain.getSapHana(), row, questionWidth);
        }

        return row;
    }

    /**
     * Write the DataDomain SAP Hana information.
     *
     * @param contentStream
     *            The content stream
     * @param sapHana
     *            The DataDomain SAP Hana information
     * @param row
     *            the start row number
     * @param questionWidth
     *            the question width
     * @return the new row number
     * @throws IOException
     *             if any IO error occurs
     * @since SRT Phase 3-5 - BRS Tabs Part 2 Assembly
     */
    private int writeDataDomainSapHana(PDPageContentStream contentStream, DataDomainSapHana sapHana, int row,
            float questionWidth) throws IOException {
        if (sapHana == null) {
            return row;
        }

        row++;
        row = writeFont(contentStream, "DATA DOMAIN SAP HANA STUDIO INTEGRATION", ++row, 0, true);

        row = writeAnswer(contentStream, row, questionWidth,
                "# of SAP Hana Databases Targeted for Backup",
                int2String(sapHana.getSapHanaDatabasesNum()));

        return row;
    }

    /**
     * Write the DataDomain Management Center Config information.
     *
     * @param contentStream
     *            The content stream
     * @param config
     *            The DataDomain Management Center Config information
     * @param row
     *            the start row number
     * @param questionWidth
     *            the question width
     * @return the new row number
     * @throws IOException
     *             if any IO error occurs
     * @since SRT Phase 3-5 - BRS Tabs Part 2 Assembly
     */
    private int writeDataDomainManagementCenterConfig(PDPageContentStream contentStream,
            DataDomainManagementCenterConfig config, int row, float questionWidth) throws IOException {
        if (config == null) {
            return row;
        }

        row++;
        row = writeFont(contentStream, "DATA DOMAIN MANAGEMENT CENTER CONFIGURATION", ++row, 0, true);

        row = writeAnswer(contentStream, row, questionWidth,
                "Select the type of DDMC Deployment Configuration the Cus",
                enum2String(config.getManagementCenterConfigType()));

        return row;
    }

    /**
     * Write the DataDomain Extended Retention Conversion information.
     *
     * @param contentStream
     *            The content stream
     * @param conversion
     *            The DataDomain Extended Retention Conversion information
     * @param row
     *            the start row number
     * @param questionWidth
     *            the question width
     * @return the new row number
     * @throws IOException
     *             if any IO error occurs
     * @since SRT Phase 3-5 - BRS Tabs Part 2 Assembly
     */
    private int writeDataDomainExtendedRetentionConversion(PDPageContentStream contentStream,
            DataDomainExtendedRetentionConversion conversion, int row, float questionWidth) throws IOException {
        if (conversion == null) {
            return row;
        }

        row++;
        row = writeFont(contentStream, "DATA DOMAIN EXTENDED RETENTION CONVERSION", ++row, 0, true);

        row = writeAnswer(contentStream, row, questionWidth,
                "# of Data Domain Appliances to convert to Extended Retention",
                int2String(conversion.getApplicancesToConvertNum()));

        return row;
    }

    /**
     * Write the DataDomain Boost information.
     *
     * @param contentStream
     *            The content stream
     * @param boost
     *            The DataDomain Boost information
     * @param row
     *            the start row number
     * @param questionWidth
     *            the question width
     * @return the new row number
     * @throws IOException
     *             if any IO error occurs
     * @since SRT Phase 3-5 - BRS Tabs Part 2 Assembly
     */
    private int writeDataDomainBoost(PDPageContentStream contentStream, DataDomainBoost boost, int row,
            float questionWidth) throws IOException {
        if (boost == null) {
            return row;
        }

        row++;
        row = writeFont(contentStream, "DATA DOMAIN BOOST", ++row, 0, true);

        String boostType = lookupEntity2String(boost.getBoostType());

        row = writeAnswer(contentStream, row, questionWidth,
                "DD Boost Implementation Type",
                boostType);

        if ("DD Boost with NBU".equals(boostType) || "DD Boost with RMAN".equals(boostType)) {
            row = writeAnswer(contentStream, row, questionWidth,
                    "# of Data Domain Appliances for DD Boost Implementation",
                    int2String(boost.getAppliancesForDDBoostNum()));
            row = writeAnswer(contentStream, row, questionWidth,
                    "# of servers for DD Boost device installation and configure",
                    int2String(boost.getServersForDDBoostNum()));
        }

        if ("DD Boost with RMAN".equals(boostType)) {
            row = writeAnswer(contentStream, row, questionWidth,
                    "Include RMAN scripting for backup and recovery",
                    bool2String(boost.getIncludeRMANScripting()));
            row = writeAnswer(contentStream, row, questionWidth,
                    "# of Oracle Database Servers for RMAN Backup",
                    int2String(boost.getOracleRMANBackupServersNum()));
            row = writeAnswer(contentStream, row, questionWidth,
                    "# of Oracle databases for Backup Configuration",
                    int2String(boost.getOracleBackupConfigServersNum()));
            row = writeAnswer(contentStream, row, questionWidth,
                    "Backup Window Time is Less than",
                    lookupEntity2String(boost.getMaxBackupWindowTime()));
        }

        return row;
    }

    /**
     * Write the DataDomain Pre-Rack information.
     *
     * @param contentStream
     *            The content stream
     * @param preRack
     *            The DataDomain Pre-Rack information
     * @param row
     *            the start row number
     * @param questionWidth
     *            the question width
     * @return the new row number
     * @throws IOException
     *             if any IO error occurs
     * @since SRT Phase 3-5 - BRS Tabs Part 2 Assembly
     */
    private int writeDataDomainPreRack(PDPageContentStream contentStream, DataDomainPreRack preRack, int row,
            float questionWidth) throws IOException {
        if (preRack == null) {
            return row;
        }

        row++;
        row = writeFont(contentStream, "DATA DOMAIN PRE-RACK", ++row, 0, true);

        row = writeAnswer(contentStream, row, questionWidth,
                "Pre-Racked Implementation Type",
                lookupEntity2String(preRack.getPreRackType()));

        DataDomainBoostBackupServer backupServer = preRack.getBoostBackupServer();

        row = writeFont(contentStream, "Select the backup application server for DD Boost Configuration", ++row,
                0, false);
        row = writeOptions(contentStream, getDataDomainBackupServers(backupServer), row, questionWidth, 2, 70f);

        row = writeAnswer(contentStream, row, questionWidth,
                "Integration with SAP HANA Studio?",
                bool2String(preRack.getIntegrateSapHana()));
        row = writeAnswer(contentStream, row, questionWidth,
                "Select to plan,design,and implement VTL?",
                bool2String(preRack.getPlanDesignImplementVTL()));
        row = writeAnswer(contentStream, row, questionWidth,
                "Include IBM iSeries BRMS Integration",
                bool2String(preRack.getIncludeIBMiseriesBRMS()));

        row = writeAnswer(contentStream, row, questionWidth,
                "# of Pre-Racked System Racks",
                int2String(preRack.getPreRackedSystemRacksNum()));
        row = writeAnswer(contentStream, row, questionWidth,
                "# of backup servers (includes storage nodes / media servers)",
                int2String(preRack.getBackupServersNum()));
        row = writeAnswer(contentStream, row, questionWidth,
                "# of Oracle Database Servers for RMAN Backup",
                int2String(preRack.getOracleRMANBackupServersNum()));
        row = writeAnswer(contentStream, row, questionWidth,
                "# of Oracle Database Servers for Backup Configuration",
                int2String(preRack.getOracleBackupConfigServersNum()));

        if (isBooleanTrue(preRack.getIntegrateSapHana())) {
            row = writeAnswer(contentStream, row, questionWidth,
                    "# of SAP Hana Databases Targeted for Backup",
                    int2String(preRack.getSapHanaDatabasesNum()));
        }
        if (isBooleanTrue(preRack.getPlanDesignImplementVTL())) {
            row = writeAnswer(contentStream, row, questionWidth,
                    "# of EDL Virtual Tape Libraries(VTL)",
                    int2String(preRack.getEdlVirtualTapeLibrariesNum()));
        }

        row = writeAnswer(contentStream, row, questionWidth,
                "# of Servers for DD Boost Device Installation and Config",
                int2String(preRack.getServersForDDBoostNum()));

        if (backupServer != null && backupServer.isNbu()) {
            row = writeAnswer(contentStream, row, questionWidth,
                    "# of Data Domain Appliances for DD Boost Implementation",
                    int2String(preRack.getAppliancesForDDBoostNum()));
        }
        if (isBooleanTrue(preRack.getPlanDesignImplementVTL())) {
            row = writeAnswer(contentStream, row, questionWidth,
                    "# of Data Domain Appliances",
                    int2String(preRack.getVtlAppliancesNum()));
            row = writeAnswer(contentStream, row, questionWidth,
                    "# of Data Domain Fibre Cards to Install",
                    int2String(preRack.getInstallFibreCardsNum()));
            row = writeAnswer(contentStream, row, questionWidth,
                    "# of Data Domain VTLs to Create",
                    int2String(preRack.getCreateVTLsNum()));
        }
        if (isBooleanTrue(preRack.getIncludeIBMiseriesBRMS())) {
            row = writeAnswer(contentStream, row, questionWidth,
                    "# of IBM i LPARS for Backup Configuration",
                    int2String(preRack.getIbmPARsNum()));
        }

        return row;
    }

    /**
     * Write the DataDomain Migration information.
     *
     * @param contentStream
     *            The content stream
     * @param migration
     *            The DataDomain Migration information
     * @param row
     *            the start row number
     * @param questionWidth
     *            the question width
     * @return the new row number
     * @throws IOException
     *             if any IO error occurs
     * @since SRT Phase 3-5 - BRS Tabs Part 2 Assembly
     */
    private int writeDataDomainMigration(PDPageContentStream contentStream, DataDomainMigration migration,
            int row, float questionWidth) throws IOException {
        if (migration == null) {
            return row;
        }

        row++;
        row = writeFont(contentStream, "DATA DOMAIN MIGRATION", ++row, 0, true);

        String migrationType = lookupEntity2String(migration.getMigrationType());

        row = writeAnswer(contentStream, row, questionWidth,
                "Select Data Migration Type",
                migrationType);

        if ("Data Domain to Data Domain".equals(migrationType)
                || "Centera to Data Domain using DixkXtender".equals(migrationType)) {

            row = writeAnswer(contentStream, row, questionWidth,
                    "# of Centera to Data Domain Migrations",
                    int2String(migration.getCentera2ddMigrationsNum()));

            if ("Data Domain to Data Domain".equals(migrationType)) {
                row = writeAnswer(contentStream, row, questionWidth,
                        "# of DD to DD Migrations",
                        int2String(migration.getDd2ddMigrationsNum()));
            }

            row = writeAnswer(contentStream, row, questionWidth,
                    "# of Data Migration Monitoring Events(1 hr.each)",
                    int2String(migration.getMonitoringEventsNum()));
        }

        return row;
    }

    /**
     * Write the DataDomain Health Check information.
     *
     * @param contentStream
     *            The content stream
     * @param healthCheck
     *            The DataDomain Health Check information
     * @param row
     *            the start row number
     * @param questionWidth
     *            the question width
     * @return the new row number
     * @throws IOException
     *             if any IO error occurs
     * @since SRT Phase 3-5 - BRS Tabs Part 2 Assembly
     */
    private int writeDataDomainHealthCheck(PDPageContentStream contentStream, DataDomainHealthCheck healthCheck,
            int row, float questionWidth) throws IOException {
        if (healthCheck == null) {
            return row;
        }

        row++;
        row = writeFont(contentStream, "DATA DOMAIN HEALTHCHECK", ++row, 0, true);

        row = writeAnswer(contentStream, row, questionWidth,
                "# of Data Domain Appliances",
                int2String(healthCheck.getDataDomainAppliancesNum()));
        row = writeAnswer(contentStream, row, questionWidth,
                "# of assessment interviews",
                int2String(healthCheck.getAssessmentInterviewsNum()));

        return row;
    }

    /**
     * Write the DataDomain Integration information.
     *
     * @param contentStream
     *            The content stream
     * @param integration
     *            The DataDomain Integration information
     * @param row
     *            the start row number
     * @param questionWidth
     *            the question width
     * @return the new row number
     * @throws IOException
     *             if any IO error occurs
     * @since SRT Phase 3-5 - BRS Tabs Part 2 Assembly
     */
    private int writeDataDomainIntegration(PDPageContentStream contentStream, DataDomainIntegration integration,
            int row, float questionWidth) throws IOException {
        if (integration == null) {
            return row;
        }

        row++;
        row = writeFont(contentStream, "DATA DOMAIN INTEGRATION", ++row, 0, true);

        String integrationType = lookupEntity2String(integration.getIntegrationType());
        row = writeAnswer(contentStream, row, questionWidth,
                "Data Domain Integration Type",
                integrationType);

        if ("DD Integration Workshop".equals(integrationType)) {
            List<String> backupApps = new ArrayList<String>();

            if (integration.isIbmTivoliStorageManager()) {
                backupApps.add("IBM Tivoli Storage Manager");
            }
            if (integration.isNetworker()) {
                backupApps.add("Networker");
            }
            if (integration.isNetBackup()) {
                backupApps.add("NetBackup");
            }
            if (integration.isRman()) {
                backupApps.add("RMAN");
            }

            row = writeFont(contentStream, "Select Backup Application(s)", ++row, 0, false);
            row = writeOptions(contentStream, backupApps, row, questionWidth, 2, 110f);

            row = writeAnswer(contentStream, row, questionWidth,
                    "# of Interviews to be conducted",
                    int2String(integration.getConductedInterviewsNum()));

            if (integration.isIbmTivoliStorageManager()) {
                row = writeAnswer(contentStream, row, questionWidth,
                        "# of IBM TSM Instances",
                        int2String(integration.getIbmTSMInstancesNum()));
            }
            if (integration.isNetworker()) {
                row = writeAnswer(contentStream, row, questionWidth,
                        "# of Networker DataZones",
                        int2String(integration.getNetworkerDataZonesNum()));
            }
            if (integration.isNetBackup()) {
                row = writeAnswer(contentStream, row, questionWidth,
                        "# of Symantec NetBackup Domains",
                        int2String(integration.getSymantecNetBackupDomainsNum()));
            }
            if (integration.isRman()) {
                row = writeAnswer(contentStream, row, questionWidth,
                        "# of Oracle Data Servers for RMAN",
                        int2String(integration.getOracleDataServersNum()));
            }
        } else if ("DD Integration with RMAN Scripting".equals(integrationType)) {
            row = writeAnswer(contentStream, row, questionWidth,
                    "Include RMAN Scripting for Backup and Recovery",
                    bool2String(integration.getIncludeRMANScripting()));
            row = writeAnswer(contentStream, row, questionWidth,
                    "# of Data Domain Appliances for DD Boost Implementation",
                    int2String(integration.getAppliancesForDDBoostNum()));
            row = writeAnswer(contentStream, row, questionWidth,
                    "# of Servers for DD Boost Device Installation and Configuration",
                    int2String(integration.getServersForDDBoostNum()));
            row = writeAnswer(contentStream, row, questionWidth,
                    "# of Oracle Database Servers for RMAN Backup",
                    int2String(integration.getOracleRMANBackupServersNum()));
            row = writeAnswer(contentStream, row, questionWidth,
                    "# of Oracle Databases for Backup Configuration",
                    int2String(integration.getOracleBackupConfigServersNum()));
            row = writeAnswer(contentStream, row, questionWidth,
                    "Backup Window Time is Less than",
                    lookupEntity2String(integration.getMaxBackupWindowTime()));
        } else if ("DD Integration with SAP Hana Studio".equals(integrationType)) {
            row = writeAnswer(contentStream, row, questionWidth,
                    "# of SAP Hana Databases Targeted for Backup",
                    int2String(integration.getSapHanaDatabasesNum()));
        }

        return row;
    }

    /**
     * Write the DataDomain Data Staging information.
     *
     * @param contentStream
     *            The content stream
     * @param dataStaging
     *            The DataDomain Data Staging information
     * @param row
     *            the start row number
     * @param questionWidth
     *            the question width
     * @return the new row number
     * @throws IOException
     *             if any IO error occurs
     * @since SRT Phase 3-5 - BRS Tabs Part 2 Assembly
     */
    private int writeDataDomainStaging(PDPageContentStream contentStream, DataDomainDataStaging dataStaging,
            int row, float questionWidth) throws IOException {
        if (dataStaging == null) {
            return row;
        }

        row++;
        row = writeFont(contentStream, "DATA STAGING AND RELOCATION", ++row, 0, true);

        row = writeAnswer(contentStream, row, questionWidth,
                "Data Staging and Relocation Environment Type",
                lookupEntity2String(dataStaging.getDataStagingType()));

        return row;
    }

    /**
     * Write the DataDomain Expansion Shelf information.
     *
     * @param contentStream
     *            The content stream
     * @param expansionShelf
     *            The DataDomain Expansion Shelf information
     * @param row
     *            the start row number
     * @param questionWidth
     *            the question width
     * @return the new row number
     * @throws IOException
     *             if any IO error occurs
     * @since SRT Phase 3-5 - BRS Tabs Part 2 Assembly
     */
    private int writeDataDomainExpansionShelf(PDPageContentStream contentStream,
            DataDomainExpansionShelf expansionShelf, int row, float questionWidth) throws IOException {
        if (expansionShelf == null) {
            return row;
        }

        row++;
        row = writeFont(contentStream, "INSTALLATION FOR DATA DOMAIN EXPANSION SHELF", ++row, 0, true);

        row = writeAnswer(contentStream, row, questionWidth,
                "# of Data Domain Storage Expansion Shelves",
                int2String(expansionShelf.getStorageExpansionShelvesNum()));

        return row;
    }

    /**
     * Write the DataDomain VTL information.
     *
     * @param contentStream
     *            The content stream
     * @param vtl
     *            The DataDomain VTL information
     * @param row
     *            the start row number
     * @param questionWidth
     *            the question width
     * @return the new row number
     * @throws IOException
     *             if any IO error occurs
     * @since SRT Phase 3-5 - BRS Tabs Part 2 Assembly
     */
    private int writeDataDomainVTL(PDPageContentStream contentStream, DataDomainVTL vtl, int row,
            float questionWidth) throws IOException {
        if (vtl == null) {
            return row;
        }

        row++;
        row = writeFont(contentStream, "DATA DOMAIN IMPLEMENTATION FOR VIRTUAL TAPE LIBRARY", ++row, 0, true);

        row = writeAnswer(contentStream, row, questionWidth,
                "Include IBM iSeries BRMS Integration",
                bool2String(vtl.getIncludeIBMiseriesBRMS()));
        if (isBooleanTrue(vtl.getIncludeIBMiseriesBRMS())) {
            row = writeAnswer(contentStream, row, questionWidth,
                    "# of IBM i PARs for Backup Configuration",
                    int2String(vtl.getIbmPARsNum()));
        }

        row = writeAnswer(contentStream, row, questionWidth,
                "# of Data Domain Appliances for VTL",
                int2String(vtl.getVtlAppliancesNum()));
        row = writeAnswer(contentStream, row, questionWidth,
                "# of Data Domain Fibre Cards to install",
                int2String(vtl.getInstallFibreCardsNum()));
        row = writeAnswer(contentStream, row, questionWidth,
                "# of Data Domain Emulated VTLs to Create",
                int2String(vtl.getCreateVTLsNum()));

        return row;
    }

    /**
     * Write the DataDomain Upgrade information.
     *
     * @param contentStream
     *            The content stream
     * @param upgrade
     *            The DataDomain Upgrade information
     * @param row
     *            the start row number
     * @param questionWidth
     *            the question width
     * @return the new row number
     * @throws IOException
     *             if any IO error occurs
     * @since SRT Phase 3-5 - BRS Tabs Part 2 Assembly
     */
    private int writeDataDomainUpgrade(PDPageContentStream contentStream, DataDomainUpgrade upgrade, int row,
        float questionWidth) throws IOException {
        if (upgrade == null) {
            return row;
        }

        row++;
        row = writeFont(contentStream, "DATA DOMAIN UPGRADE", ++row, 0, true);

        String upgradeType = lookupEntity2String(upgrade.getUpgradeType());
        row = writeAnswer(contentStream, row, questionWidth, "Type of Upgrade", upgradeType);

        if ("Code Upgrade for DD".equals(upgradeType)) {
            row = writeAnswer(contentStream, row, questionWidth,
                    "# of Data Domain Appliances to Perform DD OS Upgrade",
                    int2String(upgrade.getAppliancesNum()));
        }

        List<String> upgrades = new ArrayList<String>();
        if (upgrade.isDd890()) {
            upgrades.add("DD690,860,880 to DD890            # of Appliances : "
                + int2String(upgrade.getDd890AppliancesNum()));
        }
        if (upgrade.isDd990()) {
            upgrades.add("DD690,860,880,890 to DD990     # of Appliances : "
                + int2String(upgrade.getDd990AppliancesNum()));
        }
        if (upgrade.isDd4200()) {
            upgrades.add("DD690,860,880,890 to DD4200   # of Appliances : "
                + int2String(upgrade.getDd4200AppliancesNum()));
        }
        if (upgrade.isDd4500()) {
            upgrades.add("DD690,860,880,890 to DD4500   # of Appliances : "
                + int2String(upgrade.getDd4500AppliancesNum()));
        }
        if (upgrade.isDd7200()) {
            upgrades.add("DD690,860,880,890 to DD7200   # of Appliances : "
                + int2String(upgrade.getDd7200AppliancesNum()));
        }

        row = writeFont(contentStream, "Type of System Controller Upgrade to Perform", ++row, 0, false);
        row = writeOptions(contentStream, upgrades, row, questionWidth, 1, 200f);

        row = writeAnswer(contentStream, row, questionWidth,
                "# of Data Domain Storage Expansion Shelves",
                int2String(upgrade.getStorageExpansionShelvesNum()));
        row = writeAnswer(contentStream, row, questionWidth,
                "# of Data Domain System Controller Upgrades",
                int2String(upgrade.getSystemControllerUpgradesNum()));

        return row;
    }

    /**
     * Write the DataDomain Implementation information.
     *
     * @param contentStream
     *            The content stream
     * @param page
     *            PDF page
     * @param dataDomain
     *            The DataDomain information
     * @param row
     *            the start row number
     * @param questionWidth
     *            the question width
     * @return the new row number
     * @throws IOException
     *             if any IO error occurs
     * @since SRT Phase 3-5 - BRS Tabs Part 2 Assembly
     */
    private int writeDataDomainImpl(PDPageContentStream contentStream, PDPage page, DataDomain dataDomain,
            int row, float questionWidth) throws IOException {
        DataDomainImplementation impl = dataDomain.getImplementation();
        if (impl == null) {
            return row;
        }

        row++;
        row = writeFont(contentStream, "DATA DOMAIN IMPLEMENTATION", ++row, 0, true);

        row = writeFont(contentStream, "Data Domain Appliance Models that are part of the engagement", ++row, 0, false);

        List<String[]> rows = new ArrayList<String[]>();

        if (impl.getApplianceModels() != null) {
            for (DataDomainImplApplianceModel model : impl.getApplianceModels().values()) {
                String[] columns = new String[8];
                columns[0] = trimToEmpty(model.getModelName());
                columns[1] = int2String(model.getAppliancesNum());
                columns[2] = int2String(model.getExpansionShelvesNum());
                columns[3] = bool2String(model.getIncludeIPReplication());
                String deviceType = lookupEntity2String(model.getDeviceType());
                columns[4] = deviceType;
                columns[5] = bool2String(model.getDbBoost());
                columns[6] = "";
                columns[7] = "";
                if ("Virtual Tape Library".equals(deviceType)) {
                    columns[6] = int2String(model.getEdlVirtualTapeLibrariesNum());
                }
                if ("DB Boost".equals(deviceType)) {
                    columns[7] = int2String(model.getDdBoostServersNum());
                }
                rows.add(columns);
            }
        }

        String[][] contents = new String[rows.size() + 1][8];
        contents[0] = new String[] {"Model", "# of Appliances", "# of Expansion Shelves", "Include IP Replication",
            "Device Type", "DB Boost", "# of VTL's to create",
            "# of DD Boost Servers"};
        for (int i = 0; i < rows.size(); i++) {
            contents[i + 1] = rows.get(i);
        }

        float[] columnsWidth = new float[] {50, 60, 60, 60,
                page.findMediaBox().getWidth() - 2 * DEFAULT_PAGE_PADDING - 390, 50, 55, 55};
        row += drawTable(page, contentStream, getYPos(++row), DEFAULT_PAGE_PADDING, contents, false, columnsWidth);

        row++;

        if (!dataDomain.getDesignImplementationIdentical()) {
            row = writeDataDomainDesignImpl(contentStream, row, questionWidth, impl);
        }

        return row;
    }

    private int writeDataDomainDesignImpl(PDPageContentStream contentStream, int row, float questionWidth,
                                          DataDomainImplBase impl) throws IOException {
        DataDomainBoostBackupServer backupServer = impl.getBoostBackupServer();

        row = writeFont(contentStream, "Select the backup application server for DD Boost Configuration", ++row, 0,
                false);
        row = writeOptions(contentStream, getDataDomainBackupServers(backupServer), row, questionWidth, 2, 70f);

        row = writeAnswer(contentStream, row, questionWidth,
                "Integration with SAP HANA Studio?",
                bool2String(impl.getIntegrateSapHana()));
        row = writeAnswer(contentStream, row, questionWidth,
                "Select to plan,design,and implement VTL?",
                bool2String(impl.getPlanDesignImplementVTL()));

        if (isBooleanTrue(impl.getPlanDesignImplementVTL())) {
            row = writeAnswer(contentStream, row, questionWidth,
                    "Include IBM iSeries BRMS Integration",
                    bool2String(impl.getIncludeIBMiseriesBRMS()));
            row = writeAnswer(contentStream, row, questionWidth,
                    "# of Data Domain Appliances for VTL",
                    int2String(impl.getVtlAppliancesNum()));
            row = writeAnswer(contentStream, row, questionWidth,
                    "# of Data Domain Fibre Cards to install",
                    int2String(impl.getInstallFibreCardsNum()));
            row = writeAnswer(contentStream, row, questionWidth,
                    "# of Data Domain Emulated VTLs to Create",
                    int2String(impl.getCreateVTLsNum()));
            if (isBooleanTrue(impl.getIncludeIBMiseriesBRMS())) {
                row = writeAnswer(contentStream, row, questionWidth,
                        "# of IBM i PARs for Backup Configuration",
                        int2String(impl.getIbmPARsNum()));
            }
        }

        if (backupServer != null && backupServer.isNbu()) {
            row = writeAnswer(contentStream, row, questionWidth,
                    "# of backup servers(includes storage nodes/media servers)",
                    int2String(impl.getBackupServersNum()));
            row = writeAnswer(contentStream, row, questionWidth,
                    "# of DD Appliances for DD Boost Implementation",
                    int2String(impl.getAppliancesForDDBoostNum()));
        }

        if (backupServer != null && backupServer.isRman()) {
            row = writeAnswer(contentStream, row, questionWidth,
                    "# of Oracle Database Servers for RMAN Backup",
                    int2String(impl.getOracleRMANBackupServersNum()));
            row = writeAnswer(contentStream, row, questionWidth,
                    "# of Oracle Database Servers for Backup Configuration",
                    int2String(impl.getOracleBackupConfigServersNum()));
        }

        if (backupServer != null && backupServer.getDdbda()) {
            row = writeAnswer(contentStream, row, questionWidth, "# of DB2 Database Servers",
                int2String(impl.getDb2DatabaseServersNum()));
            row = writeAnswer(contentStream, row, questionWidth, "# of SAP HANA Database Servers",
                int2String(impl.getSapHanaDatabaseServersNum()));
            row = writeAnswer(contentStream, row, questionWidth, "# of SAP HANA Servers with Oracle Databases",
                int2String(impl.getSapHanaServersWithOracleDatabasesNum()));
        }

        if (backupServer != null && backupServer.getDdbma()) {
            row = writeAnswer(contentStream, row, questionWidth, "# of Microsoft SQL Servers",
                int2String(impl.getMicrosoftSQLServersNum()));
        }

        if (isBooleanTrue(impl.getIntegrateSapHana())) {
            row = writeAnswer(contentStream, row, questionWidth,
                    "# of SAP Hana Database Targeted for Backup",
                    int2String(impl.getSapHanaDatabasesNum()));
        }
        return row;
    }

    /**
     * Write the DataDomain Design information.
     *
     * @param contentStream
     *            The content stream
     * @param page
     *            PDF page
     * @param dataDomain
     *            The DataDomain information
     * @param row
     *            the start row number
     * @param questionWidth
     *            the question width
     * @return the new row number
     * @throws IOException
     *             if any IO error occurs
     * @since SRT Phase 3-5 - BRS Tabs Part 2 Assembly
     */
    private int writeDataDomainDesign(PDPageContentStream contentStream, PDPage page, DataDomain dataDomain,
        int row, float questionWidth) throws IOException {
        DataDomainDesign design = dataDomain.getDesign();
        if (design == null) {
            return row;
        }

        row++;
        row = writeFont(contentStream, "DATA DOMAIN DESIGN", ++row, 0, true);

        row = writeFont(contentStream, "Data Domain Appliance Models that are part of the engagement", ++row, 0, false);

        List<String[]> rows = new ArrayList<String[]>();

        if (design.getApplianceModels() != null) {
            for (DataDomainDesignApplianceModel model : design.getApplianceModels().values()) {
                String[] columns = new String[2];
                columns[0] = trimToEmpty(model.getModelName());
                columns[1] = int2String(model.getAppliancesNum());
                rows.add(columns);
            }
        }

        String[][] contents = new String[rows.size() + 1][2];
        contents[0] = new String[] {"Model", "# of Appliances"};
        for (int i = 0; i < rows.size(); i++) {
            contents[i + 1] = rows.get(i);
        }

        row += drawTable(page, contentStream, getYPos(++row), 30, contents, false, null);

        row++;

        if (!dataDomain.getDesignImplementationIdentical()) {
            row = writeDataDomainDesignImpl(contentStream, row, questionWidth, design);
        }

        return row;
    }

    /**
     * Get DataDomain backup servers in scope.
     *
     * @param backupServer
     *            the DataDomain backup servers data
     * @return DataDomain backup servers in scope.
     * @since SRT Phase 3-5 - BRS Tabs Part 2 Assembly
     */
    private static List<String> getDataDomainBackupServers(DataDomainBoostBackupServer backupServer) {

        List<String> options = new ArrayList<String>();

        if (backupServer != null) {
            if (backupServer.isNbu()) {
                options.add("NBU");
            }
            if (backupServer.isRman()) {
                options.add("RMAN");
            }
            if (backupServer.getDdbda()) {
                options.add("DDBDA");
            }
            if (backupServer.getDdbma()) {
                options.add("DDBMA");
            }
        }
        return options;
    }

    /**
     * Get DataDomain activity types in scope.
     *
     * @param dataDomain
     *            the DataDomain data
     * @return DataDomain activity types in scope.
     * @since SRT Phase 3-5 - BRS Tabs Part 2 Assembly
     */
    private static List<String> getDataDomainActivityTypes(DataDomain dataDomain) {

        List<String> options = new ArrayList<String>();

        if (dataDomain != null) {
            if (dataDomain.isDesignActivity()) {
                options.add("Design");
            }
            if (dataDomain.isImplementationActivity()) {
                options.add("Implementation");
            }
        }
        return options;
    }

    /**
     * Get DataDomain services in scope.
     *
     * @param dataDomain
     *            the DataDomain data
     * @return DataDomain services in scope.
     * @since SRT Phase 3-5 - BRS Tabs Part 2 Assembly
     */
    private static List<String> getDataDomainServices(DataDomain dataDomain) {

        List<String> options = new ArrayList<String>();

        if (dataDomain != null) {
            if (dataDomain.isImplementService()) {
                options.add("Implement Data Domain");
            }
            if (dataDomain.isUpgradeService()) {
                options.add("Upgrade Data Domain");
            }
            if (dataDomain.isImplementVTLService()) {
                options.add("Implement Data Domain Virtual Tape Library");
            }
            if (dataDomain.isDataStagingService()) {
                options.add("Data Staging and Replication");
            }
            if (dataDomain.isExpansionShelfService()) {
                options.add("Install Data Domain Expansion Shelf");
            }
            if (dataDomain.isIntegrationService()) {
                options.add("Data Domain Integration");
            }
            if (dataDomain.isHealthCheckService()) {
                options.add("Health Check for Data Domain");
            }
            if (dataDomain.isMigrationService()) {
                options.add("Data Migration for Data Domain");
            }
            if (dataDomain.isPreRackedService()) {
                options.add("Data Domain Pre-Racked");
            }
            if (dataDomain.isBoostService()) {
                options.add("Data Domain Boost");
            }
            if (dataDomain.isExtendedRetentionConversionService()) {
                options.add("Data Domain Extended Retention Conversion");
            }
            if (dataDomain.isManagementCenterConfigService()) {
                options.add("Data Domain Management Center Configuration");
            }
            if (dataDomain.isSapHanaService()) {
                options.add("SAP Hana Studio Integration with Data Domain");
            }
        }
        return options;
    }

    /**
     * Get EDL activity types in scope.
     *
     * @param edl
     *            the EDL data
     * @return EDL activity types in scope.
     * @since SRT Phase 3-5 - BRS Tabs Part 1 Assembly
     */
    private static List<String> getEDLTypes(EDL edl) {

        List<String> options = new ArrayList<String>();

        if (edl != null) {
            if (edl.isDesign()) {
                options.add("Design");
            }
            if (edl.isImplementation()) {
                options.add("Implementation");
            }
        }
        return options;
    }

    /**
     * Get EDL features in scope.
     *
     * @param designImpl
     *            the EDLDesignImpl data
     * @return EDL features in scope.
     * @since SRT Phase 3-5 - BRS Tabs Part 1 Assembly
     */
    private static List<String> getEDLFeatures(EDLDesignImpl designImpl) {

        List<String> options = new ArrayList<String>();

        if (designImpl != null) {
            if (designImpl.isReplication()) {
                options.add("Replication");
            }
            if (designImpl.isAcsls()) {
                options.add("ACSLS");
            }
            if (designImpl.isAutoEngineFailover()) {
                options.add("Auto Engine Failover (AEF)");
            }
            if (designImpl.isIntegratedBackupApplication()) {
                options.add("EDL Integrated Backup Application");
            }
        }
        return options;
    }

    /**
     * Write the EDL information.
     *
     * @param contentStream
     *            The content stream
     * @param edl
     *            The EDL information
     * @param row
     *            the start row number
     * @param questionWidth
     *            the question width
     * @return the new row number
     * @throws IOException
     *             if any IO error occurs
     * @since SRT Phase 3-5 - BRS Tabs Part 1 Assembly
     */
    private int writeEDL(PDPageContentStream contentStream, EDL edl, int row, float questionWidth)
        throws IOException {
        if (edl == null) {
            return row;
        }

        row++;
        row = writeFont(contentStream, "EMC DISK LIBRARY", ++row, 0, true);

        row = writeAnswer(contentStream, row, questionWidth,
                "# of Hours of Knowledge Transfer",
                decimal2String(edl.getKnowledgeTransferHours(), 2));

        row = writeFont(contentStream, "EMC Disk Library Activity Type", ++row, 0, false);
        row = writeOptions(contentStream, getEDLTypes(edl), row, questionWidth, 2, 70f);

        EDLDesignImpl designImpl = edl.getDesignImpl();
        if ((edl.isDesign() || edl.isImplementation()) && designImpl != null) {
            row++;
            row = writeFont(contentStream, "EMC DISK LIBRARY DESIGN AND IMPLEMENTATION", ++row, 0, true);

            row = writeFont(contentStream,
                    "Select EMC Disk Library Features that will be part of this engagement", ++row, 0, false);
            row = writeOptions(contentStream, getEDLFeatures(designImpl), row, questionWidth, 2, 120f);

            row = writeAnswer(contentStream, row, questionWidth,
                    "# of EMC Disk Library Backend Storage Arrays",
                    int2String(designImpl.getBackendStorageArraysNum()));
            row = writeAnswer(contentStream, row, questionWidth,
                    "# of Backup Servers (includes storage nodes / media servers)",
                    int2String(designImpl.getBackupServersNum()));
            row = writeAnswer(contentStream, row, questionWidth,
                    "# of Physical Tape Library Units to Which EMC Disk Library Writes",
                    int2String(designImpl.getPhysicalTapeLibUnitsNum()));
            row = writeAnswer(contentStream, row, questionWidth,
                    "# of EMC Disk Library Virtual Tape Libraries (VTL)",
                    int2String(designImpl.getVirtualTapeLibrariesNum()));
            row = writeAnswer(contentStream, row, questionWidth,
                    "# of EMC Disk Library Virtual Tapes",
                    int2String(designImpl.getVirtualTapesNum()));
            row = writeAnswer(contentStream, row, questionWidth,
                    "# of Virtual Tape Drives",
                    int2String(designImpl.getVirtualTapeDrivesNum()));

            if (designImpl.isReplication()) {
                row = writeAnswer(contentStream, row, questionWidth,
                        "# of EMC Disk Library Replications to Be Created",
                        int2String(designImpl.getReplicationsCreatedNum()));
            }
        }

        return row;
    }

    /**
     * Write the RecoverPoint information.
     *
     * @param contentStream The content stream
     * @param page the PDF page
     * @param rp The RecoverPoint information
     * @param row the start row number
     * @param questionWidth the question width
     * @return the new row number
     * @throws IOException if any IO error occurs
     * @since SRT Phase 3-5 - BRS Tabs Part 1 Assembly
     */
    private int writeRecoverPoint(PDPageContentStream contentStream, PDPage page, RecoverPoint rp, int row,
                                  float questionWidth) throws IOException {
        if (rp == null) {
            return row;
        }

        row++;
        row = writeFont(contentStream, "RECOVERPOINT SERVICES", ++row, 0, true);

        List<String> services = new ArrayList<String>();
        if (rp.getInstallAndImplement()) {
            services.add("RecoverPoint Installation and Implementation");
        }
        if (rp.getUpgradeRPAHardware()) {
            services.add("RPA Hardware Upgrade");
        }
        if (rp.getMigrateIntelligentFabricSplitter()) {
            services.add("Intelligent Fabric Splitter Migration");
        }
        row = writeOptions(contentStream, services, row, questionWidth, 1, 120f);

        if (rp.getInstallAndImplement()) {
            row = writeRecoverPointIntsalAndImpl(contentStream, rp.getInstallationAndImplementation(), row,
                questionWidth);
        }

        if (rp.getUpgradeRPAHardware()) {
            row = writeRecoverPointRPAHradareUpgrade(contentStream, rp.getRpaHardwareUpgrade(), row, questionWidth);
        }
        if (rp.getMigrateIntelligentFabricSplitter()) {
            row = writeRecoverPointIntelligentFabricSplitterMigration(contentStream,
                rp.getIntelligentFabricSplitterMigration(), row, questionWidth);
        }

        return row;
    }

    /**
     * <p>Writes the content of specified RecoverPoint Installation and Implementation section of RecoverPoint tab to
     * specified PDF document.</p>
     *
     * @param contentStream a <code>PDPageContentStream</code> to write content to.
     * @param installationAndImplementation a <code>RecoverPointInstallationAndImplementation</code> object providing
     * the content of RecoverPoint Installation and Implementation section of RecoverPoint tab.
     * @param row an <code>int</code> providing the current row number to start writing from.
     * @param questionWidth a <code>float</code> providing the with of the column.
     * @return an <code>int</code> providing the new row number.
     * @throws IOException if an I/O error occurs.
     * @since 2.14
     */
    private int writeRecoverPointIntsalAndImpl(PDPageContentStream contentStream,
                                               RecoverPointInstallationAndImplementation installationAndImplementation,
                                               int row, float questionWidth)
        throws IOException {
        if (installationAndImplementation == null) {
            return row;
        }

        row++;
        row = writeFont(contentStream, "RECOVERPOINT INSTALLATION AND IMPLEMENTATION", ++row, 0, true);

        row = writeFont(contentStream, "Delivery Options", ++row, 0, false);
        List<String> deliveryOptions = new ArrayList<String>();
        if (getBooleanValue(installationAndImplementation.getDeliveryOptionDesign())) {
            deliveryOptions.add("Design");
        }
        if (getBooleanValue(installationAndImplementation.getDeliveryOptionImplementation())) {
            deliveryOptions.add("Implementation");
        }
        row = writeOptions(contentStream, deliveryOptions, row, questionWidth, 1, 120f);
        RecoverPointOption recoverPointOption = installationAndImplementation.getRecoverPointOption();
        row = writeAnswer(contentStream, row, questionWidth, "RecoverPoint Option",
            lookupEntity2String(recoverPointOption));
        row = writeFont(contentStream, "RecoverPoint Replication Method", ++row, 0, false);
        List<String> replicationMethodOptions = new ArrayList<String>();
        if (getBooleanValue(installationAndImplementation.getLocalReplicationMethod())) {
            replicationMethodOptions.add("Local");
        }
        if (getBooleanValue(installationAndImplementation.getRemoteReplicationMethod())) {
            replicationMethodOptions.add("Remote");
        }
        row = writeOptions(contentStream, replicationMethodOptions, row, questionWidth, 1, 120f);
        row = writeAnswer(contentStream, row, questionWidth, "Include Cluster Enabler?",
            bool2String(installationAndImplementation.getIncludeClusterEnabler()));
        if (recoverPointOption != null) {
            row = writeAnswer(contentStream, row, questionWidth, "RecoverPoint Splitter Type",
                lookupEntity2String(installationAndImplementation.getRecoverPointSplitterType()));
        }
        row = writeFont(contentStream, "Select Storage Arrays involved", ++row, 0, false);
        List<String> storageArrayTypes = new ArrayList<String>();
        if (getBooleanValue(installationAndImplementation.getVnxOrClariionInvolved())) {
            storageArrayTypes.add("VNX or CLARiiON");
        }
        if (getBooleanValue(installationAndImplementation.getVmaxDMXorSYMMInvolved())) {
            storageArrayTypes.add("VMAX DMX or SYMM");
        }
        if (getBooleanValue(installationAndImplementation.getNonEMCor3rdPartyStorageInvolved())) {
            storageArrayTypes.add("3rd Party or Non-EMC Storage");
        }
        if (getBooleanValue(installationAndImplementation.getNoSourceArrayInvolved())) {
            storageArrayTypes.add("No Source Array");
        }
        if (getBooleanValue(installationAndImplementation.getXtremIOClusterInvolved())) {
            storageArrayTypes.add("XtremeIO Cluster");
        }
        row = writeOptions(contentStream, storageArrayTypes, row, questionWidth, 1, 120f);

        if (getBooleanValue(installationAndImplementation.getDeliveryOptionDesign()) ||
            getBooleanValue(installationAndImplementation.getDeliveryOptionImplementation())) {

            row = writeAnswer(contentStream, row, questionWidth, "# of Existing Physical Hosts?",
                int2String(installationAndImplementation.getNumberOfExistingPhysicalHosts()));
            row = writeAnswer(contentStream, row, questionWidth, "# of Existing ESX Servers (Not Virtual Machines)?",
                int2String(installationAndImplementation.getNumberOfExistingESXServers()));
            row =
                writeAnswer(contentStream, row, questionWidth, "# of client / servers / ESX servers in RP Environment?",
                    int2String(installationAndImplementation.getNumberOfRPEnvironmentClientsServers()));
            row = writeAnswer(contentStream, row, questionWidth,
                "# of RecoverPoint Appliances (Count each RPA Separately)?",
                int2String(installationAndImplementation.getNumberOfRPAppliances()));
            row = writeAnswer(contentStream, row, questionWidth, "# of Storage Systems Requiring Splitter?",
                int2String(installationAndImplementation.getNumberOfStorageSystemsRequiringSplitter()));
        }

        row =
            writeAnswer(contentStream, row, questionWidth, "Include Bandwidth Analysis as Part of Planning and Design?",
                bool2String(installationAndImplementation.getIncludeBandwidthAnalysis()));
        row = writeAnswer(contentStream, row, questionWidth,
            "Dispatch EMC Team to Customer's Remote Site to Install RPA?",
            bool2String(installationAndImplementation.getDispatchEMCTeam()));

        if (installationAndImplementation.getNonEMCor3rdPartyStorageInvolved()) {
            row = writeAnswer(contentStream, row, questionWidth, "Include 3rd Party Storage Array Planning and Design?",
                bool2String(installationAndImplementation.getInclude3rdPartyStorageArrayPlanningAndDesign()));
            row = writeAnswer(contentStream, row, questionWidth, "Include 3rd Party Storage Array Integration?",
                bool2String(installationAndImplementation.getInclude3rdPartyStorageArrayIntegration()));
            row = writeAnswer(contentStream, row, questionWidth, "# of Non-EMC Storage Arrays?",
                int2String(installationAndImplementation.getNumberOfNonEMCStorageArrays()));
        }

        if ((recoverPointOption != null) && (recoverPointOption.getId() == 1)) {
            row = writeAnswer(contentStream, row, questionWidth,
                "Include RecoverPoint Integration within existing Replication Manager Environment?",
                bool2String(installationAndImplementation.getIncludeReplicationManagerEnvironmentIntegration()));
            row = writeAnswer(contentStream, row, questionWidth,
                "Include RecoverPoint Integration with an existing VMWare vCenter Site?",
                bool2String(installationAndImplementation.getIncludeVMWarevCenterSiteIntegration()));
        }

        if (getBooleanValue(installationAndImplementation.getIncludeClusterEnabler())) {
            row = writeAnswer(contentStream, row, questionWidth,
                "# of Microsoft Clusters /Failover Cluster to be managed by CE?",
                int2String(installationAndImplementation.getNumberOfMicrosoftFailoverClusters()));
            row = writeAnswer(contentStream, row, questionWidth, "# of RecoverPoint/CE Cluster Nodes?",
                int2String(installationAndImplementation.getNumberOfRPCEClusterNodes()));
            row = writeAnswer(contentStream, row, questionWidth,
                "# of RecoverPoint Consistency Groups to be Converted to CE Cluster Groups?",
                int2String(installationAndImplementation.getNumberOfRPConsistencyGroups()));
        }
        return row;
    }

    /**
     * <p>Writes the content of specified Intelligent Fabric Splitter Migration section of RecoverPoint tab to specified
     * PDF document.</p>
     *
     * @param contentStream a <code>PDPageContentStream</code> to write content to.
     * @param intelligentFabricSplitterMigration a <code>IntelligentFabricSplitterMigration</code> object providing the
     * content of Intelligent Fabric Splitter Migration section of RecoverPoint tab.
     * @param row an <code>int</code> providing the current row number to start writing from.
     * @param questionWidth a <code>float</code> providing the with of the column.
     * @return an <code>int</code> providing the new row number.
     * @throws IOException if an I/O error occurs.
     * @since 2.14
     */
    private int writeRecoverPointIntelligentFabricSplitterMigration(PDPageContentStream contentStream,
                                                                    IntelligentFabricSplitterMigration intelligentFabricSplitterMigration,
                                                                    
                                                                    int row, float questionWidth) throws IOException {

        if (intelligentFabricSplitterMigration == null) {
            return row;
        }

        row++;
        row = writeFont(contentStream, "INTELLIGENT FABRIC SPLITTER MIGRATION", ++row, 0, true);

        IntelligentFabricMigrationMethod intelligentFabricMigrationMethod =
            intelligentFabricSplitterMigration.getIntelligentFabricMigrationMethod();
        row = writeAnswer(contentStream, row, questionWidth, "Intelligent Fabric Migration Method",
            lookupEntity2String(intelligentFabricMigrationMethod));
        row = writeAnswer(contentStream, row, questionWidth, "Will host data gathering (Grid Analysis) be Required?",
            bool2String(intelligentFabricSplitterMigration.getGridAnalysisRequired()));

        if (intelligentFabricMigrationMethod != null) {
            if (intelligentFabricMigrationMethod.getId() == 1 || intelligentFabricMigrationMethod.getId() == 2) {
                row = writeFont(contentStream, "Select Storage Arrays involved", ++row, 0, false);
                List<String> storageArrayTypes = new ArrayList<String>();
                if (getBooleanValue(intelligentFabricSplitterMigration.getVnxOrClariionInvolved())) {
                    storageArrayTypes.add("VNX or CLARiiON");
                }
                if (getBooleanValue(intelligentFabricSplitterMigration.getVmaxDMXorSYMMInvolved())) {
                    storageArrayTypes.add("VMAX DMX or SYMM");
                }
                if (getBooleanValue(intelligentFabricSplitterMigration.getNonEMCor3rdPartyStorageInvolved())) {
                    storageArrayTypes.add("3rd Party or Non-EMC Storage");
                }
                if (getBooleanValue(intelligentFabricSplitterMigration.getNoSourceArrayInvolved())) {
                    storageArrayTypes.add("No Source Array");
                }
                if (getBooleanValue(intelligentFabricSplitterMigration.getXtremIOClusterInvolved())) {
                    storageArrayTypes.add("XtremeIO Cluster");
                }
                row = writeOptions(contentStream, storageArrayTypes, row, questionWidth, 1, 120f);

                row = writeAnswer(contentStream, row, questionWidth,
                    "# of RPA Clusters to be Migrated Off of IF splitters?",
                    int2String(intelligentFabricSplitterMigration.getNumberOfRPAClustersToMigrate()));
                row = writeAnswer(contentStream, row, questionWidth,
                    "# of Hosts Using RPA Volumes to be Migrated Off of IF Splitters?",
                    int2String(intelligentFabricSplitterMigration.getNumberOfRPAVolumesHostsToMigrate()));
            } else if (intelligentFabricMigrationMethod.getId() >= 3 && intelligentFabricMigrationMethod.getId() <= 6) {
                row = writeAnswer(contentStream, row, questionWidth,
                    "Include Bandwidth Analysis as Part of Planning and Design?",
                    bool2String(intelligentFabricSplitterMigration.getIncludeBandwidthAnalysis()));
                row = writeAnswer(contentStream, row, questionWidth,
                    "Include 3rd Party Storage Array Planning and Design?",
                    bool2String(intelligentFabricSplitterMigration.getInclude3rdPartyStorageArrayPlanningAndDesign()));
                row = writeAnswer(contentStream, row, questionWidth, "RecoverPoint Option",
                    lookupEntity2String(intelligentFabricSplitterMigration.getRecoverPointOption()));

                if (intelligentFabricMigrationMethod.getId() <= 4) {
                    row = writeAnswer(contentStream, row, questionWidth, "# of VPLEX Clusters?",
                        int2String(intelligentFabricSplitterMigration.getNumberOfVPLEXClusters()));
                    row = writeAnswer(contentStream, row, questionWidth, "# of Volumes to Encapsulate?",
                        int2String(intelligentFabricSplitterMigration.getNumberOfEncapsulatedVolumes()));
                }

                row = writeAnswer(contentStream, row, questionWidth,
                    "# of Encapsulation Events by a Single EMC Resource?",
                    int2String(intelligentFabricSplitterMigration.getNumberOfEncapsulationEventsPerEMCResource()));

                if (intelligentFabricMigrationMethod.getId() <= 4) {
                    row = writeAnswer(contentStream, row, questionWidth, "# of Hosts to be Encapsulated into VPLEX?",
                        int2String(intelligentFabricSplitterMigration.getNumberOfHostVPLEXEncapsulations()));
                }

                row = writeAnswer(contentStream, row, questionWidth, "# of Hours in Maintenance Windows?",
                    decimal2String(intelligentFabricSplitterMigration.getMaintenanceWindowsHours(), 2));
                row = writeAnswer(contentStream, row, questionWidth,
                    "# of client / servers / ESX servers in RP Environment?",
                    int2String(intelligentFabricSplitterMigration.getNumberOfRPEnvironmentClientsServers()));

                row = writeFont(contentStream, "RecoverPoint Replication Method", ++row, 0, false);
                List<String> replicationMethodOptions = new ArrayList<String>();
                if (getBooleanValue(intelligentFabricSplitterMigration.getLocalReplicationMethod())) {
                    replicationMethodOptions.add("Local");
                }
                if (getBooleanValue(intelligentFabricSplitterMigration.getRemoteReplicationMethod())) {
                    replicationMethodOptions.add("Remote");
                }
                row = writeOptions(contentStream, replicationMethodOptions, row, questionWidth, 1, 120f);
            }
        }

        return row;
    }

    /**
     * <p>Writes the content of specified RPA Hardware Upgrade section of RecoverPoint tab to specified PDF document.
     * </p>
     *
     * @param contentStream a <code>PDPageContentStream</code> to write content to.
     * @param rpaHardwareUpgrade a <code>RPAHardwareUpgrade</code> object providing the content of RPA Hardware Upgrade
     * section of RecoverPoint tab.
     * @param row an <code>int</code> providing the current row number to start writing from.
     * @param questionWidth a <code>float</code> providing the with of the column.
     * @return an <code>int</code> providing the new row number.
     * @throws IOException if an I/O error occurs.
     * @since 2.14
     */
    private int writeRecoverPointRPAHradareUpgrade(PDPageContentStream contentStream,
                                                   RPAHardwareUpgrade rpaHardwareUpgrade, int row, float questionWidth)
        throws IOException {

        if (rpaHardwareUpgrade == null) {
            return row;
        }

        row++;
        row = writeFont(contentStream, "RPA HARDWARE UPGRADE", ++row, 0, true);

        row = writeAnswer(contentStream, row, questionWidth, "Is the RP Upgrade Being Done on GEN1 RPA Hardware?",
            bool2String(rpaHardwareUpgrade.getGen1RPAHardwareUsed()));
        row = writeAnswer(contentStream, row, questionWidth, "# of RPAs to be Upgraded?",
            int2String(rpaHardwareUpgrade.getNumberOfRPAsToUpgrade()));

        return row;
    }

    /**
     * Write the VPLEX information.
     *
     * @param contentStream
     *            The content stream
     * @param vi
     *            The VPLEX information
     * @param row
     *            the start row number
     * @param questionWidth
     *            the question width
     * @return the new row number
     * @throws IOException
     *             if any IO error occurs
     * @since SRT Phase 3-5 - BRS Tabs Part 1 Assembly
     */
    private int writeVplex(PDPageContentStream contentStream, Vplex vi, int row, float questionWidth)
        throws IOException {
        if (vi == null) {
            return row;
        }

        row++;
        row = writeFont(contentStream, "VPLEX", ++row, 0, true);

        row = writeAnswer(contentStream, row, questionWidth,
                "# of Hours of Knowledge Transfer",
                decimal2String(vi.getKnowledgeTransferHours(), 2));

        row = writeAnswer(contentStream, row, questionWidth,
                "# of sites to install VPlex",
                int2String(vi.getSitesNumber()));
        row = writeAnswer(contentStream, row, questionWidth,
                "# of VPlex engines to install (total)",
                int2String(vi.getEngineNumber()));
        row = writeAnswer(contentStream, row, questionWidth,
                "# of VPlex directors to install (total)",
                int2String(vi.getDirectorsNumber()));
        row = writeAnswer(contentStream, row, questionWidth,
                "# of existing CX4 arrays to be upgraded",
                int2String(vi.getExistingC4UpgradedNumber()));
        row = writeAnswer(contentStream, row, questionWidth,
                "# of VPlex Virtual Volumes",
                int2String(vi.getVirtualVolumesNumber()));
        row = writeAnswer(contentStream, row, questionWidth,
                "# of VPlex Mirrors",
                int2String(vi.getMirrorsNumber()));
        row = writeAnswer(contentStream, row, questionWidth,
                "# of VPlex MetroClusters to configure",
                int2String(vi.getMetroClustersNumber()));
        row = writeAnswer(contentStream, row, questionWidth,
                "# of VPlex GeoClusters to configure",
                int2String(vi.getGeoClustersNumber()));
        row = writeAnswer(contentStream, row, questionWidth,
                "# of hosts using VPlex",
                int2String(vi.getHostsNumber()));
        row = writeAnswer(contentStream, row, questionWidth,
                "# of arrays attached to VPlex",
                int2String(vi.getArraysNumber()));
        row = writeAnswer(contentStream, row, questionWidth,
                "# of storage ports dedicated to VPlex",
                int2String(vi.getStoragePortsNumber()));
        row = writeAnswer(contentStream, row, questionWidth,
                "# of storage volumes imported into VPlex",
                int2String(vi.getStorageVolumesNumber()));
        row = writeAnswer(contentStream, row, questionWidth,
                "# of VPlex Witness Servers",
                int2String(vi.getWitnessServerNumber()));
        row = writeAnswer(contentStream, row, questionWidth,
                "Type of data mobility to be implemented",
                lookupEntity2String(vi.getDataMobilityType()));
        row = writeAnswer(contentStream, row, questionWidth,
                "# of data mobility jobs",
                int2String(vi.getDataMobilityJobsNumber()));
        row = writeAnswer(contentStream, row, questionWidth,
                "# of hosts to have data encapsulated",
                int2String(vi.getEncapsulatedHostsNumber()));
        row = writeAnswer(contentStream, row, questionWidth,
                "Will hardware be installed in a customer's rack by EMC?",
                bool2String(vi.getEmcInstalledOption()));
        row = writeAnswer(contentStream, row, questionWidth,
                "Does RecoverPoint have to be installed with VPLEX?",
                bool2String(vi.getRecoverPointInstalledOption()));

        return row;
    }

    /**
     * Get Atmos services in scope.
     *
     * @param servicesScope
     *            the Atmos services scope
     * @return Atmos services in scope.
     * @since SRT Phase 3-1 - Atmos Centera and Vblock Tabs Assembly
     */
    private static List<String> getAtmosServices(AtmosCenteraServicesScope servicesScope) {

        List<String> options = new ArrayList<String>();
        if (servicesScope != null) {
            if (servicesScope.isCenteraDesignImpl()) {
                options.add("Centera Design & Implementation");
            }
            if (servicesScope.isCenteraToAtmosMig()) {
                options.add("Centera to Atmos Data Migration");
            }
            if (servicesScope.isAcdp()) {
                options.add("Atmos Cloud Delivery Platform (ACDP)");
            }
            if (servicesScope.isAtmosDesignImpl()) {
                options.add("ATMOS Design & Implementation");
            }
            if (servicesScope.isCua()) {
                options.add("Centera Universal Access (CUA)");
            }
            if (servicesScope.isCva()) {
                options.add("Centera Virtual Archive (CVA))");
            }
            if (servicesScope.isCicm()) {
                options.add("Centera Intra Cluster Migration (CICM)");
            }
            if (servicesScope.isCenteraFileErasure()) {
                options.add("Centera File Erasure");
            }
            if (servicesScope.isExpansionNodeOnly()) {
                options.add("Expansion Node");
            }
        }
        return options;
    }

    /**
     * Write Atmos request data.
     *
     * @param contentStream
     *            the stream
     * @param atmosRequestData
     *            the atmosRequestData
     * @param row
     *            the start row number
     * @param page
     *            the PDF page
     * @return the new row number
     * @throws IOException
     *             if any IO error occurs
     * @since SRT Phase 3-1 - Atmos Centera and Vblock Tabs Assembly
     */
    private int writeAtmosRequestData(PDPageContentStream contentStream, AtmosCenteraRequestData atmosRequestData,
            int row, PDPage page) throws IOException {
        float questionWidth = 280f;
        row = writeFont(contentStream, "Services & Activities - Atmos Centeras", ++row, 0, true);

        // General information
        row++;

        row = writeFont(contentStream, "GENERAL INFORMATION", ++row, 0, true);
        row = writeAnswer(contentStream, row, questionWidth,
                "Do you have a high-level design that shows existing and proposed end state?",
                bool2String(atmosRequestData.getHaveHighLevelDesign()));
        row = writeAnswer(contentStream, row, questionWidth,
                "# of sites involved",
                lookupEntity2String(atmosRequestData.getSitesInvolved()));
        row = writeAnswer(contentStream, row, questionWidth,
                "# days of knowledge transfer",
                decimal2String(atmosRequestData.getDaysOfKnowledgeTransfer(), 2));
        row = writeAnswer(contentStream, row, questionWidth,
                "Does the customer currently have Centera frames onsite?",
                bool2String(atmosRequestData.getCustomerHasCentera()));
        row = writeAnswer(contentStream, row, questionWidth,
                "General Comments",
                trimToEmpty(atmosRequestData.getGeneralComment()));

        // Services scope
        AtmosCenteraServicesScope servicesScope = atmosRequestData.getServicesScope();
        row++;
        row = writeFont(contentStream, "SERVICES TO BE SCOPED IN THIS BOE", ++row, 0, true);
        List<String> options = getAtmosServices(servicesScope);
        row = writeOptions(contentStream, options, ++row, 0, 1, 200f);

        if (servicesScope != null) {
            if (servicesScope.isCenteraDesignImpl()) {
                row = writeCenteraDesignImpl(contentStream, atmosRequestData.getCenteraDesignImpl(), row, page);
            }
            if (servicesScope.isAtmosDesignImpl()) {
                row = writeAtmosDesignImpl(contentStream, atmosRequestData.getAtmosDesignImpl(), row, page);
            }
            if (servicesScope.isCenteraToAtmosMig()) {
                row = writeCenteraToAtmosMigration(contentStream, atmosRequestData.getCenteraToAtmosMigration(),
                        row, page);
            }
            if (servicesScope.isCua()) {
                row = writeCenteraUniversalAccess(contentStream, atmosRequestData.getCenteraUniversalAccess(),
                        row, page);
            }
            if (servicesScope.isCicm()) {
                row = writeCenteraIntraClusterMigration(contentStream,
                        atmosRequestData.getCenteraIntraClusterMigration(), row, page);
            }
            if (servicesScope.isCenteraFileErasure()) {
                row = writeCenteraFileErasure(contentStream, atmosRequestData.getCenteraFileErasure(), row, page);
            }
            if (servicesScope.isExpansionNodeOnly()) {
                row = writeExpansionNodeOnly(contentStream, atmosRequestData.getExpansionNodeOnly(), row, page);
            }
        }

        return row;
    }

    /**
     * Write CenteraToAtmosMigration info.
     *
     * @param contentStream
     *            the stream
     * @param mig
     *            the CenteraToAtmosMigration info
     * @param row
     *            the start row number
     * @param page
     *            the PDF page
     * @return the new row number
     * @throws IOException
     *             if any IO error occurs
     * @since SRT Phase 3-1 - Atmos Centera and Vblock Tabs Assembly
     */
    private int writeCenteraToAtmosMigration(PDPageContentStream contentStream,
            CenteraToAtmosMigration mig, int row, PDPage page) throws IOException {

        if (mig != null) {
            float questionWidth = 280f;
            row++;
            row = writeFont(contentStream, "CENTERA TO ATMOS DATA MIGRATION", ++row, 0, true);

            row = writeAnswer(contentStream, row, questionWidth,
                    "# of applications to be migrated to Atmos",
                    int2String(mig.getApplicationsNum()));
            row = writeAnswer(contentStream, row, questionWidth,
                    "Choose Centera Protection Type",
                    mig.getProtectionType() == null ? "" : mig.getProtectionType().toString());
            row = writeAnswer(contentStream, row, questionWidth,
                    "Amount of data (in TB) to be migrated to Atmos",
                    int2String(mig.getDataAmount()));
        }
        return row;
    }

    /**
     * Write CenteraFileErasure info.
     *
     * @param contentStream
     *            the stream
     * @param erasure
     *            the CenteraFileErasure info
     * @param row
     *            the start row number
     * @param page
     *            the PDF page
     * @return the new row number
     * @throws IOException
     *             if any IO error occurs
     * @since SRT Phase 3-1 - Atmos Centera and Vblock Tabs Assembly
     */
    private int writeCenteraFileErasure(PDPageContentStream contentStream,
            CenteraFileErasure erasure, int row, PDPage page) throws IOException {

        if (erasure != null) {
            float questionWidth = 280f;
            row++;
            row = writeFont(contentStream, "CENTERA FILE ERASURE", ++row, 0, true);

            row = writeAnswer(contentStream, row, questionWidth,
                    "# of Centera Clips to be deleted (in millions) - MAX: 25 million",
                    int2String(erasure.getClipsToDeleteNum()));
        }
        return row;
    }

    /**
     * Write CenteraUniversalAccess info.
     *
     * @param contentStream
     *            the stream
     * @param cua
     *            the CenteraUniversalAccess info
     * @param row
     *            the start row number
     * @param page
     *            the PDF page
     * @return the new row number
     * @throws IOException
     *             if any IO error occurs
     * @since SRT Phase 3-1 - Atmos Centera and Vblock Tabs Assembly
     */
    private int writeCenteraUniversalAccess(PDPageContentStream contentStream,
            CenteraUniversalAccess cua, int row, PDPage page) throws IOException {

        if (cua != null) {
            float questionWidth = 280f;
            row++;
            row = writeFont(contentStream, "CENTERA UNIVERSAL ACCESS", ++row, 0, true);

            row = writeAnswer(contentStream, row, questionWidth,
                    "# of active CUAs to add to this Centera at this location",
                    int2String(cua.getActiveCUAsNum()));
            row = writeAnswer(contentStream, row, questionWidth,
                    "# of data pools required on this CUA",
                    int2String(cua.getDataPoolsNum()));
            row = writeAnswer(contentStream, row, questionWidth,
                    "# of standby CUAs to add to this Centera at this location",
                    int2String(cua.getStandbyCUAsNum()));
            row = writeAnswer(contentStream, row, questionWidth,
                    "CUA Hardware Type",
                    lookupEntity2String(cua.getCuaHardwareType()));
            row = writeAnswer(contentStream, row, questionWidth,
                    "# of active or standby CUAs to be relocated",
                    int2String(cua.getRelocatedCUAsNum()));
        }
        return row;
    }

    /**
     * Write CenteraIntraClusterMigration info.
     *
     * @param contentStream
     *            the stream
     * @param cicm
     *            the CenteraIntraClusterMigration info
     * @param row
     *            the start row number
     * @param page
     *            the PDF page
     * @return the new row number
     * @throws IOException
     *             if any IO error occurs
     * @since SRT Phase 3-1 - Atmos Centera and Vblock Tabs Assembly
     */
    private int writeCenteraIntraClusterMigration(PDPageContentStream contentStream,
            CenteraIntraClusterMigration cicm, int row, PDPage page) throws IOException {

        if (cicm != null) {
            float questionWidth = 280f;
            row++;
            row = writeFont(contentStream, "CENTERA INTRA CLUSTER MIGRATION CICM", ++row, 0, true);

            row = writeAnswer(contentStream, row, questionWidth,
                    "# of Centera source cubes",
                    int2String(cicm.getSourceCubesNum()));
            row = writeAnswer(contentStream, row, questionWidth,
                    "# of Centera target cubes",
                    int2String(cicm.getTargetCubesNum()));
            row = writeAnswer(contentStream, row, questionWidth,
                    "# of new nodes to be added to this Centera for CICM?",
                    int2String(cicm.getNewNodesNum()));
            row = writeAnswer(contentStream, row, questionWidth,
                    "# of nodes to be removed from this Centera by CICM?",
                    int2String(cicm.getRemovedNodesNum()));
            row = writeAnswer(contentStream, row, questionWidth,
                    "Are any of the existing nodes GEN3?",
                    bool2String(cicm.getExistingNodesGEN3()));
        }
        return row;
    }

    /**
     * Write ExpansionNodeOnly info.
     *
     * @param contentStream
     *            the stream
     * @param expansionNode
     *            the ExpansionNodeOnly info
     * @param row
     *            the start row number
     * @param page
     *            the PDF page
     * @return the new row number
     * @throws IOException
     *             if any IO error occurs
     * @since SRT Phase 3-1 - Atmos Centera and Vblock Tabs Assembly
     */
    private int writeExpansionNodeOnly(PDPageContentStream contentStream,
            ExpansionNodeOnly expansionNode, int row, PDPage page) throws IOException {

        if (expansionNode != null) {
            float questionWidth = 280f;
            row++;
            row = writeFont(contentStream, "EXPANSION NODE ONLY", ++row, 0, true);

            row = writeAnswer(contentStream, row, questionWidth,
                    "Number of Atmos FLEX kits to be installed",
                    int2String(expansionNode.getFlexKitsNum()));
        }
        return row;
    }

    /**
     * Write AtmosDesignImpl info.
     *
     * @param contentStream
     *            the stream
     * @param atmosDesignImpl
     *            the AtmosDesignImpl info
     * @param row
     *            the start row number
     * @param page
     *            the PDF page
     * @return the new row number
     * @throws IOException
     *             if any IO error occurs
     * @since SRT Phase 3-1 - Atmos Centera and Vblock Tabs Assembly
     */
    private int writeAtmosDesignImpl(PDPageContentStream contentStream,
            AtmosDesignImpl atmosDesignImpl, int row, PDPage page) throws IOException {

        if (atmosDesignImpl != null) {
            float questionWidth = 280f;
            row++;
            row = writeFont(contentStream, "ATMOS DESIGN & IMPLEMENTATION", ++row, 0, true);

            row = writeAnswer(contentStream, row, questionWidth,
                    "Include Atmos Cloud Delivery Platform?",
                    bool2String(atmosDesignImpl.getIncludeACDP()));
            row = writeAnswer(contentStream, row, questionWidth,
                    "# of RMGs for base Hardware and Software of Atmos",
                    int2String(atmosDesignImpl.getRmgsNum()));
            row = writeAnswer(contentStream, row, questionWidth,
                    "# of RMGs for base software for Atmos VE",
                    int2String(atmosDesignImpl.getRmgsVENum()));
            row = writeAnswer(contentStream, row, questionWidth,
                    "# of Atmos Installation Segments (IS)",
                    int2String(atmosDesignImpl.getInstallationSegmentsNum()));
            row = writeAnswer(contentStream, row, questionWidth,
                    "Is the cabinet type WS2-360?",
                    bool2String(atmosDesignImpl.getCabinetTypeWS2()));
            row = writeAnswer(contentStream, row, questionWidth,
                    "# of Atmos Hardware Servers to Install",
                    int2String(atmosDesignImpl.getHardwareServersNum()));
            row = writeAnswer(contentStream, row, questionWidth,
                    "# of CIFS servers to configure within Atmos",
                    int2String(atmosDesignImpl.getCifsServersNum()));
            row = writeAnswer(contentStream, row, questionWidth,
                    "# of NFS servers to configure within Atmos",
                    int2String(atmosDesignImpl.getNfsServersNum()));
            row = writeAnswer(contentStream, row, questionWidth,
                    "# of IFS servers to configure within Atmos",
                    int2String(atmosDesignImpl.getIfsServersNum()));
            row = writeAnswer(contentStream, row, questionWidth,
                    "# of WS servers to configure within Atmos",
                    int2String(atmosDesignImpl.getWsServersNum()));
            row = writeAnswer(contentStream, row, questionWidth,
                    "# of tenants to be created",
                    int2String(atmosDesignImpl.getTenantsNum()));
            row = writeAnswer(contentStream, row, questionWidth,
                    "# of subtenants to be created",
                    int2String(atmosDesignImpl.getSubTenantsNum()));
            row = writeAnswer(contentStream, row, questionWidth,
                    "# of policies to be created",
                    int2String(atmosDesignImpl.getPoliciesNum()));
            row = writeAnswer(contentStream, row, questionWidth,
                    "Include secondary site for ACDP?",
                    bool2String(atmosDesignImpl.getIncludeSecondaryACDPSite()));
        }
        return row;
    }

    /**
     * Write CenteraDesignImpl info.
     *
     * @param contentStream
     *            the stream
     * @param centeraDesignImpl
     *            the CenteraDesignImpl info
     * @param row
     *            the start row number
     * @param page
     *            the PDF page
     * @return the new row number
     * @throws IOException
     *             if any IO error occurs
     * @since SRT Phase 3-1 - Atmos Centera and Vblock Tabs Assembly
     */
    private int writeCenteraDesignImpl(PDPageContentStream contentStream,
            CenteraDesignImpl centeraDesignImpl, int row, PDPage page) throws IOException {

        if (centeraDesignImpl != null) {
            float questionWidth = 280f;
            row++;
            row = writeFont(contentStream, "CENTERA DESIGN & IMPLEMENTATION", ++row, 0, true);

            row = writeAnswer(contentStream, row, questionWidth,
                    "Do any (in-Scope) Centeras exist in the environment?",
                    bool2String(centeraDesignImpl.getCenterasExist()));

            boolean centerasExist = centeraDesignImpl.getCenterasExist() != null
                    && centeraDesignImpl.getCenterasExist();

            if (centerasExist) {
                Boolean requireReview = centeraDesignImpl.getExistingCenterasRequireReview();
                row = writeAnswer(contentStream, row, questionWidth,
                        "Does the existing Centeras require an Architecture Review?",
                        bool2String(requireReview));

                if (requireReview != null && requireReview) {
                    row = writeAnswer(contentStream, row, questionWidth,
                            "Details",
                            trimToEmpty(centeraDesignImpl.getExistingCenterasReviewDetail()));
                }

                boolean showHardwareRepurposing = false;
                boolean showRelocate = false;

                // Existing clusters
                List<ExistingCenteraCluster> existingClusters = centeraDesignImpl.getExistingClusters();
                if (existingClusters != null && !existingClusters.isEmpty()) {
                    String[] fields = new String[] {
                            "Existing In-Scope Centeras / Clusters",
                            "Existing Centera Location",
                            "Existing Centera serial number (mandatory)",
                            "Existing Centera modem number or ESRS",
                            "Existing Centera edition",
                            "Existing Centera generation",
                            "Does this array/cluster require a HealthCheck?",
                            "What is the replication target for this Centera (or N/A)?",
                            "What is/will be the C2C migration source for this Centera (or N/A)?",
                            "What is/will be the C2C migration target for this Centera (or N/A)?",
                            "Will there be a CICM on this Centera?",
                            "List any new applications that will be writing to the Centera",
                            "What will happen to this array as part of this project?",
                            "Is Certified Data Erasure Required?",
                            "Is Data Deletion Required?",
                            "Can the customer provide a clip list for partial erasure?"
                    };
                    List<String[]> content = createDynColTableContent(fields, existingClusters.size());

                    for (int i = 1; i <= existingClusters.size(); i++) {
                        ExistingCenteraCluster cluster = existingClusters.get(i - 1);
                        int rowNum = 0;
                        content.get(rowNum++)[i] = "Existing " + i;
                        content.get(rowNum++)[i] = trimToEmpty(cluster.getLocation());
                        content.get(rowNum++)[i] = trimToEmpty(cluster.getSerialNumber());
                        content.get(rowNum++)[i] = trimToEmpty(cluster.getModemNumber());
                        content.get(rowNum++)[i] = lookupEntity2String(cluster.getEdition());
                        content.get(rowNum++)[i] = lookupEntity2String(cluster.getGeneration());
                        content.get(rowNum++)[i] = lookupEntity2String(cluster.getHealthCheck());
                        content.get(rowNum++)[i] = trimToEmpty(cluster.getReplicationTarget());
                        content.get(rowNum++)[i] = trimToEmpty(cluster.getMigrationSource());
                        content.get(rowNum++)[i] = trimToEmpty(cluster.getMigrationTarget());
                        content.get(rowNum++)[i] = bool2String(cluster.getCicm());
                        content.get(rowNum++)[i] = trimToEmpty(cluster.getApplicationsWritting());
                        content.get(rowNum++)[i] = lookupEntity2String(cluster.getArrayAction());
                        content.get(rowNum++)[i] = bool2String(cluster.getCertifiedDataErasureRequired());
                        content.get(rowNum++)[i] = bool2String(cluster.getDataDeletionRequired());
                        content.get(rowNum++)[i] = bool2String(cluster.getCustomerClipList());

                        if (cluster.getArrayAction() != null) {
                            if ("Hardware Repurposing".equals(cluster.getArrayAction().getName())) {
                                showHardwareRepurposing = true;
                            }
                            if ("Relocate".equals(cluster.getArrayAction().getName())) {
                                showRelocate = true;
                            }
                        }
                    }

                    row += drawDynColTable(page, contentStream, getYPos(++row), 30, 242, 90,
                            content.toArray(new String[content.size()][]));
                    row++;
                }

                if (showHardwareRepurposing) {
                    row = writeAnswer(contentStream, row, questionWidth,
                            "Provide detail for any hardware repurposing",
                            trimToEmpty(centeraDesignImpl.getHardwareRepurposingDetail()));
                }
                if (showRelocate) {
                    row = writeAnswer(contentStream, row, questionWidth,
                            "Provide detail for any array/cluster relocation",
                            trimToEmpty(centeraDesignImpl.getArrayRelocationDetail()));
                    row = writeAnswer(contentStream, row, questionWidth,
                            "Who arranges shipping for relocation?",
                            lookupEntity2String(centeraDesignImpl.getShippingArranger()));

                    if (centeraDesignImpl.getShippingArranger() != null
                            && "EMC".equals(centeraDesignImpl.getShippingArranger().getName())) {

                        row = writeFont(contentStream, "Submit forms to price equipment packaging and relocation",
                                ++row, 0, false, questionWidth);
                        drawHyperLink(contentStream, page, row, "EMC Logistics Shipping",
                                "http://www.logistics.isus.emc.com/default.asp", questionWidth + DEFAULT_PAGE_PADDING);
                    }
                }
            } // End existing clusters


            // New clusters
            List<NewCenteraCluster> newClusters = centeraDesignImpl.getNewClusters();
            if (newClusters != null && !newClusters.isEmpty()) {
                String[] fields = new String[] {
                        "New Centeras / Clusters",
                        "New Centera Location",
                        "New Centera edition",
                        "New Centera generation",
                        "What protection scheme will each new Centera use?",
                        "How many nodes will each new Centera have?",
                        "What will be the replication target for this Centera?",
                        "What will be the C2C migration source for this Centera?",
                        "Will this be located at the target site during the migration?",
                        "Will this be moved from the target site after the migration?",
                        "List the applications that will be writing to the Centera"
                };
                List<String[]> content = createDynColTableContent(fields, newClusters.size());

                for (int i = 1; i <= newClusters.size(); i++) {
                    NewCenteraCluster cluster = newClusters.get(i - 1);
                    int rowNum = 0;
                    content.get(rowNum++)[i] = "New " + i;
                    content.get(rowNum++)[i] = trimToEmpty(cluster.getLocation());
                    content.get(rowNum++)[i] = lookupEntity2String(cluster.getEdition());
                    content.get(rowNum++)[i] = lookupEntity2String(cluster.getGeneration());
                    content.get(rowNum++)[i] = lookupEntity2String(cluster.getProtectionScheme());
                    content.get(rowNum++)[i] = int2String(cluster.getNodesNum());
                    content.get(rowNum++)[i] = trimToEmpty(cluster.getReplicationTarget());
                    content.get(rowNum++)[i] = trimToEmpty(cluster.getMigrationSource());
                    content.get(rowNum++)[i] = bool2String(cluster.getLocatedAtTargetSite());
                    content.get(rowNum++)[i] = bool2String(cluster.getMovedFromTargetSite());
                    content.get(rowNum++)[i] = trimToEmpty(cluster.getApplicationsWritting());
                }

                row += drawDynColTable(page, contentStream, getYPos(++row), 30, 242, 90,
                        content.toArray(new String[content.size()][]));
                row++;
            }

            row = writeAnswer(contentStream, row, questionWidth,
                    "Does EMC need to develop code for new home-grown applications to connect to Centera?",
                    bool2String(centeraDesignImpl.getNeedDevelopCode()));
            if (centeraDesignImpl.getNeedDevelopCode() != null && centeraDesignImpl.getNeedDevelopCode()) {
                row = writeAnswer(contentStream, row, questionWidth,
                        "Details",
                        trimToEmpty(centeraDesignImpl.getDevelopCodeDetail()));
            }

            row = writeAnswer(contentStream, row, questionWidth,
                    "Are there custom scripting or reporting requirements?",
                    bool2String(centeraDesignImpl.getCustomScripting()));
            if (centeraDesignImpl.getCustomScripting() != null && centeraDesignImpl.getCustomScripting()) {
                row = writeAnswer(contentStream, row, questionWidth,
                        "Details",
                        trimToEmpty(centeraDesignImpl.getCustomScriptingDetail()));
            }

            row = writeAnswer(contentStream, row, questionWidth,
                    "Define the customers expected timeline",
                    trimToEmpty(centeraDesignImpl.getExpectedTimeline()));
            row = writeAnswer(contentStream, row, questionWidth,
                    "Is there Centera replication today, or are we adding a replica?",
                    lookupEntity2String(centeraDesignImpl.getReplicationType()));
            row = writeAnswer(contentStream, row, questionWidth,
                    "Will Tape Backup of Centera be implemented?",
                    bool2String(centeraDesignImpl.getImplementTapeBackup()));
        }
        return row;
    }

    /**
     * Draw hyperlink.
     *
     * @param contentStream
     *            the content stream
     * @param page
     *            the PDF page
     * @param row
     *            the row number
     * @param link
     *            the link name
     * @param url
     *            the link url
     * @param startx
     *            the start x
     * @throws IOException
     *             if any IO error occurs
     * @since SRT Phase 3-1 - Atmos Centera and Vblock Tabs Assembly
     */
    @SuppressWarnings("unchecked")
    private static void drawHyperLink(PDPageContentStream contentStream, PDPage page, int row,
            String link, String url,
            float startx) throws IOException {

        float y = getYPos(row);
        contentStream.beginText();
        contentStream.setFont(FONT_TEXT, DEFAULT_FONT_SIZE);

        contentStream.setNonStrokingColor(Color.BLUE);

        contentStream.moveTextPositionByAmount(startx, y);

        contentStream.drawString(link);

        contentStream.endText();
        contentStream.setNonStrokingColor(Color.BLACK);

        PDActionURI action = new PDActionURI();
        action.setURI(url);

        PDRectangle position = new PDRectangle();
        position.setLowerLeftX(startx);
        position.setLowerLeftY(y + DEFAULT_FONT_SIZE);
        position.setUpperRightX(startx + FONT_TEXT.getStringWidth(link) / 1000 * DEFAULT_FONT_SIZE);
        position.setUpperRightY(y);

        PDAnnotationLink txtLink = new PDAnnotationLink();
        txtLink.setAction(action);
        txtLink.setRectangle(position);
        page.getAnnotations().add(txtLink);
    }

    /**
     * Get Vblock types to implement.
     *
     * @param designImpl
     *            the VblockDesignImpl data
     * @return Vblock types to implement.
     * @since SRT Phase 3-1 - Atmos Centera and Vblock Tabs Assembly
     */
    private static List<String> getVblockTypes(VblockDesignImpl designImpl) {

        List<String> options = new ArrayList<String>();
        if (designImpl != null) {
            if (designImpl.isVnxType()) {
                options.add("VBlock Type 1 (VNX)");
            }
            if (designImpl.isSymmetrixType()) {
                options.add("VBlock Type 2 (Symmetrix)");
            }
        }
        return options;
    }

    /**
     * Get Vblock services required.
     *
     * @param services
     *            the Vblock services data
     * @return Vblock services required.
     * @since SRT Phase 3-1 - Atmos Centera and Vblock Tabs Assembly
     */
    private static List<String> getVblockServices(VblockServices services) {

        List<String> options = new ArrayList<String>();
        if (services != null) {
            if (services.isDesignImpl()) {
                options.add("Design and Implementation");
            }
            if (services.isInfrastructure()) {
                options.add("Implementation for Vblock Infrastructure");
            }
            if (services.isTechAssessment()) {
                options.add("Technical Assessment for Vblock Infrastructure");
            }
        }
        return options;
    }

    /**
     * Write Vblock request data.
     *
     * @param contentStream
     *            the stream
     * @param vblockRequestData
     *            the vblockRequestData
     * @param row
     *            the start row number
     * @param page
     *            the PDF page
     * @return the new row number
     * @throws IOException
     *             if any IO error occurs
     * @since SRT Phase 3-1 - Atmos Centera and Vblock Tabs Assembly
     */
    private int writeVblockRequestData(PDPageContentStream contentStream,
            VblockRequestData vblockRequestData, int row, PDPage page) throws IOException {
        float questionWidth = 280f;
        row = writeFont(contentStream, "Services & Activities - Vblock", ++row, 0, true);

        // General information
        row++;

        row = writeFont(contentStream, "GENERAL INFORMATION", ++row, 0, true);
        row = writeAnswer(contentStream, row, questionWidth,
                "Describe Options",
                trimToEmpty(vblockRequestData.getDescribeOptions()));
        row = writeAnswer(contentStream, row, questionWidth,
                "General Comments",
                trimToEmpty(vblockRequestData.getGeneralComment()));

        // Services
        row++;
        row = writeFont(contentStream, "SERVICES TO BE SCOPED IN THIS BOE", ++row, 0, true);

        VblockServices services = vblockRequestData.getServices();

        if (services != null) {
            row = writeFont(contentStream, "Which VCE Vblock services are required?", ++row, 0, false);
            row = writeOptions(contentStream, getVblockServices(services), row, questionWidth, 1, 200f);

            if (services.isDesignImpl()) {
                row = writeVblockDesignImpl(contentStream, vblockRequestData.getDesignImpl(), row, page);
            }
            if (services.isInfrastructure()) {
                row = writeVblockInfra(contentStream, vblockRequestData.getInfrastructure(), row, page);
            }
            if (services.isTechAssessment()) {
                row = writeVblockTechAssessment(contentStream, vblockRequestData.getTechAssessment(), row, page);
            }
            row = writeVblockProject(contentStream, vblockRequestData.getProject(), row, page);
        }

        return row;
    }

    /**
     * Write VblockProject info.
     *
     * @param contentStream
     *            the stream
     * @param project
     *            the VblockProject info
     * @param row
     *            the start row number
     * @param page
     *            the PDF page
     * @return the new row number
     * @throws IOException
     *             if any IO error occurs
     * @since SRT Phase 3-1 - Atmos Centera and Vblock Tabs Assembly
     */
    private int writeVblockProject(PDPageContentStream contentStream,
            VblockProject project, int row, PDPage page) throws IOException {

        if (project != null) {
            float questionWidth = 280f;
            row++;
            row = writeFont(contentStream, "PROJECT DESCRIPTION", ++row, 0, true);

            row = writeAnswer(contentStream, row, questionWidth,
                    "Fill out the Infrastructure, Unified and VMware tabs as appropriate "
                    + "and provide a description of the custom project here, including the USE CASE details.",
                    trimToEmpty(project.getCustomProjectDescription()));
        }
        return row;
    }

    /**
     * Write VblockTechAssessment info.
     *
     * @param contentStream
     *            the stream
     * @param techAssessment
     *            the VblockTechAssessment info
     * @param row
     *            the start row number
     * @param page
     *            the PDF page
     * @return the new row number
     * @throws IOException
     *             if any IO error occurs
     * @since SRT Phase 3-1 - Atmos Centera and Vblock Tabs Assembly
     */
    private int writeVblockTechAssessment(PDPageContentStream contentStream,
            VblockTechAssessment techAssessment, int row, PDPage page) throws IOException {

        if (techAssessment != null) {
            float questionWidth = 280f;
            row++;
            row = writeFont(contentStream, "TECHNICAL ASSESSMENT FOR VBLOCK INFRASTRUCTURE", ++row, 0, true);

            row = writeAnswer(contentStream, row, questionWidth,
                    "# of sites to be assessed",
                    int2String(techAssessment.getAssessedSites()));
            row = writeAnswer(contentStream, row, questionWidth,
                    "# of servers identified for VMWare consolidation",
                    int2String(techAssessment.getVmwareIdentifiedServersNum()));
        }
        return row;
    }

    /**
     * Write VblockInfrastructure info.
     *
     * @param contentStream
     *            the stream
     * @param infra
     *            the VblockInfrastructure info
     * @param row
     *            the start row number
     * @param page
     *            the PDF page
     * @return the new row number
     * @throws IOException
     *             if any IO error occurs
     * @since SRT Phase 3-1 - Atmos Centera and Vblock Tabs Assembly
     */
    private int writeVblockInfra(PDPageContentStream contentStream,
            VblockInfrastructure infra, int row, PDPage page) throws IOException {

        if (infra != null) {
            float questionWidth = 280f;
            row++;
            row = writeFont(contentStream, "IMPLEMENTATION FOR VBLOCK INFRASTRUCTURE", ++row, 0, true);

            row = writeAnswer(contentStream, row, questionWidth,
                    "# of Vblock 300 Series to be installed?",
                    int2String(infra.getVblockSeries300Num()));
            row = writeAnswer(contentStream, row, questionWidth,
                    "# of Vblock 700 Series to be installed?",
                    int2String(infra.getVblockSeries700Num()));
        }
        return row;
    }

    /**
     * Write VblockDesignImpl info.
     *
     * @param contentStream
     *            the stream
     * @param designImpl
     *            the VblockDesignImpl info
     * @param row
     *            the start row number
     * @param page
     *            the PDF page
     * @return the new row number
     * @throws IOException
     *             if any IO error occurs
     * @since SRT Phase 3-1 - Atmos Centera and Vblock Tabs Assembly
     */
    private int writeVblockDesignImpl(PDPageContentStream contentStream,
            VblockDesignImpl designImpl, int row, PDPage page) throws IOException {

        if (designImpl != null) {
            float questionWidth = 280f;
            row++;
            row = writeFont(contentStream, "DESIGN AND IMPLEMENTATION", ++row, 0, true);

            row = writeFont(contentStream, "Select the Vblock type(s) to implement", ++row, 0, false);
            row = writeOptions(contentStream, getVblockTypes(designImpl), row, questionWidth, 1, 200f);

            if (designImpl.isVnxType()) {
                row = writeAnswer(contentStream, row, questionWidth,
                        "# of VBlock Type 1 Luns required (estimate)",
                        int2String(designImpl.getVnxLunsNum()));
            }
            if (designImpl.isSymmetrixType()) {
                row = writeAnswer(contentStream, row, questionWidth,
                        "# of VBlock Type 2 Luns required (estimate)",
                        int2String(designImpl.getSymmetrixLunsNum()));
            }

            row = writeAnswer(contentStream, row, questionWidth,
                    "Include Unified File Option",
                    bool2String(designImpl.getIncludeUnifiedFile()));
            row = writeAnswer(contentStream, row, questionWidth,
                    "Include Ionix UIM",
                    bool2String(designImpl.getIncludeIonixUIM()));

            row = writeAnswer(contentStream, row, questionWidth,
                    "# of type 1 Vsphere servers?",
                    int2String(designImpl.getType1VsphereServersNum()));
            row = writeAnswer(contentStream, row, questionWidth,
                    "# of type 2 Vsphere servers?",
                    int2String(designImpl.getType2VsphereServersNum()));
            row = writeAnswer(contentStream, row, questionWidth,
                    "# of hours for Vblock Cisco partner?",
                    decimal2String(designImpl.getCiscoPartnerHours(), 2));
            row = writeAnswer(contentStream, row, questionWidth,
                    "# of hours for Vblock VmWare partner?",
                    decimal2String(designImpl.getVmwarePartnerHours(), 2));
            row = writeAnswer(contentStream, row, questionWidth, "# of Type 1 LUNs (estimate)?",
                int2String(designImpl.getNumberOfType1LUNs()));
            row = writeAnswer(contentStream, row, questionWidth, "# of Type 2 LUNs (estimate)?",
                int2String(designImpl.getNumberOfType2LUNs()));
            row = writeAnswer(contentStream, row, questionWidth, "# of Unified File Type 1 (VG2)?",
                int2String(designImpl.getNumberOfUnifiedFileType1()));
            row = writeAnswer(contentStream, row, questionWidth, "# of Unified File Type 2 (VG8)?",
                int2String(designImpl.getNumberOfUnifiedFileType2()));
        }
        return row;
    }

    /**
     * Write ViPR request data.
     *
     * @param contentStream
     *            the stream
     * @param viprRequestData
     *            the viprRequestData
     * @param row
     *            the start row number
     * @param page
     *            the PDF page
     * @return the new row number
     * @throws IOException
     *             if any IO error occurs
     * @since SRT Phase 3-3 - Implement Isilon and ViPR Tabs Assembly
     */
    private int writeViprRequestData(PDPageContentStream contentStream,
            ViprRequestData viprRequestData, int row, PDPage page) throws IOException {
        float questionWidth = 350f;
        row = writeFont(contentStream, "Services & Activities - ViPR", ++row, 0, true);

        // General information
        row++;
        row = writeFont(contentStream, "GENERAL INFORMATION", ++row, 0, true);
        row = writeAnswer(contentStream, row, questionWidth,
                "# of Hours of Knowledge Transfer",
                decimal2String(viprRequestData.getKnowledgeTransferHours(), 2));
        row = writeAnswer(contentStream, row, questionWidth,
                "General Comment", trimToEmpty(viprRequestData.getGeneralComment()));

        if (viprRequestData.getPlanningDesignImplementation()) {
            row = writeViprRequestDataImplementation(contentStream, viprRequestData, row, questionWidth);
        }

        if (viprRequestData.getDataMigrationWithPPME()) {
            row = writeViprDataMigrationWithPPME(contentStream, viprRequestData.getViprDataMigrationWithPPME(), row,
                questionWidth);
        }

        if (viprRequestData.getDesignImplementationForServiceOnCommodity()) {
            row = writeViprDataServiceOnCommodityDesignImplementation(contentStream,
                viprRequestData.getViprDataServiceOnCommodityDesignImpl(), row, questionWidth);
        }

        if (viprRequestData.getEcsApplianceDesignImplementation()) {
            row = writeViprECSApplianceDesignImplementation(contentStream, viprRequestData.getEcsApplianceDesignImpl(),
                row, questionWidth);
        }

        return row;
    }

    /**
     * <p>Writes the content of specified ViPR Data Migration with PPME section of VIPR tab to specified PDF document.
     * </p>
     *
     * @param contentStream a <code>PDPageContentStream</code> to write content to.
     * @param viprDataMigrationWithPPME a <code>ViprDataMigrationPPME</code> object providing the content of ViPR Data
     * Migration with PPME section of VIPR tab.
     * @param row an <code>int</code> providing the current row number to start writing from.
     * @param questionWidth a <code>float</code> providing the with of the column.
     * @return an <code>int</code> providing the new row number.
     * @throws IOException if an I/O error occurs.
     * @since 2.10
     */
    private int writeViprDataMigrationWithPPME(PDPageContentStream contentStream,
                                               ViprDataMigrationPPME viprDataMigrationWithPPME, int row,
                                               float questionWidth) throws IOException {

        if (viprDataMigrationWithPPME == null) {
            return row;
        }

        row++;
        row = writeFont(contentStream, "VIPR DATA MIGRATION WITH PPME", ++row, 0, true);
        row++;

        if (getBooleanValue(viprDataMigrationWithPPME.getPlanningAndDesign())
            || getBooleanValue(viprDataMigrationWithPPME.getImplementationAndMigration())) {

            row = writeFont(contentStream, "Select the level of EMC involvement for the data migration", ++row, 0,
                false);

            List<String> hardwareActivities = new ArrayList<String>();
            if (getBooleanValue(viprDataMigrationWithPPME.getPlanningAndDesign())) {
                hardwareActivities.add("Planning and Design");
            }
            if (getBooleanValue(viprDataMigrationWithPPME.getImplementationAndMigration())) {
                hardwareActivities.add("Implementation and Migration");
            }
            row = writeOptions(contentStream, hardwareActivities, row, questionWidth, 1, 120f);

            row = writeAnswer(contentStream, row, questionWidth, "Does the customer want to do the migration work " +
                "themselves?", bool2String(viprDataMigrationWithPPME.getCustomerWantsToDoMigrationWorkThemselves()));
            if (getBooleanValue(viprDataMigrationWithPPME.getCustomerWantsToDoMigrationWorkThemselves())) {
                row = writeAnswer(contentStream, row, questionWidth, "Will EMC provide onsite support? (EMC does not " +
                    "perform the actual migration work)", bool2String(viprDataMigrationWithPPME.getEmcOnsiteSupport()));
            }
            HostBasedMigrationTool hostBasedMigrationTool = viprDataMigrationWithPPME.getHostBasedMigrationTool();
            row = writeAnswer(contentStream, row, questionWidth, "Choose the host-based migration tool to be used",
                hostBasedMigrationTool == null ? "" : hostBasedMigrationTool.getName());
            row = writeAnswer(contentStream, row, questionWidth, "Include ESX host migration via Storage vMotion?",
                bool2String(viprDataMigrationWithPPME.getIncludeESXHostMigrationViaVMotion()));
            row = writeAnswer(contentStream, row, questionWidth, "Include second round of data gathering (for larger " +
                "or long migration projects)?",
                bool2String(viprDataMigrationWithPPME.getIncludeSecondRoundOfDataGathering()));
            row = writeAnswer(contentStream, row, questionWidth, "Include Environment Collection Appliance (ECA)?",
                bool2String(viprDataMigrationWithPPME.getIncludeECA()));

            row = writeFont(contentStream, "Select Storage Arrays involved", ++row, 0, false);
            List<String> storageArrayTypes = new ArrayList<String>();
            if (getBooleanValue(viprDataMigrationWithPPME.getStorageArrayVNXorCLARiiON())) {
                storageArrayTypes.add("VNX or CLARiiON");
            }
            if (getBooleanValue(viprDataMigrationWithPPME.getStorageArrayVMAXorDMAXorSYMM())) {
                storageArrayTypes.add("VMAX, DMX, or SYMM");
            }
            if (getBooleanValue(viprDataMigrationWithPPME.getStorageArray3rdPartyOrNonEMCStorage())) {
                storageArrayTypes.add("3rd Party or Non-EMC Storage");
            }
            if (getBooleanValue(viprDataMigrationWithPPME.getStorageArrayNoSourceArray())) {
                storageArrayTypes.add("No Source Array");
            }
            if (getBooleanValue(viprDataMigrationWithPPME.getStorageArrayXtremeIOCluster())) {
                storageArrayTypes.add("XtremeIO Cluster");
            }
            row = writeOptions(contentStream, storageArrayTypes, row, questionWidth, 1, 120f);

            row = writeAnswer(contentStream, row, questionWidth, "# of existing physical hosts",
                int2String(viprDataMigrationWithPPME.getNumberOfExistingPhysicalHosts()));
            row = writeAnswer(contentStream, row, questionWidth, "# of existing ESX Servers (not Virtual Machines)",
                int2String(viprDataMigrationWithPPME.getNumberOfExistingESXServers()));
            row = writeAnswer(contentStream, row, questionWidth, "Swing frame required for migration?",
                bool2String(viprDataMigrationWithPPME.getSwingFrameRequiredForMigration()));
            row = writeAnswer(contentStream, row, questionWidth, "Total # of source arrays involved in a migration",
                int2String(viprDataMigrationWithPPME.getTotalNumberOfSourceArrayInvolvedInMigration()));
            row = writeAnswer(contentStream, row, questionWidth, "Total # of target arrays involved in a migration",
                int2String(viprDataMigrationWithPPME.getTotalNumberOfTargetArraysInvolvedInMigration()));
            row = writeAnswer(contentStream, row, questionWidth, "Does the data migration include device-size changes?",
                bool2String(viprDataMigrationWithPPME.getDataMigrationIncludesDeviceSizeChanges()));
            row = writeAnswer(contentStream, row, questionWidth, "% of servers requiring LUN size changes",
                decimal2String(viprDataMigrationWithPPME.getPercentOfServersRequiringLUNSizeChanges(), 2));
            row = writeAnswer(contentStream, row, questionWidth, "Amount of source data to be migrated in TB",
                int2String(viprDataMigrationWithPPME.getAmountOfSourceDataToBeMigratedInTB()));
            row = writeAnswer(contentStream, row, questionWidth, "# of hosts to be migrated via PowerPath Migration " +
                "Enabler by EMC",
                int2String(viprDataMigrationWithPPME.getNumberOfHostsToBeMigratedViaPowerPathMigrationEnablerByEMC()));
            row = writeAnswer(contentStream, row, questionWidth, "# of VMware Virtual Machines to Storage vMontion",
                int2String(viprDataMigrationWithPPME.getNumberOfVMWareVirtualMachinesToStorageVMontion()));
        }

        if (getBooleanValue(viprDataMigrationWithPPME.getPlanningAndDesign())
            && viprDataMigrationWithPPME.getPpmePlanningDesign() != null) {

            row++;
            row = writeFont(contentStream, "PLANNING AND DESIGN", ++row, 0, true);

            ViprDataMigrationPPMEPlanningDesign ppmePlanningDesign = viprDataMigrationWithPPME.getPpmePlanningDesign();
            row = writeAnswer(contentStream, row, questionWidth, "# of source and target sites (total)",
                int2String(ppmePlanningDesign.getTotalNumberOfSourceAndTargetSites()));
            row = writeAnswer(contentStream, row, questionWidth, "# of new physical hosts included in design",
                int2String(ppmePlanningDesign.getNumberOfNewPhysicalHostsIncluded()));
            row = writeAnswer(contentStream, row, questionWidth, "# of new ESX Servers in design",
                int2String(ppmePlanningDesign.getNumberOfNewESXServers()));
            row = writeAnswer(contentStream, row, questionWidth, "# of New Enterprise Directors",
                int2String(ppmePlanningDesign.getNumberOfNewEnterpriseDirectors()));
            row = writeAnswer(contentStream, row, questionWidth, "# of New Departmental Switches",
                int2String(ppmePlanningDesign.getNumberOfNewDepartmentalSwitches()));
            row = writeAnswer(contentStream, row, questionWidth, "# of new VNX Block storage arrays",
                int2String(ppmePlanningDesign.getNumberOfNewVNXBlockStorageArrays()));
            row = writeAnswer(contentStream, row, questionWidth, "% for Data Migration Complexity Factor",
                decimal2String(ppmePlanningDesign.getPercentForDataMigrationComplexityFactor(), 2));
            row = writeAnswer(contentStream, row, questionWidth, "# of new Symmetrix storage arrays",
                int2String(ppmePlanningDesign.getNumberOfNewSymmetrixStorageArrays()));
            row = writeAnswer(contentStream, row, questionWidth, "# of VNX Block arrays to be upgraded",
                int2String(ppmePlanningDesign.getNumberOfVNXBlocksToUpgrade()));
            row = writeAnswer(contentStream, row, questionWidth, "# of Symmetrix to be upgraded",
                int2String(ppmePlanningDesign.getNumberOfSymmetrixToUpgrade()));
            if (getBooleanValue(viprDataMigrationWithPPME.getStorageArrayXtremeIOCluster())) {
                row = writeAnswer(contentStream, row, questionWidth, "# of XtremIO clusters",
                    int2String(ppmePlanningDesign.getNumberOfXtremeIOClusters()));
            }
            if (getBooleanValue(viprDataMigrationWithPPME.getStorageArray3rdPartyOrNonEMCStorage())) {
                row = writeAnswer(contentStream, row, questionWidth, "# of non-EMC storage arrays",
                    int2String(ppmePlanningDesign.getNumberOfNonEMCStorageArrays()));
            }
        }

        if (getBooleanValue(viprDataMigrationWithPPME.getImplementationAndMigration()) &&
            viprDataMigrationWithPPME.getPpmeImplementationMigration() != null) {

            row++;
            row = writeFont(contentStream, "IMPLEMENTATION AND MIGRATION", ++row, 0, true);

            ViprDataMigrationPPMEImplementationMigration ppmeImplementationMigration =
                viprDataMigrationWithPPME.getPpmeImplementationMigration();

            row = writeFont(contentStream, "Include the Following Hardware Activities", ++row, 0, false);
            List<String> services = new ArrayList<String>();
            if (getBooleanValue(ppmeImplementationMigration.getRemoveExistingEMCStorage())) {
                services.add("Remove Existing EMC Storage");
            }
            if (getBooleanValue(ppmeImplementationMigration.getRelocateAndReinstallExistingEMCStorage())) {
                services.add("Relocate and Reinstall Existing EMC Storage");
            }
            row = writeOptions(contentStream, services, row, questionWidth, 1, 120f);

            row = writeAnswer(contentStream, row, questionWidth, "Include Data Erasure of Storage?",
                bool2String(ppmeImplementationMigration.getIncludeDataErasureOfStorage()));
            if (getBooleanValue(viprDataMigrationWithPPME.getStorageArrayVMAXorDMAXorSYMM())) {
                row = writeAnswer(contentStream, row, questionWidth, "Include Additional BIN File work?",
                    bool2String(ppmeImplementationMigration.getIncludeAdditionalBINFileWork()));
                if (getBooleanValue(ppmeImplementationMigration.getIncludeAdditionalBINFileWork())) {
                    row = writeAnswer(contentStream, row, questionWidth, "# of BIN Files to be designed and implemented",
                        int2String(ppmeImplementationMigration.getNumberOfBinFilesToBeDesignedAndImplemented()));
                    row = writeAnswer(contentStream, row, questionWidth, "# of hours per BIN File for design and " +
                        "implementation", decimal2String(ppmeImplementationMigration.getNumberOFHoursPerBINFile(), 2));
                }
            }
            if (getBooleanValue(viprDataMigrationWithPPME.getStorageArrayXtremeIOCluster())) {
                row = writeAnswer(contentStream, row, questionWidth, "Include XtremIO clusters 2-brick or 4-brick " +
                    "configurations?",
                    bool2String(ppmeImplementationMigration.getIncludeXtremIOClusters24BricksConfigurations()));
            }
            row = writeAnswer(contentStream, row, questionWidth, "Amount of source data to be migrated in TB",
                int2String(ppmeImplementationMigration.getAmountOfSourceDataToBeMigratedInTB()));
            row = writeAnswer(contentStream, row, questionWidth, "% for Data Migration Complexity Factor",
                decimal2String(ppmeImplementationMigration.getPercentForDataMigrationComplexityFactor(), 2));
            row = writeAnswer(contentStream, row, questionWidth, "Total # of hosts (physical hosts & ESX Servers) to " +
                "be migrated by EMC", int2String(ppmeImplementationMigration.getTotalNumberOfHostsToBeMigratedByEMC()));
            row = writeAnswer(contentStream, row, questionWidth, "# of new physical hosts included in design",
                int2String(ppmeImplementationMigration.getNumberOfNewHostsIncludedInDesign()));
            row = writeAnswer(contentStream, row, questionWidth, "# of new ESX Servers in design",
                int2String(ppmeImplementationMigration.getNumberOfNewESXServers()));
            row = writeAnswer(contentStream, row, questionWidth,
                "Will the customer do the zoning work on the switches?",
                bool2String(ppmeImplementationMigration.getWillCustomerDoZonningWorkOnSwitches()));
            row = writeAnswer(contentStream, row, questionWidth, "# of existing SAN fabrics",
                int2String(ppmeImplementationMigration.getNumberOfExistingSANFabrics()));
            row = writeAnswer(contentStream, row, questionWidth, "# of hosts to be booted from the SAN",
                int2String(ppmeImplementationMigration.getNumberOfHostsToBeBootedFromSAN()));
            row = writeAnswer(contentStream, row, questionWidth, "Will the customer do the LUN or device allocation " +
                "work on the storage?",
                bool2String(ppmeImplementationMigration.getWillCustomerDoLUNorDeviceAllocationWorkOnStorage()));
            if (getBooleanValue(viprDataMigrationWithPPME.getStorageArrayVNXorCLARiiON())) {
                row = writeAnswer(contentStream, row, questionWidth, "# of new VNX Block storage arrays",
                    int2String(ppmeImplementationMigration.getNumberOfNewVNXBlockStorageArrays()));
                row = writeAnswer(contentStream, row, questionWidth, "# of VNX Block arrays to be upgraded",
                    int2String(ppmeImplementationMigration.getNumberOfVNXBlockArraysToBeUpgraded()));
            }
            if (getBooleanValue(viprDataMigrationWithPPME.getStorageArrayXtremeIOCluster())) {
                row = writeAnswer(contentStream, row, questionWidth, "# of XtremIO clusters",
                    int2String(ppmeImplementationMigration.getNumberOfXtremeIOClusters()));
                row = writeAnswer(contentStream, row, questionWidth, "# of XtremIO Bricks per cluster",
                    int2String(ppmeImplementationMigration.getNumberOfXtremeIOBricksPerCluster()));
            }
            row = writeAnswer(contentStream, row, questionWidth,
                "# of hosts to be migrated via PowerPath Migration Enabler by EMC",
                int2String(
                    ppmeImplementationMigration.getNumberOfHostsToBeMigratedViaPowerPathMigrationEnablerByEMC()));
            row = writeAnswer(contentStream, row, questionWidth, "Does the data migration include device-size changes?",
                bool2String(ppmeImplementationMigration.getDataMigrationIncludesDeviceSizeChanges()));
            if (getBooleanValue(ppmeImplementationMigration.getIncludeDataErasureOfStorage())) {
                row = writeAnswer(contentStream, row, questionWidth, "% of servers requiring LUN size changes",
                    decimal2String(ppmeImplementationMigration.getPercentOfServersRequiringLUNSizeChanges(), 2));
                row = writeAnswer(contentStream, row, questionWidth, "# of VNX arrays to have data erased",
                    int2String(ppmeImplementationMigration.getNumberOfVNXArraysToHaveDataErased()));
                row = writeAnswer(contentStream, row, questionWidth, "Enter the Serial Number(s) of the Array(s)",
                    ppmeImplementationMigration.getVnxArraysSerialNumbers());
                row = writeAnswer(contentStream, row, questionWidth, "# of Symmetrix storage to have data erased",
                    int2String(ppmeImplementationMigration.getNumberOfSymmetrixStorageToHaveDataErased()));
                row = writeAnswer(contentStream, row, questionWidth, "Enter the Serial Number(s) of the Array(s)",
                    ppmeImplementationMigration.getSymmetrixArraysSerialNumbers());
            }
        }

        return row;
    }

    /**
     * <p>Writes the content of specified Design & Implementation for VIPR Data Service on Commodity section of VIPR tab
     * to specified PDF document.</p>
     *
     * @param contentStream a <code>PDPageContentStream</code> to write content to.
     * @param viprDataServiceOnCommodityDesignImpl a <code>ViprDataServiceOnCommodityDesignImpl</code> object providing
     * the content of Design & Implementation for VIPR Data Service on Commodity section of VIPR tab.
     * @param row an <code>int</code> providing the current row number to start writing from.
     * @param questionWidth a <code>float</code> providing the with of the column.
     * @return an <code>int</code> providing the new row number.
     * @throws IOException if an I/O error occurs.
     * @since 2.10
     */
    private int writeViprDataServiceOnCommodityDesignImplementation(PDPageContentStream contentStream,
        ViprDataServiceOnCommodityDesignImpl viprDataServiceOnCommodityDesignImpl, int row, float questionWidth)
        throws IOException {

        if (viprDataServiceOnCommodityDesignImpl == null) {
            return row;
        }

        row++;
        row = writeFont(contentStream, "DESIGN & IMPLEMENTATION FOR VIPR DATA SERVICE ON COMMODITY", ++row, 0, true);

        row++;
        row = writeFont(contentStream, "VIPR DATA SERVICE FOR COMMODITY FEATURES", ++row, 0, true);

        row = writeAnswer(contentStream, row, questionWidth, "Include Data Services for HDFS?",
            bool2String(viprDataServiceOnCommodityDesignImpl.getIncludeDataServicesForHDFS()));
        row = writeAnswer(contentStream, row, questionWidth, "Include integration with Active Directory/LDAP?",
            bool2String(viprDataServiceOnCommodityDesignImpl.getIncludeIntegrationWithADLDAP()));
        row = writeAnswer(contentStream, row, questionWidth, "Include Kerberos Authentication Mode for ViPR FS?",
            bool2String(viprDataServiceOnCommodityDesignImpl.getIncludeKerberosAuthModeForViprFS()));
        row = writeAnswer(contentStream, row, questionWidth, "Include ViPR Content Address Storage (CAS) API Support?",
            bool2String(viprDataServiceOnCommodityDesignImpl.getIncludeViprContentAddressStorageAPISupport()));
        row = writeAnswer(contentStream, row, questionWidth, "Does a Watch4net platform exist on site that meets ViPR"
            + " requirements?", bool2String(viprDataServiceOnCommodityDesignImpl.getWatch4NetPlatformExists()));

        row++;
        row = writeFont(contentStream, "VIPR DATA SERVICE FOR COMMODITY SCOPE DETAILS", ++row, 0, true);

        row = writeAnswer(contentStream, row, questionWidth, "# of Commodity Storage Systems",
            int2String(viprDataServiceOnCommodityDesignImpl.getNumberOfCommodityStorageSystems()));
        row = writeAnswer(contentStream, row, questionWidth, "# of Tenants defined",
            int2String(viprDataServiceOnCommodityDesignImpl.getNumberOfTenantsDefined()));
        if (getBooleanValue(viprDataServiceOnCommodityDesignImpl.getIncludeDataServicesForHDFS())) {
            row = writeAnswer(contentStream, row, questionWidth, "# of Hadoop Clusters",
                int2String(viprDataServiceOnCommodityDesignImpl.getNumberOfHadoopClusters()));
            row = writeAnswer(contentStream, row, questionWidth, "Total # of Hadoop Cluster Nodes (Where ViPR HDFS "
                + "Clients are to be deployed)",
                int2String(viprDataServiceOnCommodityDesignImpl.getTotalNumberOfHadoopClusterNodes()));
        }

        row++;
        row = writeFont(contentStream, "VIPR COMMODITY SYSTEM CONFIGURATION", ++row, 0, true);

        row = writeAnswer(contentStream, row, questionWidth, "# of Virtual Arrays",
            int2String(viprDataServiceOnCommodityDesignImpl.getNumberOfVirtualArrays()));
        row = writeAnswer(contentStream, row, questionWidth, "# of Object Virtual Pools",
            int2String(viprDataServiceOnCommodityDesignImpl.getNumberOfObjectVirtualPools()));
        row = writeAnswer(contentStream, row, questionWidth, "# of Projects",
            int2String(viprDataServiceOnCommodityDesignImpl.getNumberOfProjects()));
        row = writeAnswer(contentStream, row, questionWidth, "# of User Roles defined",
            int2String(viprDataServiceOnCommodityDesignImpl.getNumberOfUserRolesDefined()));
        row = writeAnswer(contentStream, row, questionWidth, "# of Catalog Services to Customize",
            int2String(viprDataServiceOnCommodityDesignImpl.getNumberOfCatalogServicesToCustomize()));
        row = writeAnswer(contentStream, row, questionWidth, "# of ViPR Commodity or ECS Systems Requiring CAS",
            int2String(viprDataServiceOnCommodityDesignImpl.getNumberOfViprCommodityOrECSSystemsRequiringCAS()));

        return row;
    }

    /**
     * <p>Writes the content of specified ECS Appliance Design and Implementation section of VIPR tab to specified PDF
     * document.</p>
     *
     * @param contentStream a <code>PDPageContentStream</code> to write content to.
     * @param ecsApplianceDesignImpl a <code>ECSApplianceDesignImpl</code> object providing the content of ECS Appliance
     * Design and Implementation section of VIPR tab.
     * @param row an <code>int</code> providing the current row number to start writing from.
     * @param questionWidth a <code>float</code> providing the with of the column.
     * @return an <code>int</code> providing the new row number.
     * @throws IOException if an I/O error occurs.
     * @since 2.10
     */
    private int writeViprECSApplianceDesignImplementation(PDPageContentStream contentStream,
                                                          ECSApplianceDesignImpl ecsApplianceDesignImpl, int row,
                                                          float questionWidth) throws IOException {
        if (ecsApplianceDesignImpl == null) {
            return row;
        }

        row++;
        row = writeFont(contentStream, "ECS APPLIANCE DESIGN & IMPLEMENTATION", ++row, 0, true);

        row++;
        row = writeFont(contentStream, "ECS APPLIANCE DESIGN & IMPLEMENTATION FEATURES", ++row, 0, true);

        row = writeAnswer(contentStream, row, questionWidth, "Include Data Services for HDFS?",
            bool2String(ecsApplianceDesignImpl.getIncludeDataServicesForHDFS()));
        row = writeAnswer(contentStream, row, questionWidth, "Include integration with Active Directory/LDAP?",
            bool2String(ecsApplianceDesignImpl.getIncludeIntegrationWithADLDAP()));
        row = writeAnswer(contentStream, row, questionWidth, "Include Kerberos Authentication Mode for ViPR FS?",
            bool2String(ecsApplianceDesignImpl.getIncludeKerberosAuthModeForViprFS()));
        row = writeAnswer(contentStream, row, questionWidth, "Include ViPR Content Address Storage (CAS) API Support?",
            bool2String(ecsApplianceDesignImpl.getIncludeViprContentAddressStorageAPISupport()));
        row = writeAnswer(contentStream, row, questionWidth, "Does a Watch4net platform exist on site that meets ViPR" +
            " requirements?", bool2String(ecsApplianceDesignImpl.getWatch4NetPlatformExists()));

        row++;
        row = writeFont(contentStream, "ECS APPLIANCE DESIGN & IMPLEMENTATION SCOPE DETAILS", ++row, 0, true);

        row = writeAnswer(contentStream, row, questionWidth, "# of ECS systems containing Block (Block-only or Mixed " +
            "Block-and-Unstructured)", int2String(ecsApplianceDesignImpl.getNumberOfECSSystemsContainingBlock()));
        row = writeAnswer(contentStream, row, questionWidth, "# of ECS Unstructured systems",
            int2String(ecsApplianceDesignImpl.getNumberOfECSUnstructuredSystems()));
        row = writeAnswer(contentStream, row, questionWidth, "# of Tenants defined",
            int2String(ecsApplianceDesignImpl.getNumberOfTenantsDefined()));
        if (getBooleanValue(ecsApplianceDesignImpl.getIncludeDataServicesForHDFS())) {
            row = writeAnswer(contentStream, row, questionWidth, "# of Hadoop Clusters",
                int2String(ecsApplianceDesignImpl.getNumberOfHadoopClusters()));
            row = writeAnswer(contentStream, row, questionWidth, "Total # of Hadoop Cluster Nodes (Where ViPR HDFS " +
                "Clients are to be deployed)", int2String(ecsApplianceDesignImpl.getTotalNumberOfHadoopClusterNodes()));
        }

        row++;
        row = writeFont(contentStream, "ECS IN VIPR CONFIGURATION", ++row, 0, true);

        row = writeAnswer(contentStream, row, questionWidth, "# of Virtual Arrays",
            int2String(ecsApplianceDesignImpl.getNumberOfVirtualArrays()));
        row = writeAnswer(contentStream, row, questionWidth, "# of Block Virtual Pools",
            int2String(ecsApplianceDesignImpl.getNumberOfBlockVirtualPools()));
        row = writeAnswer(contentStream, row, questionWidth, "# of Object Virtual Pools",
            int2String(ecsApplianceDesignImpl.getNumberOfObjectVirtualPools()));
        row = writeAnswer(contentStream, row, questionWidth, "# of Projects",
            int2String(ecsApplianceDesignImpl.getNumberOfProjects()));
        row = writeAnswer(contentStream, row, questionWidth, "# of Data Services Buckets",
            int2String(ecsApplianceDesignImpl.getNumberOfDataServiceBuckets()));
        row = writeAnswer(contentStream, row, questionWidth, "# of User Roles defined",
            int2String(ecsApplianceDesignImpl.getNumberOfUserRolesDefined()));
        row = writeAnswer(contentStream, row, questionWidth, "# of Catalog Services to Customize",
            int2String(ecsApplianceDesignImpl.getNumberOfCatalogServicesToCustomize()));
        row = writeAnswer(contentStream, row, questionWidth, "# of ViPR Commodity or ECS Systems Requiring CAS",
            int2String(ecsApplianceDesignImpl.getNumberOfViprCommodityOrECSSystemsRequiringCAS()));

        return row;
    }

    /**
     * Write ViprImplementation info.
     *
     * @param contentStream the stream.
     * @param viprRequestData the viprRequestData.
     * @param row the start row number.
     * @param questionWidth a <code>float</code> providing the with of the column.
     * @return the new row number
     * @throws IOException if any IO error occurs
     * @since SRT Phase 3-3 - Implement Isilon and ViPR Tabs Assembly
     */
    private int writeViprRequestDataImplementation(PDPageContentStream contentStream, ViprRequestData viprRequestData,
                                                   int row, float questionWidth) throws IOException {
        ViprImplementation impl = viprRequestData.getImpl();

        if (impl == null) {
            return row;
        }

        row++;
        row = writeFont(contentStream, "VIPR PLANNING, DESIGN, AND IMPLEMENTATION", ++row, 0, true);

        row = writeAnswer(contentStream, row, questionWidth, "Implementation Type",
            bool2StringNewOrUpgrade(impl.getNewImplType()));

        row++;
        row = writeFont(contentStream, "VIPR FEATURES", ++row, 0, true);

        row = writeAnswer(contentStream, row, questionWidth, "Include Data Services for Object?",
            bool2String(impl.getIncludeDataServices()));
        row = writeAnswer(contentStream, row, questionWidth, "Include Data Services for HDFS?",
            bool2String(impl.getIncludeHDFS()));
        row = writeAnswer(contentStream, row, questionWidth, "Include integration with Active Directory/LDAP?",
            bool2String(impl.getIncludeLDAP()));
        if (getBooleanValue(impl.getIncludeLDAP())) {
            row = writeAnswer(contentStream, row, questionWidth, "Include Kerberos Authentication Mode for ViPR FS?",
                bool2String(impl.getIncludeKerberosAuth()));
        }
        row = writeAnswer(contentStream, row, questionWidth, "Include ViPR Content Address Storage (CAS) API Support?",
            bool2String(impl.getIncludeViprContentAddressStorageAPISupport()));
        row = writeAnswer(contentStream, row, questionWidth, "Does a Watch4net platform exist on site that meets ViPR" +
            " requirements?", bool2String(impl.getWatch4netExist()));
        row = writeAnswer(contentStream, row, questionWidth, "Include Block Services Storage Ingestion?",
            bool2String(impl.getIncludeBlockServices()));
        row = writeAnswer(contentStream, row, questionWidth, "Include installations of ViPR software for third party " +
            "system integration?", bool2String(impl.getIncludeInstallationOfViprSoftwareFor3rdPartySystemIntegration()));
        if (getBooleanValue(impl.getIncludeInstallationOfViprSoftwareFor3rdPartySystemIntegration())) {
            row = writeAnswer(contentStream, row, questionWidth, "Include integration with VMware vCenter Operations " +
                "(vCOps)?", bool2String(impl.getIncludeVCOps()));
            row = writeAnswer(contentStream, row, questionWidth, "Include integration with VMware vCenter " +
                "Orchestrator (vCO)?", bool2String(impl.getIncludeVCO()));
            row = writeAnswer(contentStream, row, questionWidth, "Include integration with VMware vCloud Automation " +
                "Center (vCAC)?", bool2String(impl.getIncludeVCAC()));
            row = writeAnswer(contentStream, row, questionWidth, "Include integration with Microsoft SCVMM ?",
                bool2String(impl.getIncludeSCVMM()));
            row = writeAnswer(contentStream, row, questionWidth, "Include integration with EMC VSI (for VMware " +
                "vSphere Web Client)?", bool2String(impl.getIncludeVSI()));
        }

        row++;
        row = writeFont(contentStream, "VIPR SCOPE DETAILS", ++row, 0, true);

        if (getBooleanValue(impl.getIncludeHDFS())) {
            row = writeAnswer(contentStream, row, questionWidth, "# of Hadoop Clusters",
                int2String(impl.getHadoopClustersNum()));
            row = writeAnswer(contentStream, row, questionWidth, "Total # of Hadoop Cluster Nodes (Where ViPR HDFS " +
                "Clients are to be deployed)", int2String(impl.getHadoopNodesNum()));
        }

        row = writeAnswer(contentStream, row, questionWidth, "# of ViPR Controller instances",
            int2String(impl.getControllerInstancesNum()));
        row = writeAnswer(contentStream, row, questionWidth, "# of Tenants defined",
            int2String(impl.getNumberOfTenantsDefined()));
        row = writeAnswer(contentStream, row, questionWidth, "# of physical Unix hosts (targeted for provisioning)",
            int2String(impl.getUnixHostsNum()));
        row = writeAnswer(contentStream, row, questionWidth, "# of physical Windows hosts (targeted for provisioning)",
            int2String(impl.getWindowsHostsNum()));
        row = writeAnswer(contentStream, row, questionWidth, "# of VMware vCenter hosts",
            int2String(impl.getvCenterHostsNum()));
        row = writeAnswer(contentStream, row, questionWidth, "# of File-only arrays natively discovered (VNX, NetApp," +
            " Isilon)", int2String(impl.getFileOnlyArraysNum()));
        row = writeAnswer(contentStream, row, questionWidth, "# of EMC Block arrays natively discovered (VMAX / VNX)",
            int2String(impl.getBlockArraysNum()));
        row = writeAnswer(contentStream, row, questionWidth, "# of EMC VPLEX arrays discovered",
            int2String(impl.getVplexArraysNum()));
        row = writeAnswer(contentStream, row, questionWidth, "# of EMC RecoverPoint systems discovered",
            int2String(impl.getRecoverPointSystemsNum()));
        row = writeAnswer(contentStream, row, questionWidth, "# of Cisco switch fabrics",
            int2String(impl.getCiscoSwitchFabricsNum()));
        row = writeAnswer(contentStream, row, questionWidth, "# of Brocade switch fabrics",
            int2String(impl.getBrocadeSwitchFabricsNum()));
        row = writeAnswer(contentStream, row, questionWidth, "# of 3rd Party Arrays Integrated via OpenStack Cinder",
            int2String(impl.getNumberOf3rdPartyArraysIntegratedWithOpenStackCinder()));
        row = writeAnswer(contentStream, row, questionWidth, "# of ScaleIO Protection Domains",
            int2String(impl.getNumberOfScaleIOProtectionDomains()));

        row++;
        row = writeFont(contentStream, "VIPR PHYSICAL AND VIRTUAL ASSET CONFIGURATION", ++row, 0, true);

        row = writeAnswer(contentStream, row, questionWidth, "# of Virtual Arrays",
            int2String(impl.getVirtualArraysNum()));
        row = writeAnswer(contentStream, row, questionWidth, "# of Block and File Virtual Pools",
            int2String(impl.getNumberOfBlockAndFileVirtualPools()));
        row = writeAnswer(contentStream, row, questionWidth, "# of Catalog Services to Customize",
            int2String(impl.getCatalogServicesNum()));
        row = writeAnswer(contentStream, row, questionWidth, "# of User Roles defined",
            int2String(impl.getUserRolesNum()));
        row = writeAnswer(contentStream, row, questionWidth, "# of Projects",
            int2String(impl.getNumberOfProjects()));
        row = writeAnswer(contentStream, row, questionWidth, "# of Data Services Buckets",
            int2String(impl.getDsBucketsNum()));
        row = writeAnswer(contentStream, row, questionWidth, "# of Object Virtual Pools",
            int2String(impl.getDsPoolsNum()));
        row = writeAnswer(contentStream, row, questionWidth, "# of Data Stores",
            int2String(impl.getDataStoresNum()));
        row = writeAnswer(contentStream, row, questionWidth, "# of DS File Ingestions performed",
            int2String(impl.getDsIngestionsNum()));
        row = writeAnswer(contentStream, row, questionWidth, "# of hours for additional knowledge transfer (SA effort)",
            decimal2String(impl.getSaKnowledgeTransferHours(), 2));
        row = writeAnswer(contentStream, row, questionWidth, "# of additional hours for testing to be faciliated",
            decimal2String(impl.getNumberOfAdditionalHoursForTesting(), 2));


        return row;
    }

    /**
     * Get Isilon services scope.
     *
     * @param servicesScope
     *            the Isilon services scope
     * @return Isilon services scope.
     * @since SRT Phase 3-3 - Implement Isilon and ViPR Tabs Assembly
     */
    private static List<String> getIsilonRequestDataServicesScope(IsilonServicesScope servicesScope) {

        List<String> options = new ArrayList<String>();
        if (servicesScope != null) {
            if (servicesScope.isClusterRelocation()) {
                options.add("Isilon Cluster Relocation");
            }
            if (servicesScope.isHardwareUpgrade()) {
                options.add("Isilon Hardware Upgrade");
            }
            if (servicesScope.isMigration()) {
                options.add("Isilon Migration");
            }
            if (servicesScope.isDesignAndImpl()) {
                options.add("Isilon Design and Implementation");
            }
            if (servicesScope.isConfigAssurance()) {
                options.add("Isilon Configuration Assurance");
            }
        }
        return options;
    }

    /**
     * Get Isilon migration types.
     *
     * @param mig
     *            the Isilon migration data
     * @return Isilon migration types.
     * @since SRT Phase 3-3 - Implement Isilon and ViPR Tabs Assembly
     */
    private static List<String> getIsilonMigrationTypes(IsilonMigration mig) {

        List<String> options = new ArrayList<String>();
        if (mig != null) {
            if (mig.isNetApp3rdPartyMigration()) {
                options.add("NetApp/Third Party Migration to Isilon");
            }
            if (mig.isCelerraUnifiedFile()) {
                options.add("Celerra/Unified File to Isilon");
            }
            if (mig.isSyncIQ()) {
                options.add("Isilon to Isilon SyncIQ");
            }
            if (mig.isTechRefresh()) {
                options.add("Isilon Technology Refresh");
            }
            if (mig.getNetAppMigrationNodeBased()) {
                options.add("Netapp migration to Isilon (Node Based/3rd party tools)");
            }
        }
        return options;
    }

    /**
     * Get Isilon EMC levels.
     *
     * @param mig
     *            the Isilon migration data
     * @return Isilon EMC levels.
     * @since SRT Phase 3-3 - Implement Isilon and ViPR Tabs Assembly
     */
    private static List<String> getIsilonEMCLevels(IsilonMigration mig) {

        List<String> options = new ArrayList<String>();
        if (mig != null) {
            if (mig.isPlanAndDesign()) {
                options.add("Planning and Design");
            }
            if (mig.isImplAndMigration()) {
                options.add("Implementation and Migration");
            }
        }
        return options;
    }

    /**
     * Get Isilon user defined activities.
     *
     * @param mig
     *            the Isilon migration data
     * @return Isilon user defined activities.
     * @since SRT Phase 3-3 - Implement Isilon and ViPR Tabs Assembly
     */
    private static List<String> getIsilonUserActivities(IsilonMigration mig) {

        List<String> options = new ArrayList<String>();
        if (mig != null) {
            if (mig.isAdditionalTesting()) {
                options.add("Additional Testing");
            }
            if (mig.isAdditionalMonitoring()) {
                options.add("Additional Monitoring");
            }
            if (mig.isScriptingWork()) {
                options.add("Scripting Work");
            }
        }
        return options;
    }

    /**
     * Get Isilon migration protocols.
     *
     * @param mig
     *            the Isilon migration data
     * @return Isilon migration protocols.
     * @since SRT Phase 3-3 - Implement Isilon and ViPR Tabs Assembly
     */
    private static List<String> getIsilonMigProtocols(IsilonMigration mig) {

        List<String> options = new ArrayList<String>();
        if (mig != null) {
            if (mig.isCifs()) {
                options.add("CIFS");
            }
            if (mig.isNfs()) {
                options.add("NFS");
            }
            if (mig.isMultiProtocol()) {
                options.add("Multi-protocol");
            }
        }
        return options;
    }

    /**
     * Write Isilon request data.
     *
     * @param contentStream
     *            the stream
     * @param isilonRequestData
     *            the isilonRequestData
     * @param row
     *            the start row number
     * @param page
     *            the PDF page
     * @return the new row number
     * @throws IOException
     *             if any IO error occurs
     * @since SRT Phase 3-3 - Implement Isilon and ViPR Tabs Assembly
     */
    private int writeIsilonRequestData(PDPageContentStream contentStream,
            IsilonRequestData isilonRequestData, int row, PDPage page) throws IOException {
        float questionWidth = 200f;
        row = writeFont(contentStream, "Services & Activities - Isilon", ++row, 0, true);

        // General information
        row++;

        row = writeFont(contentStream, "GENERAL INFORMATION", ++row, 0, true);
        row = writeAnswer(contentStream, row, questionWidth,
                "# of Hours of Knowledge Transfer", decimal2String(isilonRequestData.getKnowledgeTransferHours(), 2));
        row = writeAnswer(contentStream, row, questionWidth,
                "General Comment", trimToEmpty(isilonRequestData.getGeneralComment()));

        int columnNum = 3;
        float columnWidth = 200f;

        // Services scope
        IsilonServicesScope servicesScope = isilonRequestData.getServicesScope();
        row++;
        row = writeFont(contentStream, "SERVICES TO BE SCOPED IN THIS BOE", ++row, 0, true);
        List<String> options = getIsilonRequestDataServicesScope(servicesScope);
        row = writeOptions(contentStream, options, ++row, 0, columnNum, columnWidth);

        row = writeIsilonRequestDataClusterRelocation(contentStream, isilonRequestData, row, page);

        row = writeIsilonRequestDataDesignImpl(contentStream, isilonRequestData, row, page);

        row = writeIsilonRequestDataHardwareUpgrade(contentStream, isilonRequestData, row, page);

        row = writeIsilonRequestDataMigration(contentStream, isilonRequestData, row, page);

        return row;
    }

    /**
     * Write IsilonMigration info.
     *
     * @param contentStream
     *            the stream
     * @param isilonRequestData
     *            the isilonRequestData
     * @param row
     *            the start row number
     * @param page
     *            the PDF page
     * @return the new row number
     * @throws IOException
     *             if any IO error occurs
     * @since SRT Phase 3-3 - Implement Isilon and ViPR Tabs Assembly
     */
    private int writeIsilonRequestDataMigration(PDPageContentStream contentStream,
            IsilonRequestData isilonRequestData, int row, PDPage page) throws IOException {
        IsilonMigration mig = isilonRequestData.getMigration();

        if (mig != null && isilonRequestData.getServicesScope() != null
                && isilonRequestData.getServicesScope().isMigration()) {

            float questionWidth = 270f;
            row++;
            row = writeFont(contentStream, "ISILON MIGRATION", ++row, 0, true);

            int columnNum = 2;
            float columnWidth = 150f;

            row = writeFont(contentStream, "Migration Type", ++row, 0, false);
            row = writeOptions(contentStream, getIsilonMigrationTypes(mig), row, questionWidth, columnNum,
                    columnWidth);

            if (mig.isNetApp3rdPartyMigration() || mig.isCelerraUnifiedFile() || mig.isSyncIQ()) {
                row = writeFont(contentStream, "Level of EMC Involvement", ++row, 0, false);
                row = writeOptions(contentStream, getIsilonEMCLevels(mig), row, questionWidth, columnNum,
                        columnWidth);

                row = writeFont(contentStream, "Include Activities for User Defined Additional Effort", ++row, 0,
                        false);
                row = writeOptions(contentStream, getIsilonUserActivities(mig), row, questionWidth, columnNum,
                        columnWidth);
            }

            if (mig.isTechRefresh()) {
                row = writeAnswer(contentStream, row, questionWidth,
                        "Install Isilon Hardware(New cluster or node expansion)?",
                        bool2String(mig.getInstallIsilonHardware()));
            }

            if (mig.isNetApp3rdPartyMigration() || mig.isCelerraUnifiedFile() || mig.isSyncIQ()) {
                row = writeFont(contentStream, "Select protocols for Isilon Migrations", ++row, 0, false);
                row = writeOptions(contentStream, getIsilonMigProtocols(mig), row, questionWidth, columnNum,
                        columnWidth);

                if (mig.isCifs()) {
                    row = writeAnswer(contentStream, row, questionWidth,
                            "Amount of CIFS data in TB to be migrated",
                            int2String(mig.getCifsDataAmount()));
                    row = writeAnswer(contentStream, row, questionWidth,
                            "Include Local Users and Groups?",
                            bool2String(mig.getIncludeLocalUsersGroups()));
                }
                if (mig.isNfs()) {
                    row = writeAnswer(contentStream, row, questionWidth,
                            "Amount of NFS Data in TB to be Migrated",
                            int2String(mig.getNfsDataAmount()));
                }
                if (mig.isMultiProtocol()) {
                    row = writeAnswer(contentStream, row, questionWidth,
                            "Amount of Multi-Protocol Data in TB to be Migrated",
                            int2String(mig.getMultiProtocolDataAmount()));
                }
                row = writeAnswer(contentStream, row, questionWidth,
                        "Average duration of data migration event",
                        decimal2String(mig.getAverageDuration(), 2));
            }

            if (mig.isNetApp3rdPartyMigration() || mig.isCelerraUnifiedFile()) {
                row = writeAnswer(contentStream, row, questionWidth,
                        "# of data migration events",
                        int2String(mig.getDataMigEventsNum()));
            }

            if (mig.isSyncIQ()) {
                row = writeAnswer(contentStream, row, questionWidth,
                        "# of weeks to monitor data movement",
                        int2String(mig.getMonitorWeeksNum()));
                row = writeAnswer(contentStream, row, questionWidth,
                        "# of cutover events for synch IQ migration",
                        int2String(mig.getCutoverEventsNum()));
            }

            if (mig.isTechRefresh()) {
                row = writeAnswer(contentStream, row, questionWidth,
                        "Is SmartPools already enabled on the clusters?",
                        bool2String(mig.getSmartPoolsEnabled()));
                row = writeAnswer(contentStream, row, questionWidth,
                        "Total # of Isilon nodes to be removed on the cluster after refresh",
                        int2String(mig.getRemoveNodesNum()));
                row = writeAnswer(contentStream, row, questionWidth,
                        "# of events required to move all node data",
                        int2String(mig.getRequiredEventsNum()));
                row = writeAnswer(contentStream, row, questionWidth,
                        "Total TB of data to be moved as part of tech refresh",
                        int2String(mig.getTechRefreshMovedData()));
            }
            
            if (mig.getNetAppMigrationNodeBased()) {
                IsilonNetAppNodeBaseMigration netAppNodeBasedMigration = mig.getNetAppNodeBasedMigration();
                if (netAppNodeBasedMigration != null) {
                    row = writeAnswer(contentStream, row, questionWidth, "Source system type",
                        trimToEmpty(netAppNodeBasedMigration.getSourceSystemType()));
                    row = writeAnswer(contentStream, row, questionWidth,
                        "# of Isilon Nodes - Capacity: 12TB or less",
                        int2String(netAppNodeBasedMigration.getNumberOfNodesCapacity1()));
                    row = writeAnswer(contentStream, row, questionWidth,
                        "# of Isilon Nodes - Capacity between: 12TB - 108TB",
                        int2String(netAppNodeBasedMigration.getNumberOfNodesCapacity2()));
                    row = writeAnswer(contentStream, row, questionWidth,
                        "# of Isilon Nodes - Capacity between: 109TB - 144TB",
                        int2String(netAppNodeBasedMigration.getNumberOfNodesCapacity3()));
                    row = writeAnswer(contentStream, row, questionWidth,
                        "# of Isilon Nodes - Capacity between: 145TB - 216TB",
                        int2String(netAppNodeBasedMigration.getNumberOfNodesCapacity4()));
                    row = writeAnswer(contentStream, row, questionWidth,
                        "# of Isilon Nodes - Capacity: 217TB",
                        int2String(netAppNodeBasedMigration.getNumberOfNodesCapacity5()));
                    row = writeAnswer(contentStream, row, questionWidth, "Multi-protocol data in the environment?",
                        bool2String(netAppNodeBasedMigration.getMultiProtocolDataInEnv()));
                    row = writeAnswer(contentStream, row, questionWidth,
                        "Are widelinks present in the environment (only applies to Netapp)?",
                        bool2String(netAppNodeBasedMigration.getWideLinksPresent()));
                    row = writeAnswer(contentStream, row, questionWidth, 
                        "Are historical SIDS present in the environment?",
                        bool2String(netAppNodeBasedMigration.getHistoricalSIDSPresent()));
                    row = writeAnswer(contentStream, row, questionWidth, "Are local users or groups in use?",
                        bool2String(netAppNodeBasedMigration.getLocalUsersGroupsInUse()));
                    row = writeAnswer(contentStream, row, questionWidth,
                        "Is archived data present in the environment (CTA/eVault/Archivio)?",
                        bool2String(netAppNodeBasedMigration.getArchivedDataPresent()));
                    row = writeAnswer(contentStream, row, questionWidth,
                        "Expected # of cutovers to be supported by EMC",
                        int2String(netAppNodeBasedMigration.getNumberOfExpectedCutovers()));
                }

            }
        }
        return row;
    }

    /**
     * Write IsilonHardwareUpgrade info.
     *
     * @param contentStream
     *            the stream
     * @param isilonRequestData
     *            the isilonRequestData
     * @param row
     *            the start row number
     * @param page
     *            the PDF page
     * @return the new row number
     * @throws IOException
     *             if any IO error occurs
     * @since SRT Phase 3-3 - Implement Isilon and ViPR Tabs Assembly
     */
    private int writeIsilonRequestDataHardwareUpgrade(PDPageContentStream contentStream,
            IsilonRequestData isilonRequestData, int row, PDPage page) throws IOException {
        IsilonHardwareUpgrade hu = isilonRequestData.getHardwareUpgrade();

        if (hu != null && isilonRequestData.getServicesScope() != null
                && isilonRequestData.getServicesScope().isHardwareUpgrade()) {

            float questionWidth = 270f;
            row++;
            row = writeFont(contentStream, "ISILON HARDWARE UPGRADE", ++row, 0, true);

            row = writeAnswer(contentStream, row, questionWidth,
                    "Perform Pre and Post Upgrade Configuration?",
                    bool2String(hu.getPerformConfig()));
            if (hu.getPerformConfig() != null) {
                row = writeAnswer(contentStream, row, questionWidth, "# of Isilon nodes to upgrade",
                    int2String(hu.getNodesNum()));
            }
        }
        return row;
    }

    /**
     * Write IsilonDesignAndImpl info.
     *
     * @param contentStream
     *            the stream
     * @param isilonRequestData
     *            the isilonRequestData
     * @param row
     *            the start row number
     * @param page
     *            the PDF page
     * @return the new row number
     * @throws IOException
     *             if any IO error occurs
     * @since SRT Phase 3-3 - Implement Isilon and ViPR Tabs Assembly
     */
    private int writeIsilonRequestDataDesignImpl(PDPageContentStream contentStream,
            IsilonRequestData isilonRequestData, int row, PDPage page) throws IOException {
        IsilonDesignAndImpl di = isilonRequestData.getDesignAndImpl();

        if (di != null && isilonRequestData.getServicesScope() != null
                && isilonRequestData.getServicesScope().isDesignAndImpl()) {

            float questionWidth = 270f;
            row++;
            row = writeFont(contentStream, "ISILON DESIGN AND IMPLEMENTATION", ++row, 0, true);

            row = writeAnswer(contentStream, row, questionWidth,
                    "Install Isilon Hardware(New Cluster or Node Expansion)?",
                    bool2String(di.getInstallHardware()));
            
            if (getBooleanValue(di.getInstallHardware())) {
                row = writeAnswer(contentStream, row, questionWidth,
                    "Include 1U InfiniBand Switch Installation?",
                    bool2String(di.getInclude1UInfiniBandSwitchInstall()));
                row = writeAnswer(contentStream, row, questionWidth,
                    "Include InfiniBand 4U Chassis Installation?",
                    bool2String(di.getInclude4UInfiniBandChassisInstall()));
                row = writeAnswer(contentStream, row, questionWidth,
                    "Include 1-2U Node Installation?", bool2String(di.getInclude12UNodeInstall()));
                row = writeAnswer(contentStream, row, questionWidth,
                    "Include 4U Node Installation?", bool2String(di.getInclude4UNodeInstall()));
            }
            
            row = writeAnswer(contentStream, row, questionWidth,
                    "Include Isilon Technology Refresh?",
                    bool2String(di.getIncludeTechRefresh()));
            row = writeAnswer(contentStream, row, questionWidth,
                    "New Isilon Cluster?",
                    bool2String(di.getNewCluster()));

            if (di.getNewCluster() != null && di.getNewCluster()) {
                row = writeAnswer(contentStream, row, questionWidth,
                        "# of Isilon subnets to configure",
                        int2String(di.getSubnetsNum()));
                row = writeAnswer(contentStream, row, questionWidth,
                        "# of Isilon Smart Connect Zones to Configure",
                        int2String(di.getSmartConnectZonesNum()));
                row = writeAnswer(contentStream, row, questionWidth,
                        "# of Authentication Methods to Configure",
                        int2String(di.getAuthMethodsNum()));
                row = writeAnswer(contentStream, row, questionWidth,
                        "# of Isilon Shares / Exports to Configure",
                        int2String(di.getSharesExportsNum()));
                row = writeAnswer(contentStream, row, questionWidth,
                        "# of Isilon Smart Quotas to Configure",
                        int2String(di.getSmartQuotasNum()));
                row = writeAnswer(contentStream, row, questionWidth,
                        "# of Snapshots IQ Entries to Configure",
                        int2String(di.getSnapshotsIQEntriesNum()));
            }

            row = writeAnswer(contentStream, row, questionWidth,
                    "Include Email and Support IQ Configuration?",
                    bool2String(di.getIncludeEmail()));
            row = writeAnswer(contentStream, row, questionWidth,
                    "Include subnet configuration?",
                    bool2String(di.getIncludeSubnet()));
            row = writeAnswer(contentStream, row, questionWidth,
                    "Include advice on data protection levels?",
                    bool2String(di.getIncludeAdvice()));
            row = writeAnswer(contentStream, row, questionWidth,
                    "Include smart connect configuration?",
                    bool2String(di.getIncludeSmartConnect()));
            row = writeAnswer(contentStream, row, questionWidth,
                    "Include authentication configuration?",
                    bool2String(di.getIncludeAuth()));
            row = writeAnswer(contentStream, row, questionWidth,
                    "Include File System Shares / Export Configuration?",
                    bool2String(di.getIncludeFileSystemShares()));
            row = writeAnswer(contentStream, row, questionWidth,
                    "Install Insight IQ?",
                    bool2String(di.getInstallInsightIQ()));
            row = writeAnswer(contentStream, row, questionWidth,
                    "Include Configuration of Smart Quotas?",
                    bool2String(di.getIncludeSmartQuotas()));
            row = writeAnswer(contentStream, row, questionWidth,
                    "Include Configuration of Isilon Snapshots?",
                    bool2String(di.getIncludeSnapshots()));
            row = writeAnswer(contentStream, row, questionWidth,
                    "Include NDMP Configuration?",
                    bool2String(di.getIncludeNDMP()));
            row = writeAnswer(contentStream, row, questionWidth,
                    "Include SmartLock Configuration?",
                    bool2String(di.getIncludeSmartLock()));
        }
        return row;
    }

    /**
     * Write IsilonClusterRelocation info.
     *
     * @param contentStream
     *            the stream
     * @param isilonRequestData
     *            the isilonRequestData
     * @param row
     *            the start row number
     * @param page
     *            the PDF page
     * @return the new row number
     * @throws IOException
     *             if any IO error occurs
     * @since SRT Phase 3-3 - Implement Isilon and ViPR Tabs Assembly
     */
    private int writeIsilonRequestDataClusterRelocation(PDPageContentStream contentStream,
            IsilonRequestData isilonRequestData, int row, PDPage page) throws IOException {

        IsilonClusterRelocation cr = isilonRequestData.getClusterRelocation();

        if (cr != null && isilonRequestData.getServicesScope() != null
                && isilonRequestData.getServicesScope().isClusterRelocation()) {

            float questionWidth = 270f;
            row++;
            row = writeFont(contentStream, "ISILON CLUSTER RELOCATION", ++row, 0, true);

            row = writeAnswer(contentStream, row, questionWidth,
                    "# of 1-2U Isilon Servers to Install", int2String(cr.getIsilon12UServersNum()));
            row = writeAnswer(contentStream, row, questionWidth,
                    "# of Isilon 4U Servers to Install", int2String(cr.getIsilon4UServersNum()));
            row = writeAnswer(contentStream, row, questionWidth,
                    "# of 1U Infiniband Switches to Install", int2String(cr.getInfinibandSwitchesNum()));
            row = writeAnswer(contentStream, row, questionWidth,
                    "# of Isilon Infiniband Chassis to install(Non-1U Switches)",
                    int2String(cr.getInfinibandChassisNum()));
        }
        return row;
    }

    /**
     * Get HealthCheck services scope.
     *
     * @param servicesScope
     *            the HealthCheck services scope
     * @return ASD services scope.
     * @since SRT Phase 3-4 - ASD and Healthcheck Tabs Assembly
     */
    private static List<String> getHealthCheckRequestDataServicesScope(HealthCheckServicesScope servicesScope) {

        List<String> options = new ArrayList<String>();
        if (servicesScope != null) {
            if (servicesScope.isAvamar()) {
                options.add("Avamar");
            }
            if (servicesScope.isDataDomain()) {
                options.add("Data Domain");
            }
            if (servicesScope.isDpa()) {
                options.add("Data Protection Advisor");
            }
            if (servicesScope.isDlm()) {
                options.add("DLM");
            }
            if (servicesScope.isGreenPlum()) {
                options.add("GreenPlum");
            }
            if (servicesScope.isIonix()) {
                options.add("Ionix");
            }
            if (servicesScope.isNetWorker()) {
                options.add("NetWorker");
            }
            if (servicesScope.isSanSecurity()) {
                options.add("San Security");
            }
            if (servicesScope.isSap()) {
                options.add("SAP");
            }
            if (servicesScope.isSourceOne()) {
                options.add("SourceOne");
            }
            if (servicesScope.isSymmetrixVmax()) {
                options.add("Symmetrix / Vmax");
            }
            if (servicesScope.isSymmetrixVmaxStorageReplication()) {
                options.add("Symmetrix / Vmax Storage Replication");
            }
            if (servicesScope.isUnified()) {
                options.add("Unified");
            }
            if (servicesScope.isVblock()) {
                options.add("Vblock");
            }
            if (servicesScope.isVmwareVirtualInfrastructure()) {
                options.add("VMWare Virtual Infrastructure");
            }
            if (servicesScope.isVplex()) {
                options.add("Vplex");
            }
        }
        return options;
    }

    /**
     * Write HealthCheck request data.
     *
     * @param contentStream
     *            the stream
     * @param healthCheckRequestData
     *            the healthCheckRequestData
     * @param row
     *            the start row number
     * @param page
     *            the PDF page
     * @return the new row number
     * @throws IOException
     *             if any IO error occurs
     * @since SRT Phase 3-4 - ASD and Healthcheck Tabs Assembly
     */
    private int writeHealthCheckRequestData(PDPageContentStream contentStream,
            HealthCheckRequestData healthCheckRequestData, int row, PDPage page) throws IOException {
        float questionWidth = 200f;
        row = writeFont(contentStream, "Services & Activities - Healthcheck", ++row, 0, true);

        // General information
        row++;

        row = writeFont(contentStream, "GENERAL INFORMATION", ++row, 0, true);
        row = writeAnswer(contentStream, row, questionWidth,
                "General Comment", trimToEmpty(healthCheckRequestData.getGeneralComment()));

        int columnNum = 3;
        float columnWidth = 150f;

        // Services scope
        HealthCheckServicesScope servicesScope = healthCheckRequestData.getServicesScope();
        row++;
        row = writeFont(contentStream, "SERVICES TO BE SCOPED IN THIS BOE", ++row, 0, true);
        List<String> options = getHealthCheckRequestDataServicesScope(servicesScope);
        row = writeOptions(contentStream, options, ++row, 0, columnNum, columnWidth);

        questionWidth = 320f;

        HealthCheckAvamar avamar = healthCheckRequestData.getAvamar();
        if (avamar != null && servicesScope != null && servicesScope.isAvamar()) {
            row++;
            row = writeFont(contentStream, "AVAMAR HEALTH-CHECK", ++row, 0, true);
            row = writeAnswer(contentStream, row, questionWidth,
                    "# of Avamar Grids?",
                    int2String(avamar.getAvamarGridsNum()));
            row = writeAnswer(contentStream, row, questionWidth,
                    "# of Assessment interviews?",
                    int2String(avamar.getAssessmentInterviewsNum()));
        }

        HealthCheckDataDomain dataDomain = healthCheckRequestData.getDataDomain();
        if (dataDomain != null && servicesScope != null && servicesScope.isDataDomain()) {
            row++;
            row = writeFont(contentStream, "DATA DOMAIN HEALTH-CHECK", ++row, 0, true);
            row = writeAnswer(contentStream, row, questionWidth,
                    "# of Data Domain appliances?",
                    int2String(dataDomain.getAppliancesNum()));
            row = writeAnswer(contentStream, row, questionWidth,
                    "# of Assessment interviews?",
                    int2String(dataDomain.getAssessmentInterviewsNum()));
        }

        HealthCheckDPA dpa = healthCheckRequestData.getDpa();
        if (dpa != null && servicesScope != null && servicesScope.isDpa()) {
            row++;
            row = writeFont(contentStream, "DATA PROTECTION ADVISOR HEALTH-CHECK", ++row, 0, true);
            row = writeAnswer(contentStream, row, questionWidth,
                    "# of DPA site implementations?",
                    int2String(dpa.getSiteImplementationsNum()));
        }

        HealthCheckDLM dlm = healthCheckRequestData.getDlm();
        if (dlm != null && servicesScope != null && servicesScope.isDlm()) {
            row++;
            row = writeFont(contentStream, "DLM HEALTH-CHECK", ++row, 0, true);
            row = writeAnswer(contentStream, row, questionWidth,
                    "# of Dish Library for Mainframe (DLm) subsystem to be evaluated?",
                    int2String(dlm.getDlmSubsystemNum()));
            row = writeAnswer(contentStream, row, questionWidth,
                    "Amount of storage, in whole TeraBytes (TB), on the DLm subsystem(s) to be evaluated?",
                    int2String(dlm.getStorageAmount()));
        }

        HealthCheckGreenPlum greenplum = healthCheckRequestData.getGreenPlum();
        if (greenplum != null && servicesScope != null && servicesScope.isGreenPlum()) {
            row++;
            row = writeFont(contentStream, "GREENPLUM HEALTH-CHECK", ++row, 0, true);
            row = writeAnswer(contentStream, row, questionWidth,
                    "# of Greenplum primary master host servers targeted for health check analysis?",
                    int2String(greenplum.getMasterHostServersNum()));
        }

        HealthCheckIonix ionix = healthCheckRequestData.getIonix();
        if (ionix != null && servicesScope != null && servicesScope.isIonix()) {
            row++;
            row = writeFont(contentStream, "IONIX HEALTH-CHECK", ++row, 0, true);
            row = writeAnswer(contentStream, row, questionWidth,
                    "Include the Executive Summary Presentation?",
                    bool2String(ionix.getIncludeExecutiveSummaryPresentation()));
            row = writeAnswer(contentStream, row, questionWidth,
                    "What size environment?",
                    ionix.getSizeEnvironment() == null ? "" : ionix.getSizeEnvironment().name());
        }

        HealthCheckNetWorker netWorker = healthCheckRequestData.getNetWorker();
        if (netWorker != null && servicesScope != null && servicesScope.isNetWorker()) {
            row++;
            row = writeFont(contentStream, "NETWORKER HEALTH-CHECK", ++row, 0, true);
            row = writeAnswer(contentStream, row, questionWidth,
                    "Include EMC Assessment Service Analysis Summary Presentation?",
                    bool2String(netWorker.getIncludeEMCAssessment()));
            row = writeAnswer(contentStream, row, questionWidth,
                    "# of NetWorker datazones?",
                    int2String(netWorker.getDataZonesNum()));
            row = writeAnswer(contentStream, row, questionWidth,
                    "# of Assessment interviews?",
                    int2String(netWorker.getAssessmentInterviewsNum()));
        }

        HealthCheckSanSecurity sanSecurity = healthCheckRequestData.getSanSecurity();
        if (sanSecurity != null && servicesScope != null && servicesScope.isSanSecurity()) {
            row++;
            row = writeFont(contentStream, "SAN SECURITY HEALTH-CHECK", ++row, 0, true);
            row = writeAnswer(contentStream, row, questionWidth,
                    "# of Assessment interviews?",
                    int2String(sanSecurity.getAssessmentInterviewsNum()));
            row = writeAnswer(contentStream, row, questionWidth,
                    "# of sites to be assessed?",
                    int2String(sanSecurity.getAssessedSitesNum()));
            row = writeAnswer(contentStream, row, questionWidth,
                    "# of EMC storage arrays to review?",
                    int2String(sanSecurity.getEmcStorageArraysNum()));
            row = writeAnswer(contentStream, row, questionWidth,
                    "# of SAN attached Hosts?",
                    int2String(sanSecurity.getSanAttachedHostsNum()));
            row = writeAnswer(contentStream, row, questionWidth,
                    "# of storage management stations?",
                    int2String(sanSecurity.getStorageManagementStationsNum()));
        }

        HealthCheckSAP sap = healthCheckRequestData.getSap();
        if (sap != null && servicesScope != null && servicesScope.isSap()) {
            row++;
            row = writeFont(contentStream, "SAP HEALTH-CHECK", ++row, 0, true);
            row = writeAnswer(contentStream, row, questionWidth,
                    "# of Disk Library for Mainframe (DLm) subsystems to be evaluated?",
                    int2String(sap.getDlmSubsystemNum()));
            row = writeAnswer(contentStream, row, questionWidth,
                    "Amount of stroage, in whole TeraBytes (TB), on the DLm subsystem(s) to be evaluated",
                    int2String(sap.getStorageAmount()));
        }

        HealthCheckSourceOne sourceOne = healthCheckRequestData.getSourceOne();
        if (sourceOne != null && servicesScope != null && servicesScope.isSourceOne()) {
            row++;
            row = writeFont(contentStream, "SOURCEONE HEALTH-CHECK", ++row, 0, true);
            row = writeAnswer(contentStream, row, questionWidth,
                    "# of SourceOne servers?",
                    int2String(sourceOne.getServersNum()));
            row = writeAnswer(contentStream, row, questionWidth,
                    "# of Assessment interviews?",
                    int2String(sourceOne.getAssessmentInterviewsNum()));
        }

        HealthCheckSymmetrixVmax symmVmax = healthCheckRequestData.getSymmetrixVmax();
        if (symmVmax != null && servicesScope != null && servicesScope.isSymmetrixVmax()) {
            row++;
            row = writeFont(contentStream, "SYMMETRIX / VMAX HEALTH-CHECK", ++row, 0, true);
            row = writeAnswer(contentStream, row, questionWidth,
                    "# of Health Checks Events sold to customer?",
                    int2String(symmVmax.getEventsSoldNum()));
            row = writeAnswer(contentStream, row, questionWidth,
                    "# of Symmetrix DMX and/or VMAX arrays?",
                    int2String(symmVmax.getDmxVmaxArraysNum()));
        }

        HealthCheckSymmetrixVmaxStorageReplication symmVmaxSR = healthCheckRequestData
                .getSymmetrixVmaxStorageReplication();
        if (symmVmaxSR != null && servicesScope != null
            && servicesScope.isSymmetrixVmaxStorageReplication()) {
            row++;
            row = writeFont(contentStream, "SYMMETRIX / VMAX STORAGE REPLICATION SE", ++row, 0, true);
            row = writeAnswer(contentStream, row, questionWidth,
                    "Include Final Report?",
                    bool2String(symmVmaxSR.getIncludeFinalReport()));
            row = writeAnswer(contentStream, row, questionWidth,
                    "Include Executive Summary Review Presentation?",
                    bool2String(symmVmaxSR.getIncludeExecutiveSummaryReviewPresentation()));
            row = writeAnswer(contentStream, row, questionWidth,
                    "# of Assessment interviews?",
                    int2String(symmVmaxSR.getAssessmentInterviewsNum()));
            row = writeAnswer(contentStream, row, questionWidth,
                    "# of Consistency Groups for Symmetrix Health Check?",
                    int2String(symmVmaxSR.getConsistencyGroupsNum()));
            row = writeAnswer(contentStream, row, questionWidth,
                    "# of Symmetrix arrays for Symmetrix Health Check?",
                    int2String(symmVmaxSR.getSymmetrixArraysNum()));
            row = writeAnswer(contentStream, row, questionWidth,
                    "# of Open Systems Hosts for Symmetrix Health Check?",
                    int2String(symmVmaxSR.getOpenSystemsHostsNum()));
            row = writeAnswer(contentStream, row, questionWidth,
                    "# of Symmetrix Logical Devices for Symmetrix Health Check?",
                    int2String(symmVmaxSR.getLogicalDevicesNum()));
        }

        HealthCheckUnified unified = healthCheckRequestData.getUnified();
        if (unified != null && servicesScope != null && servicesScope.isUnified()) {
            row++;
            row = writeFont(contentStream, "UNIFIED HEALTH-CHECK", ++row, 0, true);
            row = writeAnswer(contentStream, row, questionWidth,
                    "Type of Healthcheck?",
                    lookupEntity2String(unified.getHealthCheckType()));
            row = writeAnswer(contentStream, row, questionWidth,
                    "# of Health Checks Events sold to customer",
                    int2String(unified.getEventsSoldNum()));

            if (unified.getHealthCheckType() != null) {
                if ("File".equals(unified.getHealthCheckType().getName())) {
                    row = writeAnswer(contentStream, row, questionWidth,
                            "# of Celerra or VNX Unified File Based Arrays",
                            int2String(unified.getFileArraysNum()));
                }

                if ("Block".equals(unified.getHealthCheckType().getName())) {
                    row = writeAnswer(contentStream, row, questionWidth,
                            "# of Clariion or VNX Unified Unified Block Arrays",
                            int2String(unified.getBlockArraysNum()));
                }
            }
        }

        HealthCheckVblock vblock = healthCheckRequestData.getVblock();
        if (vblock != null && servicesScope != null && servicesScope.isVblock()) {
            row++;
            row = writeFont(contentStream, "VBLOCK HEALTH-CHECK", ++row, 0, true);
            row = writeAnswer(contentStream, row, questionWidth,
                    "Include Interoperability Check?",
                    bool2String(vblock.getIncludeInteroperabilityCheck()));
            row = writeAnswer(contentStream, row, questionWidth,
                    "Include Performance Check?",
                    bool2String(vblock.getIncludePerformanceCheck()));
            row = writeAnswer(contentStream, row, questionWidth,
                    "Include Capacity Analysis?",
                    bool2String(vblock.getIncludeCapacityAnalysis()));
            row = writeAnswer(contentStream, row, questionWidth,
                    "Include VNX Block Flare Software Update?",
                    bool2String(vblock.getIncludeFlareSoftwareUpdate()));
            row = writeAnswer(contentStream, row, questionWidth,
                    "# of existing VNX Block arrays for Health Check",
                    int2String(vblock.getBlockArraysNum()));
            row = writeAnswer(contentStream, row, questionWidth,
                    "# of existing SAN switches for Health Check",
                    int2String(vblock.getSanSwitchesNum()));
            row = writeAnswer(contentStream, row, questionWidth,
                    "# of existing SAN hosts for health check",
                    int2String(vblock.getSanHostsNum()));
        }

        HealthCheckVmwareVirtualInfrastructure vmware = healthCheckRequestData.getVmwareVirtualInfrastructure();
        if (vmware != null && servicesScope != null && servicesScope.isVmwareVirtualInfrastructure()) {
            row++;
            row = writeFont(contentStream, "VMWARE VIRTUAL INFRASTRUCTURE HEALTH-CHECK", ++row, 0, true);
            row = writeAnswer(contentStream, row, questionWidth,
                    "Include the Vmware Health Check Executive Summary review with the Project Sponsor?",
                    bool2String(vmware.getIncludeExecutiveSummaryReview()));
            row = writeAnswer(contentStream, row, questionWidth,
                    "# of Assessment interviews?",
                    int2String(vmware.getAssessmentInterviewsNum()));
            row = writeAnswer(contentStream, row, questionWidth,
                    "# of existing ESX/ESXi Servers?",
                    int2String(vmware.getEsxServersNum()));
            row = writeAnswer(contentStream, row, questionWidth,
                    "# of existing VMware virtual hosts?",
                    int2String(vmware.getVirtualHostsNum()));
        }

        HealthCheckVplex vplex = healthCheckRequestData.getVplex();
        if (vplex != null && servicesScope != null && servicesScope.isVplex()) {
            row++;
            row = writeFont(contentStream, "VPLEX HEALTH-CHECK", ++row, 0, true);
            row = writeAnswer(contentStream, row, questionWidth,
                    "# of VPLEX Clusters reviewed in each Health Check event?",
                    int2String(vplex.getClustersReviewedNum()));
            row = writeAnswer(contentStream, row, questionWidth,
                    "# of Health Checks Events sold to customer",
                    int2String(vplex.getEventsSoldNum()));
        }

        return row;
    }

    /**
     * Get ASD services scope.
     *
     * @param servicesScope
     *            the ASD services scope
     * @return ASD services scope.
     * @since SRT Phase 3-4 - ASD and Healthcheck Tabs Assembly
     */
    private static List<String> getASDRequestDataServicesScope(ASDServicesScope servicesScope) {

        List<String> options = new ArrayList<String>();
        if (servicesScope != null) {
            if (servicesScope.isNcm()) {
                options.add("NCM");
            }
            if (servicesScope.isAppSync()) {
                options.add("AppSync");
            }
            if (servicesScope.isUim()) {
                options.add("UIM");
            }
        }
        return options;
    }

    /**
     * Write ASD request data.
     *
     * @param contentStream
     *            the stream
     * @param asdRequestData
     *            the asdRequestData
     * @param row
     *            the start row number
     * @param page
     *            the PDF page
     * @return the new row number
     * @throws IOException
     *             if any IO error occurs
     * @since SRT Phase 3-4 - ASD and Healthcheck Tabs Assembly
     */
    private int writeASDRequestData(PDPageContentStream contentStream,
            ASDRequestData asdRequestData, int row, PDPage page) throws IOException {
        float questionWidth = 200f;
        row = writeFont(contentStream, "Services & Activities - ASD", ++row, 0, true);

        // General information
        row++;

        row = writeFont(contentStream, "GENERAL INFORMATION", ++row, 0, true);
        row = writeAnswer(contentStream, row, questionWidth,
                "General Comment", trimToEmpty(asdRequestData.getGeneralComment()));

        int columnNum = 3;
        float columnWidth = 150f;

        // Services scope
        ASDServicesScope servicesScope = asdRequestData.getServicesScope();
        row++;
        row = writeFont(contentStream, "SERVICES TO BE SCOPED IN THIS BOE", ++row, 0, true);
        List<String> options = getASDRequestDataServicesScope(servicesScope);
        row = writeOptions(contentStream, options, ++row, 0, columnNum, columnWidth);

        row = writeASDRequestDataAppSync(contentStream, asdRequestData, row, page);

        row = writeASDRequestDataUIM(contentStream, asdRequestData, row, page);

        return row;
    }

    /**
     * Write ASD UIM info.
     *
     * @param contentStream
     *            the stream
     * @param asdRequestData
     *            the asdRequestData
     * @param row
     *            the start row number
     * @param page
     *            the PDF page
     * @return the new row number
     * @throws IOException
     *             if any IO error occurs
     * @since SRT Phase 3-4 - ASD and Healthcheck Tabs Assembly
     */
    private int writeASDRequestDataUIM(PDPageContentStream contentStream,
            ASDRequestData asdRequestData, int row, PDPage page) throws IOException {

        ASDUIM uim = asdRequestData.getUim();

        if (uim != null && asdRequestData.getServicesScope() != null
                && asdRequestData.getServicesScope().isUim()) {

            float questionWidth = 320f;
            row++;
            row = writeFont(contentStream, "UIM", ++row, 0, true);

            row = writeAnswer(contentStream, row, questionWidth,
                    "Install Type?",
                    lookupEntity2String(uim.getInstallType()));
            row = writeAnswer(contentStream, row, questionWidth,
                    "Upgrade Type?",
                    lookupEntity2String(uim.getUpgradeType()));

            row = writeAnswer(contentStream, row, questionWidth,
                    "Include Remote OS Install Agent?",
                    bool2String(uim.getIncludeRemoteInstallAgent()));
            if (uim.getIncludeRemoteInstallAgent() != null
                    && uim.getIncludeRemoteInstallAgent()) {
                row = writeAnswer(contentStream, row, questionWidth,
                        "# of Remote Install Agents?",
                        int2String(uim.getRemoteInstallAgentsNum()));
            }

            if (uim.getInstallType() != null && (
                "UIM/P".equals(uim.getInstallType().getName())
                  || "Both".equals(uim.getInstallType().getName()))) {
                row = writeAnswer(contentStream, row, questionWidth,
                        "# of UIM / Provisioning vApps to Install",
                        int2String(uim.getUimProvisioningVAppsNum()));
                row = writeAnswer(contentStream, row, questionWidth,
                        "# of Isolation Zones to Add",
                        int2String(uim.getIsolationZonesNum()));
                row = writeAnswer(contentStream, row, questionWidth,
                        "Include integration with VMware vCenter Orchestrator (vCO)?",
                        bool2String(uim.getIncludeVCO()));
                if (uim.getIncludeVCO() != null && uim.getIncludeVCO()) {
                    row = writeAnswer(contentStream, row, questionWidth,
                            "Total # of vCenter Instances to Add",
                            int2String(uim.getVcenterInstancesNum()));
                }
            }

            if (uim.getUpgradeType() != null && (
                "UIM/P".equals(uim.getUpgradeType().getName())
                  || "Both".equals(uim.getUpgradeType().getName()))) {
                row = writeAnswer(contentStream, row, questionWidth,
                        "# of UIM / Provisioning version 3.x Servers to Upgrade",
                        int2String(uim.getUimProvisioningServersNum()));
            }

            row = writeAnswer(contentStream, row, questionWidth,
                    "# of vCloud Director Instances to Add",
                    int2String(uim.getVcloudDirectorInstancesNum()));
            row = writeAnswer(contentStream, row, questionWidth,
                    "# of Converged Hardware Systems to Discover by UIM / Provisioning",
                    int2String(uim.getConvergedHardwareSystemsNum()));
            row = writeAnswer(contentStream, row, questionWidth,
                    "# of Blade and Storage Grades to Add and Assign to Pools",
                    int2String(uim.getBladeStorageGradesNum()));
            row = writeAnswer(contentStream, row, questionWidth,
                    "# of Identity (UUID, MAC, IP, WWNN, WWPN) Pools to Add",
                    int2String(uim.getIdentityPoolsNum()));
            row = writeAnswer(contentStream, row, questionWidth,
                    "# of Network Profiles to Set",
                    int2String(uim.getNetworkProfilesNum()));
            row = writeAnswer(contentStream, row, questionWidth,
                    "# of UIM / Operations vApps to Install",
                    int2String(uim.getUimOperationsVAppsNum()));
            row = writeAnswer(contentStream, row, questionWidth,
                    "# of Service Offerings to Create",
                    int2String(uim.getServiceOfferingsToCreateNum()));
            row = writeAnswer(contentStream, row, questionWidth,
                    "# of Services to Create",
                    int2String(uim.getServicesToCreateNum()));
            row = writeAnswer(contentStream, row, questionWidth,
                    "# of Blades to Provision",
                    int2String(uim.getBladesToProvisionNum()));
            row = writeAnswer(contentStream, row, questionWidth,
                    "# of LUNs (block/RDM/File) to Provision",
                    int2String(uim.getLunsToProvisionNum()));
            row = writeAnswer(contentStream, row, questionWidth,
                    "# of Services to Provision with OS Install",
                    int2String(uim.getServicesToProvisionNum()));

            if (uim.getInstallType() != null && (
                "UIM/O".equals(uim.getInstallType().getName())
                  || "Both".equals(uim.getInstallType().getName()))) {
                row = writeAnswer(contentStream, row, questionWidth,
                        "# of Data Sources added to UIM / Operations",
                        int2String(uim.getDataSourcesNum()));
                row = writeAnswer(contentStream, row, questionWidth,
                        "# of SNMP Alerts and/or Syslogs Forwarding Setup to External Management Systems",
                        int2String(uim.getSnmpAlertsNum()));
            }

            if (uim.getUpgradeType() != null && (
                    "UIM/O".equals(uim.getUpgradeType().getName())
                      || "Both".equals(uim.getUpgradeType().getName()))) {
                row = writeAnswer(contentStream, row, questionWidth,
                        "# of UIM Operations Servers to Upgrade from 3.x",
                        int2String(uim.getUimOperationsServersNum()));
                row = writeAnswer(contentStream, row, questionWidth,
                        "# of UIM / Operations Users to Create",
                        int2String(uim.getUimOperationsUsersNum()));
            }

            row = writeAnswer(contentStream, row, questionWidth,
                    "Perfrom Elastic Provisioning?",
                    bool2String(uim.getPerformElasticProvisioning()));
            if (uim.getPerformElasticProvisioning() != null
                    && uim.getPerformElasticProvisioning()) {
                row = writeAnswer(contentStream, row, questionWidth,
                        "# of Services Requiring Elastic Operations",
                        int2String(uim.getServicesRequiringElasticOperationsNum()));
                row = writeAnswer(contentStream, row, questionWidth,
                        "# of Blades Impacted by vNIC Elastic Operations",
                        int2String(uim.getBladesImpactedNum()));
            }

            row = writeAnswer(contentStream, row, questionWidth,
                    "Migrate Services from non-UIM Converged Hardware Systems to UIM management?",
                    bool2String(uim.getMigrateServices()));
            if (uim.getMigrateServices() != null && uim.getMigrateServices()) {
                row = writeAnswer(contentStream, row, questionWidth,
                        "# of non-UIM Converged Hardware Systems adopted/migrated to UIM",
                        int2String(uim.getNonUIMConvergedHardwareSystemsNum()));
                row = writeAnswer(contentStream, row, questionWidth,
                        "# of Services From non-UIM Converged Hardware Systems Adopted/Migrated to UIM",
                        int2String(uim.getServicesAdoptedMigratedNum()));
                row = writeAnswer(contentStream, row, questionWidth,
                        "# of Blades Adopted/Migrated",
                        int2String(uim.getBladesAdoptedMigratedNum()));
            }

            row = writeAnswer(contentStream, row, questionWidth,
                    "Is the Customer Known to be Difficult to Meet UIM Pre-install Requirements",
                    bool2String(uim.getCustomerKnown()));
            if (uim.getCustomerKnown() != null && uim.getCustomerKnown()) {
                row = writeAnswer(contentStream, row, questionWidth,
                        "# of Hours to remediate UIM pre-install issues",
                        decimal2String(uim.getRemediateHours(), 2));
            }

            row = writeAnswer(contentStream, row, questionWidth,
                    "# of Hours for Additional Knowledge Transfer (SA effort)?",
                    decimal2String(uim.getSaKnowledgeTransferHours(), 2));
            row = writeAnswer(contentStream, row, questionWidth,
                    "# of Hours for Additional Knowledge Transfer (IS effort)?",
                    decimal2String(uim.getIsKnowledgeTransferHours(), 2));
        }
        return row;
    }

    /**
     * Write ASD AppSync info.
     *
     * @param contentStream
     *            the stream
     * @param asdRequestData
     *            the asdRequestData
     * @param row
     *            the start row number
     * @param page
     *            the PDF page
     * @return the new row number
     * @throws IOException
     *             if any IO error occurs
     * @since SRT Phase 3-4 - ASD and Healthcheck Tabs Assembly
     */
    private int writeASDRequestDataAppSync(PDPageContentStream contentStream,
            ASDRequestData asdRequestData, int row, PDPage page) throws IOException {

        ASDAppSync appSync = asdRequestData.getAppSync();

        if (appSync != null && asdRequestData.getServicesScope() != null
                && asdRequestData.getServicesScope().isAppSync()) {

            float questionWidth = 320f;
            row++;
            row = writeFont(contentStream, "APPSYNC", ++row, 0, true);

            row = writeAnswer(contentStream, row, questionWidth,
                    "Install VSI AppSync Management Plugin?",
                    bool2String(appSync.getInstallVSI()));

            row = writeAnswer(contentStream, row, questionWidth,
                    "# of AppSync Instances Installed?",
                    int2String(appSync.getAppSyncInstancesNum()));
            row = writeAnswer(contentStream, row, questionWidth,
                    "# of vCenter Servers Discovered?",
                    int2String(appSync.getvCenterServersNum()));
            row = writeAnswer(contentStream, row, questionWidth,
                    "# of Application Production Hosts Discovered?",
                    int2String(appSync.getApplicationProductionHostsNum()));
            row = writeAnswer(contentStream, row, questionWidth,
                    "# of VNX Arrays Discovered?",
                    int2String(appSync.getVnxArraysNum()));
            row = writeAnswer(contentStream, row, questionWidth,
                    "# of Application Mount Hosts Discovered?",
                    int2String(appSync.getApplicationMountHostsNum()));
            row = writeAnswer(contentStream, row, questionWidth,
                    "# of RecoverPoint Appliances Discovered?",
                    int2String(appSync.getRecoverPointAppliancesNum()));

            row = writeAnswer(contentStream, row, questionWidth,
                    "# of hours for additional knowledge transfer (IS effort)?",
                    decimal2String(appSync.getKnowledgeTransferHours(), 2));
        }
        return row;
    }

    /**
     * Get SourceOne services scope.
     *
     * @param servicesScope
     *            the SourceOne services scope
     * @return SourceOne services scope.
     * @since SRT Phase 3-3 - Remove BRS and Isilon and Update Residency and Implement SourceOne Tabs Assembly
     */
    private static List<String> getSourceOneRequestDataServicesScope(SourceOneServicesScope servicesScope) {

        List<String> options = new ArrayList<String>();
        if (servicesScope != null) {
            if (servicesScope.isDesignAndImpl()) {
                options.add("Design & Implement");
            }
            if (servicesScope.isUpgrade()) {
                options.add("Upgrade");
            }
            if (servicesScope.isMigration()) {
                options.add("In Place Migration");
            }
            if (servicesScope.isHealthCheck()) {
                options.add("HealthCheck");
            }
        }
        return options;
    }

    /**
     * Write SourceOne request data.
     *
     * @param contentStream
     *            the stream
     * @param sourceOneRequestData
     *            the sourceOneRequestData
     * @param row
     *            the start row number
     * @param page
     *            the PDF page
     * @return the new row number
     * @throws IOException
     *             if any IO error occurs
     * @since SRT Phase 3-3 - Remove BRS and Isilon and Update Residency and Implement SourceOne Tabs Assembly
     */
    private int writeSourceOneRequestData(PDPageContentStream contentStream,
            SourceOneRequestData sourceOneRequestData, int row, PDPage page) throws IOException {
        float questionWidth = 200f;
        row = writeFont(contentStream, "Services & Activities - SourceOne", ++row, 0, true);

        // General information
        row++;

        row = writeFont(contentStream, "GENERAL INFORMATION", ++row, 0, true);
        row = writeAnswer(contentStream, row, questionWidth,
                "# of sites involved", int2String(sourceOneRequestData.getSitesInvolvedNum()));

        SourceOneServicesScope servicesScope = sourceOneRequestData.getServicesScope();

        BigDecimal totalKnowledgeTransferHours = new BigDecimal(0);

        if (servicesScope != null) {
            if (servicesScope.isDesignAndImpl() && sourceOneRequestData.getDesignImpl() != null
                    && sourceOneRequestData.getDesignImpl().getKnowledgeTransferHours() != null) {
                totalKnowledgeTransferHours = totalKnowledgeTransferHours.add(sourceOneRequestData.getDesignImpl()
                        .getKnowledgeTransferHours());
            }
            if (servicesScope.isUpgrade() && sourceOneRequestData.getUpgrade() != null
                    && sourceOneRequestData.getUpgrade().getKnowledgeTransferHours() != null) {
                totalKnowledgeTransferHours = totalKnowledgeTransferHours.add(sourceOneRequestData.getUpgrade()
                        .getKnowledgeTransferHours());
            }
            if (servicesScope.isMigration() && sourceOneRequestData.getMigration() != null
                    && sourceOneRequestData.getMigration().getKnowledgeTransferHours() != null) {
                totalKnowledgeTransferHours = totalKnowledgeTransferHours.add(sourceOneRequestData.getMigration()
                        .getKnowledgeTransferHours());
            }
            if (servicesScope.isHealthCheck() && sourceOneRequestData.getHealthCheck() != null
                    && sourceOneRequestData.getHealthCheck().getKnowledgeTransferHours() != null) {
                totalKnowledgeTransferHours = totalKnowledgeTransferHours.add(sourceOneRequestData
                        .getHealthCheck().getKnowledgeTransferHours());
            }
        }

        row = writeAnswer(contentStream, row, questionWidth,
                "totalKnowledgeTransferHours", decimal2String(totalKnowledgeTransferHours, 2));
        row = writeAnswer(contentStream, row, questionWidth,
                "General Comment", trimToEmpty(sourceOneRequestData.getGeneralComment()));

        int columnNum = 2;
        float columnWidth = 150f;

        // Services scope
        row++;
        row = writeFont(contentStream, "SOURCEONE", ++row, 0, true);
        List<String> options = getSourceOneRequestDataServicesScope(servicesScope);
        row = writeOptions(contentStream, options, ++row, 0, columnNum, columnWidth);

        row++;
        row = writeAnswer(contentStream, row, questionWidth, "Has a BRS Source One SME been engaged yet? Who? **If " +
            "you did not get pre-review from Source One SME, your SLA may be extended.**",
            trimToEmpty(sourceOneRequestData.getBrsSMEEngagementComment()));

        // Design & Implement
        row = writeSourceOneRequestDataDesignAndImpl(contentStream, sourceOneRequestData, row, page);

        // Upgrade
        row = writeSourceOneRequestDataUpgrade(contentStream, sourceOneRequestData, row, page);

        // Migration
        row = writeSourceOneRequestDataMigration(contentStream, sourceOneRequestData, row, page);

        // Health Check
        row = writeSourceOneRequestDataHealthCheck(contentStream, sourceOneRequestData, row, page);

        return row;
    }

    /**
     * Get SourceOne features.
     *
     * @param features
     *            the SourceOne features
     * @return SourceOne features.
     * @since SRT Phase 3-3 - Remove BRS and Isilon and Update Residency and Implement SourceOne Tabs Assembly
     */
    private static List<String> getSourceOneRequestDataFeatures(SourceOneFeatures features) {

        List<String> options = new ArrayList<String>();
        if (features != null) {
            if (features.isEmailArchiving()) {
                options.add("Email Archiving");
            }
            if (features.isDiscoveryManager()) {
                options.add("Discovery Manager");
            }
            if (features.isSharePointArchiving()) {
                options.add("SharePoint Archiving");
            }
            if (features.isFileArchiving()) {
                options.add("File Archiving");
            }
            if (features.isEmailSupervisor()) {
                options.add("Email Supervisor");
            }
            if (features.isSharePointStorageManagment()) {
                options.add("SharePoint Storage Managment");
            }
            if (features.isCloudTieringAppMgmt()) {
                options.add("Cloud Tiering App Mgmt");
            }
        }
        return options;
    }

    /**
     * Get SourceOne DR options.
     *
     * @param drOptions
     *            the SourceOne DR options
     * @return SourceOne DR options.
     * @since SRT Phase 3-3 - Remove BRS and Isilon and Update Residency and Implement SourceOne Tabs Assembly
     */
    private static List<String> getSourceOneRequestDataDrOptions(SourceOneDROptions drOptions) {

        List<String> options = new ArrayList<String>();
        if (drOptions != null) {
            if (drOptions.isFullDR()) {
                options.add("Full DR Implementation");
            }
            if (drOptions.isDrPlanning()) {
                options.add("DR Planning");
            }
            if (drOptions.isDrTesting()) {
                options.add("DR Failover\\Failback Testing");
            }
        }
        return options;
    }

    /**
     * Write SourceOne upgrade info.
     *
     * @param contentStream
     *            the stream
     * @param sourceOneRequestData
     *            the sourceOneRequestData
     * @param row
     *            the start row number
     * @param page
     *            the PDF page
     * @return the new row number
     * @throws IOException
     *             if any IO error occurs
     * @since SRT Phase 3-3 - Remove BRS and Isilon and Update Residency and Implement SourceOne Tabs Assembly
     */
    private int writeSourceOneRequestDataUpgrade(PDPageContentStream contentStream,
            SourceOneRequestData sourceOneRequestData, int row, PDPage page) throws IOException {
        SourceOneUpgrade upgrade = sourceOneRequestData.getUpgrade();

        if (upgrade != null && sourceOneRequestData.getServicesScope() != null
                && sourceOneRequestData.getServicesScope().isUpgrade()) {
            float questionWidth = 280f;
            row++;
            row = writeFont(contentStream, "UPGRADE", ++row, 0, true);

            row = writeAnswer(contentStream, row, questionWidth,
                    "# of hours of knowledge transfer",
                    decimal2String(upgrade.getKnowledgeTransferHours(), 2));

            row = writeAnswer(contentStream, row, questionWidth,
                    "Current level/version of software (6.5/6.6/6.7/6.8.1/6.8.2)?",
                    trimToEmpty(upgrade.getCurrentVersion()));

            row = writeAnswer(contentStream, row, questionWidth,
                    "Upgrade level/version to: (6.8.2 or 7.0) ?",
                    trimToEmpty(upgrade.getUpgradeVersion()));

            row = writeAnswer(contentStream, row, questionWidth,
                    "Number of Master Servers?",
                    int2String(upgrade.getMasterServersNum()));

            row = writeAnswer(contentStream, row, questionWidth,
                    "Number of Worker Servers?",
                    int2String(upgrade.getWorkerServersNum()));

            row = writeAnswer(contentStream, row, questionWidth,
                    "Number of billable hours for additional testing to be done by IS?",
                    int2String(upgrade.getBillableHoursNum()));
        }
        return row;
    }

    /**
     * Write SourceOne migration info.
     *
     * @param contentStream
     *            the stream
     * @param sourceOneRequestData
     *            the sourceOneRequestData
     * @param row
     *            the start row number
     * @param page
     *            the PDF page
     * @return the new row number
     * @throws IOException
     *             if any IO error occurs
     * @since SRT Phase 3-3 - Remove BRS and Isilon and Update Residency and Implement SourceOne Tabs Assembly
     */
    private int writeSourceOneRequestDataMigration(PDPageContentStream contentStream,
            SourceOneRequestData sourceOneRequestData, int row, PDPage page) throws IOException {
        SourceOneMigration migration = sourceOneRequestData.getMigration();

        if (migration != null && sourceOneRequestData.getServicesScope() != null
                && sourceOneRequestData.getServicesScope().isMigration()) {
            float questionWidth = 280f;
            row++;
            row = writeFont(contentStream, "IN-PLACE MIGRATION", ++row, 0, true);

            row = writeAnswer(contentStream, row, questionWidth,
                    "# of hours of knowledge transfer",
                    decimal2String(migration.getKnowledgeTransferHours(), 2));

            row = writeAnswer(contentStream, row, questionWidth,
                    "Number of EmailXtender Servers?",
                    int2String(migration.getEmailXtenderServersNum()));

            row = writeAnswer(contentStream, row, questionWidth,
                    "Total Size (TB) of the EmailXtender Archive to be migrated?",
                    int2String(migration.getMigratedSize()));

            row = writeAnswer(contentStream, row, questionWidth,
                    "Number of billable hours for additional testing to be done by IS?",
                    int2String(migration.getBillableHoursNum()));
        }
        return row;
    }

    /**
     * Write SourceOne health check info.
     *
     * @param contentStream
     *            the stream
     * @param sourceOneRequestData
     *            the sourceOneRequestData
     * @param row
     *            the start row number
     * @param page
     *            the PDF page
     * @return the new row number
     * @throws IOException
     *             if any IO error occurs
     * @since SRT Phase 3-3 - Remove BRS and Isilon and Update Residency and Implement SourceOne Tabs Assembly
     */
    private int writeSourceOneRequestDataHealthCheck(PDPageContentStream contentStream,
            SourceOneRequestData sourceOneRequestData, int row, PDPage page) throws IOException {
        SourceOneHealthCheck healthCheck = sourceOneRequestData.getHealthCheck();

        if (healthCheck != null && sourceOneRequestData.getServicesScope() != null
                && sourceOneRequestData.getServicesScope().isHealthCheck()) {
            float questionWidth = 280f;
            row++;
            row = writeFont(contentStream, "HEALTHCHECK", ++row, 0, true);

            row = writeAnswer(contentStream, row, questionWidth,
                    "# of hours of knowledge transfer",
                    decimal2String(healthCheck.getKnowledgeTransferHours(), 2));

            row = writeAnswer(contentStream, row, questionWidth,
                    "Number of servers?",
                    int2String(healthCheck.getServersNum()));

            row = writeAnswer(contentStream, row, questionWidth,
                    "Number of assesment interviews?",
                    int2String(healthCheck.getAssessmentInterviewsNum()));

            row = writeAnswer(contentStream, row, questionWidth,
                    "Number of Master Servers?",
                    int2String(healthCheck.getMasterServersNum()));

            row = writeAnswer(contentStream, row, questionWidth,
                    "Number of Worker Servers?",
                    int2String(healthCheck.getWorkerServersNum()));
        }
        return row;
    }

    /**
     * Write SourceOne design and implement info.
     *
     * @param contentStream
     *            the stream
     * @param sourceOneRequestData
     *            the sourceOneRequestData
     * @param row
     *            the start row number
     * @param page
     *            the PDF page
     * @return the new row number
     * @throws IOException
     *             if any IO error occurs
     * @since SRT Phase 3-3 - Remove BRS and Isilon and Update Residency and Implement SourceOne Tabs Assembly
     */
    private int writeSourceOneRequestDataDesignAndImpl(PDPageContentStream contentStream,
            SourceOneRequestData sourceOneRequestData, int row, PDPage page) throws IOException {
        SourceOneDesignImpl designImpl = sourceOneRequestData.getDesignImpl();

        if (designImpl != null && sourceOneRequestData.getServicesScope() != null
                && sourceOneRequestData.getServicesScope().isDesignAndImpl()) {
            float questionWidth = 280f;
            row++;
            row = writeFont(contentStream, "DESIGN & IMPLEMENT", ++row, 0, true);

            row = writeAnswer(contentStream, row, questionWidth,
                    "# of hours of knowledge transfer",
                    decimal2String(designImpl.getKnowledgeTransferHours(), 2));

            row = writeAnswer(contentStream, row, questionWidth,
                    "How many mailboxes?",
                    int2String(designImpl.getMailboxesNum()));

            row = writeAnswer(contentStream, row, questionWidth,
                    "Include SourceOne Piolt? (Y/N)",
                    bool2String(designImpl.getIncludePiolt()));

            row = writeAnswer(contentStream, row, questionWidth,
                    "Include a SourceOne Meeting on Determining the retention & disposition policies? (Y/N)",
                    bool2String(designImpl.getIncludeMeeting()));

            row = writeFont(contentStream, "Select SourceOne Features to be implemented", ++row, 0, false);
            SourceOneFeatures features = designImpl.getFeatures();
            row = writeOptions(contentStream, getSourceOneRequestDataFeatures(features), row, questionWidth, 2,
                    130f);

            row = writeFont(contentStream, "Select SourceOne Disaster Recovery option", ++row, 0, false);
            row = writeOptions(contentStream, getSourceOneRequestDataDrOptions(designImpl.getDrOptions()), row,
                    questionWidth, 2, 130f);

            row = writeAnswer(contentStream, row, questionWidth,
                    "Include solution validation sizing? (Y/N)",
                    bool2String(designImpl.getIncludeValidationSizing()));

            if (features != null && features.isEmailArchiving()) {
                row = writeAnswer(contentStream, row, questionWidth,
                        "Include Shortcutting? (Email) (Y/N)",
                        bool2String(designImpl.getIncludeShortcutEmail()));
            }
            if (features != null && features.isFileArchiving()) {
                row = writeAnswer(contentStream, row, questionWidth,
                        "Include Shortcutting? (File Archive) (Y/N)",
                        bool2String(designImpl.getIncludeShortcutFileArchive()));
            }
            if (features != null && features.isEmailSupervisor()) {
                row = writeAnswer(contentStream, row, questionWidth,
                        "Include advance Lexicon Query design & creation? (Y/N)",
                        bool2String(designImpl.getIncludeLexiconQuery()));
                row = writeAnswer(contentStream, row, questionWidth,
                        "Number of users to be supervised with Supervisor?",
                        int2String(designImpl.getSupervisedUsersNum()));
            }
            row = writeAnswer(contentStream, row, questionWidth,
                    "Number of Master Servers?",
                    int2String(designImpl.getMasterServersNum()));
            if (features != null && features.isEmailArchiving()) {
                row = writeAnswer(contentStream, row, questionWidth,
                        "Number of Worker Servers to perform Email Management?",
                        int2String(designImpl.getEmailMgmtServersNum()));
            }
            if (features != null && features.isSharePointArchiving()) {
                row = writeAnswer(contentStream, row, questionWidth,
                        "Number of Worker Servers to be used for SharePoint Archiving?",
                        int2String(designImpl.getSharePointArchivingServersNum()));
            }
            if (features != null && features.isFileArchiving()) {
                row = writeAnswer(contentStream, row, questionWidth,
                        "Number of Worker Servers to be used for File Archiving?",
                        int2String(designImpl.getFileArchivingServersNum()));
            }
            row = writeAnswer(contentStream, row, questionWidth,
                    "Number of Management Console(s)?",
                    int2String(designImpl.getMgmtConsolesNum()));
            if (features != null && features.isEmailArchiving()) {
                row = writeAnswer(contentStream, row, questionWidth,
                        "Number of Mapped Folders to Configure and Map these to the particular archive folder?",
                        int2String(designImpl.getMappedFoldersNum()));
                row = writeAnswer(contentStream, row, questionWidth,
                        "Number of Organization Policies for Email Archive?",
                        int2String(designImpl.getEmailArchivePoliciesNum()));
            }
            if (features != null && features.isFileArchiving()) {
                row = writeAnswer(contentStream, row, questionWidth,
                        "Number of Organization Policies for File Archive?",
                        int2String(designImpl.getFileArchivePoliciesNum()));
            }
            if (features != null && features.isDiscoveryManager()) {
                row = writeAnswer(contentStream, row, questionWidth,
                        "Number of Discovery Manager Admin Console?",
                        int2String(designImpl.getDisManagerAdminConsoleNum()));
                row = writeAnswer(contentStream, row, questionWidth,
                        "Number of Discovery Manager Client?",
                        int2String(designImpl.getDisManagerClientNum()));
                row = writeAnswer(contentStream, row, questionWidth,
                        "Number of Hold Folders?",
                        int2String(designImpl.getHoldFoldersNum()));
                row = writeAnswer(contentStream, row, questionWidth,
                        "Number of Sample Matter?",
                        int2String(designImpl.getSampleMatterNum()));
                row = writeAnswer(contentStream, row, questionWidth,
                        "Number of Legal Hold Folders to Configure?",
                        int2String(designImpl.getLegalHoldFoldersNum()));
            }
            if (features != null && features.isSharePointArchiving()) {
                row = writeAnswer(contentStream, row, questionWidth,
                        "Number of SharePoint Farms? (SP Archive)",
                        int2String(designImpl.getArchiveSharePointFarmsNum()));
            }
            if (features != null && features.isSharePointStorageManagment()) {
                row = writeAnswer(contentStream, row, questionWidth,
                        "Number of SharePoint Farms? (SP Storage Mangment)",
                        int2String(designImpl.getStorageMgmtSharePointFarmsNum()));
            }
            if (features != null && features.isFileArchiving()) {
                row = writeAnswer(contentStream, row, questionWidth,
                        "Number of File Archive Mapped Folders?",
                        int2String(designImpl.getFileArchiveMappedFoldersNum()));
                row = writeAnswer(contentStream, row, questionWidth,
                        "Number of Organization Policies to be configured for File Archive?",
                        int2String(designImpl.getFileArchivePolicesToBeConfiguredNum()));
            }
            if (features != null && features.isCloudTieringAppMgmt()) {
                row = writeAnswer(contentStream, row, questionWidth,
                        "Number of Cloud Tiering Appliances?",
                        int2String(designImpl.getCloudTieringAppliancesNum()));
            }
            if (features != null && features.isEmailSupervisor()) {
                row = writeAnswer(contentStream, row, questionWidth,
                        "Number of reviewer clients?",
                        int2String(designImpl.getReviewerClientsNum()));
            }
        }

        return row;
    }

    /**
     * Write Residency request data.
     *
     * @param contentStream
     *            the stream
     * @param residencyRequestData
     *            the residencyRequestData
     * @param row
     *            the start row number
     * @param page
     *            the PDF page
     * @return the new row number
     * @throws IOException
     *             if any IO error occurs
     * @since SRT Phase 3-3 - Isilon and Residency Tabs Assembly
     */
    private int writeResidencyRequestData(PDPageContentStream contentStream, ResidencyRequestData residencyRequestData,
        int row, PDPage page) throws IOException {
        float questionWidth = 200f;
        row = writeFont(contentStream, "Services & Activities - Residency", ++row, 0, true);

        row = writeAnswer(contentStream, row, questionWidth,
                "General Comment", trimToEmpty(residencyRequestData.getGeneralComment()));

        row = writeAnswer(contentStream, row, questionWidth, "Payment Type",
                lookupEntity2String(residencyRequestData.getPaymentType()));

        row = writeAnswer(contentStream, row, questionWidth, "Location (City/State) of the Engagement",
                trimToEmpty(residencyRequestData.getLocation()));

        row = writeAnswer(contentStream, row, questionWidth, "Any Special Conditions?",
                trimToEmpty(residencyRequestData.getSpecialConditions()));

        row = writeAnswer(contentStream, row, questionWidth, "Work-week start day",
                lookupEntity2String(residencyRequestData.getWorkStartDay()));

        row = writeAnswer(contentStream, row, questionWidth, "Work-week end day",
                lookupEntity2String(residencyRequestData.getWorkEndDay()));

        row = writeAnswer(contentStream, row, questionWidth, "Approximate Start Date",
                residencyRequestData.getApproximateStartDate() == null ? "" : new SimpleDateFormat(
                        DEFAULT_DATE_FORMAT).format(residencyRequestData.getApproximateStartDate()));

        row = writeAnswer(contentStream, row, questionWidth, "# of work hours in a month",
                decimal2String(residencyRequestData.getWorkHoursNum(), 2));

        if (residencyRequestData.getRoleSkillLevels() != null) {
            row++;
            row = writeFont(contentStream, "ROLE / SKILL LEVEL SECTION BELOW", ++row, 0, true);

            row = writeAnswer(contentStream, row, questionWidth, "Special Handling Instructions",
                    trimToEmpty(residencyRequestData.getRoleSkillLevels().getSpecialHandlingInstructions()));

            float margin = 30;
            float[] columnsWidth = new float[] {140, 65, 70, 
                    page.findMediaBox().getWidth() - 2 * margin - 70 - 65 - 140};

            row += drawTable(page, contentStream, getYPos(++row), margin,
                    getResidencyBackupContent(residencyRequestData.getRoleSkillLevels().getBackup()), false,
                    columnsWidth);

            row += drawTable(page, contentStream, getYPos(++row), margin,
                    getResidencyProjectManagementContent(
                        residencyRequestData.getRoleSkillLevels().getProjectManagement()), false, columnsWidth);

            row += drawTable(page, contentStream, getYPos(++row), margin,
                    getResidencySysAdminContent(residencyRequestData.getRoleSkillLevels().getSystemAdmin()), false, 
                columnsWidth);

            row += drawTable(page, contentStream, getYPos(++row), margin,
                    getResidencyStorageContent(residencyRequestData.getRoleSkillLevels().getStorage()), false, 
                columnsWidth);

            row += drawTable(page, contentStream, getYPos(++row), margin,
                    getResidencySupportContent(residencyRequestData.getRoleSkillLevels().getSupport()), false, 
                columnsWidth);

            row += drawTable(page, contentStream, getYPos(++row), margin,
                    getResidencyVmwareContent(residencyRequestData.getRoleSkillLevels().getVmware()), false, 
                columnsWidth);

            row += drawTable(page, contentStream, getYPos(++row), margin,
                getResidencyOtherContent(residencyRequestData.getRoleSkillLevels().getArchive(), "Archive"), false,
                columnsWidth);
            row += drawTable(page, contentStream, getYPos(++row), margin,
                getResidencyOtherContent(residencyRequestData.getRoleSkillLevels().getCloud(), "Cloud"), false,
                columnsWidth);
            row += drawTable(page, contentStream, getYPos(++row), margin,
                getResidencyOtherContent(residencyRequestData.getRoleSkillLevels().getDataWareHouse(),
                    "Data Warehouse"), false, columnsWidth);
            row += drawTable(page, contentStream, getYPos(++row), margin,
                getResidencyOtherContent(residencyRequestData.getRoleSkillLevels().getIsilon(), "Isilon"), false,
                columnsWidth);
            row += drawTable(page, contentStream, getYPos(++row), margin,
                getResidencyOtherContent(residencyRequestData.getRoleSkillLevels().getStorageManagement(),
                    "Storage Management"), false, columnsWidth);
            row += drawTable(page, contentStream, getYPos(++row), margin,
                getResidencyOtherContent(residencyRequestData.getRoleSkillLevels().getVblock(), "Vblock"), false,
                columnsWidth);
            row += drawTable(page, contentStream, getYPos(++row), margin,
                getResidencyOtherContent(residencyRequestData.getRoleSkillLevels().getVirtualizationXtremeIO(),
                    "Virtualization & XtremeIO"), false, columnsWidth);
        }
        return row;
    }

    /**
     * Get Residency other table content.
     *
     *
     * @param roleSkillLevels
     *            Residency other levels data
     * @param title a title for the table.
     * @return Residency other content
     * @since SRT Phase 3-3 - Isilon and Residency Tabs Assembly
     */
    private static String[][] getResidencyOtherContent(List<RoleSkillLevel> roleSkillLevels, String title) {

        List<String[]> rows = new ArrayList<String[]>();
        if (roleSkillLevels != null) {
            for (RoleSkillLevel level : roleSkillLevels) {
                rows.add(getRoleSkillLevelColumns(level));
            }
        }

        String[][] contents = new String[rows.size() + 1][4];
        contents[0] = new String[] {title, "Time Period", "Quantity", "Additional Information"};
        for (int i = 0; i < rows.size(); i++) {
            contents[i + 1] = rows.get(i);
        }
        return contents;
    }

    /**
     * Get Residency vmware table content.
     *
     * @param vmware
     *            Residency vmware data
     * @return Residency vmware content
     * @since SRT Phase 3-3 - Isilon and Residency Tabs Assembly
     */
    private static String[][] getResidencyVmwareContent(Map<String, RoleSkillLevel> vmware) {

        List<String[]> rows = new ArrayList<String[]>();
        if (vmware != null) {
            for (RoleSkillLevel level : vmware.values()) {
                rows.add(getRoleSkillLevelColumns(level));
            }
        }

        String[][] contents = new String[rows.size() + 1][4];
        contents[0] = new String[] {"Vmware", "Time Period", "Quantity", "Additional Information"};
        for (int i = 0; i < rows.size(); i++) {
            contents[i + 1] = rows.get(i);
        }
        return contents;
    }

    /**
     * Get Residency support table content.
     *
     * @param support
     *            Residency support data
     * @return Residency support content
     * @since SRT Phase 3-3 - Isilon and Residency Tabs Assembly
     */
    private static String[][] getResidencySupportContent(Map<String, RoleSkillLevel> support) {

        List<String[]> rows = new ArrayList<String[]>();
        if (support != null) {
            for (RoleSkillLevel level : support.values()) {
                rows.add(getRoleSkillLevelColumns(level));
            }
        }

        String[][] contents = new String[rows.size() + 1][4];
        contents[0] = new String[] {"Support", "Time Period", "Quantity", "Additional Information"};
        for (int i = 0; i < rows.size(); i++) {
            contents[i + 1] = rows.get(i);
        }
        return contents;
    }

    /**
     * Get Residency storage table content.
     *
     * @param storage
     *            Residency storage data
     * @return Residency storage content
     * @since SRT Phase 3-3 - Isilon and Residency Tabs Assembly
     */
    private static String[][] getResidencyStorageContent(Map<String, RoleSkillLevel> storage) {

        List<String[]> rows = new ArrayList<String[]>();
        if (storage != null) {
            for (RoleSkillLevel level : storage.values()) {
                rows.add(getRoleSkillLevelColumns(level));
            }
        }

        String[][] contents = new String[rows.size() + 1][4];
        contents[0] = new String[] {"Storage", "Time Period", "Quantity", "Additional Information"};
        for (int i = 0; i < rows.size(); i++) {
            contents[i + 1] = rows.get(i);
        }
        return contents;
    }

    /**
     * Get Residency system administration table content.
     *
     * @param sysAdmin
     *            Residency system administration data
     * @return Residency system administration content
     * @since SRT Phase 3-3 - Isilon and Residency Tabs Assembly
     */
    private static String[][] getResidencySysAdminContent(Map<String, RoleSkillLevel> sysAdmin) {

        List<String[]> rows = new ArrayList<String[]>();
        if (sysAdmin != null) {
            for (RoleSkillLevel level : sysAdmin.values()) {
                rows.add(getRoleSkillLevelColumns(level));
            }
        }

        String[][] contents = new String[rows.size() + 1][4];
        contents[0] = new String[] {"System Administration", "Time Period", "Quantity", "Additional Information"};
        for (int i = 0; i < rows.size(); i++) {
            contents[i + 1] = rows.get(i);
        }
        return contents;
    }

    /**
     * Get Residency project management table content.
     *
     * @param projectManagement
     *            Residency project management data
     * @return Residency project management content
     * @since SRT Phase 3-3 - Isilon and Residency Tabs Assembly
     */
    private static String[][] getResidencyProjectManagementContent(Map<String, RoleSkillLevel> projectManagement) {

        List<String[]> rows = new ArrayList<String[]>();
        if (projectManagement != null) {
            for (RoleSkillLevel level : projectManagement.values()) {
                rows.add(getRoleSkillLevelColumns(level));
            }
        }

        String[][] contents = new String[rows.size() + 1][4];
        contents[0] = new String[] {"Project Management", "Time Period", "Quantity", "Additional Information"};
        for (int i = 0; i < rows.size(); i++) {
            contents[i + 1] = rows.get(i);
        }
        return contents;
    }

    /**
     * Get Residency backup table content.
     *
     * @param backup
     *            Residency backup data
     * @return Residency backup table content
     * @since SRT Phase 3-3 - Isilon and Residency Tabs Assembly
     */
    private static String[][] getResidencyBackupContent(Map<String, RoleSkillLevel> backup) {

        List<String[]> rows = new ArrayList<String[]>();
        if (backup != null) {
            for (RoleSkillLevel level : backup.values()) {
                rows.add(getRoleSkillLevelColumns(level));
            }
        }

        String[][] contents = new String[rows.size() + 1][4];
        contents[0] = new String[] {"Backup", "Time Period", "Quantity", "Additional Information"};
        for (int i = 0; i < rows.size(); i++) {
            contents[i + 1] = rows.get(i);
        }
        return contents;
    }

    /**
     * Convert RoleSkillLevel to array of columns.
     *
     * @param level
     *            Role skill level
     * @return columns converted
     * @since SRT Phase 3-3 - Isilon and Residency Tabs Assembly
     */
    private static String[] getRoleSkillLevelColumns(RoleSkillLevel level) {

        String[] columns = new String[4];
        columns[0] = trimToEmpty(level.getRollSkillName());
        columns[1] = trimToEmpty(level.getTimePeriod());
        columns[2] = decimal2String(level.getQuantity(), 2);
        columns[3] = trimToEmpty(level.getAdditionalInfo());
        return columns;
    }

    /**
     * Write MSS request data.
     *
     * @param contentStream
     *            the stream
     * @param mssRequestData
     *            the mssRequestData
     * @param row
     *            the start row number
     * @param page
     *            the PDF page
     * @return the new row number
     * @throws IOException
     *             if any IO error occurs
     * @since SRT Phase 3-1 - CTA Rainfinity and MSS Tabs Assembly
     */
    private int writeMSSRequestData(PDPageContentStream contentStream, MSSRequestData mssRequestData, int row,
            PDPage page) throws IOException {
        float questionWidth = 200f;
        row = writeFont(contentStream, "Services & Activities - Disk Retention", ++row, 0, true);

        // General information
        row++;

        row = writeFont(contentStream, "General Information", ++row, 0, true);

        row = writeAnswer(contentStream, row, questionWidth,
                "Service Scope Description",
                trimToEmpty(mssRequestData.getServiceScopeDescription()));

        row = writeAnswer(contentStream, row, questionWidth,
                "General Comment",
                trimToEmpty(mssRequestData.getGeneralComment()));

        row++;
        row = writeFont(contentStream, "DISK RETENTION AND ERASURE SERVICES", ++row, 0, true);

        row = writeAnswer(contentStream, row, questionWidth,
                "Duration (Months)",
                lookupEntity2String(mssRequestData.getDurationMonths()));

        // Dynamic columns grid
        if (mssRequestData.getMssArray() != null && !mssRequestData.getMssArray().isEmpty()) {
            String clariionAx4DrivesTxt = "CLARiiON AX4 Drives ";
            String spaces = appendSpacesToSameLenth(clariionAx4DrivesTxt, " ", FONT_TEXT, DEFAULT_FONT_SIZE);
            List<String[]> content = createDynColTableContent(new String[] {
                    "Arrays",
                    "Location",
                    "Service",
                    "Platform",
                    appendSpacesToSameLenth(clariionAx4DrivesTxt, "FC / ATA Drives",
                            FONT_TEXT, DEFAULT_FONT_SIZE) + "73GB",
                    spaces + "146GB",
                    spaces + "300GB",
                    spaces + "400GB",
                    spaces + "450GB",
                    spaces + "500GB",
                    spaces + "600GB",
                    spaces + "750GB",
                    spaces + "1TB",
                    spaces + "2TB",
                    spaces + "3TB (4G)",
                    spaces + "Other",
                    appendSpacesToSameLenth(clariionAx4DrivesTxt, "Flash Drives",
                            FONT_TEXT, DEFAULT_FONT_SIZE) + "73GB Flash",
                    spaces + "100GB Flash",
                    spaces + "146GB Flash",
                    spaces + "200GB Flash",
                    spaces + "400GB Flash",
                    spaces + "Other",
                    appendSpacesToSameLenth(clariionAx4DrivesTxt, "VNX SAS Drives",
                            FONT_TEXT, DEFAULT_FONT_SIZE) + "300GB SAS",
                    spaces + "2.5\" 300GB SAS",
                    spaces + "600GB SAS",
                    spaces + "2.5\" 600GB SAS",
                    spaces + "2.5\" 900GB SAS",
                    spaces + "3.5\" 900GB SAS",
                    spaces + "1TB SAS",
                    spaces + "2TB SAS",
                    spaces + "3TB SAS",
                    spaces + "100GB SAS Flash",
                    spaces + "200GB SAS Flash",
                    spaces + "Other",
                    clariionAx4DrivesTxt + "500GB SATA-II",
                    spaces + "750GB SATA-II",
                    spaces + "1000GB SATA-II",
                    spaces + "146GB 15K SAS",
                    spaces + "300GB 15K SAS",
                    spaces + "400GB 15K SAS",
                    spaces + "450GB 10K SAS",
                    spaces + "600GB 10K SAS",
                    spaces + "Other",
                    appendSpacesToSameLenth(clariionAx4DrivesTxt, "Centera Nodes",
                            FONT_TEXT, DEFAULT_FONT_SIZE) + "Gen-1 640GB nodes",
                    spaces + "Gen-2 1TB nodes",
                    spaces + "Gen-3 1.28TB nodes",
                    spaces + "Gen-4 750GB nodes",
                    spaces + "Gen-4 1.28TB nodes",
                    spaces + "Gen-4 2TB nodes",
                    spaces + "Gen-4LP 1TB drive nodes",
                    spaces + "Gen-4LP 2TB drive nodes",
                    spaces + "Other",
                    appendSpacesToSameLenth(clariionAx4DrivesTxt, "Avamar Nodes",
                            FONT_TEXT, DEFAULT_FONT_SIZE) + "1TB Storage Nodes",
                    spaces + "2TB Storage Nodes",
                    spaces + "3.3TB Storage Nodes",
                    spaces + "Utility Nodes (Gen 1)",
                    spaces + "Utility Nodes (Gen 2/Gen 3)",
                    spaces + "Utility Nodes (Gen 4)",
                    spaces + "Accelerator Nodes (Gen 1)",
                    spaces + "Small Accelerator Nodes (Gen 2)",
                    spaces + "Large Accelerator Nodes (Gen 2)",
                    spaces + "Accelerator Nodes for Gen 3&4 Hardware",
                    spaces + "1.3TB storage Nodes for Gen4",
                    spaces + "2.6TB storage Nodes for Gen4",
                    spaces + "3.9TB storage Nodes for Gen4",
                    spaces + "7.8TB storage Nodes for Gen4",
                    spaces + "Other",
                    appendSpacesToSameLenth(clariionAx4DrivesTxt, "ATMOS",
                            FONT_TEXT, DEFAULT_FONT_SIZE) + "2.5 IN 250GB(SATA) disk drives",
                    spaces + "1TB(SATA) disk drives",
                    spaces + "2TB(SATA) disk drives",
                    spaces + "3TB(SATA) disk drives",
                    spaces + "Other",
                    appendSpacesToSameLenth(clariionAx4DrivesTxt, "Data Domain",
                            FONT_TEXT, DEFAULT_FONT_SIZE) + "Model Type?",
                    spaces + "Serial #?",
                    spaces + "Number of drives for retention?",
                    appendSpacesToSameLenth(clariionAx4DrivesTxt, "GREENPLUM",
                            FONT_TEXT, DEFAULT_FONT_SIZE) + "2.5 600GB(SAS) 10K disk drives",
                    spaces + "3.5 in 600GB(SAS) 15K disk drives",
                    spaces + "3.5 in 2TB(SATA) disk drives"
            }, mssRequestData.getMssArray().size());

            for (int i = 1; i <= mssRequestData.getMssArray().size(); i++) {
                MSSArray array = mssRequestData.getMssArray().get(i - 1);
                int rowNum = 0;
                content.get(rowNum++)[i] = "Array " + i;
                content.get(rowNum++)[i] = trimToEmpty(array.getLocation());
                content.get(rowNum++)[i] = lookupEntity2String(array.getService());
                content.get(rowNum++)[i] = lookupEntity2String(array.getPlatform());
                MSSFcAtaDrives fcAtaDrives = array.getFcAtaDrives();
                content.get(rowNum++)[i] = trimToEmpty(fcAtaDrives == null ? "" : fcAtaDrives.getFcAta73GB());
                content.get(rowNum++)[i] = trimToEmpty(fcAtaDrives == null ? "" : fcAtaDrives.getFcAta146GB());
                content.get(rowNum++)[i] = trimToEmpty(fcAtaDrives == null ? "" : fcAtaDrives.getFcAta300GB());
                content.get(rowNum++)[i] = trimToEmpty(fcAtaDrives == null ? "" : fcAtaDrives.getFcAta400GB());
                content.get(rowNum++)[i] = trimToEmpty(fcAtaDrives == null ? "" : fcAtaDrives.getFcAta450GB());
                content.get(rowNum++)[i] = trimToEmpty(fcAtaDrives == null ? "" : fcAtaDrives.getFcAta500GB());
                content.get(rowNum++)[i] = trimToEmpty(fcAtaDrives == null ? "" : fcAtaDrives.getFcAta600GB());
                content.get(rowNum++)[i] = trimToEmpty(fcAtaDrives == null ? "" : fcAtaDrives.getFcAta750GB());
                content.get(rowNum++)[i] = trimToEmpty(fcAtaDrives == null ? "" : fcAtaDrives.getFcAta1TB());
                content.get(rowNum++)[i] = trimToEmpty(fcAtaDrives == null ? "" : fcAtaDrives.getFcAta2TB());
                content.get(rowNum++)[i] = trimToEmpty(fcAtaDrives == null ? "" : fcAtaDrives.getFcAta3TB4G());
                content.get(rowNum++)[i] = trimToEmpty(fcAtaDrives == null ? "" : fcAtaDrives.getFcAtaOther());
                MSSFlashDrives flashDrives = array.getFlashDrives();
                content.get(rowNum++)[i] = trimToEmpty(flashDrives == null ? "" : flashDrives.getFlash73GB());
                content.get(rowNum++)[i] = trimToEmpty(flashDrives == null ? "" : flashDrives.getFlash100GB());
                content.get(rowNum++)[i] = trimToEmpty(flashDrives == null ? "" : flashDrives.getFlash146GB());
                content.get(rowNum++)[i] = trimToEmpty(flashDrives == null ? "" : flashDrives.getFlash200GB());
                content.get(rowNum++)[i] = trimToEmpty(flashDrives == null ? "" : flashDrives.getFlash400GB());
                content.get(rowNum++)[i] = trimToEmpty(flashDrives == null ? "" : flashDrives.getFlashOther());
                MSSVnxSasDrives vnaSasDrives = array.getVnxSasDrives();
                content.get(rowNum++)[i] = trimToEmpty(vnaSasDrives == null ? "" : vnaSasDrives.getVnxSas300GB());
                content.get(rowNum++)[i] = trimToEmpty(vnaSasDrives == null ? "" : vnaSasDrives.getVnxSas25Inch300GB());
                content.get(rowNum++)[i] = trimToEmpty(vnaSasDrives == null ? "" : vnaSasDrives.getVnxSas600GB());
                content.get(rowNum++)[i] = trimToEmpty(vnaSasDrives == null ? "" : vnaSasDrives.getVnxSas25Inch600GB());
                content.get(rowNum++)[i] = trimToEmpty(vnaSasDrives == null ? "" : vnaSasDrives.getVnxSas25Inch900GB());
                content.get(rowNum++)[i] = trimToEmpty(vnaSasDrives == null ? "" : vnaSasDrives.getVnxSas35Inch900GB());
                content.get(rowNum++)[i] = trimToEmpty(vnaSasDrives == null ? "" : vnaSasDrives.getVnxSas1TB());
                content.get(rowNum++)[i] = trimToEmpty(vnaSasDrives == null ? "" : vnaSasDrives.getVnxSas2TB());
                content.get(rowNum++)[i] = trimToEmpty(vnaSasDrives == null ? "" : vnaSasDrives.getVnxSas3TB());
                content.get(rowNum++)[i] = trimToEmpty(vnaSasDrives == null ? "" : vnaSasDrives.getVnxSas100GBFlash());
                content.get(rowNum++)[i] = trimToEmpty(vnaSasDrives == null ? "" : vnaSasDrives.getVnxSas200GBFlash());
                content.get(rowNum++)[i] = trimToEmpty(vnaSasDrives == null ? "" : vnaSasDrives.getVnxSasOther());
                MSSClariionAx4Drives ax4Drives = array.getClariionAx4Drives();
                content.get(rowNum++)[i] = trimToEmpty(ax4Drives == null ? "" : ax4Drives.getClariionAx4SataII500GB());
                content.get(rowNum++)[i] = trimToEmpty(ax4Drives == null ? "" : ax4Drives.getClariionAx4SataII750GB());
                content.get(rowNum++)[i] = trimToEmpty(ax4Drives == null ? "" : ax4Drives.getClariionAx4SataII1000GB());
                content.get(rowNum++)[i] = trimToEmpty(ax4Drives == null ? "" : ax4Drives.getClariionAx4Sas146GB15k());
                content.get(rowNum++)[i] = trimToEmpty(ax4Drives == null ? "" : ax4Drives.getClariionAx4Sas300GB15k());
                content.get(rowNum++)[i] = trimToEmpty(ax4Drives == null ? "" : ax4Drives.getClariionAx4Sas400GB15k());
                content.get(rowNum++)[i] = trimToEmpty(ax4Drives == null ? "" : ax4Drives.getClariionAx4Sas450GB10k());
                content.get(rowNum++)[i] = trimToEmpty(ax4Drives == null ? "" : ax4Drives.getClariionAx4Sas600GB10k());
                content.get(rowNum++)[i] = trimToEmpty(ax4Drives == null ? "" : ax4Drives.getClariionAx4Other());
                MSSCenteraNodes centeraNodes = array.getCenteraNodes();
                content.get(rowNum++)[i] = trimToEmpty(centeraNodes == null ? "" : centeraNodes.getGen1Nodes640GB());
                content.get(rowNum++)[i] = trimToEmpty(centeraNodes == null ? "" : centeraNodes.getGen2Nodes1TB());
                content.get(rowNum++)[i] = trimToEmpty(centeraNodes == null ? "" : centeraNodes.getGen3Nodes128TB());
                content.get(rowNum++)[i] = trimToEmpty(centeraNodes == null ? "" : centeraNodes.getGen4Nodes750GB());
                content.get(rowNum++)[i] = trimToEmpty(centeraNodes == null ? "" : centeraNodes.getGen4Nodes128TB());
                content.get(rowNum++)[i] = trimToEmpty(centeraNodes == null ? "" : centeraNodes.getGen4Nodes2TB());
                content.get(rowNum++)[i] = trimToEmpty(centeraNodes == null ? "" : centeraNodes.getGen4LPNodes1TB());
                content.get(rowNum++)[i] = trimToEmpty(centeraNodes == null ? "" : centeraNodes.getGen4LPNodes2TB());
                content.get(rowNum++)[i] = trimToEmpty(centeraNodes == null ? "" : centeraNodes.getOtherCenteraNodes());
                MSSAvamarNodes avaNodes = array.getAvamarNodes();
                content.get(rowNum++)[i] = trimToEmpty(avaNodes == null ? "" : avaNodes.getStorageNodes1TB());
                content.get(rowNum++)[i] = trimToEmpty(avaNodes == null ? "" : avaNodes.getStorageNodes2TB());
                content.get(rowNum++)[i] = trimToEmpty(avaNodes == null ? "" : avaNodes.getStorageNodes33TB());
                content.get(rowNum++)[i] = trimToEmpty(avaNodes == null ? "" : avaNodes.getUtilityNodesGen1());
                content.get(rowNum++)[i] = trimToEmpty(avaNodes == null ? "" : avaNodes.getUtilityNodesGen2Gen3());
                content.get(rowNum++)[i] = trimToEmpty(avaNodes == null ? "" : avaNodes.getUtilityNodesGen4());
                content.get(rowNum++)[i] = trimToEmpty(avaNodes == null ? "" : avaNodes.getAcceleratorNodesGen1());
                content.get(rowNum++)[i] = trimToEmpty(avaNodes == null ? "" : avaNodes.getSmallAcceleratorNodesGen2());
                content.get(rowNum++)[i] = trimToEmpty(avaNodes == null ? "" : avaNodes.getLargeAcceleratorNodesGen2());
                content.get(rowNum++)[i] = trimToEmpty(avaNodes == null ? "" : avaNodes.getAcceleratorNodesGen3Gen4());
                content.get(rowNum++)[i] = trimToEmpty(avaNodes == null ? "" : avaNodes.getStorageNodes13TBGen4());
                content.get(rowNum++)[i] = trimToEmpty(avaNodes == null ? "" : avaNodes.getStorageNodes26TBGen4());
                content.get(rowNum++)[i] = trimToEmpty(avaNodes == null ? "" : avaNodes.getStorageNodes39TBGen4());
                content.get(rowNum++)[i] = trimToEmpty(avaNodes == null ? "" : avaNodes.getStorageNodes78TBGen4());
                content.get(rowNum++)[i] = trimToEmpty(avaNodes == null ? "" : avaNodes.getOtherAvamarNodes());
                MSSAtmos atmos = array.getAtmos();
                content.get(rowNum++)[i] = trimToEmpty(atmos == null ? "" : atmos.getAtmos25Inch250GB());
                content.get(rowNum++)[i] = trimToEmpty(atmos == null ? "" : atmos.getAtmos1TB());
                content.get(rowNum++)[i] = trimToEmpty(atmos == null ? "" : atmos.getAtmos2TB());
                content.get(rowNum++)[i] = trimToEmpty(atmos == null ? "" : atmos.getAtmos3TB());
                content.get(rowNum++)[i] = trimToEmpty(atmos == null ? "" : atmos.getAtmosOther());
                MSSDataDomain dd = array.getDataDomain();
                content.get(rowNum++)[i] = trimToEmpty(dd == null ? "" : dd.getModelType());
                content.get(rowNum++)[i] = trimToEmpty(dd == null ? "" : dd.getSerialNumber());
                content.get(rowNum++)[i] = dd == null ? "" : int2String(dd.getNumRetentionDrives());
                MSSGreenplum greenplum = array.getGreenplum();
                content.get(rowNum++)[i] = trimToEmpty(greenplum == null ? "" : greenplum.getGreenplum25Inch600GB10K());
                content.get(rowNum++)[i] = trimToEmpty(greenplum == null ? "" : greenplum.getGreenplum35Inch2TB());
                content.get(rowNum++)[i] = trimToEmpty(greenplum == null ? "" : greenplum.getGreenplum35Inch2TB());
            }

            row += drawDynColTable(page, contentStream, getYPos(++row), 30, 237, 95,
                    content.toArray(new String[content.size()][]));
            row++;
        }
        return row;
    }

    /**
     * Append spaces to given start string to same length of given text.
     *
     * @param text
     *            to determine the length
     * @param start
     *            the start string
     * @param font
     *            PDF font
     * @param fontSize
     *            Font size
     * @return String with spaces appended to same length of given text
     * @throws IOException
     *             if any IO error occurs
     */
    private static String appendSpacesToSameLenth(String text, String start, PDFont font, int fontSize)
        throws IOException {

        final float size = font.getStringWidth(text) / 1000 * fontSize;
        StringBuilder sb = new StringBuilder(start);
        float spacesSize = -1f;
        while (spacesSize < size) {
            sb.append(" ");
            spacesSize = font.getStringWidth(sb.toString()) / 1000 * fontSize;
        }
        return sb.toString();
    }

    /**
     * Get CTA services scope.
     *
     * @param ctaRequestData
     *            the ctaRequestData
     * @return CTA services scope.
     * @since SRT Phase 3-1 - CTA Rainfinity and MSS Tabs Assembly
     */
    private static List<String> getCTARequestDataServicesScope(CTARequestData ctaRequestData) {

        List<String> options = new ArrayList<String>();
        CTAServicesScope scope = ctaRequestData.getServicesScope();
        if (scope != null) {
            if (scope.isCtaDesignAndImplementation()) {
                options.add("Design and Implementation of CTA");
            }
            if (scope.isCtaImplementation()) {
                options.add("Implementation of CTA");
            }
            if (scope.isCtaConversion()) {
                options.add("Conversion for CTA");
            }
            if (scope.isRainfinityDesignAndImplementation()) {
                options.add("Rainfinity: Design & Imp for File Virtualization Appliance");
            }
        }
        return options;
    }

    /**
     * Write CTA request data.
     *
     * @param contentStream
     *            the stream
     * @param ctaRequestData
     *            the ctaRequestData
     * @param row
     *            the start row number
     * @param page
     *            the PDF page
     * @return the new row number
     * @throws IOException
     *             if any IO error occurs
     * @since SRT Phase 3-1 - CTA Rainfinity and MSS Tabs Assembly
     */
    private int writeCTARequestData(PDPageContentStream contentStream, CTARequestData ctaRequestData, int row,
            PDPage page) throws IOException {
        float questionWidth = 200f;
        row = writeFont(contentStream, "Services & Activities - CTA Rainfinity", ++row, 0, true);

        // General information
        row++;

        row = writeFont(contentStream, "General Information", ++row, 0, true);

        row = writeAnswer(contentStream, row, questionWidth, "# of sites involved?",
                lookupEntity2String(ctaRequestData.getSitesInvolved()));

        row = writeAnswer(contentStream, row, questionWidth, "# days of knowledge transfer",
                decimal2String(ctaRequestData.getDaysOfknowledgeTransfer(), 2));

        row = writeAnswer(contentStream, row, questionWidth,
                "General Comment", trimToEmpty(ctaRequestData.getGeneralComment()));

        int columnNum = 3;
        float columnWidth = 150f;

        // Services scope
        row++;
        row = writeFont(contentStream, "Services to be Scoped in this BOE", ++row, 0, true);
        List<String> options = getCTARequestDataServicesScope(ctaRequestData);
        row = writeOptions(contentStream, options, ++row, 0, columnNum, columnWidth);

        // CTA implementation
        row = writeCTARequestDataImplementation(contentStream, ctaRequestData, row, page);

        // CTA conversion
        row = writeCTARequestDataConversion(contentStream, ctaRequestData, row, page);

        // CTA Rainfinity
        row = writeCTARequestDataRainfinity(contentStream, ctaRequestData, row, page);

        return row;
    }

    /**
     * Get CTA Nas destination.
     *
     * @param nasDestination
     *            the nas destination object
     * @return the destination list.
     */
    private String getCTANasDestinations(NASDestination nasDestination) {
        StringBuilder sb = new StringBuilder();
        if (nasDestination != null) {
            if (nasDestination.isCelerra()) {
                sb.append("Celerra, ");
            }
            if (nasDestination.isVnx()) {
                sb.append("VNX, ");
            }
            if (nasDestination.isVnxe()) {
                sb.append("VNXe, ");
            }
            if (nasDestination.isNetworkAppliance()) {
                sb.append("Network Appliance, ");
            }
            if (nasDestination.isCentera()) {
                sb.append("Centera, ");
            }
            if (nasDestination.isWindows()) {
                sb.append("Windows, ");
            }
            if (nasDestination.isAtmos()) {
                sb.append("Atmos, ");
            }
            if (nasDestination.isDataDomain()) {
                sb.append("Data Domain, ");
            }
            if (sb.length() > 0) {
                sb.deleteCharAt(sb.length() - 1);
                sb.deleteCharAt(sb.length() - 1);
            }
        }
        return sb.toString();
    }

    /**
     * Write CTA rainfinity info.
     *
     * @param contentStream
     *            the stream
     * @param ctaRequestData
     *            the ctaRequestData
     * @param row
     *            the start row number
     * @param page
     *            the PDF page
     * @return the new row number
     * @throws IOException
     *             if any IO error occurs
     * @since SRT Phase 3-1 - CTA Rainfinity and MSS Tabs Update Assembly
     */
    private int writeCTARequestDataRainfinity(PDPageContentStream contentStream, CTARequestData ctaRequestData,
            int row, PDPage page) throws IOException {

        CTARaininfinity rainfinity = ctaRequestData.getRaininfinity();

        if (rainfinity != null) {
            float questionWidth = 400f;
            row++;
            row = writeFont(contentStream,
                    "RAININFINITY DESIGN & IMPLEMENTATION FOR FILE VIRTUALZATION APPLIANCE (FVA)", ++row, 0, true);

            row = writeAnswer(contentStream, row, questionWidth,
                    "Include File Virtualization Appliance Clustered Deployment",
                    bool2String(rainfinity.isIncludeClusteredDeployment()));
            row = writeAnswer(contentStream, row, questionWidth,
                    "Will hardware conversion from a Rainfinity Global File Virtualization (GFV) appliance to a File"
                    + " Virtualization Appliance (FVA) will be implemented",
                    bool2String(rainfinity.isHardwareConversion()));
            row = writeAnswer(contentStream, row, questionWidth,
                    "Will Rainfinity File Virtualization Appliance (FVA) multi-instances spanning tree protocol (MSTP)"
                    + " will be implemented",
                    bool2String(rainfinity.isMstp()));
            row = writeAnswer(contentStream, row, questionWidth,
                    "Will Rainfinity FVA cross-functional migration will be implemented",
                    bool2String(rainfinity.isCrossFunctionalMigration()));

            row = writeAnswer(contentStream, row, questionWidth,
                    "# of billable hours for Solutions Architect to complete Solutions Qualifiers",
                    decimal2String(rainfinity.getBillableHoursNum(), 2));
            row = writeAnswer(contentStream, row, questionWidth,
                    "# of File Virtualization Appliances to be deployed",
                    int2String(rainfinity.getAppliancesDeployedNum()));
            row = writeAnswer(contentStream, row, questionWidth,
                    "# of file servers in the File Virtualization Appliance environment",
                    int2String(rainfinity.getFileServersNum()));
            row = writeAnswer(contentStream, row, questionWidth,
                    "# of file systems in the File Virtualization Appliance environment",
                    int2String(rainfinity.getFileSystemsNum()));

            row = writeAnswer(contentStream, row, questionWidth,
                    "Include File Virtualization Appliance SID Translator Utility",
                    bool2String(rainfinity.getIncludeSID()));
            row = writeAnswer(contentStream, row, questionWidth,
                    "# of local user and group objects",
                    int2String(rainfinity.getLocalUserObjectsNum()));
            row = writeAnswer(contentStream, row, questionWidth,
                    "Include File Virtualization Appliance Windows Proxy Service",
                    bool2String(rainfinity.getIncludeWindowsProxy()));
            row = writeAnswer(contentStream, row, questionWidth,
                    "Include File Virtualization Appliance remote migration implementation",
                    bool2String(rainfinity.getIncludeRemoteMigration()));

            row = writeAnswer(contentStream, row, questionWidth,
                    "# of Rainfinity Global File Virtualization appliances",
                    int2String(rainfinity.getRainfinityAppliancesNum()));
            row = writeAnswer(contentStream, row, questionWidth,
                    "# of Rainfinity FVA VLANs for the MSTP configuration",
                    int2String(rainfinity.getRainfinityVLANsNum()));
            row = writeAnswer(contentStream, row, questionWidth,
                    "# of Domains for File Virtualization Appliance (FVA) cross-functional migration implementation",
                    int2String(rainfinity.getDomainsNum()));
            row = writeAnswer(contentStream, row, questionWidth,
                    "Is switch configuration required for the File Virtualization Appliance implementation?",
                    bool2String(rainfinity.getSwitchConfigRequired()));
            row = writeAnswer(contentStream, row, questionWidth,
                    "Include File Virtualization Appliance local migration implementation",
                    bool2String(rainfinity.getIncludeLocalMigration()));
            row = writeAnswer(contentStream, row, questionWidth,
                    "Amount of data in GB to be migrated by the Rainfinity File Virtualization Appliance",
                    int2String(rainfinity.getMigrateDataAmount()));
        }
        return row;
    }

    /**
     * Write CTA conversion info.
     *
     * @param contentStream
     *            the stream
     * @param ctaRequestData
     *            the ctaRequestData
     * @param row
     *            the start row number
     * @param page
     *            the PDF page
     * @return the new row number
     * @throws IOException
     *             if any IO error occurs
     * @since SRT Phase 3-1 - CTA Rainfinity and MSS Tabs Update Assembly
     */
    private int writeCTARequestDataConversion(PDPageContentStream contentStream, CTARequestData ctaRequestData,
            int row, PDPage page) throws IOException {
        CTAConversion conversion = ctaRequestData.getConversion();
        if (conversion != null) {
            float questionWidth = 400f;
            row++;
            row = writeFont(contentStream, "CONVERSION", ++row, 0, true);

            row = writeAnswer(contentStream, row, questionWidth,
                    "Select Conversation Type",
                    conversion.getConversationType() == null ? "" : conversion.getConversationType().name());

            row = writeAnswer(contentStream, row, questionWidth,
                    "# of Cloud Tiering Appliance or Cloud Tiering Appliance/VEs for conversion",
                    int2String(conversion.getCloudTieringApplianceNum()));
            row = writeAnswer(contentStream, row, questionWidth,
                    "# of file servers for the conversion",
                    int2String(conversion.getFileServersNum()));
            row = writeAnswer(contentStream, row, questionWidth,
                    "# of sites for Rainfinity File Management Appliance conversion",
                    int2String(conversion.getManagementSitesNum()));
            row = writeAnswer(contentStream, row, questionWidth,
                    "# of Files on all the File Systems to be Converted (in millions)",
                    int2String(conversion.getFilesConvertedNum()));
            row = writeAnswer(contentStream, row, questionWidth,
                    "# of Centera File Archivers in conversion environment",
                    int2String(conversion.getFileArchiversNum()));
            row = writeAnswer(contentStream, row, questionWidth,
                    "# of CFA database records to be converted to Cloud Tiering Appliance (in millions)",
                    int2String(conversion.getCfaRecordsNum()));

            String monMethod = "";
            if (conversion.getMonitoringMethod() != null) {
                switch (conversion.getMonitoringMethod()) {
                case ON_SITE:
                    monMethod = "On-Site";
                    break;
                case REMOTE:
                    monMethod = "Remote";
                    break;
                default:
                    monMethod = "";
                }
            }
            row = writeAnswer(contentStream, row, questionWidth,
                    "Select the Cloud Tiering Appliance Stub Conversion Monitoring Method",
                    monMethod);
        }
        return row;
    }

    /**
     * Write CTA implementation info.
     *
     * @param contentStream
     *            the stream
     * @param ctaRequestData
     *            the ctaRequestData
     * @param row
     *            the start row number
     * @param page
     *            the PDF page
     * @return the new row number
     * @throws IOException
     *             if any IO error occurs
     * @since SRT Phase 3-1 - CTA Rainfinity and MSS Tabs Assembly
     */
    private int writeCTARequestDataImplementation(PDPageContentStream contentStream, CTARequestData ctaRequestData,
            int row, PDPage page) throws IOException {
        CTAImplementation impl = ctaRequestData.getImplementation();

        if (impl != null && ctaRequestData.getServicesScope() != null
                && (ctaRequestData.getServicesScope().isCtaDesignAndImplementation()
                        || ctaRequestData.getServicesScope().isCtaImplementation())) {
            float questionWidth = 200f;
            row++;
            row = writeFont(contentStream, "DESIGN AND IMPLEMENTATION", ++row, 0, true);

            // Dynamic columns grid
            if (impl.getArray() != null && !impl.getArray().isEmpty()) {
                boolean conversionChecked = ctaRequestData.getServicesScope() != null
                        && ctaRequestData.getServicesScope().isCtaConversion();
                String[] fields = conversionChecked ? new String[] {
                    "Cloud Tiering Appliance",
                    "Location (City, State)",
                    "Appliance Type",
                    "Clustered Appliance?",
                    "# of clusters",
                    "Select the source file server type",
                    "# of source exports/shares",
                    "Muti-tier archiving will be implemented?",
                    "# of Multi-tier sites?",
                    "Will security hardening will be implemented?",
                    "Select the type(s) of NAS destination for the Cloud Tiering Appliance implementation",
                    "# of archive policies?",
                    "# Number of migration policies?",
                    "Use Cloud Tiering Appliance for capacity management? - FVA only"
                } : new String[] {
                    "Cloud Tiering Appliance",
                    "Location (City, State)",
                    "Appliance Type",
                    "Clustered Appliance?",
                    "# of clusters",
                    "Select the source file server type",
                    "# of source exports/shares",
                    "Muti-tier archiving will be implemented?",
                    "# of Multi-tier sites?",
                    "Will security hardening will be implemented?",
                    "Select the type(s) of NAS destination for the Cloud Tiering Appliance implementation",
                    "Use Cloud Tiering Appliance for capacity management? - FVA only"
                };
                List<String[]> content = createDynColTableContent(fields, impl.getArray().size());

                for (int i = 1; i <= impl.getArray().size(); i++) {
                    CTAImplementationArray array = impl.getArray().get(i - 1);
                    int rowNum = 0;
                    content.get(rowNum++)[i] = "Appliance " + i;
                    content.get(rowNum++)[i] = trimToEmpty(array.getLocation());
                    content.get(rowNum++)[i] = lookupEntity2String(array.getApplianceType());
                    content.get(rowNum++)[i] = bool2String(array.getClusteredAppliance());
                    content.get(rowNum++)[i] = int2String(array.getClustersNum());
                    content.get(rowNum++)[i] = lookupEntity2String(array.getSourceFileServerType());
                    content.get(rowNum++)[i] = int2String(array.getSourceExportsSharesNum());
                    content.get(rowNum++)[i] = bool2String(array.getMultiTierArchiving());
                    content.get(rowNum++)[i] = int2String(array.getMultiTierSitesNum());
                    content.get(rowNum++)[i] = bool2String(array.getSecurityHardening());
                    content.get(rowNum++)[i] = getCTANasDestinations(array.getNasDestination());
                    if (conversionChecked) {
                        content.get(rowNum++)[i] = int2String(array.getArchivePoliciesNum());
                        content.get(rowNum++)[i] = int2String(array.getMigrationPoliciesNum());
                    }
                    content.get(rowNum++)[i] = bool2String(array.getCapacityManagement());
                }

                row += drawDynColTable(page, contentStream, getYPos(++row), 30, 190, 80,
                        content.toArray(new String[content.size()][]));
                row++;
            }

            row = writeAnswer(contentStream, row, questionWidth,
                    "Provide a brief explanation of customer expectations",
                    trimToEmpty(impl.getCustomerExpectations()));

        }
        return row;
    }

    /**
     * Get BcRequestData Options part one.
     *
     * @param bcRequestData
     *            the bcRequestData
     * @return the options list.
     */
    private List<String> getBcRequestDataOptions1(BcRequestData bcRequestData) {
        List<String> options = new ArrayList<String>();
        BCServicesScope scope = bcRequestData.getServicesScope();
        if (scope != null) {
            if (scope.isSrdf()) {
                options.add("SRDF");
            }
            if (scope.isTimeFinder()) {
                options.add("TimeFinder");
            }
            if (scope.isMirrowView()) {
                options.add("MirrorView");
            }
            if (scope.isReplicationServices()) {
                options.add("Replication Manager");
            }
        }
        return options;
    }

    /**
     * Get BcRequestData BCV, Snap, and/or Clones Options.
     *
     * @param bcRequestData
     *            the bcRequestData
     * @return the options list.
     */
    private List<String> getTimeFinderBCVOptions(BcRequestData bcRequestData) {
        List<String> options = new ArrayList<String>();
        TimeFinderInformation timeFinderInformation = bcRequestData.getTimeFinderInformation();
        if (timeFinderInformation != null) {
            if (timeFinderInformation.getBcvToImplement()) {
                options.add("BCV");
            }
            if (timeFinderInformation.getCloneToImplement()) {
                options.add("Clone");
            }
            if (timeFinderInformation.getSnapToImplement()) {
                options.add("Snaps");
            }
            if (timeFinderInformation.getVpSnapToImplement()) {
                options.add("VP Snap");
            }
        }
        return options;
    }

    /**
     * Get BcRequestData MirrorView Functionality Options.
     *
     * @param bcRequestData
     *            the bcRequestData
     * @return the options list.
     */
    private List<String> getMirrorViewFunctionalityOptions(BcRequestData bcRequestData) {
        List<String> options = new ArrayList<String>();
        MirrorViewInformation mirrorViewInformation = bcRequestData.getMirrorViewInformation();
        if (mirrorViewInformation != null) {
            if (mirrorViewInformation.isMirrorViewSFunctionalityRequired()) {
                options.add("MirrorView/S");
            }
            if (mirrorViewInformation.isMirrorViewAFunctionalityRequired()) {
                options.add("MirrorView/A");
            }
            if (mirrorViewInformation.isMirrorViewCEFunctionalityRequired()) {
                options.add("MirrorView/CE");
            }
        }
        return options;
    }

    /**
     * Get BcRequestData SnapView Functionality Options.
     *
     * @param bcRequestData
     *            the bcRequestData
     * @return the options list.
     */
    private List<String> getSnapViewFunctionalityOptions(BcRequestData bcRequestData) {
        List<String> options = new ArrayList<String>();
        SnapViewInformation snapViewInformation = bcRequestData.getSnapViewInformation();
        if (snapViewInformation != null) {
            if (snapViewInformation.isSnapViewFunctionalityRequired()) {
                options.add("Snapview");
            }
            if (snapViewInformation.isSnapShotViewFunctionalityRequired()) {
                options.add("VNX SnapShot");
            }
        }
        return options;
    }

    /**
     * Get BcRequestData Replication Manager Software Options.
     *
     * @param bcRequestData
     *            the bcRequestData
     * @return the options list.
     */
    private List<String> getReplManagerSoftwareOptions(BcRequestData bcRequestData) {
        List<String> options = new ArrayList<String>();
        ReplicationManagerInformation replicationManagerInformation = bcRequestData
                .getReplicationManagerInformation();
        if (replicationManagerInformation != null) {
            if (replicationManagerInformation.isTimeFinderManaged()) {
                options.add("TimeFinder");
            }
            if (replicationManagerInformation.isSanCopyManaged()) {
                options.add("SAN Copy");
            }
            if (replicationManagerInformation.isOpenReplicatorManaged()) {
                options.add("Open Replicator");
            }
            if (replicationManagerInformation.isCelerraManaged()) {
                options.add("IP Replicator");
            }
            if (replicationManagerInformation.isSnapViewManaged()) {
                options.add("SnapView");
            }
            if (replicationManagerInformation.isSnapSureManaged()) {
                options.add("SnapSure");
            }
            if (replicationManagerInformation.isRecoverPointManaged()) {
                options.add("RecoverPoint");
            }
        }
        return options;
    }

    /**
     * Get BcRequestData SRDF Functionality Options.
     *
     * @param bcRequestData
     *            the bcRequestData
     * @return the options list.
     */
    private List<String> getSRDFFunctionalityOptions(BcRequestData bcRequestData) {
        List<String> options = new ArrayList<String>();
        SrdfInformation srdfInformation = bcRequestData.getSrdfInformation();
        if (srdfInformation != null) {
            if (srdfInformation.isSrdfSFunctionalityRequired()) {
                options.add("SRDF/S");
            }
            if (srdfInformation.isCascadingSrdfFunctionalityRequired()) {
                options.add("Cascading SRDF (R21)");
            }
            if (srdfInformation.isSrdfAFunctionalityRequired()) {
                // options.add("SRDF/A");
            }
            if (srdfInformation.isSrdfStarFunctionalityRequired()) {
                options.add("SRDF/STAR");
            }
            if (srdfInformation.isConcurrentSrdfFunctionalityRequired()) {
                options.add("Concurrent SRDF");
            }
            if (srdfInformation.isSrdfCe()) {
                options.add("SRDF/CE");
            }
        }
        return options;
    }

    /**
     * Write the question to stream.
     *
     * @param contentStream
     *            the contest stream
     * @param question
     *            the question text
     * @param row
     *            the row
     * @param x
     *            the x position
     * @param isHeader
     *            the flag whether the message is header
     * @param maxQuestionWidth
     *            the max width of question
     * @return the new row number
     * @throws IOException
     *             if any IO error occurs
     */
    private int writeQuestion(PDPageContentStream contentStream, String question, int row, float x, boolean isHeader,
            float maxQuestionWidth) throws IOException {
        question = question == null ? "" : question;

        float messageWidth = 0;

        contentStream.beginText();

        PDFont font = isHeader ? FONT_TEXT_BOLD : FONT_TEXT;
        int fontSize = isHeader ? DEFAULT_FONT_SIZE + 1 : DEFAULT_FONT_SIZE;
        contentStream.setFont(font, fontSize);
        messageWidth = font.getStringWidth(question) / 1000 * fontSize;

        float startX = DEFAULT_PAGE_PADDING + x;

        if (messageWidth > maxQuestionWidth) {
            contentStream.appendRawCommands(CELL_HEIGHT + " TL\n");
            contentStream.moveTextPositionByAmount(startX, getYPos(row));

            // The question text is surely well formed text (which is split by space)
            List<String> lines = breakToLinesBySpace(question, maxQuestionWidth, font, fontSize);
            for (Iterator<String> i = lines.iterator(); i.hasNext();) {
                contentStream.drawString(i.next().trim());
                if (i.hasNext()) {
                    row++;
                    contentStream.appendRawCommands("T*\n");
                }
            }
        } else {
            contentStream.moveTextPositionByAmount(startX, getYPos(row));
            contentStream.drawString(question);
        }

        contentStream.endText();

        return row;
    }

    /**
     * Write question and answer with indent.
     *
     * @param contentStream
     *            the stream
     * @param row
     *            the start row number
     * @param questionWidth
     *            the question width
     * @param questionIndent
     *            the indent size of question
     * @param question
     *            the question text
     * @param answer
     *            the answer text
     * @return the new row number
     * @throws IOException
     *             if any IO error occurs
     * @since SRT Phase 3-1 - Implement VMWare Tab Assembly
     */
    private int writeAnswer(PDPageContentStream contentStream, int row, float questionWidth, float questionIndent,
            String question, String answer) throws IOException {

        int rowNum = ++row;
        row = Math.max(row, writeQuestion(contentStream, question, rowNum, questionIndent, false,
                questionWidth - questionIndent));
        row = Math.max(row, writeFont(contentStream, answer, rowNum, questionWidth, false));
        return row;
    }

    /**
     * Write question and answer.
     *
     * @param contentStream
     *            the stream
     * @param row
     *            the start row number
     * @param questionWidth
     *            the question width
     * @param question
     *            the question text
     * @param answer
     *            the answer text
     * @return the new row number
     * @throws IOException
     *             if any IO error occurs
     * @since SRT Phase 3-3 - BRS Tab Assembly
     */
    private int writeAnswer(PDPageContentStream contentStream, int row, float questionWidth, String question,
            String answer) throws IOException {

        int rowNum = ++row;
        row = Math.max(row, writeQuestion(contentStream, question, rowNum, 0, false, questionWidth));
        row = Math.max(row, writeFont(contentStream, answer, rowNum, questionWidth, false));
        return row;
    }

    /**
     * Write question and answers.
     *
     * @param contentStream
     *            the stream
     * @param row
     *            the start row number
     * @param questionWidth
     *            the question width
     * @param question
     *            the question text
     * @param answers
     *            the lines of answers
     * @return the new row number
     * @throws IOException
     *             if any IO error occurs
     * @since SRT Phase 3-5 - BRS Tabs Part 1 Assembly
     */
    private int writeAnswers(PDPageContentStream contentStream, int row, float questionWidth, String question,
            List<String> answers) throws IOException {

        int rowNum = ++row;
        row = Math.max(row, writeQuestion(contentStream, question, rowNum, 0, false, questionWidth));
        for (String answer : answers) {
            rowNum = writeFont(contentStream, answer, rowNum, questionWidth, false);
            rowNum++;
        }
        return Math.max(row, --rowNum);
    }

    /**
     * Write BcRequestData.
     *
     * @param contentStream
     *            the stream
     * @param bcRequestData
     *            the bcRequestData
     * @param unifiedRequestData
     *            the unifiedRequestData
     * @param infrastructureRequestData
     *            the infrastructureRequestData
     * @param row
     *            the start row number
     * @param page
     *            PDF page
     * @return the new row number
     * @throws IOException
     *             if any IO error occurs
     */
    private int writeBcRequestData(PDPageContentStream contentStream, BcRequestData bcRequestData,
            UnifiedRequestData unifiedRequestData, InfrastructureRequestData infrastructureRequestData, int row,
            PDPage page) throws IOException {
        row = writeFont(contentStream, "Services & Activities - Replication", ++row, 0, true);

        float answerStart = 200f;

        row = writeFont(contentStream, "General Information", ++row, 0, true);
        row = writeAnswer(contentStream, row, answerStart,
                "General Comment", trimToEmpty(bcRequestData.getGeneralComment()));
        answerStart = 250f;
        row++;
        row = writeFont(contentStream, "Replication Services", ++row, 0, true);
        int columnNum = 5;
        float columnWidth = 100f;
        row++;
        List<String> options = getBcRequestDataOptions1(bcRequestData);
        row = writeOptions(contentStream, options, row, 0, columnNum, columnWidth);

        columnNum = 2;

        BCServicesScope servicesScope = bcRequestData.getServicesScope();

        SrdfInformation srdfInformation = bcRequestData.getSrdfInformation();
        if (servicesScope.isSrdf() && srdfInformation != null) {
            row = writeFont(contentStream, "SRDF", ++row, 0, true);
            row = writeFont(contentStream, "# hours of knowledgetransfer", ++row, 0, false);
            row = writeFont(contentStream, srdfInformation.getKnowledgeTransferHours(), row, answerStart, false);
            row = writeFont(contentStream, "SRDF functionality required", ++row, 0, false);
            options = getSRDFFunctionalityOptions(bcRequestData);
            row = writeOptions(contentStream, options, row, answerStart, columnNum, columnWidth);
            row = writeFont(contentStream, "SRDF network link status", ++row, 0, false);
            NetworkLinkStatus networkLinkStatus = srdfInformation.getNetworkLinkStatus();
            if (networkLinkStatus != null) {
                row = writeFont(contentStream, networkLinkStatus.getName(), row, answerStart, false);
            }
            row = writeFont(contentStream, "Static or dynamic SRDF?", ++row, 0, false);
            SrdfStaticDynamicType srdfStaticDynamicType = srdfInformation.getSrdfStaticDynamicType();
            if (srdfStaticDynamicType != null) {
                row = writeFont(contentStream, srdfStaticDynamicType.getName(), row, answerStart, false);
            }
            row = writeFont(contentStream, "SRDF Source Host Information", ++row, 0, false);
            row++;
            String[][] contents = getBcSRDFSourceHostContents(srdfInformation);
            int tableRows = drawTable(page, contentStream, getYPos(row), 30, contents, true, null);
            row += tableRows;
            row = writeSRDFSourceArrayInformation(contentStream, srdfInformation, row);
            row = writeSRDFTargetArrayInformation(contentStream, srdfInformation, row);
            row = writeFont(contentStream, "SRDF Process Scripting Requirements", ++row, 0, false);
            ScriptingLevel scriptingLevel2 = srdfInformation.getBcPractiveScriptingLevel2();
            if (scriptingLevel2 != null) {
                row = writeFont(contentStream, scriptingLevel2.getName(), row, answerStart, false);
            }
            row = writeFont(contentStream, "Will EMC Map/Mask/Zone R2 devices?", ++row, 0, false);
            row = writeFont(contentStream, bool2String(srdfInformation.isEmcMapPointsOption()), row, answerStart,
                    false);
            row = writeFont(contentStream, "# of Symmetrix Directors Requiring FA-to-RA Conversion", ++row, 0, false);
            row = writeFont(contentStream,
                int2String(srdfInformation.getNumOfSymmetrixDirectorsRequiringFA2RAConversion()), row, answerStart,
                false);
            row = writeFont(contentStream, "# of Symmetrix RA Directors Requiring Compression", ++row, 0, false);
            row = writeFont(contentStream, int2String(srdfInformation.getNumOfSymmetrixRADirectorsRequiringCompression()),
                row, answerStart, false);
            row = writeFont(contentStream, "# of Symmetrix Gigabit Ethernet Directors", ++row, 0, false);
            row = writeFont(contentStream, int2String(srdfInformation.getNumOfSymmetrixGigabitEthernetDirectors()), row,
                answerStart, false);
        }

        TimeFinderInformation timeFinderInformation = bcRequestData.getTimeFinderInformation();
        if (servicesScope.isTimeFinder() && timeFinderInformation != null) {
            row = writeFont(contentStream, "TIMEFINDER", ++row, 0, true);
            row = writeFont(contentStream, "# hours of knowledgetransfer", ++row, 0, false);
            row = writeFont(contentStream, timeFinderInformation.getKnowledgeTransferHours(), row, answerStart,
                    false);
            row = writeFont(contentStream, "BCV, Snap, and/or Clones to be implemented", ++row, 0, false);
            options = getTimeFinderBCVOptions(bcRequestData);
            row = writeOptions(contentStream, options, row, answerStart, columnNum, columnWidth);
            row = writeFont(contentStream, "Do target devices need to be created via config change?", ++row, 0,
                    false);
            ConfigChangeType configChangeType = timeFinderInformation.getConfigChangeType();
            if (configChangeType != null) {
                row = writeFont(contentStream, configChangeType.getName(), row, answerStart, false);
            }
            row = writeFont(contentStream, "TB of storage to be replicated", ++row, 0, false);
            row = writeFont(contentStream, int2String(timeFinderInformation.getReplicatedStorageSize()), row,
                    answerStart, false);
            row = writeFont(contentStream, "TimeFinder process scripting requirements", ++row, 0, false);
            ScriptingLevel scriptingLevel = timeFinderInformation.getScriptingLevel();
            if (scriptingLevel != null) {
                row = writeFont(contentStream, scriptingLevel.getName(), row, answerStart, false);
            }

            row = writeFont(contentStream, "Snap save area sizing", ++row, 0, false);
            AreaSizingType areaSizingType = timeFinderInformation.getAreaSizingType();
            if (areaSizingType != null) {
                row = writeFont(contentStream, areaSizingType.getName(), row, answerStart, false);
            }
            row = writeFont(contentStream, "# of copies for Clone", ++row, 0, false);
            row = writeFont(contentStream, int2String(timeFinderInformation.getNrOfCloneCopies()), row,
                    answerStart, false);
            row = writeFont(contentStream, "# of copies for BCV", ++row, 0, false);
            row = writeFont(contentStream, int2String(timeFinderInformation.getNrOfBcvCopies()), row, answerStart,
                    false);
            row = writeFont(contentStream, "# of copies for Snaps", ++row, 0, false);
            row = writeFont(contentStream, int2String(timeFinderInformation.getNrOfSnapsCopies()), row,
                    answerStart, false);
            row = writeFont(contentStream, "# of copies for VP Snaps", ++row, 0, false);
            row = writeFont(contentStream, int2String(timeFinderInformation.getNrOfVPSnapsCopies()), row,
                    answerStart, false);
            row = writeFont(contentStream, "How many hosts need solutions enabler installed?", ++row, 0, false);
            row = writeFont(contentStream, int2String(timeFinderInformation.getNrOfSolutionEnablerHosts()), row,
                    answerStart, false);
            row = writeFont(contentStream, "# of clone pairs?", ++row, 0, false);
            row = writeFont(contentStream, int2String(timeFinderInformation.getNrOfClonePairs()), row,
                    answerStart, false);
            row = writeFont(contentStream, "TimeFinder Host Information", ++row, 0, false);
            row++;
            String[][] contents = getBcTimefinderHostContents(timeFinderInformation);
            int tableRows = drawTable(page, contentStream, getYPos(row), 30, contents, true, null);
            row += tableRows;
        }

        MirrorViewInformation mirrorViewInformation = bcRequestData.getMirrorViewInformation();
        if (servicesScope.isMirrowView() && mirrorViewInformation != null) {
            row = writeFont(contentStream, "MIRRORVIEW", ++row, 0, true);
            row = writeFont(contentStream, "# hours of knowledgetransfer", ++row, 0, false);
            row = writeFont(contentStream, mirrorViewInformation.getKnowledgeTransferHours(), row, answerStart,
                    false);
            row = writeFont(contentStream, "MirrorView functionality required", ++row, 0, false);
            options = getMirrorViewFunctionalityOptions(bcRequestData);
            row = writeOptions(contentStream, options, row, answerStart, columnNum, columnWidth);
            row = writeFont(contentStream, "MirrorView network link status", ++row, 0, false);
            NetworkLinkStatus networkLinkStatus = mirrorViewInformation.getNetworkLinkStatus();
            if (networkLinkStatus != null) {
                row = writeFont(contentStream, networkLinkStatus.getName(), row, answerStart, false);
            }
            row = writeFont(contentStream, "MirrorView Source Host Information", ++row, 0, false);
            row++;
            String[][] contents = getBcMirrorViewSourceHostContents(mirrorViewInformation);
            int tableRows = drawTable(page, contentStream, getYPos(row), 30, contents, true, null);
            row += tableRows;

            row = writeMirrorViewSourceArrayInformation(contentStream, mirrorViewInformation, row);
            row = writeMirrorViewTargetArrayInformation(contentStream, mirrorViewInformation, row);
            row = writeFont(contentStream, "MirrorView process scripting requirements", ++row, 0, false);
            ScriptingLevel scriptingLevel2 = mirrorViewInformation.getMirrowViewScriptingLevel();
            if (scriptingLevel2 != null) {
                row = writeFont(contentStream, scriptingLevel2.getName(), row, answerStart, false);
            }
            row = writeFont(contentStream, "# of MirrorView consistency Groups Created?", ++row, 0, false);
            row = writeFont(contentStream, int2String(mirrorViewInformation.getNrOfConsistencyGroups()), row,
                    answerStart, false);
            row = writeFont(contentStream, "# of MirrorView Remote Mirrors?", ++row, 0, false);
            row = writeFont(contentStream, int2String(mirrorViewInformation.getNumberOfRemoteMirrors()), row,
                answerStart, false);
            row = writeFont(contentStream, "# of MirrorView Secondary Images Created?", ++row, 0, false);
            row = writeFont(contentStream, int2String(mirrorViewInformation.getNumberOfSecondaryImagesCreated()), row,
                answerStart, false);
        }

        SnapViewInformation snapViewInformation = bcRequestData.getSnapViewInformation();
        if (servicesScope.isSnapView() && snapViewInformation != null) {
            row = writeFont(contentStream, "SnapView", ++row, 0, true);
            row = writeFont(contentStream, "# hours of knowledgetransfer", ++row, 0, false);
            row = writeFont(contentStream, snapViewInformation.getKnowledgeTransferHours(), row, answerStart,
                    false);
            row = writeFont(contentStream, "TB of storage to be replicated", ++row, 0, false);
            row = writeFont(contentStream, int2String(snapViewInformation.getReplicatedStorageSize()), row,
                    answerStart, false);
            row = writeFont(contentStream, "Snapview Scripting Requirements", ++row, 0, false);
            ScriptingLevel scriptingLevel = snapViewInformation.getScriptingLevel();
            if (scriptingLevel != null) {
                row = writeFont(contentStream, scriptingLevel.getName(), row, answerStart, false);
            }
            row = writeFont(contentStream, "Select Snap Technology?", ++row, 0, false);
            options = getSnapViewFunctionalityOptions(bcRequestData);
            row = writeOptions(contentStream, options, row, answerStart, columnNum, columnWidth);
            row = writeFont(contentStream, "# of VNX Arrays involved with Snapshots or SnapView", ++row, 0, false);
            row = writeFont(contentStream, int2String(snapViewInformation.getNrOfVnxArrays()), row, answerStart,
                    false);
            row = writeFont(contentStream, "# of Snapshots?", ++row, 0, false);
            row = writeFont(contentStream, int2String(snapViewInformation.getNrOfVnxSnapshotsCopies()), row,
                    answerStart, false);
            row = writeFont(contentStream, "# of Clones?", ++row, 0, false);
            row = writeFont(contentStream, int2String(snapViewInformation.getNrOfSnapViewClonesCopies()), row,
                    answerStart, false);
            row = writeFont(contentStream, "# of Consistent Sessions for SnapView?", ++row, 0, false);
            row = writeFont(contentStream, int2String(snapViewInformation.getNumberOfSnapViewConsistentSessions()), row,
                answerStart, false);
            row = writeFont(contentStream, "# of Persistent Sessions for SnapView?", ++row, 0, false);
            row = writeFont(contentStream, int2String(snapViewInformation.getNumberOfSnapViewPersistentSessions()), row,
                answerStart, false);

            row = writeFont(contentStream, "SnapView Host Information", ++row, 0, false);
            row++;
            String[][] contents = getBcSnapViewHostContents(snapViewInformation);
            int tableRows = drawTable(page, contentStream, getYPos(row), 30, contents, true, null);
            row += tableRows;
        }

        ReplicationManagerInformation managerInformation = bcRequestData.getReplicationManagerInformation();
        if (servicesScope.isReplicationServices() && managerInformation != null) {
            row = writeFont(contentStream, "REPLICATION MANAGER", ++row, 0, true);
            row = writeFont(contentStream, "# hours of knowledgetransfer", ++row, 0, false);
            row = writeFont(contentStream, managerInformation.getKnowledgeTransferHours(), row, answerStart, false);
            row = writeFont(contentStream, "Replication software to be managed", ++row, 0, false);
            options = getReplManagerSoftwareOptions(bcRequestData);
            row = writeOptions(contentStream, options, row, answerStart, columnNum, columnWidth);
            row = writeFont(contentStream, "Is the replication software already installed and configured?", ++row,
                    0, false);
            row = writeFont(contentStream, bool2String(managerInformation.isReplicationInstalled()), row,
                    answerStart, false);
            row = writeFont(contentStream, "Type of replication manager implementation", ++row, 0, false);
            ReplicationManagerImplementation managerImplementation = managerInformation
                    .getReplicationManagerImplementation();
            if (managerImplementation != null) {
                row = writeFont(contentStream, managerImplementation.getName(), row, answerStart, false);
            }
            row = writeFont(contentStream, "TB of storage to be replicated", ++row, 0, false);
            row = writeFont(contentStream, int2String(managerInformation.getReplicatedStorageSize()), row,
                    answerStart, false);
            row = writeFont(contentStream, "Do target devices need to be created via config change?", ++row, 0,
                    false);
            ConfigChangeType configChangeType = managerInformation.getConfigChangeType();
            if (configChangeType != null) {
                row = writeFont(contentStream, configChangeType.getName(), row, answerStart, false);
            }
            row = writeFont(contentStream, "# of replication manager servers (Windows only)", ++row, 0, false);
            row = writeFont(contentStream, int2String(managerInformation.getManagerServersNumber()), row,
                    answerStart, false);
            row = writeFont(contentStream, "Will the RM server(s) be clustered?", ++row, 0, false);
            row = writeFont(contentStream, bool2String(managerInformation.isClusteredRmServerOption()), row,
                    answerStart, false);

            String[][] contents;
            int tableRows;

            row = writeFont(contentStream, "Replication Manager Source Hosts Information", ++row, 0, false);
            row++;
            contents = getBcReplManagerSourceHostContents(managerInformation);
            tableRows = drawTable(page, contentStream, getYPos(row), 30, contents, true, null);
            row += tableRows;

            row = writeFont(contentStream, "Replication Manager Mount Host Information", ++row, 0, false);
            row++;
            contents = getBcReplManagerTargetHostContents(managerInformation);
            tableRows = drawTable(page, contentStream, getYPos(row), 30, contents, true, null);
            row += tableRows;

            row = writeFont(contentStream, "Is custom scripting required?", ++row, 0, false);
            row = writeFont(contentStream, bool2String(managerInformation.isCustomScriptingRequired()), row,
                    answerStart, false);
            row = writeFont(contentStream, "Include Application Integration?", ++row, 0, false);
            row = writeFont(contentStream, bool2String(managerInformation.isIncludeAppIntegration()), row,
                    answerStart, false);
            row = writeFont(contentStream, "Replication Manager Product Specific Preparation", ++row, 0, false);
            ReplicationManagerProductSpecificPreparation preparation = managerInformation
                    .getReplicationManagerProductSpecificPreparation();
            if (preparation != null) {
                row = writeFont(contentStream, preparation.getName(), row, answerStart, false);
            }
            row = writeFont(contentStream, "# of Replicas?", ++row, 0, false);
            row = writeFont(contentStream, int2String(managerInformation.getNrOfReplicas()), row, answerStart,
                    false);
            row = writeFont(contentStream, "# of applications replicated?", ++row, 0, false);
            row = writeFont(contentStream, int2String(managerInformation.getNrOfReplicatedApps()), row,
                    answerStart, false);
            row = writeFont(contentStream, "# of replication jobs?", ++row, 0, false);
            row = writeFont(contentStream, int2String(managerInformation.getNrOfReplicationJobs()), row,
                    answerStart, false);
        }
        row = writeNasIpReplicationInformation(contentStream, bcRequestData, unifiedRequestData,
                infrastructureRequestData, row, answerStart);
        return row;
    }

    /**
     * Write the Mirror View Target Array Information.
     *
     * @param contentStream
     *            the content stream
     * @param mirrorViewInformation
     *            the mirror view information
     * @param row
     *            the row number
     * @return the updated row number
     * @throws IOException
     *             if any I/O error occurs
     */
    private int writeMirrorViewTargetArrayInformation(PDPageContentStream contentStream,
            MirrorViewInformation mirrorViewInformation, int row) throws IOException {
        List<MirrorViewTargetArrayInformation> tais = mirrorViewInformation.getTargetArrayInformation();
        if (tais != null && tais.size() > 0) {
            row++;
            row = writeFont(contentStream, "MirrorView Target Array Information", ++row, 0, true);
            row = writeFont(contentStream, "Target Name:", ++row, 0, true);

            float datacell = 120f;
            float cellWidth = 60f;

            int dataRow = row + 1;
            for (int i = 0; i < tais.size(); i++) {
                row = writeFont(contentStream, "Target " + (i + 1), row, datacell + cellWidth * (i + 1), true);
            }

            writeFont(contentStream, "Array Model", dataRow++, 0, false);
            writeFont(contentStream, "Existing or New", dataRow++, 0, false);
            writeFont(contentStream, "Current MV Status", dataRow++, 0, false);

            for (int i = 0; i < tais.size(); i++) {
                dataRow = row + 1;
                MirrorViewTargetArrayInformation tai = tais.get(i);
                float dataCellStart = datacell + cellWidth * (i + 1);
                dataRow = writeCelerraCell(contentStream, tai.getArrayModel(), dataRow, dataCellStart, false,
                        cellWidth);
                dataRow = writeCelerraCell(contentStream, tai.getExistingOptionEnabled(), dataRow, dataCellStart,
                        true, cellWidth);
                dataRow = writeCelerraCell(contentStream, tai.getMirrowViewInstalledStatus(), dataRow,
                        dataCellStart, false, cellWidth);
            }
            row += (dataRow - row);
        }
        return row;
    }

    /**
     * Write the Mirror View Source Array Information.
     *
     * @param contentStream
     *            the content stream
     * @param mirrorViewInformation
     *            the mirror view information
     * @param row
     *            the row number
     * @return the updated row number
     * @throws IOException
     *             if any I/O error occurs
     */
    private int writeMirrorViewSourceArrayInformation(PDPageContentStream contentStream,
            MirrorViewInformation mirrorViewInformation, int row) throws IOException {
        List<MirrorViewSourceArrayInformation> sais = mirrorViewInformation.getSourceArrayInformation();
        if (sais != null && sais.size() > 0) {
            row++;
            row = writeFont(contentStream, "MirrorView Source Array Information", ++row, 0, true);
            row = writeFont(contentStream, "Source Name:", ++row, 0, true);

            float datacell = 120f;
            float cellWidth = 60f;

            int dataRow = row + 1;
            for (int i = 0; i < sais.size(); i++) {
                row = writeFont(contentStream, "Source " + (i + 1), row, datacell + cellWidth * (i + 1), true);
            }

            writeFont(contentStream, "Array Model", dataRow++, 0, false);
            writeFont(contentStream, "Existing or New", dataRow++, 0, false);
            writeFont(contentStream, "# TB to Replicate", dataRow++, 0, false);
            writeFont(contentStream, "Current MV Status", dataRow++, 0, false);
            writeFont(contentStream, "Uni or Bi Directional", dataRow++, 0, false);
            writeFont(contentStream, "MV Connection", dataRow++, 0, false);

            for (int i = 0; i < sais.size(); i++) {
                dataRow = row + 1;
                MirrorViewSourceArrayInformation sai = sais.get(i);
                float dataCellStart = datacell + cellWidth * (i + 1);
                dataRow = writeCelerraCell(contentStream, sai.getArrayModel(), dataRow, dataCellStart, false,
                        cellWidth);
                dataRow = writeCelerraCell(contentStream, sai.getExistingOptionEnabled(), dataRow, dataCellStart,
                        true, cellWidth);
                dataRow = writeCelerraCell(contentStream, sai.getReplicateSize(), dataRow, dataCellStart, false,
                        cellWidth);
                dataRow = writeCelerraCell(contentStream, sai.getMirrowViewInstalledStatus(), dataRow,
                        dataCellStart, false, cellWidth);
                dataRow = writeCelerraCell(contentStream, sai.getUniOptionEnabled(), dataRow, dataCellStart,
                        false, cellWidth);
                dataRow = writeCelerraCell(contentStream, sai.getMvConnectionType(), dataRow, dataCellStart,
                        false, cellWidth);
            }
            row += (dataRow - row);
        }
        return row;
    }

    /**
     * Write the SRDF Source Array Information.
     *
     * @param contentStream
     *            the content stream
     * @param srdfInformation
     *            the SRDF information
     * @param row
     *            the row number
     * @return the updated row number
     * @throws IOException
     *             if any I/O error occurs
     */
    private int writeSRDFSourceArrayInformation(PDPageContentStream contentStream,
            SrdfInformation srdfInformation, int row) throws IOException {
        List<SrdfSourceArrayInformation> sais = srdfInformation.getSourceArrayInformation();
        if (sais != null && sais.size() > 0) {
            row++;
            row = writeFont(contentStream, "SRDF Source Array Information", ++row, 0, true);
            row = writeFont(contentStream, "Source Name:", ++row, 0, true);

            float datacell = 140f;
            float cellWidth = 60f;

            int dataRow = row + 1;
            for (int i = 0; i < sais.size(); i++) {
                row = writeFont(contentStream, "Source " + (i + 1), row, datacell + cellWidth * (i + 1), true);
            }

            writeFont(contentStream, "Symmetrix Model", dataRow++, 0, false);
            writeFont(contentStream, "# TB to Replicate", dataRow++, 0, false);
            writeFont(contentStream, "# of Symmetrix RDF Source Devices", dataRow++, 0, false);
            writeFont(contentStream, "# of Symmetrix Devices Needed at SRDF Remote Sites", dataRow++, 0, false);
            writeFont(contentStream, "Current SRDF Status", dataRow++, 0, false);
            writeFont(contentStream, "Uni or Bi Directional", dataRow++, 0, false);
            writeFont(contentStream, "SRDF Connection", dataRow++, 0, false);
            writeFont(contentStream, "# of RDF pairs", dataRow++, 0, false);
            writeFont(contentStream, "# RDF groups", dataRow++, 0, false);

            for (int i = 0; i < sais.size(); i++) {
                dataRow = row + 1;
                SrdfSourceArrayInformation sai = sais.get(i);
                float dataCellStart = datacell + cellWidth * (i + 1);
                dataRow = writeCelerraCell(contentStream, sai.getSymmetrixModel(), dataRow, dataCellStart, false,
                        cellWidth);
                dataRow = writeCelerraCell(contentStream, sai.getReplicateSize(), dataRow, dataCellStart, false,
                        cellWidth);
                dataRow = writeCelerraCell(contentStream, sai.getNumOfSymmetrixRDFSourceDevices(), dataRow,
                    dataCellStart, false, cellWidth);
                dataRow = writeCelerraCell(contentStream, sai.getNumOfSymmetrixDevicesNeededAtRDFRemoteSites(), dataRow,
                    dataCellStart, false, cellWidth);
                dataRow = writeCelerraCell(contentStream, sai.getSrdfInstalledStatus(), dataRow, dataCellStart,
                        false, cellWidth);
                dataRow = writeCelerraCell(contentStream, sai.getUniOptionEnabled(), dataRow, dataCellStart,
                        false, cellWidth);
                dataRow = writeCelerraCell(contentStream, sai.getSrdfConnectionType(), dataRow, dataCellStart,
                        false, cellWidth);
                dataRow = writeCelerraCell(contentStream, sai.getNrOfRDFPairs(), dataRow, dataCellStart, false,
                        cellWidth);
                dataRow = writeCelerraCell(contentStream, sai.getNrOfRDFGroups(), dataRow, dataCellStart, false,
                        cellWidth);
            }
            row += (dataRow - row);
        }
        return row;
    }

    /**
     * Write the SRDF Target Array Information.
     *
     * @param contentStream
     *            the content stream
     * @param srdfInformation
     *            the SRDF information
     * @param row
     *            the row number
     * @return the updated row number
     * @throws IOException
     *             if any I/O error occurs
     */
    private int writeSRDFTargetArrayInformation(PDPageContentStream contentStream,
            SrdfInformation srdfInformation, int row) throws IOException {
        List<SrdfTargetArrayInformation> tais = srdfInformation.getTargetArrayInformation();
        if (tais != null && tais.size() > 0) {
            row++;
            row = writeFont(contentStream, "SRDF Target Array Information", ++row, 0, true);
            row = writeFont(contentStream, "Target Name:", ++row, 0, true);

            float datacell = 140f;
            float cellWidth = 60f;

            int dataRow = row + 1;
            for (int i = 0; i < tais.size(); i++) {
                row = writeFont(contentStream, "Target " + (i + 1), row, datacell + cellWidth * (i + 1), true);
            }

            writeFont(contentStream, "Symmetrix Model", dataRow++, 0, false);
            writeFont(contentStream, "Current SRDF Status", dataRow++, 0, false);
            writeFont(contentStream, "Source Name", dataRow++, 0, false);
            writeFont(contentStream, "Include bandwidth analysis and cache size validation?", dataRow++, 0, false);
            writeFont(contentStream, "Include network assessment for new RDF links?", dataRow++, 0, false);
            writeFont(contentStream, "How many hosts need solutions enabler installed?", dataRow++, 0, false);
            writeFont(contentStream, "# of device and / or composite groups?", dataRow++, 0, false);

            for (int i = 0; i < tais.size(); i++) {
                dataRow = row + 1;
                SrdfTargetArrayInformation tai = tais.get(i);
                float dataCellStart = datacell + cellWidth * (i + 1);
                dataRow = writeCelerraCell(contentStream, tai.getSymmetrixModel(), dataRow, dataCellStart, false,
                        cellWidth);
                dataRow = writeCelerraCell(contentStream, tai.getSrdfInstalledStatus(), dataRow, dataCellStart,
                        false, cellWidth);
                dataRow = writeCelerraCell(contentStream, tai.getSourceName(), dataRow, dataCellStart, false,
                        cellWidth);
                dataRow = writeCelerraCell(contentStream, tai.getIncludeBandwidthAnalysis(), dataRow,
                        dataCellStart, false, cellWidth);
                dataRow = writeCelerraCell(contentStream, tai.getIncludeNetworkAssessement(), dataRow,
                        dataCellStart, false, cellWidth);
                dataRow = writeCelerraCell(contentStream, tai.getNrOfHostsNeeded(), dataRow, dataCellStart, false,
                        cellWidth);
                dataRow = writeCelerraCell(contentStream, tai.getNrOfDeviceCompositeGroups(), dataRow,
                        dataCellStart, false, cellWidth);
            }
            row += (dataRow - row);
        }
        return row;
    }

    /**
     * Get BC Replication Manager Source Host contents.
     *
     * @param managerInformation
     *            The BC Replication Manager request data
     * @return the contents
     */
    private String[][] getBcReplManagerSourceHostContents(ReplicationManagerInformation managerInformation) {
        Map<String, Integer> totals = new HashMap<String, Integer>();
        List<String[]> rows = new ArrayList<String[]>();
        for (String platform : PLATFORMS) {
            if (managerInformation.getSourceHostNumber() != null
                    && managerInformation.getSourceHostNumber().get(platform) != null) {
                String[] columns = new String[2];
                columns[0] = platform;
                columns[1] = int2String(getIntegerFromMapAndUpdateTotal(managerInformation.getSourceHostNumber(),
                        platform, totals, "1"));
                rows.add(columns);
            }
        }
        String[][] contents = new String[rows.size() + 2][2];
        contents[0] = new String[] {"Platform", "# of Hosts"};
        for (int i = 0; i < rows.size(); i++) {
            contents[i + 1] = rows.get(i);
        }
        contents[contents.length - 1] = new String[] {"Totals", int2String(totals.get("1"))};
        return contents;
    }

    /**
     * Get BC Replication Manager Target Host contents.
     *
     * @param managerInformation
     *            The BC Replication Manager request data
     * @return the contents
     */
    private String[][] getBcReplManagerTargetHostContents(ReplicationManagerInformation managerInformation) {
        Map<String, Integer> totals = new HashMap<String, Integer>();
        List<String[]> rows = new ArrayList<String[]>();
        for (String platform : PLATFORMS) {
            if (managerInformation.getTargetHostNumber() != null
                    && managerInformation.getTargetHostNumber().get(platform) != null) {
                String[] columns = new String[2];
                columns[0] = platform;
                columns[1] = int2String(getIntegerFromMapAndUpdateTotal(managerInformation.getTargetHostNumber(),
                        platform, totals, "1"));
                rows.add(columns);
            }
        }
        String[][] contents = new String[rows.size() + 2][2];
        contents[0] = new String[] {"Platform", "# of Hosts"};
        for (int i = 0; i < rows.size(); i++) {
            contents[i + 1] = rows.get(i);
        }
        contents[contents.length - 1] = new String[] {"Totals", int2String(totals.get("1"))};
        return contents;
    }

    /**
     * Get BC SnapView Host contents.
     *
     * @param snapViewInformation
     *            The BC SnapView request data
     * @return the contents
     */
    private String[][] getBcSnapViewHostContents(SnapViewInformation snapViewInformation) {
        Map<String, Integer> totals = new HashMap<String, Integer>();
        List<String[]> rows = new ArrayList<String[]>();
        for (String platform : PLATFORMS) {
            if (snapViewInformation.getHostNumbers() != null
                    && snapViewInformation.getHostNumbers().get(platform) != null) {
                String[] columns = new String[2];
                columns[0] = platform;
                columns[1] = int2String(getIntegerFromMapAndUpdateTotal(snapViewInformation.getHostNumbers(),
                        platform, totals, "1"));
                rows.add(columns);
            }
        }
        String[][] contents = new String[rows.size() + 2][2];
        contents[0] = new String[] {"Platform", "# of Hosts"};
        for (int i = 0; i < rows.size(); i++) {
            contents[i + 1] = rows.get(i);
        }
        contents[contents.length - 1] = new String[] {"Totals", int2String(totals.get("1"))};
        return contents;
    }

    /**
     * Get BC Timefinder Host contents.
     *
     * @param timeFinderInformation
     *            The BC Timefinder request data
     * @return the contents
     */
    private String[][] getBcTimefinderHostContents(TimeFinderInformation timeFinderInformation) {
        Map<String, Integer> totals = new HashMap<String, Integer>();
        List<String[]> rows = new ArrayList<String[]>();
        for (String platform : PLATFORMS) {
            if (timeFinderInformation.getHostNumbers() != null
                    && timeFinderInformation.getHostNumbers().get(platform) != null) {
                String[] columns = new String[2];
                columns[0] = platform;
                columns[1] = int2String(getIntegerFromMapAndUpdateTotal(timeFinderInformation.getHostNumbers(),
                        platform, totals, "1"));
                rows.add(columns);
            }
        }
        String[][] contents = new String[rows.size() + 2][2];
        contents[0] = new String[] {"Platform", "# of Hosts"};
        for (int i = 0; i < rows.size(); i++) {
            contents[i + 1] = rows.get(i);
        }
        contents[contents.length - 1] = new String[] {"Totals", int2String(totals.get("1"))};
        return contents;
    }

    /**
     * Get BC MirrorView Source Host contents.
     *
     * @param mirrorViewInformation
     *            The BC MirrorView request data
     * @return the contents
     */
    private String[][] getBcMirrorViewSourceHostContents(MirrorViewInformation mirrorViewInformation) {
        Map<String, Integer> totals = new HashMap<String, Integer>();
        List<String[]> rows = new ArrayList<String[]>();
        for (String platform : PLATFORMS) {
            if (mirrorViewInformation.getHostNumbers() != null
                    && mirrorViewInformation.getHostNumbers().get(platform) != null) {
                String[] columns = new String[2];
                columns[0] = platform;
                columns[1] = int2String(getIntegerFromMapAndUpdateTotal(mirrorViewInformation.getHostNumbers(),
                        platform, totals, "1"));
                rows.add(columns);
            }
        }
        String[][] contents = new String[rows.size() + 2][2];
        contents[0] = new String[] {"Platform", "# of Hosts"};
        for (int i = 0; i < rows.size(); i++) {
            contents[i + 1] = rows.get(i);
        }
        contents[contents.length - 1] = new String[] {"Totals", int2String(totals.get("1"))};
        return contents;
    }

    /**
     * Get BC SRDF Source Host contents.
     *
     * @param srdfInformation
     *            The BC SRDF Source Host request data
     * @return the contents
     */
    private String[][] getBcSRDFSourceHostContents(SrdfInformation srdfInformation) {
        Map<String, Integer> totals = new HashMap<String, Integer>();
        List<String[]> rows = new ArrayList<String[]>();
        for (String platform : PLATFORMS) {
            if (srdfInformation.getHostNumbers() != null && srdfInformation.getHostNumbers().get(platform) != null) {
                String[] columns = new String[2];
                columns[0] = platform;
                columns[1] = int2String(getIntegerFromMapAndUpdateTotal(srdfInformation.getHostNumbers(),
                        platform, totals, "1"));
                rows.add(columns);
            }
        }
        String[][] contents = new String[rows.size() + 2][2];
        contents[0] = new String[] {"Platform", "# of Hosts"};
        for (int i = 0; i < rows.size(); i++) {
            contents[i + 1] = rows.get(i);
        }
        contents[contents.length - 1] = new String[] {"Totals", int2String(totals.get("1"))};
        return contents;
    }

    /**
     * Write MainframeRequestData.
     *
     * @param contentStream
     *            the stream
     * @param mainframeRequestData
     *            the mainframeRequestData
     * @param row
     *            the start row number
     * @return the new row number
     * @throws IOException
     *             if any IO error occurs
     */
    private int writeMainframeRequestData(PDPageContentStream contentStream,
            MainframeRequestData mainframeRequestData, int row) throws IOException {
        row = writeFont(contentStream, "Services & Activities - Mainframe", ++row, 0, true);
        float answerStart = 200f;

        row = writeFont(contentStream, "General Information", ++row, 0, true);
        row = writeAnswer(contentStream, row, answerStart,
                "General Comment", trimToEmpty(mainframeRequestData.getGeneralComment()));

        row++;
        row = writeFont(contentStream, "DMX/VMAX Services", ++row, 0, true);
        int columnNum = 3;
        float columnWidth = 170f;
        row++;
        boolean atLeastOneOption = false;
        List<String> options = getMainframeRequestDataOptions1(mainframeRequestData);
        atLeastOneOption = !options.isEmpty();
        row = writeOptions(contentStream, options, row, 0, columnNum, columnWidth);

        row++;
        row = writeFont(contentStream, "DLm Services", ++row, 0, true);
        row++;
        columnNum = 2;
        columnWidth = 240f;

        options = getMainframeRequestDataOptions2(mainframeRequestData);
        atLeastOneOption = atLeastOneOption || !options.isEmpty();
        row = writeOptions(contentStream, options, row, 0, columnNum, columnWidth);

        if (atLeastOneOption) {
            Map<String, ServiceData> serviceDataMap = new HashMap<String, ServiceData>();
            List<BooleanServiceData> booleanServiceData = mainframeRequestData.getBooleanServiceData();
            for (BooleanServiceData bsd : booleanServiceData) {
                serviceDataMap.put(bsd.getServiceName(), bsd);
            }
            List<StringServiceData> stringServiceData = mainframeRequestData.getStringServiceData();
            for (StringServiceData ssd : stringServiceData) {
                serviceDataMap.put(ssd.getServiceName(), ssd);
            }
            row++;
            MainframeServicesScope servicesScope = mainframeRequestData.getServicesScope();

            if (servicesScope.isDataAnalyticsHealthcheck()) {
                row = writeMainframeServiceTableHeader(contentStream, "Data Analysis Services", row);
                row = writeMainframeServiceData(contentStream, serviceDataMap.get("DAS-01 Flash analysis"),
                        "Flash analysis", row);
                row = writeMainframeServiceData(contentStream,
                        serviceDataMap.get("DAS-02 Number of source arrays"), "Number of source arrays", row);
                row = writeMainframeServiceData(contentStream,
                        serviceDataMap.get("DAS-03 Number of network link tests"), "Number of network link tests",
                        row);
                row = writeMainframeServiceData(contentStream,
                        serviceDataMap.get("DAS-04 Number of DMX/VMAX performance analysis"),
                        "Number of DMX/VMAX performance analysis", row);
                row = writeMainframeServiceData(contentStream, serviceDataMap.get("DAS-05 Number of arrays"),
                        "Number of arrays", row);
                row = writeMainframeServiceData(contentStream,
                        serviceDataMap.get("DAS-06 Number of SRDF bandwidth analysis"),
                        "Number of SRDF bandwidth analysis", row);
                row = writeMainframeServiceData(contentStream,
                        serviceDataMap.get("DAS-07 Number of source arrays"), "Number of source arrays", row);
                row = writeMainframeServiceData(contentStream,
                        serviceDataMap.get("DAS-08 Number of SRDF health checks"), "Number of SRDF health checks",
                        row);
                row = writeMainframeServiceData(contentStream,
                        serviceDataMap.get("DAS-09 Number of source arrays"), "Number of source arrays", row);
                row = writeMainframeServiceData(contentStream,
                        serviceDataMap.get("DAS-10 TimeFinder snap sizing analysis"),
                        "TimeFinder snap sizing analysis", row);
                row = writeMainframeServiceData(contentStream,
                        serviceDataMap.get("DAS-11 Number of source arrays"), "Number of source arrays", row);

                row++;
            }
            if (servicesScope.isEzsmEccInfoMover()) {
                row = writeMainframeServiceTableHeader(contentStream, "Management Software Services", row);
                row = writeMainframeServiceData(contentStream,
                        serviceDataMap.get("MSS-01 EzSM install and knowledge sharing"),
                        "EzSM install and knowledge sharing", row);
                row = writeMainframeServiceData(contentStream,
                        serviceDataMap.get("MSS-02 ECC install and knowledge sharing"),
                        "ECC install and knowledge sharing", row);
                row++;
                row = writeMainframeServiceTableHeader(contentStream, "Other Software Services", row);
                row = writeMainframeServiceData(contentStream,
                        serviceDataMap.get("MSS-03 InfoMover Implementation"), "InfoMover Implementation", row);
                row = writeMainframeServiceData(contentStream, serviceDataMap.get("MSS-04 Number of LPARs"),
                        "Number of LPARs", row);
                row++;
            }
            if (servicesScope.isDmxVmaxDataMigration()) {
                row = writeMainframeServiceTableHeader(contentStream, "Disk Services - Migration", row);
                row = writeMainframeServiceData(contentStream,
                        serviceDataMap.get("DSM-01 zMigrator Volume Migration"), "zMigrator Volume Migration", row);
                row = writeMainframeServiceData(contentStream, serviceDataMap.get("DSM-02 TBs to migrate"),
                        "TBs to migrate", row);
                row = writeMainframeServiceData(contentStream,
                        serviceDataMap.get("DSM-03 zMigrator DataSet Migration"), "zMigrator DataSet Migration",
                        row);
                row = writeMainframeServiceData(contentStream, serviceDataMap.get("DSM-04 TBs to migrate"),
                        "TBs to migrate", row);
                row = writeMainframeServiceData(contentStream, serviceDataMap.get("DSM-05 SRDF Migration"),
                        "SRDF Migration", row);
                row = writeMainframeServiceData(contentStream,
                        serviceDataMap.get("DSM-06 Source frames migrated from"), "Source frames migrated from",
                        row);
                row = writeMainframeServiceData(contentStream,
                        serviceDataMap.get("DSM-07 Source frames migrated to"), "Source frames migrated to", row);
                row = writeMainframeServiceData(contentStream, serviceDataMap.get("DSM-08 TBs to migrate"),
                        "TBs to migrate", row);
                row = writeMainframeServiceData(contentStream, serviceDataMap.get("DSM-09 Maintain replication"),
                        "Maintain replication", row);
                row = writeMainframeServiceData(contentStream,
                        serviceDataMap.get("DSM-10 Number of migration tests"), "Number of migration tests", row);
                row = writeMainframeServiceData(contentStream,
                        serviceDataMap.get("DSM-11 iSeries Host Migration"), "iSeries Host Migration", row);
                row = writeMainframeServiceData(contentStream, serviceDataMap.get("DSM-12 TBs to migrate"),
                        "TBs to migrate", row);
                row++;
            }
            if (servicesScope.isDmxVmaxHardwareImplementation()) {
                row = writeMainframeServiceTableHeader(contentStream, "Disk Services - Hardware", row);
                row = writeMainframeServiceData(contentStream,
                        serviceDataMap.get("DSH-01 Virtual Provisioning Design"), "Virtual Provisioning Design",
                        row);
                row = writeMainframeServiceData(contentStream, serviceDataMap.get("DSH-02 Number of arrays"),
                        "Number of arrays", row);
                row = writeMainframeServiceData(contentStream, serviceDataMap.get("DSH-03 TBs"), "TBs", row);
                row = writeMainframeServiceData(contentStream, serviceDataMap.get("DSH-04 Implement VP"),
                        "Implement VP", row);
                row = writeMainframeServiceData(contentStream, serviceDataMap.get("DSH-05 Number of arrays"),
                        "Number of arrays", row);
                row = writeMainframeServiceData(contentStream, serviceDataMap.get("DSH-06 TBs"), "TBs", row);
                row = writeMainframeServiceData(contentStream, serviceDataMap.get("DSH-07 Implement Fast VP"),
                        "Implement Fast VP", row);
                row = writeMainframeServiceData(contentStream, serviceDataMap.get("DSH-08 Number of arrays"),
                        "Number of arrays", row);
                row = writeMainframeServiceData(contentStream, serviceDataMap.get("DSH-09 TBs"), "TBs", row);
                row = writeMainframeServiceData(contentStream,
                        serviceDataMap.get("DSH-10 Non-Replicated Hardware Design"),
                        "Non-Replicated Hardware Design", row);
                row = writeMainframeServiceData(contentStream, serviceDataMap.get("DSH-11 Number of arrays"),
                        "Number of arrays", row);
                row = writeMainframeServiceData(contentStream, serviceDataMap.get("DSH-12 TBs"), "TBs", row);
                row = writeMainframeServiceData(contentStream,
                        serviceDataMap.get("DSH-13 FICON Director Implementation"),
                        "FICON Director Implementation", row);
                row = writeMainframeServiceData(contentStream, serviceDataMap.get("DSH-14 Vendor"), "Vendor", row);
                row = writeMainframeServiceData(contentStream, serviceDataMap.get("DSH-15 Number of directors"),
                        "Number of directors", row);
                row = writeMainframeServiceData(contentStream, serviceDataMap.get("DSH-16 Number of ports"),
                        "Number of ports", row);
                row = writeMainframeServiceData(contentStream,
                        serviceDataMap.get("DSH-17 Replication (SRDF/IBM) Hardware Design"),
                        "Replication (SRDF/IBM) Hardware Design", row);
                row = writeMainframeServiceData(contentStream, serviceDataMap.get("DSH-18 Number of R1 arrays"),
                        "Number of R1 arrays", row);
                row = writeMainframeServiceData(contentStream, serviceDataMap.get("DSH-19 Number of R2 arrays"),
                        "Number of R2 arrays", row);
                row = writeMainframeServiceData(contentStream, serviceDataMap.get("DSH-20 TBs replicated"),
                        "TBs replicated", row);
                row = writeMainframeServiceData(contentStream,
                        serviceDataMap.get("DSH-21 Number of BIN files needed"), "Number of BIN files needed", row);
                row = writeMainframeServiceData(contentStream,
                        serviceDataMap.get("DSH-22 Array hardware relocation (number)"),
                        "Array hardware relocation (number)", row);
                row++;
            }
            if (servicesScope.isDmxVmaxSrdf()) {
                row = writeMainframeServiceTableHeader(contentStream, "Disk Services - SRDF", row);
                row = writeMainframeServiceData(contentStream,
                        serviceDataMap.get("DSS-01 SRDF - A New Implementation"), "SRDF - A New Implementation",
                        row);
                row = writeMainframeServiceData(contentStream, serviceDataMap.get("DSS-02 Number of R1 arrays"),
                        "Number of R1 arrays", row);
                row = writeMainframeServiceData(contentStream, serviceDataMap.get("DSS-03 Number of R2 arrays"),
                        "Number of R2 arrays", row);
                row = writeMainframeServiceData(contentStream, serviceDataMap.get("DSS-04 TBs replicated"),
                        "TBs replicated", row);
                row = writeMainframeServiceData(contentStream,
                        serviceDataMap.get("DSS-05 SRDF - A New Implementation"), "SRDF - A Refresh/Upgrade", row);
                row = writeMainframeServiceData(contentStream, serviceDataMap.get("DSS-06 Number of R1 arrays"),
                        "Number of R1 arrays", row);
                row = writeMainframeServiceData(contentStream, serviceDataMap.get("DSS-07 Number of R2 arrays"),
                        "Number of R2 arrays", row);
                row = writeMainframeServiceData(contentStream, serviceDataMap.get("DSS-08 TBs replicated"),
                        "TBs replicated", row);
                row = writeMainframeServiceData(contentStream, serviceDataMap.get("DSS-09 SRDF - A MSC Option"),
                        "SRDF - A MSC Option", row);
                row = writeMainframeServiceData(contentStream,
                        serviceDataMap.get("DSS-11 SRDF - A Auto Recovery Option"),
                        "SRDF - A Auto Recovery Option", row);
                row = writeMainframeServiceData(contentStream,
                        serviceDataMap.get("DSS-12 SRDF - A 75 Code Enhancements"),
                        "SRDF - A 75 Code Enhancements", row);
                row = writeMainframeServiceData(contentStream,
                        serviceDataMap.get("DSS-13 SRDF - S New Implementation"), "SRDF - S New Implementation",
                        row);
                row = writeMainframeServiceData(contentStream, serviceDataMap.get("DSS-14 Number of R1 arrays"),
                        "Number of R1 arrays", row);
                row = writeMainframeServiceData(contentStream, serviceDataMap.get("DSS-15 Number of R2 arrays"),
                        "Number of R2 arrays", row);
                row = writeMainframeServiceData(contentStream, serviceDataMap.get("DSS-16 TBs replicated"),
                        "TBs replicated", row);
                row = writeMainframeServiceData(contentStream,
                        serviceDataMap.get("DSS-17 SRDF - S Consistency Group Option"),
                        "SRDF - S Consistency Group Option", row);
                row = writeMainframeServiceData(contentStream,
                        serviceDataMap.get("DSS-18 SRDF - AR New Implementation"), "SRDF - AR New Implementation",
                        row);
                row = writeMainframeServiceData(contentStream, serviceDataMap.get("DSS-19 Number of R1 arrays"),
                        "Number of R1 arrays", row);
                row = writeMainframeServiceData(contentStream, serviceDataMap.get("DSS-20 Number of R2 arrays"),
                        "Number of R2 arrays", row);
                row = writeMainframeServiceData(contentStream, serviceDataMap.get("DSS-21 TBs replicated"),
                        "TBs replicated", row);
                row = writeMainframeServiceData(contentStream,
                        serviceDataMap.get("DSS-22 SRDF - AR Refresh/Upgrade"), "SRDF - AR Refresh/Upgrade", row);
                row = writeMainframeServiceData(contentStream, serviceDataMap.get("DSS-23 Number of R1 arrays"),
                        "Number of R1 arrays", row);
                row = writeMainframeServiceData(contentStream, serviceDataMap.get("DSS-24 Number of R2 arrays"),
                        "Number of R2 arrays", row);
                row = writeMainframeServiceData(contentStream, serviceDataMap.get("DSS-25 TBs replicated"),
                        "TBs replicated", row);
                row = writeMainframeServiceData(contentStream,
                        serviceDataMap.get("DSS-26 Number of SRDF DR Tests"), "Number of SRDF DR Tests", row);
                row = writeMainframeServiceData(contentStream,
                        serviceDataMap.get("DSS-27 SRDF Conversion Static -> Dynamic"),
                        "SRDF Conversion Static -> Dynamic", row);
                row = writeMainframeServiceData(contentStream, serviceDataMap.get("DSS-28 TBs"), "TBs", row);
                row = writeMainframeServiceData(contentStream,
                        serviceDataMap.get("DSS-29 SRDF Knowledge Transfer (hours)"),
                        "SRDF Knowledge Transfer (hours)", row);
                row++;
            }
            if (servicesScope.isDmxVmaxTimeFinder()) {
                row = writeMainframeServiceTableHeader(contentStream, "Disk Services - TimeFinder", row);
                row = writeMainframeServiceData(contentStream,
                        serviceDataMap.get("DST-01 TimeFinder Hardware Design"), "TimeFinder Hardware Design", row);
                row = writeMainframeServiceData(contentStream, serviceDataMap.get("DST-02 Number of arrays"),
                        "Number of arrays", row);
                row = writeMainframeServiceData(contentStream, serviceDataMap.get("DST-03 TBs"), "TBs", row);
                row = writeMainframeServiceData(contentStream,
                        serviceDataMap.get("DST-04 TimeFinder Clone New Implementation"),
                        "TimeFinder Clone New Implementation", row);
                row = writeMainframeServiceData(contentStream, serviceDataMap.get("DST-05 Number of arrays"),
                        "Number of arrays", row);
                row = writeMainframeServiceData(contentStream, serviceDataMap.get("DST-06 TBs"), "TBs", row);
                row = writeMainframeServiceData(contentStream,
                        serviceDataMap.get("DST-07 TimeFinder Clone Refresh/Upgrade"),
                        "TimeFinder Clone Refresh/Upgrade", row);
                row = writeMainframeServiceData(contentStream, serviceDataMap.get("DST-08 Number of arrays"),
                        "Number of arrays", row);
                row = writeMainframeServiceData(contentStream, serviceDataMap.get("DST-09 TBs"), "TBs", row);
                row = writeMainframeServiceData(contentStream,
                        serviceDataMap.get("DST-10 TimeFinder Volume Snap New Implementation"),
                        "TimeFinder Volume Snap New Implementation", row);
                row = writeMainframeServiceData(contentStream, serviceDataMap.get("DST-11 Number of sites"),
                        "Number of sites", row);
                row = writeMainframeServiceData(contentStream, serviceDataMap.get("DST-12 Number of snap copies"),
                        "Number of snap copies", row);
                row = writeMainframeServiceData(contentStream,
                        serviceDataMap.get("DST-13 TimeFinder Volume Snap Refresh/ Upgrade"),
                        "TimeFinder Volume Snap Refresh/ Upgrade", row);
                row = writeMainframeServiceData(contentStream, serviceDataMap.get("DST-14 Number of sites"),
                        "Number of sites", row);
                row = writeMainframeServiceData(contentStream, serviceDataMap.get("DST-15 TBs"), "TBs", row);
                row = writeMainframeServiceData(contentStream,
                        serviceDataMap.get("DST-16 TimeFinder Dataset Snap New Implementation"),
                        "TimeFinder Dataset Snap New Implementation", row);
                row = writeMainframeServiceData(contentStream, serviceDataMap.get("DST-17 Number of sites"),
                        "Number of sites", row);
                row = writeMainframeServiceData(contentStream, serviceDataMap.get("DST-18 TBs"), "TBs", row);
                row = writeMainframeServiceData(contentStream,
                        serviceDataMap.get("DST-19 TimeFinder Dataset Snap Refresh/Upgrade"),
                        "TimeFinder Dataset Snap Refresh/Upgrade", row);
                row = writeMainframeServiceData(contentStream, serviceDataMap.get("DST-20 Number of sites"),
                        "Number of sites", row);
                row = writeMainframeServiceData(contentStream, serviceDataMap.get("DST-21 TBs"), "TBs", row);
                row = writeMainframeServiceData(contentStream,
                        serviceDataMap.get("DST-22 TimeFinder knowledge transfer (hours)"),
                        "TimeFinder knowledge transfer (hours)", row);
                row = writeMainframeServiceData(contentStream,
                        serviceDataMap.get("DST-23 TimeFinder tests (number)"), "TimeFinder tests (number)", row);
                row = writeMainframeServiceData(contentStream,
                        serviceDataMap.get("DST-24 TimeFinder convert from BCV to Clone"),
                        "TimeFinder convert from BCV to Clone", row);
                row = writeMainframeServiceData(contentStream, serviceDataMap.get("DST-25 Number of arrays"),
                        "Number of arrays", row);
                row = writeMainframeServiceData(contentStream, serviceDataMap.get("DST-26 TBs"), "TBs", row);
                row++;
            }
            if (servicesScope.isDmxVmaxAutoswapGddr()) {
                row = writeMainframeServiceTableHeader(contentStream, "Replication Automation", row);
                row = writeMainframeServiceData(contentStream, serviceDataMap.get("RA-01 GDDR Implementation"),
                        "GDDR Implementation", row);
                row = writeMainframeServiceData(contentStream, serviceDataMap.get("RA-02 Sites"), "Sites", row);
                row = writeMainframeServiceData(contentStream, serviceDataMap.get("RA-03 Number of Arrays total"),
                        "Number of Arrays total", row);
                row = writeMainframeServiceData(contentStream,
                        serviceDataMap.get("RA-04 Number of production LPARs"), "Number of production LPARs", row);
                row = writeMainframeServiceData(contentStream, serviceDataMap.get("RA-05 Autoswap"), "Autoswap",
                        row);
                row = writeMainframeServiceData(contentStream, serviceDataMap.get("RA-06 Number of arrays"),
                        "Number of arrays", row);
                row = writeMainframeServiceData(contentStream, serviceDataMap.get("RA-07 Number of LPARs"),
                        "Number of LPARs", row);
                row = writeMainframeServiceData(contentStream,
                        serviceDataMap.get("RA-08 Autoswap DR Testing (Number)"), "Autoswap DR Testing (Number)",
                        row);
                row = writeMainframeServiceData(contentStream,
                        serviceDataMap.get("RA-09 Autoswap Customized Scripting (Hours)"),
                        "Autoswap Customized Scripting (Hours)", row);
                row = writeMainframeServiceData(contentStream,
                        serviceDataMap.get("RA-10 Autoswap Knowledge Transfer (Hours)"),
                        "Autoswap Knowledge Transfer (Hours)", row);
                row++;
            }
            if (servicesScope.isDlmDataMigration()) {
                row = writeMainframeServiceTableHeader(contentStream, "DLm - Migration", row);
                row = writeMainframeServiceData(contentStream, serviceDataMap.get("DM-01 Normal Tape Migration"),
                        "Normal Tape Migration", row);
                row = writeMainframeServiceData(contentStream,
                        serviceDataMap.get("DM-02 Average Throughput Estimate (TBs/Day)"),
                        "Average Throughput Estimate (TBs/Day)", row);
                row = writeMainframeServiceData(contentStream, serviceDataMap.get("DM-03 TBs to migrate"),
                        "TBs to migrate", row);
                row = writeMainframeServiceData(contentStream,
                        serviceDataMap.get("DM-04 Block Level Tape Migration"), "Block Level Tape Migration", row);
                row = writeMainframeServiceData(contentStream,
                        serviceDataMap.get("DM-05 Average Throughput Estimate (TBs/Day)"),
                        "Average Throughput Estimate (TBs/Day)", row);
                row = writeMainframeServiceData(contentStream, serviceDataMap.get("DM-06 TBs to migrate"),
                        "TBs to migrate", row);
                row = writeMainframeServiceData(contentStream,
                        serviceDataMap.get("DM-07 DLm IP Replicator Based Migration"),
                        "DLm IP Replicator Based Migration", row);
                row = writeMainframeServiceData(contentStream, serviceDataMap.get("DM-08 Number of source DLMs"),
                        "Number of source DLMs", row);
                row = writeMainframeServiceData(contentStream,
                        serviceDataMap.get("DM-09 Number of TBs to be migrated"), "Number of TBs to be migrated",
                        row);
                row++;
            }
            if (servicesScope.isDlmHealthcheck()) {
                row = writeMainframeServiceTableHeader(contentStream, "DLm - Health Checks", row);
                row = writeMainframeServiceData(contentStream,
                        serviceDataMap.get("HC-01 DLm Comprehensive Healthcheck (Number)"),
                        "DLm Comprehensive Healthcheck (Number)", row);
                row = writeMainframeServiceData(contentStream,
                        serviceDataMap.get("HC-02 Number of production sites"), "Number of production sites", row);
                row = writeMainframeServiceData(contentStream,
                        serviceDataMap.get("HC-03 TBs of production capacity"), "TBs of production capacity", row);
                row = writeMainframeServiceData(contentStream,
                        serviceDataMap.get("HC-04 DLm Storage Healthcheck (Number)"),
                        "DLm Storage Healthcheck (Number)", row);
                row = writeMainframeServiceData(contentStream,
                        serviceDataMap.get("HC-05 Number of production sites"), "Number of production sites", row);
                row = writeMainframeServiceData(contentStream,
                        serviceDataMap.get("HC-06 TBs of production capacity"), "TBs of production capacity", row);
                row = writeMainframeServiceData(contentStream,
                        serviceDataMap.get("HC-07 DLm Operations Healthcheck (Number)"),
                        "DLm Operations Healthcheck (Number)", row);
                row = writeMainframeServiceData(contentStream,
                        serviceDataMap.get("HC-08 Number of production sites"), "Number of production sites", row);
                row = writeMainframeServiceData(contentStream,
                        serviceDataMap.get("HC-09 TBs of production capacity"), "TBs of production capacity", row);
                row = writeMainframeServiceData(contentStream,
                        serviceDataMap.get("HC-10 DLm DR Healthcheck (Number)"), "DLm DR Healthcheck (Number)",
                        row);
                row = writeMainframeServiceData(contentStream,
                        serviceDataMap.get("HC-11 Number of production sites"), "Number of production sites", row);
                row = writeMainframeServiceData(contentStream,
                        serviceDataMap.get("HC-12 TBs of production capacity"), "TBs of production capacity", row);
                row = writeMainframeServiceData(contentStream,
                        serviceDataMap.get("HC-13 DLm Post Implementation DR Test Participation (Number)"),
                        "DLm Post Implementation DR Test Participation (Number)", row);
                row = writeMainframeServiceData(contentStream,
                        serviceDataMap.get("HC-14 Number of production sites"), "Number of production sites", row);
                row = writeMainframeServiceData(contentStream,
                        serviceDataMap.get("HC-15 TBs of production capacity"), "TBs of production capacity", row);
                row++;
            }
            if (servicesScope.isDlmCustomRequirements()) {
                row = writeMainframeServiceTableHeader(contentStream, "DLm - Custom Services", row);
                row = writeMainframeServiceData(contentStream,
                        serviceDataMap.get("DCS-01 Custom Testing - Describe"), "Custom Testing - Describe", row);
                row = writeMainframeServiceData(contentStream,
                        serviceDataMap.get("DCS-02 Custom Scripting - Describe"), "Custom Scripting - Describe",
                        row);
                row = writeMainframeServiceData(contentStream,
                        serviceDataMap.get("DCS-03 Custom Knowledge - Describe"), "Custom Knowledge - Describe",
                        row);
                row = writeMainframeServiceData(contentStream,
                        serviceDataMap.get("DCS-04 Custom Other - Describe"), "Custom Other - Describe", row);
                row++;
            }
            if (servicesScope.isDlmImplementUpgrade()) {
                row = writeMainframeServiceTableHeader(contentStream,
                        "DLm 2000/6000 and 120/960 Services - Hardware", row);
                row = writeMainframeServiceData(contentStream,
                        serviceDataMap.get("D2SH-01 DLm new NS/VNX hardware impl. (DLm 2000/6000, 120/960)"),
                        "DLm new NS/VNX hardware impl. (DLm 2000/6000, 120/960)", row);
                row = writeMainframeServiceData(contentStream, serviceDataMap.get("D2SH-02 Number of sites"),
                        "Number of sites", row);
                row = writeMainframeServiceData(contentStream,
                        serviceDataMap.get("D2SH-03 Number of replication sites"), "Number of replication sites",
                        row);
                row = writeMainframeServiceData(contentStream, serviceDataMap.get("D2SH-04 Number of TBs usable"),
                        "Number of TBs usable", row);
                row = writeMainframeServiceData(contentStream,
                        serviceDataMap.get("D2SH-05 DLm 2000 POC hardware implementation"),
                        "DLm 2000 POC hardware implementation", row);
                row = writeMainframeServiceData(contentStream, serviceDataMap.get("D2SH-06 Number of sites"),
                        "Number of sites", row);
                row = writeMainframeServiceData(contentStream,
                        serviceDataMap.get("D2SH-07 Number of replication sites"), "Number of replication sites",
                        row);
                row = writeMainframeServiceData(contentStream, serviceDataMap.get("D2SH-08 Number of TBs usable"),
                        "Number of TBs usable", row);
                row = writeMainframeServiceData(contentStream,
                        serviceDataMap.get("D2SH-09 DLm new DD hardware implementation"),
                        "DLm new DD hardware implementation", row);
                row = writeMainframeServiceData(contentStream, serviceDataMap.get("D2SH-10 Number of sites"),
                        "Number of sites", row);
                row = writeMainframeServiceData(contentStream,
                        serviceDataMap.get("D2SH-11 Number of replication sites"), "Number of replication sites",
                        row);
                row = writeMainframeServiceData(contentStream, serviceDataMap.get("D2SH-12 Number of TBs usable"),
                        "Number of TBs usable", row);
                row = writeMainframeServiceData(contentStream,
                        serviceDataMap.get("D2SH-13 DD capacity add service"), "DD capacity add service", row);
                row = writeMainframeServiceData(contentStream, serviceDataMap.get("D2SH-14 Number of TBs usable"),
                        "Number of TBs usable", row);
                row = writeMainframeServiceData(contentStream, serviceDataMap.get("D2SH-15 Number of sites"),
                        "Number of sites", row);
                row = writeMainframeServiceData(contentStream,
                        serviceDataMap.get("D2SH-16 Number of VTEs (Total for all sites)"),
                        "Number of VTEs (Total for all sites)", row);
                row = writeMainframeServiceData(contentStream,
                        serviceDataMap.get("D2SH-17 Expand current filesystems"), "Expand current filesystems",
                        row);
                row = writeMainframeServiceData(contentStream,
                        serviceDataMap.get("D2SH-18 DLm capacity add service (4020/4080 and DLm 120/960)"),
                        "DLm capacity add service (4020/4080 and DLm 120/960)", row);
                row = writeMainframeServiceData(contentStream, serviceDataMap.get("D2SH-19 Number of sites"),
                        "Number of sites", row);
                row = writeMainframeServiceData(contentStream, serviceDataMap.get("D2SH-20 TBs of capacity"),
                        "TBs of capacity", row);
                row = writeMainframeServiceData(contentStream,
                        serviceDataMap.get("D2SH-21 Expand current filesystems"), "Expand current filesystems",
                        row);
                row = writeMainframeServiceData(contentStream, serviceDataMap.get("D2SH-22 Add new filesystems"),
                        "Add new filesystems", row);
                row = writeMainframeServiceData(contentStream,
                        serviceDataMap.get("D2SH-23 DLm capacity add service (DLm 2000/6000)"),
                        "DLm capacity add service (DLm 2000/6000)", row);
                row = writeMainframeServiceData(contentStream, serviceDataMap.get("D2SH-24 Number of sites"),
                        "Number of sites", row);
                row = writeMainframeServiceData(contentStream, serviceDataMap.get("D2SH-25 TBs of capacity"),
                        "TBs of capacity", row);
                row = writeMainframeServiceData(contentStream,
                        serviceDataMap.get("D2SH-26 DLm storage controller add (DLm 2000/6000)"),
                        "DLm storage controller add (DLm 2000/6000)", row);
                row = writeMainframeServiceData(contentStream, serviceDataMap.get("D2SH-27 Number of sites"),
                        "Number of sites", row);
                row = writeMainframeServiceData(contentStream,
                        serviceDataMap.get("D2SH-28 Number of storage controllers total - DataMovers"),
                        "Number of storage controllers total - DataMovers", row);
                row = writeMainframeServiceData(contentStream,
                        serviceDataMap.get("D2SH-29 DLm 120/960/2000/6000 VTE Add (Number of VTEs)"),
                        "DLm 120/960/2000/6000 VTE Add (Number of VTEs)", row);
                row = writeMainframeServiceData(contentStream,
                        serviceDataMap.get("D2SH-30 DLm 120/960/2000/6000 VTE Reconfigure (Number of VTEs)"),
                        "DLm 120/960/2000/6000 VTE Reconfigure (Number of VTEs)", row);
                row++;
                row = writeMainframeServiceTableHeader(contentStream,
                        "DLm 2000/6000 and 120/960 Services - Solution Design", row);
                row = writeMainframeServiceData(contentStream,
                        serviceDataMap.get("D2SSD-01 DLm new implementation"), "DLm new implementation", row);
                row = writeMainframeServiceData(contentStream, serviceDataMap.get("D2SSD-02 DLm 960/120"),
                        "DLm 960/120", row);
                row = writeMainframeServiceData(contentStream, serviceDataMap.get("D2SSD-03 DLm 6000"),
                        "DLm 6000", row);
                row = writeMainframeServiceData(contentStream, serviceDataMap.get("D2SSD-04 DLm 2000"),
                        "DLm 2000", row);
                row = writeMainframeServiceData(contentStream, serviceDataMap.get("D2SSD-05 Number of sites"),
                        "Number of sites", row);
                row = writeMainframeServiceData(contentStream,
                        serviceDataMap.get("D2SSD-06 Number of replication sites"), "Number of replication sites",
                        row);
                row = writeMainframeServiceData(contentStream,
                        serviceDataMap.get("D2SSD-07 Number of VTEs (Total)"), "Number of VTEs (Total)", row);
                row = writeMainframeServiceData(contentStream, serviceDataMap.get("D2SSD-08 DLm 2000 POC"),
                        "DLm 2000 POC", row);
                row = writeMainframeServiceData(contentStream,
                        serviceDataMap.get("D2SSD-09 Number of replication sites"), "Number of replication sites",
                        row);
                row = writeMainframeServiceData(contentStream,
                        serviceDataMap.get("D2SSD-10 Number of VTEs (Total)"), "Number of VTEs (Total)", row);
                row = writeMainframeServiceData(contentStream,
                        serviceDataMap.get("D2SSD-11 DLm 2000/6000 Upgrade/Tech Refresh"),
                        "DLm 2000/6000 Upgrade/Tech Refresh", row);
                row = writeMainframeServiceData(contentStream, serviceDataMap.get("D2SSD-12 Number of sites"),
                        "Number of sites", row);
                row = writeMainframeServiceData(contentStream,
                        serviceDataMap.get("D2SSD-13 Number of replication sites"), "Number of replication sites",
                        row);
                row = writeMainframeServiceData(contentStream,
                        serviceDataMap.get("D2SSD-14 Capacity increase during refresh"),
                        "Capacity increase during refresh", row);
                row = writeMainframeServiceData(contentStream,
                        serviceDataMap.get("D2SSD-15 Number of VTEs (Total)"), "Number of VTEs (Total)", row);
                row = writeMainframeServiceData(contentStream,
                        serviceDataMap.get("D2SSD-16 DLm DR failover test (number)"),
                        "DLm DR failover test (number)", row);
                row = writeMainframeServiceData(contentStream,
                        serviceDataMap.get("D2SSD-17 DLm knowledge sharing (hours)"),
                        "DLm knowledge sharing (hours)", row);
                row++;
            }
            if (servicesScope.isDlmReconfigureAddMove()) {
                row = writeMainframeServiceTableHeader(contentStream,
                        "DLm 2000/6000 and 120/960 Services - Reconfigure, Add, Move", row);
                row = writeMainframeServiceData(contentStream,
                        serviceDataMap.get("DSRAM-01 DLm code upgrade (number)"), "DLm code upgrade (number)", row);
                row = writeMainframeServiceData(contentStream,
                        serviceDataMap.get("DSRAM-02 DLm storage redesign (DLm 4020/4080,120/960)"),
                        "DLm storage redesign (DLm 4020/4080,120/960)", row);
                row = writeMainframeServiceData(contentStream, serviceDataMap.get("DSRAM-03 Number of sites"),
                        "Number of sites", row);
                row = writeMainframeServiceData(contentStream,
                        serviceDataMap.get("DSRAM-04 TBs added via expanding filesystems"),
                        "TBs added via expanding filesystems", row);
                row = writeMainframeServiceData(contentStream,
                        serviceDataMap.get("DSRAM-05 TBs added via new filesystems"),
                        "TBs added via new filesystems", row);
                row = writeMainframeServiceData(contentStream,
                        serviceDataMap.get("DSRAM-06 TBs filesystems removed"), "TBs filesystems removed", row);
                row = writeMainframeServiceData(contentStream,
                        serviceDataMap.get("DSRAM-07 DLm storage redesign service (DLm 2000/6000)"),
                        "DLm storage redesign service (DLm 2000/6000)", row);
                row = writeMainframeServiceData(contentStream, serviceDataMap.get("DSRAM-08 Number of sites"),
                        "Number of sites", row);
                row = writeMainframeServiceData(contentStream,
                        serviceDataMap.get("DSRAM-09 Number of VTEs requiring reconfiguration"),
                        "Number of VTEs requiring reconfiguration", row);
                row = writeMainframeServiceData(contentStream,
                        serviceDataMap.get("DSRAM-10 TBs of capacity reconfigured"),
                        "TBs of capacity reconfigured", row);
                row = writeMainframeServiceData(contentStream,
                        serviceDataMap.get("DSRAM-11 TBs of capacity added"), "TBs of capacity added", row);
                row = writeMainframeServiceData(contentStream,
                        serviceDataMap.get("DSRAM-12 TBs of capacity removed"), "TBs of capacity removed", row);
                row = writeMainframeServiceData(contentStream, serviceDataMap.get("DSRAM-13 DLm Snap"),
                        "DLm Snap", row);
                row = writeMainframeServiceData(contentStream, serviceDataMap.get("DSRAM-14 Number of sites"),
                        "Number of sites", row);
                row = writeMainframeServiceData(contentStream,
                        serviceDataMap.get("DSRAM-15 Number of snap copies"), "Number of snap copies", row);
                row = writeMainframeServiceData(contentStream,
                        serviceDataMap.get("DSRAM-16 DLm Virtuent 6 to 7 Upgrade"), "DLm Virtuent 6 to 7 Upgrade",
                        row);
                row = writeMainframeServiceData(contentStream, serviceDataMap.get("DSRAM-17 Number of DLms"),
                        "Number of DLms", row);
                row = writeMainframeServiceData(contentStream, serviceDataMap.get("DSRAM-18 Includes VNX snap"),
                        "Includes VNX snap", row);
                row = writeMainframeServiceData(contentStream,
                        serviceDataMap.get("DSRAM-19 Number of VTEs (total)"), "Number of VTEs (total)", row);
                row = writeMainframeServiceData(contentStream,
                        serviceDataMap.get("DSRAM-20 DLm Add Replication Site"), "DLm Add Replication Site", row);
                row = writeMainframeServiceData(contentStream,
                        serviceDataMap.get("DSRAM-21 Number of new replication sites"),
                        "Number of new replication sites", row);
                row = writeMainframeServiceData(contentStream,
                        serviceDataMap.get("DSRAM-22 Number of VTEs (total)"), "Number of VTEs (total)", row);
                row = writeMainframeServiceData(contentStream, serviceDataMap.get("DSRAM-23 DLm Relocate"),
                        "DLm Relocate", row);
                row = writeMainframeServiceData(contentStream,
                        serviceDataMap.get("DSRAM-24 Number of production DLms"), "Number of production DLms", row);
                row = writeMainframeServiceData(contentStream,
                        serviceDataMap.get("DSRAM-25 Number of production DLms"), "Number of production DLms", row);
                row = writeMainframeServiceData(contentStream, serviceDataMap.get("DSRAM-26 DLm Removal"),
                        "DLm Removal", row);
                row = writeMainframeServiceData(contentStream,
                        serviceDataMap.get("DSRAM-27 Number of production DLms"), "Number of production DLms", row);
                row = writeMainframeServiceData(contentStream,
                        serviceDataMap.get("DSRAM-28 Number of production DLms"), "Number of production DLms", row);
                row = writeMainframeServiceData(contentStream,
                        serviceDataMap.get("DSRAM-29 DLm Unisys Lead - EMC DLm Install Services"),
                        "DLm Unisys Lead - EMC DLm Install Services", row);
                row = writeMainframeServiceData(contentStream, serviceDataMap.get("DSRAM-30 Number of sites"),
                        "Number of sites", row);
                row = writeMainframeServiceData(contentStream,
                        serviceDataMap.get("DSRAM-31 Number of active sites"), "Number of active sites", row);
                row++;
            }
            if (servicesScope.isDlmServices()) {
                row = writeMainframeServiceTableHeader(contentStream, "DLm 1010/1020 Services - Hardware", row);
                row = writeMainframeServiceData(contentStream,
                        serviceDataMap.get("D1SH-01 DD Hardware Implementation"), "DD Hardware Implementation",
                        row);
                row = writeMainframeServiceData(contentStream, serviceDataMap.get("D1SH-02 Number of sites"),
                        "Number of sites", row);
                row = writeMainframeServiceData(contentStream,
                        serviceDataMap.get("D1SH-03 Number of replication sites"), "Number of replication sites",
                        row);
                row = writeMainframeServiceData(contentStream, serviceDataMap.get("D1SH-04 Number of TBs usable"),
                        "Number of TBs usable", row);
                row = writeMainframeServiceData(contentStream,
                        serviceDataMap.get("D1SH-05 DD Capacity Add Service"), "DD Capacity Add Service", row);
                row = writeMainframeServiceData(contentStream, serviceDataMap.get("D1SH-06 Number of TBs usable"),
                        "Number of TBs usable", row);
                row = writeMainframeServiceData(contentStream, serviceDataMap.get("D1SH-07 Number of sites"),
                        "Number of sites", row);
                row = writeMainframeServiceData(contentStream,
                        serviceDataMap.get("D1SH-08 Number of VTEs (total for all sites)"),
                        "Number of VTEs (total for all sites)", row);
                row = writeMainframeServiceData(contentStream,
                        serviceDataMap.get("D1SH-09 Expand current filesystems"), "Expand current filesystems",
                        row);
                row = writeMainframeServiceData(contentStream, serviceDataMap.get("D1SH-10 Add new filesystems"),
                        "Add new filesystems", row);
                row++;
                row = writeMainframeServiceTableHeader(contentStream, "DLm 1010/1020 Services - Solution", row);
                row = writeMainframeServiceData(contentStream,
                        serviceDataMap.get("D1SS-01 DLm 1010/1020 new implementation"),
                        "DLm 1010/1020 new implementation", row);
                row = writeMainframeServiceData(contentStream, serviceDataMap.get("D1SS-02 Number of sites"),
                        "Number of sites", row);
                row = writeMainframeServiceData(contentStream,
                        serviceDataMap.get("D1SS-03 Number of replication sites"), "Number of replication sites",
                        row);
                row = writeMainframeServiceData(contentStream, serviceDataMap.get("D1SS-04 Number of VTEs"),
                        "Number of VTEs", row);
                row = writeMainframeServiceData(contentStream,
                        serviceDataMap.get("D1SS-05 DLm 1010/1020 tech refresh"), "DLm 1010/1020 tech refresh",
                        row);
                row = writeMainframeServiceData(contentStream, serviceDataMap.get("D1SS-06 Number of sites"),
                        "Number of sites", row);
                row = writeMainframeServiceData(contentStream,
                        serviceDataMap.get("D1SS-07 Number of replication sites"), "Number of replication sites",
                        row);
                row = writeMainframeServiceData(contentStream, serviceDataMap.get("D1SS-08 Number of VTEs"),
                        "Number of VTEs", row);
                row = writeMainframeServiceData(contentStream,
                        serviceDataMap.get("D1SS-09 DLm 1010/1020 DR failover test (number)"),
                        "DLm 1010/1020 DR failover test (number)", row);
                row = writeMainframeServiceData(contentStream,
                        serviceDataMap.get("D1SS-10 DLm 1010/1020 knowledge sharing hours"),
                        "DLm 1010/1020 knowledge sharing hours", row);
                row = writeMainframeServiceData(contentStream,
                        serviceDataMap.get("D1SS-11 DLm 1010/1020 code upgrade (number)"),
                        "DLm 1010/1020 code upgrade (number)", row);
                row = writeMainframeServiceData(contentStream, serviceDataMap.get("D1SS-12 DLm 1010/1020 snap"),
                        "DLm 1010/1020 snap", row);
                row = writeMainframeServiceData(contentStream, serviceDataMap.get("D1SS-13 Number of sites"),
                        "Number of sites", row);
                row = writeMainframeServiceData(contentStream,
                        serviceDataMap.get("D1SS-14 Number of snap copies"), "Number of snap copies", row);
                row = writeMainframeServiceData(contentStream,
                        serviceDataMap.get("D1SS-15 DLm 1010/1020 add replication site"),
                        "DLm 1010/1020 add replication site", row);
                row = writeMainframeServiceData(contentStream,
                        serviceDataMap.get("D1SS-16 Number of replication sites"), "Number of replication sites",
                        row);
                row = writeMainframeServiceData(contentStream,
                        serviceDataMap.get("D1SS-17 Number of new active sites"), "Number of new active sites",
                        row);
                row = writeMainframeServiceData(contentStream, serviceDataMap.get("D1SS-18 Number of TBs usable"),
                        "Number of TBs usable", row);
                row = writeMainframeServiceData(contentStream,
                        serviceDataMap.get("D1SS-19 Number of VTEs (total)"), "Number of VTEs (total)", row);
                row = writeMainframeServiceData(contentStream,
                        serviceDataMap.get("D1SS-20 DLm 1010/1020 relocate"), "DLm 1010/1020 relocate", row);
                row = writeMainframeServiceData(contentStream,
                        serviceDataMap.get("D1SS-21 Number of production VTEs"), "Number of production VTEs", row);
                row = writeMainframeServiceData(contentStream,
                        serviceDataMap.get("D1SS-22 Number of replication VTEs"), "Number of replication VTEs",
                        row);
                row++;
            }
            if (servicesScope.isDlmImplementation()) {
                row = writeMainframeServiceTableHeader(contentStream, "DLm 8000 Services - Hardware", row);
                row = writeMainframeServiceData(contentStream,
                        serviceDataMap.get("D8SH-01 Replication Hardware Design"), "Replication Hardware Design",
                        row);
                row = writeMainframeServiceData(contentStream, serviceDataMap.get("D8SH-02 Number of R1 arrays"),
                        "Number of R1 arrays", row);
                row = writeMainframeServiceData(contentStream, serviceDataMap.get("D8SH-03 Number of R2 arrays"),
                        "Number of R2 arrays", row);
                row = writeMainframeServiceData(contentStream, serviceDataMap.get("D8SH-04 TBs replicated"),
                        "TBs replicated", row);
                row = writeMainframeServiceData(contentStream,
                        serviceDataMap.get("D8SH-05 Number of BIN files needed"), "Number of BIN files needed",
                        row);
                row = writeMainframeServiceData(contentStream,
                        serviceDataMap.get("D8SH-06 Number Brocade 5100B Installation and Zoning"),
                        "Number Brocade 5100B Installation and Zoning", row);
                row = writeMainframeServiceData(contentStream,
                        serviceDataMap.get("D8SH-07 Number Brocade VDX Installation and Configuration"),
                        "Number Brocade VDX Installation and Configuration", row);
                row = writeMainframeServiceData(contentStream, serviceDataMap.get("D8SH-08 Number of VG8s Total"),
                        "Number of VG8s Total", row);
                row = writeMainframeServiceData(contentStream, serviceDataMap.get("D8SH-09 VTE Implementation"),
                        "VTE Implementation", row);
                row = writeMainframeServiceData(contentStream, serviceDataMap.get("D8SH-10 Number of sites"),
                        "Number of sites", row);
                row = writeMainframeServiceData(contentStream,
                        serviceDataMap.get("D8SH-11 Number of replication sites"), "Number of replication sites",
                        row);
                row = writeMainframeServiceData(contentStream, serviceDataMap.get("D8SH-12 Number of TBs usable"),
                        "Number of TBs usable", row);
                row = writeMainframeServiceData(contentStream,
                        serviceDataMap.get("D8SH-13 SRDF-S New Implementation"), "SRDF-S New Implementation", row);
                row = writeMainframeServiceData(contentStream, serviceDataMap.get("D8SH-14 Number of R1 arrays"),
                        "Number of R1 arrays", row);
                row = writeMainframeServiceData(contentStream, serviceDataMap.get("D8SH-15 Number of R2 arrays"),
                        "Number of R2 arrays", row);
                row = writeMainframeServiceData(contentStream, serviceDataMap.get("D8SH-16 TBs replicated"),
                        "TBs replicated", row);
                row = writeMainframeServiceData(contentStream,
                        serviceDataMap.get("D8SH-17 SRDF-A New Implementation"), "SRDF-A New Implementation", row);
                row = writeMainframeServiceData(contentStream, serviceDataMap.get("D8SH-18 Number of R1 arrays"),
                        "Number of R1 arrays", row);
                row = writeMainframeServiceData(contentStream, serviceDataMap.get("D8SH-19 Number of R2 arrays"),
                        "Number of R2 arrays", row);
                row = writeMainframeServiceData(contentStream, serviceDataMap.get("D8SH-20 TBs replicated"),
                        "TBs replicated", row);
                row = writeMainframeServiceData(contentStream,
                        serviceDataMap.get("D8SH-21 Number of SRDF Bandwidth Analysis"),
                        "Number of SRDF Bandwidth Analysis", row);
                row = writeMainframeServiceData(contentStream,
                        serviceDataMap.get("D8SH-22 Number of source arrays"), "Number of source arrays", row);
                row = writeMainframeServiceData(contentStream,
                        serviceDataMap.get("D8SH-23 TimeFinder Clone New Implementation"),
                        "TimeFinder Clone New Implementation", row);
                row = writeMainframeServiceData(contentStream, serviceDataMap.get("D8SH-24 Number of Arrays"),
                        "Number of Arrays", row);
                row = writeMainframeServiceData(contentStream, serviceDataMap.get("D8SH-25 TBs"), "TBs", row);
                row = writeMainframeServiceData(contentStream, serviceDataMap.get("D8SH-26 Number of sites"),
                        "Number of sites", row);
                row = writeMainframeServiceData(contentStream,
                        serviceDataMap.get("D8SH-27 Number of replication sites"), "Number of replication sites",
                        row);
                row = writeMainframeServiceData(contentStream,
                        serviceDataMap.get("D1SS-28 Number of VTEs (total)"), "Number of VTEs (total)", row);
                row = writeMainframeServiceData(contentStream,
                        serviceDataMap.get("D1SS-29 DLm DR Failover Test (number)"),
                        "DLm DR Failover Test (number)", row);
                row = writeMainframeServiceData(contentStream,
                        serviceDataMap.get("D1SS-30 DLm Knowledge Sharing (hours)"),
                        "DLm Knowledge Sharing (hours)", row);
                row = writeMainframeServiceData(contentStream,
                        serviceDataMap.get("D8SH-31 DLm 2 Site Standard Scripted Replication Solution"),
                        "DLm 2 Site Standard Scripted Replication Solution", row);
                row++;
            }
            if (servicesScope.isDlmScripting()) {
                row = writeMainframeServiceTableHeader(contentStream, "DLm 2000/6000 Scripting", row);
                row = writeMainframeServiceData(contentStream,
                        serviceDataMap.get("D2S-01 DLm snapshot DR testing scripts (1 site, 1 DLM, and 1 snap)"),
                        "DLm snapshot DR testing scripts (1 site, 1 DLM, and 1 snap)", row);
                row++;
            }
        }
        return row;
    }

    /**
     * Write the Mainframe Service table header.
     *
     * @param contentStream
     *            the content stream
     * @param title
     *            the table title
     * @param row
     *            the row number
     * @return the updated row number
     * @throws IOException
     *             if any I/O error occurs
     */
    private int writeMainframeServiceTableHeader(PDPageContentStream contentStream, String title, int row)
        throws IOException {
        row = writeFont(contentStream, title, ++row, 0, true);
        row = writeFont(contentStream, "Service", ++row, 0, true);
        row = writeFont(contentStream, "Scope", row, 300, true);
        row = writeFont(contentStream, "Description", row, 400, true);
        return row;
    }

    /**
     * Write the Mainframe Service Data.
     *
     * @param contentStream
     *            the content stream
     * @param serviceData
     *            the service data
     * @param label
     *            the field label
     * @param row
     *            the row number
     * @return the updated row number
     * @throws IOException
     *             if any I/O error occurs
     */
    private int writeMainframeServiceData(PDPageContentStream contentStream, ServiceData serviceData,
            String label, int row) throws IOException {
        if (serviceData instanceof BooleanServiceData) {
            BooleanServiceData booleanServiceData = (BooleanServiceData) serviceData;
            row = writeFont(contentStream, label, ++row, 0, true);
            Boolean enabled = booleanServiceData.getEnabled();
            if (enabled != null && enabled) {
                row = writeFont(contentStream, bool2String(enabled), row, 300, false);
            }
            String description = booleanServiceData.getDescription();
            if (description != null) {
                row = writeFont(contentStream, description, row, 400, false);
            }
        } else if (serviceData instanceof StringServiceData) {
            StringServiceData stringServiceData = (StringServiceData) serviceData;
            row = writeFont(contentStream, label, ++row, 0, true);
            String value = stringServiceData.getValue();
            if (value != null) {
                row = writeFont(contentStream, value, row, 300, false);
            }
            String description = stringServiceData.getDescription();
            if (description != null) {
                row = writeFont(contentStream, description, row, 400, false);
            }
        }
        return row;
    }

    /**
     * Get MainframeRequestData Options part one.
     *
     * @param mainframeRequestData
     *            the mainframeRequestData
     * @return the options list.
     */
    private List<String> getMainframeRequestDataOptions1(MainframeRequestData mainframeRequestData) {
        List<String> options = new ArrayList<String>();
        MainframeServicesScope scope = mainframeRequestData.getServicesScope();
        if (scope != null) {
            if (scope.isDataAnalyticsHealthcheck()) {
                options.add("Data Analytics and Healthchecks");
            }
            if (scope.isEzsmEccInfoMover()) {
                options.add("EzSM, ECC, InfoMover");
            }
            if (scope.isDmxVmaxDataMigration()) {
                options.add("DMX/VMAX Data Migration");
            }
            if (scope.isDmxVmaxHardwareImplementation()) {
                options.add("DMX/VMAX Hardware Implementation");
            }
            if (scope.isDmxVmaxSrdf()) {
                options.add("DMX/VMAX SRDF");
            }
            if (scope.isDmxVmaxTimeFinder()) {
                options.add("DMX/VMAX TimeFinder");
            }
            if (scope.isDmxVmaxAutoswapGddr()) {
                options.add("DMX/VMAX AutoSwap, GDDR");
            }
        }
        return options;
    }

    /**
     * Get MainframeRequestData Options part two.
     *
     * @param mainframeRequestData
     *            the mainframeRequestData
     * @return the options list.
     */
    private List<String> getMainframeRequestDataOptions2(MainframeRequestData mainframeRequestData) {
        List<String> options = new ArrayList<String>();
        MainframeServicesScope scope = mainframeRequestData.getServicesScope();
        if (scope != null) {
            if (scope.isDlmDataMigration()) {
                options.add("DLm Data Migration");
            }
            if (scope.isDlmHealthcheck()) {
                options.add("DLm Healthchecks");
            }
            if (scope.isDlmCustomRequirements()) {
                options.add("DLm Custom Requirements");
            }
            if (scope.isDlmImplementUpgrade()) {
                options.add("DLm 2000/6000 120/960 Implement / Upgrade");
            }
            if (scope.isDlmReconfigureAddMove()) {
                options.add("DLm 2000/6000 120/960 Reconfigure, Add, Move");
            }
            if (scope.isDlmScripting()) {
                options.add("DLm 2000/6000 DR Scripting");
            }
            if (scope.isDlmServices()) {
                options.add("DLm 1000 Services");
            }
            if (scope.isDlmImplementation()) {
                options.add("DLm 8000 Implementation");
            }
        }
        return options;
    }

    /**
     * Write UnifiedRequestData.
     *
     * @param contentStream
     *            the stream
     * @param unifiedRequestData
     *            the unifiedRequestData
     * @param infrastuctureRequestData
     *            the infrastuctureRequestData
     * @param row
     *            the start row number
     * @return the new row number
     * @throws IOException
     *             if any IO error occurs
     */
    private int writeUnifiedRequestData(PDPageContentStream contentStream, UnifiedRequestData unifiedRequestData,
            InfrastructureRequestData infrastuctureRequestData, int row) throws IOException {
        row = writeFont(contentStream, "Services & Activities - File / NAS", ++row, 0, true);
        row = writeFont(contentStream, "GENERAL INFORMATION", ++row, 0, true);

        float answerStart = 200f;
        row = writeFont(contentStream, "# hours of knowledge transfer", ++row, 0, false);
        row = writeFont(contentStream, getTotalHoursOfKnowledgeTransferUnified(unifiedRequestData), row,
                answerStart, false);
        row = writeAnswer(contentStream, row, answerStart,
                "General Comment", trimToEmpty(unifiedRequestData.getGeneralComment()));
        answerStart = 280f;
        row++;
        row = writeFont(contentStream, "Unified Services", ++row, 0, true);
        List<String> options = getUnifiedRequestDataOptions(unifiedRequestData);
        row++;
        row = writeOptions(contentStream, options, row, 0, 5, 100f);
        row = writeCelerraDetailInformation(contentStream, unifiedRequestData, infrastuctureRequestData, row,
                answerStart);
        row = writeNasMigrationInformation(contentStream, unifiedRequestData, row, answerStart);
        return row;
    }

    /**
     * Writes celerra detail information.
     *
     * @param contentStream
     *            the stream
     * @param unifiedRequestData
     *            the unifiedRequestData
     * @param infrastuctureRequestData
     *            the infrastuctureRequestData
     * @param row
     *            the start row number
     * @param answerStart
     *            the answer start position
     * @return the new row number
     * @throws IOException
     *             if any IO error occurs
     */
    private int writeCelerraDetailInformation(PDPageContentStream contentStream,
            UnifiedRequestData unifiedRequestData, InfrastructureRequestData infrastuctureRequestData, int row,
            float answerStart) throws IOException {
        List<CelerraDetailInformation> cdis = unifiedRequestData.getCelerraDetailInformation();
        if (cdis != null && cdis.size() > 0) {
            row++;
            row = writeFont(contentStream, "VNX Implementation", ++row, 0, true);

            if (infrastuctureRequestData != null) {
                VnxClariionInformation vci = infrastuctureRequestData.getVnxClariionInformation();
                if (vci != null && vci.getVnxInstallProtocolType() != null
                        && infrastuctureRequestData.isVnxClariionServiceEnabled()) {
                    VnxInstallProtocolType vnxInstallProtocolType = vci.getVnxInstallProtocolType();

                    boolean vnxFileAll = vnxInstallProtocolType != null
                            && "File Only (CIFS/NFS)".equals(vnxInstallProtocolType.getName());
                    boolean vnxBothBasic = vnxInstallProtocolType != null
                            && "BOTH".equals(vnxInstallProtocolType.getName());
                    boolean vnxFileStandardComplex = vnxInstallProtocolType != null
                            && ("File Only (CIFS/NFS)".equals(vnxInstallProtocolType.getName()));
                    boolean vnxFileCifsStandardComplex = vnxFileStandardComplex;
                    boolean vnxFileNfsStandardComplex = vnxFileStandardComplex;
                    boolean vnxAllStandardComplex = true;
                    UnifiedServicesScope servicesScope = unifiedRequestData.getServicesScope();
                    boolean celerraImplementation = servicesScope.isCelerraImplementation();

                    row = writeFont(contentStream, "# hours of knowledge transfer", ++row, 0, false);
                    row = writeFont(contentStream, unifiedRequestData.getCelerraDetailKnowledgeTransferHours(),
                            row, answerStart, false);
                    row = writeFont(contentStream, "In Scope Area:", ++row, 0, true);

                    float datacell = 220f;
                    float cellWidth = 60f;

                    int dataRow = row + 1;
                    for (int i = 0; i < cdis.size(); i++) {
                        row = writeFont(contentStream, "Celerra " + (i + 1), row, datacell + cellWidth * (i + 1),
                                true);
                    }
                    if (celerraImplementation && vnxFileAll) {
                        writeFont(contentStream, "Select the model for each Celerra", dataRow++, 0, false);
                    }
                    if (celerraImplementation) {
                        writeFont(contentStream, "VNX Location (City, State)", dataRow++, 0, false);
                        writeFont(contentStream, "VNX Protocol", dataRow++, 0, false);
                    }
                    if (celerraImplementation && vnxFileAll) {
                        writeFont(contentStream, "New or Existing Celerra?", dataRow++, 0, false);
                    }
                    writeFont(contentStream, "Include additional Disk Array Enclosures (DAE) and or Dense (DAE)",
                            dataRow++, 0, false);
                    writeFont(contentStream, "Include \"rack and stack\" as part of custom quote?", dataRow++, 0,
                            false);
                    writeFont(contentStream, "Storage hardware for the Gateway", dataRow++, 0, false);
                    writeFont(contentStream, "New or existing Symmetrix storage for the Gateway?", dataRow++, 0,
                            false);
                    if (vnxBothBasic) {
                        writeFont(contentStream, "Select IO interface modules for VNX Unified Storage System:",
                                dataRow++, 0, false);
                    }
                    if (vnxFileAll) {
                        writeFont(contentStream, "Dual Control Stations to be used?", dataRow++, 0, false);
                        writeFont(contentStream, "# of New Datamovers - per Celerra", dataRow++, 0, false);
                    }
                    writeFont(contentStream, "Configure FAST VP for File?", dataRow++, 0, false);
                    if (vnxFileAll) {
                        writeFont(contentStream, "Usable Storage to be allocated to NAS (TB) - per NAS array",
                                dataRow++, 0, false);
                        writeFont(contentStream, "# of Filesystems to be created for NAS (TB) per NAS array",
                                dataRow++, 0, false);
                        writeFont(contentStream, "Configure NFS? - per NAS array", dataRow++, 0, false);
                        writeFont(contentStream, "Configure CIFS? - per NAS array", dataRow++, 0, false);
                        writeFont(contentStream, "Configure Celerra/VNX as MultiProtocol? - per NAS array",
                                dataRow++, 0, false);
                    }
                    if (vnxFileStandardComplex) {
                        writeFont(contentStream, "NAS Features Required", dataRow++, 0, false);
                    }
                    if (vnxFileCifsStandardComplex) {
                        writeFont(contentStream, "Include CIFS Advanced Features?", dataRow++, 0, false);
                    }
                    if (vnxFileStandardComplex) {
                        writeFont(contentStream, "LDAP Integration Required? - per NAS array", dataRow++, 0, false);
                    }
                    if (vnxFileNfsStandardComplex) {
                        writeFont(contentStream, "NFSv4 Required? - per Celerra", dataRow++, 0, false);
                        writeFont(contentStream, "Include pNFS over FC?", dataRow++, 0, false);
                        writeFont(contentStream, "Include pNFS over iSCSI?", dataRow++, 0, false);
                    }
                    if (vnxAllStandardComplex) {
                        writeFont(contentStream, "Is IP Replication currently configured on this Celerra?",
                                dataRow++, 0, false);
                        writeFont(contentStream, "Deinstall this Celerra?", dataRow++, 0, false);
                    }
                    if (vnxFileStandardComplex) {
                        writeFont(contentStream, "# of CAVA servers to be configured - Total", dataRow++, 0, false);
                    }
                    if (servicesScope.isMpfs()) {
                        writeFont(contentStream, "MPFS hosts to be configured? - per Celerra", dataRow++, 0, false);
                        writeFont(contentStream, "MPFS host quantity - per Celerra", dataRow++, 0, false);
                        writeFont(contentStream, "MPFS file systems - per Celerra", dataRow++, 0, false);
                        writeFont(contentStream, "MPFSi hosts to be configured? - per Celerra", dataRow++, 0,
                                false);
                        writeFont(contentStream, "MPFSi host quantity - per Celerra", dataRow++, 0, false);
                        writeFont(contentStream, "MPFSi file systems - per Celerra", dataRow++, 0, false);
                    }
                    writeFont(contentStream, "# of file servers", dataRow++, 0, false);
                    writeFont(contentStream, "# of file systems to be configured", dataRow++, 0, false);
                    writeFont(contentStream, "# of CIFS servers to be configured", dataRow++, 0, false);
                    writeFont(contentStream, "# of CIFS Shares to be configured", dataRow++, 0, false);
                    writeFont(contentStream, "# of NFS Filesystems to be configured", dataRow++, 0, false);
                    writeFont(contentStream, "# of File Systems to be NFS Exported", dataRow++, 0, false);

                    for (int i = 0; i < cdis.size(); i++) {
                        dataRow = row + 1;
                        CelerraDetailInformation cdi = cdis.get(i);
                        float dataCellStart = datacell + cellWidth * (i + 1);
                        if (celerraImplementation && vnxFileAll) {
                            dataRow = writeCelerraCell(contentStream, cdi.getCelerraModel(), dataRow,
                                    dataCellStart, false, cellWidth);
                        }
                        if (celerraImplementation) {
                            dataRow = writeCelerraCell(contentStream, cdi.getCelerraLocation(), dataRow,
                                    dataCellStart, false, cellWidth);
                            dataRow = writeCelerraCell(contentStream, cdi.getVnxProtocol(), dataRow,
                                    dataCellStart, false, cellWidth);
                        }
                        if (celerraImplementation && vnxFileAll) {
                            dataRow = writeCelerraCell(contentStream, cdi.getNewCelerraOption(), dataRow,
                                    dataCellStart, true, cellWidth);
                        }
                        dataRow = writeCelerraCell(contentStream, cdi.getDiskArrayEnclosuresIncluded(), dataRow,
                                dataCellStart, false, cellWidth);
                        dataRow = writeCelerraCell(contentStream, cdi.getRackAndStackOption(), dataRow,
                                dataCellStart, false, cellWidth);
                        dataRow = writeCelerraCell(contentStream, cdi.getGatewayStorageType(), dataRow,
                                dataCellStart, false, cellWidth);
                        dataRow = writeCelerraCell(contentStream, cdi.getNewSymmetrixStorageOption(), dataRow,
                                dataCellStart, true, cellWidth);
                        if (vnxBothBasic) {
                            dataRow = writeCelerraCell(contentStream, cdi.getIoInterfaceModule(), dataRow,
                                    dataCellStart, false, cellWidth);
                        }
                        if (vnxFileAll) {
                            dataRow = writeCelerraCell(contentStream, cdi.getDualControlStationsUsed(), dataRow,
                                    dataCellStart, false, cellWidth);
                            dataRow = writeCelerraCell(contentStream, cdi.getDatamoversNumber(), dataRow,
                                    dataCellStart, false, cellWidth);
                        }
                        dataRow = writeCelerraCell(contentStream, cdi.getFileFastVpConfigured(), dataRow,
                                dataCellStart, false, cellWidth);
                        if (vnxFileAll) {
                            dataRow = writeCelerraCell(contentStream, cdi.getUsableStorageSize(), dataRow,
                                    dataCellStart, false, cellWidth);
                            dataRow = writeCelerraCell(contentStream, cdi.getFileSystemNumber(), dataRow,
                                    dataCellStart, false, cellWidth);
                            dataRow = writeCelerraCell(contentStream, cdi.getNfsConfigured(), dataRow,
                                    dataCellStart, false, cellWidth);
                            dataRow = writeCelerraCell(contentStream, cdi.getCifsConfigured(), dataRow,
                                    dataCellStart, false, cellWidth);
                            dataRow = writeCelerraCell(contentStream, cdi.getMultiprotocolCelerraConfigured(),
                                    dataRow, dataCellStart, false, cellWidth);
                        }
                        if (vnxFileStandardComplex) {
                            String unifiedNasFeatures = getUnifiedNasFeatures(cdi.getNasFeatures());
                            String nasFeaturesString = StringUtils.EMPTY;
                            if (unifiedNasFeatures.length() >= 10) {
                                nasFeaturesString = unifiedNasFeatures.substring(0, 10) + "...";
                            }
                            dataRow = writeCelerraCell(contentStream, nasFeaturesString, dataRow, dataCellStart,
                                    false, cellWidth);
                        }
                        if (vnxFileCifsStandardComplex) {
                            dataRow = writeCelerraCell(contentStream, cdi.getCifsFeaturesIncluded(), dataRow,
                                    dataCellStart, false, cellWidth);
                        }
                        if (vnxFileStandardComplex) {
                            dataRow = writeCelerraCell(contentStream, cdi.getLdapRequired(), dataRow,
                                    dataCellStart, false, cellWidth);
                        }
                        if (vnxFileNfsStandardComplex) {
                            dataRow = writeCelerraCell(contentStream, cdi.getNfsv4Configured(), dataRow,
                                    dataCellStart, false, cellWidth);
                            dataRow = writeCelerraCell(contentStream, cdi.getIncludeNfsOverFc(), dataRow,
                                    dataCellStart, false, cellWidth);
                            dataRow = writeCelerraCell(contentStream, cdi.getIncludeNfsOverIScsi(), dataRow,
                                    dataCellStart, false, cellWidth);
                        }
                        if (vnxAllStandardComplex) {
                            dataRow = writeCelerraCell(contentStream, cdi.getIpReplicationConfigured(), dataRow,
                                    dataCellStart, false, cellWidth);
                            dataRow = writeCelerraCell(contentStream, cdi.getDeinstallCelera(), dataRow,
                                    dataCellStart, false, cellWidth);
                        }
                        if (vnxFileStandardComplex) {
                            dataRow = writeCelerraCell(contentStream, cdi.getCavaServerNumber(), dataRow,
                                    dataCellStart, false, cellWidth);
                        }
                        if (servicesScope.isMpfs()) {
                            dataRow = writeCelerraCell(contentStream, cdi.getMpfsRequired(), dataRow,
                                    dataCellStart, false, cellWidth);
                            dataRow = writeCelerraCell(contentStream, cdi.getMpfsHostQuantity(), dataRow,
                                    dataCellStart, false, cellWidth);
                            dataRow = writeCelerraCell(contentStream, cdi.getMpfsFileSystemsQuantity(), dataRow,
                                    dataCellStart, false, cellWidth);
                            dataRow = writeCelerraCell(contentStream, cdi.getMpfsiRequired(), dataRow,
                                    dataCellStart, false, cellWidth);
                            dataRow = writeCelerraCell(contentStream, cdi.getMpfsiHostQuantity(), dataRow,
                                    dataCellStart, false, cellWidth);
                            dataRow = writeCelerraCell(contentStream, cdi.getMpfsiFileSystemsQuantity(), dataRow,
                                    dataCellStart, false, cellWidth);
                        }
                        dataRow = writeCelerraCell(contentStream, cdi.getFileServersNumber(), dataRow,
                                dataCellStart, false, cellWidth);
                        dataRow = writeCelerraCell(contentStream, cdi.getFileSystemsNumber(), dataRow,
                                dataCellStart, false, cellWidth);
                        dataRow = writeCelerraCell(contentStream, cdi.getCifsFileServersNumber(), dataRow,
                                dataCellStart, false, cellWidth);
                        dataRow = writeCelerraCell(contentStream, cdi.getCifsFileSharesNumber(), dataRow,
                                dataCellStart, false, cellWidth);
                        dataRow = writeCelerraCell(contentStream, cdi.getNfsFileSystemsConfNumber(), dataRow,
                                dataCellStart, false, cellWidth);
                        dataRow = writeCelerraCell(contentStream, cdi.getNfsFileSystemsExportNumber(), dataRow,
                                dataCellStart, false, cellWidth);
                    }
                    row += (dataRow - row);
                } else {
                    row = writeFont(contentStream, "VNX Protocol has not been set. ", ++row, 0, true);
                }
            } else {
                row = writeFont(contentStream, "VNX Protocol has not been set. ", ++row, 0, true);
            }
            row = writeFont(contentStream, "Include Unified File Home Directories?", ++row, 0, false);
            row = writeFont(contentStream, bool2String(unifiedRequestData.getIncludeUnifiedHomeDirs()), row,
                    answerStart, false);
            row = writeFont(contentStream, "Include unified Virtual Data Movers?", ++row, 0, false);
            row = writeFont(contentStream, bool2String(unifiedRequestData.getIncludeUnifiedVirtualDM()), row,
                    answerStart, false);
        }

        return row;
    }

    /**
     * Write the Nas Migration Information.
     *
     * @param contentStream
     *            the content stream
     * @param unifiedRequestData
     *            the unified request data
     * @param row
     *            the row number
     * @param answerStart
     *            the answer start position
     * @return the updated row number
     * @throws IOException
     *             if any I/O error occurs
     */
    private int writeNasMigrationInformation(PDPageContentStream contentStream,
            UnifiedRequestData unifiedRequestData, int row, float answerStart) throws IOException {
        if (unifiedRequestData.getServicesScope().isFileNasMigration()) {
            List<NasMigrationInformation> nmis = unifiedRequestData.getNasMigrationInformation();
            if (nmis != null && nmis.size() > 0) {
                row++;
                row = writeFont(contentStream, "NAS Migration", ++row, 0, true);
                row = writeFont(contentStream, "# hours of knowledge transfer", ++row, 0, false);
                row = writeFont(contentStream, unifiedRequestData.getNasMigrationKnowledgeTransferHours(), row,
                        answerStart, false);
                row = writeFont(contentStream, "In Scope Data Repositories:", ++row, 0, true);

                float datacell = 220f;
                float cellWidth = 60f;

                int dataRow = row + 1;
                for (int i = 0; i < nmis.size(); i++) {
                    row = writeFont(contentStream, "File " + (i + 1), row, datacell + cellWidth * (i + 1), true);
                }

                writeFont(contentStream, "Source or Target File Array", dataRow++, 0, false);
                writeFont(contentStream, "Location (City, State)", dataRow++, 0, false);
                writeFont(contentStream, "Target File Array - per source type", dataRow++, 0, false);
                writeFont(contentStream, "What is the average file size? - per source", dataRow++, 0, false);
                writeFont(contentStream, "Amount of CIFS data to be migrated (TBs)", dataRow++, 0, false);
                writeFont(contentStream, "# of CIFS file systems to be migrated", dataRow++, 0, false);
                writeFont(contentStream, "Local groups used within CIFS Filesystems? - per source", dataRow++, 0,
                    false);
                writeFont(contentStream, "Amount of NFS data to be migrated (TBs)", dataRow++, 0, false);
                writeFont(contentStream, "# of NFS file systems to be migrated", dataRow++, 0, false);
                writeFont(contentStream, "Amount of Bimodal (CIFS and NFS) data to be migrated (TBs)", dataRow++, 0,
                    false);
                writeFont(contentStream, "# of Bimodal (CIFS and NFS) file systems to be migrated", dataRow++, 0,
                    false);
                writeFont(contentStream, "Do you require a backend Certified Data Erasure after migration?",
                        dataRow++, 0, false);
                writeFont(contentStream, "Migration window length (hours)", dataRow++, 0, false);
                writeFont(contentStream, "# of migration windows customer expects", dataRow++, 0, false);
                writeFont(contentStream, "Migration Method", dataRow++, 0, false);

                for (int i = 0; i < nmis.size(); i++) {
                    dataRow = row + 1;
                    NasMigrationInformation nmi = nmis.get(i);
                    float dataCellStart = datacell + cellWidth * (i + 1);
                    dataRow = writeCelerraCell(contentStream, nmi.getCelerraVnxModel(), dataRow, dataCellStart,
                            false, cellWidth);
                    dataRow = writeCelerraCell(contentStream, nmi.getLocation(), dataRow, dataCellStart, false,
                            cellWidth);
                    dataRow = writeCelerraCell(contentStream, nmi.getTargetCelerra(), dataRow, dataCellStart,
                            false, cellWidth);
                    dataRow = writeCelerraCell(contentStream, nmi.getAverageFileSize(), dataRow, dataCellStart,
                            false, cellWidth);
                    dataRow = writeCelerraCell(contentStream, nmi.getCifsDataSize(), dataRow, dataCellStart,
                            false, cellWidth);
                    dataRow = writeCelerraCell(contentStream, nmi.getCifsFilesystemNumber(), dataRow,
                            dataCellStart, false, cellWidth);
                    dataRow = writeCelerraCell(contentStream, nmi.getCifsLocalGroupOption(), dataRow,
                            dataCellStart, false, cellWidth);
                    dataRow = writeCelerraCell(contentStream, nmi.getNfsDataSizeNumber(), dataRow, dataCellStart,
                            false, cellWidth);
                    dataRow = writeCelerraCell(contentStream, nmi.getNfsFilesystemNumber(), dataRow,
                            dataCellStart, false, cellWidth);
                    dataRow = writeCelerraCell(contentStream, nmi.getBimodalDataSizeNumber(), dataRow,
                            dataCellStart, false, cellWidth);
                    dataRow = writeCelerraCell(contentStream, nmi.getBimodalFilesystemNumber(), dataRow,
                            dataCellStart, false, cellWidth);
                    dataRow = writeCelerraCell(contentStream, nmi.getCertifiedDataMigrationOption(), dataRow,
                            dataCellStart, false, cellWidth);
                    dataRow = writeCelerraCell(contentStream, nmi.getMigrationWindowLength(), dataRow,
                            dataCellStart, false, cellWidth);
                    dataRow = writeCelerraCell(contentStream, nmi.getMigrationWindowsCustomerNumber(), dataRow,
                            dataCellStart, false, cellWidth);
                    dataRow = writeCelerraCell(contentStream, lookupEntity2String(nmi.getMigrationMethod()), dataRow,
                        dataCellStart, false, cellWidth);
                }
                row += (dataRow - row);
            }
        }
        return row;
    }

    /**
     * Write the IP Replication Information.
     *
     * @param contentStream
     *            the content stream
     * @param bcRequestData
     *            the bc request data
     * @param unifiedRequestData
     *            the unified request data
     * @param infrastuctureRequestData
     *            the infrastucture request data
     * @param row
     *            the row number
     * @param answerStart
     *            the answer start position
     * @return the updated row number
     * @throws IOException
     *             if any I/O error occurs
     */
    private int writeNasIpReplicationInformation(PDPageContentStream contentStream, BcRequestData bcRequestData,
            UnifiedRequestData unifiedRequestData, InfrastructureRequestData infrastuctureRequestData, int row,
            float answerStart) throws IOException {
        if (unifiedRequestData != null && unifiedRequestData.getServicesScope().isNasIpReplication()) {
            row++;
            row = writeFont(contentStream, "IP Replication", ++row, 0, true);

            VnxClariionInformation vci = infrastuctureRequestData.getVnxClariionInformation();
            if (vci != null && vci.getVnxInstallProtocolType() != null
                    && infrastuctureRequestData.isVnxClariionServiceEnabled()) {

                VnxInstallProtocolType vnxInstallProtocolType = vci.getVnxInstallProtocolType();
                boolean vnxFileStandardComplex = vnxInstallProtocolType != null
                        && ("File Only (CIFS/NFS)".equals(vnxInstallProtocolType.getName()));

                if (vnxFileStandardComplex) {
                    row = writeFont(contentStream, "# hours of knowledge transfer", ++row, 0, false);
                    row = writeFont(contentStream, bcRequestData.getNasIpReplicationKnowledgeTransferHours(), row,
                            answerStart, false);
                    List<NasIpReplicationInformation> niris = bcRequestData.getNasIpReplicationInformation();
                    if (niris != null && niris.size() > 0) {
                        row = writeFont(contentStream, "In Scope Data Repositories:", ++row, 0, true);

                        float datacell = 220f;
                        float cellWidth = 60f;

                        int dataRow = row + 1;
                        for (int i = 0; i < niris.size(); i++) {
                            row = writeFont(contentStream, "Celerra " + (i + 1), row, datacell + cellWidth
                                    * (i + 1), true);
                        }
                        writeFont(contentStream, "Source / Target", dataRow++, 0, false);
                        writeFont(contentStream, "# of Filesystems to be newly replicated from Source", dataRow++,
                                0, false);
                        writeFont(contentStream, "Amount of data to be newly replicated from Source (TB)",
                                dataRow++, 0, false);
                        writeFont(contentStream, "Which VNX Array?", dataRow++, 0, false);
                        writeFont(contentStream, "Include Local Replication?", dataRow++, 0, false);
                        writeFont(contentStream, "Include Remote Replication?", dataRow++, 0, false);
                        writeFont(contentStream, "# of CIFS file systems", dataRow++, 0, false);
                        writeFont(contentStream, "TB of CIFS Filesystems", dataRow++, 0, false);
                        writeFont(contentStream, "# of NFS file systems", dataRow++, 0, false);
                        writeFont(contentStream, "TB of NFS file systems", dataRow++, 0, false);
                        for (int i = 0; i < niris.size(); i++) {
                            dataRow = row + 1;
                            NasIpReplicationInformation niri = niris.get(i);
                            float dataCellStart = datacell + cellWidth * (i + 1);
                            dataRow = writeCelerraCell(contentStream, niri.getCelerraDeviceType(), dataRow,
                                    dataCellStart, false, cellWidth);
                            dataRow = writeCelerraCell(contentStream, niri.getNewFileSystemReplicationNumber(),
                                    dataRow, dataCellStart, false, cellWidth);
                            dataRow = writeCelerraCell(contentStream, niri.getReplicatedDataSize(), dataRow,
                                    dataCellStart, false, cellWidth);
                            dataRow = writeCelerraCell(contentStream, niri.getVnxArray(), dataRow, dataCellStart,
                                    false, cellWidth);
                            dataRow = writeCelerraCell(contentStream, niri.getIncludeLocalReplication(), dataRow,
                                    dataCellStart, false, cellWidth);
                            dataRow = writeCelerraCell(contentStream, niri.getIncludeRemoteReplication(), dataRow,
                                    dataCellStart, false, cellWidth);
                            dataRow = writeCelerraCell(contentStream, niri.getNrOfCifsFileSystems(), dataRow,
                                    dataCellStart, false, cellWidth);
                            dataRow = writeCelerraCell(contentStream, niri.getTbOfCifsFileSystems(), dataRow,
                                    dataCellStart, false, cellWidth);
                            dataRow = writeCelerraCell(contentStream, niri.getNrOfNfsFileSystems(), dataRow,
                                    dataCellStart, false, cellWidth);
                            dataRow = writeCelerraCell(contentStream, niri.getTbOfNfsFileSystems(), dataRow,
                                    dataCellStart, false, cellWidth);
                        }
                        row += (dataRow - row);
                    }
                } else {
                    row = writeFont(contentStream, "Nothing to show with the VNX Protocol.", ++row, 0, true);
                }
            } else {
                row = writeFont(contentStream, "VNX Protocol has not been set.", ++row, 0, true);
            }
        }
        return row;
    }

    /**
     * Get unifiedRequestData Options.
     *
     * @param unifiedRequestData
     *            the unifiedRequestData
     * @return the options list.
     */
    private List<String> getUnifiedRequestDataOptions(UnifiedRequestData unifiedRequestData) {
        List<String> options = new ArrayList<String>();
        UnifiedServicesScope scope = unifiedRequestData.getServicesScope();
        if (scope != null) {
            if (scope.isCelerraImplementation()) {
                options.add("VNX File Implementation");
            }
            if (scope.isNasHealthCheck()) {
                options.add("NAS Health Check");
            }
            if (scope.isFileNasMigration()) {
                options.add("File (NAS) Migration");
            }
            if (scope.isMpfs()) {
                options.add("MPFS / MPFSi");
            }
            if (scope.isNasIpReplication()) {
                options.add("IP Replication");
            }
        }
        return options;
    }

    /**
     * Get Unified Nas Features.
     *
     * @param nasFeature
     *            the nas feature object
     * @return the options list.
     */
    private String getUnifiedNasFeatures(NasFeature nasFeature) {
        StringBuilder sb = new StringBuilder();
        if (nasFeature != null) {
            if (nasFeature.isAdvancedFileSystemFeatures()) {
                sb.append(" - Advanced File System Features (FLR, DFS, Nested Mounts)");
            }
            if (nasFeature.isAdvancedNetworkingFeatures()) {
                sb.append(" - Advanced Networking Features (FSN, Etherchannel, LACP)");
            }
            if (nasFeature.isAdvancedStorageFeatures()) {
                sb.append(" - Advanced Storage Features (User Pools, Shelf-by-Shelf, Application Specific)");
            }
            if (nasFeature.isBackup()) {
                sb.append(" - Backup");
            }
            if (nasFeature.isVee()) {
                sb.append(" - VEE");
            }
            if (nasFeature.isVnxFileMover()) {
                sb.append(" - VNX FileMover");
            }
            if (nasFeature.isFtp()) {
                sb.append(" - FTP");
            }
            if (nasFeature.isVnxDataDeduplication()) {
                sb.append(" - VNX Data Reduplication");
            }
            if (nasFeature.isIscsi()) {
                sb.append(" - iSCSI");
            }
            if (nasFeature.isVnxMpfs()) {
                sb.append(" - VNX MPFS");
            }
            if (nasFeature.isVnxQuotas()) {
                sb.append(" - VNX Quotas");
            }
            if (nasFeature.isVnxReplicator()) {
                sb.append(" - VNX Replicator");
            }
            if (nasFeature.isVnxIscsiReplicator()) {
                sb.append(" - VNX Replicator for iSCSI");
            }
            if (nasFeature.isVnxAdministrativeSecurity()) {
                sb.append(" - VNX Administrative Security");
            }
            if (nasFeature.isVnxSnapSure()) {
                sb.append(" - VNX Sanapsure");
            }
        }
        return sb.toString();
    }

    /**
     * Write the Celerra Table.
     *
     * @param contentStream
     *            the content stream
     * @param value
     *            the object to export/write
     * @param row
     *            the start row number
     * @param datacell
     *            the data cell start position
     * @param newOrExisting
     *            whether the boolean value represents "New"/"Existing"
     * @param cellWidth
     *            the cell width
     * @return the new row number
     * @throws IOException
     *             if any I/O error occurs
     */
    @SuppressWarnings("unchecked")
    private int writeCelerraCell(PDPageContentStream contentStream, Object value, int row, float datacell,
            boolean newOrExisting, float cellWidth) throws IOException {
        if (value != null) {
            if (value instanceof Boolean) {
                if (newOrExisting) {
                    row = writeFont(contentStream, bool2StringNewOrExisting((Boolean) value), row, datacell, false);
                } else {
                    row = writeFont(contentStream, bool2String((Boolean) value), row, datacell, false);
                }
            } else if (value instanceof Integer) {
                row = writeFont(contentStream, int2String((Integer) value), row, datacell, false);
            } else if (value instanceof LookupEntity) {
                row = writeFont(contentStream, ((LookupEntity) value).getName(), row, datacell, false);
            } else if (value instanceof List) {
                writeOptions(contentStream, (List<String>) value, row, datacell, 5, 100f);
            } else {
                row = writeFont(contentStream, String.valueOf(value), row, datacell, false, cellWidth);
            }
        }
        row++;
        return row;
    }

    /**
     * Get Infrastructure EnvironmentDetailsInformation Host contents.
     *
     * @param environmentDetailsInformation
     *            The Infrastructure EnvironmentDetailsInformation request data
     * @return the contents
     */
    private String[][] getInfraEnvironmentDetailsHostInfoContents(
            EnvironmentDetailsInformation environmentDetailsInformation) {
        List<EnvironmentDetailsHostInfo> hostInfo = environmentDetailsInformation.getHostInformation();

        List<String[]> rows = new ArrayList<String[]>();
        int totalNumberOfHostNumber = 0;
        int totalNumberOfNewHosts = 0;
        int totalNumberOfClusters = 0;
        int totalNumberBootFromSan = 0;
        for (EnvironmentDetailsHostInfo host : hostInfo) {
            String[] columns = new String[6];
            columns[0] = host.getPlatform();

            Integer numberOfExistingHosts = host.getHostNumber();
            columns[1] = int2String(numberOfExistingHosts);
            totalNumberOfHostNumber += numberOfExistingHosts == null ? 0 : numberOfExistingHosts;

            Integer numberOfNewHosts = host.getNewHostNumber();
            columns[2] = int2String(numberOfNewHosts);
            totalNumberOfNewHosts += numberOfNewHosts == null ? 0 : numberOfNewHosts;

            Integer numberOfClusters = host.getNumberOfClusters();
            columns[3] = int2String(numberOfClusters);
            totalNumberOfClusters += numberOfClusters == null ? 0 : numberOfClusters;

            Integer numberBootFromSan = host.getNumberBootFromSan();
            columns[4] = int2String(numberBootFromSan);
            totalNumberBootFromSan += numberBootFromSan == null ? 0 : numberBootFromSan;

            columns[5] = host.getArrayHostAttachedTo();

            rows.add(columns);
        }
        String[][] contents = new String[rows.size() + 2][3];
        contents[0] = new String[] {
            "Platform", "# of Existing Hosts", "# of New Hosts", "# of Clusters", "# Boot from SAN",
            "Array Host is Attached To"
        };
        for (int i = 0; i < rows.size(); i++) {
            contents[i + 1] = rows.get(i);
        }
        contents[contents.length - 1] = new String[] {
            "Totals", int2String(totalNumberOfHostNumber), int2String(totalNumberOfNewHosts),
            int2String(totalNumberOfClusters), int2String(totalNumberBootFromSan), ""
        };
        return contents;
    }

    /**
     * Write InfrastructureRequestData.
     *
     * @param contentStream
     *            the stream
     * @param infrastructureRequestData
     *            the infrastuctureRequestData
     * @param row
     *            The current row
     * @param page
     *            The current page
     * @return the row number
     * @throws IOException
     *             if any IO error occurs
     */
    private int writeInfrastructureRequestData(PDPageContentStream contentStream,
            InfrastructureRequestData infrastructureRequestData, int row, PDPage page) throws IOException {
        row = writeFont(contentStream, "Services & Activities - Core", ++row, 0, true);
        row = writeFont(contentStream, "General Information", ++row, 0, true);
        row = writeAnswer(contentStream, row, PROJECT_COL_WIDTH,
                "# hours of knowledge transfer", getTotalHoursOfKnOwrowledgeTransferInf(infrastructureRequestData));
        row = writeAnswer(contentStream, row, PROJECT_COL_WIDTH,
                "General Comment", trimToEmpty(infrastructureRequestData.getGeneralComment()));
        row++;
        row = writeFont(contentStream, "Core Services", ++row, 0, true);
        List<String> options = getInfrastructureRequestDataOptions(infrastructureRequestData);
        row++;
        row = writeOptions(contentStream, options, row, 0, 5, 100f);

        row++;
        row = writeFont(contentStream, "Current Environment", ++row, 0, true);
        float answerStart = 280f;
        EnvironmentDetailsInformation edi = infrastructureRequestData.getEnvironmentDetailsInformation();
        row = writeFont(contentStream, "Who will be gathering current environment information?", ++row, 0, false);
        EnvironmentGatherer environmentGatherer = edi.getEnvironmentGatherer();
        if (environmentGatherer != null) {
            String environmentGathererName = environmentGatherer.getName();
            row = writeFont(contentStream, environmentGathererName, row, answerStart, false);
            if ("ECA".equals(environmentGathererName)) {
                row = writeFont(contentStream, "# of ECA appliances to install and use to collect host data:",
                        ++row, 0, false);
                row = writeFont(contentStream, int2String(edi.getDcaAppliancesNumber1()), row, answerStart, false);
            }
        }
        row = writeFont(contentStream, "Who installs host software?", ++row, 0, false);
        row = writeFont(contentStream, edi.getHostSoftwareInstaller().getName(), row, answerStart, false);
        row = writeFont(contentStream, "Who performs standard SAN implementation tasks?", ++row, 0, false);
        row = writeFont(contentStream, edi.getSanImplementator().getName(), row, answerStart, false);

        float cell2 = 120f;
        float cell3 = 240f;
        float cell4 = 360f;

        row = writeFont(contentStream, "Current Storage Array Information (In Scope Components Only)", ++row, 0,
                true);
        row = writeFont(contentStream, "Existing Array Type", ++row, 0, true);
        row = writeFont(contentStream, "Location", row, cell2, true);
        row = writeFont(contentStream, "Usable Capacity (TB)", row, cell3, true);
        row = writeFont(contentStream, "# of Attached Hosts", row, cell4, true);

        row++;
        for (int i = 0; i < edi.getExistingArrayTypes().size() && i < edi.getExistingStorageLocations().size()
                && i < edi.getUsableCapacities().size() && i < edi.getNumberOfAttachedHosts().size(); i++) {
            int currentRow = row;
            row = Math.max(row,
                    writeFont(contentStream, edi.getExistingArrayTypes().get(i).getName(), currentRow, 0, false));
            row = Math.max(
                    row,
                    writeFont(contentStream, edi.getExistingStorageLocations().get(i), currentRow, cell2, false,
                            115));
            row = Math.max(
                    row,
                    writeFont(contentStream, double2String(edi.getUsableCapacities().get(i)), currentRow, cell3,
                            false));
            row = Math.max(
                    row,
                    writeFont(contentStream, int2String(edi.getNumberOfAttachedHosts().get(i)), currentRow, cell4,
                            false));
            row++;
        }

        row = writeFont(contentStream, "Current SAN Information (In Scope Components Only)", ++row, 0, true);
        row = writeFont(contentStream, "Device Type", ++row, 0, true);
        row = writeFont(contentStream, "Manufacturer", row, cell2, true);
        row = writeFont(contentStream, "Location", row, cell3, true);
        row = writeFont(contentStream, "Device Quantity", row, cell4, true);

        row++;
        for (int i = 0; i < edi.getEnvironmentDeviceTypes().size() && i < edi.getExistingSanLocations().size()
                && i < edi.getDeviceQuantities().size(); i++) {
            int currentRow = row;
            row = Math.max(
                    row,
                    writeFont(contentStream, edi.getEnvironmentDeviceTypes().get(i).getName(), currentRow, 0,
                            false));
            row = Math.max(row,
                    writeFont(contentStream, edi.getManufacturers().get(i), currentRow, cell2, false, 115));
            row = Math.max(row,
                    writeFont(contentStream, edi.getExistingSanLocations().get(i), currentRow, cell3, false, 115));
            row = Math.max(
                    row,
                    writeFont(contentStream, double2String(edi.getDeviceQuantities().get(i)), currentRow, cell4,
                            false));
            row++;
        }

        row = writeFont(contentStream, "Host Information (In Scope Components Only)", ++row, 0, true);
        row++;
        String[][] contents = getInfraEnvironmentDetailsHostInfoContents(edi);
        row += drawTable(page, contentStream, getYPos(row), 30, contents, true, null);

        row = writeFont(contentStream, "# of existing SAN fabrics", ++row, 0, false);
        row = writeFont(contentStream, int2String(edi.getExistingSanFabricsNumber()), row, answerStart, false);

        if (infrastructureRequestData.getSymmetrixMFServiceEnabled()) {
            row++;
            row = writeSymmetrixData(contentStream, infrastructureRequestData.getSymmetrixMF(), true, "SymmetrixMF",
                row);
        }

        if (infrastructureRequestData.getSymmetrixOSServiceEnabled()) {
            row++;
            row = writeSymmetrixData(contentStream, infrastructureRequestData.getSymmetrixOS(), true, "SymmetrixOS",
                row);
        }

        if (infrastructureRequestData.isDataMigrationServiceEnabled()) {
            row++;
            row = writeDataMigrationData(contentStream, infrastructureRequestData, row, page);
        }

        if (infrastructureRequestData.isVnxClariionServiceEnabled()
                || infrastructureRequestData.isCxReplicationServiceEnabled()) {
            row++;
            row = writeVnxClariionData(contentStream, infrastructureRequestData, row);
        }

        if (infrastructureRequestData.getVplexServiceEnabled()) {
            row = writeVplex(contentStream, infrastructureRequestData.getVplex(), row, 300f);
        }


        return row;
    }

    /**
     * Write the VNX/Clariion information.
     *
     * @param contentStream
     *            The content stream
     * @param infrastructureRequestData
     *            The infrastructure request data
     * @param row
     *            Current row
     * @return the last row written
     * @throws IOException
     *             When an error occurs while writing into stream
     */
    private int writeSymmetrixData(PDPageContentStream contentStream, SymmetrixInformationBase si, boolean isSym, 
                                   String title, int row)
        throws IOException {
        float answerStart = 300f;
        row = writeFont(contentStream, title, ++row, 0, true);
        if (isSym) {
            row = writeFont(contentStream, "# hours of knowledge transfer", ++row, 0, false);
            row = writeFont(contentStream, si.getKnowledgeTransferHours(), row, answerStart, false);
            row = writeFont(contentStream, "# of new Open Systems VMAX arrays to be installed", ++row, 0, false);
            row = writeFont(contentStream, int2String(si.getVmaxArraysNumber()), row, answerStart, false);
            row = writeFont(contentStream, "# of new Open Systems DMX arrays to be installed", ++row, 0, false);
            row = writeFont(contentStream, int2String(si.getDmxArraysNumber()), row, answerStart, false);
            row = writeFont(contentStream, "# of existing Open Systems VMAX arrays to be upgraded", ++row, 0,
                    false);
            row = writeFont(contentStream, int2String(si.getVmaxArraysUpgradeNumber()), row, answerStart, false);
            row = writeFont(contentStream, "# of existing Open Systems DMX arrays to be upgraded", ++row, 0, false);
            row = writeFont(contentStream, int2String(si.getDmxArraysUpgradeNumber()), row, answerStart, false);
        }
        row = writeFont(contentStream, "# of source and target arrays to configure SRDF", ++row, 0, false);
        row = writeFont(contentStream, int2String(si.getSrdfArraysNumber()), row, answerStart, false);
        row = writeFont(contentStream, "# of source and target arrays to configure SRDF/A", ++row, 0, false);
        row = writeFont(contentStream, int2String(si.getSrdfAArraysNumber()), row, answerStart, false);
        if (isSym) {
            row = writeFont(contentStream, "# of arrays to implement Virtual Provisioning", ++row, 0, false);
            row = writeFont(contentStream, int2String(si.getVirtualProvisioningArraysNumber()), row, answerStart,
                    false);
            row = writeFont(contentStream, "# of hosts to use thin devices for first time, across multiple tiers",
                    ++row, 0, false);
            row = writeFont(contentStream, int2String(si.getThinDevicesHostNumber()), row, answerStart, false);
            row = writeFont(contentStream, "# of hosts requiring mapping/LUN masking to DMX", ++row, 0, false);
            row = writeFont(contentStream, int2String(si.getLunToDmxHostNumber()), row, answerStart, false);
            row = writeFont(contentStream, "# of hosts requiring AutoProvisioning to VMAX", ++row, 0, false);
            row = writeFont(contentStream, int2String(si.getAutoProvisioingToDmxHostNumber()), row, answerStart,
                    false);
            row = writeFont(contentStream, "# of Arrays to Implement FAST", ++row, 0, false);
            row = writeFont(contentStream, int2String(si.getAdvancedFastArraysNumber()), row, answerStart, false);
            row = writeFont(contentStream, "# of Open Systems VMAX arrays to be de-installed", ++row, 0, false);
            row = writeFont(contentStream, int2String(si.getDeinstallOpenSystemsVmaxNumber()), row, answerStart,
                    false);
            row = writeFont(contentStream, "# of VMAXe, VMAX, VMAX 20K, or VMAX 40K Arrays?", ++row, 0, false);
            row = writeFont(contentStream, int2String(si.getVmaxArraysNum()), row, answerStart, false);
            row = writeFont(contentStream, "# of Symmetrix VMAX FAST Storage Groups?", ++row, 0, false);
            row = writeFont(contentStream, int2String(si.getVmaxGroupsNum()), row, answerStart, false);
            row = writeFont(contentStream,
                    "# of Symmetrix VMAX FAST Disk Technology and Capacity/Speed Combinations?", ++row, 0, false);
            row = writeFont(contentStream, int2String(si.getVmaxCombinationsNum()), row, answerStart, false);
            row = writeFont(contentStream, "# of Symmetrix VMAX FAST Tiers?", ++row, 0, false);
            row = writeFont(contentStream, int2String(si.getVmaxTiersNum()), row, answerStart, false);
            row = writeFont(contentStream, "# of Symmetrix VMAX FAST Policies?", ++row, 0, false);
            row = writeFont(contentStream, int2String(si.getVmaxPoliciesNum()), row, answerStart, false);
            row = writeFont(contentStream, "# of Symmetrix VMAX FAST Performance Windows?", ++row, 0, false);
            row = writeFont(contentStream, int2String(si.getVmaxPerformanceWindowsNum()), row, answerStart, false);
            row = writeFont(contentStream, "# of Symmetrix VMAX FAST Data Movement Windows?", ++row, 0, false);
            row = writeFont(contentStream, int2String(si.getVmaxDMWindowsNum()), row, answerStart, false);
            row = writeFont(contentStream,
                    "# of Additional Hours for Creating VP or VP FAST Customer Developed Tests?", ++row, 0, false);
            row = writeFont(contentStream, int2String(si.getVmaxAdditionalHoursCreateDevTestsNum()), row,
                    answerStart, false);
            row = writeFont(contentStream,
                    "# of Additional Hours for Executing VP or VP FAST Customer Developed Tests?", ++row, 0, false);
            row = writeFont(contentStream, int2String(si.getVmaxAdditionalHoursExecuteDevTestsNum()), row,
                    answerStart, false);
            row = writeFont(contentStream, "# of VP Storage Groups?", ++row, 0, false);
            row = writeFont(contentStream, int2String(si.getVpStorageGroupsNum()), row, answerStart, false);
            row = writeFont(contentStream, "# of VP Disk Technology and RAID Protection Combinations?", ++row, 0,
                    false);
            row = writeFont(contentStream, int2String(si.getVpDiskCombinationsNum()), row, answerStart, false);
            row = writeFont(contentStream, "# of VP Thin Devices (TDEVs)?", ++row, 0, false);
            row = writeFont(contentStream, int2String(si.getTdevNum()), row, answerStart, false);
            row = writeFont(contentStream, "# of VP Data Devices (TDATs)?", ++row, 0, false);
            row = writeFont(contentStream, int2String(si.getTdatNum()), row, answerStart, false);
            row = writeFont(contentStream, "# of VP Thin Pools?", ++row, 0, false);
            row = writeFont(contentStream, int2String(si.getVpThinPoolsNum()), row, answerStart, false);
            row = writeFont(contentStream, "# of FAST VP Performance Time Windows?", ++row, 0, false);
            row = writeFont(contentStream, int2String(si.getFastVpPerformanceTimeWindowsNum()), row, answerStart,
                    false);
            row = writeFont(contentStream, "# of FAST VP Move Time Windows?", ++row, 0, false);
            row = writeFont(contentStream, int2String(si.getFastVpMoveTimeWindowsNum()), row, answerStart, false);
            row = writeFont(contentStream, "# of FAST VP Tiers?", ++row, 0, false);
            row = writeFont(contentStream, int2String(si.getFastVpTiersNum()), row, answerStart, false);
            row = writeFont(contentStream, "# of FAST VP Policies?", ++row, 0, false);
            row = writeFont(contentStream, int2String(si.getFastVpPoliciesNum()), row, answerStart, false);
            row = writeFont(contentStream, "Is this engagement adding FAST VP to an installed VP Environment?",
                    ++row, 0, false);
            row = writeFont(contentStream, bool2String(si.getEngagementAddingFastVP()), row, answerStart, false);
        }

        return row;
    }

    /**
     * Write the Data Migration information.
     *
     * @param contentStream
     *            The content stream
     * @param infrastructureRequestData
     *            The infrastructure request data
     * @param row
     *            Current row
     * @param page
     *            The current page
     * @return the last row written
     * @throws IOException
     *             When an error occurs while writing into stream
     */
    private int writeDataMigrationData(PDPageContentStream contentStream,
            InfrastructureRequestData infrastructureRequestData, int row, PDPage page) throws IOException {
        float answerStart = 290f;
        DataMigrationInformation di = infrastructureRequestData.getDataMigrationInformation();
        if (di == null) { // prevent null, use default
            di = new DataMigrationInformation();
        }
        row = writeFont(contentStream, "Block Data Migration", ++row, 0, true);

        row = writeFont(contentStream, "# hours of knowledge transfer", ++row, 0, false);
        row = writeFont(contentStream, di.getKnowledgeTransferHours(), row, answerStart, false);

        // table
        row += 1;
        row = writeFont(contentStream, "Migration Information", ++row, 0, false);
        row += 1;
        String[][] contents = getHostMigrationInformationContents(infrastructureRequestData);
        int tableRows = drawTable(page, contentStream, getYPos(row), 30, contents, true, null);
        row += tableRows;

        row = writeFont(contentStream, "Who does hands-on Host Migration Work?", ++row, 0, false);
        row = writeFont(contentStream, di.getMigrationWorker() != null ? trimToEmpty(di.getMigrationWorker()
                .getName()) : "", row, answerStart, false);
        row = writeFont(contentStream, "Migrate from Thick to Thin Luns on Symmetrix?", ++row, 0, false);
        row = writeFont(contentStream, bool2String(di.isMigrateLunsToSymmetrixOption()), row, answerStart, false);
        row = writeFont(contentStream, "Migrate from Thick to Thin Luns on VNX Block?", ++row, 0, false);
        row = writeFont(contentStream, bool2String(di.isMigrateLunsToClariionOption()), row, answerStart, false);
        row = writeFont(contentStream, "Will volume sizes change on Symmetrix target?", ++row, 0, false);
        row = writeFont(contentStream, trimToEmpty(di.getSymmetrixVolumeSizeChange() != null ? di
                .getSymmetrixVolumeSizeChange().getName() : ""), row, answerStart, false);
        row = writeFont(contentStream, "Will volume sizes change on VNX Block target?", ++row, 0, false);
        row = writeFont(contentStream, trimToEmpty(di.getClariionVolumeSizeChange() != null ? di
                .getClariionVolumeSizeChange().getName() : ""), row, answerStart, false);
        row = writeFont(contentStream, "What level of migration involvement will EMC have?", ++row, 0, false);
        row = writeFont(contentStream, trimToEmpty(di.getEmcMigrationInvolvement() != null ? di
                .getEmcMigrationInvolvement().getName() : ""), row, answerStart, false);
        row = writeFont(contentStream, "How long are the weekend maintenance windows? (hours)", ++row, 0, false);
        row = writeFont(contentStream, int2String(di.getWeekendMaintenanceHours()), row, answerStart, false);
        row = writeFont(contentStream, "# of weekends per month that migrations can occur?", ++row, 0, false);
        row = writeFont(contentStream, int2String(di.getWeekendMigrationsNumber()), row, answerStart, false);
        row = writeFont(contentStream, "# of migration tests to execute per host prior to cutover", ++row, 0,
                false);
        row = writeFont(contentStream, int2String(di.getMigrationCutoverTestsNumber()), row, answerStart, false);
        row = writeFont(contentStream, "# of migration cutover events (use *0* for practice to determine)", ++row,
                0, false);
        row = writeFont(contentStream, int2String(di.getMigrationCutoverEventsNumber()), row, answerStart, false);
        row = writeFont(contentStream, "Will existing replication scripts need to be adjusted?", ++row, 0, false);
        row = writeFont(contentStream, bool2String(di.isScriptAdjustmentOption()), row, answerStart, false);
        row = writeFont(contentStream, "# of hosts/clusters to test prior to migration cutover", ++row, 0, false);
        row = writeFont(contentStream, int2String(di.getMigrationCutoverHostsNumber()), row, answerStart, false);

        OpenReplicator openReplicator = infrastructureRequestData.getOpenReplicator();
        if (openReplicator != null) {
            row = writeFont(contentStream, "Completion of PostSales qualifier", ++row, 0, false);
            PostSalesCompletionQualifier postSalesCompletionQualifier = openReplicator
                    .getPostSalesCompletionQualifier();
            if (postSalesCompletionQualifier != null) {
                row = writeFont(contentStream, postSalesCompletionQualifier.getName(), row, answerStart, false);
            }
        }

        row = writeFont(contentStream, "Include Environment Collection Appliance (ECA)?", ++row, 0, false);
        row = writeFont(contentStream, bool2String(di.getIncludeECA()), row, answerStart, false);
        row = writeFont(contentStream, "Include Data Erasure of Storage?", ++row, 0, false);
        row = writeFont(contentStream, bool2String(di.getIncludeStorageDataErasure()), row, answerStart, false);
        row = writeFont(contentStream, "Remove or relocate existing EMC storage?", ++row, 0, false);
        row = writeFont(contentStream, bool2String(di.getRemoveRelocateEMCStorage()), row, answerStart, false);
        row = writeFont(contentStream, "Proposed Migration Tool(s) (RecoverPoint, SRDF, LVM, Open Replicator, etc.)",
            ++row, 0, false);
        row = writeFont(contentStream, di.getProposedMigrationTools(), row, answerStart, false);

        return row;
    }

    /**
     * Get Migration Information contents.
     *
     * @param infrastructureRequestData
     *            The infrastructure request data
     * @return the contents
     */
    private String[][] getHostMigrationInformationContents(InfrastructureRequestData infrastructureRequestData) {
        DataMigrationInformation di = infrastructureRequestData.getDataMigrationInformation();
        int totalNumberOfNonEsxHosts = 0;
        int totalNumberOfEsxHosts = 0;
        int totalNumberOfVirtualMachines = 0;
        List<String[]> rows = new ArrayList<String[]>();
        if (di.getArrayInformation() != null) {
            for (DataMigrationInformationArray array : di.getArrayInformation()) {
                String[] columns = new String[8];
                columns[0] = array.getEnvironmentArrayType().getName();
                columns[1] = array.getLocation();
                columns[2] = int2String(array.getNumberOfNonEsxHosts());
                totalNumberOfNonEsxHosts += array.getNumberOfNonEsxHosts();
                columns[3] = int2String(array.getNumberOfEsxHosts());
                totalNumberOfEsxHosts += array.getNumberOfEsxHosts();
                columns[4] = int2String(array.getNumberOfVirtualMachines());
                totalNumberOfVirtualMachines += array.getNumberOfVirtualMachines();
                columns[5] = bool2String(array.isSwingBox());
                columns[6] = array.getArrayType();
                columns[7] = double2String(array.getCapacity());
                rows.add(columns);
            }
        }
        String[][] contents = new String[rows.size() + 2][8];
        contents[0] = new String[] {
            "Array", "Location", "# of Non-ESX Hosts", "# of ESX Hosts", "# of Virtual Machines",
            "Swing Box?", "Source/Target", "Used (Host) Capacity"
        };
        for (int i = 0; i < rows.size(); i++) {
            contents[i + 1] = rows.get(i);
        }
        contents[contents.length - 1] = new String[] {
            "Totals", "", int2String(totalNumberOfNonEsxHosts), int2String(totalNumberOfEsxHosts),
            int2String(totalNumberOfVirtualMachines), "", "", "", ""
        };
        return contents;
    }

    /**
     * Get Integer from Map.
     *
     * @param map
     *            The map of values.
     * @param key
     *            The key
     * @param total
     *            the totals
     * @param col
     *            the column
     * @return integer the mapped value
     */
    private Integer getIntegerFromMapAndUpdateTotal(Map<String, Integer> map, String key,
            Map<String, Integer> total, String col) {
        if (map == null) {
            return 0;
        }
        Integer i = map.get(key);
        if (i == null) {
            return 0;
        } else {
            if (total.get(col) == null) {
                total.put(col, i);
            } else {
                Integer current = total.get(col);
                total.put(col, current + i);
            }
            return i;
        }
    }

    /**
     * Write the VNX/Clariion information.
     *
     * @param contentStream
     *            The content stream
     * @param infrastructureRequestData
     *            The infrastructure request data
     * @param row
     *            Current row
     * @return the last row written
     * @throws IOException
     *             When an error occurs while writing into stream
     */
    private int writeVnxClariionData(PDPageContentStream contentStream,
            InfrastructureRequestData infrastructureRequestData, int row) throws IOException {
        float answerStart = 270f;
        VnxClariionInformation vci = infrastructureRequestData.getVnxClariionInformation();
        if (vci == null) { // prevent null, use defaults if null
            vci = new VnxClariionInformation();
        }
        boolean isVx = infrastructureRequestData.isVnxClariionServiceEnabled();
        boolean isCx = infrastructureRequestData.isCxReplicationServiceEnabled();

        row = writeFont(contentStream, "VNX Block", ++row, 0, true);
        row = writeFont(contentStream, "# hours of knowledge transfer", ++row, 0, false);
        row = writeFont(contentStream, vci.getKnowledgeTransferHours(), row, answerStart, false);
        if (isVx || isCx) {
            row = writeFont(contentStream, "# of new VNX arrays to be installed", ++row, 0, false);
            row = writeFont(contentStream, int2String(vci.getVnxArraysNumber()), row, answerStart, false);
            row = writeFont(contentStream, "Unified Conversions required? If so what kind?", ++row, 0, false);
            row = writeFont(
                    contentStream,
                        vci.getUnifiedConversionType() != null ?
                            bool2String(vci.isUnifiedConversionsRequired()) + " - "
                                + vci.getUnifiedConversionType().getName()
                            : bool2String(vci.isUnifiedConversionsRequired()), row, answerStart, false);

            if (vci.isIscsi()) {
                row = writeFont(contentStream, "iSCSI required? - per VNX File", ++row, 0, false);
                row = writeFont(contentStream, bool2String(vci.getiScsiRequired()), row, answerStart, false);
                row = writeFont(contentStream, "iSCSI Host Quantity", ++row, 0, false);
                row = writeFont(contentStream, int2String(vci.getiScsiHostQuantity()), row, answerStart, false);
                row = writeFont(contentStream, "iSCSI LUN Quantity (VNX Native) - Total to be presented", ++row,
                        0, false);
                row = writeFont(contentStream, int2String(vci.getiVnxScsiHostQuantity()), row, answerStart, false);
                row = writeFont(contentStream, "iSCSI LUN Quantity (via DART) - Total to be presented", ++row, 0,
                        false);
                row = writeFont(contentStream, int2String(vci.getiDartScsiHostQuantity()), row, answerStart, false);
            }
        }
        if (isVx) {
            row = writeFont(contentStream, "Health Check required?", ++row, 0, false);
            row = writeFont(contentStream, bool2String(vci.isHealthCheckRequired()), row, answerStart, false);
            row = writeFont(contentStream, "SAP HANA Required?", ++row, 0, false);
            row = writeFont(contentStream, bool2String(vci.isSapHanaRequired()), row, answerStart, false);
            row = writeFont(contentStream, "What kind of VNX Protocol Will Be Installed?", ++row, 0, false);
            row = writeFont(contentStream, trimToEmpty(vci.getVnxInstallProtocolType() != null ? vci
                    .getVnxInstallProtocolType().getName() : ""), row, answerStart, false);

            if (vci.getVnxInstallProtocolType() != null
                    && ("File Only (CIFS/NFS)".equals(vci.getVnxInstallProtocolType().getName()) || "BOTH"
                            .equals(vci.getVnxInstallProtocolType().getName()))) {
                row = writeFont(contentStream, "# of unified VNX file servers", ++row, 0, false);
                row = writeFont(contentStream, int2String(vci.getVnxFileServersNumber()), row, answerStart, false);
                row = writeFont(contentStream, "Total amount of storage allocated in TB", ++row, 0, false);
                row = writeFont(contentStream, double2String(vci.getTotalStorageAmount()), row, answerStart, false);
                row = writeFont(contentStream, "# of active data movers", ++row, 0, false);
                row = writeFont(contentStream, int2String(vci.getActiveDataMoversNumber()), row, answerStart,
                        false);
                row = writeFont(contentStream, "# of control stations", ++row, 0, false);
                row = writeFont(contentStream, int2String(vci.getControlStationsNumber()), row, answerStart, false);
                row = writeFont(contentStream, "# of files systems to be configured in the environment", ++row, 0,
                        false);
                row = writeFont(contentStream, int2String(vci.getFileSystemsNumber()), row, answerStart, false);
                row = writeFont(contentStream, "Average file system size", ++row, 0, false);
                row = writeFont(contentStream, trimToEmpty(vci.getAvgFileSystemSize()), row, answerStart, false);
            }
            row = writeFont(contentStream, "VNX Monitoring and Reporting?", ++row, 0, false);
            row = writeFont(contentStream, bool2String(vci.isVnxMonitoringReportingRequired()), row, answerStart,
                    false);
            row = writeFont(contentStream, "Storage Network connectivity options (one or more)?", ++row, 0, false);
            row = writeFont(contentStream, trimToEmpty(getVnxStorageNetworkConnectivityOptions(vci)), row,
                    answerStart, false);
        }
        if (isVx || isCx) {
            row = writeFont(contentStream, "Include Virtual Infrastructure Enablement - VSI Knowledge Transfer?",
                    ++row, 0, false);
        }
        if (isVx) {
            row = writeFont(contentStream, bool2String(vci.isVirtualInfrastructureEnablementIncluded()), row,
                    answerStart, false);
            row = writeFont(contentStream, "Include Watch4Net for VNX Monitoring and Reporting Software?", ++row,
                    0, false);
            row = writeFont(contentStream, bool2String(vci.isWatch4NetIncluded()), row, answerStart, false);
            row = writeFont(contentStream, "Add additional Software Bundles?", ++row, 0, false);
            row = writeOptions(contentStream, getAdditionalSoftwareBundles(vci), row, answerStart, 2, 145f);
            row = writeFont(contentStream, "Included Unifed Software Options?", ++row, 0, false);
            row = writeOptions(contentStream, getUnifiedSoftwareOptions(vci), row, answerStart, 2, 145f);
            row = writeFont(contentStream, "Include Storage Analytics?", ++row, 0, false);
            row = writeFont(contentStream, bool2String(vci.isStorageAnalytics()), row, answerStart, false);
            row = writeFont(contentStream, "Will a Unified File OE upgrade be required?", ++row, 0, false);
            row = writeFont(contentStream, bool2String(vci.isUnifiedFileOERequired()), row, answerStart, false);
            row = writeFont(contentStream, "Include dial home activities?", ++row, 0, false);
            row = writeFont(contentStream, bool2String(vci.isDialHomeActivities()), row, answerStart, false);
            row = writeFont(contentStream, "# of UniSphere domains to configure", ++row, 0, false);
            row = writeFont(contentStream, int2String(vci.getUnisphereDomainsNumber()), row, answerStart, false);
            row = writeFont(contentStream, "# of arrays to implement FAST Cache setup", ++row, 0, false);
            row = writeFont(contentStream, int2String(vci.getFastCacheSetupNumber()), row, answerStart, false);
            row = writeFont(contentStream, "# of arrays to implement Virtual Provisioning", ++row, 0, false);
            row = writeFont(contentStream, int2String(vci.getVirtualProvisioningArraysNumber()), row, answerStart,
                    false);
            if (vci.getVirtualProvisioningArraysNumber() != null && vci.getVirtualProvisioningArraysNumber() > 0) {
                row = writeFont(contentStream, "# of storage pools to be created for VNX Block", ++row, 0, false);
                row = writeFont(contentStream, int2String(vci.getStoragePoolsNumber()), row, answerStart, false);
                row = writeFont(contentStream, "# of of thin luns to be created", ++row, 0, false);
                row = writeFont(contentStream, int2String(vci.getThinLunsNumber()), row, answerStart, false);
                row = writeFont(contentStream, "# of storage groups to be created", ++row, 0, false);
                row = writeFont(contentStream, int2String(vci.getStorageGroupsNumber()), row, answerStart, false);
            }
            row = writeFont(contentStream, "Flash storage layout services required", ++row, 0, false);
            row = writeFont(contentStream, trimToEmpty(vci.getFlashStorageLayoutServices() != null ? vci
                    .getFlashStorageLayoutServices().getName() : ""), row, answerStart, false);
            row = writeFont(contentStream, "# of CX/NS arrays to execute Certified Disk Erasure", ++row, 0, false);
            row = writeFont(contentStream, int2String(vci.getCertifiedDiskErasureArraysNumber()), row,
                    answerStart, false);
            row = writeFont(contentStream, "# of CX/NS/VNX arrays to be deinstalled for a move", ++row, 0, false);
            row = writeFont(contentStream, int2String(vci.getDeinstallCxNsVnxNumber()), row, answerStart, false);
        }
        return row;
    }

    /**
     * Write the SAN / Connectivity information.
     *
     * @param contentStream
     *            The content stream
     * @param si
     *            The SAN/Connectivity request data
     * @param row
     *            Current row
     * @return the last row written
     * @throws IOException
     *             When an error occurs while writing into stream
     */
    private int writeSanTanConnectData(PDPageContentStream contentStream, SanTanInformation si, int row) throws IOException {
        float answerStart = 240f;
        if (si == null) { // prevent null, use defaults if null
            si = new SanTanInformation();
        }

        row = writeFont(contentStream, "Services & Activities - SAN", ++row, 0, true);
        row++;

        row = writeFont(contentStream, "SAN / Connectivity", ++row, 0, true);
        row = writeFont(contentStream, "# hours of knowledge transfer", ++row, 0, false);
        row = writeFont(contentStream, si.getKnowledgeTransferHours(), row, answerStart, false);
        row = writeFont(contentStream, "Is SAN migration in scope?", ++row, 0, false);
        boolean sanMigrationInScopeOption = si.isSanMigrationInScopeOption();
        row = writeFont(contentStream, bool2String(sanMigrationInScopeOption), row, answerStart, false);
        if (sanMigrationInScopeOption) {
            row = writeFont(contentStream, "# of total ports to migrate?", ++row, 0, false);
            row = writeFont(contentStream, int2String(si.getTotalPortsToMigrate()), row, answerStart, false);
        }
        row = writeFont(contentStream, "# of SAN directors to install", ++row, 0, false);
        row = writeFont(contentStream, int2String(si.getSanDirectorsNumber()), row, answerStart, false);
        row = writeFont(contentStream, "# of SAN switches to install", ++row, 0, false);
        row = writeFont(contentStream, int2String(si.getSanSwitchesNumber()), row, answerStart, false);
        row = writeFont(contentStream, "# of blades to install in existing directors and switches", ++row, 0,
                false);
        row = writeFont(contentStream, int2String(si.getBladesNumber()), row, answerStart, false);
        row = writeFont(contentStream, "# of FCoE switches to install", ++row, 0, false);
        row = writeFont(contentStream, int2String(si.getFcoeSwitchesNumber()), row, answerStart, false);
        row = writeFont(contentStream, "# of FCoE VLANs to configure per switch", ++row, 0, false);
        row = writeFont(contentStream, int2String(si.getFcoeVlanNumber()), row, answerStart, false);
        row = writeFont(contentStream, "# of Virtual SANs", ++row, 0, false);
        row = writeFont(contentStream, int2String(si.getNumberOfVirtualSANs()), row, answerStart, false);
        row = writeFont(contentStream, "# of FCoE Uplinks", ++row, 0, false);
        row = writeFont(contentStream, int2String(si.getNumberOfFCoEUplinks()), row, answerStart, false);
        row = writeFont(contentStream, "# of FCoE port channels/trunks to configure per switch", ++row, 0, false);
        row = writeFont(contentStream, int2String(si.getFcoeChannelNumber()), row, answerStart, false);
        row = writeFont(contentStream, "# of SAN extension devices to be installed", ++row, 0, false);
        row = writeFont(contentStream, int2String(si.getSanExtensionDevicesNumber()), row, answerStart, false);
        row = writeFont(contentStream, "# of new NAS units to connect to SAN and CX", ++row, 0, false);
        row = writeFont(contentStream, int2String(si.getNasToCxUnitsNumber()), row, answerStart, false);
        row = writeFont(contentStream, "# of new NAS units to connect to SAN and Symmetrix", ++row, 0, false);
        row = writeFont(contentStream, int2String(si.getNasToSymmetrixUnitsNumber()), row, answerStart, false);
        row = writeFont(contentStream, "# of new physical hosts to connect to SAN and CX", ++row, 0, false);
        row = writeFont(contentStream, int2String(si.getNasToCxHostsNumber()), row, answerStart, false);
        row = writeFont(contentStream, "# of new physical hosts to connect to SAN and Symmetrix", ++row, 0, false);
        row = writeFont(contentStream, int2String(si.getNasToSymmetrixHostsNumber()), row, answerStart, false);
        row = writeFont(contentStream, "# of hosts to verify connectivity after major outage (not migrations)",
                ++row, 0, false);
        row = writeFont(contentStream, int2String(si.getVerifyMajorOutageConnectivityHostsNumber()), row,
                answerStart, false);
        row = writeFont(contentStream, "# of SAN directors to be deinstalled", ++row, 0, false);
        row = writeFont(contentStream, int2String(si.getDeinstalledSanDirectorsNumber()), row, answerStart, false);
        row = writeFont(contentStream, "# of SAN switches/appliances to be deinstalled", ++row, 0, false);
        row = writeFont(contentStream, int2String(si.getDeinstalledSanSwitchesNumber()), row, answerStart, false);
        row = writeFont(contentStream, "# of SAN extension devices to be deinstalled", ++row, 0, false);
        row = writeFont(contentStream, int2String(si.getDeinstalledSanExtensionDevicesNumber()), row, answerStart,
                false);

        return row;
    }

    /**
     * Get Storage Network Connectivity options.
     *
     * @param vci
     *            VNX Clariion information
     * @return the storage network connectivity options
     */
    private String getVnxStorageNetworkConnectivityOptions(VnxClariionInformation vci) {
        StringBuilder sb = new StringBuilder();
        if (vci.isFcStorageConnectivityRequired()) {
            sb.append(" - FC");
        }
        if (vci.isFcoeStorageConnectivityRequired()) {
            sb.append(" - Fcoe");
        }
        if (vci.isIscsiSanExtensionStorageConnectivityRequired()) {
            sb.append(" - ISCSISan Extention");
        }
        if (vci.isVsanLsanStorageConnectivityRequired()) {
            sb.append(" - VSAN/LSAN");
        }
        if (vci.isFcRoutingStorageConnectivityRequired()) {
            sb.append(" - FC Routing");
        }
        return sb.toString();
    }

    /**
     * Get Additional Software bundles.
     *
     * @param vci
     *            VNX Clariion information
     * @return the additional software bundles
     */
    private List<String> getAdditionalSoftwareBundles(VnxClariionInformation vci) {
        List<String> options = new ArrayList<String>();
        if (vci.isUnifiedLocalProtection()) {
            options.add("VNX Unified Local Protection");
        }
        if (vci.isUnifiedRemoteProtection()) {
            options.add("VNX Unified Remote Protection");
        }
        if (vci.isUnifiedApplicationProtection()) {
            options.add("VNX Unified Application Protection");
        }
        if (vci.isUnifiedFastDeployment()) {
            options.add("VNX Unified FAST Deployment");
        }
        if (vci.isUnifiedSecurityCompliance()) {
            options.add("VNX Unified Security and Compliance");
        }
        if (vci.isUnifiedManagementSuite()) {
            options.add("VNX Unified Management Suite");
        }
        return options;
    }

    /**
     * Get Unified software options.
     *
     * @param vci
     *            VNX Clariion information
     * @return the unified softrware options
     */
    private List<String> getUnifiedSoftwareOptions(VnxClariionInformation vci) {
        List<String> options = new ArrayList<String>();
        if (vci.isDataProtectionAdvisor()) {
            options.add("Data Protection Advisor");
        }
        if (vci.isFastLunMigrator()) {
            options.add("FAST LUN Migrator");
        }
        if (vci.isMirrorView()) {
            options.add("MirrorView");
        }
        if (vci.isQosManager()) {
            options.add("QOS Manager (Install and Overview)");
        }
        if (vci.isReplicationManager()) {
            options.add("Replication Manager");
        }
        if (vci.isRecoverPoint()) {
            options.add("RecoverPoint");
        }
        if (vci.isSanCopy()) {
            options.add("SAN Copy");
        }
        if (vci.isSnapViewVnxSnapShots()) {
            options.add("SnapView and VNX Snapshots");
        }
        if (vci.isVirtualProvisioning()) {
            options.add("Virtual Provisioning");
        }
        if (vci.isUnisphereAnalyzer()) {
            options.add("Unisphere Analyzer - Installation & Overview");
        }
        if (vci.isUnisphereRemote()) {
            options.add("Unisphere Remote");
        }
        return options;
    }

    /**
     * Get infrastuctureRequestData Options.
     *
     * @param infrastuctureRequestData
     *            the infrastuctureRequestData
     * @return the options list.
     */
    private List<String> getInfrastructureRequestDataOptions(InfrastructureRequestData infrastuctureRequestData) {
        List<String> options = new ArrayList<String>();
        if (infrastuctureRequestData.getSymmetrixMFServiceEnabled()) {
            options.add("Symm (MF)");
        }
        if (infrastuctureRequestData.getSymmetrixOSServiceEnabled()) {
            options.add("Symm (OS)");
        }
        if (infrastuctureRequestData.isDataMigrationServiceEnabled()) {
            options.add("Data Migration");
        }
        if (infrastuctureRequestData.isVnxClariionServiceEnabled()) {
            options.add("Unified");
        }
        if (infrastuctureRequestData.isCxReplicationServiceEnabled()) {
            options.add("Replication");
        }
        if (infrastuctureRequestData.isSanAssessmentServiceEnabled()) {
            options.add("SAN Assessment");
        }
        if (infrastuctureRequestData.isArrayHealthCheckServiceEnabled()) {
            options.add("Array HealthCheck");
        }
        if (infrastuctureRequestData.isSanHealthCheckServiceEnabled()) {
            options.add("SAN HealthCheck");
        }
        if (infrastuctureRequestData.getVplexServiceEnabled()) {
            options.add("VPLEX");
        }
        return options;
    }

    /**
     * Transfer Phone to string.
     *
     * @param phone
     *            the Phone
     * @return the string
     */
    private static String phone2String(Phone phone) {
        return phone == null ? "" : phone.toString();
    }

    /**
     * Transfer boolean to string.
     *
     * @param flag
     *            the boolean
     * @return the string
     */
    private static String bool2String(Boolean flag) {
        if (flag == null) {
            return "";
        }
        return flag ? "Yes" : "No";
    }

    /**
     * Transfer "New Or Existing" boolean flags to string.
     *
     * @param flag
     *            the boolean
     * @return the string
     */
    private static String bool2StringNewOrExisting(Boolean flag) {
        if (flag == null) {
            return "";
        }
        return flag ? "New" : "Existing";
    }

    /**
     * Transfer "New Or Upgrade" boolean flags to string.
     *
     * @param flag
     *            the boolean
     * @return the string
     */
    private static String bool2StringNewOrUpgrade(Boolean flag) {
        if (flag == null) {
            return "";
        }
        return flag ? "New" : "Upgrade";
    }

    /**
     * Transfer int to String.
     *
     * @param num
     *            the integer
     * @return the string
     */
    private static String int2String(Integer num) {
        if (num == null) {
            return "";
        }
        return String.format("%1$02d", num);
    }

    /**
     * Transfer date to String.
     *
     * @param date
     *            the date
     * @return the string
     */
    private static String date2String(Date date) {
        if (date == null) {
            return "";
        }
        return new SimpleDateFormat(DEFAULT_DATE_FORMAT).format(date);
    }

    /**
     * Transfer double to String.
     *
     * @param value
     *            the double
     * @return the string
     */
    private static String double2String(Double value) {
        if (value == null) {
            return "";
        }
        NumberFormat nf = NumberFormat.getNumberInstance();
        nf.setGroupingUsed(false);
        nf.setMaximumFractionDigits(9);
        return nf.format(value.doubleValue());
    }

    /**
     * Write Project information.
     *
     * @param contentStream
     *            the stream
     * @param request
     *            the request
     * @param row
     *            the start row number
     * @param path 
     * @return the new row number
     * @throws IOException
     *             if any IO error occurs
     */
    private int writeProjectInfo(PDPageContentStream contentStream, Request request, int row, SRTPath path) throws IOException {
        StartRequestData startRequestData = request.getStartRequestData();
        if (startRequestData == null) {
            startRequestData = new StartRequestData();
        }

        EstimatesData estimatesData = request.getEstimatesData();
        if (estimatesData != null && path == SRTPath.SRT4 || path == SRTPath.SRT_HYBRID) {
            DeliverAction deliverAction = estimatesData.getDeliverAction();
            String deliverActionToBeExported = deliverAction == null ? "" : deliverAction.getName();
            writeToCol(contentStream, "Delivery Action", deliverActionToBeExported, row, false,
                    PROJECT_COL_WIDTH, true);
        }
        row++;
        row = writeFont(contentStream, "Project Info", row, 0, true);
        row++;

        int newRow = row;
        
        newRow = Math
                .max(newRow,
                        writeToCol(contentStream, "Project Name", request.getProjectName(), row, false,
                                PROJECT_COL_WIDTH, true));
        newRow = Math.max(
                newRow,
                writeToCol(contentStream, "Opportunity Number", startRequestData.getSfdcNumber(), row, true,
                        PROJECT_COL_WIDTH, true));
        row = newRow;

        newRow = Math.max(
                newRow,
                writeToCol(contentStream, "Project Type", request.getProjectType().getName(), ++row, false,
                        PROJECT_COL_WIDTH, true));
        newRow = Math.max(newRow,
            writeToCol(contentStream, "Oracle Party ID", startRequestData.getOraclePartyID(), row, true,
                PROJECT_COL_WIDTH, true));
        row = newRow;

        newRow = Math.max(newRow,
            writeToCol(contentStream, "Project Regulatory Type", request.getProjectRegulatoryType().getName(), ++row,
                false, PROJECT_COL_WIDTH, true));
        MeetingStatus meetingStatus = startRequestData.getMeetingStatus();
        if (meetingStatus == null) {
            meetingStatus = new MeetingStatus();
        }
//        newRow = Math.max(newRow,
//            writeToCol(contentStream, "Sales Force Case Number", startRequestData.getExistingSfdcNumber(), row, true,
//                PROJECT_COL_WIDTH));
        row = newRow;

        newRow = Math.max(newRow,
            writeToCol(contentStream, "Estimated Start Date", date2String(request.getProjectStartDate()), ++row, false,
                PROJECT_COL_WIDTH, true));
        RiskLevel riskLevel = startRequestData.getRiskLevel();
        if (riskLevel == null) {
            riskLevel = new RiskLevel();
        }
        newRow = Math.max(newRow,
            writeToCol(contentStream, "Status Meetings", meetingStatus.getName(), row, true, PROJECT_COL_WIDTH, true));
        row = newRow;

        newRow = Math.max(newRow,
            writeToCol(contentStream, "Expected End Date", date2String(request.getProjectEndDate()), ++row, false,
                PROJECT_COL_WIDTH, true));
        SowLanguage sowLanguage = startRequestData.getSowLanguage();
        if (sowLanguage == null) {
            sowLanguage = new SowLanguage();
        }
        newRow = Math.max(newRow,
            writeToCol(contentStream, "Presales Risk Factor", riskLevel.getName(), row, true, PROJECT_COL_WIDTH, true));
        row = newRow;

        Division selectedDivision = startRequestData.getSelectedDivision();
        if (selectedDivision == null) {
            selectedDivision = new Division();
        }
        newRow = Math.max(newRow,
            writeToCol(contentStream, "Sales Division", selectedDivision.getDivisionName(), ++row, false,
                PROJECT_COL_WIDTH, true));
        newRow = Math.max(newRow,
            writeToCol(contentStream, "SOW Language", sowLanguage.getName(), row, true, PROJECT_COL_WIDTH, true));
        row = newRow;

        String districtName = "";
        String areaName = "";
        if (startRequestData.getSelectedDistrict() != null) {
            districtName = startRequestData.getSelectedDistrict().getDistrictName();
            areaName = startRequestData.getSelectedDistrict().getAreaName();
        }
        newRow = Math.max(newRow,
                writeToCol(contentStream, "Sales District", districtName, ++row, false, PROJECT_COL_WIDTH, true));
        newRow = Math.max(newRow,
            writeToCol(contentStream, "Expense Type", lookupEntity2String(startRequestData.getExpenseType()), row, true,
                PROJECT_COL_WIDTH, true));
        row = newRow;

        newRow = Math.max(newRow,
                writeToCol(contentStream, "Sales Area", areaName, ++row, false, PROJECT_COL_WIDTH, true));
        newRow = Math.max(newRow,
            writeToCol(contentStream, "Sold Through Reseller", startRequestData.isResellerSold(), row, true,
                PROJECT_COL_WIDTH, true));
        row = newRow;

        newRow = Math.max(
                newRow,
                writeToCol(contentStream, "Customer Name", startRequestData.getCustomerName(), ++row, false,
                        PROJECT_COL_WIDTH, true));
        newRow = Math.max(newRow,
            writeToCol(contentStream, "Requested Return Date", startRequestData.getRequestedReturnDate(), row, true,
                PROJECT_COL_WIDTH, true));
        row = newRow;

        newRow = Math.max(
                newRow,
                writeToCol(contentStream, "Primary Work Cities", startRequestData.getWorkCity(), ++row, false,
                        PROJECT_COL_WIDTH, true));
        newRow = Math.max(newRow,
            writeToCol(contentStream, "Equipment Returning to EMC?", startRequestData.isReturnEquipment(), row, true,
                PROJECT_COL_WIDTH, true));
        row = newRow;

        newRow = Math.max(
                newRow,
                writeToCol(contentStream, "Program Delivery Manager Name", startRequestData.getPdmName(), ++row,
                        false, PROJECT_COL_WIDTH, true));
        newRow = Math.max(newRow,
            writeToCol(contentStream, "Will Customer Allow Remote Access?", 
                bool2String(startRequestData.isRemoteAccess()), row, true, PROJECT_COL_WIDTH, true));
        row = newRow;

        newRow = Math.max(
                newRow,
                writeToCol(contentStream, "Project Manager Name", startRequestData.getPmName(), ++row, false,
                        PROJECT_COL_WIDTH, true));
        newRow = Math.max(newRow,
            writeToCol(contentStream, "Special Travel Requirements", startRequestData.getTravelRequirements(), row,
                true, PROJECT_COL_WIDTH, true));
        row = newRow;

        newRow = Math.max(
                newRow,
                writeToCol(contentStream, "SE/CSD Name", startRequestData.getSeCsdName(), ++row, false,
                        PROJECT_COL_WIDTH, true));
        // only if Division is Federal
        if ("Federal".equals(selectedDivision.getDivisionName())) {
            ClearanceLevel clearanceLevel = startRequestData.getClearanceLevel();
            if (clearanceLevel == null) {
                clearanceLevel = new ClearanceLevel();
            }
            newRow = Math.max(newRow,
                writeToCol(contentStream, "Clearance Level", clearanceLevel.getName(), row, true, PROJECT_COL_WIDTH, true));
        } else {
            newRow = Math.max(newRow,
                writeToCol(contentStream, "Project Description", request.getProjectDescription(), row, true, PROJECT_COL_WIDTH, true));
        }
        row = newRow;

        newRow = Math.max(
                newRow,
                writeToCol(contentStream, "SE/CSD Phone", phone2String(startRequestData.getSeCsdPhone()), ++row,
                        false, PROJECT_COL_WIDTH, true));
        if ("Federal".equals(selectedDivision.getDivisionName())) {
            newRow = Math.max(newRow,
                writeToCol(contentStream, "Project Description", request.getProjectDescription(), row, true,
                    PROJECT_COL_WIDTH, true));
        }
        row = newRow;

        newRow = Math.max(
                newRow,
                writeToCol(contentStream, "SE Manager Name", startRequestData.getSeManagerName(), ++row, false,
                        PROJECT_COL_WIDTH, true));

        row = newRow;

        newRow = Math.max(
                newRow,
                writeToCol(contentStream, "Quote Number", startRequestData.getDxQuoteNumber(),
                        ++row, false, PROJECT_COL_WIDTH, true));
        
        row = newRow;

        return row;
    }

    /**
     * Writes engagement type data.
     *
     * @param contentStream
     *            the content stream.
     * @param request
     *            The service request.
     * @param row
     *            the start row number.
     * @return the new row number
     * @throws IOException
     *             if any I/O error occurs
     */
    private int writeEngagement(PDPageContentStream contentStream, Request request, int row) throws IOException {

        EngagementTypeData engagement = request.getEngagementTypeData();

        if (engagement == null) {
            return row;
        }

        float questionWidth = PROJECT_COL_WIDTH;
        row++;
        row = writeFont(contentStream, "Engagement Type", ++row, 0, true);

        List<String> types = new ArrayList<String>();
        if (engagement.isProductLead()) {
            types.add("Product Led");
        }
        if (engagement.isServiceLead()) {
            types.add("Service Led");
        }
        row = writeFont(contentStream, "Engagement Type", ++row, 0, false);
        row = writeFont(contentStream, ":", row, questionWidth, false);
        row = writeOptions(contentStream, types, row, questionWidth + COLON_PADDING, 1, 100f);

        List<String> lobs = new ArrayList<String>();
        if (engagement.isEmc()) {
            lobs.add("EMC");
        }
        if (engagement.isEcd()) {
            lobs.add("ECD");
        }
        if (engagement.isRsa()) {
            lobs.add("RSA");
        }
        if (engagement.isMs()) {
            lobs.add("MS");
        }
        row = writeFont(contentStream, "Line of Business", ++row, 0, false);
        row = writeFont(contentStream, ":", row, questionWidth, false);
        row = writeOptions(contentStream, lobs, row, questionWidth + COLON_PADDING, 1, 100f);

        row = writeToCol(contentStream, "Booking Country",
                lookupEntity2String(engagement.getDeliveryCountry()),
                ++row, false, questionWidth, true, 200);

        return row;
    }

    /**
     * Write Customer information.
     *
     * @param contentStream
     *            the stream
     * @param request
     *            the request
     * @param row
     *            the row number
     * @return the row number
     * @throws IOException
     *             if any IO error occurs
     */
    private int writeCustomerInfo(PDPageContentStream contentStream, Request request, int row) throws IOException {
        StartRequestData startRequestData = request.getStartRequestData();

        if (startRequestData == null) {
            startRequestData = new StartRequestData();
        }
        if (request.getRequestType().getId() == 1) {
            // there is no customer info for BOE
            return row;
        }

        Customer customer = request.getCustomer();
        if (customer != null) {
            row++;
            row = writeFont(contentStream, "Customer", ++row, 0, true);
            row = writeFont(contentStream, "Customer Bill-To Info", ++row, 0, true);
            row = writeFont(contentStream, "District Info", row, SECOND_LIST_START, true);
            int newRow = row;

            newRow = Math.max(
                    newRow,
                    writeToCol(contentStream, "Customer Name", customer.getFormalName(), ++row, false,
                            PROJECT_COL_WIDTH, true));
            String districtName = "";
            if (startRequestData.getSelectedDistrict() != null) {
                districtName = startRequestData.getSelectedDistrict().getDistrictName();
            }
            PdmName pdm = startRequestData.getSelectedPdmName();
            newRow = Math.max(newRow,
                    writeToCol(contentStream, "District Name", districtName, row, true, PROJECT_COL_WIDTH, true));
            row = newRow;

            newRow = Math.max(
                    newRow,
                    writeToCol(contentStream, "Address Line 1", customer.getAddress1(), ++row, false,
                            PROJECT_COL_WIDTH, true));
            newRow = Math.max(
                    newRow,
                    writeToCol(contentStream, "District PDM Address Line 1",
                            pdm == null ? "N/A" : pdm.getAddress1(), row, true, PROJECT_COL_WIDTH, true));
            row = newRow;

            newRow = Math.max(
                    newRow,
                    writeToCol(contentStream, "Address Line 2", customer.getAddress2(), ++row, false,
                            PROJECT_COL_WIDTH, true));
            newRow = Math.max(
                    newRow,
                    writeToCol(contentStream, "District PDM Address Line 2",
                            pdm == null ? "N/A" : pdm.getAddress2(), row, true, PROJECT_COL_WIDTH, true));
            row = newRow;

            newRow = Math.max(newRow,
                    writeToCol(contentStream, "City", customer.getCity(), ++row, false, PROJECT_COL_WIDTH, true));
            newRow = Math.max(
                    newRow,
                    writeToCol(contentStream, "District PDM City", pdm == null ? "N/A" : pdm.getCity(), row, true,
                            PROJECT_COL_WIDTH, true));
            row = newRow;

            Region region = customer.getRegion();
            if (region == null) {
                region = new Region();
            }
            newRow = Math
                    .max(newRow,
                            writeToCol(contentStream, "CountryState", region.getName(), ++row, false,
                                    PROJECT_COL_WIDTH, true));
            newRow = Math.max(
                    newRow,
                    writeToCol(contentStream, "District PDM State", pdm == null ? "N/A" : pdm.getState(), row,
                            true, PROJECT_COL_WIDTH, true));
            row = newRow;

            newRow = Math.max(newRow,
                    writeToCol(contentStream, "ZIP", customer.getZip(), ++row, false, PROJECT_COL_WIDTH, true));
            newRow = Math.max(
                    newRow,
                    writeToCol(contentStream, "District PDM Zip Code", pdm == null ? "N/A" : pdm.getPostalCode(),
                            row, true, PROJECT_COL_WIDTH, true));
            row = newRow;

            row++;
            row = writeFont(contentStream, "Customer Contact", ++row, 0, true);
            row = writeFont(contentStream, "EMC PDM Contact Info", row, SECOND_LIST_START, true);
            newRow = Math.max(
                    newRow,
                    writeToCol(contentStream, "Name", pdm == null ? "N/A" : pdm.getPdmName(), ++row, true,
                            PROJECT_COL_WIDTH, true));
            row = newRow;

            newRow = Math.max(newRow,
                    writeToCol(contentStream, "Title", customer.getTitle(), ++row, false, PROJECT_COL_WIDTH, true));
            newRow = Math.max(
                    newRow,
                    writeToCol(contentStream, "Title", pdm == null ? "N/A" : pdm.getTitle(), row, true,
                            PROJECT_COL_WIDTH, true));
            row = newRow;

            newRow = Math.max(
                    newRow,
                    writeToCol(contentStream, "Office Phone", phone2String(customer.getOfficePhone()), ++row,
                            false, PROJECT_COL_WIDTH, true));
            newRow = Math.max(
                    newRow,
                    writeToCol(contentStream, "Office Phone", pdm == null ? "N/A" : pdm.getOfficeNumber(), row,
                            true, PROJECT_COL_WIDTH, true));
            row = newRow;

            newRow = Math.max(
                    newRow,
                    writeToCol(contentStream, "Mobile Phone", phone2String(customer.getMobilePhone()), ++row,
                            false, PROJECT_COL_WIDTH, true));
            newRow = Math.max(
                    newRow,
                    writeToCol(contentStream, "Mobile Phone", pdm == null ? "N/A" : pdm.getMobileNumber(), row,
                            true, PROJECT_COL_WIDTH, true));
            row = newRow;

            newRow = Math.max(
                    newRow,
                    writeToCol(contentStream, "Fax", phone2String(customer.getFax()), ++row, false,
                            PROJECT_COL_WIDTH, true));
            newRow = Math.max(
                    newRow,
                    writeToCol(contentStream, "Fax", pdm == null ? "N/A" : pdm.getFaxNumber(), row, true,
                            PROJECT_COL_WIDTH, true));
            row = newRow;

            newRow = Math.max(newRow,
                    writeToCol(contentStream, "Email", customer.getEmail(), ++row, false, PROJECT_COL_WIDTH, true));
            newRow = Math.max(
                    newRow,
                    writeToCol(contentStream, "Email", pdm == null ? "N/A" : pdm.getEmailAddress(), row, true,
                            PROJECT_COL_WIDTH, true));
            row = newRow;

        }
        return row;
    }

    /**
     * Write Service Request information.
     *
     * @param contentStream
     *            the stream
     * @param request
     *            the request
     * @param row
     *            the row number
     * @return the row number
     * @throws IOException
     *             if any IO error occurs
     */
    private int writeServiceRequestInfo(PDPageContentStream contentStream, Request request, int row)
        throws IOException {
        row++;
        row = writeFont(contentStream, "Service Request Info", ++row, 0, true);
        RequestType requestType = request.getRequestType();
        int newRow = row;
        if (requestType != null) {
            newRow = Math.max(
                    newRow,
                    writeToCol(contentStream, "Request Type", requestType.getName(), ++row, false,
                            PROJECT_COL_WIDTH, true));
            row = newRow;
        }
        StartRequestData startRequestData = request.getStartRequestData();
        if (startRequestData == null) {
            startRequestData = new StartRequestData();
        }
        newRow = Math.max(
                newRow,
                writeToCol(contentStream, "Phone call to discuss request", startRequestData.isPhoneCallRequest(),
                        ++row, false, PROJECT_COL_WIDTH, true));
        row = newRow;
        row = writeFont(contentStream, "Service Request Scope and Customer Objectives", ++row, 0, true);

        row = writeFont(contentStream, "Core", ++row, 0, true);
        row = writeFont(contentStream, ":", row, PROJECT_COL_WIDTH, false);

        float startPosision = PROJECT_COL_WIDTH + COLON_PADDING;
        float columnWidth = 100f;
        List<String> options = getCoreOptionsList(startRequestData.getCoreOptions());
        row = writeOptions(contentStream, options, row, startPosision, 3, columnWidth);

        row = writeFont(contentStream, "DPAD", ++row, 0, true);
        row = writeFont(contentStream, ":", row, PROJECT_COL_WIDTH, false);

        options = getDPADOptions(startRequestData.getDpadOptions());
        row = writeOptions(contentStream, options, row, startPosision, 2, columnWidth);

        row = writeFont(contentStream, "ASD", ++row, 0, true);
        row = writeFont(contentStream, ":", row, PROJECT_COL_WIDTH, false);

        options = getASDOptionsList(startRequestData.getAsdOptions());
        row = writeOptions(contentStream, options, row, startPosision, 3, columnWidth);

        row = writeFont(contentStream, "Affinity", ++row, 0, true);
        row = writeFont(contentStream, ":", row, PROJECT_COL_WIDTH, false);

        options = getAffinityOptionsList(startRequestData.getAffinityOptions());
        row = writeOptions(contentStream, options, row, startPosision, 1, columnWidth);

        row = writeFont(contentStream, "Consulting", ++row, 0, true);
        row = writeFont(contentStream, ":", row, PROJECT_COL_WIDTH, false);

        options = getConsultingOptionsList(startRequestData.getConsultingOptions());
        row = writeOptions(contentStream, options, row, startPosision, 1, columnWidth);

        row = writeFont(contentStream, "Other", ++row, 0, true);
        row = writeFont(contentStream, ":", row, PROJECT_COL_WIDTH, false);

        OtherRequestOptions otherRequestOptions = startRequestData.getOtherRequestOptions();
        options = getOtherRequestOptionsList(otherRequestOptions);
        row = writeOptions(contentStream, options, row, startPosision, 1, columnWidth);

        row = writeFont(contentStream, "Scope Description", ++row, 0, true);
        row = writeFont(
                contentStream,
                "* Describe the problem that the customer is trying to solve and the general approach to resolution.",
                ++row, 0, false);
        String serviceRequestScope = startRequestData.getServiceRequestScope();
        if (serviceRequestScope != null) {
            row = writeFont(contentStream, serviceRequestScope, ++row, 0, false);
        }

        row++;
        row = writeFont(contentStream, "Attachment", ++row, 0, true);
        List<Attachment> attachments = startRequestData.getAttachments();
        if (attachments != null) {
            for (Attachment attachment : attachments) {
                row = writeFont(contentStream, "* " + attachment.getAttachmentFilename(), ++row, 0, false);
            }
        }

        Customer customer = request.getCustomer();
        if (customer != null) {
            row++;
            row = writeFont(contentStream, "Customer Work Sites", ++row, 0, true);
            row = writeFont(contentStream, "#", ++row, 10f, true);
            row = writeFont(contentStream, "Site Name", row, 50f, true);
            row = writeFont(contentStream, "Delivery Country", row, 150f, true);
            row = writeFont(contentStream, "Delivery Region/State", row, 300f, true);
            row = writeFont(contentStream, "Delivery City", row, 450f, true);

            int i = 0;
            List<CustomerWorkSite> workSites = customer.getCustomerWorkSites();
            if (workSites != null) {
                int newrow = row;
                for (CustomerWorkSite customerWorkSite : workSites) {
                    i++;
                    newrow++;
                    int currentRow = newrow;
                    newrow = Math.max(newrow, writeFont(contentStream, "" + i, currentRow, 10f, false));
                    newrow = Math
                            .max(newrow,
                                    writeFont(contentStream, customerWorkSite.getSiteName(), currentRow, 50f,
                                            false, 140f));
                    DeliveryCountry deliveryCountry = customerWorkSite.getDeliveryCountry();
                    newrow = Math.max(newrow,
                            writeFont(contentStream, deliveryCountry.getName() != null ? deliveryCountry.getName() : "", currentRow, 150f, false));
                    Region deliveryRegion = customerWorkSite.getDeliveryRegion();
                    if (deliveryRegion == null) {
                        deliveryRegion = new Region();
                    }
                    newrow = Math.max(newrow,
                            writeFont(contentStream, deliveryRegion.getName() != null ? deliveryRegion.getName() : "", currentRow, 300f, false));
                    newrow = Math.max(newrow,
                            writeFont(contentStream, customerWorkSite.getDeliveryCity(), currentRow, 450f, false));
                }
                row = newrow;
            }
        }

        if (requestType.getId() == 1) {
            // there is no customer info for BOE
            return row;
        }

        row++;
        row = writeFont(contentStream, "Customer Contract Info", ++row, 0, true);
        RequestContractData requestContractData = startRequestData.getRequestContractData();
        if (requestContractData == null) {
            requestContractData = new RequestContractData();
        }
        SowType sowType = requestContractData.getSowType();
        if (sowType == null) {
            sowType = new SowType();
        }
        newRow = Math.max(newRow,
                writeToCol(contentStream, "SOW Type Needed", sowType.getName(), ++row, false, PROJECT_COL_WIDTH, true));
        row = newRow;
        newRow = Math.max(
                newRow,
                writeToCol(contentStream, "Customer SOW Format Required",
                        requestContractData.isCustomerFormatRequired(), ++row, false, PROJECT_COL_WIDTH, true));
        row = newRow;
        ServicesAgreementType servicesAgreementType = requestContractData.getServicesAgreementType();
        if (servicesAgreementType == null) {
            servicesAgreementType = new ServicesAgreementType();
        }
        newRow = Math.max(
                newRow,
                writeToCol(contentStream, "PSA Agreement Type", servicesAgreementType.getName(), ++row, false,
                        PROJECT_COL_WIDTH, true));
        row = newRow;
        row = writeFont(contentStream, "* If no PSA Agreement, please contact Business Operations", ++row,
                PROJECT_COL_WIDTH + COLON_PADDING, false);
        newRow = Math.max(
                newRow,
                writeToCol(contentStream, "PSA Date", requestContractData.getServicesAgreementDate(), ++row,
                        false, PROJECT_COL_WIDTH, true));
        row = newRow;
        newRow = Math.max(
                newRow,
                writeToCol(contentStream, "Reseller / Distributor / Partner",
                        requestContractData.getPartnerInformation(), ++row, false, PROJECT_COL_WIDTH,
                        true, DEFAULT_PAGE_WIDTH - PROJECT_COL_WIDTH - 50));
        row = newRow;
        return row;
    }

    /**
     * Get OtherRequestOptions list.
     *
     * @param otherRequestOptions
     *            the input options entity
     * @return the options list.
     */
    private List<String> getOtherRequestOptionsList(OtherRequestOptions otherRequestOptions) {
        List<String> options = new ArrayList<String>();
        if (otherRequestOptions != null) {
            if (otherRequestOptions.isResidency()) {
                options.add("Residency");
            }
            if (otherRequestOptions.isiSeries()) {
                options.add("iSeries (AS/400)");
            }
            if (otherRequestOptions.isDiskRetention()) {
                options.add("Certified Data Erasure - Single Disk");
            }
            if (otherRequestOptions.isMoveRequest()) {
                options.add("CS Services");
            }
            if (otherRequestOptions.isHealthChecks()) {
                options.add("Health Checks");
            }
            if (otherRequestOptions.getNotListed()) {
                options.add("Not Listed");
            }
            if (otherRequestOptions.getAssessment()) {
                options.add("Assessment");
            }
            if (otherRequestOptions.getProtectPoint()) {
                options.add("ProtectPoint");
            }
        }
        return options;
    }

    /**
     * Get ConsultingOptions list.
     *
     * @param consultingOptions
     *            the input options entity
     * @return the options list.
     */
    private List<String> getConsultingOptionsList(ConsultingOptions consultingOptions) {
        List<String> options = new ArrayList<String>();
        if (consultingOptions != null) {
            if (consultingOptions.isBluePrinting()) {
                options.add("Blueprinting");
            }
            if (consultingOptions.isDcm()) {
                options.add("DCM");
            }
            if (consultingOptions.isStaff()) {
                options.add("Staff Augmentation");
            }
            if (consultingOptions.isP2v()) {
                options.add("P2V - V2V");
            }
            if (consultingOptions.isVmware()) {
                options.add("VMWare Re-Papering");
            }
        }
        return options;
    }

    /**
     * Get AffinityOptions list.
     *
     * @param affinityOptions
     *            the input options entity
     * @return the options list.
     */
    private List<String> getAffinityOptionsList(AffinityOptions affinityOptions) {
        List<String> options = new ArrayList<String>();
        if (affinityOptions != null) {
            if (affinityOptions.isVmware()) {
                options.add("VMWare");
            }
            if (affinityOptions.isPivotal()) {
                options.add("Pivotal");
            }
            if (affinityOptions.isRsa()) {
                options.add("RSA");
            }
            if (affinityOptions.isVce()) {
                options.add("VCE");
            }
            if (affinityOptions.isEcd()) {
                options.add("ECD");
            }
        }
        return options;
    }

    /**
     * Get ASDOptions list.
     *
     * @param asdOptions
     *            the input options entity
     * @return the options list.
     */
    private List<String> getASDOptionsList(ASDOptions asdOptions) {
        List<String> options = new ArrayList<String>();
        if (asdOptions != null) {
            if (asdOptions.isSrm()) {
                options.add("SRM");
            }
            if (asdOptions.isAppSync()) {
                options.add("AppSync");
            }
            if (asdOptions.isAtmos()) {
                options.add("ATMOS");
            }
            if (asdOptions.isW4n()) {
                options.add("W4N");
            }
            if (asdOptions.isCentera()) {
                options.add("Centera");
            }
            if (asdOptions.isVipr()) {
                options.add("ViPR");
            }
            if (asdOptions.isUim()) {
                options.add("UIM");
            }
            if (asdOptions.isNcm()) {
                options.add("NCM");
            }
        }
        return options;
    }

    /**
     * Get DPADOptions list.
     *
     * @param dpadOptions
     *            the input options entity
     * @return the options list.
     */
    private List<String> getDPADOptions(DPADOptions dpadOptions) {
        List<String> options = new ArrayList<String>();
        if (dpadOptions != null) {
            if (dpadOptions.isAvamar()) {
                options.add("Avamar");
            }
            if (dpadOptions.isSourceOne()) {
                options.add("SourceOne");
            }
            if (dpadOptions.isDataDomain()) {
                options.add("Data Domain");
            }
            if (dpadOptions.isNetworker()) {
                options.add("Networker");
            }
            if (dpadOptions.isEdl()) {
                options.add("EDL");
            }
            if (dpadOptions.isMozy()) {
                options.add("Mozy");
            }
            if (dpadOptions.isDlm()) {
                options.add("DLM");
            }
            if (dpadOptions.isDpa()) {
                options.add("DPA");
            }
            if (dpadOptions.isRecoverPoint()) {
                options.add("RecoverPoint");
            }
        }
        return options;
    }

    /**
     * Get CoreOptions list.
     *
     * @param coreOptions
     *            the input options entity
     * @return the options list.
     */
    private List<String> getCoreOptionsList(CoreOptions coreOptions) {
        List<String> options = new ArrayList<String>();
        if (coreOptions != null) {
            if (coreOptions.isSymmMf()) {
                options.add("Symm (MF)");
            }
            if (coreOptions.isSan()) {
                options.add("SAN");
            }
            if (coreOptions.isReplication()) {
                options.add("Replication");
            }
            if (coreOptions.isSymmOs()) {
                options.add("Symm (OS)");
            }
            if (coreOptions.isIsilon()) {
                options.add("Isilon");
            }
            if (coreOptions.isXtremeIO()) {
                options.add("Xtreme");
            }
            if (coreOptions.isVblock()) {
                options.add("Vblock");
            }
            if (coreOptions.isVplex()) {
                options.add("VPLEX");
            }
            if (coreOptions.isMainframe()) {
                options.add("Mainframe");
            }
            if (coreOptions.isUnified()) {
                options.add("Unified");
            }
            if (coreOptions.isCta()) {
                options.add("CTA");
            }
        }
        return options;
    }

    /**
     * Write option list in to stream.
     *
     * @param contentStream
     *            the contest stream
     * @param options
     *            the option list
     * @param row
     *            the row
     * @param startPosition
     *            the start position
     * @param colNum
     *            the column number
     * @param colWidth
     *            the column width
     * @param noPrefix
     *            No "*" prefix before the option
     * @return the row number
     * @throws IOException
     *             if any IO error occurs
     */
    private int writeOptions(PDPageContentStream contentStream, List<String> options, int row,
            float startPosition, int colNum, float colWidth, Boolean... noPrefix) throws IOException {
        boolean noPre = noPrefix != null && noPrefix.length > 0 && Boolean.TRUE.equals(noPrefix[0]);
        int i = 0;
        for (String option : options) {
            if (i != 0 && i % colNum == 0) {
                row++;
            }
            row = writeFont(contentStream, noPre ? option : "* " + option, row,
                    startPosition + (colWidth * (i % colNum)), false);
            i++;
        }
        return row;
    }

    /**
     * Write message in to stream.
     *
     * @param contentStream
     *            the contest stream
     * @param colname
     *            the column name
     * @param value
     *            the value
     * @param row
     *            the row
     * @param isSecondList
     *            the flag whether the message is in second list
     * @param colNamewidth
     *            the column name width
     * @param hasColon 
     *            flag indicating if the value should be preceeded by a colon
     * @param maxColValueWidths
     *            the max column value width
     * @return the new row number
     * @throws IOException
     *             if any IO error occurs
     */
    private int writeToCol(PDPageContentStream contentStream, String colname, Object value, int row,
            boolean isSecondList, float colNamewidth, boolean hasColon, float... maxColValueWidths) throws IOException {
        String strValue;
        if (value == null) {
            strValue = "";
        } else if (value instanceof Boolean) {
            strValue = bool2String((Boolean) value);
        } else if (value instanceof Date) {
            SimpleDateFormat df = new SimpleDateFormat(DEFAULT_DATE_FORMAT);
            strValue = df.format((Date) value);
        } else if (value instanceof Integer) {
            strValue = int2String((Integer) value);
        } else {
            strValue = String.valueOf(value);
        }
        float maxColValueWidth = maxColValueWidths == null || maxColValueWidths.length == 0 ? SECOND_LIST_START
                - colNamewidth - COLON_PADDING - 5 : maxColValueWidths[0];
        if (isSecondList) {
            row = writeFont(contentStream, colname, row, SECOND_LIST_START, false);
            if(hasColon){
                row = writeFont(contentStream, ":", row, SECOND_LIST_START + colNamewidth, false);
            }
            row = writeFont(contentStream, strValue, row, SECOND_LIST_START + colNamewidth + COLON_PADDING, false,
                    maxColValueWidth);
        } else {
            row = writeFont(contentStream, colname, row, 0, false);
            if(hasColon){
                row = writeFont(contentStream, ":", row, colNamewidth, false);
            }
            row = writeFont(contentStream, strValue, row, colNamewidth + COLON_PADDING, false, maxColValueWidth);
        }
        return row;
    }

    /**
     * Write the message to stream.
     *
     * @param contentStream
     *            the contest stream
     * @param message
     *            the message
     * @param row
     *            the row
     * @param x
     *            the x position
     * @param isHeader
     *            the flag whether the message is header
     * @param maxWidths
     *            the max width
     * @return the new row number
     * @throws IOException
     *             if any IO error occurs
     */
    private int writeFont(PDPageContentStream contentStream, String message, int row, float x,
            boolean isHeader, float... maxWidths) throws IOException {
        return writeText(contentStream, message, row, x, isHeader, false, false, maxWidths);
    }

    /**
     * Write the message to stream.
     *
     * @param contentStream
     *            the contest stream
     * @param message
     *            the message
     * @param row
     *            the row
     * @param x
     *            the x position
     * @param isHeader
     *            flag indicating whether the message is a header
     * @param isItalic
     *            flag indicating whether the message style should be italic
     * @param alwaysBreakBySpace
     *            flag indicating whether the message should always be broken by space
     * @param maxWidths
     *            the max widths
     * @return the new row number
     * @throws IOException
     *             if any IO error occurs
     * @since 2.23
     */
    private int writeText(PDPageContentStream contentStream, String message, int row, float x, boolean isHeader,
            boolean isItalic, boolean alwaysBreakBySpace, float... maxWidths) throws IOException {
        message = message == null ? "" : message;

        boolean containsLF = message.contains("\n");
        if (containsLF) {
            String[] lines = message.split("\n");
            int rowNum = row - 1;
            for (String line : lines) {
                rowNum = writeText(contentStream, line, ++rowNum, x, isHeader, isItalic, alwaysBreakBySpace, maxWidths);
            }
            return rowNum;
        }

        float messageWidth = 0;

        contentStream.beginText();

        PDFont font = isHeader ? FONT_TEXT_BOLD : (isItalic ? FONT_TEXT_OBLIQUE : FONT_TEXT);
        int fontSize = isHeader ? DEFAULT_FONT_SIZE + 1 : DEFAULT_FONT_SIZE;
        contentStream.setFont(font, fontSize);
        messageWidth = font.getStringWidth(message) / 1000 * fontSize;

        float startX = DEFAULT_PAGE_PADDING + x;

        float maxWidth = maxWidths == null || maxWidths.length == 0 ? DEFAULT_PAGE_WIDTH - startX - 1 : maxWidths[0];
        if (messageWidth > maxWidth) {
            contentStream.appendRawCommands(CELL_HEIGHT + " TL\n");
            contentStream.moveTextPositionByAmount(startX, getYPos(row));

            List<String> lines =  breakToLinesBySpace(message, maxWidth, font, fontSize);
            for (Iterator<String> i = lines.iterator(); i.hasNext();) {
                contentStream.drawString(i.next().trim());
                if (i.hasNext()) {
                    row++;
                    contentStream.appendRawCommands("T*\n");
                }
            }
        } else {
            contentStream.moveTextPositionByAmount(startX, getYPos(row));
            contentStream.drawString(message);
        }

        contentStream.endText();

        return row;
    }

    /**
     * Break the text in lines by space.
     *
     * @param text
     *            to break
     * @param maxWidth
     *            Max width of the text
     * @param font
     *            PDF font
     * @param fontSize
     *            PDF font size
     * @return lines break
     * @throws IOException
     *             if any IO error occurs
     */
    private static List<String> breakToLinesBySpace(String text, float maxWidth, PDFont font, int fontSize)
            throws IOException {
        List<String> result = new ArrayList<String>();

        String[] split = text.split("(?<=[^a-zA-Z0-9_\\(\\)])");
        int[] possibleWrapPoints = new int[split.length];
        possibleWrapPoints[0] = split[0].length();
        for (int i = 1; i < split.length; i++) {
            possibleWrapPoints[i] = possibleWrapPoints[i - 1] + split[i].length();
        }

        int start = 0;
        int end = 0;
        for (int i : possibleWrapPoints) {
            float width = font.getStringWidth(text.substring(start, i)) / 1000 * fontSize;
            if (start < end && width > maxWidth) {
                result.add(text.substring(start, end));
                start = end;
            }
            end = i;
        }
        // Last piece of text
        result.add(text.substring(start));
        return result;
    }
    
    /**
     * Break the text in lines.
     *
     * @param text
     *            to break
     * @param maxWidth
     *            Max width of the text
     * @param font
     *            PDF font
     * @param fontSize
     *            PDF font size
     * @return lines break
     * @throws IOException
     *             if any IO error occurs
     */
    private static List<String> breakToLines(String text, float maxWidth, PDFont font, int fontSize)
        throws IOException {

        maxWidth = maxWidth * 1000 / fontSize;
        List<String> result = new ArrayList<String>();

        float width = 0;
        StringBuilder sb = new StringBuilder();
        byte[] data = text.getBytes("ISO-8859-1");
        for (int i = 0; i < data.length; i++) {
            float charWidth = font.getFontWidth(data, i, 1);
            width += charWidth;
            if (width >= maxWidth) {
                result.add(sb.toString());
                sb.delete(0, sb.length());
                width = 0;
                i--;
            } else {
                sb.append(font.encode(data, i, 1));
            }
        }
        if (sb.length() > 0) {
            result.add(sb.toString());
        }

        return result;
    }

    /**
     * Get y position by row number.
     *
     * @param row
     *            the row number
     * @return the y position
     */
    private static float getYPos(int row) {
        return DEFAULT_PAGE_HEIGHT - DEFAULT_PAGE_PADDING - CELL_HEIGHT * row;
    }

    /**
     * Renders a table.
     *
     * @param page
     *            the current page
     * @param contentStream
     *            the content stream
     * @param y
     *            the y-coordinate of the first row
     * @param margin
     *            the padding on left and right of table
     * @param content
     *            a 2d array containing the table data
     * @param highlightLastRow
     *            Whether highlight last row
     * @param columnWidths
     *            Customize the columns width. If null then default column width will be used.
     * @return the table rows (include line break with cell)
     * @throws IllegalArgumentException
     *             if columnWidths length is not same as the length of content columns
     * @throws IOException
     *             for any errors encountered
     */
    public static int drawTable(PDPage page, PDPageContentStream contentStream, float y, float margin,
            String[][] content, boolean highlightLastRow, float[] columnWidths) throws IOException {
        final int cols = content[0].length;
        if (columnWidths != null && columnWidths.length != cols) {
            throw new IllegalArgumentException("Columns length does not match");
        }
        final float rowHeight = 20f;
        final float tableWidth = page.findMediaBox().getWidth() - (2 * margin);
        final float colWidth = tableWidth / (float) cols; // the default column width
        final float cellMargin = 5f;

        // draw the first row
        contentStream.drawLine(margin, y, margin + tableWidth, y);

        float textx = margin + cellMargin;
        float texty = y - 15;

        for (int i = 0; i < content.length; i++) {
            int maxCellHeight = 1;
            for (int j = 0; j < content[i].length; j++) {
                int currentCellHeight = 1;
                String text = content[i][j];

                float messageWidth = 0;

                boolean boldText = i == 0 || ((i + 1) == content.length && highlightLastRow);
                PDFont font = boldText ? FONT_TEXT_BOLD : FONT_TEXT;
                int fontSize = boldText ? DEFAULT_FONT_SIZE + 1 : DEFAULT_FONT_SIZE;

                contentStream.setFont(font, fontSize);
                messageWidth = font.getStringWidth(text) / 1000 * fontSize;

                contentStream.beginText();

                float maxCellValWidth = columnWidths == null ? colWidth - 10 : columnWidths[j] - 10;
                if (messageWidth > maxCellValWidth) {
                    contentStream.appendRawCommands(CELL_HEIGHT + " TL\n");
                    contentStream.moveTextPositionByAmount(textx, texty);

                    List<String> lines = boldText ? breakToLinesBySpace(text, maxCellValWidth, font, fontSize)
                            : breakToLines(text, maxCellValWidth, font, fontSize);
                    for (Iterator<String> it = lines.iterator(); it.hasNext();) {
                        contentStream.drawString(it.next().trim());
                        if (it.hasNext()) {
                            currentCellHeight++;
                            contentStream.appendRawCommands("T*\n");
                        }
                    }
                } else {
                    contentStream.moveTextPositionByAmount(textx, texty);
                    contentStream.drawString(text);
                }
                maxCellHeight = Math.max(maxCellHeight, currentCellHeight);
                contentStream.endText();
                textx += columnWidths == null ? colWidth : columnWidths[j];
            }

            texty -= rowHeight + CELL_HEIGHT * (maxCellHeight - 1);
            textx = margin + cellMargin;

            // Draw row
            contentStream.drawLine(margin, texty + 15, margin + tableWidth, texty + 15);
        }

        // draw the columns
        float nextx = margin;
        for (int i = 0; i <= cols; i++) {
            contentStream.drawLine(nextx, y, nextx, texty + 15);
            if (i < cols) {
                nextx += columnWidths == null ? colWidth : columnWidths[i];
            }
        }

        return (int) Math.floor(Math.abs(y - (texty + 15)) / CELL_HEIGHT) + 1;
    }

    /**
     * Renders a pricing table.
     *
     * @param page
     *            the current page
     * @param contentStream
     *            the content stream
     * @param y
     *            the y-coordinate of the first row
     * @param leftMargin
     *            the padding on left and right of table
     * @param content
     *            a 2d array containing the table data
     * @param columnWidths
     *            Customize the columns width. If null then default column width
     *            will be used.
     * @return the table rows (include line break with cell)
     * @throws IllegalArgumentException
     *             if columnWidths length is not same as the length of content
     *             columns
     * @throws IOException
     *             for any errors encountered
     * @since 2.23
     */
    public static int drawPricingTable(PDPage page, PDPageContentStream contentStream, float y, float leftMargin,
            String[][] content, float[] columnWidths) throws IOException {
        int cols = content[0].length;
        if (columnWidths != null && columnWidths.length != cols) {
            throw new IllegalArgumentException("Columns length does not match");
        }
        float rowHeight = 20f;
        float tableWidth = 0;
        for (int i = 0; i < columnWidths.length; i++) {
            tableWidth += columnWidths[i];
        }
        float cellMargin = 5f;

        // draw the first row
        contentStream.drawLine(leftMargin, y, leftMargin + tableWidth, y);

        float textx = leftMargin + cellMargin;
        float texty = y - 15;

        for (int i = 0; i < content.length; i++) {
            int maxCellHeight = 1;
            for (int j = 0; j < content[i].length; j++) {
                int currentCellHeight = 1;
                String text = content[i][j];

                float messageWidth = 0;

                boolean boldText = i == 0;
                PDFont font = boldText ? FONT_TEXT_BOLD : FONT_TEXT;
                int fontSize = boldText ? DEFAULT_FONT_SIZE + 1 : DEFAULT_FONT_SIZE;

                contentStream.setFont(font, fontSize);
                messageWidth = font.getStringWidth(text) / 1000 * fontSize;

                contentStream.beginText();

                float maxCellValWidth = columnWidths[j] - 10;
                if (messageWidth > maxCellValWidth) {
                    contentStream.appendRawCommands(CELL_HEIGHT + " TL\n");
                    contentStream.moveTextPositionByAmount(textx, texty);

                    List<String> lines = breakToLinesBySpace(text, maxCellValWidth, font, fontSize);;
                    for (Iterator<String> it = lines.iterator(); it.hasNext();) {
                        contentStream.drawString(it.next().trim());
                        if (it.hasNext()) {
                            currentCellHeight++;
                            contentStream.appendRawCommands("T*\n");
                        }
                    }
                } else {
                    contentStream.moveTextPositionByAmount(textx, texty);
                    contentStream.drawString(text);
                }
                maxCellHeight = Math.max(maxCellHeight, currentCellHeight);
                contentStream.endText();
                textx += columnWidths[j];
            }

            texty -= rowHeight + CELL_HEIGHT * (maxCellHeight - 1);
            textx = leftMargin + cellMargin;

            // Draw row
            contentStream.drawLine(leftMargin, texty + 15, leftMargin + tableWidth, texty + 15);
        }

        // draw the columns
        float nextx = leftMargin;
        for (int i = 0; i <= cols; i++) {
            contentStream.drawLine(nextx, y, nextx, texty + 15);
            if (i < cols) {
                nextx += columnWidths[i];
            }
        }

        return (int) Math.floor(Math.abs(y - (texty + 15)) / CELL_HEIGHT) + 1;
    }

    /**
     * Renders a dynamic column table.
     *
     * @param page
     *            the current page
     * @param contentStream
     *            the content stream
     * @param y
     *            the y-coordinate of the first row
     * @param margin
     *            the padding on left and right of table
     * @param firstColumnWidth
     *            the width of first column.
     * @param columnWidth
     *            the width of column
     * @param content
     *            a 2d array containing the table data
     * @return the table rows (include line break within cell)
     * @throws IOException
     *             for any errors encountered
     * @since SRT Phase 3-3 - BRS Tab Assembly
     */
    private static int drawDynColTable(PDPage page, PDPageContentStream contentStream, final float y,
            final float margin, final float firstColumnWidth, final float columnWidth, String[][] content)
        throws IOException {
        final float tableWidth = page.findMediaBox().getWidth() - (2 * margin);

        int maxCols = (int) ((tableWidth - firstColumnWidth) / columnWidth);

        final float rowHeight = 20f;
        final float cellMargin = 5f;

        float textx = margin + cellMargin;
        float texty = y;
        int tableCount = 0;

        do {
            float lastTexty = texty;

            // draw the first row
            contentStream.drawLine(margin, lastTexty, margin + tableWidth, lastTexty);

            for (int i = 0; i < content.length; i++) {
                int maxCellHeight = 1;

                for (int j = 0; j < content[i].length; j++) {
                    if (j == 0 || (j > tableCount * maxCols && j <= (tableCount + 1) * maxCols)) {
                        float maxCellValWidth = j == 0 ? firstColumnWidth : columnWidth;
                        if (j == (tableCount + 1) * maxCols) {
                            maxCellValWidth = page.findMediaBox().getWidth() - textx - margin -  1;
                        }
                        int currentCellHeight = 1;
                        String text = content[i][j];

                        float messageWidth = 0;
                        PDFont font = i == 0 ? FONT_TEXT_BOLD : FONT_TEXT;
                        int fontSize = i == 0 ? DEFAULT_FONT_SIZE + 1 : DEFAULT_FONT_SIZE;

                        contentStream.setFont(font, fontSize);
                        messageWidth = font.getStringWidth(text) / 1000 * fontSize;

                        contentStream.beginText();

                        if (messageWidth > maxCellValWidth) {
                            contentStream.appendRawCommands(CELL_HEIGHT + " TL\n");
                            contentStream.moveTextPositionByAmount(textx, texty - 15);

                            List<String> lines = j == 0 ? breakToLinesBySpace(text, maxCellValWidth, font, fontSize)
                                    : breakToLines(text, maxCellValWidth, font, fontSize);
                            for (Iterator<String> it = lines.iterator(); it.hasNext();) {
                                contentStream.drawString(it.next().trim());
                                if (it.hasNext()) {
                                    currentCellHeight++;
                                    contentStream.appendRawCommands("T*\n");
                                }
                            }
                        } else {
                            contentStream.moveTextPositionByAmount(textx, texty - 15);
                            contentStream.drawString(text);
                        }
                        maxCellHeight = Math.max(maxCellHeight, currentCellHeight);
                        contentStream.endText();
                        
                        textx += (maxCellValWidth + cellMargin);
                    }
                }

                texty -= rowHeight + CELL_HEIGHT * (maxCellHeight - 1);
                textx = margin + cellMargin;

                // Draw row
                if (i == 0 || i == content.length - 1) {
                    contentStream.drawLine(margin, texty, margin + tableWidth, texty);
                }
            }

            // draw the columns
            contentStream.drawLine(margin, lastTexty, margin, texty);
            contentStream.drawLine(margin + firstColumnWidth, lastTexty, margin + firstColumnWidth, texty);
            contentStream.drawLine(margin + tableWidth, lastTexty, margin + tableWidth, texty);

            tableCount++;
        } while (tableCount * maxCols < content[0].length - 1);

        return (int) Math.floor(Math.abs(y - texty) / CELL_HEIGHT) + 1;
    }
    
    /**
     * Renders a estimates dynamic column table.
     *
     * @param page
     *            the current page
     * @param contentStream
     *            the content stream
     * @param y
     *            the y-coordinate of the first row
     * @param margin
     *            the padding on left and right of table
     * @param firstColumnWidth
     *            the width of first column.
     * @param headerColWidth
     *            the width of a header column.
     * @param columnWidth
     *            the width of column
     * @param content
     *            a 2d array containing the table data
     * @return the table rows (include line break within cell)
     * @throws IOException
     *             for any errors encountered
     * @since 2.23
     */
    private static int drawEstimatesDynColTable(PDPage page, PDPageContentStream contentStream, final float y,
            final float margin, final float firstColumnWidth, final float columnWidth, String[][] content)
        throws IOException {
        final float tableWidth = page.findMediaBox().getWidth() - (2 * margin);

        int maxCols = (int) ((tableWidth - firstColumnWidth) / columnWidth);

        final float rowHeight = 20f;
        final float cellMargin = 5f;

        float textx = margin + cellMargin;
        float texty = y;
        int tableCount = 0;

        do {
            float lastTexty = texty;

            // draw the first row
            contentStream.drawLine(margin, lastTexty, margin + tableWidth, lastTexty);

            for (int i = 0; i < content.length; i++) {
                int maxCellHeight = 1;

                for (int j = 0; j < content[i].length; j++) {
                    if (j == 0 || (j > tableCount * maxCols && j <= (tableCount + 1) * maxCols)) {
                        float maxCellValWidth = j == 0 ? firstColumnWidth : columnWidth;
                        if (j == (tableCount + 1) * maxCols) {
                            maxCellValWidth = page.findMediaBox().getWidth() - textx - margin -  1;
                        }
                        int currentCellHeight = 1;
                        String text = content[i][j];

                        float messageWidth = 0;
                        PDFont font = i == 0 ? FONT_TEXT_BOLD : FONT_TEXT;
                        int fontSize = i == 0 ? DEFAULT_FONT_SIZE + 1 : DEFAULT_FONT_SIZE;

                        contentStream.setFont(font, fontSize);
                        messageWidth = font.getStringWidth(text) / 1000 * fontSize;

                        contentStream.beginText();

                        if (messageWidth > maxCellValWidth) {
                            contentStream.appendRawCommands(CELL_HEIGHT + " TL\n");
                            contentStream.moveTextPositionByAmount(textx, texty - 15);

                            List<String> lines = j == 0 ? breakToLinesBySpace(text, maxCellValWidth, font, fontSize)
                                    : i == 0 ? breakToLinesBySpace(text, columnWidth, font, fontSize) : 
                                        breakToLines(text, maxCellValWidth, font, fontSize);
                            for (Iterator<String> it = lines.iterator(); it.hasNext();) {
                                contentStream.drawString(it.next().trim());
                                if (it.hasNext()) {
                                    currentCellHeight++;
                                    contentStream.appendRawCommands("T*\n");
                                }
                            }
                        } else {
                            contentStream.moveTextPositionByAmount(textx, texty - 15);
                            contentStream.drawString(text);
                        }
                        maxCellHeight = Math.max(maxCellHeight, currentCellHeight);
                        contentStream.endText();
                        
                        textx += (maxCellValWidth + cellMargin);
                    }
                }

                texty -= rowHeight + CELL_HEIGHT * (maxCellHeight - 1);
                textx = margin + cellMargin;

                // Draw row
                contentStream.drawLine(margin, texty, margin + tableWidth, texty);
            }

            // draw the columns
            contentStream.drawLine(margin, lastTexty, margin, texty);
            contentStream.drawLine(margin + firstColumnWidth, lastTexty, margin + firstColumnWidth, texty);
            contentStream.drawLine(margin + tableWidth, lastTexty, margin + tableWidth, texty);

            tableCount++;
        } while (tableCount * maxCols < content[0].length - 1);

        return (int) Math.floor(Math.abs(y - texty) / CELL_HEIGHT) + 1;
    }

    /**
     * Renders the pricing overview dynamic column table.
     *
     * @param page
     *            the current page
     * @param contentStream
     *            the content stream
     * @param y
     *            the y-coordinate of the first row
     * @param margin
     *            the padding on left and right of table
     * @param firstColumnWidth
     *            the width of first column.
     * @param columnWidth
     *            the width of column
     * @param content
     *            a 2d array containing the table data
     * @return the table rows (include line break within cell)
     * @throws IOException
     *             for any errors encountered
     * @since 2.23
     */
    private static int drawPricingOverviewDynColTable(PDPage page, PDPageContentStream contentStream, final float y,
            final float margin, final float firstColumnWidth, float columnWidth, String[][] content)
            throws IOException {
        final float tableWidth = page.findMediaBox().getWidth() - (2 * margin);

        int maxCols = (int) ((tableWidth - firstColumnWidth) / columnWidth);
        if(maxCols > content[0].length - 1){
            columnWidth = (tableWidth - firstColumnWidth) / (content[0].length - 1) - 10;
        }

        final float rowHeight = 20f;
        final float cellMargin = 5f;

        float textx = margin + cellMargin;
        float texty = y;
        int tableCount = 0;

        do {
            float lastTexty = texty;

            // draw the first row
            contentStream.drawLine(margin, lastTexty, margin + tableWidth, lastTexty);

            for (int i = 0; i < content.length; i++) {
                int maxCellHeight = 1;

                for (int j = 0; j < content[i].length; j++) {
                    if (j == 0 || (j > tableCount * maxCols && j <= (tableCount + 1) * maxCols)) {
                        float maxCellValWidth = j == 0 ? firstColumnWidth : columnWidth;
                        if (j == (tableCount + 1) * maxCols) {
                            maxCellValWidth = page.findMediaBox().getWidth() - textx - margin - 1;
                        }
                        int currentCellHeight = 1;
                        String text = content[i][j];
                        float messageWidth = 0;
                        PDFont font = i == 0 ? FONT_TEXT_BOLD : FONT_TEXT;
                        int fontSize = i == 0 ? DEFAULT_FONT_SIZE + 1 : DEFAULT_FONT_SIZE;

                        contentStream.setFont(font, fontSize);
                        messageWidth = font.getStringWidth(text) / 1000 * fontSize;
                        if(text.length() > 0 && ((text.charAt(0) =='(' && text.charAt(text.length()-1) == ')') || 
                                (text.charAt(0) =='-' && text.charAt(text.length()-1) == '%'))){
                            contentStream.setNonStrokingColor(Color.RED);
                        }
                        
                        
                        contentStream.beginText();

                        if (messageWidth > maxCellValWidth) {
                            contentStream.appendRawCommands(CELL_HEIGHT + " TL\n");
                            contentStream.moveTextPositionByAmount(textx, texty - 15);

                            List<String> lines = j == 0 ? breakToLinesBySpace(text, maxCellValWidth, font, fontSize)
                                    : i == 0 ? breakToLinesBySpace(text, columnWidth, font, fontSize) : 
                                        breakToLines(text, maxCellValWidth, font, fontSize);
                            for (Iterator<String> it = lines.iterator(); it.hasNext();) {
                                contentStream.drawString(it.next().trim());
                                if (it.hasNext()) {
                                    currentCellHeight++;
                                    contentStream.appendRawCommands("T*\n");
                                }
                            }
                        } else {
                            contentStream.moveTextPositionByAmount(textx, texty - 15);
                            contentStream.drawString(text);
                        }
                        maxCellHeight = Math.max(maxCellHeight, currentCellHeight);
                        contentStream.endText();
                        contentStream.setNonStrokingColor(Color.BLACK);
                        textx += (maxCellValWidth + cellMargin);
                    }
                }

                texty -= rowHeight + CELL_HEIGHT * (maxCellHeight - 1);
                textx = margin + cellMargin;
                contentStream.drawLine(margin, texty, margin + tableWidth, texty);
            }

            // draw the columns
            contentStream.drawLine(margin, lastTexty, margin, texty);
            contentStream.drawLine(margin + firstColumnWidth, lastTexty, margin + firstColumnWidth, texty);
            contentStream.drawLine(margin + tableWidth, lastTexty, margin + tableWidth, texty);

            tableCount++;
        } while (tableCount * maxCols < content[0].length - 1);

        return (int) Math.floor(Math.abs(y - texty) / CELL_HEIGHT) + 1;
    }
    
    /**
     * Create dynamic column table content.
     *
     * @param rowNames
     *            row names
     * @param columnsNum
     *            number of columns
     * @return table content
     * @since SRT Phase 3-3 - BRS Tab Assembly
     */
    private static List<String[]> createDynColTableContent(String[] rowNames, int columnsNum) {
        List<String[]> content = new ArrayList<String[]>();
        for (String rowName : rowNames) {
            String[] row = new String[columnsNum + 1];
            row[0] = rowName;
            content.add(row);
        }
        return content;
    }

    /**
     * Create dynamic column table content.
     *
     * @param colNames
     *            column names
     * @param rowsNum
     *            number of rows
     * @return table content
     * @since 2.23
     */
    private static List<String[]> createLongWidthTableContent(List<String> colNames, int rowsNum) {
        List<String[]> content = new ArrayList<String[]>();
        for (String colName : colNames) {
            String[] col = new String[rowsNum + 1];
            col[0] = colName;
            content.add(col);
        }
        return content;
    }

    /**
     * <p>
     * Retrieves the total hours of knowledge transfer for Infrastructure (for all the subsections).
     * </p>
     *
     * @param infrastructureRequestData
     *            the infrastructureRequestData
     * @return the total hours of knowledge transfer for Infrastructure
     */
    private String getTotalHoursOfKnOwrowledgeTransferInf(InfrastructureRequestData infrastructureRequestData) {
        Float totalHours = 0f;
        DecimalFormat decimalFormat = new DecimalFormat("0.#");
        if (infrastructureRequestData.getSymmetrixMFServiceEnabled()) {
            SymmetrixMF symmetrixMF = infrastructureRequestData.getSymmetrixMF();
            if (symmetrixMF != null) {
                totalHours += Float.parseFloat(symmetrixMF.getKnowledgeTransferHours());
            }
        }
        if (infrastructureRequestData.getSymmetrixOSServiceEnabled()) {
            SymmetrixOS symmetrixOS = infrastructureRequestData.getSymmetrixOS();
            if (symmetrixOS != null) {
                totalHours += Float.parseFloat(symmetrixOS.getKnowledgeTransferHours());
            }
        }
        if (infrastructureRequestData.isDataMigrationServiceEnabled()) {
            DataMigrationInformation dataMigrationInformation = infrastructureRequestData
                    .getDataMigrationInformation();
            if (dataMigrationInformation != null) {
                totalHours += Float.parseFloat(dataMigrationInformation.getKnowledgeTransferHours());
            }
        }
        if (infrastructureRequestData.isVnxClariionServiceEnabled()) {
            VnxClariionInformation vnxClariionInformation = infrastructureRequestData.getVnxClariionInformation();
            if (vnxClariionInformation != null) {
                totalHours += Float.parseFloat(vnxClariionInformation.getKnowledgeTransferHours());
            }
        }
        if (infrastructureRequestData.getVplexServiceEnabled() && infrastructureRequestData.getVplex() != null 
            && infrastructureRequestData.getVplex().getKnowledgeTransferHours() != null) {
            totalHours += infrastructureRequestData.getVplex().getKnowledgeTransferHours().floatValue();
        }

        return decimalFormat.format(totalHours);
    }

    /**
     * <p>
     * Retrieves the total hours of knowledge transfer for Unified (for all the subsections).
     * </p>
     *
     * @param unifiedRequestData
     *            the unifiedRequestData
     * @return the total hours of knowledge transfer for Unified
     */
    private String getTotalHoursOfKnowledgeTransferUnified(UnifiedRequestData unifiedRequestData) {
        Float totalHours = 0f;
        DecimalFormat decimalFormat = new DecimalFormat("0.#");

        List<CelerraDetailInformation> celerraDetailInformation = unifiedRequestData.getCelerraDetailInformation();
        if (celerraDetailInformation != null && celerraDetailInformation.size() > 0) {
            totalHours += Float.parseFloat(unifiedRequestData.getCelerraDetailKnowledgeTransferHours());
        }
        List<NasMigrationInformation> nmis = unifiedRequestData.getNasMigrationInformation();
        if (unifiedRequestData.getServicesScope().isFileNasMigration() && nmis != null && nmis.size() > 0) {
            totalHours += Float.parseFloat(unifiedRequestData.getNasMigrationKnowledgeTransferHours());
        }
        return decimalFormat.format(totalHours);
    }

    /**
     * Get expenses table contents.
     *
     * @param estimatedResult
     *            The estimated result data
     * @return the contents
     * @since 2.23
     */
    private String[][] getExpensesTableContents(EstimatedResult estimatedResult) {
        List<String[]> rows = new ArrayList<String[]>();
        for (EstimatedLOB estimatedLob : estimatedResult.getEstimatedLOBs()) {
            String[] columns = new String[4];
            LOB lob = estimatedLob.getLob();
            columns[0] = trimToEmpty(lob == null ? "" : lob.getName());
            MaterialCode materialCode = estimatedLob.getMaterialCode();
            columns[1] = trimToEmpty(materialCode == null ? "" : materialCode.getName());
            Competency competency = estimatedLob.getCompetency();
            columns[2] = trimToEmpty(competency == null ? "" : competency.getName());
            columns[3] = Helper.decimal2GroupedString(estimatedLob.getExpenseAmount(), 2, true);
            rows.add(columns);
        }
        String[][] contents = new String[rows.size() + 1][4];
        DealCurrency dealCurrency = estimatedResult.getDealCurrency();
        contents[0] = new String[] { "LOB", "Material Code", "Competency", "Expense Amount\n( " + dealCurrency.getName() + " )" };
        for (int i = 0; i < rows.size(); i++) {
            contents[i + 1] = rows.get(i);
        }
        return contents;
    }

    /**
     * Get fixed price material codes discounting table contents.
     *
     * @param estimatedResult
     *            The estimated result data
     * @return the contents
     * @since 2.23
     */
    private String[][] getFPMCDiscountingTableContents(EstimatedResult estimatedResult) {
        List<String[]> rows = new ArrayList<String[]>();
        for (EstimatedLOB estimatedLob : estimatedResult.getEstimatedLOBs()) {
            String[] columns = new String[5];
            BillingType billingType = estimatedLob.getBillingType();
            if (billingType != null && billingType.getName().equals("Fixed Price")) {
                LOB lob = estimatedLob.getLob();
                columns[0] = trimToEmpty(lob == null ? "" : lob.getName());
                MaterialCode materialCode = estimatedLob.getMaterialCode();
                columns[1] = trimToEmpty(materialCode == null ? "" : materialCode.getName());
                Competency competency = estimatedLob.getCompetency();
                columns[2] = trimToEmpty(competency == null ? "" : competency.getName());
                columns[3] = Helper.decimal2GroupedString(estimatedLob.getTotalHours(), 2, true);
                BigDecimal discountPercent = estimatedLob.getDiscountPercent();
                columns[4] = discountPercent == null ? "" : Helper.decimal2GroupedString(discountPercent, 2, true)
                        + "%";
                rows.add(columns);
            }
        }
        String[][] contents = new String[rows.size() + 1][8];
        contents[0] = new String[] { "LOB", "Material Code", "Competency", "Total hours", "Discount %" };
        for (int i = 0; i < rows.size(); i++) {
            contents[i + 1] = rows.get(i);
        }
        return contents;
    }

    /**
     * Get time and materials discounting table contents.
     *
     * @param estimatedResult
     *            The estimated result data
     * @return the contents
     * @since 2.23
     */
    private String[][] getTMDiscountingTableContents(EstimatedResult estimatedResult) {
        List<String[]> rows = new ArrayList<String[]>();
        for (EstimatedLOB estimatedLob : estimatedResult.getEstimatedLOBs()) {
            BillingType billingType = estimatedLob.getBillingType();
            if (billingType != null && billingType.getName().equals("Time and Materials")) {
                LOB lob = estimatedLob.getLob();
                MaterialCode materialCode = estimatedLob.getMaterialCode();
                for (int i = 0; i < estimatedLob.getEstimatedResources().size(); i++) {
                    String[] columns = new String[6];
                    EstimatedResource lobResource = estimatedLob.getEstimatedResources().get(i);
                    columns[0] = trimToEmpty(lob == null ? "" : lob.getName());
                    columns[1] = trimToEmpty(materialCode == null ? "" : materialCode.getName());
                    Competency competency = lobResource.getCompetency();
                    columns[2] = trimToEmpty(lobResource == null ? "" : competency.getName());
                    BOERole role = lobResource.getRole();
                    columns[3] = trimToEmpty(role == null ? "" : role.getName());
                    columns[4] = Helper.decimal2GroupedString(lobResource.getBudgetedHours(), 2, true);
                    columns[5] = Helper.decimal2GroupedString(lobResource.getStandardBillRate(), 2, true);
                    rows.add(columns);
                }
            }
        }
        String[][] contents = new String[rows.size() + 1][10];
        contents[0] = new String[] { "LOB", "Material Code", "Competency", "Role", "Total hours", "Standard bill rate" };
        for (int i = 0; i < rows.size(); i++) {
            contents[i + 1] = rows.get(i);
        }
        return contents;
    }

    /**
     * <p>
     * Gets the value of specified Boolean object. If object is null then false
     * is returned.
     * </p>
     *
     * @param b
     *            boolean object.
     * @return boolean value.
     * @since 2.10
     */
    private static boolean getBooleanValue(Boolean b) {
        if (b == null) {
            return false;
        } else {
            return b.booleanValue();
        }
    }

    /**
     * This method checks whether the instance of the class was initialized properly.
     *
     * @throws ServiceRequestToolConfigurationException
     *             if enabledTabs/estimatesService is null
     */
    @PostConstruct
    protected void checkInit() {
        Helper.checkState(enabledTabs == null, "'enabledTabs' can't be null.");
        Helper.checkState(estimatesService == null, "'estimatesService' can't be null.");
    }

    /**
     * Setter method for property <tt>enabledTabs</tt>.
     *
     * @param enabledTabs
     *            value to be assigned to property enabledTabs
     */
    public void setEnabledTabs(EnabledTabs enabledTabs) {
        this.enabledTabs = enabledTabs;
    }

    /**
     * <p>
     * Sets the value to estimatesService field.
     * </p>
     *
     * @param estimatesService
     *            the value of estimatesService to set
     */
    public void setEstimatesService(EstimatesService estimatesService) {
        this.estimatesService = estimatesService;
    }
}

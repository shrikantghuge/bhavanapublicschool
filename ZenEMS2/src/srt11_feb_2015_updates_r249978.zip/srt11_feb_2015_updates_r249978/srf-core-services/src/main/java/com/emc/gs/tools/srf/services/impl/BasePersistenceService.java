/*
 * This code is copyright (c) 2013 - 2014 EMC Corporation.
 */
package com.emc.gs.tools.srf.services.impl;

import javax.annotation.PostConstruct;
import javax.persistence.EntityManager;

/**
 * <p>
 * This class is the base class for all services that use persistence. It simply aggregates JPA EntityManager.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: This class is effectively thread safe after configuration, the configuration is done
 * in a thread safe manner.
 * </p>
 *
 * @author faeton, stevenfrog
 * @version 1.0
 */
public abstract class BasePersistenceService extends BaseLoggerService {
    /**
     * Represents the JPA EntityManager instance used to implement the persistence operation. It is accessible by getter
     * and modified by setter. It is injected by Spring. It can not be null after injected.
     */
    private EntityManager entityManager;

    /**
     * Creates instance of the class.
     */
    protected BasePersistenceService() {
        // Empty
    }

    /**
     * This method checks whether the instance of the class was initialized properly.
     *
     * @throws ServiceRequestToolConfigurationException
     *             if entityManager is null
     */
    @PostConstruct
    protected void checkInit() {
        Helper.checkState(entityManager == null, "'entityManager' can't be null.");
    }

    /**
     * <p>
     * Retrieves the entityManager field.
     * </p>
     *
     * @return the entityManager
     */
    protected EntityManager getEntityManager() {
        return entityManager;
    }

    /**
     * <p>
     * Sets the value to entityManager field.
     * </p>
     *
     * @param entityManager
     *            the entityManager to set
     */
    public void setEntityManager(EntityManager entityManager) {
        this.entityManager = entityManager;
    }
}

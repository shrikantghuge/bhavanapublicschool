/*
 * This code is copyright (c) 2014 EMC Corporation.
 */
package com.emc.gs.tools.srf.services;

import org.springframework.mail.javamail.JavaMailSender;

import com.emc.gs.tools.srf.model.Profile;

/**
 * <p>
 * This interface defines a contract to create mail sender.
 * </p>
 * <p>
 * <strong>Thread safety</strong>: The implementation are required to be thread safe.
 * </p>
 * 
 * @author TCSASSEMBLER
 * @version 1.0
 * @since SRT Phase 4 - ET Assembly 2
 */
public interface MailSenderFactory {

    /**
     * Creates a mail sender.
     * 
     * @param profile
     *            The user profile
     * @throws IllegalArgumentException
     *             if profile is null
     * @return mail sender
     */
    public JavaMailSender createJavaMailSender(Profile profile);
}

/*
 * This code is copyright (c) 2014 EMC Corporation.
 */
package com.emc.gs.tools.srf.services;

/**
 * <p>
 * TThis service defines methods to for the application.
 * </p>
 *
 * <p>
 * <strong>Thread safety</strong>: The implementation are required to be thread safe.
 * </p>
 *
 * @author TCSASSEMBLER
 * @version 1.0
 * @since SRT Phase 4 - ET Assembly 2
 */
public interface AppService {

    /**
     * Indicates whether this application is cloud app or local app.
     * 
     * @return true for cloud app; false for local app.
     */
    public boolean isCloudApp();

    /**
     * Gets application identifier.
     * 
     * @return application identifier.
     */
    public String getAppIdentifier();

    /**
     * <p>Gets the flag indicating if application is operating in standalone mode or not.</p>
     *
     * @return a <code>boolean</code> providing the value for standalone property.
     * @since 1.1
     */
    public boolean isStandaloneMode();
}

/*
 * This code is copyright (c) 2014 EMC Corporation.
 */
package com.emc.gs.tools.srf.services;

import com.emc.gs.tools.srf.model.User;

/**
 * <p>
 * This service defines method to authenticate user.
 * </p>
 *
 * <p>
 * <strong>Thread safety</strong>: The implementation are required to be thread safe.
 * </p>
 *
 * <p>
 * <strong>Changes V1.1:</strong>
 * <strong>SRT Phase 4 - ET Assembly 2</strong>
 * <ul>
 * <li>Encapsulate the authentication logic in authenticate() method. User entity does
 * not need CURD functions at present.</li>
 * </ul>
 * </p>
 * 
 * @author zsudraco, TCSASSEMBLER
 * @version 1.1
 */
public interface UserService {

    /**
     * Authenticate given user.
     * 
     * @param user
     *            the user to be authenticated
     * @return the authenticated user
     * @throws IllegalArgumentException
     *             if given user is null, or if its userIdentifier is null or empty
     * @throws AuthorizationException
     *             if given user is not authorized
     * @throws ServiceRequestToolException
     *             if any other error occurred during the operation
     * @since SRT Phase 4 - ET Assembly 2
     */
    public User authenticate(User user) throws ServiceRequestToolException;
}

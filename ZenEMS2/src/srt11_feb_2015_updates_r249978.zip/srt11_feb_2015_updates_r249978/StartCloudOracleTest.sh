export MAVEN_OPTS="-Xms256m -Xmx1024m -XX:PermSize=128m -XX:MaxPermSize=256m -Dspring.profiles.active=dev"
mvn integration-test -P cloud-test,oracle $1